<?php

declare(strict_types=1);

require_once __DIR__ . '/../admin/includes/bootstrap.php';
require_once __DIR__ . '/../admin/includes/public-rate-limit.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function api_response(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function request_rate_limit_response(int $retryAfter): void
{
    header('Retry-After: ' . max(60, $retryAfter));
    api_response([
        'ok' => false,
        'errors' => ['Слишком много заявок за короткое время. Попробуйте отправить форму чуть позже или позвоните менеджеру.'],
    ], 429);
}

function request_busy_dates_for_car(string $carSlug, string $carName, string $startDate, string $endDate): array
{
    $start = parse_date_value($startDate);
    $end = parse_date_value($endDate);
    if (!$start || !$end || $end < $start) {
        return [];
    }

    $busyDates = [];
    $availabilityStatuses = availability_statuses();
    for ($day = $start; $day <= $end; $day = $day->modify('+1 day')) {
        $date = $day->format('Y-m-d');
        $entry = availability_entry_for_date($carSlug, $date);
        $status = is_array($entry) ? (string) ($entry['status'] ?? '') : '';
        if (isset($availabilityStatuses[$status])) {
            $busyDates[] = $date;
            continue;
        }

        foreach (read_rentals()['items'] as $existing) {
            $existing = normalize_rental_item($existing);
            if (is_rental_canceled($existing)) {
                continue;
            }

            foreach ($existing['vehicleSegments'] as $segment) {
                if ((string) ($segment['carSlug'] ?? '') !== $carSlug) {
                    continue;
                }
                if (in_array($date, rental_segment_date_keys($segment, $existing), true)) {
                    $busyDates[] = $date;
                    break 2;
                }
            }
        }
    }

    return array_values(array_unique($busyDates));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    api_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

if (trim((string) ($_POST['website'] ?? '')) !== '') {
    api_response(['ok' => true]);
}

$phone = trim((string) ($_POST['phone'] ?? ''));
$normalizedPhone = normalize_ru_phone($phone);
$consent = (string) ($_POST['consent'] ?? '');
$startDate = trim((string) ($_POST['start_date'] ?? ''));
$startTime = trim((string) ($_POST['start_time'] ?? ''));
$endDate = trim((string) ($_POST['end_date'] ?? ''));
$endTime = trim((string) ($_POST['end_time'] ?? ''));
$partnerSlug = trim((string) ($_POST['partner_slug'] ?? ''));
$partnerAgentSlug = trim((string) ($_POST['partner_agent_slug'] ?? ''));
$landingPageId = preg_replace('/[^a-zA-Z0-9_.:-]+/', '', trim((string) ($_POST['landing_page_id'] ?? ''))) ?? '';
$landingPageSlug = demand_transliterate((string) ($_POST['landing_page_slug'] ?? ''));
$postedAiReferralSource = preg_replace('/[^a-zA-Z0-9_-]+/', '', trim((string) ($_POST['ai_referral_source'] ?? ''))) ?? '';
$postedAiReferralMatchedBy = preg_replace('/[^a-zA-Z0-9_-]+/', '', trim((string) ($_POST['ai_referral_matched_by'] ?? ''))) ?? '';
$aiReferral = function_exists('demand_integrations_detect_ai_referrer')
    ? demand_integrations_detect_ai_referrer((string) ($_SERVER['HTTP_REFERER'] ?? ''), (string) ($_POST['utm_source'] ?? $postedAiReferralSource))
    : ['isAi' => false, 'source' => '', 'matchedBy' => ''];
if (empty($aiReferral['isAi']) && in_array($postedAiReferralSource, ['chatgpt', 'perplexity', 'copilot', 'other_ai'], true)) {
    $aiReferral = [
        'isAi' => true,
        'source' => $postedAiReferralSource,
        'matchedBy' => $postedAiReferralMatchedBy !== '' ? $postedAiReferralMatchedBy : 'client_metadata',
    ];
}
$carSlug = trim((string) ($_POST['car_slug'] ?? ''));
$requestKind = trim((string) ($_POST['request_kind'] ?? 'specific'));
if (!in_array($requestKind, ['specific', 'selection'], true)) {
    $requestKind = 'specific';
}
if ($requestKind === 'selection') {
    $carSlug = '';
}
$parsedStartDate = $startDate !== '' ? parse_date_value($startDate) : null;
$parsedEndDate = $endDate !== '' ? parse_date_value($endDate) : null;
$parsedStartTime = $startTime !== '' ? parse_time_value($startTime) : null;
$parsedEndTime = $endTime !== '' ? parse_time_value($endTime) : null;

$errors = [];
if ($phone === '') {
    $errors[] = 'Укажите телефон.';
} elseif ($normalizedPhone === null) {
    $errors[] = 'Проверьте телефон: нужен российский номер из 11 цифр, например +7-978-995-12-55 или 89789951255.';
}
if ($consent !== '1') {
    $errors[] = 'Нужно согласие на обработку данных.';
}
if ($startDate !== '' && !$parsedStartDate) {
    $errors[] = 'Некорректная дата начала аренды.';
}
if ($endDate !== '' && !$parsedEndDate) {
    $errors[] = 'Некорректная дата окончания аренды.';
}
if ($startTime !== '' && !$parsedStartTime) {
    $errors[] = 'Некорректное время подачи.';
}
if ($endTime !== '' && !$parsedEndTime) {
    $errors[] = 'Некорректное время возврата.';
}
if ($parsedStartDate && $parsedEndDate && $parsedEndDate < $parsedStartDate) {
    $errors[] = 'Дата окончания не может быть раньше даты начала.';
}
if ($parsedStartDate && $parsedEndDate && $parsedStartDate == $parsedEndDate && $parsedStartTime && $parsedEndTime && $parsedEndTime < $parsedStartTime) {
    $errors[] = 'Время возврата не может быть раньше времени подачи в один день.';
}
$partnerSubmissionGuard = $partnerSlug !== '' && function_exists('uav2_partner_submission_guard_begin')
    ? uav2_partner_submission_guard_begin($partnerSlug)
    : [];
$partner = null;
$partnerAgent = null;
if ($partnerSlug !== '') {
    $partner = find_partner_by_slug($partnerSlug);
    if (!$partner || empty($partner['active'])) {
        $errors[] = 'Партнёрская ссылка неактивна. Попросите менеджера проверить ссылку.';
    } elseif ($partnerAgentSlug !== '') {
        $partnerAgent = find_partner_agent((string) $partner['slug'], $partnerAgentSlug);
        if (!$partnerAgent) {
            $errors[] = 'Персональная ссылка представителя неактивна. Попросите менеджера проверить ссылку.';
        }
    }
    if ($partner && !partner_deal_public_context_is_valid((string) $partner['slug'], $partnerAgentSlug)) {
        $errors[] = 'Партнёрский источник не подтверждён. Откройте действующую ссылку партнёра и повторите отправку.';
    }
}

$car = null;
if ($carSlug === '' && $requestKind !== 'selection') {
    $errors[] = 'Выберите автомобиль или отправьте заявку на подбор.';
} elseif ($carSlug !== '') {
    $car = find_car($carSlug);
    if (!$car) {
        $errors[] = 'Выбранный автомобиль не найден. Обновите страницу и выберите машину заново.';
    }
}

if ($car && $partner && !public_car_visible_for_api($car, $partner, 'request_post')) {
    $errors[] = 'Этот автомобиль недоступен для вашего партнёрского контура.';
}
if ($car && !$partner && !public_car_visible_for_api($car, null, 'request_post')) {
    $errors[] = 'Этот автомобиль недоступен для выбранного канала заявки.';
}
if ($carSlug !== '' && PhpPublicationAutomation::unavailable($carSlug)) {
    api_response(['ok' => false, 'errors' => ['Автомобиль сейчас недоступен.']], 409);
}

if ($errors) {
    api_response(['ok' => false, 'errors' => $errors], 422);
}

if ($car && $parsedStartDate && $parsedEndDate) {
    $probe = default_rental_item();
    $probe['carSlug'] = $carSlug;
    $probe['carName'] = (string) ($car['name'] ?? $carSlug);
    $probe['startDate'] = $startDate;
    $probe['startTime'] = $startTime;
    $probe['endDate'] = $endDate;
    $probe['endTime'] = $endTime;
    $conflicts = rental_conflicts($probe, null);
    if ($conflicts) {
        $busyDates = request_busy_dates_for_car($carSlug, (string) ($car['name'] ?? $carSlug), $startDate, $endDate);
        api_response([
            'ok' => false,
            'error' => 'car_unavailable',
            'message' => 'Выбранный автомобиль уже недоступен на эти даты.',
            'carSlug' => $carSlug,
            'dateFrom' => $startDate,
            'dateTo' => $endDate,
            'busyDates' => $busyDates,
            'alternativesUrl' => '/cars/?date_from=' . rawurlencode($startDate) . '&date_to=' . rawurlencode($endDate),
            'selectionRequestAvailable' => true,
        ], 409);
    }
}

$quote = $car ? calculate_rate_quote($carSlug, $startDate, $startTime, $endDate, $endTime) : null;
$lessorSlug = $car ? car_lessor_slug($car) : '';
$selectionScopeFields = $car ? [] : [
    'car_owner_scope_id' => 'rent_rk',
    'car_owner_type' => 'rent_rk',
    'responsible_scope_id' => 'rent_rk',
    'settlement_counterparty_type' => 'rent_rk',
    'settlement_counterparty_scope_id' => 'rent_rk',
];
$partnerFields = array_merge(
    partner_request_fields($partner),
    request_partner_context_fields($partner, $car),
    partner_agent_request_fields($partnerAgent)
);
$pickupPlace = trim((string) ($_POST['pickup_place'] ?? ''));
if ($pickupPlace === '' && $partner) {
    $pickupPlace = (string) ($partner['defaultPickupPlace'] ?? '');
}
$postedCarName = trim((string) ($_POST['car_name'] ?? ''));
$carName = $requestKind === 'selection'
    ? 'Подбор автомобиля'
    : ($postedCarName !== '' ? $postedCarName : (string) ($car['name'] ?? ''));
$requestPayload = [
    'carSlug' => $carSlug,
    'carName' => $carName,
    'requestKind' => $requestKind,
    'customerName' => trim((string) ($_POST['name'] ?? '')),
    'phone' => $normalizedPhone ?? $phone,
    'startDate' => $startDate,
    'startTime' => $startTime,
    'endDate' => $endDate,
    'endTime' => $endTime,
    'pickupPlace' => $pickupPlace,
    'returnPlace' => trim((string) ($_POST['return_place'] ?? '')),
    'message' => trim((string) ($_POST['message'] ?? '')),
    'quote' => $quote,
    'source' => $partner ? ('partner:' . $partner['slug'] . ($partnerAgent ? ':' . $partnerAgent['slug'] : '')) : (string) ($_SERVER['HTTP_REFERER'] ?? ''),
    'sourcePage' => (string) ($_SERVER['HTTP_REFERER'] ?? ''),
    'sourceLandingPageId' => $landingPageId,
    'sourceLandingPageSlug' => $landingPageSlug,
    'aiReferralSource' => !empty($aiReferral['isAi']) ? (string) ($aiReferral['source'] ?? '') : '',
    'aiReferralMatchedBy' => !empty($aiReferral['isAi']) ? (string) ($aiReferral['matchedBy'] ?? '') : '',
];
if ($lessorSlug !== '') {
    $requestPayload['lessorSlug'] = $lessorSlug;
}
try {
    $intent = $_POST;
    unset($intent['command_id'], $intent['website']);
    $intent['phone'] = $normalizedPhone;
    $commandId = business_command_id($_POST['command_id'] ?? null);
    $rateLimitReservation = ['status' => 'not_started'];
    $result = public_request_command('request', $commandId, $intent,
        static function () use ($normalizedPhone, $phone, $requestPayload, $partnerFields, $selectionScopeFields, $commandId, $intent, &$rateLimitReservation): array {
            $rateLimitReservation = public_rate_limit_reserve('request', $normalizedPhone ?? $phone, $commandId, $intent);
            if (($rateLimitReservation['status'] ?? '') === 'denied') {
                throw new PublicRateLimitExceeded((int) ($rateLimitReservation['retryAfter'] ?? 60));
            }
            return add_request(array_merge($requestPayload, $partnerFields, $selectionScopeFields));
        });
    $request = $result['request'];
    public_rate_limit_finish($rateLimitReservation, true);
} catch (Throwable $exception) {
    if (isset($rateLimitReservation)) {
        public_rate_limit_finish($rateLimitReservation, false);
    }
    if ($exception instanceof PublicRateLimitExceeded) {
        request_rate_limit_response($exception->retryAfter());
    }
    api_response(['ok' => false, 'errors' => [$exception instanceof InvalidArgumentException || $exception->getCode() === 409
        ? $exception->getMessage() : 'Не удалось сохранить заявку. Повторите отправку позже.']],
        in_array($exception->getCode(), [409, 503], true) ? $exception->getCode() : ($exception instanceof InvalidArgumentException ? 422 : 503));
}
if ($partnerSubmissionGuard) {
    uav2_partner_submission_guard_end($partnerSubmissionGuard);
    $partnerSubmissionGuard = [];
}
if ($result['replayed']) api_response(['ok' => true, 'id' => $request['id'], 'telegramSent' => false, 'message' => 'Заявка уже принята. Менеджер свяжется с вами.']);
if ($partner) {
    analytics_record_request_event('partner_lead_created', $request, [
        'partnerAgentSlug' => (string) ($request['partnerAgentSlug'] ?? ''),
        'requestKind' => $requestKind,
    ]);
}

$tg = static fn($value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$requestAdminUrl = alert_admin_path('requests.php?open=' . rawurlencode((string) $request['id']));
$requestActionLabel = $requestKind === 'selection'
    ? 'Открыть заявку на подбор автомобиля'
    : (!empty($request['partnerName']) ? 'Открыть партнёрскую заявку' : 'Открыть заявку по автомобилю');
$requestActionLine = telegram_action_line($requestActionLabel, $requestAdminUrl);
$telegramText = "Новая заявка Rent RK\n"
    . ($requestKind === 'selection' ? "Тип заявки: подбор автомобиля\n" : "")
    . "Авто: " . $tg($request['carName'] ?: $request['carSlug']) . "\n"
    . "Клиент: " . $tg($request['customerName'] ?: 'не указано') . "\n"
    . "Телефон: " . $tg($request['phone']) . "\n"
    . "Период: " . $tg(format_request_period($request)) . "\n"
    . (!empty($request['partnerName']) ? "Партнёр: " . $tg($request['partnerName']) . "\n" : "")
    . (!empty($request['partnerAgentName']) ? "Представитель: " . $tg($request['partnerAgentName']) . "\n" : "")
    . ($quote ? "Расчёт: " . $tg(format_quote_summary($quote)) . "\n" : "")
    . "Подача: " . $tg($request['pickupPlace'] ?: 'не указано') . "\n"
    . "Возврат: " . $tg($request['returnPlace'] ?: 'не указано') . "\n"
    . "ID: " . $tg($request['id']) . "\n"
    . ($requestActionLine !== '' ? $requestActionLine : $tg($requestAdminUrl));

$telegramSent = false;
if (!defined('TELEGRAM_NOTIFY_REQUESTS') || TELEGRAM_NOTIFY_REQUESTS) {
    try {
        $telegramSent = send_telegram_message($telegramText);
    } catch (Throwable $exception) {
        technical_log('request_notification_failed_after_commit', ['reason' => get_class($exception)]);
    }
}

api_response([
    'ok' => true,
    'id' => $request['id'],
    'telegramSent' => $telegramSent,
    'message' => 'Заявка отправлена. Менеджер свяжется с вами.',
]);
