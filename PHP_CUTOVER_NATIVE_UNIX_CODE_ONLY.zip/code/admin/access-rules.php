<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
require_permission('access-rules.manage');

if (current_admin_role() !== 'admin') {
    deny_scope_access();
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? 'save');

    try {
        $disabledAction = RentalReturnStore::transaction(static function () use ($action): bool {
        require_permission('access-rules.manage');
        if (current_admin_role() !== 'admin') deny_scope_access();
        business_assert_form_version([ACCESS_RULES_FILE, CARS_FILE, LESSORS_FILE], $_POST['expected_version'] ?? null);
        if ($action === 'disable') {
            $disabled = disable_access_rule((string) ($_POST['id'] ?? ''));
            if (!$disabled) {
                throw new RuntimeException('Правило доступа не найдено.');
            }
            return true;
        }
        if ($action !== 'save') throw new InvalidArgumentException('Неизвестное действие.');
        upsert_access_rule([
            'id' => (string) ($_POST['id'] ?? ''),
            'from_scope_id' => (string) ($_POST['from_scope_id'] ?? ''),
            'to_scope_id' => (string) ($_POST['to_scope_id'] ?? ''),
            'cars' => isset($_POST['cars']) && is_array($_POST['cars']) ? $_POST['cars'] : [],
            'allow_lessor_managers' => isset($_POST['allow_lessor_managers']),
            'allow_lessor_partners' => isset($_POST['allow_lessor_partners']),
            'status' => (string) ($_POST['status'] ?? 'active'),
            'comment' => (string) ($_POST['comment'] ?? ''),
        ]);
        return false;
        });
        $rebuilt = rebuild_public_site();
        redirect_to('access-rules.php?' . ($disabledAction ? 'disabled' : 'saved') . '=1&rebuilt=' . ($rebuilt ? '1' : '0'));
    } catch (Throwable $exception) {
        http_response_code(in_array((int) $exception->getCode(), [403, 409, 503], true) ? (int) $exception->getCode() : 400);
        $error = $exception->getMessage();
    }
}

$rebuildWarning = PhpPublicationCutover::selected()
    ? 'Публичные файлы не обновлены. Изменение правила не разрешает автоматическую публикацию.'
    : 'Автоматическая пересборка не удалась. Запустите tools/build-site.ps1 вручную.';
if (isset($_GET['saved'])) {
    $message = ((string) ($_GET['rebuilt'] ?? '1') === '1')
        ? 'Правило доступа сохранено.'
        : 'Правило доступа сохранено. ' . $rebuildWarning;
}
if (isset($_GET['disabled'])) {
    $message = ((string) ($_GET['rebuilt'] ?? '1') === '1')
        ? 'Правило доступа отключено.'
        : 'Правило доступа отключено. ' . $rebuildWarning;
}

$rules = read_access_rules()['items'];
$fromOptions = ['rent_rk' => 'Rent RK'] + access_rule_scope_options(true);
$toOptions = access_rule_scope_options(false);
unset($toOptions['rent_rk']);
$editId = (string) ($_GET['edit'] ?? '');
$editingRule = null;
foreach ($rules as $rule) {
    if ((string) ($rule['id'] ?? '') === $editId) {
        $editingRule = $rule;
        break;
    }
}

$selectedFromScope = $editingRule['from_scope_id'] ?? (array_key_exists('rent_rk', $fromOptions) ? 'rent_rk' : (array_key_first($fromOptions) ?: ''));
$selectedToScope = $editingRule['to_scope_id'] ?? (array_key_first(array_filter($toOptions, static fn($scopeId): bool => (string) $scopeId !== (string) $selectedFromScope, ARRAY_FILTER_USE_KEY)) ?: '');
$selectedCars = $editingRule['cars'] ?? [];
$selectedStatus = $editingRule ? (string) ($editingRule['status'] ?? 'active') : 'active';
if (!in_array($selectedStatus, ['active', 'disabled'], true)) {
    $selectedStatus = 'active';
}
$carsByScope = [];
foreach ($fromOptions as $scopeId => $label) {
    $carsByScope[$scopeId] = cars_for_owner_scope((string) $scopeId);
}

admin_header('Доступы к паркам', 'access_rules');
?>
<section class="page-head">
  <div>
    <p class="eyebrow">Партнёрские контуры</p>
    <h1>Доступы к паркам</h1>
    <p class="muted">Точечно открывайте автомобили одного контура другому арендодателю. Эти правила не управляют общей витриной партнёров Rent RK.</p>
  </div>
</section>

<?php if ($message): ?><div class="notice success"><?= e($message) ?></div><?php endif; ?>
<?php if ($error): ?><div class="notice error"><?= e($error) ?></div><?php endif; ?>

<article class="panel user-editor">
  <div class="panel-head">
    <div>
      <h2><?= $editingRule ? 'Редактировать правило' : 'Создать правило доступа' ?></h2>
      <p class="muted">access_rules открывают чужие автомобили контурам арендодателей, их менеджерам и партнёрам. Партнёры Rent RK работают через флаги витрины, а не через эти правила.</p>
    </div>
    <?php if ($editingRule): ?><a class="btn secondary" href="access-rules.php">Новое правило</a><?php endif; ?>
  </div>
  <form method="post" class="partner-admin-form">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="save">
    <?= business_form_version_field([ACCESS_RULES_FILE, CARS_FILE, LESSORS_FILE]) ?>
    <?php if ($editingRule): ?>
      <input type="hidden" name="id" value="<?= e((string) $editingRule['id']) ?>">
      <input type="hidden" name="from_scope_id" value="<?= e((string) $selectedFromScope) ?>">
      <input type="hidden" name="to_scope_id" value="<?= e((string) $selectedToScope) ?>">
      <label>Чей парк открыт <input value="<?= e(scope_display_name((string) $selectedFromScope)) ?>" disabled></label>
      <label>Кому открыт доступ <input value="<?= e(scope_display_name((string) $selectedToScope)) ?>" disabled></label>
    <?php else: ?>
      <label>
        Чей парк открываем
        <select name="from_scope_id" data-access-from-scope>
          <?php foreach ($fromOptions as $scopeId => $label): ?>
            <option value="<?= e((string) $scopeId) ?>" <?= (string) $selectedFromScope === (string) $scopeId ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
        <span class="field-hint">Выберите контур, чей парк открывается другому участнику системы.</span>
      </label>
      <label>
        Кому открываем доступ
        <select name="to_scope_id">
          <option value="">Выберите контур арендодателя</option>
          <?php foreach ($toOptions as $scopeId => $label): ?>
            <option value="<?= e((string) $scopeId) ?>" data-access-to-option <?= (string) $selectedToScope === (string) $scopeId ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
        <span class="field-hint">Выберите контур арендодателя, которому будет открыт доступ.</span>
      </label>
    <?php endif; ?>

    <div class="rate-field-wide">
      <strong>Какие автомобили открываем</strong>
      <?php foreach ($carsByScope as $scopeId => $scopeCars): ?>
        <div class="access-cars-group" data-access-cars-scope="<?= e((string) $scopeId) ?>">
          <p class="muted"><?= e(scope_display_name((string) $scopeId)) ?></p>
          <?php if (!$scopeCars): ?>
            <p class="field-hint">В этом контуре пока нет автомобилей.</p>
          <?php endif; ?>
          <?php foreach ($scopeCars as $car): ?>
            <?php $carSlug = (string) ($car['slug'] ?? ''); ?>
            <label class="check-row">
              <input type="checkbox" name="cars[]" value="<?= e($carSlug) ?>" <?= in_array($carSlug, $selectedCars, true) ? 'checked' : '' ?>>
              <span><?= e((string) ($car['name'] ?? $carSlug)) ?> <small class="muted"><?= e($carSlug) ?></small></span>
            </label>
          <?php endforeach; ?>
        </div>
      <?php endforeach; ?>
    </div>

    <label class="check-row rate-field-wide">
      <input type="checkbox" name="allow_lessor_managers" value="1" <?= !empty($editingRule['allow_lessor_managers'] ?? false) ? 'checked' : '' ?>>
      <span>Видят менеджеры арендодателя</span>
    </label>
    <p class="field-hint rate-field-wide">Если включено, менеджеры выбранного арендодателя смогут видеть эти автомобили в своём рабочем контуре.</p>

    <label class="check-row rate-field-wide">
      <input type="checkbox" name="allow_lessor_partners" value="1" <?= !empty($editingRule['allow_lessor_partners'] ?? false) ? 'checked' : '' ?>>
      <span>Видят партнёры арендодателя</span>
    </label>
    <p class="field-hint rate-field-wide">Если включено, партнёры выбранного арендодателя смогут видеть эти автомобили и создавать по ним заявки. Расчёты с такими партнёрами остаются ответственностью арендодателя.</p>

    <label>
      Статус
      <select name="status">
        <option value="active" <?= $selectedStatus === 'active' ? 'selected' : '' ?>>Активно</option>
        <option value="disabled" <?= $selectedStatus === 'disabled' ? 'selected' : '' ?>>Отключено</option>
      </select>
    </label>
    <label class="rate-field-wide">Внутренний комментарий <textarea name="comment" rows="3"><?= e((string) ($editingRule['comment'] ?? '')) ?></textarea></label>
    <button class="btn" type="submit"><?= $editingRule ? 'Сохранить правило' : 'Создать правило' ?></button>
  </form>
</article>

<article class="panel">
  <div class="panel-head">
    <div>
      <h2>Существующие правила</h2>
      <p class="muted">Отключение не удаляет правило физически, чтобы сохранялась история настройки доступа.</p>
    </div>
  </div>
  <?php if (!$rules): ?>
    <p class="muted">Правила доступа ещё не созданы.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="report-table">
        <thead>
          <tr>
            <th>Чей парк открыт</th>
            <th>Кому открыт доступ</th>
            <th>Машины</th>
            <th>Менеджеры</th>
            <th>Партнёры</th>
            <th>Статус</th>
            <th>Обновлено</th>
            <th>Действия</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rules as $rule): ?>
            <tr>
              <th><?= e(scope_display_name((string) $rule['from_scope_id'])) ?></th>
              <td><?= e(scope_display_name((string) $rule['to_scope_id'])) ?></td>
              <td><?= count($rule['cars']) ?></td>
              <td><?= !empty($rule['allow_lessor_managers']) ? 'да' : 'нет' ?></td>
              <td><?= !empty($rule['allow_lessor_partners']) ? 'да' : 'нет' ?></td>
              <td><span class="status status-<?= $rule['status'] === 'active' ? 'free' : 'busy' ?>"><?= $rule['status'] === 'active' ? 'активно' : 'отключено' ?></span></td>
              <td><?= e(format_ru_date((string) ($rule['updated_at'] ?: $rule['created_at']))) ?></td>
              <td>
                <div class="table-actions">
                  <a class="small-link" href="access-rules.php?edit=<?= e(rawurlencode((string) $rule['id'])) ?>">редактировать</a>
                  <?php if ($rule['status'] !== 'disabled'): ?>
                    <form method="post" onsubmit="return confirm('Отключить это правило доступа?');">
                      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                      <input type="hidden" name="action" value="disable">
                      <?= business_form_version_field([ACCESS_RULES_FILE, CARS_FILE, LESSORS_FILE]) ?>
                      <input type="hidden" name="id" value="<?= e((string) $rule['id']) ?>">
                      <button class="small-link danger-link" type="submit">отключить</button>
                    </form>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</article>

<script>
(() => {
  const select = document.querySelector('[data-access-from-scope]');
  const toSelect = document.querySelector('select[name="to_scope_id"]');
  const groups = Array.from(document.querySelectorAll('[data-access-cars-scope]'));
  const sync = () => {
    const active = select ? select.value : '<?= e((string) $selectedFromScope) ?>';
    groups.forEach((group) => {
      const visible = group.dataset.accessCarsScope === active;
      group.hidden = !visible;
      group.querySelectorAll('input[type="checkbox"]').forEach((input) => {
        input.disabled = !visible;
      });
    });
    if (toSelect) {
      const options = Array.from(toSelect.querySelectorAll('option[data-access-to-option]'));
      options.forEach((option) => {
        const sameScope = option.value === active;
        option.hidden = sameScope;
        option.disabled = sameScope;
      });
      if (toSelect.value === active || toSelect.selectedOptions[0]?.disabled) {
        const next = options.find((option) => !option.disabled);
        toSelect.value = next ? next.value : '';
      }
    }
  };
  sync();
  if (select) {
    select.addEventListener('change', sync);
  }
})();
</script>

<?php admin_footer(); ?>
