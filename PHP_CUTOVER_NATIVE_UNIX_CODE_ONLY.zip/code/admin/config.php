<?php
declare(strict_types=1);
if (!defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || !RENT_RK_AUDIT_ISOLATION_VERIFIED) { throw new RuntimeException('Synthetic config requires audit isolation'); }
if (!defined('ADMIN_USER')) define('ADMIN_USER', 'qa-dry-root');
define('ADMIN_PASSWORD_SALT', '');
define('ADMIN_PASSWORD_HASH', '');
define('TELEGRAM_BOT_TOKEN', '');
define('TELEGRAM_CHAT_ID', '');
