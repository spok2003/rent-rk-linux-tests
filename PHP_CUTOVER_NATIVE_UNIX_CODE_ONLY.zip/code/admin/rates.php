<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
require_admin();

$message = '';
$error = '';
$allCars = read_cars();
$fields = rate_fields();
$rates = read_rates();
$rawCars = is_file(CARS_FILE) ? read_json_file(CARS_FILE, []) : $allCars;
$rawRates = is_file(RATES_FILE) ? read_json_file(RATES_FILE, []) : $rates;
$returnTo = admin_safe_return_to($_GET['return_to'] ?? $_POST['return_to'] ?? '', '');
$requestedScopeId = trim((string) ($_GET['scope_id'] ?? $_POST['scope_id'] ?? ''));
$activeScopeId = $requestedScopeId;

if (!current_user_is_platform_admin()) {
    $activeScopeId = current_user_data_scope_id();
    if ($activeScopeId === '') {
        $activeScopeId = 'rent_rk';
    }
    if ($requestedScopeId !== '' && $requestedScopeId !== $activeScopeId) {
        deny_scope_access();
    }
}

if (!current_user_can_view_tariffs($activeScopeId)) {
    deny_scope_access();
}

$canEditTariffs = current_user_can_edit_tariffs($activeScopeId);
$canEditSystemRateFields = current_user_is_platform_admin();
$canEditCarIdentityFields = current_user_can_edit_car_identity($activeScopeId);
$canEditCarMarketValueFields = current_user_can_edit_car_market_value($activeScopeId);
$cars = array_values(array_filter($allCars, static function (array $car) use ($activeScopeId): bool {
    return $activeScopeId === '' || car_owner_scope_id($car) === $activeScopeId;
}));
$allowedCarSlugs = array_fill_keys(array_map(static fn(array $car): string => (string) ($car['slug'] ?? ''), $cars), true);
$formVersion = rates_form_version($activeScopeId);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (!$canEditTariffs) {
        deny_scope_access();
    }

    $postedRates = isset($_POST['rates']) && is_array($_POST['rates']) ? $_POST['rates'] : [];
    $postedCars = isset($_POST['cars']) && is_array($_POST['cars']) ? $_POST['cars'] : [];
    $nextRates = $rawRates;
    $rateErrors = [];
    try {
    foreach (['rates', 'cars'] as $key) {
        if (isset($_POST[$key]) && !is_array($_POST[$key])) throw new InvalidArgumentException('Неверная структура формы. Изменения не сохранены.');
    }
    if (!is_string($_POST['form_version'] ?? null) || !hash_equals($formVersion, $_POST['form_version'])) {
        $rateErrors[] = 'Данные изменились после открытия формы. Обновите страницу и повторите изменения.';
        http_response_code(409);
    }
    $allowedRateKeys = array_merge(array_keys($fields), ['depositAmount']);
    $allowedCarKeys = ['hourlyAvailable', 'mileageLimitPerDay', 'extraMileageRate'];
    if ($canEditCarIdentityFields) $allowedCarKeys = array_merge($allowedCarKeys, ['plateNumber', 'vin', 'registrationCertificate']);
    if ($canEditCarMarketValueFields) $allowedCarKeys[] = 'marketValue';
    if ($canEditSystemRateFields) $allowedCarKeys = array_merge($allowedCarKeys, ['ownershipType', 'ownerName', 'ownerCommissionType', 'ownerCommissionValue']);
    foreach ([[$postedRates, $allowedRateKeys], [$postedCars, $allowedCarKeys]] as [$rows, $allowedKeys]) {
        foreach ($rows as $slug => $row) {
            if (empty($allowedCarSlugs[$slug]) || !is_array($row) || array_diff(array_keys($row), $allowedKeys)
                || array_filter($row, static fn($value): bool => !is_scalar($value) && $value !== null)) {
                $rateErrors[] = 'Форма содержит неизвестные или недоступные поля. Изменения не сохранены.';
            }
        }
    }
    if (!$canEditSystemRateFields && array_key_exists('default_deposit', $_POST)) $rateErrors[] = 'Общий залог недоступен для изменения.';
    if (array_key_exists('default_deposit', $_POST) && !is_scalar($_POST['default_deposit'])) $rateErrors[] = 'Неверный формат общего залога.';
    if ($rateErrors) throw new InvalidArgumentException(implode("\n", $rateErrors));
    if ($canEditSystemRateFields && preg_match('/-\s*\d/', (string) ($_POST['default_deposit'] ?? ''))) {
        $rateErrors[] = 'Общий залог не может быть отрицательным.';
    }
    if ($canEditSystemRateFields && array_key_exists('default_deposit', $_POST)
        && normalize_rate_price($_POST['default_deposit']) !== ($rates['settings']['defaultDeposit'] ?? null)) {
        $nextRates['settings']['defaultDeposit'] = normalize_rate_price($_POST['default_deposit']);
    }
    $nextCars = $rawCars;
    $rawCarIndexes = array_flip(array_map(static fn(array $car): string => (string) ($car['slug'] ?? ''), $rawCars));

    foreach ($allCars as $index => $car) {
        $slug = (string) ($car['slug'] ?? '');
        if ($slug === '' || empty($allowedCarSlugs[$slug])) {
            continue;
        }
        if (!array_key_exists($slug, $postedRates) && !array_key_exists($slug, $postedCars)) continue;
        $index = $rawCarIndexes[$slug];

        $posted = isset($postedRates[$slug]) && is_array($postedRates[$slug]) ? $postedRates[$slug] : [];
        $record = $rawRates['cars'][$slug] ?? [];
        $effectiveRecord = $rates['cars'][$slug] ?? default_rate_for_car($car);
        foreach (array_keys($fields) as $field) {
            if (array_key_exists($field, $posted) && normalize_rate_price($posted[$field]) !== ($effectiveRecord[$field] ?? null)) {
                $record[$field] = normalize_rate_price($posted[$field]);
            }
        }
        if (preg_match('/-\s*\d/', (string) ($posted['depositAmount'] ?? ''))) {
            $rateErrors[] = 'Индивидуальный залог не может быть отрицательным: ' . (string) ($car['name'] ?? $slug) . '.';
        }
        if (array_key_exists('depositAmount', $posted) && normalize_rate_price($posted['depositAmount']) !== ($effectiveRecord['depositAmount'] ?? null)) {
            $record['depositAmount'] = normalize_rate_price($posted['depositAmount']);
        }

        if (array_key_exists('base', $record) && $record['base'] === null) {
            $record['base'] = normalize_rate_price($car['price'] ?? null);
        }

        if ($record !== ($rawRates['cars'][$slug] ?? [])) {
            $record['updatedAt'] = now_iso();
            $nextRates['cars'][$slug] = $record;
        }

        $postedCar = isset($postedCars[$slug]) && is_array($postedCars[$slug]) ? $postedCars[$slug] : [];
        $carDocuments = normalize_car_document_fields($car);
        $nextCars[$index]['hourlyAvailable'] = array_key_exists('hourlyAvailable', $postedCar) ? !empty($postedCar['hourlyAvailable']) : ($car['hourlyAvailable'] ?? false);
        $nextCars[$index]['mileageLimitPerDay'] = normalize_mileage_limit($postedCar['mileageLimitPerDay'] ?? ($car['mileageLimitPerDay'] ?? null)) ?? default_mileage_limit_per_day();
        $nextCars[$index]['extraMileageRate'] = normalize_rate_price($postedCar['extraMileageRate'] ?? ($car['extraMileageRate'] ?? null));
        $identityKeys = ['plateNumber', 'vin', 'registrationCertificate'];
        if (!$canEditCarIdentityFields) {
            foreach ($identityKeys as $identityKey) {
                if (array_key_exists($identityKey, $postedCar)) {
                    $rateErrors[] = 'Недостаточно прав для изменения VIN, госномера или СТС: ' . (string) ($car['name'] ?? $slug) . '.';
                    break;
                }
            }
        } else {
            $licensePlate = normalize_car_license_plate($postedCar['plateNumber'] ?? ($carDocuments['licensePlate'] ?? ''));
            $nextCars[$index]['plateNumber'] = $licensePlate;
            $nextCars[$index]['licensePlate'] = $licensePlate;
            $nextCars[$index]['vin'] = trim((string) ($postedCar['vin'] ?? ($carDocuments['vin'] ?? '')));
            $registrationCertificate = trim((string) ($postedCar['registrationCertificate'] ?? ($carDocuments['registrationCertificate'] ?? '')));
            $currentRegistrationCertificate = trim((string) ($carDocuments['registrationCertificate'] ?? ''));
            $registrationChanged = $registrationCertificate !== $currentRegistrationCertificate;
            if ($registrationChanged && $registrationCertificate !== '' && !car_registration_certificate_input_is_valid($registrationCertificate)) {
                $rateErrors[] = 'СТС можно вводить цифрами подряд или через пробел/дефис/тире после серии: ' . (string) ($car['name'] ?? $slug) . '.';
            } elseif ($registrationChanged && $registrationCertificate !== '' && car_registration_certificate_digit_count($registrationCertificate) !== 10) {
                $rateErrors[] = 'СТС должен содержать 10 цифр: серия 4 цифры и номер 6 цифр: ' . (string) ($car['name'] ?? $slug) . '.';
            }
            $nextCars[$index]['registrationCertificate'] = normalize_car_registration_certificate($registrationCertificate);
        }
        if (!$canEditCarMarketValueFields && array_key_exists('marketValue', $postedCar)) {
            $rateErrors[] = 'Недостаточно прав для изменения рыночной стоимости: ' . (string) ($car['name'] ?? $slug) . '.';
        } elseif ($canEditCarMarketValueFields) {
            $nextCars[$index]['marketValue'] = normalize_rate_price($postedCar['marketValue'] ?? ($carDocuments['marketValue'] ?? null));
        }
        if ($canEditSystemRateFields) {
            $ownershipType = (string) ($postedCar['ownershipType'] ?? ($car['ownershipType'] ?? 'own'));
            if (!isset(car_ownership_types()[$ownershipType])) {
                $ownershipType = 'own';
            }
            $ownerCommissionType = (string) ($postedCar['ownerCommissionType'] ?? ($car['ownerCommissionType'] ?? 'rent_rk_percent'));
            if (!isset(owner_commission_types()[$ownerCommissionType])) {
                $ownerCommissionType = 'rent_rk_percent';
            }
            $nextCars[$index]['ownershipType'] = $ownershipType;
            $nextCars[$index]['ownerName'] = trim((string) ($postedCar['ownerName'] ?? ($car['ownerName'] ?? '')));
            $nextCars[$index]['ownerCommissionType'] = $ownerCommissionType;
            $nextCars[$index]['ownerCommissionValue'] = normalize_rate_price($postedCar['ownerCommissionValue'] ?? ($car['ownerCommissionValue'] ?? null));
        }
        $postedCarFieldMap = ['licensePlate' => 'plateNumber'];
        $displayFields = array_merge($car, $carDocuments, car_mileage_policy($car), normalize_car_finance_fields($car));
        $displayFields['hourlyAvailable'] = !empty($car['hourlyAvailable']);
        $displayFields['plateNumber'] = $carDocuments['licensePlate'] ?? '';
        foreach ($nextCars[$index] as $key => $value) {
            $inputKey = $postedCarFieldMap[$key] ?? $key;
            $displayValue = $displayFields[$key] ?? null;
            if (!array_key_exists($inputKey, $postedCar) || $displayValue === $value) {
                if (array_key_exists($key, $rawCars[$index])) $nextCars[$index][$key] = $rawCars[$index][$key];
                else unset($nextCars[$index][$key]);
            }
        }
    }

        if ($rateErrors) {
            throw new InvalidArgumentException(implode("\n", $rateErrors));
        }
        $queued = RentalReturnStore::transaction(static function () use ($nextCars, $nextRates, $activeScopeId, $canEditSystemRateFields, $formVersion, $allowedCarSlugs): bool {
            if (!current_user_can_edit_tariffs($activeScopeId) || !hash_equals($formVersion, rates_form_version($activeScopeId))) {
                throw new RuntimeException('Данные или права изменились. Обновите страницу.', 409);
            }
            $before = [];
            if (PhpPublicationAutomation::enabled()) {
                foreach (array_keys($allowedCarSlugs) as $slug) {
                    $before[$slug] = PhpPublicationAutomation::tariff($slug);
                }
            }
            write_json_file(CARS_FILE, $nextCars);
            $nextRates['updatedAt'] = now_iso();
            write_json_file(RATES_FILE, $nextRates);
            audit_log('rates.update', 'rates', $activeScopeId === '' ? 'all' : $activeScopeId, 'Изменены тарифы автомобилей', [
                'scope_id' => $activeScopeId === '' ? 'all' : $activeScopeId,
            ]);
            if ($canEditSystemRateFields) {
                audit_log('car.documents.update', 'car', 'all', 'Изменены данные автомобилей для документов');
            }
            $queued = false;
            foreach ($before as $slug => $publicRate) {
                $queued = PhpPublicationAutomation::ratesSaved($slug, $publicRate) || $queued;
            }
            return $queued;
        });
        if (PhpPublicationAutomation::enabled()) {
            $resultMessage = $queued ? 'Сохранено. Ожидает публикации.' : 'Сохранено. Публичные файлы не изменялись.';
            if ($queued && PhpPublicationCutover::selected()) {
                $execution = PhpPublicationCutover::status()['execution'] ?? null;
                if ($execution !== 'running') $resultMessage = $execution === 'paused'
                    ? 'Сохранено. Задание ожидает: исполнитель приостановлен.'
                    : 'Сохранено. Не опубликовано: проверьте режим публикации.';
            }
            $_SESSION[$returnTo !== '' ? 'admin_flash_message' : 'php_rates_flash'] = $resultMessage;
            redirect_to($returnTo !== '' ? $returnTo : 'rates.php');
        }
        if ($returnTo !== '') {
            $_SESSION['admin_flash_message'] = 'Тарифы и залог сохранены. Калькулятор на публичной карточке использует их сразу.';
        }
        redirect_to($returnTo !== '' ? $returnTo : 'rates.php?saved=1');
    } catch (Throwable $exception) {
        if (in_array($exception->getCode(), [403, 409, 503], true)) http_response_code($exception->getCode());
        $error = $exception->getMessage();
    }
}

if (!PhpPublicationAutomation::enabled() && isset($_GET['saved'])) {
    $message = 'Тарифы сохранены. Калькулятор на публичной карточке использует их сразу.';
}
if (PhpPublicationAutomation::enabled() && isset($_SESSION['php_rates_flash'])) {
    $message = (string) $_SESSION['php_rates_flash'];
    unset($_SESSION['php_rates_flash']);
}

$rates = read_rates();
$fieldDisabledAttr = $canEditTariffs ? '' : ' disabled';
$systemFieldDisabledAttr = ($canEditSystemRateFields && $canEditTariffs) ? '' : ' disabled';
$identityFieldDisabledAttr = ($canEditCarIdentityFields && $canEditTariffs) ? '' : ' disabled';
$marketValueFieldDisabledAttr = ($canEditCarMarketValueFields && $canEditTariffs) ? '' : ' disabled';
$scopeQuerySuffix = $activeScopeId !== '' ? '?' . http_build_query(['scope_id' => $activeScopeId]) : '';

admin_header('Тарифы', 'rates');
?>
<section class="page-head">
  <div>
    <p class="eyebrow">Цены</p>
    <h1>Тарифы по автомобилям</h1>
    <p class="muted">Пустые поля не применяются. Приоритет расчёта: индивидуальная цена, праздники, срок аренды, сезон, базовая цена.</p>
  </div>
  <div class="actions">
    <a class="btn secondary" href="../cars/index.html" target="_blank" rel="noreferrer">Открыть каталог</a>
  </div>
</section>

<?php if ($message): ?><div class="notice success"><?= e($message) ?></div><?php endif; ?>
<?php if ($error): ?><div class="notice error"><?= e($error) ?></div><?php endif; ?>
<?php if (!$canEditTariffs): ?>
  <div class="notice">У вас есть доступ только на просмотр тарифов. Сохранение изменений недоступно.</div>
<?php endif; ?>
<?php if ($canEditTariffs && (!$canEditCarIdentityFields || !$canEditCarMarketValueFields)): ?>
  <div class="notice">Чувствительные поля автомобиля отделены от тарифов: <?= !$canEditCarIdentityFields ? 'VIN, госномер и СТС недоступны без права cars.identity.edit. ' : '' ?><?= !$canEditCarMarketValueFields ? 'Рыночная стоимость недоступна без права cars.market_value.edit.' : '' ?></div>
<?php endif; ?>
<?php if ($activeScopeId !== ''): ?>
  <div class="notice">Показаны тарифы контура: <?= e(scope_display_name($activeScopeId)) ?>.</div>
<?php endif; ?>

<article class="panel rate-rules">
  <h2>Правила сезонности</h2>
  <p class="muted">Высокий сезон сейчас считается для июня-сентября, низкий — для ноября-марта. Праздники: 1-8 января, 23 февраля, 8 марта, 1 мая, 9 мая, 12 июня, 4 ноября.</p>
</article>

<form method="post" class="rates-form">
  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="form_version" value="<?= e($formVersion) ?>">
  <?php if ($activeScopeId !== ''): ?><input type="hidden" name="scope_id" value="<?= e($activeScopeId) ?>"><?php endif; ?>
  <?php if ($returnTo !== ''): ?><input type="hidden" name="return_to" value="<?= e($returnTo) ?>"><?php endif; ?>
  <?php if ($canEditSystemRateFields): ?>
  <article class="panel rate-rules">
    <h2>Залог по умолчанию</h2>
    <p class="muted">Эта сумма автоматически подставляется в новую карточку аренды и в аренду, созданную из заявки. В самой аренде залог можно изменить вручную.</p>
    <label class="rate-default-deposit">
      Залог
      <input
        type="number"
        min="0"
        step="100"
        inputmode="numeric"
        name="default_deposit"
        value="<?= e(($rates['settings']['defaultDeposit'] ?? null) === null ? '' : $rates['settings']['defaultDeposit']) ?>"
        placeholder="руб."
        <?= $fieldDisabledAttr ?>
      >
    </label>
  </article>
  <?php endif; ?>
  <section class="rates-grid">
    <?php foreach ($cars as $car): ?>
      <?php
        $slug = (string) ($car['slug'] ?? '');
        $record = rate_for_car($slug, $car);
        $carFinance = normalize_car_finance_fields($car);
        $publicationSummary = car_publication_summary($car);
      ?>
      <article class="rate-card" id="<?= e($slug) ?>">
        <div class="rate-card-media">
          <img src="../<?= e($car['image'] ?? '') ?>" alt="">
        </div>
        <div class="rate-card-body">
          <div class="rate-card-head">
            <div>
              <h2><?= e($car['name'] ?? '') ?></h2>
              <p><span class="status <?= $publicationSummary['isPublicVisible'] ? 'status-free' : 'status-canceled' ?>"><?= e($publicationSummary['publicLabel']) ?></span></p>
              <p class="muted"><?= e($car['class'] ?? '') ?> · <?= e($car['seats'] ?? '') ?> мест</p>
            </div>
            <?php if (!empty($publicationSummary['isPublicVisible'])): ?>
              <a class="small-link" href="../cars/<?= e($slug) ?>.html" target="_blank" rel="noreferrer">Карточка</a>
            <?php else: ?>
              <span class="small-link muted">Скрыта</span>
            <?php endif; ?>
          </div>
          <div class="rate-fields">
            <label>
              Индивидуальный залог
              <input
                type="number"
                min="0"
                step="100"
                inputmode="numeric"
                name="rates[<?= e($slug) ?>][depositAmount]"
                value="<?= e(($record['depositAmount'] ?? null) === null ? '' : $record['depositAmount']) ?>"
                placeholder="<?= e(($rates['settings']['defaultDeposit'] ?? null) === null ? 'общий залог не задан' : 'по умолчанию ' . format_money((int) $rates['settings']['defaultDeposit'])) ?>"
                <?= $fieldDisabledAttr ?>
              >
              <span class="field-hint">Если пусто, новая аренда возьмёт общий залог по умолчанию.</span>
            </label>
            <?php foreach ($fields as $field => $label): ?>
              <?php $value = $record[$field] ?? null; ?>
              <label class="<?= $field === 'manual' ? 'rate-field-wide' : '' ?>">
                <?= e($label) ?>
                <input
                  type="number"
                  min="0"
                  step="100"
                  inputmode="numeric"
                  name="rates[<?= e($slug) ?>][<?= e($field) ?>]"
                  value="<?= e($value === null ? '' : $value) ?>"
                  placeholder="<?= $field === 'base' ? 'обязательно' : 'не задано' ?>"
                  <?= $fieldDisabledAttr ?>
                >
                <?php if ($field === 'hourly' && empty($car['hourlyAvailable'])): ?>
                  <span class="field-hint">Почасовой расчёт применится только если у авто включена почасовая аренда.</span>
                <?php endif; ?>
                <?php if ($field === 'manual'): ?>
                  <span class="field-hint">Если заполнено, эта цена перекрывает остальные тарифы для автомобиля.</span>
                <?php endif; ?>
              </label>
            <?php endforeach; ?>
          </div>
          <div class="rate-fields document-car-fields">
            <label class="check-row rate-field-wide">
              <input type="hidden" name="cars[<?= e($slug) ?>][hourlyAvailable]" value="0"<?= $fieldDisabledAttr ?>>
              <input type="checkbox" name="cars[<?= e($slug) ?>][hourlyAvailable]" value="1" <?= !empty($car['hourlyAvailable']) ? 'checked' : '' ?><?= $fieldDisabledAttr ?>>
              <span>Почасовая аренда включена</span>
            </label>
            <?php $mileagePolicy = car_mileage_policy($car); ?>
            <?php $carDocuments = normalize_car_document_fields($car); ?>
            <label>
              Лимит пробега в сутки
              <input type="number" min="0" step="1" inputmode="numeric" name="cars[<?= e($slug) ?>][mileageLimitPerDay]" value="<?= e((string) $mileagePolicy['mileageLimitPerDay']) ?>" placeholder="250"<?= $fieldDisabledAttr ?>>
            </label>
            <label>
              Стоимость 1 км перепробега
              <input type="number" min="0" step="1" inputmode="numeric" name="cars[<?= e($slug) ?>][extraMileageRate]" value="<?= e($mileagePolicy['extraMileageRate'] === null ? '' : $mileagePolicy['extraMileageRate']) ?>" placeholder="руб./км"<?= $fieldDisabledAttr ?>>
            </label>
            <label>
              Госномер
              <input data-license-plate-input name="cars[<?= e($slug) ?>][plateNumber]" value="<?= e($carDocuments['licensePlate'] ?? '') ?>" placeholder="А000АА 82"<?= $identityFieldDisabledAttr ?>>
              <?php if (!$canEditCarIdentityFields): ?><span class="field-hint">Нужно право cars.identity.edit.</span><?php endif; ?>
            </label>
            <label>
              VIN
              <input name="cars[<?= e($slug) ?>][vin]" value="<?= e($carDocuments['vin'] ?? '') ?>" placeholder="VIN"<?= $identityFieldDisabledAttr ?>>
              <?php if (!$canEditCarIdentityFields): ?><span class="field-hint">Нужно право cars.identity.edit.</span><?php endif; ?>
            </label>
            <label>
              Рыночная стоимость
              <input type="number" min="0" step="100" inputmode="numeric" name="cars[<?= e($slug) ?>][marketValue]" value="<?= e($carDocuments['marketValue'] === null ? '' : (string) $carDocuments['marketValue']) ?>" placeholder="руб."<?= $marketValueFieldDisabledAttr ?>>
              <?php if (!$canEditCarMarketValueFields): ?><span class="field-hint">Нужно право cars.market_value.edit.</span><?php endif; ?>
            </label>
            <label class="rate-field-wide">
              СТС
              <input name="cars[<?= e($slug) ?>][registrationCertificate]" value="<?= e($carDocuments['registrationCertificate'] ?? '') ?>" placeholder="серия и номер свидетельства"<?= $identityFieldDisabledAttr ?>>
              <?php if (!$canEditCarIdentityFields): ?><span class="field-hint">Нужно право cars.identity.edit.</span><?php endif; ?>
            </label>
          </div>
          <div class="rate-fields document-car-fields">
            <label>
              Финансовая модель
              <select name="cars[<?= e($slug) ?>][ownershipType]"<?= $systemFieldDisabledAttr ?>>
                <?php foreach (car_ownership_types() as $key => $label): ?>
                  <option value="<?= e($key) ?>" <?= $key === $carFinance['ownershipType'] ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
            <label>
              Владелец / источник
              <input name="cars[<?= e($slug) ?>][ownerName]" value="<?= e($carFinance['ownerName']) ?>" placeholder="например: Иван, партнёрский парк"<?= $systemFieldDisabledAttr ?>>
            </label>
            <label>
              Правило комиссии
              <select name="cars[<?= e($slug) ?>][ownerCommissionType]"<?= $systemFieldDisabledAttr ?>>
                <?php foreach (owner_commission_types() as $key => $label): ?>
                  <option value="<?= e($key) ?>" <?= $key === $carFinance['ownerCommissionType'] ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
            <label>
              Значение
              <input
                type="number"
                min="0"
                step="1"
                inputmode="numeric"
                name="cars[<?= e($slug) ?>][ownerCommissionValue]"
                value="<?= e($carFinance['ownerCommissionValue'] === null ? '' : $carFinance['ownerCommissionValue']) ?>"
                placeholder="% или руб."
                <?= $systemFieldDisabledAttr ?>
              >
            </label>
            <p class="field-hint rate-field-wide">Для своего авто вся стоимость аренды считается доходом Rent RK. Для авто на комиссии отчёты покажут долю Rent RK и выплату владельцу отдельно от партнёрских комиссий.</p>
          </div>
        </div>
      </article>
    <?php endforeach; ?>
    <?php if (!$cars): ?>
      <article class="panel admin-empty">
        <p>В доступном контуре пока нет автомобилей для настройки тарифов.</p>
      </article>
    <?php endif; ?>
  </section>

  <?php if ($canEditTariffs): ?>
  <div class="sticky-save">
    <span class="muted">Сохранение обновит файл data/rates.json.</span>
    <button class="btn" type="submit">Сохранить тарифы</button>
  </div>
  <?php endif; ?>
</form>
<?php admin_footer(); ?>
