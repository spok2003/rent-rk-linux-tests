<?php

declare(strict_types=1);

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['action'] ?? '') === 'publish_dry_run') {
    define('RENT_RK_PHP_CAR_PREVIEW_REQUEST', true);
}
require_once __DIR__ . '/includes/bootstrap.php';

if (defined('RENT_RK_PHP_CAR_PREVIEW_REQUEST') && PhpPublicationCutover::selected()) {
    try { RentalReturnStore::enter(true); }
    catch (RuntimeException $e) {
        http_response_code($e->getCode() === 409 ? 409 : 503);
        exit('Предварительная проверка остановлена: ' . $e->getMessage());
    }
}
require_permission('cars.edit');

function car_edit_find_index(array $cars, string $slug): ?int
{
    foreach ($cars as $index => $car) {
        if (normalize_car_slug((string) ($car['slug'] ?? '')) === $slug) {
            return $index;
        }
    }

    return null;
}

function car_edit_value(array $car, string $key): string
{
    $value = $car[$key] ?? '';
    if (is_array($value)) {
        return implode("\n", array_map(static fn($item): string => trim((string) $item), $value));
    }

    return trim((string) $value);
}

function car_edit_list_from_post(string $key, int $limit = 8, int $itemLimit = 80): array
{
    $raw = trim((string) ($_POST[$key] ?? ''));
    if ($raw === '') {
        return [];
    }

    $items = preg_split('/\r\n|\r|\n|,/', $raw) ?: [];
    $normalized = [];
    foreach ($items as $item) {
        $item = preg_replace('/\s+/u', ' ', trim((string) $item)) ?? '';
        if ($item === '') {
            continue;
        }
        if (mb_strlen($item) > $itemLimit) {
            $item = mb_substr($item, 0, $itemLimit);
        }
        if (!in_array($item, $normalized, true)) {
            $normalized[] = $item;
        }
        if (count($normalized) >= $limit) {
            break;
        }
    }

    return $normalized;
}

function car_edit_text_from_post(string $key, int $limit, array &$errors, string $label): string
{
    $value = preg_replace('/\s+/u', ' ', trim((string) ($_POST[$key] ?? ''))) ?? '';
    if (mb_strlen($value) > $limit) {
        $errors[] = $label . ': максимум ' . $limit . ' символов.';
        $value = mb_substr($value, 0, $limit);
    }

    return $value;
}

function car_edit_int_from_post(string $key, ?int $default, int $min, int $max, array &$errors, string $label): ?int
{
    $raw = trim((string) ($_POST[$key] ?? ''));
    if ($raw === '') {
        return $default;
    }

    $raw = str_replace([' ', "\xc2\xa0"], '', $raw);
    if (!preg_match('/^-?\d+$/', $raw)) {
        $errors[] = $label . ': укажите число.';
        return $default;
    }

    $value = (int) $raw;
    if ($value < $min || $value > $max) {
        $errors[] = $label . ': допустимо от ' . $min . ' до ' . $max . '.';
        return $default;
    }

    return $value;
}

function car_edit_extra_specs_from_post(): array
{
    $keys = $_POST['extraSpecs_key'] ?? [];
    $labels = $_POST['extraSpecs_label'] ?? [];
    $values = $_POST['extraSpecs_value'] ?? [];
    $units = $_POST['extraSpecs_unit'] ?? [];
    $sorts = $_POST['extraSpecs_sort'] ?? [];
    foreach (['keys', 'labels', 'values', 'units', 'sorts'] as $varName) {
        if (!is_array($$varName)) {
            $$varName = [$$varName];
        }
    }

    $rows = [];
    $count = min(20, max(count($keys), count($labels), count($values), count($units), count($sorts)));
    for ($index = 0; $index < $count; $index++) {
        $rows[] = [
            'key' => (string) ($keys[$index] ?? ''),
            'label' => (string) ($labels[$index] ?? ''),
            'value' => (string) ($values[$index] ?? ''),
            'unit' => (string) ($units[$index] ?? ''),
            'sort' => (string) ($sorts[$index] ?? ''),
        ];
    }

    return normalize_car_extra_specs($rows);
}

function car_edit_structured_fields_from_post(): array
{
    return normalize_car_structured_fields([
        'brand' => (string) ($_POST['brand'] ?? ''),
        'model' => (string) ($_POST['model'] ?? ''),
        'year' => $_POST['year'] ?? null,
        'generation' => (string) ($_POST['generation'] ?? ''),
        'trim' => (string) ($_POST['trim'] ?? ''),
        'bodyType' => (string) ($_POST['bodyType'] ?? ''),
        'fuelType' => (string) ($_POST['fuelType'] ?? ''),
        'color' => (string) ($_POST['color'] ?? ''),
        'doors' => $_POST['doors'] ?? null,
        'enginePowerHp' => $_POST['enginePowerHp'] ?? null,
        'engineDisplacementL' => $_POST['engineDisplacementL'] ?? null,
        'electricRangeKm' => $_POST['electricRangeKm'] ?? null,
        'equipment' => $_POST['equipment'] ?? [],
        'extraSpecs' => car_edit_extra_specs_from_post(),
    ]);
}

function car_edit_options_by_group(array $options): array
{
    $groups = [];
    foreach ($options as $code => $option) {
        if (!is_array($option) || empty($option['isActive'])) {
            continue;
        }
        $group = trim((string) ($option['group'] ?? ''));
        if ($group === '') {
            $group = 'Другое';
        }
        $groups[$group][$code] = $option;
    }

    return $groups;
}

function car_edit_structured_readiness_missing(array $fields): array
{
    $missing = [];
    if (trim((string) ($fields['brand'] ?? '')) === '') {
        $missing[] = 'бренд';
    }
    if (trim((string) ($fields['model'] ?? '')) === '') {
        $missing[] = 'модель';
    }
    if (($fields['year'] ?? null) === null) {
        $missing[] = 'год';
    }

    return $missing;
}

function car_edit_terms(array $car): array
{
    $terms = isset($car['specialRentalTerms']) && is_array($car['specialRentalTerms']) ? $car['specialRentalTerms'] : [];

    return [
        'enabled' => !empty($terms['enabled']),
        'minDays' => isset($terms['minDays']) && $terms['minDays'] !== '' ? (int) $terms['minDays'] : null,
        'deliveryText' => trim((string) ($terms['deliveryText'] ?? '')),
        'note' => trim((string) ($terms['note'] ?? '')),
    ];
}

function car_edit_split_preview(array $items): string
{
    $items = array_values(array_filter($items, static fn($item): bool => trim((string) $item) !== ''));
    if (!$items) {
        return '<p class="muted">Не заполнено.</p>';
    }

    $html = array_map(static fn($item): string => '<span>' . e((string) $item) . '</span>', $items);
    return '<div class="car-content-editor-chips">' . implode('', $html) . '</div>';
}

function car_edit_public_dirty_fields(): array
{
    return [
        'name',
        'class',
        'brand',
        'model',
        'year',
        'generation',
        'trim',
        'bodyType',
        'fuelType',
        'color',
        'doors',
        'enginePowerHp',
        'engineDisplacementL',
        'electricRangeKm',
        'equipment',
        'extraSpecs',
        'seats',
        'drive',
        'transmission',
        'engine',
        'price',
        'hourlyAvailable',
        'image',
        'shortScenario',
        'cardDescription',
        'detailDescription',
        'bestFor',
        'strongPoints',
        'cardBadgesCustom',
        'specialRentalTerms',
        'seoTitle',
        'seoDescription',
        'adminStatus',
        'publicStatus',
        'isPublished',
        'publishChannels',
    ];
}

function car_edit_can_publish_single_page(): bool
{
    return has_permission('cars.publish') || has_permission('content.publish.single_page');
}

function car_edit_status_class(string $state): string
{
    return match ($state) {
        'current' => 'is-current',
        'dirty' => 'is-dirty',
        'conflict' => 'is-conflict',
        'unavailable' => 'is-unavailable',
        'unknown_ownership' => 'is-unknown',
        'baseline_missing' => 'is-unknown',
        default => 'is-check',
    };
}

function car_edit_admin_route_exists(string $route): bool
{
    $route = trim(str_replace('\\', '/', $route), '/');
    if ($route === '' || str_contains($route, '..') || !preg_match('/^[a-z0-9_\/-]+\.php$/i', $route)) {
        return false;
    }

    return is_file(__DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $route));
}

function car_edit_descriptive_name(array $car, array $structuredFields, string $fallbackSlug): string
{
    $parts = [];
    foreach (['brand', 'model', 'year'] as $field) {
        $value = trim((string) ($structuredFields[$field] ?? ''));
        if ($value !== '') {
            $parts[] = $value;
        }
    }
    if ($parts) {
        return implode(' ', $parts);
    }

    return trim((string) ($car['name'] ?? '')) ?: $fallbackSlug;
}

function car_edit_description_present(array $car): bool
{
    foreach (['cardDescription', 'detailDescription', 'description', 'publicDescription', 'summary'] as $field) {
        if (trim((string) ($car[$field] ?? '')) !== '') {
            return true;
        }
    }

    return false;
}

function car_edit_seo_present(array $car): bool
{
    return trim((string) ($car['seoTitle'] ?? '')) !== ''
        && trim((string) ($car['seoDescription'] ?? '')) !== '';
}

function car_edit_promo_scope_matches_car(array $scope, string $slug, string $scopeId): bool
{
    $type = (string) ($scope['type'] ?? '');
    if ($type === 'single_car') {
        return normalize_car_slug((string) ($scope['carSlug'] ?? '')) === $slug;
    }
    if ($type === 'selected_cars') {
        return in_array($slug, array_map(static fn($item): string => normalize_car_slug((string) $item), (array) ($scope['carSlugs'] ?? [])), true);
    }
    if ($type === 'contour') {
        return contour_page_content_normalize_scope_id((string) ($scope['contourSlug'] ?? '')) === $scopeId;
    }
    if ($type === 'central') {
        return $scopeId === 'rent_rk';
    }

    return $type === 'global';
}

function car_edit_active_promo_count(string $slug, string $scopeId): ?int
{
    if (!function_exists('can_view_promo_badges') || !can_view_promo_badges()) {
        return null;
    }

    $today = function_exists('promo_badge_today_key') ? promo_badge_today_key() : date('Y-m-d');
    $count = 0;
    foreach (promo_badges_visible_to_user() as $item) {
        $item = promo_badge_normalize_item($item);
        if ((string) ($item['status'] ?? '') !== 'active') {
            continue;
        }
        $activeFrom = (string) ($item['activeFrom'] ?? '');
        $activeTo = (string) ($item['activeTo'] ?? '');
        if ($activeFrom !== '' && $activeFrom > $today) {
            continue;
        }
        if ($activeTo !== '' && $activeTo < $today) {
            continue;
        }
        if (car_edit_promo_scope_matches_car(promo_badge_normalize_scope($item['scope'] ?? []), $slug, $scopeId)) {
            $count++;
        }
    }

    return $count;
}

function car_edit_working_state(string $availabilityStatus, array $serviceHolds): array
{
    if ($serviceHolds || $availabilityStatus === 'service') {
        return ['label' => 'В сервисе', 'tone' => 'service', 'hint' => 'Есть сервисная недоступность или активное удержание.'];
    }

    return match ($availabilityStatus) {
        'free' => ['label' => 'Свободна', 'tone' => 'ok', 'hint' => 'На сегодня нет явной занятости в календаре.'],
        'reserved' => ['label' => 'Забронирована', 'tone' => 'warning', 'hint' => 'Календарь показывает бронь на сегодня.'],
        'busy' => ['label' => 'В аренде', 'tone' => 'busy', 'hint' => 'Календарь показывает занятость на сегодня.'],
        'unavailable', 'blocked', 'problem' => ['label' => 'Недоступна', 'tone' => 'danger', 'hint' => 'Календарь показывает ограничение.'],
        default => ['label' => 'Рабочее состояние требует проверки', 'tone' => 'warning', 'hint' => 'Не удалось надежно определить состояние из текущих источников.'],
    };
}

function car_edit_publication_human_status(array $publicationSummary, array $publicationBuildStatus): array
{
    $state = (string) ($publicationBuildStatus['state'] ?? '');
    if (!empty($publicationBuildStatus['dirty'])) {
        return ['label' => 'Есть неопубликованные изменения', 'tone' => 'warning', 'hint' => 'После сохранения карточку нужно проверить и обновить через штатный publish workflow.'];
    }
    if (in_array($state, ['conflict', 'baseline_missing', 'unavailable', 'needs_check'], true)) {
        return ['label' => 'Публикация требует проверки', 'tone' => 'warning', 'hint' => (string) ($publicationBuildStatus['label'] ?? 'Нужна проверка публикации.')];
    }
    if (!empty($publicationSummary['isPublicVisible'])) {
        return ['label' => 'Опубликовано', 'tone' => 'ok', 'hint' => 'Автомобиль видим в публичном канале Rent RK.'];
    }
    if ((string) ($publicationSummary['publicStatus'] ?? '') === 'hidden') {
        return ['label' => 'Скрыто', 'tone' => 'muted', 'hint' => 'Публичная витрина сейчас не должна показывать эту машину.'];
    }

    return ['label' => 'Публикация требует проверки', 'tone' => 'warning', 'hint' => (string) ($publicationSummary['publicLabel'] ?? 'Статус не определен полностью.')];
}

function car_edit_primary_next_action(array $context): array
{
    if (!empty($context['structuredMissing'])) {
        return ['label' => 'Проверить данные', 'href' => '#car-editor-identification', 'tone' => 'warning'];
    }
    if (empty($context['priceOk'])) {
        return ['label' => 'Заполнить цену', 'href' => (string) ($context['tariffsUrl'] ?? ''), 'tone' => 'warning'];
    }
    if (empty($context['depositOk'])) {
        return ['label' => 'Заполнить залог', 'href' => (string) ($context['tariffsUrl'] ?? ''), 'tone' => 'warning'];
    }
    if (empty($context['photoOk'])) {
        return ['label' => 'Добавить/проверить фото', 'href' => '#car-editor-card-fields', 'tone' => 'warning'];
    }
    if (!empty($context['serviceHoldCount'])) {
        return ['label' => 'Открыть календарь', 'href' => (string) ($context['calendarUrl'] ?? ''), 'tone' => 'service'];
    }
    if (!empty($context['publicationNeedsCheck'])) {
        return ['label' => 'Проверить публикацию', 'href' => (string) ($context['pageContentUrl'] ?? '#car-editor-publication-technical'), 'tone' => 'warning'];
    }
    if (!empty($context['publicVisible'])) {
        return ['label' => 'Открыть витрину', 'href' => (string) ($context['publicUrl'] ?? ''), 'tone' => 'ok'];
    }

    return ['label' => 'Вернуться в автопарк', 'href' => 'cars.php', 'tone' => 'muted'];
}

$cars = read_cars();
$id = normalize_car_slug((string) ($_POST['id'] ?? $_GET['id'] ?? ''));
if ($id !== '') require_car_scope($id);
$message = '';
$error = '';
$warning = '';
$rebuildResult = null;
$publishDryRunResult = null;
$singleCarPublishResult = null;
$publicationPlan = null;
$publicationApplyResult = null;
$canPublish = has_permission('cars.publish');
$canPublishSinglePage = car_edit_can_publish_single_page();
$rebuildStatus = public_site_rebuild_status();
$canRebuildPublicSite = $canPublish && !empty($rebuildStatus['available']);
$rebuildUnavailableMessage = $canPublish && !$canRebuildPublicSite
    ? (string) ($rebuildStatus['message'] ?? 'Пересборка публичного сайта недоступна на этом сервере.')
    : '';

if ($id === '') {
    admin_header('Редактор контента автомобилей', 'cars');
    ?>
    <section class="page-head">
      <div>
        <p class="eyebrow">Контент автомобилей</p>
        <h1>Выберите автомобиль</h1>
        <p class="muted">Редактор меняет только карточку и публичные тексты. Тарифы, заявки, аренды и календарь остаются в своих разделах.</p>
      </div>
      <a class="btn secondary" href="cars.php">Автопарк</a>
    </section>
    <section class="panel car-content-editor-list">
      <?php foreach (scope_cars_for_current_user($cars) as $car): ?>
        <?php $slug = normalize_car_slug((string) ($car['slug'] ?? '')); ?>
        <?php if ($slug === '') { continue; } ?>
        <a href="car-edit.php?id=<?= e($slug) ?>">
          <strong><?= e((string) ($car['name'] ?? $slug)) ?></strong>
          <span><?= e($slug) ?></span>
        </a>
      <?php endforeach; ?>
    </section>
    <?php
    admin_footer();
    exit;
}

$index = car_edit_find_index($cars, $id);
if ($index === null) {
    http_response_code(404);
    admin_header('Автомобиль не найден', 'cars');
    echo '<section class="page-head"><div><p class="eyebrow">Контент автомобилей</p><h1>Автомобиль не найден</h1><p class="muted">Проверьте slug в адресе.</p></div><a class="btn secondary" href="car-edit.php">Выбрать автомобиль</a></section>';
    admin_footer();
    exit;
}

$car = $cars[$index];
$carVersion = business_record_version(CARS_FILE, $id, 'slug');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? 'save');

    if ($action === 'publish_dry_run') {
        if (!$canPublishSinglePage) {
            http_response_code(403);
            exit('Недостаточно прав.');
        }
        $publishDryRunResult = run_car_publish_dry_run($id, static function () use ($id): bool {
            if (!has_permission('cars.edit') || !car_edit_can_publish_single_page()) {
                return false;
            }
            foreach (scope_cars_for_current_user(read_cars()) as $candidate) {
                if (normalize_car_slug((string) ($candidate['slug'] ?? '')) === $id) {
                    return true;
                }
            }
            return false;
        });
        if (($publishDryRunResult['reason'] ?? '') === 'access_changed') {
            http_response_code(403);
            exit('Publication access changed. Reload the page.');
        }
        if (!empty($publishDryRunResult['unavailable'])) {
            $warning = (string) ($publishDryRunResult['error'] ?? 'Проверка сборки на этом сервере недоступна.');
        } elseif (!empty($publishDryRunResult['success'])) {
            $parsed = $publishDryRunResult['parsed'] ?? [];
            $unknownCount = count($parsed['unknownOwnership'] ?? []);
            $conflictCount = count($parsed['conflicts'] ?? []);
            if ($conflictCount > 0) {
                $warning = 'Dry-run нашёл conflict generated-файла. Реальная публикация заблокирована.';
            } elseif ($unknownCount > 0) {
                $warning = 'Dry-run выполнен. Есть unknown ownership: нужна безопасная baseline/ownership проверка перед публикацией.';
            } else {
                $message = 'Dry-run проверки публичной страницы выполнен: блокирующих conflicts/unknown ownership не найдено.';
            }
        } else {
            $error = (string) ($publishDryRunResult['error'] ?? 'Dry-run проверки публичной страницы не выполнен.');
        }
    } elseif ($action === 'guarded_publish_preflight') {
        if (!$canPublishSinglePage) {
            http_response_code(403);
            exit('Недостаточно прав.');
        }
        try {
            $publicationPlan = car_publication_prepare_plan($id);
            $message = 'План публикации сохранён. Проверьте список файлов и подтвердите его отдельным действием.';
        } catch (Throwable $exception) {
            http_response_code(in_array($exception->getCode(), [403, 404, 409], true) ? $exception->getCode() : 503);
            $warning = $exception->getMessage();
        }
    } elseif ($action === 'guarded_publish_apply') {
        if (!$canPublishSinglePage) {
            http_response_code(403);
            exit('Недостаточно прав.');
        }
        try {
            if ((string) ($_POST['confirm_publication_plan'] ?? '') !== '1') {
                throw new RuntimeException('Подтвердите применение просмотренного плана.', 409);
            }
            $publicationApplyResult = car_publication_apply_plan(
                (string) ($_POST['publication_plan_id'] ?? ''),
                (string) ($_POST['publication_plan_digest'] ?? ''),
                $id
            );
            $publicationPlan = $publicationApplyResult['plan'] ?? null;
            $message = !empty($publicationApplyResult['alreadyApplied'])
                ? 'Этот план уже был применён. Повторная запись не выполнялась.'
                : 'План публикации применён одной транзакцией.';
        } catch (Throwable $exception) {
            http_response_code(in_array($exception->getCode(), [403, 404, 409], true) ? $exception->getCode() : 503);
            $warning = $exception->getMessage();
        }
    } elseif ($action === 'publish_single_car') {
        if (!$canPublishSinglePage) {
            http_response_code(403);
            exit('Недостаточно прав.');
        }
        http_response_code(409);
        $singleCarPublishResult = [
            'enabled' => false,
            'reason' => 'prepared_but_disabled',
            'message' => 'Реальная single-car публикация подготовлена, но отключена на Stage 2. Сначала нужен known ownership baseline, dry-run без conflicts/unknown ownership и безопасный режим с -Backup.',
        ];
        $warning = $singleCarPublishResult['message'];
    } elseif ($action === 'rebuild') {
        require_permission('cars.publish');
        http_response_code(409);
        $warning = 'Устаревшая полная пересборка из карточки отключена: она не обеспечивает единую фиксацию данных и публичных файлов.';
    } elseif ($action === 'save_rebuild') {
        require_permission('cars.publish');
        http_response_code(409);
        $warning = 'Команда «сохранить и пересобрать» отключена. Сохраните карточку отдельно, затем используйте безопасную публикацию страницы.';
    } else {
        $errors = [];
        if (!is_string($_POST['expected_version'] ?? null) || !hash_equals($carVersion, $_POST['expected_version'])) {
            http_response_code(409);
            $errors[] = 'Карточка изменена после открытия формы. Обновите страницу и повторите изменения.';
        }
        $carVersion = is_string($_POST['expected_version'] ?? null) ? $_POST['expected_version'] : '';
        $before = $car;
        $updated = $car;

        $name = car_edit_text_from_post('name', 120, $errors, 'Название');
        if ($name === '') {
            $errors[] = 'Название обязательно.';
        }

        $updated['name'] = $name !== '' ? $name : (string) ($car['name'] ?? '');
        $updated['class'] = car_edit_text_from_post('class', 80, $errors, 'Тип');
        $updated = array_merge($updated, car_edit_structured_fields_from_post());
        $updated['seats'] = car_edit_int_from_post('seats', (int) ($car['seats'] ?? 5), 1, 9, $errors, 'Мест');
        $updated['drive'] = car_edit_text_from_post('drive', 80, $errors, 'Привод');
        $updated['transmission'] = car_edit_text_from_post('transmission', 80, $errors, 'Коробка');
        $updated['engine'] = car_edit_text_from_post('engine', 120, $errors, 'Двигатель');
        $updated['price'] = car_edit_int_from_post('price', isset($car['price']) ? (int) $car['price'] : 0, 0, 1000000, $errors, 'Цена');
        $updated['hourlyAvailable'] = !empty($_POST['hourlyAvailable']);
        $updated['image'] = car_edit_text_from_post('image', 240, $errors, 'Фото');

        $updated['shortScenario'] = car_edit_text_from_post('shortScenario', 180, $errors, 'Сценарий для карточки');
        $updated['cardDescription'] = car_edit_text_from_post('cardDescription', 320, $errors, 'Описание для карточки');
        $updated['detailDescription'] = car_edit_text_from_post('detailDescription', 1400, $errors, 'Описание для детальной страницы');
        $updated['bestFor'] = car_edit_list_from_post('bestFor');
        $updated['strongPoints'] = car_edit_list_from_post('strongPoints');
        $updated['cardBadgesCustom'] = car_edit_list_from_post('cardBadgesCustom', 3, 40);

        $updated['specialRentalTerms'] = [
            'enabled' => !empty($_POST['specialRentalTerms_enabled']),
            'minDays' => car_edit_int_from_post('specialRentalTerms_minDays', null, 1, 60, $errors, 'Минимальный срок'),
            'deliveryText' => car_edit_text_from_post('specialRentalTerms_deliveryText', 160, $errors, 'Подача'),
            'note' => car_edit_text_from_post('specialRentalTerms_note', 220, $errors, 'Заметка по условиям'),
        ];

        $updated['seoTitle'] = car_edit_text_from_post('seoTitle', 90, $errors, 'SEO title');
        $updated['seoDescription'] = car_edit_text_from_post('seoDescription', 180, $errors, 'SEO description');

        if ($canPublish && isset($_POST['publication_mode'])) {
            $mode = (string) $_POST['publication_mode'];
            $channels = isset($updated['publishChannels']) && is_array($updated['publishChannels']) ? $updated['publishChannels'] : [];
            if ($mode === 'published') {
                $updated['adminStatus'] = 'active';
                $updated['publicStatus'] = 'published';
                $updated['isPublished'] = true;
                if (!in_array('rent_rk_public', $channels, true)) {
                    array_unshift($channels, 'rent_rk_public');
                }
            } elseif ($mode === 'hidden') {
                $updated['publicStatus'] = 'hidden';
                $updated['isPublished'] = false;
                $channels = array_values(array_filter($channels, static fn($channel): bool => $channel !== 'rent_rk_public'));
            }
            $updated['publishChannels'] = $channels;
            $updated['publishUpdatedAt'] = now_iso();
            $updated['publishUpdatedBy'] = current_admin_user() ?: 'system';
        }

        if ($errors) {
            $error = implode(' ', $errors);
            $car = $updated;
        } else {
            try {
            $publicChanges = changed_fields($before, $updated, car_edit_public_dirty_fields());
            RentalReturnStore::transaction(static function () use ($id, $carVersion, $before, $updated, $publicChanges): void {
                require_permission('cars.edit');
                require_car_scope($id);
                if (!hash_equals(business_record_version(CARS_FILE, $id, 'slug'), $carVersion)) {
                    throw new RuntimeException('Карточка изменена. Обновите страницу.', 409);
                }
                $rawCars = read_json_file(CARS_FILE, []);
                $rawIndex = car_edit_find_index($rawCars, $id);
                if ($rawIndex === null) throw new RuntimeException('Автомобиль больше не существует.', 409);
                foreach ($updated as $key => $value) {
                    if (!array_key_exists($key, $before) || $before[$key] !== $value) $rawCars[$rawIndex][$key] = $value;
                }
                write_json_file(CARS_FILE, $rawCars);
                audit_log('car.content.update', 'car', $id, 'Обновлён публичный контент автомобиля', ['changed' => $publicChanges]);
                if ($publicChanges) mark_build_dirty('car', $id, array_keys($publicChanges), 'car.content.update', current_admin_user() ?: 'system');
            });
            $carVersion = business_record_version(CARS_FILE, $id, 'slug');
            $freshCars = read_cars();
            $freshIndex = car_edit_find_index($freshCars, $id);
            if ($freshIndex !== null) {
                $cars = $freshCars;
                $index = $freshIndex;
                $car = $cars[$index];
            } else {
                $car = $updated;
            }
            $message = 'Карточка сохранена.';
            if ($publicChanges) {
                $message .= ' Публичная страница помечена как требующая обновления.';
            }

            } catch (Throwable $exception) {
                http_response_code($exception->getCode() === 409 ? 409 : 503);
                $error = $exception->getMessage();
                $car = $updated;
            }
        }
    }
}

if ($publicationPlan === null && isset($_GET['publication_plan'])) {
    $candidatePlan = car_publication_find_plan((string) $_GET['publication_plan']);
    if (is_array($candidatePlan)) {
        $candidateView = car_publication_public_plan_view($candidatePlan);
        $candidateActor = is_array($candidateView['actor'] ?? null) ? $candidateView['actor'] : [];
        if ((string) ($candidateView['slug'] ?? '') === $id && hash_equals((string) ($candidateActor['login'] ?? ''), current_admin_user())) {
            $publicationPlan = $candidateView;
        }
    }
}

if (is_array($publicationPlan) && isset($publicationPlan['immutable'])) {
    $publicationPlan = car_publication_public_plan_view($publicationPlan);
}

$terms = car_edit_terms($car);
$publicationMode = (string) ($car['publicStatus'] ?? '') === 'published' && !empty($car['isPublished']) ? 'published' : 'hidden';
$publicationLabel = $publicationMode === 'published' ? 'Опубликовано' : 'Скрыто';
$publishUpdatedAt = trim((string) ($car['publishUpdatedAt'] ?? ''));
$publishUpdatedLabel = $publishUpdatedAt !== '' ? format_admin_datetime($publishUpdatedAt) : 'нет данных';
$publicUrl = '../cars/' . rawurlencode($id) . '.html';
$aiSettings = function_exists('openai_ai_settings') ? openai_ai_settings() : [];
$aiReady = !empty($aiSettings['enabled']) && !empty($aiSettings['apiKeyConfigured']);
$aiTones = function_exists('ai_text_tone_presets') ? ai_text_tone_presets() : [];
$publicationBuildStatus = car_publication_build_status($id);
$guardedPublishPreflightPreview = guarded_single_car_publish_preflight_preview($id);
$structuredFields = normalize_car_structured_fields($car);
$bodyTypeGroups = car_edit_options_by_group(car_body_type_options());
$fuelTypeGroups = car_edit_options_by_group(car_fuel_type_options());
$selectedEquipment = normalize_car_equipment($structuredFields['equipment'] ?? []);
$equipmentGroups = car_edit_options_by_group(car_equipment_options_for_selection($selectedEquipment));
$extraSpecRows = normalize_car_extra_specs($structuredFields['extraSpecs'] ?? []);
while (count($extraSpecRows) < 20) {
    $extraSpecRows[] = ['key' => '', 'label' => '', 'value' => '', 'unit' => '', 'sort' => ''];
}
$extraSpecRows = array_slice($extraSpecRows, 0, 20);
$structuredReadinessMissing = car_edit_structured_readiness_missing($structuredFields);
$carDocuments = normalize_car_document_fields($car);
$ownerScopeId = car_owner_scope_id($car);
$ownerLabel = scope_display_name($ownerScopeId);
$humanCarName = car_edit_descriptive_name($car, $structuredFields, $id);
$publicationSummary = car_publication_summary($car);
$today = new DateTimeImmutable('today', new DateTimeZone(APP_TIMEZONE));
$availabilityStatusToday = availability_status_for_date($id, $today->format('Y-m-d'));
$availabilityLabels = availability_statuses_with_free() + [
    'unavailable' => 'Недоступно',
    'blocked' => 'Недоступно',
    'problem' => 'Проблема',
];
$serviceHolds = active_service_holds($id);
$service = car_service_state($car);
$workingState = car_edit_working_state($availabilityStatusToday, $serviceHolds);
$rate = rate_for_car($id, $car);
$primaryPrice = normalize_rate_price($rate['manual'] ?? null)
    ?? normalize_rate_price($rate['base'] ?? null)
    ?? normalize_rate_price($car['price'] ?? null);
$depositAmount = car_deposit_amount($id, $car);
$hasPhoto = trim((string) ($car['image'] ?? '')) !== '' || count(car_photos($car)) > 0;
$hasDescription = car_edit_description_present($car);
$hasSeo = car_edit_seo_present($car);
$promoCount = car_edit_active_promo_count($id, $ownerScopeId);
$publicationHumanStatus = car_edit_publication_human_status($publicationSummary, $publicationBuildStatus);
$pageContentUrl = car_edit_admin_route_exists('cars/page-content.php') && can_view_car_page_content_editor($car)
    ? 'cars/page-content.php?slug=' . rawurlencode($id)
    : '';
$tariffsUrl = car_edit_admin_route_exists('rates.php') && current_user_can_view_tariffs($ownerScopeId)
    ? 'rates.php#' . rawurlencode($id)
    : '';
$calendarUrl = has_permission('calendar.view') ? admin_calendar_url(['page' => 'car', 'car' => $id, 'view' => 'range']) : '';
$serviceHoldsUrl = car_edit_admin_route_exists('service-holds.php') && !is_lessor_user() && has_permission('calendar.edit')
    ? ($serviceHolds ? 'service-holds.php#hold-' . rawurlencode((string) ($serviceHolds[0]['id'] ?? '')) : 'service-holds.php?car=' . rawurlencode($id))
    : '';
$promoUrl = car_edit_admin_route_exists('promo-badges.php') && can_view_promo_badges()
    ? 'promo-badges.php?' . http_build_query(['scope' => 'single_car', 'car' => $id])
    : '';
$cardLooksFilled = $hasDescription && $hasPhoto && $primaryPrice !== null && $primaryPrice > 0;
$publicationNeedsCheck = !empty($publicationBuildStatus['dirty'])
    || in_array((string) ($publicationBuildStatus['state'] ?? ''), ['conflict', 'baseline_missing', 'unavailable', 'needs_check'], true)
    || empty($publicationSummary['isPublicVisible']);
$primaryNextAction = car_edit_primary_next_action([
    'structuredMissing' => $structuredReadinessMissing,
    'priceOk' => $primaryPrice !== null && $primaryPrice > 0,
    'depositOk' => $depositAmount !== null && $depositAmount > 0,
    'photoOk' => $hasPhoto,
    'serviceHoldCount' => count($serviceHolds),
    'publicationNeedsCheck' => $publicationNeedsCheck,
    'publicVisible' => !empty($publicationSummary['isPublicVisible']),
    'tariffsUrl' => $tariffsUrl,
    'calendarUrl' => $calendarUrl,
    'pageContentUrl' => $pageContentUrl,
    'publicUrl' => $publicUrl,
]);
$secondaryLinks = array_values(array_filter([
    ['label' => 'Автопарк', 'href' => 'cars.php', 'hint' => 'Вернуться к списку машин.'],
    $tariffsUrl !== '' ? ['label' => 'Открыть тарифы', 'href' => $tariffsUrl, 'hint' => 'Цена и залог редактируются только в тарифах.'] : null,
    $calendarUrl !== '' ? ['label' => 'Открыть календарь', 'href' => $calendarUrl, 'hint' => 'Проверить занятость без изменения availability.'] : null,
    $serviceHoldsUrl !== '' ? ['label' => 'Сервисные удержания', 'href' => $serviceHoldsUrl, 'hint' => $serviceHolds ? 'Открыть активное удержание.' : 'Открыть профильный сервисный раздел.'] : null,
    $pageContentUrl !== '' ? ['label' => 'Page-content', 'href' => $pageContentUrl, 'hint' => 'Отдельный редактор публичной страницы.'] : null,
    $promoUrl !== '' ? ['label' => 'Промо-метки', 'href' => $promoUrl, 'hint' => 'Промо управляется отдельно.'] : null,
], static fn($link): bool => is_array($link)));

admin_header('Редактор контента: ' . (string) ($car['name'] ?? $id), 'cars');
?>
<section class="page-head car-content-editor-head">
  <div>
    <p class="eyebrow">Контент автомобиля</p>
    <h1><?= e((string) ($car['name'] ?? $id)) ?></h1>
    <p class="muted">Тексты сохраняются в private source JSON и попадают на сайт только через публикацию и сборку. Slug не редактируется здесь, чтобы не сломать URL.</p>
    <div class="car-content-editor-meta" aria-label="Служебная информация">
      <span>Статус: <?= e($publicationLabel) ?></span>
      <span>Slug: <?= e($id) ?></span>
      <span>Последнее обновление публикации: <?= e($publishUpdatedLabel) ?></span>
    </div>
  </div>
  <div class="actions">
    <a class="btn secondary" href="cars.php">Автопарк</a>
    <a class="btn secondary" href="<?= e($publicUrl) ?>" target="_blank" rel="noopener">Публичная страница</a>
    <a class="btn secondary" href="#car-editor-preview">Предпросмотр</a>
  </div>
</section>

<section class="panel car-human-status-header is-<?= e((string) $publicationHumanStatus['tone']) ?>" data-car-human-status-header>
  <div class="car-human-status-top">
    <div class="car-human-status-title">
      <p class="eyebrow">Карточка автомобиля</p>
      <h2><?= e($humanCarName) ?></h2>
      <p class="muted">Сводка только читает существующие данные и показывает, где безопасно продолжить работу. Сохранение, публикация, тарифы, календарь и сервисные удержания остаются в профильных формах ниже или в соседних разделах.</p>
    </div>
    <div class="car-human-primary-action is-<?= e((string) $primaryNextAction['tone']) ?>" data-car-human-primary-action>
      <span>Следующее безопасное действие</span>
      <?php if ((string) $primaryNextAction['href'] !== ''): ?>
        <a class="btn" href="<?= e((string) $primaryNextAction['href']) ?>"><?= e((string) $primaryNextAction['label']) ?></a>
      <?php else: ?>
        <span class="btn secondary is-disabled" aria-disabled="true"><?= e((string) $primaryNextAction['label']) ?></span>
      <?php endif; ?>
    </div>
  </div>

  <div class="car-human-status-grid" aria-label="Сводка состояния автомобиля">
    <article class="car-human-status-card is-summary">
      <span>Сводка</span>
      <strong><?= e($humanCarName) ?></strong>
      <small><?= e($carDocuments['licensePlate'] !== '' ? 'Госномер ' . $carDocuments['licensePlate'] : 'ID ' . $id) ?> · <?= e((string) ($publicationSummary['adminLabel'] ?? 'статус требует проверки')) ?> · <?= e($ownerLabel) ?></small>
    </article>

    <article class="car-human-status-card is-<?= e((string) $workingState['tone']) ?>">
      <span>Рабочее состояние</span>
      <strong><?= e((string) $workingState['label']) ?></strong>
      <small><?= e((string) $workingState['hint']) ?></small>
    </article>

    <article class="car-human-status-card <?= $cardLooksFilled ? 'is-ok' : 'is-warning' ?>">
      <span>Статус витрины</span>
      <strong><?= $cardLooksFilled ? 'Публичная карточка заполнена' : 'Публичная карточка требует проверки' ?></strong>
      <small>Описание: <?= $hasDescription ? 'есть' : 'нет' ?> · SEO: <?= $hasSeo ? 'есть' : 'требует проверки' ?> · Промо: <?= $promoCount === null ? 'требует проверки' : ($promoCount > 0 ? 'есть' : 'нет') ?></small>
    </article>

    <article class="car-human-status-card <?= ($primaryPrice !== null && $primaryPrice > 0 && $depositAmount !== null && $depositAmount > 0) ? 'is-ok' : 'is-warning' ?>">
      <span>Цена и залог</span>
      <strong><?= $primaryPrice !== null && $primaryPrice > 0 ? 'Цена указана' : 'Цена не указана' ?> · <?= $depositAmount !== null && $depositAmount > 0 ? 'Залог указан' : 'Залог не указан' ?></strong>
      <small>Цена: <?= e($primaryPrice === null ? 'не задана' : format_money((int) $primaryPrice)) ?> · Залог: <?= e($depositAmount === null ? 'не задан' : format_money((int) $depositAmount)) ?></small>
    </article>

    <article class="car-human-status-card <?= $hasPhoto ? 'is-ok' : 'is-warning' ?>">
      <span>Фото</span>
      <strong><?= $hasPhoto ? 'Главное фото есть' : 'Главного фото нет' ?></strong>
      <small>Галерея: <?= count(car_photos($car)) > 0 ? e((string) count(car_photos($car))) . ' фото' : 'требует проверки' ?>. Загрузка и сортировка здесь не выполняются.</small>
    </article>

    <article class="car-human-status-card <?= $serviceHolds ? 'is-service' : 'is-check' ?>">
      <span>Доступность / сервис</span>
      <strong><?= e((string) ($availabilityLabels[$availabilityStatusToday] ?? 'Требует проверки')) ?></strong>
      <small><?= $serviceHolds ? 'Есть service hold: ' . e((string) count($serviceHolds)) : 'Нет явного service hold' ?> · ТО: <?= e($service['status'] === 'overdue' ? 'просрочено' : ($service['status'] === 'soon' ? 'скоро' : 'по графику')) ?></small>
    </article>

    <article class="car-human-status-card is-<?= e((string) $publicationHumanStatus['tone']) ?>">
      <span>Публикация</span>
      <strong><?= e((string) $publicationHumanStatus['label']) ?></strong>
      <small><?= e((string) $publicationHumanStatus['hint']) ?></small>
    </article>

    <article class="car-human-status-card <?= !empty($publicationBuildStatus['dirty']) ? 'is-warning' : 'is-ok' ?>">
      <span>Неопубликованные изменения</span>
      <strong><?= !empty($publicationBuildStatus['dirty']) ? 'Есть' : 'Нет' ?></strong>
      <small><?= !empty($publicationBuildStatus['dirty']) ? 'Карточка сохранена, но публичная страница еще не обновлена.' : 'Неопубликованных изменений для этой машины нет.' ?></small>
    </article>
  </div>

  <div class="car-human-secondary-links" data-car-human-secondary-links>
    <?php foreach ($secondaryLinks as $link): ?>
      <a class="car-human-secondary-link" href="<?= e((string) $link['href']) ?>">
        <strong><?= e((string) $link['label']) ?></strong>
        <span><?= e((string) $link['hint']) ?></span>
      </a>
    <?php endforeach; ?>
  </div>

  <?php if ($canPublishSinglePage): ?>
    <details class="car-human-technical-details" id="car-editor-publication-technical" data-car-human-technical-details>
      <summary>Показать технические детали публикации</summary>
      <div class="car-human-technical-grid">
        <div><strong>Build status</strong><span><?= e((string) ($publicationBuildStatus['label'] ?? 'требует проверки')) ?></span></div>
        <div><strong>Output</strong><span><?= e((string) ($publicationBuildStatus['outputPath'] ?? 'нет данных')) ?></span></div>
        <div><strong>Baseline</strong><span><?= e((string) ($publicationBuildStatus['baselineLabel'] ?? 'не проверен')) ?></span></div>
        <div><strong>Dirty</strong><span><?= !empty($publicationBuildStatus['dirty']) ? 'есть' : 'нет' ?></span></div>
      </div>
    </details>
  <?php endif; ?>
</section>

<!-- car-editor-publication-technical-panel compatibility boundary for the Stage 5B read-only header smoke -->
<?php if ($message !== ''): ?><div class="notice success"><?= e($message) ?></div><?php endif; ?>
<?php if ($warning !== ''): ?><div class="notice warning"><?= e($warning) ?></div><?php endif; ?>
<?php if ($error !== ''): ?><?= admin_error_notice($error) ?><?php endif; ?>
<?php if ($structuredReadinessMissing): ?>
  <div class="notice warning">Structured-поля карточки заполнены не полностью: <?= e(implode(', ', $structuredReadinessMissing)) ?>. Это подсказка для качества карточки; сохранение и текущая публикация не блокируются.</div>
<?php endif; ?>
<?php if (is_array($rebuildResult) && !$rebuildResult['success'] && !empty($rebuildResult['output'])): ?>
  <details class="panel"><summary>Вывод сборки</summary><pre><?= e(implode("\n", $rebuildResult['output'])) ?></pre></details>
<?php endif; ?>
<?php if ($canPublish && !$canRebuildPublicSite && $warning === ''): ?>
  <div class="notice warning">На этом сервере доступно сохранение карточки без пересборки публичного HTML. Публичный сайт обновляется через data-only pull, штатную локальную сборку и code-only FTP-загрузку.</div>
<?php endif; ?>

<nav class="car-editor-section-nav" aria-label="Навигация по редактору">
  <span>Перейти к:</span>
  <a href="#car-editor-basic">Основные данные</a>
  <a href="#car-editor-commercial">Коммерческие условия</a>
  <a href="#car-editor-storefront">Витрина</a>
  <a href="#car-editor-equipment">Оснащение</a>
  <a href="#car-editor-photos">Фото</a>
  <a href="#car-editor-availability">Доступность</a>
  <a href="#car-editor-publication">Публикация</a>
  <a href="#car-editor-technical">Технические детали</a>
</nav>

<form method="post" class="car-content-editor" id="car-editor-form">
  <input type="hidden" name="expected_version" value="<?= e($carVersion) ?>">
  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="id" value="<?= e($id) ?>">

  <div class="car-content-editor-layout">
  <div class="car-content-editor-main">

  <header class="car-editor-group-header is-basic" id="car-editor-basic">
    <p class="eyebrow">Раздел 1</p>
    <h2>Основные данные автомобиля</h2>
    <p>Марка, модель и характеристики меняют рабочую карточку автомобиля. После сохранения публичная страница может потребовать отдельной публикации.</p>
  </header>

  <section class="panel car-content-editor-section car-editor-basic-part" id="car-editor-identification">
    <div class="panel-head">
      <div>
        <p class="eyebrow">Основные данные</p>
        <h2>Идентификация карточки</h2>
      </div>
    </div>
    <div class="car-content-editor-grid">
      <label>Бренд <input name="brand" value="<?= e(car_edit_value($structuredFields, 'brand')) ?>" maxlength="80" autocomplete="off"></label>
      <label>Модель <input name="model" value="<?= e(car_edit_value($structuredFields, 'model')) ?>" maxlength="80" autocomplete="off"></label>
      <label>Год <input name="year" type="number" min="1900" max="<?= e((string) ((int) date('Y') + 2)) ?>" value="<?= e(car_edit_value($structuredFields, 'year')) ?>"></label>
      <label>Поколение <input name="generation" value="<?= e(car_edit_value($structuredFields, 'generation')) ?>" maxlength="80" autocomplete="off"></label>
      <label>Комплектация <input name="trim" value="<?= e(car_edit_value($structuredFields, 'trim')) ?>" maxlength="120" autocomplete="off"></label>
      <label>Название <input name="name" value="<?= e(car_edit_value($car, 'name')) ?>" required maxlength="120"></label>
      <p class="field-hint is-wide">Название можно составить из бренда, модели и года, но редактор не меняет его автоматически.</p>
      <label>Slug <input value="<?= e($id) ?>" disabled aria-readonly="true"></label>
      <label>Класс <input name="class" value="<?= e(car_edit_value($car, 'class')) ?>" maxlength="80"></label>
    </div>
  </section>

  <section class="panel car-content-editor-section car-editor-basic-part" id="car-editor-card-fields">
    <div class="panel-head">
      <div>
        <p class="eyebrow">Технические характеристики</p>
        <h2>Параметры автомобиля</h2>
      </div>
    </div>
    <div class="car-content-editor-grid">
      <label>Кузов
        <select name="bodyType">
          <option value="">Не указан</option>
          <?php foreach ($bodyTypeGroups as $group => $options): ?>
            <optgroup label="<?= e($group) ?>">
              <?php foreach ($options as $code => $option): ?>
                <option value="<?= e((string) $code) ?>" <?= $structuredFields['bodyType'] === $code ? 'selected' : '' ?>><?= e((string) $option['label']) ?></option>
              <?php endforeach; ?>
            </optgroup>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Топливо
        <select name="fuelType">
          <option value="">Не указано</option>
          <?php foreach ($fuelTypeGroups as $group => $options): ?>
            <optgroup label="<?= e($group) ?>">
              <?php foreach ($options as $code => $option): ?>
                <option value="<?= e((string) $code) ?>" <?= $structuredFields['fuelType'] === $code ? 'selected' : '' ?>><?= e((string) $option['label']) ?></option>
              <?php endforeach; ?>
            </optgroup>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Цвет <input name="color" value="<?= e(car_edit_value($structuredFields, 'color')) ?>" maxlength="80"></label>
      <label>Дверей <input name="doors" type="number" min="1" max="8" value="<?= e(car_edit_value($structuredFields, 'doors')) ?>"></label>
      <label>Мест <input name="seats" type="number" min="1" max="9" value="<?= e(car_edit_value($car, 'seats')) ?>"></label>
      <label>Коробка <input name="transmission" value="<?= e(car_edit_value($car, 'transmission')) ?>" maxlength="80"></label>
      <label>Привод <input name="drive" value="<?= e(car_edit_value($car, 'drive')) ?>" maxlength="80"></label>
      <label>Двигатель <input name="engine" value="<?= e(car_edit_value($car, 'engine')) ?>" maxlength="120"></label>
      <label>Мощность, л.с. <input name="enginePowerHp" type="number" min="1" max="2000" value="<?= e(car_edit_value($structuredFields, 'enginePowerHp')) ?>"></label>
      <label>Объём, л <input name="engineDisplacementL" type="number" min="0.1" max="20" step="0.1" value="<?= e(car_edit_value($structuredFields, 'engineDisplacementL')) ?>"></label>
      <label>Запас хода EV, км <input name="electricRangeKm" type="number" min="1" max="2000" value="<?= e(car_edit_value($structuredFields, 'electricRangeKm')) ?>"></label>
    </div>
  </section>

  <header class="car-editor-group-header is-equipment" id="car-editor-equipment">
    <p class="eyebrow">Раздел 4</p>
    <h2>Оснащение и характеристики</h2>
    <p>Опции и display-only параметры влияют на характеристики в карточке, но не меняют тарифы, заявки, занятость или бронирования.</p>
  </header>

  <section class="panel car-content-editor-section car-editor-equipment-part" id="car-editor-texts">
    <div class="panel-head">
      <div>
        <p class="eyebrow">Оснащение</p>
        <h2>Опции по справочнику</h2>
        <p class="muted">В карточке сохраняются только технические коды. Русские подписи берутся из общего helper-справочника.</p>
      </div>
    </div>
    <div class="car-content-editor-grid">
      <?php foreach ($equipmentGroups as $group => $options): ?>
        <fieldset class="is-wide">
          <legend><?= e($group) ?></legend>
          <?php foreach ($options as $code => $option): ?>
            <label class="check-row">
              <input type="checkbox" name="equipment[]" value="<?= e((string) $code) ?>" <?= in_array((string) $code, $selectedEquipment, true) ? 'checked' : '' ?>>
              <span><?= e((string) $option['label']) ?></span>
            </label>
          <?php endforeach; ?>
        </fieldset>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="panel car-content-editor-section car-editor-equipment-part">
    <div class="panel-head">
      <div>
        <p class="eyebrow">Дополнительные характеристики</p>
        <h2>Display-only параметры</h2>
        <p class="muted">Пустые строки отбрасываются. Эти параметры не участвуют в тарифах, заявках, занятости или бронировании.</p>
      </div>
    </div>
    <div class="car-content-editor-grid">
      <div class="is-wide">
        <?php foreach ($extraSpecRows as $rowIndex => $row): ?>
          <div class="car-content-editor-grid is-nested is-wide">
            <input type="hidden" name="extraSpecs_key[]" value="<?= e((string) ($row['key'] ?? '')) ?>">
            <label>Название <input name="extraSpecs_label[]" value="<?= e((string) ($row['label'] ?? '')) ?>" maxlength="80"></label>
            <label>Значение <input name="extraSpecs_value[]" value="<?= e((string) ($row['value'] ?? '')) ?>" maxlength="160"></label>
            <label>Ед. <input name="extraSpecs_unit[]" value="<?= e((string) ($row['unit'] ?? '')) ?>" maxlength="20"></label>
            <label>Sort <input name="extraSpecs_sort[]" type="number" value="<?= e((string) ($row['sort'] ?? '')) ?>"></label>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <header class="car-editor-group-header is-commercial" id="car-editor-commercial">
    <p class="eyebrow">Раздел 2</p>
    <h2>Коммерческие условия</h2>
    <p>Цена в карточке, почасовой формат и индивидуальные исключения сохраняются в рабочей карточке. Тарифы и залог проверяются и редактируются в профильном разделе.</p>
  </header>

  <section class="panel car-content-editor-section car-editor-commercial-part">
    <div class="panel-head">
      <div>
        <p class="eyebrow">Цена и формат аренды</p>
        <h2>Условия в карточке</h2>
        <p class="muted">Обычное сохранение обновляет рабочие данные, но само по себе не публикует страницу автомобиля.</p>
      </div>
    </div>
    <div class="car-content-editor-grid">
      <label>Цена в карточке <input name="price" inputmode="numeric" value="<?= e(car_edit_value($car, 'price')) ?>"></label>
      <label class="car-content-editor-switch is-wide"><input type="checkbox" name="hourlyAvailable" value="1" <?= !empty($car['hourlyAvailable']) ? 'checked' : '' ?>><span class="car-content-editor-switch-track" aria-hidden="true"></span><span>Почасовая аренда доступна</span></label>
      <div class="car-editor-readonly-summary is-wide">
        <div><span>Расчётная цена</span><strong><?= e($primaryPrice === null ? 'не задана' : format_money((int) $primaryPrice)) ?></strong></div>
        <div><span>Залог</span><strong><?= e($depositAmount === null ? 'не задан' : format_money((int) $depositAmount)) ?></strong></div>
        <?php if ($tariffsUrl !== ''): ?>
          <a class="btn secondary" href="<?= e($tariffsUrl) ?>">Открыть тарифы и залог</a>
        <?php else: ?>
          <span class="btn secondary is-disabled" aria-disabled="true">Тарифы недоступны по роли</span>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <header class="car-editor-group-header is-photos" id="car-editor-photos">
    <p class="eyebrow">Раздел 5</p>
    <h2>Фото и медиа</h2>
    <p>Главное фото влияет на публичную карточку. Галерея остаётся в профильном редакторе; сохранение здесь не запускает публикацию.</p>
  </header>

  <section class="panel car-content-editor-section car-editor-photo-part">
    <div class="panel-head">
      <div>
        <p class="eyebrow">Главное изображение</p>
        <h2>Фото карточки</h2>
      </div>
    </div>
    <div class="car-content-editor-grid">
      <label class="is-wide">Путь к главному фото <input name="image" value="<?= e(car_edit_value($car, 'image')) ?>" maxlength="240"></label>
      <div class="car-editor-readonly-summary is-wide">
        <div><span>Главное фото</span><strong><?= $hasPhoto ? 'есть' : 'не задано' ?></strong></div>
        <div><span>Фотографий в галерее</span><strong><?= e((string) count(car_photos($car))) ?></strong></div>
        <?php if ($pageContentUrl !== ''): ?>
          <a class="btn secondary" href="<?= e($pageContentUrl) ?>">Открыть редактор страницы</a>
        <?php else: ?>
          <span class="btn secondary is-disabled" aria-disabled="true">Редактор фото недоступен по роли</span>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <section class="panel car-content-editor-section car-editor-publication-setting">
    <div class="panel-head">
      <div>
        <p class="eyebrow">Видимость</p>
        <h2>Режим публикации в source</h2>
        <p class="muted">Это поле сохраняет режим видимости в рабочей карточке. Обновление публичного HTML выполняется отдельным действием.</p>
      </div>
    </div>
    <div class="car-content-editor-grid">
      <?php if ($canPublish): ?>
        <label>Публикация
          <select name="publication_mode">
            <option value="published" <?= $publicationMode === 'published' ? 'selected' : '' ?>>Опубликовано</option>
            <option value="hidden" <?= $publicationMode === 'hidden' ? 'selected' : '' ?>>Скрыто</option>
          </select>
        </label>
      <?php endif; ?>
    </div>
  </section>

  <header class="car-editor-group-header is-storefront" id="car-editor-storefront">
    <p class="eyebrow">Раздел 3</p>
    <h2>Витрина и описание</h2>
    <p>Тексты, преимущества и SEO влияют на публичную карточку автомобиля. Сохранение фиксирует данные, но не означает публикацию сайта.</p>
  </header>

  <section class="panel car-content-editor-section car-editor-storefront-part">
    <div class="panel-head">
      <div>
        <p class="eyebrow">Тексты</p>
        <h2>Сценарии и польза</h2>
      </div>
    </div>
    <div class="car-content-editor-grid">
      <label class="is-wide car-content-editor-field">
        <span class="car-content-editor-label-row"><span>Сценарий для карточки</span><span class="car-content-editor-label-actions"><span class="field-counter" data-char-counter="shortScenario"></span><button class="car-ai-field-button" type="button" data-car-ai-field-generate="shortScenario" <?= $aiReady ? '' : 'disabled' ?>>AI</button></span></span>
        <span class="field-hint">Короткая строка: для кого и для какой поездки авто.</span>
        <textarea name="shortScenario" rows="2" maxlength="180" data-autoresize><?= e(car_edit_value($car, 'shortScenario')) ?></textarea>
      </label>
      <label class="is-wide car-content-editor-field">
        <span class="car-content-editor-label-row"><span>Описание для карточки</span><span class="car-content-editor-label-actions"><span class="field-counter" data-char-counter="cardDescription"></span><button class="car-ai-field-button" type="button" data-car-ai-field-generate="cardDescription" <?= $aiReady ? '' : 'disabled' ?>>AI</button></span></span>
        <span class="field-hint">1-2 предложения, без рекламного давления.</span>
        <textarea name="cardDescription" rows="3" maxlength="320" data-autoresize><?= e(car_edit_value($car, 'cardDescription')) ?></textarea>
      </label>
      <label class="is-wide car-content-editor-field">
        <span class="car-content-editor-label-row"><span>Описание для детальной страницы</span><button class="car-ai-field-button" type="button" data-car-ai-field-generate="detailDescription" <?= $aiReady ? '' : 'disabled' ?>>AI</button></span>
        <span class="field-hint">Можно подробнее: сценарий, комфорт, маршруты, но без выдуманных фактов.</span>
        <textarea name="detailDescription" rows="4" maxlength="1400" data-autoresize><?= e(car_edit_value($car, 'detailDescription')) ?></textarea>
      </label>
      <label class="car-content-editor-field">
        <span class="car-content-editor-label-row"><span>Кому подойдёт</span><button class="car-ai-field-button" type="button" data-car-ai-field-generate="bestFor" <?= $aiReady ? '' : 'disabled' ?>>AI</button></span>
        <span class="field-hint">По одному пункту с новой строки.</span>
        <textarea name="bestFor" rows="3" data-autoresize><?= e(car_edit_value($car, 'bestFor')) ?></textarea>
      </label>
      <label class="car-content-editor-field">
        <span class="car-content-editor-label-row"><span>Что удобно</span><button class="car-ai-field-button" type="button" data-car-ai-field-generate="strongPoints" <?= $aiReady ? '' : 'disabled' ?>>AI</button></span>
        <span class="field-hint">По одному преимуществу с новой строки.</span>
        <textarea name="strongPoints" rows="3" data-autoresize><?= e(car_edit_value($car, 'strongPoints')) ?></textarea>
      </label>
      <label class="is-wide car-content-editor-field">
        <span class="car-content-editor-label-row"><span>Кастомные бейджи</span><button class="car-ai-field-button" type="button" data-car-ai-field-generate="cardBadgesCustom" <?= $aiReady ? '' : 'disabled' ?>>AI</button></span>
        <span class="field-hint">До трёх коротких бейджей, каждый с новой строки.</span>
        <textarea name="cardBadgesCustom" rows="2" data-autoresize><?= e(car_edit_value($car, 'cardBadgesCustom')) ?></textarea>
      </label>
    </div>
  </section>

  <details class="panel car-content-editor-section car-ai-generator car-editor-storefront-part"
    data-car-ai-generator
    data-car-ai-endpoint="api/car-ai-text.php"
    data-car-ai-car-id="<?= e($id) ?>">
    <summary class="car-ai-generator-summary">
      <div>
        <p class="eyebrow">AI-помощник</p>
        <h2>Общий AI-блок</h2>
        <p class="muted">Тон и направляющий промт для кнопок AI у полей. Можно сгенерировать все активные тексты сразу.</p>
      </div>
      <span class="car-ai-generator-status <?= $aiReady ? 'is-ready' : 'is-muted' ?>"><?= $aiReady ? 'DeepSeek настроен' : 'DeepSeek не настроен' ?></span>
    </summary>
    <div class="car-ai-generator-body">
    <div class="car-ai-generator-controls">
      <label>Тон
        <select data-car-ai-tone>
          <?php foreach ($aiTones as $toneValue => $toneLabel): ?>
            <option value="<?= e((string) $toneValue) ?>"><?= e((string) $toneLabel) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="is-wide">Направляющий промт
        <textarea data-car-ai-prompt rows="3" maxlength="1000" placeholder="Например: сделать акцент на поездках по горным дорогам, семье с детьми и спокойном комфорте. Без пафоса и без шаблонных фраз." data-autoresize></textarea>
      </label>
    </div>
    <div class="car-ai-generator-actions">
      <button class="btn secondary" type="button" data-car-ai-generate-all <?= $aiReady ? '' : 'disabled' ?>>Сгенерировать всё</button>
    </div>
    <div class="notice warning car-ai-generator-warning" data-car-ai-save-warning hidden>Проверьте текст перед сохранением.</div>
    <div class="notice" data-car-ai-status hidden></div>
    </div>
  </details>

  <section class="panel car-content-editor-section car-editor-commercial-part">
    <div class="panel-head">
      <div>
        <p class="eyebrow">Условия</p>
        <h2>Исключения по автомобилю</h2>
      </div>
    </div>
    <p class="muted">Общие условия каталога задаются в генераторе: от 1 суток, подача по Ялте бесплатно, по Крыму по договорённости. Здесь заполняются только отличия.</p>
    <div class="car-content-editor-grid">
      <label class="car-content-editor-switch is-wide"><input type="checkbox" name="specialRentalTerms_enabled" value="1" <?= $terms['enabled'] ? 'checked' : '' ?> data-special-terms-toggle><span class="car-content-editor-switch-track" aria-hidden="true"></span><span>Есть особые условия по этому автомобилю</span></label>
      <p class="muted car-content-editor-terms-note" data-special-terms-empty>Используются общие условия каталога.</p>
      <div class="car-content-editor-grid is-nested is-wide" data-special-terms-fields>
        <label>Минимальный срок, суток <input name="specialRentalTerms_minDays" type="number" min="1" max="60" value="<?= e($terms['minDays'] === null ? '' : (string) $terms['minDays']) ?>"></label>
        <label>Подача <input name="specialRentalTerms_deliveryText" value="<?= e($terms['deliveryText']) ?>" maxlength="160" placeholder="например: подача по Ялте 500 ₽"></label>
        <label class="is-wide car-content-editor-field">Заметка <textarea name="specialRentalTerms_note" rows="2" maxlength="220" data-autoresize><?= e($terms['note']) ?></textarea></label>
      </div>
    </div>
  </section>

  <section class="panel car-content-editor-section car-editor-storefront-part">
    <div class="panel-head">
      <div>
        <p class="eyebrow">SEO</p>
        <h2>Title и description</h2>
      </div>
    </div>
    <div class="car-content-editor-grid">
      <label class="is-wide car-content-editor-field">
        <span class="car-content-editor-label-row"><span>SEO title</span><span class="car-content-editor-label-actions"><span class="field-counter" data-char-counter="seoTitle"></span><button class="car-ai-field-button" type="button" data-car-ai-field-generate="seoTitle" <?= $aiReady ? '' : 'disabled' ?>>AI</button></span></span>
        <input name="seoTitle" value="<?= e(car_edit_value($car, 'seoTitle')) ?>" maxlength="90">
      </label>
      <label class="is-wide car-content-editor-field">
        <span class="car-content-editor-label-row"><span>SEO description</span><span class="car-content-editor-label-actions"><span class="field-counter" data-char-counter="seoDescription"></span><button class="car-ai-field-button" type="button" data-car-ai-field-generate="seoDescription" <?= $aiReady ? '' : 'disabled' ?>>AI</button></span></span>
        <textarea name="seoDescription" rows="2" maxlength="180" data-autoresize><?= e(car_edit_value($car, 'seoDescription')) ?></textarea>
      </label>
    </div>
  </section>

  </div>

  <aside class="car-content-editor-preview-rail" id="car-editor-preview">
  <section class="panel car-content-editor-preview">
    <div class="panel-head">
      <div>
        <p class="eyebrow">Предпросмотр</p>
        <h2>Как это читается</h2>
      </div>
    </div>
    <div class="car-content-editor-preview-grid">
      <article>
        <h3 data-preview-field="name"><?= e((string) ($car['name'] ?? $id)) ?></h3>
        <p class="car-content-editor-preview-scenario" data-preview-field="shortScenario"><?= e(car_edit_value($car, 'shortScenario')) ?></p>
        <p data-preview-field="cardDescription"><?= e(car_edit_value($car, 'cardDescription')) ?></p>
        <div data-preview-list="cardBadgesCustom"><?= car_edit_split_preview(isset($car['cardBadgesCustom']) && is_array($car['cardBadgesCustom']) ? $car['cardBadgesCustom'] : []) ?></div>
      </article>
      <article>
        <h3>Детальная страница</h3>
        <p data-preview-field="detailDescription"><?= e(car_edit_value($car, 'detailDescription')) ?></p>
        <div data-preview-list="bestFor"><?= car_edit_split_preview(isset($car['bestFor']) && is_array($car['bestFor']) ? $car['bestFor'] : []) ?></div>
      </article>
    </div>
  </section>
  </aside>
  </div>

  <div class="car-content-editor-actions">
    <div class="car-content-editor-save-actions">
      <button class="btn" type="submit" name="action" value="save">Сохранить изменения</button>
      <a class="btn secondary" href="cars.php">Назад без сохранения</a>
    </div>
    <?php if ($canPublish && $canRebuildPublicSite): ?>
      <fieldset class="car-content-editor-publication-actions">
        <legend>Отдельные действия публикации</legend>
        <span>Пересборка сайта не входит в обычное сохранение.</span>
        <a class="btn secondary" href="cars/page-content.php?slug=<?= e($id) ?>">Безопасная публикация страницы</a>
      </fieldset>
    <?php endif; ?>
  </div>
</form>

<section class="car-editor-operational-section" id="car-editor-availability">
  <header class="car-editor-group-header">
    <p class="eyebrow">Раздел 6</p>
    <h2>Доступность и сервис</h2>
    <p>Этот блок только показывает текущее состояние. Календарь и сервисные удержания меняются в профильных защищённых разделах.</p>
  </header>
  <div class="car-editor-operational-grid">
    <article>
      <span>Сегодня</span>
      <strong><?= e((string) ($availabilityLabels[$availabilityStatusToday] ?? 'Требует проверки')) ?></strong>
      <small>Статус получен из календаря доступности без записи.</small>
    </article>
    <article>
      <span>Сервисные удержания</span>
      <strong><?= $serviceHolds ? e((string) count($serviceHolds)) : 'Нет активных' ?></strong>
      <small><?= $serviceHolds ? 'У автомобиля есть активное сервисное ограничение.' : 'Явных service hold для автомобиля нет.' ?></small>
    </article>
    <article>
      <span>Техническое обслуживание</span>
      <strong><?= e($service['status'] === 'overdue' ? 'Просрочено' : ($service['status'] === 'soon' ? 'Скоро' : 'По графику')) ?></strong>
      <small>Редактирование выполняется вне этой формы.</small>
    </article>
  </div>
  <div class="car-editor-operational-actions">
    <?php if ($calendarUrl !== ''): ?>
      <a class="btn secondary" href="<?= e($calendarUrl) ?>">Открыть календарь</a>
    <?php else: ?>
      <span class="btn secondary is-disabled" aria-disabled="true">Календарь недоступен по роли</span>
    <?php endif; ?>
    <?php if ($serviceHoldsUrl !== ''): ?>
      <a class="btn secondary" href="<?= e($serviceHoldsUrl) ?>">Сервисные удержания</a>
    <?php else: ?>
      <span class="btn secondary is-disabled" aria-disabled="true">Сервисные удержания недоступны</span>
    <?php endif; ?>
  </div>
</section>

<section class="car-editor-operational-section" id="car-editor-publication">
  <header class="car-editor-group-header">
    <p class="eyebrow">Раздел 7</p>
    <h2>Публикация и review</h2>
    <p>Сохранение рабочей карточки и публикация сайта — разные действия. Здесь можно проверить состояние и перейти к просмотру без изменения данных.</p>
  </header>
  <div class="car-editor-operational-grid">
    <article>
      <span>Публичная видимость</span>
      <strong><?= e((string) $publicationHumanStatus['label']) ?></strong>
      <small><?= e((string) $publicationHumanStatus['hint']) ?></small>
    </article>
    <article>
      <span>Неопубликованные изменения</span>
      <strong><?= !empty($publicationBuildStatus['dirty']) ? 'Есть' : 'Нет' ?></strong>
      <small><?= !empty($publicationBuildStatus['dirty']) ? 'Рабочая карточка отличается от известной публикации.' : 'Dirty-запись для автомобиля отсутствует.' ?></small>
    </article>
    <article>
      <span>Публичная карточка</span>
      <strong><?= $cardLooksFilled ? 'Основные данные заполнены' : 'Требует проверки' ?></strong>
      <small>Фото, цена и описание проверяются без автоматической публикации.</small>
    </article>
  </div>
  <div class="car-editor-operational-actions">
    <a class="btn secondary" href="<?= e($publicUrl) ?>" target="_blank" rel="noopener">Открыть публичную страницу</a>
    <a class="btn secondary" href="#car-editor-preview">Проверить предпросмотр</a>
    <?php if ($pageContentUrl !== ''): ?>
      <a class="btn secondary" href="<?= e($pageContentUrl) ?>">Редактор текста страницы</a>
    <?php endif; ?>
  </div>
</section>

<details class="car-editor-technical-shell" id="car-editor-technical">
  <summary>
    <span>
      <small>Раздел 8</small>
      <strong>Технические детали публикации</strong>
      <em>Hash, baseline, output paths и guarded diagnostics. Для обычного редактирования не требуются.</em>
    </span>
  </summary>
  <div class="car-editor-technical-body">
    <section class="panel car-publication-status <?= e(car_edit_status_class((string) $publicationBuildStatus['state'])) ?>" id="car-editor-publication-technical-panel">
      <div class="panel-head">
        <div>
          <p class="eyebrow">Публикация страницы</p>
          <h2><?= e((string) $publicationBuildStatus['label']) ?></h2>
          <p class="muted"><?= e((string) $publicationBuildStatus['message']) ?></p>
        </div>
        <span class="status"><?= e((string) $publicationBuildStatus['outputPath']) ?></span>
      </div>
      <div class="car-publication-status-grid">
        <div><strong>Dirty registry</strong><span><?= !empty($publicationBuildStatus['dirty']) ? 'car:' . e($id) . ' ожидает публикации' : 'dirty-записи нет' ?></span></div>
        <div><strong>Ownership</strong><span><?= !empty($publicationBuildStatus['hasKnownOwnership']) ? 'known generated output' : 'unknown или ещё не зарегистрирован' ?></span></div>
        <div><strong>Baseline</strong><span><?= e((string) ($publicationBuildStatus['baselineLabel'] ?? 'не проверен')) ?></span></div>
        <div><strong>Current hash</strong><span><?= e((string) ($publicationBuildStatus['currentHash'] ?? 'нет файла')) ?></span></div>
        <div><strong>Known hash</strong><span><?= e((string) ($publicationBuildStatus['knownHash'] !== '' ? $publicationBuildStatus['knownHash'] : 'нет записи')) ?></span></div>
      </div>
      <?php if ($canPublishSinglePage): ?>
        <form method="post" class="car-publication-status-actions">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="id" value="<?= e($id) ?>">
          <a class="btn secondary" href="cars/page-content.php?slug=<?= e($id) ?>">Открыть безопасный редактор страницы</a>
          <button class="btn secondary" type="submit" name="action" value="publish_dry_run"><?= PhpPublicationCutover::selected() ? 'Проверить PHP-план без публикации' : 'Проверить прежний генератор без записи' ?></button>
        </form>
      <?php else: ?>
        <p class="muted">Проверка публикации доступна пользователям с `cars.publish` или `content.publish.single_page`.</p>
      <?php endif; ?>
    </section>

    <section class="panel car-publication-status car-guarded-publish-preflight" data-publication-workflow="two-phase-plan">
      <div class="panel-head">
        <div>
          <p class="eyebrow">Двухфазная публикация</p>
          <h2>Сначала план, затем подтверждение</h2>
          <p class="muted">Система сохраняет точные байты четырёх car-scoped файлов. Подтверждение применяет только просмотренный payload, без повторной генерации, удаления и записи public JSON.</p>
        </div>
        <span class="status"><?= is_array($publicationPlan) ? e((string) ($publicationPlan['state'] ?? 'prepared')) : 'plan required' ?></span>
      </div>
      <?php if (is_array($publicationPlan)): ?>
        <div class="car-publication-status-grid">
          <div><strong>Plan ID</strong><span><?= e((string) ($publicationPlan['id'] ?? '')) ?></span></div>
          <div><strong>Digest</strong><span><?= e((string) ($publicationPlan['digest'] ?? '')) ?></span></div>
          <div><strong>Автомобиль</strong><span><?= e((string) ($publicationPlan['slug'] ?? $id)) ?></span></div>
          <div><strong>Public JSON</strong><span>не изменяется</span></div>
          <div><strong>Удаление</strong><span>запрещено</span></div>
          <div><strong>Payload regeneration</strong><span>запрещена</span></div>
        </div>
        <div class="car-publish-output-list">
          <?php foreach (($publicationPlan['outputs'] ?? []) as $output): ?>
            <div>
              <strong><?= e((string) ($output['path'] ?? '')) ?></strong>
              <span><?= !empty($output['changed']) ? 'будет изменён' : 'байты уже совпадают' ?> · <?= e((string) ($output['beforeHash'] ?? '')) ?> → <?= e((string) ($output['afterHash'] ?? '')) ?></span>
            </div>
          <?php endforeach; ?>
        </div>
        <?php if ((string) ($publicationPlan['state'] ?? '') === 'prepared'): ?>
          <form method="post" class="car-publication-status-actions">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="id" value="<?= e($id) ?>">
            <input type="hidden" name="publication_plan_id" value="<?= e((string) ($publicationPlan['id'] ?? '')) ?>">
            <input type="hidden" name="publication_plan_digest" value="<?= e((string) ($publicationPlan['digest'] ?? '')) ?>">
            <label><input type="checkbox" name="confirm_publication_plan" value="1" required> Я проверил файлы и подтверждаю применение именно этого плана</label>
            <button class="btn" type="submit" name="action" value="guarded_publish_apply">Применить просмотренный план</button>
          </form>
        <?php endif; ?>
      <?php elseif ($canPublishSinglePage): ?>
        <form method="post" class="car-publication-status-actions">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="id" value="<?= e($id) ?>">
          <button class="btn secondary" type="submit" name="action" value="guarded_publish_preflight">Подготовить план публикации</button>
        </form>
      <?php else: ?>
        <p class="muted">Публикация доступна только пользователям с `cars.publish` или `content.publish.single_page`.</p>
      <?php endif; ?>
    </section>

    <?php if (is_array($publishDryRunResult)): ?>
      <?php $dryParsed = $publishDryRunResult['parsed'] ?? ['items' => [], 'conflicts' => [], 'unknownOwnership' => [], 'publicData' => []]; ?>
      <section class="panel car-publish-dry-run-result">
        <div class="panel-head">
          <div>
            <p class="eyebrow">Dry-run</p>
            <h2>Проверка публичной страницы без записи</h2>
            <p class="muted"><?= PhpPublicationCutover::selected() ? 'Предварительная проверка PHP. Публичные файлы и очередь не изменены.' : 'Проверка прежнего генератора без публикации.' ?></p>
          </div>
          <span class="status"><?= !empty($publishDryRunResult['success']) ? 'ok' : 'failed' ?></span>
        </div>
        <div class="car-publication-status-grid">
          <div><strong>Conflicts</strong><span><?= e((string) count($dryParsed['conflicts'] ?? [])) ?></span></div>
          <div><strong>Unknown ownership</strong><span><?= e((string) count($dryParsed['unknownOwnership'] ?? [])) ?></span></div>
          <div><strong>Public data</strong><span><?= e(count($dryParsed['publicData'] ?? []) > 0 ? 'related output нужен, запись отключена' : 'не требуется') ?></span></div>
          <div><strong>Deletes</strong><span><?= e((string) (($dryParsed['deleteCount'] ?? 0) ?? 0)) ?></span></div>
        </div>
        <?php if (!empty($dryParsed['items'])): ?>
          <div class="car-publish-output-list">
            <?php foreach ($dryParsed['items'] as $item): ?>
              <div>
                <strong><?= e((string) $item['path']) ?></strong>
                <span><?= e((string) $item['status']) ?> · <?= e((string) $item['entityType']) ?>:<?= e((string) $item['entityId']) ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <?php if (!empty($publishDryRunResult['presentationLimits'])): ?>
          <ul><?php foreach ($publishDryRunResult['presentationLimits'] as $limit): ?><li><?= e($limit) ?></li><?php endforeach; ?></ul>
        <?php endif; ?>
        <?php if (!empty($publishDryRunResult['output'])): ?>
          <details class="car-publish-raw-output"><summary>Технический вывод dry-run</summary><pre><?= e(implode("\n", $publishDryRunResult['output'])) ?></pre></details>
        <?php endif; ?>
      </section>
    <?php endif; ?>
  </div>
</details>

<?php admin_footer(); ?>
