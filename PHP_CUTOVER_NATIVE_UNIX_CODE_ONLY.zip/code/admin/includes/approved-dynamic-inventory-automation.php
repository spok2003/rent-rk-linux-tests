<?php
declare(strict_types=1);

/** Prepares a technical state change; the plan service owns the commit boundary. */
final class ApprovedDynamicInventoryAutomation
{
    private static function digest(array $value): string
    {
        return hash('sha256', RentRkPublicRenderer::canonical($value));
    }

    public static function signingBytes(array $value): string
    {
        return "RentRK automatic dynamic inventory event v1\0" . RentRkPublicRenderer::canonical($value);
    }

    private static function block(string $reason): never
    {
        throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_' . $reason, 409);
    }

    private static function history(array $history, array $context, int $now): ?array
    {
        if (count($history) !== 3 || ($history['schemaVersion'] ?? null) !== 1
            || !is_array($history['events'] ?? null) || !array_is_list($history['events']) || $history['events'] === []) self::block('HISTORY_INVALID');
        $previous = null;
        $previousHash = null;
        $usedKeys = [];
        foreach ($history['events'] as $event) {
            $p = $event['payload'] ?? null;
            $signature = is_string($event['signature'] ?? null) ? base64_decode($event['signature'], true) : false;
            $keyId = $p['keyId'] ?? null;
            if (!is_array($event) || count($event) !== 2 || !is_array($p) || !is_string($keyId)
                || !is_string($signature) || strlen($signature) !== SODIUM_CRYPTO_SIGN_BYTES) self::block('HISTORY_INVALID');
            if (in_array($keyId, $context['revokedKeyIds'] ?? [], true)) self::block('KEY_REVOKED');
            $retired = $context['retiredKeys'][$keyId] ?? null;
            $public = $keyId === $context['keyId'] ? $context['publicKeyBase64'] : ($retired['publicKeyBase64'] ?? null);
            if ($public === null) self::block('KEY_UNKNOWN');
            if (!sodium_crypto_sign_verify_detached($signature, self::signingBytes($p), base64_decode($public, true))) self::block('HISTORY_INVALID');
            $issued = $p['issuedAt'] ?? null;
            $expiry = $p['expiresAt'] ?? null;
            $content = $p['content'] ?? null;
            if (count($p) !== 9 || ($p['schemaVersion'] ?? null) !== 1 || ($p['audience'] ?? null) !== 'rent-rk-global-sitemap'
                || ($p['issuer'] ?? null) !== $context['issuer'] || !array_key_exists('previousSha256', $p) || $p['previousSha256'] !== $previousHash
                || !is_int($issued) || !is_int($expiry) || $issued < 1 || $issued > $now || $expiry <= $issued || $expiry - $issued > 86400
                || ($retired !== null && $issued > $retired['retiredAt']) || !is_array($content) || !is_array($content['baseline'] ?? null)) self::block('HISTORY_INVALID');
            $changed = $previous === null || self::digest($previous['content']) !== self::digest($content);
            if (($p['revision'] ?? null) !== ($previous['revision'] ?? 0) + (int) $changed) self::block('HISTORY_INVALID');
            if ($previous !== null) {
                if ($issued < $previous['issuedAt'] || $content['baseline'] !== $previous['content']['baseline']) self::block('HISTORY_INVALID');
                if ($previous['keyId'] !== $keyId) {
                    $cutover = $context['retiredKeys'][$previous['keyId']]['retiredAt'] ?? null;
                    if ($cutover === null || $issued < $cutover || isset($usedKeys[$keyId])) self::block('HISTORY_INVALID');
                } elseif (!$changed && $issued < $previous['expiresAt']) self::block('HISTORY_INVALID');
            }
            $usedKeys[$keyId] = true;
            $previous = $p;
            $previousHash = self::digest($event);
        }
        if (($history['activeSha256'] ?? null) !== $previousHash) self::block('HISTORY_INVALID');
        return $previous;
    }

    private static function fileHash(string $path): string
    {
        if (is_link($path) || !is_file($path) || !is_string($hash = hash_file('sha256', $path))) self::block('SOURCE_INVALID');
        return $hash;
    }

    private static function baseline(?array $previous, array $staticUrls, array $urls): array
    {
        sort($staticUrls, SORT_STRING);
        $staticDigest = self::digest($staticUrls);
        $path = PROJECT_ROOT . 'sitemap.xml';
        if (is_link($path) || (file_exists($path) && !is_file($path))) self::block('SITEMAP_UNTRUSTED');
        $bytes = is_file($path) ? file_get_contents($path) : null;
        if ($bytes === false) self::block('SITEMAP_UNTRUSTED');
        $hash = $bytes === null ? null : hash('sha256', $bytes);
        $current = ['beforeSha256' => $hash, 'staticUrlsSha256' => $staticDigest];
        $expected = array_merge($staticUrls, $urls);
        if (count(array_unique($expected)) !== count($expected)) self::block('SITEMAP_DUPLICATE');
        if ($previous !== null) {
            if ($previous !== $current) self::block('SITEMAP_BASELINE_CHANGED');
            return $previous;
        }
        if ($bytes !== null) {
            $doc = new DOMDocument();
            $errors = libxml_use_internal_errors(true);
            try { $valid = $doc->loadXML($bytes, LIBXML_NONET); }
            finally { libxml_clear_errors(); libxml_use_internal_errors($errors); }
            if (!$valid || $doc->doctype !== null || $doc->documentElement?->localName !== 'urlset') self::block('SITEMAP_UNTRUSTED');
            $seen = [];
            foreach ($doc->getElementsByTagName('loc') as $loc) $seen[] = $loc->textContent;
            sort($seen, SORT_STRING);
            sort($expected, SORT_STRING);
            if ($seen !== $expected) self::block('SITEMAP_UNTRUSTED');
        }
        return $current;
    }

    private static function loadHistory(array $store, array $context, int $now): array
    {
        $exists = array_key_exists('dynamicInventory', $store);
        $history = $store['dynamicInventory'] ?? null;
        if ($exists && !is_array($history)) self::block('HISTORY_INVALID');
        $witness = null;
        foreach (read_audit_log()['items'] ?? [] as $audit) {
            if (($audit['action'] ?? '') !== 'public_inventory.technical_attestation') continue;
            if (!$exists) self::block('HISTORY_MISSING');
            $witness = $audit['meta']['eventSha256'] ?? '';
            break;
        }
        if (!$exists) {
            $history = ['schemaVersion' => 1, 'activeSha256' => null, 'events' => []];
        }
        $previous = $exists ? self::history($history, $context, $now) : null;
        if ($witness !== null && $witness !== $history['activeSha256']) self::block('AUDIT_HEAD_MISMATCH');
        return [$history, $previous];
    }

    public static function trustedOrigin(array $store, array $context): array
    {
        [, $previous] = self::loadHistory($store, $context, time());
        if ($previous === null) self::block('HISTORY_MISSING');
        return $previous['content']['baseline'];
    }

    public static function prepare(array $store, array $context, array $staticUrls, int $now, ?array $carChange = null): array
    {
        [$history, $previous] = self::loadHistory($store, $context, $now);
        if ($previous === null && array_key_exists('sitemapContinuity', $store)) self::block('HISTORY_MISSING');
        $inventory = $context['inventory'];
        // Only the two authoritative dynamic stores may advance without static repinning.
        foreach (['routes' => PROJECT_ROOT . 'data/routes.json', 'representatives' => ADMIN_USERS_FILE,
            'partners' => PARTNERS_FILE, 'demand' => LANDING_PAGE_DRAFTS_FILE] as $name => $path) {
            $hash = self::fileHash($path);
            if (in_array($name, ['routes', 'representatives'], true) && ($inventory['dependencies'][$name] ?? null) !== $hash) {
                self::block('STATIC_DEPENDENCY_STALE');
            }
            $inventory['dependencies'][$name] = $hash;
        }
        $entries = ApprovedPublicDynamicInventory::projection();
        $sources = ApprovedPublicDynamicInventory::sources($inventory);
        $sources['automationRules'] = self::fileHash(__FILE__);
        if ($previous === null && array_key_exists('dynamicEnvelope', $inventory)) {
            ApprovedPublicDynamicInventory::verify($inventory, $context['issuer'], $context['keyId'], base64_decode($context['publicKeyBase64'], true));
        }
        if ($previous !== null) {
            foreach (['partnerEndpoint', 'demandEndpoint', 'demandRules', 'partnerRules', 'projector', 'automationRules'] as $key) {
                $previousHash = $previous['content']['sources'][$key] ?? null;
                $predecessor = match ($key) {
                    'demandRules' => '76966491c9f64ebf1d6516acf3992021be1172f0d129f924368928b3d218a52a',
                    'automationRules' => in_array($previousHash, [
                        'd948237900d2b5d5753eb8be30ff75c18a2494e079e55b66012cbad87c4a4180',
                        '949f1f533942e47d45d7530e91ad6d52bb964ea0e80b1173d5581ea40e2c6713',
                        '85fb3e5781ed8086ddecde69ad49151c7dbc3949de5501cf5ffb178e5026ae57',
                    ], true) ? $previousHash : null,
                    'partnerRules' => in_array($previousHash, [
                        '112a607000d45db35db40a81b2ce525e85419c1f8898446967478b5c910c94ab',
                        '47d7498555ce8e860c23e0c7431c30fab9df67fea23893328d1ba5224bf92702',
                    ], true) && $sources[$key] === '901950d7ee7a72064148f6a5e3f70e2dab3172417c5b0a25c2ee48cf85452e13' ? $previousHash : null,
                    default => null,
                };
                // The predecessor used the same projection rules, without native writer evidence.
                $compatible = $predecessor !== null && $previousHash === $predecessor
                    && ($key !== 'demandRules' || $sources[$key] === '3cf9d8a5da0848e20badbf4783d3339446a4791f71ed633732d13bb9db8f5080');
                if ($previousHash !== $sources[$key] && !$compatible) self::block('SOURCE_RULES_CHANGED');
            }
            if ($previous['content']['siteDigest'] !== $inventory['siteDigest'] || $previous['content']['decisionId'] !== $inventory['decisionId']) {
                self::block('PROVENANCE_CHANGED');
            }
        }
        $urls = array_column($entries, 'url');
        $origin = $previous['content']['baseline'] ?? null;
        $continuity = $origin === null ? null : ApprovedSitemapContinuity::observe($store, $origin, $context);
        $oldStatic = $staticUrls;
        if ($carChange !== null && $continuity !== null) {
            $url = $carChange['url'];
            sort($oldStatic, SORT_STRING);
            if (self::digest($oldStatic) !== $continuity['baseline']['staticUrlsSha256']) {
                $oldStatic = $carChange['action'] === 'withdraw' ? array_merge($staticUrls, [$url])
                    : array_values(array_diff($staticUrls, [$url]));
            }
        }
        $baseline = self::baseline($continuity['baseline'] ?? null, $oldStatic, $urls);
        if (($continuity['sha256'] ?? null) !== null) $sources['sitemapContinuity'] = $continuity['sha256'];
        $content = ['decisionId' => $inventory['decisionId'], 'siteDigest' => $inventory['siteDigest'], 'sources' => $sources,
            'entries' => $entries, 'baseline' => $origin ?? $baseline];
        $changed = $previous === null || self::digest($previous['content']) !== self::digest($content);
        $rotating = $previous !== null && $previous['keyId'] !== $context['keyId'];
        $audit = null;
        if ($changed || $rotating || $previous['expiresAt'] <= $now) {
            $ttl = $context['inventorySignatureLifetimeSeconds'] ?? 3600;
            if (!is_int($ttl) || $ttl < 1 || $ttl > 86400) self::block('SIGNING_CONFIGURATION');
            $payload = ['schemaVersion' => 1, 'audience' => 'rent-rk-global-sitemap', 'issuer' => $context['issuer'], 'keyId' => $context['keyId'],
                'issuedAt' => $now, 'expiresAt' => $now + $ttl, 'revision' => ($previous['revision'] ?? 0) + (int) $changed,
                'previousSha256' => $history['activeSha256'], 'content' => $content];
            $secret = base64_decode($context['secretKeyBase64'], true);
            try { $signature = sodium_crypto_sign_detached(self::signingBytes($payload), $secret); }
            finally { sodium_memzero($secret); }
            $event = ['payload' => $payload, 'signature' => base64_encode($signature)];
            $history['events'][] = $event;
            $history['activeSha256'] = self::digest($event);
            self::history($history, $context, $now);
            $audit = ['revision' => $payload['revision'], 'eventSha256' => $history['activeSha256'], 'previousSha256' => $payload['previousSha256'],
                'reason' => $previous === null ? 'initial' : ($changed ? 'source_version' : ($rotating ? 'rotation' : 'expiry')),
                'keyId' => $context['keyId'], 'published' => false];
            $previous = $payload;
        }
        return ['urls' => $urls, 'sha256' => $history['activeSha256'], 'revision' => $previous['revision'],
            'expiresAt' => $previous['expiresAt'], 'beforeSha256' => $baseline['beforeSha256'], 'history' => $history, 'audit' => $audit];
    }
}
