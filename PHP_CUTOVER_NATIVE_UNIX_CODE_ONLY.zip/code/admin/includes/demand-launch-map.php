<?php

declare(strict_types=1);

function demand_map_read_clusters(): array
{
    return demand_read_container(DEMAND_CLUSTERS_FILE);
}

function demand_map_save_clusters(array $data): void
{
    demand_write_container(DEMAND_CLUSTERS_FILE, $data);
}

function demand_map_read_launch_plan(): array
{
    return demand_read_container(SEO_LAUNCH_PLAN_FILE);
}

function demand_map_save_launch_plan(array $data): void
{
    demand_write_container(SEO_LAUNCH_PLAN_FILE, $data);
}

function demand_map_read_card_hints(): array
{
    return demand_read_container(DEMAND_CARD_OPTIMIZATION_HINTS_FILE);
}

function demand_map_save_card_hints(array $data): void
{
    demand_write_container(DEMAND_CARD_OPTIMIZATION_HINTS_FILE, $data);
}

function demand_map_read_content_briefs(): array
{
    return demand_read_container(DEMAND_CONTENT_BRIEFS_FILE);
}

function demand_map_save_content_briefs(array $data): void
{
    demand_write_container(DEMAND_CONTENT_BRIEFS_FILE, $data);
}

function demand_map_visible_items(array $items, string $scopeFilter, string $permission): array
{
    if (!has_permission($permission)) {
        return [];
    }

    $scopeIds = demand_current_scope_filter($scopeFilter);
    if (!$scopeIds) {
        return [];
    }

    return array_values(array_filter($items, static function ($item) use ($scopeIds): bool {
        return is_array($item)
            && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopeIds, true);
    }));
}

function demand_map_visible_clusters(string $scopeFilter): array
{
    $items = demand_map_visible_items(demand_map_read_clusters()['items'], $scopeFilter, 'demand.map.view');
    usort($items, static fn(array $a, array $b): int => ((int) ($b['priorityScore'] ?? 0)) <=> ((int) ($a['priorityScore'] ?? 0)));

    return $items;
}

function demand_map_visible_launch_plan(string $scopeFilter): array
{
    $items = demand_map_visible_items(demand_map_read_launch_plan()['items'], $scopeFilter, 'demand.launch_plan.view');
    usort($items, static fn(array $a, array $b): int => ((int) ($b['priorityScore'] ?? 0)) <=> ((int) ($a['priorityScore'] ?? 0)));

    return $items;
}

function demand_map_visible_card_hints(string $scopeFilter): array
{
    $items = demand_map_visible_items(demand_map_read_card_hints()['items'], $scopeFilter, 'demand.card_hints.view');
    usort($items, static fn(array $a, array $b): int => strcmp((string) ($b['createdAt'] ?? ''), (string) ($a['createdAt'] ?? '')));

    return $items;
}

function demand_map_visible_content_briefs(string $scopeFilter): array
{
    $items = demand_map_visible_items(demand_map_read_content_briefs()['items'], $scopeFilter, 'demand.content_briefs.view');
    usort($items, static fn(array $a, array $b): int => strcmp((string) ($b['createdAt'] ?? ''), (string) ($a['createdAt'] ?? '')));

    return $items;
}

function demand_map_contains_any(string $normalized, array $needles): bool
{
    foreach ($needles as $needle) {
        if ($needle !== '' && str_contains($normalized, demand_normalize_phrase($needle))) {
            return true;
        }
    }

    return false;
}

function demand_map_cluster_seed(array $keyword): array
{
    $normalized = demand_normalize_phrase((string) ($keyword['normalizedPhrase'] ?? $keyword['phrase'] ?? ''));
    $city = (string) ($keyword['detectedCity'] ?? '');
    $region = (string) ($keyword['detectedRegion'] ?? '');
    $class = (string) ($keyword['detectedCarClass'] ?? '');
    $condition = (string) ($keyword['detectedCondition'] ?? '');
    $regionName = (string) ($keyword['regionName'] ?? ($city ?: $region));
    $negativeIntent = (string) ($keyword['negativeIntent'] ?? '');

    if ($negativeIntent !== '') {
        return [
            'key' => 'excluded:' . $negativeIntent . ':' . substr(hash('sha1', $normalized), 0, 10),
            'clusterType' => 'excluded',
            'name' => 'Нецелевой запрос: ' . (string) ($keyword['phrase'] ?? ''),
            'intent' => 'unsafe_or_unsupported',
            'regionName' => $regionName,
        ];
    }

    if ($condition === 'без залога' || demand_map_contains_any($normalized, ['без залога'])) {
        return [
            'key' => 'condition:no_deposit:' . demand_normalize_phrase($regionName ?: 'all'),
            'clusterType' => 'condition',
            'name' => 'Запросы про аренду без залога',
            'intent' => 'deposit_sensitive_rental',
            'regionName' => $regionName,
        ];
    }

    if (demand_map_contains_any($normalized, ['дешево', 'дешёв', 'недорого', 'доступно'])) {
        return [
            'key' => 'price:economy:' . demand_normalize_phrase($regionName ?: 'all'),
            'clusterType' => 'price',
            'name' => 'Экономичные варианты аренды авто' . ($regionName !== '' ? ': ' . $regionName : ''),
            'intent' => 'economy_rental',
            'regionName' => $regionName,
        ];
    }

    if (demand_map_contains_any($normalized, ['аэропорт', 'симферополь аэропорт'])) {
        return [
            'key' => 'airport:simferopol:' . demand_normalize_phrase($regionName ?: 'crimea'),
            'clusterType' => 'airport',
            'name' => 'Аренда авто в аэропорту Симферополя',
            'intent' => 'airport_pickup_rental',
            'regionName' => $regionName ?: 'Симферополь',
        ];
    }

    if ($class !== '' || demand_map_contains_any($normalized, ['минивэн', 'минивен', '7 мест', 'семимест', 'кабриолет', 'кроссовер'])) {
        $detectedClass = $class;
        if ($detectedClass === '' && demand_map_contains_any($normalized, ['минивэн', 'минивен', '7 мест', 'семимест'])) {
            $detectedClass = 'минивэн';
        } elseif ($detectedClass === '' && demand_map_contains_any($normalized, ['кабриолет'])) {
            $detectedClass = 'кабриолет';
        } elseif ($detectedClass === '' && demand_map_contains_any($normalized, ['кроссовер'])) {
            $detectedClass = 'кроссовер';
        }

        $name = match ($detectedClass) {
            'минивэн' => 'Минивэны и 7 мест',
            'кабриолет' => 'Кабриолеты',
            'кроссовер' => 'Кроссоверы',
            default => 'Класс авто: ' . $detectedClass,
        };

        return [
            'key' => 'car_class:' . demand_normalize_phrase($detectedClass) . ':' . demand_normalize_phrase($regionName ?: $city ?: $region ?: 'all'),
            'clusterType' => 'car_class',
            'name' => $name . (($city ?: $regionName ?: $region) !== '' ? ': ' . ($city ?: $regionName ?: $region) : ''),
            'intent' => str_replace(' ', '_', $detectedClass) . '_rental',
            'regionName' => $regionName ?: $city ?: $region,
        ];
    }

    if ($city !== '') {
        return [
            'key' => 'city:' . demand_normalize_phrase($city),
            'clusterType' => 'city',
            'name' => 'Аренда авто в ' . $city,
            'intent' => 'city_car_rental',
            'regionName' => $city,
        ];
    }

    if ($region !== '' || demand_map_contains_any($normalized, ['крым'])) {
        $name = $region ?: 'Крым';
        return [
            'key' => 'region:' . demand_normalize_phrase($name),
            'clusterType' => 'region',
            'name' => 'Аренда авто: ' . $name,
            'intent' => 'region_car_rental',
            'regionName' => $name,
        ];
    }

    if (demand_map_contains_any($normalized, ['семья', 'семей', 'детское кресло', 'дети'])) {
        return [
            'key' => 'family:' . demand_normalize_phrase($regionName ?: 'all'),
            'clusterType' => 'family',
            'name' => 'Семейные поездки и дети',
            'intent' => 'family_rental',
            'regionName' => $regionName,
        ];
    }

    if (demand_map_contains_any($normalized, ['неделя', 'месяц', 'сутки', 'день'])) {
        return [
            'key' => 'duration:' . demand_normalize_phrase($regionName ?: 'all'),
            'clusterType' => 'duration',
            'name' => 'Срок аренды авто',
            'intent' => 'duration_rental',
            'regionName' => $regionName,
        ];
    }

    return [
        'key' => 'unknown:' . substr(hash('sha1', $normalized), 0, 12),
        'clusterType' => 'unknown',
        'name' => 'Неразобранный спрос',
        'intent' => 'unknown',
        'regionName' => $regionName,
    ];
}

function demand_map_external_metrics_by_entity(): array
{
    $data = function_exists('demand_integrations_read_external_metrics')
        ? demand_integrations_read_external_metrics()
        : demand_read_container(DEMAND_EXTERNAL_METRICS_FILE);
    $result = [];
    foreach ((array) ($data['items'] ?? []) as $item) {
        if (!is_array($item)) {
            continue;
        }
        $entityType = (string) ($item['entityType'] ?? '');
        $entityId = (string) ($item['entityId'] ?? '');
        if ($entityType === '' || $entityId === '') {
            continue;
        }
        $result[$entityType][$entityId][] = $item;
    }

    return $result;
}

function demand_map_keyword_frequency(array $keyword, array $metricsByEntity): int
{
    $frequency = max(0, (int) ($keyword['frequency'] ?? 0));
    $keywordId = (string) ($keyword['id'] ?? '');
    foreach ((array) ($metricsByEntity['keyword'][$keywordId] ?? []) as $metric) {
        $metrics = is_array($metric['metrics'] ?? null) ? $metric['metrics'] : [];
        foreach (['frequency30d', 'wordstatFrequency', 'frequency'] as $field) {
            if (isset($metrics[$field])) {
                $frequency = max($frequency, (int) $metrics[$field]);
            }
        }
    }

    return $frequency;
}

function demand_map_keyword_seasonality(array $keyword, array $metricsByEntity): float
{
    $score = 0.0;
    $keywordId = (string) ($keyword['id'] ?? '');
    foreach ((array) ($metricsByEntity['keyword'][$keywordId] ?? []) as $metric) {
        $metrics = is_array($metric['metrics'] ?? null) ? $metric['metrics'] : [];
        $seasonality = is_array($metrics['seasonality'] ?? null) ? $metrics['seasonality'] : [];
        $dynamics = is_array($metrics['dynamics'] ?? null) ? $metrics['dynamics'] : [];
        $score = max($score, min(10.0, (count($seasonality) + count($dynamics)) * 1.5));
    }

    return $score;
}

function demand_map_has_existing_page(array $cluster, array $keywordsById, array $drafts): bool
{
    foreach ((array) ($cluster['keywordIds'] ?? []) as $keywordId) {
        $keyword = $keywordsById[(string) $keywordId] ?? null;
        if (!is_array($keyword)) {
            continue;
        }
        if (demand_find_similar_pages($keyword)) {
            return true;
        }
        $slug = demand_landing_slug_for_keyword($keyword);
        foreach ($drafts as $draft) {
            if (!is_array($draft)) {
                continue;
            }
            if ((string) ($draft['slug'] ?? '') === $slug && !in_array((string) ($draft['publishStatus'] ?? ''), ['archived', 'merged', 'rolled_back'], true)) {
                return true;
            }
        }
    }

    return false;
}

function demand_map_supply_score(array $cars): int
{
    if (!$cars) {
        return 0;
    }

    $score = 8 + min(7, count($cars) * 2);
    $withPrice = array_values(array_filter($cars, static fn(array $car): bool => demand_car_has_price($car)));
    $withDeposit = array_values(array_filter($cars, static fn(array $car): bool => demand_car_deposit_state($car) !== 'unknown'));
    $withPhoto = array_values(array_filter($cars, static fn(array $car): bool => trim((string) ($car['image'] ?? '')) !== ''));
    $score += $withPrice ? 4 : 0;
    $score += $withDeposit ? 4 : 0;
    $score += $withPhoto ? 2 : 0;

    return min(25, $score);
}

function demand_map_commercial_score(array $keywords): int
{
    $score = 0;
    foreach ($keywords as $keyword) {
        $normalized = (string) ($keyword['normalizedPhrase'] ?? '');
        if (demand_map_contains_any($normalized, ['аренда', 'прокат', 'заказать', 'цена', 'на сутки', 'на неделю', 'в аренду'])) {
            $score += 4;
        }
    }

    return min(15, max(4, $score));
}

function demand_map_risk_score(array $riskFlags): int
{
    $score = 0;
    foreach (array_unique($riskFlags) as $flag) {
        $score += match ((string) $flag) {
            'not_relevant_for_car_rental', 'unsupported_legal_request' => 45,
            'possible_false_promise', 'condition_not_supported' => 22,
            'no_matching_cars', 'region_not_supported' => 18,
            'no_price_data', 'no_deposit_data', 'needs_human_review' => 8,
            'too_generic', 'too_similar_to_existing_page', 'low_frequency' => 5,
            default => 4,
        };
    }

    return min(45, $score);
}

function demand_map_cluster_risk_flags(array $clusterKeywords, array $cars): array
{
    $flags = [];
    foreach ($clusterKeywords as $keyword) {
        $flags = array_merge($flags, (array) ($keyword['riskFlags'] ?? []));
    }

    if (!$cars) {
        $flags[] = 'no_matching_cars';
    }

    $normalizedPhrases = demand_normalize_phrase(implode(' ', array_map(static fn(array $keyword): string => (string) ($keyword['phrase'] ?? ''), $clusterKeywords)));
    if (demand_map_contains_any($normalizedPhrases, ['без залога'])) {
        $depositStates = array_values(array_unique(array_map(static fn(array $car): string => demand_car_deposit_state($car), $cars)));
        if (!$cars || in_array('has_deposit', $depositStates, true) || in_array('unknown', $depositStates, true)) {
            $flags[] = 'possible_false_promise';
            $flags[] = 'condition_not_supported';
        }
    }

    if (demand_map_contains_any($normalizedPhrases, ['дешево', 'дешёв', 'недорого'])) {
        $economyCars = array_values(array_filter($cars, static function (array $car): bool {
            $price = normalize_rate_price($car['price'] ?? null);
            if ($price === null) {
                $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
                $rate = $slug !== '' ? rate_for_car($slug, $car) : [];
                $price = normalize_rate_price($rate['base'] ?? null);
            }

            return $price !== null && (int) $price <= 4500;
        }));
        if (!$economyCars) {
            $flags[] = 'needs_human_review';
        }
    }

    return demand_unique_strings($flags);
}

function demand_map_plan_type_for_cluster(array $cluster, bool $hasPage, array $riskFlags): string
{
    if ((string) ($cluster['clusterType'] ?? '') === 'excluded' || in_array('not_relevant_for_car_rental', $riskFlags, true) || in_array('unsupported_legal_request', $riskFlags, true)) {
        return 'do_not_create_page';
    }
    if (in_array('possible_false_promise', $riskFlags, true)) {
        return 'condition_explanation';
    }
    if (in_array('region_not_confirmed', $riskFlags, true) || in_array('unknown_region', $riskFlags, true)) {
        return 'needs_business_decision';
    }
    if (in_array('no_matching_cars', $riskFlags, true)) {
        return 'needs_business_decision';
    }
    if ($hasPage) {
        return 'internal_linking';
    }

    return match ((string) ($cluster['clusterType'] ?? 'unknown')) {
        'city' => 'city_page',
        'region', 'car_class' => 'landing_page',
        'condition' => 'condition_explanation',
        'airport', 'family', 'season', 'duration', 'price' => 'landing_page',
        default => 'faq_block',
    };
}

function demand_map_recommended_action(string $planType, array $riskFlags): string
{
    if ($planType === 'do_not_create_page' || in_array('not_relevant_for_car_rental', $riskFlags, true) || in_array('unsupported_legal_request', $riskFlags, true)) {
        return 'ignore_as_irrelevant';
    }
    if (in_array('possible_false_promise', $riskFlags, true)) {
        return 'create_condition_explanation';
    }
    if (in_array('region_not_confirmed', $riskFlags, true) || in_array('unknown_region', $riskFlags, true)) {
        return 'needs_business_decision';
    }
    if (in_array('no_matching_cars', $riskFlags, true)) {
        return 'postpone_until_supply_exists';
    }

    return match ($planType) {
        'city_page' => 'create_city_landing_draft',
        'landing_page', 'category_page' => 'create_landing_draft',
        'internal_linking' => 'add_internal_links',
        'car_card_update' => 'create_card_optimization_hint',
        'condition_explanation' => 'create_condition_explanation',
        default => 'create_content_brief',
    };
}

function demand_map_action_from_stage_b_decision(string $recommendedDecision, string $planType, array $riskFlags): string
{
    if ($recommendedDecision === '') {
        return demand_map_recommended_action($planType, $riskFlags);
    }

    return match ($recommendedDecision) {
        'create_landing_page' => $planType === 'city_page' ? 'create_city_landing_draft' : 'create_landing_draft',
        'improve_existing_page', 'merge_with_existing_page' => 'improve_existing_page',
        'create_faq' => 'add_faq',
        'add_condition_block' => 'create_condition_explanation',
        'create_car_card_hint' => 'create_card_optimization_hint',
        'create_content_brief' => 'create_content_brief',
        'needs_business_decision' => 'needs_business_decision',
        'needs_human_review' => 'need_human_review',
        'do_not_create_page' => 'do_not_create_page',
        'ignore_as_irrelevant' => 'ignore_as_irrelevant',
        'postpone_until_supply_exists' => 'postpone_until_supply_exists',
        default => demand_map_recommended_action($planType, $riskFlags),
    };
}

function demand_map_reason(array $cluster, bool $hasPage, int $carCount, array $riskFlags, string $priority): string
{
    if ((string) ($cluster['clusterType'] ?? '') === 'excluded' || in_array('not_relevant_for_car_rental', $riskFlags, true)) {
        return 'Нецелевой или неподдерживаемый запрос. Он сохраняется для истории и анализа, но не должен становиться страницей, черновиком, ТЗ или подсказкой для авто.';
    }
    if (in_array('possible_false_promise', $riskFlags, true)) {
        return 'Запрос есть, но страница с обещанием "без залога" может создать ложное ожидание. Нужна либо подтвержденная бизнес-политика без залога, либо безопасный информационный блок про размер залога и условия возврата.';
    }
    if (in_array('region_not_confirmed', $riskFlags, true) || in_array('unknown_region', $riskFlags, true)) {
        return 'Спрос найден по региону, который не входит в подтверждённую зону Rent RK. Нужно решить, работаем ли мы с этим городом, прежде чем готовить страницу.';
    }
    if (in_array('no_matching_cars', $riskFlags, true)) {
        return 'Спрос найден, но подходящие активные автомобили или подтвержденные условия не найдены. Перед созданием посадочной страницы нужно решить, реально ли Rent RK оказывает эту услугу.';
    }
    if ($hasPage) {
        return 'Похожая страница или черновик уже есть. Лучше доработать существующий материал, FAQ, карточки авто и внутренние ссылки, не создавая дубль.';
    }
    if ($priority === 'high') {
        return 'Высокий приоритет: есть спрос, найдено предложение в автопарке, отдельной страницы не найдено. Рекомендуется подготовить черновик и связанные подсказки для карточек авто.';
    }

    return 'Кластер полезен для карты запуска: есть спрос и можно подготовить контент внутри ручного workflow без автоматической публикации.';
}

function demand_map_build_required_work(string $planType, bool $hasPage, array $riskFlags, array $cars): array
{
    $work = [];
    if ($planType === 'do_not_create_page' || in_array('not_relevant_for_car_rental', $riskFlags, true) || in_array('unsupported_legal_request', $riskFlags, true)) {
        return ['ignore_as_irrelevant'];
    }
    if (in_array('possible_false_promise', $riskFlags, true)) {
        return ['create_condition_explanation', 'needs_business_decision'];
    }
    if (in_array('region_not_confirmed', $riskFlags, true) || in_array('unknown_region', $riskFlags, true)) {
        return ['needs_business_decision'];
    }
    if (in_array('no_matching_cars', $riskFlags, true)) {
        return ['postpone_until_supply_exists', 'needs_business_decision'];
    }
    if (!$hasPage && in_array($planType, ['landing_page', 'city_page', 'category_page'], true)) {
        $work[] = 'create_landing_draft';
    }
    $work[] = 'create_content_brief';
    $work[] = 'add_faq';
    $work[] = 'add_internal_links';
    if ($cars) {
        $work[] = 'improve_car_cards';
    }

    return array_values(array_unique($work));
}

function demand_map_priority_from_score(int $score, array $riskFlags): string
{
    if (in_array('not_relevant_for_car_rental', $riskFlags, true) || in_array('unsupported_legal_request', $riskFlags, true)) {
        return 'blocked';
    }
    if (in_array('possible_false_promise', $riskFlags, true) || in_array('condition_not_supported', $riskFlags, true)) {
        return 'blocked';
    }
    if (in_array('no_matching_cars', $riskFlags, true) || in_array('region_not_supported', $riskFlags, true) || in_array('region_not_confirmed', $riskFlags, true) || in_array('unknown_region', $riskFlags, true)) {
        return 'needs_business_decision';
    }
    if ($score >= 70) {
        return 'high';
    }
    if ($score >= 45) {
        return 'medium';
    }

    return 'low';
}

function demand_map_recalculate(string $scopeFilter = 'all'): array
{
    require_permission('demand.map.manage');

    $scopeIds = demand_current_scope_filter($scopeFilter);
    if (!$scopeIds) {
        deny_scope_access();
    }

    $metricsByEntity = demand_map_external_metrics_by_entity();
    $keywords = array_values(array_filter(read_demand_keywords()['items'], static function ($item) use ($scopeIds): bool {
        return is_array($item)
            && (string) ($item['status'] ?? 'active') === 'active'
            && trim((string) ($item['negativeIntent'] ?? '')) === ''
            && empty($item['isExcluded'])
            && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopeIds, true);
    }));

    $keywordsById = [];
    foreach ($keywords as $keyword) {
        $keywordsById[(string) ($keyword['id'] ?? '')] = $keyword;
    }

    $buckets = [];
    foreach ($keywords as $keyword) {
        $seed = demand_map_cluster_seed($keyword);
        $scopeId = demand_normalize_scope_id((string) ($keyword['scope_id'] ?? 'rent_rk'));
        $bucketKey = $scopeId . '|' . (string) $seed['key'];
        if (!isset($buckets[$bucketKey])) {
            $buckets[$bucketKey] = [
                'seed' => $seed,
                'scope_id' => $scopeId,
                'keywords' => [],
            ];
        }
        $buckets[$bucketKey]['keywords'][] = $keyword;
    }

    $existingClusters = [];
    foreach (demand_map_read_clusters()['items'] as $item) {
        if (is_array($item)) {
            $existingClusters[(string) ($item['id'] ?? '')] = $item;
        }
    }
    $existingPlans = [];
    foreach (demand_map_read_launch_plan()['items'] as $item) {
        if (is_array($item)) {
            $existingPlans[(string) ($item['id'] ?? '')] = $item;
        }
    }

    $drafts = read_landing_page_drafts()['items'];
    $clusters = [];
    $plans = [];
    $createdClusters = 0;
    $updatedClusters = 0;
    $createdPlans = 0;
    $now = now_iso();

    foreach ($buckets as $bucketKey => $bucket) {
        $seed = $bucket['seed'];
        $scopeId = (string) $bucket['scope_id'];
        $clusterKeywords = (array) $bucket['keywords'];
        usort($clusterKeywords, static function (array $a, array $b) use ($metricsByEntity): int {
            return demand_map_keyword_frequency($b, $metricsByEntity) <=> demand_map_keyword_frequency($a, $metricsByEntity);
        });
        $primaryKeyword = $clusterKeywords[0] ?? [];
        $clusterId = 'dc_' . substr(hash('sha1', $bucketKey), 0, 14);
        $existingCluster = $existingClusters[$clusterId] ?? [];
        $keywordIds = array_values(array_filter(array_map(static fn(array $keyword): string => (string) ($keyword['id'] ?? ''), $clusterKeywords)));
        $carsBySlug = [];
        foreach ($clusterKeywords as $keyword) {
            foreach (demand_match_cars_for_keyword($keyword) as $car) {
                $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
                if ($slug !== '') {
                    $carsBySlug[$slug] = $car;
                }
            }
        }
        $cars = array_values($carsBySlug);
        $riskFlags = demand_map_cluster_risk_flags($clusterKeywords, $cars);
        $hasPage = demand_map_has_existing_page(['keywordIds' => $keywordIds], $keywordsById, $drafts);
        $totalFrequency = array_sum(array_map(static fn(array $keyword): int => demand_map_keyword_frequency($keyword, $metricsByEntity), $clusterKeywords));
        $seasonalityScore = (int) min(10, array_sum(array_map(static fn(array $keyword): float => demand_map_keyword_seasonality($keyword, $metricsByEntity), $clusterKeywords)));
        $stageBKeyword = $primaryKeyword;
        $stageBKeyword['frequency'] = $totalFrequency;
        $stageBKeyword['riskFlags'] = $riskFlags;
        $stageB = demand_stage_b_score_keyword($stageBKeyword, [
            'cars' => $cars,
            'similarPages' => is_array($primaryKeyword) ? demand_find_similar_pages($primaryKeyword) : [],
            'clusterKeywordCount' => count($clusterKeywords),
            'seasonalityScore' => $seasonalityScore,
            'hasExistingPage' => $hasPage,
            'drafts' => $drafts,
        ]);
        $stageC = demand_stage_c_analyze_keyword($stageBKeyword, [
            'cars' => $cars,
            'stageB' => $stageB,
            'similarPages' => is_array($primaryKeyword) ? demand_find_similar_pages($primaryKeyword) : [],
        ]);
        $riskFlags = demand_unique_strings((array) ($stageB['riskFlags'] ?? $riskFlags));
        $demandScore = (int) ($stageB['demandVolumeScore'] ?? 0);
        $supplyScore = (int) ($stageB['supplyFitScore'] ?? demand_map_supply_score($cars));
        $commercialScore = (int) ($stageB['commercialScore'] ?? demand_map_commercial_score($clusterKeywords));
        $pageFitScore = (int) ($stageB['pageFitScore'] ?? 0);
        $contentGapScore = (int) ($stageB['contentGapScore'] ?? ($hasPage ? 4 : 20));
        $regionFitScore = (int) ($stageB['regionFitScore'] ?? ((string) ($seed['regionName'] ?? '') !== '' ? 8 : 3));
        $riskScore = (int) ($stageB['riskScore'] ?? demand_map_risk_score($riskFlags));
        $priorityScore = (int) ($stageB['decisionScore'] ?? max(0, min(100, $demandScore + $supplyScore + $commercialScore + $contentGapScore + $seasonalityScore - $riskScore)));
        $priority = (string) ($stageB['priorityLevel'] ?? demand_map_priority_from_score($priorityScore, $riskFlags));

        $cluster = array_merge($existingCluster, [
            'id' => $clusterId,
            'scope_id' => $scopeId,
            'name' => (string) ($seed['name'] ?? 'Кластер спроса'),
            'clusterType' => (string) ($seed['clusterType'] ?? 'unknown'),
            'intent' => (string) ($seed['intent'] ?? 'unknown'),
            'regionName' => (string) ($seed['regionName'] ?? ''),
            'primaryPhrase' => (string) ($primaryKeyword['phrase'] ?? ''),
            'keywordIds' => $keywordIds,
            'keywordCount' => count($keywordIds),
            'totalFrequency' => $totalFrequency,
            'demandVolumeScore' => $demandScore,
            'regionMatchScore' => (string) ($seed['regionName'] ?? '') !== '' ? 8 : 3,
            'regionFitScore' => $regionFitScore,
            'seasonalityScore' => $seasonalityScore,
            'commercialScore' => $commercialScore,
            'supplyScore' => $supplyScore,
            'supplyFitScore' => $supplyScore,
            'pageFitScore' => $pageFitScore,
            'contentGapScore' => $contentGapScore,
            'riskScore' => $riskScore,
            'priorityScore' => $priorityScore,
            'decisionScore' => $priorityScore,
            'priority' => $priority,
            'priorityLevel' => $priority,
            'recommendedDecision' => (string) ($stageB['recommendedDecision'] ?? ''),
            'scoringExplanation' => (string) ($stageB['scoringExplanation'] ?? ''),
            'contentGapSummary' => (string) ($stageB['contentGapSummary'] ?? ''),
            'pageFitStatus' => (string) ($stageB['pageFitStatus'] ?? ($hasPage ? 'page_exists_weak_fit' : 'no_page_found')),
            'pageFitSummary' => (string) ($stageB['pageFitSummary'] ?? ''),
            'supplyFitSummary' => (string) ($stageB['supplyFitSummary'] ?? ''),
            'pageRiskProfile' => (array) ($stageB['pageRiskProfile'] ?? []),
            'whatBlocks' => (array) ($stageB['whatBlocks'] ?? []),
            'userQuestionMap' => (array) ($stageC['userQuestionMap'] ?? []),
            'safeContentBlocks' => (array) ($stageC['safeContentBlocks'] ?? []),
            'contentGapReport' => (array) ($stageC['contentGapReport'] ?? []),
            'firstScreenAnswer' => (string) ($stageC['firstScreenAnswer'] ?? ''),
            'mustAnswer' => (array) ($stageC['mustAnswer'] ?? []),
            'mustNotPromise' => (array) ($stageC['mustNotPromise'] ?? []),
            'recommendedFaq' => (array) ($stageC['recommendedFaq'] ?? []),
            'recommendedInternalLinks' => (array) ($stageC['recommendedInternalLinks'] ?? []),
            'recommendedCarCardHints' => (array) ($stageC['recommendedCarCardHints'] ?? []),
            'userClarityScore' => (array) ($stageC['userClarityScore'] ?? []),
            'aiSearchReadiness' => (array) ($stageC['aiSearchReadiness'] ?? []),
            'riskFlags' => $riskFlags,
            'linkedCars' => array_keys($carsBySlug),
            'hasExistingPage' => $hasPage,
            'status' => (string) ($existingCluster['status'] ?? 'active'),
            'createdAt' => (string) ($existingCluster['createdAt'] ?? $now),
            'updatedAt' => $now,
        ]);
        $clusters[] = $cluster;
        if (!$existingCluster) {
            $createdClusters++;
            analytics_record_event('demand_cluster_created', [
                'scopeId' => $scopeId,
                'entityType' => 'demand_cluster',
                'entityId' => $clusterId,
            ]);
        } else {
            $updatedClusters++;
            analytics_record_event('demand_cluster_updated', [
                'scopeId' => $scopeId,
                'entityType' => 'demand_cluster',
                'entityId' => $clusterId,
            ]);
        }

        $planType = demand_map_plan_type_for_cluster($cluster, $hasPage, $riskFlags);
        $recommendedAction = demand_map_action_from_stage_b_decision((string) ($stageB['recommendedDecision'] ?? ''), $planType, $riskFlags);
        $planId = 'slp_' . substr(hash('sha1', $scopeId . '|' . $clusterId), 0, 14);
        $existingPlan = $existingPlans[$planId] ?? [];
        $launchStatus = (string) ($existingPlan['launchStatus'] ?? 'planned');
        if ($priority === 'blocked' && $launchStatus === 'planned') {
            $launchStatus = 'blocked';
        } elseif ($priority === 'needs_business_decision' && $launchStatus === 'planned') {
            $launchStatus = 'postponed';
        }

        $plan = array_merge($existingPlan, [
            'id' => $planId,
            'scope_id' => $scopeId,
            'title' => (string) $cluster['name'],
            'planType' => $planType,
            'clusterId' => $clusterId,
            'priority' => $priority,
            'priorityScore' => $priorityScore,
            'demandVolumeScore' => $demandScore,
            'commercialScore' => $commercialScore,
            'supplyFitScore' => $supplyScore,
            'pageFitScore' => $pageFitScore,
            'contentGapScore' => $contentGapScore,
            'riskScore' => $riskScore,
            'regionFitScore' => $regionFitScore,
            'seasonalityScore' => $seasonalityScore,
            'decisionScore' => $priorityScore,
            'priorityLevel' => $priority,
            'recommendedDecision' => (string) ($stageB['recommendedDecision'] ?? ''),
            'scoringExplanation' => (string) ($stageB['scoringExplanation'] ?? ''),
            'contentGapSummary' => (string) ($stageB['contentGapSummary'] ?? ''),
            'pageFitStatus' => (string) ($stageB['pageFitStatus'] ?? ($hasPage ? 'page_exists_weak_fit' : 'no_page_found')),
            'pageFitSummary' => (string) ($stageB['pageFitSummary'] ?? ''),
            'supplyFitSummary' => (string) ($stageB['supplyFitSummary'] ?? ''),
            'pageRiskProfile' => (array) ($stageB['pageRiskProfile'] ?? []),
            'whatBlocks' => (array) ($stageB['whatBlocks'] ?? []),
            'userQuestionMap' => (array) ($stageC['userQuestionMap'] ?? []),
            'safeContentBlocks' => (array) ($stageC['safeContentBlocks'] ?? []),
            'contentGapReport' => (array) ($stageC['contentGapReport'] ?? []),
            'firstScreenAnswer' => (string) ($stageC['firstScreenAnswer'] ?? ''),
            'mustAnswer' => (array) ($stageC['mustAnswer'] ?? []),
            'mustNotPromise' => (array) ($stageC['mustNotPromise'] ?? []),
            'recommendedFaq' => (array) ($stageC['recommendedFaq'] ?? []),
            'recommendedInternalLinks' => (array) ($stageC['recommendedInternalLinks'] ?? []),
            'recommendedCarCardHints' => (array) ($stageC['recommendedCarCardHints'] ?? []),
            'userClarityScore' => (array) ($stageC['userClarityScore'] ?? []),
            'aiSearchReadiness' => (array) ($stageC['aiSearchReadiness'] ?? []),
            'reason' => (string) ($stageB['scoringExplanation'] ?? '') !== '' ? (string) $stageB['scoringExplanation'] : demand_map_reason($cluster, $hasPage, count($cars), $riskFlags, $priority),
            'recommendedAction' => $recommendedAction,
            'linkedKeywordIds' => $keywordIds,
            'linkedCars' => array_keys($carsBySlug),
            'linkedDraftId' => (string) ($existingPlan['linkedDraftId'] ?? ''),
            'linkedContentBriefId' => (string) ($existingPlan['linkedContentBriefId'] ?? ''),
            'requiredWork' => demand_map_build_required_work($planType, $hasPage, $riskFlags, $cars),
            'riskFlags' => $riskFlags,
            'launchStatus' => $launchStatus,
            'createdAt' => (string) ($existingPlan['createdAt'] ?? $now),
            'updatedAt' => $now,
        ]);
        $plans[] = $plan;
        if (!$existingPlan) {
            $createdPlans++;
            analytics_record_event('seo_launch_plan_created', [
                'scopeId' => $scopeId,
                'entityType' => 'seo_launch_plan',
                'entityId' => $planId,
            ]);
        }
    }

    $preserveClusters = array_values(array_filter(demand_map_read_clusters()['items'], static function ($item) use ($scopeIds): bool {
        return is_array($item) && !in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopeIds, true);
    }));
    $preservePlans = array_values(array_filter(demand_map_read_launch_plan()['items'], static function ($item) use ($scopeIds): bool {
        return is_array($item) && !in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopeIds, true);
    }));

    $clusterStore = demand_map_read_clusters();
    $clusterStore['items'] = array_merge($preserveClusters, $clusters);
    demand_map_save_clusters($clusterStore);
    $planStore = demand_map_read_launch_plan();
    $planStore['items'] = array_merge($preservePlans, $plans);
    demand_map_save_launch_plan($planStore);
    demand_map_upsert_recommendations_for_plans($plans);

    analytics_record_event('demand_map_recalculated', [
        'scopeId' => current_user_is_platform_admin() ? 'rent_rk' : (demand_current_scope_filter($scopeFilter)[0] ?? 'rent_rk'),
        'entityType' => 'demand_map',
        'entityId' => 'stage3_3',
        'meta' => [
            'clusters' => count($clusters),
            'plans' => count($plans),
            'scopeFilter' => $scopeFilter,
        ],
    ]);

    return [
        'clusters' => count($clusters),
        'plans' => count($plans),
        'createdClusters' => $createdClusters,
        'updatedClusters' => $updatedClusters,
        'createdPlans' => $createdPlans,
    ];
}

function demand_map_recommendation_type_for_plan(array $plan): string
{
    if ((string) ($plan['recommendedAction'] ?? '') === 'ignore_as_irrelevant' || in_array('not_relevant_for_car_rental', (array) ($plan['riskFlags'] ?? []), true)) {
        return 'ignore_as_irrelevant';
    }
    if (in_array('possible_false_promise', (array) ($plan['riskFlags'] ?? []), true)) {
        return 'block_false_promise_page';
    }

    return match ((string) ($plan['recommendedAction'] ?? '')) {
        'create_city_landing_draft' => 'create_city_landing_draft',
        'create_landing_draft' => (string) ($plan['planType'] ?? '') === 'landing_page' ? 'create_class_landing_draft' : 'create_launch_plan_item',
        'create_card_optimization_hint' => 'create_card_optimization_hint',
        'create_condition_explanation' => 'create_condition_explanation',
        'add_faq' => 'add_faq',
        'improve_existing_page' => 'update_existing_page',
        'postpone_until_supply_exists' => 'postpone_until_supply_exists',
        'needs_business_decision' => 'needs_business_decision',
        'need_human_review' => 'need_human_review',
        'do_not_create_page' => 'do_not_create_page',
        'ignore_as_irrelevant' => 'ignore_as_irrelevant',
        default => 'create_launch_plan_item',
    };
}

function demand_map_upsert_recommendations_for_plans(array $plans): void
{
    if (!$plans) {
        return;
    }

    $data = read_demand_recommendations();
    $existingByKey = [];
    foreach ((array) ($data['items'] ?? []) as $index => $item) {
        if (!is_array($item)) {
            continue;
        }
        $planId = (string) ($item['launchPlanId'] ?? '');
        if ($planId !== '') {
            $existingByKey[$planId . '|' . (string) ($item['recommendationType'] ?? '')] = [$index, $item];
        }
    }

    foreach ($plans as $plan) {
        $planKeywordIds = (array) ($plan['linkedKeywordIds'] ?? []);
        $keywordId = (string) ($planKeywordIds[0] ?? '');
        if ($keywordId === '') {
            continue;
        }
        $type = demand_map_recommendation_type_for_plan($plan);
        $key = (string) ($plan['id'] ?? '') . '|' . $type;
        $existing = $existingByKey[$key][1] ?? [];
        $recommendation = [
            'id' => (string) ($existing['id'] ?? ('dr_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)))),
            'scope_id' => demand_normalize_scope_id((string) ($plan['scope_id'] ?? 'rent_rk')),
            'keywordId' => $keywordId,
            'launchPlanId' => (string) ($plan['id'] ?? ''),
            'recommendationType' => $type,
            'priority' => (string) ($plan['priority'] ?? 'medium'),
            'confidence' => 0.78,
            'reason' => (string) ($plan['reason'] ?? ''),
            'linkedCars' => array_values((array) ($plan['linkedCars'] ?? [])),
            'linkedPages' => [],
            'riskFlags' => demand_unique_strings((array) ($plan['riskFlags'] ?? [])),
            'demandVolumeScore' => (int) ($plan['demandVolumeScore'] ?? 0),
            'commercialScore' => (int) ($plan['commercialScore'] ?? 0),
            'supplyFitScore' => (int) ($plan['supplyFitScore'] ?? 0),
            'pageFitScore' => (int) ($plan['pageFitScore'] ?? 0),
            'contentGapScore' => (int) ($plan['contentGapScore'] ?? 0),
            'riskScore' => (int) ($plan['riskScore'] ?? 0),
            'regionFitScore' => (int) ($plan['regionFitScore'] ?? 0),
            'seasonalityScore' => (int) ($plan['seasonalityScore'] ?? 0),
            'decisionScore' => (int) ($plan['decisionScore'] ?? $plan['priorityScore'] ?? 0),
            'priorityLevel' => (string) ($plan['priorityLevel'] ?? $plan['priority'] ?? 'medium'),
            'recommendedDecision' => (string) ($plan['recommendedDecision'] ?? ''),
            'scoringExplanation' => (string) ($plan['scoringExplanation'] ?? $plan['reason'] ?? ''),
            'contentGapSummary' => (string) ($plan['contentGapSummary'] ?? ''),
            'pageFitStatus' => (string) ($plan['pageFitStatus'] ?? ''),
            'supplyFitSummary' => (string) ($plan['supplyFitSummary'] ?? ''),
            'pageRiskProfile' => is_array($plan['pageRiskProfile'] ?? null) ? $plan['pageRiskProfile'] : [],
            'whatBlocks' => array_values((array) ($plan['whatBlocks'] ?? [])),
            'userQuestionMap' => array_values((array) ($plan['userQuestionMap'] ?? [])),
            'safeContentBlocks' => array_values((array) ($plan['safeContentBlocks'] ?? [])),
            'contentGapReport' => is_array($plan['contentGapReport'] ?? null) ? $plan['contentGapReport'] : [],
            'firstScreenAnswer' => (string) ($plan['firstScreenAnswer'] ?? ''),
            'mustAnswer' => array_values((array) ($plan['mustAnswer'] ?? [])),
            'mustNotPromise' => array_values((array) ($plan['mustNotPromise'] ?? [])),
            'recommendedFaq' => array_values((array) ($plan['recommendedFaq'] ?? [])),
            'recommendedInternalLinks' => array_values((array) ($plan['recommendedInternalLinks'] ?? [])),
            'recommendedCarCardHints' => array_values((array) ($plan['recommendedCarCardHints'] ?? [])),
            'userClarityScore' => is_array($plan['userClarityScore'] ?? null) ? $plan['userClarityScore'] : [],
            'aiSearchReadiness' => is_array($plan['aiSearchReadiness'] ?? null) ? $plan['aiSearchReadiness'] : [],
            'actionStatus' => (string) ($existing['actionStatus'] ?? 'new'),
            'createdAt' => (string) ($existing['createdAt'] ?? now_iso()),
            'updatedAt' => now_iso(),
        ];

        if (isset($existingByKey[$key])) {
            $data['items'][(int) $existingByKey[$key][0]] = $recommendation;
        } else {
            $data['items'][] = $recommendation;
            analytics_record_event('demand_recommendation_created', [
                'scopeId' => (string) $recommendation['scope_id'],
                'entityType' => 'demand_recommendation',
                'entityId' => (string) $recommendation['id'],
                'meta' => ['type' => $type, 'launchPlanId' => (string) ($plan['id'] ?? '')],
            ]);
        }
    }

    save_demand_recommendations($data);
}

function demand_map_find_cluster(string $clusterId): ?array
{
    foreach (demand_map_read_clusters()['items'] as $cluster) {
        if (is_array($cluster) && (string) ($cluster['id'] ?? '') === $clusterId) {
            return $cluster;
        }
    }

    return null;
}

function demand_map_find_plan(string $planId): ?array
{
    foreach (demand_map_read_launch_plan()['items'] as $plan) {
        if (is_array($plan) && (string) ($plan['id'] ?? '') === $planId) {
            return $plan;
        }
    }

    return null;
}

function demand_map_update_plan_item(array $plan): array
{
    $planId = (string) ($plan['id'] ?? '');
    $data = demand_map_read_launch_plan();
    foreach ($data['items'] as $index => $item) {
        if (is_array($item) && (string) ($item['id'] ?? '') === $planId) {
            $plan['updatedAt'] = now_iso();
            $data['items'][$index] = $plan;
            demand_map_save_launch_plan($data);
            analytics_record_event('seo_launch_plan_item_updated', [
                'scopeId' => (string) ($plan['scope_id'] ?? 'rent_rk'),
                'entityType' => 'seo_launch_plan',
                'entityId' => $planId,
                'meta' => ['launchStatus' => (string) ($plan['launchStatus'] ?? '')],
            ]);

            return $plan;
        }
    }

    throw new RuntimeException('Пункт SEO-плана не найден.');
}

function demand_map_update_plan_status(string $planId, string $status): array
{
    $allowed = ['planned', 'draft_created', 'in_review', 'ready_noindex', 'ready_for_future_index', 'postponed', 'blocked', 'done', 'archived'];
    if (!in_array($status, $allowed, true)) {
        throw new RuntimeException('Некорректный статус SEO-плана.');
    }
    $plan = demand_map_find_plan($planId);
    if (!$plan) {
        throw new RuntimeException('Пункт SEO-плана не найден.');
    }
    demand_scope_guard($plan, 'demand.launch_plan.manage');
    $plan['launchStatus'] = $status;
    $updated = demand_map_update_plan_item($plan);
    if ($status === 'blocked') {
        analytics_record_event('launch_plan_item_blocked', [
            'scopeId' => (string) ($updated['scope_id'] ?? 'rent_rk'),
            'entityType' => 'seo_launch_plan',
            'entityId' => $planId,
        ]);
    } elseif ($status === 'postponed') {
        analytics_record_event('launch_plan_item_postponed', [
            'scopeId' => (string) ($updated['scope_id'] ?? 'rent_rk'),
            'entityType' => 'seo_launch_plan',
            'entityId' => $planId,
        ]);
    }

    return $updated;
}

function demand_map_brief_questions(array $cluster, array $plan): array
{
    $questions = [
        'Какие документы нужны для аренды?',
        'От чего зависит залог?',
        'Можно ли получить автомобиль в нужном городе?',
        'Как выбрать подходящий автомобиль?',
    ];
    if ((string) ($cluster['clusterType'] ?? '') === 'car_class') {
        $questions[] = 'Подойдет ли этот класс авто для семьи или компании?';
        $questions[] = 'Есть ли место для багажа?';
    }
    if ((string) ($cluster['clusterType'] ?? '') === 'airport') {
        $questions[] = 'Можно ли согласовать подачу в аэропорт Симферополя?';
    }
    if (in_array('possible_false_promise', (array) ($plan['riskFlags'] ?? []), true)) {
        $questions[] = 'Почему условия залога нужно подтверждать до публикации?';
    }

    return array_values(array_unique($questions));
}

function demand_map_create_content_brief(string $planId): array
{
    $plan = demand_map_find_plan($planId);
    if (!$plan) {
        throw new RuntimeException('Пункт SEO-плана не найден.');
    }
    demand_scope_guard($plan, 'demand.content_briefs.manage');
    $cluster = demand_map_find_cluster((string) ($plan['clusterId'] ?? ''));
    if (!$cluster) {
        throw new RuntimeException('Кластер спроса не найден.');
    }

    foreach (demand_map_read_content_briefs()['items'] as $existing) {
        if (is_array($existing) && (string) ($existing['launchPlanId'] ?? '') === $planId) {
            return $existing;
        }
    }

    $keywordIds = (array) ($plan['linkedKeywordIds'] ?? $cluster['keywordIds'] ?? []);
    $keyword = null;
    foreach ($keywordIds as $keywordId) {
        $keyword = demand_find_keyword((string) $keywordId);
        if ($keyword) {
            break;
        }
    }
    if (!$keyword) {
        $keyword = [
            'id' => '',
            'scope_id' => (string) ($plan['scope_id'] ?? 'rent_rk'),
            'phrase' => (string) ($cluster['primaryPhrase'] ?? $plan['title'] ?? ''),
            'normalizedPhrase' => demand_normalize_phrase((string) ($cluster['primaryPhrase'] ?? $plan['title'] ?? '')),
            'intent' => (string) ($cluster['intent'] ?? 'unknown'),
            'riskFlags' => (array) ($plan['riskFlags'] ?? []),
        ];
    }
    $cars = array_values(array_filter(array_map(static fn(string $slug): ?array => find_car($slug), array_values((array) ($plan['linkedCars'] ?? [])))));
    $stageC = is_array($plan['safeContentBlocks'] ?? null) && $plan['safeContentBlocks']
        ? [
            'userQuestionMap' => (array) ($plan['userQuestionMap'] ?? []),
            'safeContentBlocks' => (array) ($plan['safeContentBlocks'] ?? []),
            'contentGapReport' => (array) ($plan['contentGapReport'] ?? []),
            'firstScreenAnswer' => (string) ($plan['firstScreenAnswer'] ?? ''),
            'mustAnswer' => (array) ($plan['mustAnswer'] ?? []),
            'mustNotPromise' => (array) ($plan['mustNotPromise'] ?? []),
            'recommendedFaq' => (array) ($plan['recommendedFaq'] ?? []),
            'recommendedInternalLinks' => (array) ($plan['recommendedInternalLinks'] ?? []),
            'recommendedCarCardHints' => (array) ($plan['recommendedCarCardHints'] ?? []),
            'userClarityScore' => (array) ($plan['userClarityScore'] ?? []),
            'aiSearchReadiness' => (array) ($plan['aiSearchReadiness'] ?? []),
        ]
        : demand_stage_c_analyze_keyword($keyword, [
            'cars' => $cars,
            'stageB' => [
                'riskFlags' => (array) ($plan['riskFlags'] ?? []),
                'pageRiskProfile' => (array) ($plan['pageRiskProfile'] ?? []),
                'priorityLevel' => (string) ($plan['priorityLevel'] ?? $plan['priority'] ?? ''),
                'contentGapSummary' => (string) ($plan['contentGapSummary'] ?? ''),
            ],
        ]);
    $recommendedBlockTypes = array_values(array_filter(array_map(static fn(array $block): string => (string) ($block['type'] ?? ''), (array) ($stageC['safeContentBlocks'] ?? []))));
    $faqQuestions = array_values(array_filter(array_map(static fn(array $faq): string => (string) ($faq['question'] ?? ''), (array) ($stageC['recommendedFaq'] ?? []))));

    $brief = [
        'id' => 'dcb_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'scope_id' => demand_normalize_scope_id((string) ($plan['scope_id'] ?? 'rent_rk')),
        'clusterId' => (string) ($cluster['id'] ?? ''),
        'launchPlanId' => $planId,
        'title' => 'Бриф: ' . (string) ($plan['title'] ?? $cluster['name'] ?? ''),
        'targetIntent' => 'Пользователь ищет реальный вариант аренды по теме "' . (string) ($cluster['primaryPhrase'] ?? $cluster['name'] ?? '') . '" и должен получить честный ответ без неподтвержденных обещаний.',
        'mustAnswer' => (array) ($stageC['mustAnswer'] ?? []) ?: [
            'Какие автомобили подходят',
            'Какая цена или где она проверяется',
            'Какой залог и от чего он зависит',
            'Можно ли согласовать подачу',
            'Какие документы нужны',
        ],
        'mustNotPromise' => (array) ($stageC['mustNotPromise'] ?? []) ?: [
            'аренда без залога, если условия не подтверждены',
            'самая низкая цена без подтверждения',
            'наличие конкретного автомобиля без проверки доступности',
        ],
        'recommendedBlocks' => $recommendedBlockTypes ?: [
            'intro_answer',
            'who_is_it_for',
            'available_cars',
            'conditions',
            'faq',
            'internal_links',
        ],
        'faqQuestions' => $faqQuestions ?: demand_map_brief_questions($cluster, $plan),
        'userQuestionMap' => (array) ($stageC['userQuestionMap'] ?? []),
        'safeContentBlocks' => (array) ($stageC['safeContentBlocks'] ?? []),
        'contentGapReport' => (array) ($stageC['contentGapReport'] ?? []),
        'firstScreenAnswer' => (string) ($stageC['firstScreenAnswer'] ?? ''),
        'recommendedFaq' => (array) ($stageC['recommendedFaq'] ?? []),
        'recommendedInternalLinks' => (array) ($stageC['recommendedInternalLinks'] ?? []),
        'recommendedCarCardHints' => (array) ($stageC['recommendedCarCardHints'] ?? []),
        'pageRiskProfile' => (array) ($plan['pageRiskProfile'] ?? []),
        'userClarityGoals' => (array) ($stageC['userClarityScore'] ?? []),
        'aiSearchReadinessGoals' => (array) ($stageC['aiSearchReadiness'] ?? []),
        'linkedCars' => array_values((array) ($plan['linkedCars'] ?? [])),
        'status' => 'draft',
        'createdAt' => now_iso(),
        'updatedAt' => now_iso(),
    ];
    $data = demand_map_read_content_briefs();
    array_unshift($data['items'], $brief);
    demand_map_save_content_briefs($data);
    $plan['linkedContentBriefId'] = (string) $brief['id'];
    demand_map_update_plan_item($plan);
    analytics_record_event('content_brief_created', [
        'scopeId' => (string) $brief['scope_id'],
        'entityType' => 'demand_content_brief',
        'entityId' => (string) $brief['id'],
        'meta' => ['launchPlanId' => $planId],
    ]);

    return $brief;
}

function demand_map_hint_payload(array $plan, string $carSlug): array
{
    $cluster = demand_map_find_cluster((string) ($plan['clusterId'] ?? '')) ?? [];
    $type = (string) ($cluster['clusterType'] ?? '');
    $phrase = (string) ($cluster['primaryPhrase'] ?? $plan['title'] ?? '');
    $hintType = match ($type) {
        'car_class' => 'add_body_type_info',
        'family' => 'add_family_context',
        'airport', 'city', 'region' => 'add_delivery_info',
        'price' => 'add_economy_context',
        'condition' => 'add_deposit_info',
        default => 'needs_human_review',
    };
    if (in_array('possible_false_promise', (array) ($plan['riskFlags'] ?? []), true)) {
        $hintType = 'avoid_false_promise';
    }

    foreach ((array) ($plan['recommendedCarCardHints'] ?? []) as $stageHint) {
        if (!is_array($stageHint) || normalize_car_slug((string) ($stageHint['carSlug'] ?? '')) !== normalize_car_slug($carSlug)) {
            continue;
        }
        $hintItems = array_values(array_filter(array_map('strval', (array) ($stageHint['hints'] ?? []))));
        if ($hintItems) {
            return [
                $hintType,
                'В спросе есть связанная тема "' . $phrase . '". Карточку нужно доработать только безопасными подтверждёнными фактами.',
                implode('; ', array_slice($hintItems, 0, 4)) . '.',
            ];
        }
    }

    $message = 'В спросе есть связанная тема "' . $phrase . '", но карточку авто стоит проверить на понятные формулировки под этот сценарий.';
    $suggested = 'Добавить короткий блок: кому подойдет автомобиль, какие условия нужно уточнить, есть ли подача, цена и залог.';
    if ($hintType === 'avoid_false_promise') {
        $message = 'Запрос содержит риск ложного обещания. Карточка не должна обещать аренду без залога, если это не подтверждено условиями.';
        $suggested = 'Безопасно объяснить размер залога, условия возврата и случаи, когда менеджер уточняет детали.';
    } elseif ($type === 'car_class') {
        $suggested = 'Подойдет для семьи или компании, когда важно ехать вместе и оставить место для багажа. Количество мест нужно сверить с данными авто.';
    } elseif ($type === 'price') {
        $suggested = 'Можно описать экономичные варианты без обещания самой низкой цены: итоговая стоимость зависит от дат, автомобиля и условий аренды.';
    }

    return [$hintType, $message, $suggested];
}

function demand_map_create_card_hints(string $planId): array
{
    $plan = demand_map_find_plan($planId);
    if (!$plan) {
        throw new RuntimeException('Пункт SEO-плана не найден.');
    }
    demand_scope_guard($plan, 'demand.card_hints.manage');

    $linkedCars = array_values(array_filter(array_map(static fn($value): string => normalize_car_slug((string) $value), (array) ($plan['linkedCars'] ?? []))));
    if (!$linkedCars) {
        throw new RuntimeException('Для пункта SEO-плана нет связанных авто.');
    }

    $data = demand_map_read_card_hints();
    $existingKeys = [];
    foreach ($data['items'] as $item) {
        if (is_array($item)) {
            $existingKeys[(string) ($item['carId'] ?? '') . '|' . (string) ($item['clusterId'] ?? '') . '|' . (string) ($item['hintType'] ?? '')] = true;
        }
    }

    $created = [];
    foreach ($linkedCars as $carSlug) {
        [$hintType, $message, $suggested] = demand_map_hint_payload($plan, $carSlug);
        $key = $carSlug . '|' . (string) ($plan['clusterId'] ?? '') . '|' . $hintType;
        if (isset($existingKeys[$key])) {
            continue;
        }
        $hint = [
            'id' => 'dcoh_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
            'scope_id' => demand_normalize_scope_id((string) ($plan['scope_id'] ?? 'rent_rk')),
            'carId' => $carSlug,
            'keywordIds' => array_values((array) ($plan['linkedKeywordIds'] ?? [])),
            'clusterId' => (string) ($plan['clusterId'] ?? ''),
            'launchPlanId' => $planId,
            'hintType' => $hintType,
            'priority' => (string) ($plan['priority'] ?? 'medium'),
            'message' => $message,
            'suggestedText' => $suggested,
            'status' => 'new',
            'createdAt' => now_iso(),
            'updatedAt' => now_iso(),
        ];
        array_unshift($data['items'], $hint);
        $created[] = $hint;
        analytics_record_event('card_optimization_hint_created', [
            'scopeId' => (string) $hint['scope_id'],
            'entityType' => 'demand_card_optimization_hint',
            'entityId' => (string) $hint['id'],
            'meta' => ['launchPlanId' => $planId, 'carId' => $carSlug],
        ]);
    }

    demand_map_save_card_hints($data);

    return $created;
}

function demand_map_slug_exists(string $slug): bool
{
    foreach (read_landing_page_drafts()['items'] as $draft) {
        if (!is_array($draft)) {
            continue;
        }
        if ((string) ($draft['slug'] ?? '') === $slug && !in_array((string) ($draft['publishStatus'] ?? ''), ['archived', 'merged', 'rolled_back'], true)) {
            return true;
        }
    }

    foreach (demand_existing_pages() as $page) {
        if ((string) ($page['slug'] ?? '') === $slug) {
            return true;
        }
    }

    return false;
}

function demand_map_create_landing_draft_from_plan(string $planId): array
{
    $plan = demand_map_find_plan($planId);
    if (!$plan) {
        throw new RuntimeException('Пункт SEO-плана не найден.');
    }
    demand_scope_guard($plan, 'demand.drafts.create');

    $blockedFlags = array_intersect((array) ($plan['riskFlags'] ?? []), ['possible_false_promise', 'condition_not_supported', 'no_matching_cars', 'not_relevant_for_car_rental', 'unsupported_legal_request']);
    if ($blockedFlags) {
        throw new RuntimeException('Черновик из SEO-плана заблокирован риск-флагами: ' . implode(', ', $blockedFlags));
    }
    if (!in_array((string) ($plan['planType'] ?? ''), ['landing_page', 'city_page', 'category_page'], true)) {
        throw new RuntimeException('Для этого пункта безопаснее создать бриф или объясняющий блок, а не посадочную страницу.');
    }
    if ((string) ($plan['linkedDraftId'] ?? '') !== '') {
        $existing = demand_find_draft((string) $plan['linkedDraftId']);
        if ($existing) {
            return $existing;
        }
    }

    $planKeywordIds = (array) ($plan['linkedKeywordIds'] ?? []);
    $keywordId = (string) ($planKeywordIds[0] ?? '');
    $keyword = $keywordId !== '' ? demand_find_keyword($keywordId) : null;
    if (!$keyword) {
        throw new RuntimeException('Связанный ключевой запрос не найден.');
    }

    $slug = demand_landing_slug_for_keyword($keyword);
    if (demand_map_slug_exists($slug)) {
        throw new RuntimeException('Черновик с таким slug или похожий публичный маршрут уже существует.');
    }

    $linkedCars = array_values((array) ($plan['linkedCars'] ?? []));
    $cars = array_values(array_filter(array_map(static fn(string $slug): ?array => find_car($slug), $linkedCars)));
    $carNames = array_values(array_filter(array_map(static fn(array $car): string => (string) ($car['name'] ?? ''), $cars)));
    $h1 = demand_landing_h1_for_keyword($keyword);
    $stageC = is_array($plan['safeContentBlocks'] ?? null) && $plan['safeContentBlocks']
        ? [
            'userQuestionMap' => (array) ($plan['userQuestionMap'] ?? []),
            'safeContentBlocks' => (array) ($plan['safeContentBlocks'] ?? []),
            'contentGapReport' => (array) ($plan['contentGapReport'] ?? []),
            'firstScreenAnswer' => (string) ($plan['firstScreenAnswer'] ?? ''),
            'mustAnswer' => (array) ($plan['mustAnswer'] ?? []),
            'mustNotPromise' => (array) ($plan['mustNotPromise'] ?? []),
            'recommendedFaq' => (array) ($plan['recommendedFaq'] ?? []),
            'recommendedInternalLinks' => (array) ($plan['recommendedInternalLinks'] ?? []),
            'recommendedCarCardHints' => (array) ($plan['recommendedCarCardHints'] ?? []),
            'userClarityScore' => (array) ($plan['userClarityScore'] ?? []),
            'aiSearchReadiness' => (array) ($plan['aiSearchReadiness'] ?? []),
        ]
        : demand_stage_c_analyze_keyword($keyword, [
            'cars' => $cars,
            'stageB' => [
                'riskFlags' => (array) ($plan['riskFlags'] ?? []),
                'pageRiskProfile' => (array) ($plan['pageRiskProfile'] ?? []),
                'priorityLevel' => (string) ($plan['priorityLevel'] ?? $plan['priority'] ?? ''),
                'contentGapSummary' => (string) ($plan['contentGapSummary'] ?? ''),
            ],
        ]);
    $intro = trim((string) ($stageC['firstScreenAnswer'] ?? '')) !== ''
        ? (string) $stageC['firstScreenAnswer']
        : 'Черновик подготовлен из карты спроса по теме "' . (string) ($plan['title'] ?? '') . '". Он не опубликован, не добавлен в sitemap и должен пройти ручной workflow Rent RK.';
    $contentBlocks = demand_stage_c_content_blocks_for_draft($stageC, $cars);
    if (!$contentBlocks) {
        $contentBlocks = [
            [
                'type' => 'who_is_it_for',
                'title' => 'Кому подойдёт',
                'body' => 'Подойдёт пользователям, которые ищут реальную услугу Rent RK по этой теме. Формулировки нужно сверить с доступными автомобилями и условиями.',
            ],
            [
                'type' => 'available_cars',
                'title' => 'Какие авто подходят',
                'body' => $carNames ? 'Связанные авто: ' . implode(', ', $carNames) . '.' : 'Подходящие авто нужно подтвердить вручную перед публикацией.',
            ],
            [
                'type' => 'conditions',
                'title' => 'Что важно знать перед арендой',
                'body' => 'Документы, цена, залог, подача и срок аренды берутся из актуальных карточек авто и действующих правил. Нельзя обещать условия, которые не подтверждены данными.',
            ],
        ];
    }
    $draft = [
        'id' => 'lpd_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'scope_id' => demand_normalize_scope_id((string) ($plan['scope_id'] ?? 'rent_rk')),
        'sourceKeywordIds' => array_values((array) ($plan['linkedKeywordIds'] ?? [])),
        'slug' => $slug,
        'title' => $h1 . ' - Rent RK',
        'h1' => $h1,
        'metaDescription' => 'Черновик из SEO-плана запуска. Условия аренды, цена, залог и подача сверяются по реальным данным автомобилей и менеджером перед публикацией.',
        'intro' => $intro,
        'contentBlocks' => $contentBlocks,
        'linkedCars' => $linkedCars,
        'linkedRecommendations' => [],
        'linkedLaunchPlanId' => $planId,
        'linkedClusterId' => (string) ($plan['clusterId'] ?? ''),
        'userQuestionMap' => (array) ($stageC['userQuestionMap'] ?? []),
        'safeContentBlocks' => (array) ($stageC['safeContentBlocks'] ?? []),
        'contentGapReport' => (array) ($stageC['contentGapReport'] ?? []),
        'mustAnswer' => (array) ($stageC['mustAnswer'] ?? []),
        'mustNotPromise' => (array) ($stageC['mustNotPromise'] ?? []),
        'recommendedFaq' => (array) ($stageC['recommendedFaq'] ?? []),
        'recommendedInternalLinks' => (array) ($stageC['recommendedInternalLinks'] ?? []),
        'recommendedCarCardHints' => (array) ($stageC['recommendedCarCardHints'] ?? []),
        'userClarityScore' => (array) ($stageC['userClarityScore'] ?? []),
        'aiSearchReadiness' => (array) ($stageC['aiSearchReadiness'] ?? []),
        'adminNote' => 'Stage C: проверить вопросы пользователя, блоки, цену, залог, подачу и запреты перед публикацией. Нельзя обещать: ' . implode('; ', array_slice((array) ($stageC['mustNotPromise'] ?? []), 0, 4)),
        'publishStatus' => 'draft',
        'indexStatus' => 'blocked',
        'qualityStatus' => demand_draft_quality_status(['linkedCars' => $linkedCars], (array) ($plan['riskFlags'] ?? [])),
        'riskFlags' => demand_unique_strings((array) ($plan['riskFlags'] ?? [])),
        'createdBy' => current_admin_user() ?: 'system',
        'reviewedBy' => null,
        'createdAt' => now_iso(),
        'updatedAt' => now_iso(),
    ];

    $data = read_landing_page_drafts();
    array_unshift($data['items'], $draft);
    save_landing_page_drafts($data);

    $plan['linkedDraftId'] = (string) $draft['id'];
    $plan['launchStatus'] = 'draft_created';
    demand_map_update_plan_item($plan);

    demand_append_lifecycle_event(
        (string) $draft['scope_id'],
        'landing_page_draft',
        (string) $draft['id'],
        'landing_draft_created_from_launch_plan',
        'Черновик посадочной страницы создан из SEO-плана запуска. Публикация и индексация не включались.',
        current_admin_user() ?: 'system',
        ['launchPlanId' => $planId, 'clusterId' => (string) ($plan['clusterId'] ?? '')]
    );
    analytics_record_event('launch_plan_draft_created', [
        'scopeId' => (string) $draft['scope_id'],
        'entityType' => 'landing_page_draft',
        'entityId' => (string) $draft['id'],
        'meta' => ['launchPlanId' => $planId],
    ]);
    analytics_record_event('landing_page_draft_created', [
        'scopeId' => (string) $draft['scope_id'],
        'entityType' => 'landing_page_draft',
        'entityId' => (string) $draft['id'],
        'meta' => ['source' => 'seo_launch_plan', 'launchPlanId' => $planId],
    ]);

    return $draft;
}

function demand_map_stats(array $clusters, array $plans, array $hints): array
{
    return [
        'clusters' => count($clusters),
        'high' => count(array_filter($clusters, static fn(array $item): bool => (string) ($item['priority'] ?? '') === 'high')),
        'medium' => count(array_filter($clusters, static fn(array $item): bool => (string) ($item['priority'] ?? '') === 'medium')),
        'blocked' => count(array_filter($clusters, static fn(array $item): bool => in_array((string) ($item['priority'] ?? ''), ['blocked', 'needs_business_decision'], true))),
        'demandNoSupply' => count(array_filter($clusters, static fn(array $item): bool => in_array('no_matching_cars', (array) ($item['riskFlags'] ?? []), true))),
        'supplyNoPage' => count(array_filter($clusters, static fn(array $item): bool => !empty($item['linkedCars']) && empty($item['hasExistingPage']))),
        'cardHints' => count($hints),
        'readyForDraft' => count(array_filter($plans, static fn(array $item): bool => in_array((string) ($item['recommendedAction'] ?? ''), ['create_landing_draft', 'create_city_landing_draft'], true) && !array_intersect((array) ($item['riskFlags'] ?? []), ['possible_false_promise', 'condition_not_supported', 'no_matching_cars', 'region_not_confirmed', 'unknown_region', 'not_relevant_for_car_rental', 'unsupported_legal_request']))),
        'lastRecalculatedAt' => (string) (demand_map_read_clusters()['updatedAt'] ?? ''),
    ];
}

function demand_map_export_rows(array $plans): array
{
    $clustersById = [];
    foreach (demand_map_read_clusters()['items'] as $cluster) {
        if (is_array($cluster)) {
            $clustersById[(string) ($cluster['id'] ?? '')] = $cluster;
        }
    }

    $rows = [];
    foreach ($plans as $plan) {
        $cluster = $clustersById[(string) ($plan['clusterId'] ?? '')] ?? [];
        $rows[] = [
            'cluster' => (string) ($cluster['name'] ?? $plan['title'] ?? ''),
            'priority' => (string) ($plan['priority'] ?? ''),
            'action' => (string) ($plan['recommendedAction'] ?? ''),
            'reason' => (string) ($plan['reason'] ?? ''),
            'risk' => implode(', ', (array) ($plan['riskFlags'] ?? [])),
            'linkedCars' => implode(', ', (array) ($plan['linkedCars'] ?? [])),
            'status' => (string) ($plan['launchStatus'] ?? ''),
        ];
    }

    return $rows;
}
