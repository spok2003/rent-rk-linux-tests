<?php

declare(strict_types=1);

function site_maintenance_default_content(): array
{
    return [
        'schemaVersion' => 1,
        'title' => 'Обновляем систему',
        'message' => 'Сайт временно недоступен из-за технических работ. Уже скоро всё снова будет работать. Пожалуйста, повторите попытку немного позже.',
        'statusText' => 'Данные сохранены, идёт плановое обновление',
        'updatedAt' => null,
        'updatedBy' => null,
    ];
}

function site_maintenance_paths(?string $projectRoot = null, ?string $dataRoot = null): array
{
    if ($projectRoot === null && in_array(PHP_SAPI, ['cli', 'cli-server'], true) && getenv('RENT_RK_ALLOW_SITE_MAINTENANCE_TEST_ROOT') === '1') {
        $candidate = realpath(trim((string) getenv('RENT_RK_SITE_MAINTENANCE_TEST_ROOT')));
        $base = realpath(PROJECT_ROOT . 'tmp');
        if ($candidate !== false && $base !== false) {
            $candidatePath = rtrim(str_replace('\\', '/', $candidate), '/') . '/';
            $basePath = rtrim(str_replace('\\', '/', $base), '/') . '/';
            if (str_starts_with($candidatePath, $basePath)) {
                $projectRoot = $candidate;
            }
        }
    }
    $root = realpath($projectRoot ?? PROJECT_ROOT);
    $data = realpath($dataRoot ?? DATA_DIR);
    if ($root === false || !is_dir($root) || $data === false || !is_dir($data)) {
        throw new RuntimeException('Не удалось определить каталоги режима обслуживания.');
    }

    $root = rtrim($root, DIRECTORY_SEPARATOR);
    $data = rtrim($data, DIRECTORY_SEPARATOR);

    return [
        'root' => $root,
        'dataRoot' => $data,
        'page' => $root . DIRECTORY_SEPARATOR . 'maintenance-rr-20260912.html',
        'flag' => $root . DIRECTORY_SEPARATOR . '.partner-commission-maintenance-20260912',
        'htaccess' => $root . DIRECTORY_SEPARATOR . '.htaccess',
        'lock' => $data . DIRECTORY_SEPARATOR . 'site-maintenance-control.lock',
    ];
}

function site_maintenance_htaccess_block(array $paths): string
{
    $flag = str_replace('\\', '/', (string) $paths['flag']);

    return "# BEGIN RENT RK ROOT MAINTENANCE\n"
        . "RewriteEngine On\n"
        . "RewriteCond " . $flag . " -f\n"
        . "RewriteRule ^abcp/public/auto_poll[.]php$ - [R=503,L]\n"
        . "RewriteCond " . $flag . " -f\n"
        . "RewriteRule ^(?!(?:maintenance-rr-20260912[.]html$|admin(?:/|$)|abcp(?:/|$)|power-station-selector(?:/|$)|sto-documents(?:/|$))).* - [R=503,L]\n"
        . "ErrorDocument 503 /maintenance-rr-20260912.html\n"
        . "<IfModule mod_headers.c>\n"
        . "<Files \"maintenance-rr-20260912.html\">\n"
        . "Header always set Retry-After \"300\"\n"
        . "Header always set Cache-Control \"no-store, no-cache, must-revalidate, max-age=0\"\n"
        . "</Files>\n"
        . "</IfModule>\n"
        . "RewriteCond %{ENV:REDIRECT_STATUS} =503\n"
        . "RewriteRule ^maintenance-rr-20260912[.]html$ - [END]\n"
        . "# END RENT RK ROOT MAINTENANCE\n";
}

function site_maintenance_routing_ready(array $paths): bool
{
    if (!is_file($paths['htaccess']) || is_link($paths['htaccess'])) {
        return false;
    }
    $body = file_get_contents($paths['htaccess']);
    if (!is_string($body)) {
        return false;
    }

    return str_contains($body, '# BEGIN RENT RK ROOT MAINTENANCE')
        && str_contains($body, '# END RENT RK ROOT MAINTENANCE')
        && str_contains($body, str_replace('\\', '/', (string) $paths['flag']))
        && str_contains($body, 'ErrorDocument 503 /maintenance-rr-20260912.html')
        && str_contains($body, 'maintenance-rr-20260912[.]html$|admin(?:/|$)')
        && str_contains($body, 'Header always set Retry-After "300"')
        && str_contains($body, 'RewriteCond %{ENV:REDIRECT_STATUS} =503')
        && str_contains($body, 'Header always set Cache-Control "no-store, no-cache, must-revalidate, max-age=0"');
}

function site_maintenance_text_length(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
}

function site_maintenance_normalize_text(mixed $value): string
{
    $text = trim((string) $value);
    $text = preg_replace('/[\x{0000}-\x{0008}\x{000B}\x{000C}\x{000E}-\x{001F}\x{007F}]/u', '', $text) ?? $text;
    return preg_replace('/\s+/u', ' ', $text) ?? $text;
}

function site_maintenance_normalize_content(array $input, string $actor): array
{
    $title = site_maintenance_normalize_text($input['title'] ?? '');
    $message = site_maintenance_normalize_text($input['message'] ?? '');
    $statusText = site_maintenance_normalize_text($input['statusText'] ?? '');

    if ($title !== strip_tags($title) || site_maintenance_text_length($title) < 5 || site_maintenance_text_length($title) > 80) {
        throw new RuntimeException('Заголовок должен содержать от 5 до 80 символов и не должен содержать HTML.');
    }
    if ($message !== strip_tags($message) || site_maintenance_text_length($message) < 20 || site_maintenance_text_length($message) > 500) {
        throw new RuntimeException('Сообщение должно содержать от 20 до 500 символов и не должно содержать HTML.');
    }
    if ($statusText !== strip_tags($statusText) || site_maintenance_text_length($statusText) < 5 || site_maintenance_text_length($statusText) > 160) {
        throw new RuntimeException('Строка состояния должна содержать от 5 до 160 символов и не должна содержать HTML.');
    }

    return [
        'schemaVersion' => 1,
        'title' => $title,
        'message' => $message,
        'statusText' => $statusText,
        'updatedAt' => now_iso(),
        'updatedBy' => $actor,
    ];
}

function site_maintenance_read_content(array $paths): array
{
    if (!file_exists($paths['page'])) {
        return site_maintenance_default_content();
    }
    if (is_link($paths['page']) || !is_file($paths['page']) || !is_readable($paths['page'])) {
        throw new RuntimeException('Страница обслуживания недоступна.');
    }

    $raw = file_get_contents($paths['page']);
    if (!is_string($raw) || !preg_match('/<!-- RENT_RK_MAINTENANCE_CONFIG:([A-Za-z0-9+\/=]+) -->/', $raw, $match)) {
        return site_maintenance_default_content();
    }
    $json = base64_decode($match[1], true);
    $stored = is_string($json) ? json_decode($json, true) : null;
    if (!is_array($stored) || (int) ($stored['schemaVersion'] ?? 0) !== 1) {
        throw new RuntimeException('Настройки страницы обслуживания повреждены.');
    }

    return array_replace(site_maintenance_default_content(), $stored);
}

function site_maintenance_escape(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function site_maintenance_render_page(array $content): string
{
    $title = site_maintenance_escape((string) $content['title']);
    $message = site_maintenance_escape((string) $content['message']);
    $statusText = site_maintenance_escape((string) $content['statusText']);
    $serialized = base64_encode(json_encode($content, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));

    return <<<HTML
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <title>Rent RK - технические работы</title>
  <style>
    :root { color-scheme: light; font-family: Inter, Arial, sans-serif; }
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px; color: #14221f; background: #f4f7f6; }
    main { width: min(620px, 100%); padding: 40px; border: 1px solid #cfe0dc; border-radius: 8px; background: #fff; box-shadow: 0 18px 50px rgba(23, 55, 48, .10); }
    .brand { display: flex; align-items: center; gap: 12px; margin-bottom: 32px; }
    .mark { display: grid; width: 44px; height: 44px; place-items: center; border-radius: 8px; color: #fff; background: #078879; font-size: 22px; font-weight: 800; }
    .brand strong { display: block; font-size: 22px; }
    .brand small { color: #667a75; font-size: 12px; text-transform: uppercase; }
    h1 { margin: 0 0 14px; font-size: clamp(28px, 6vw, 42px); line-height: 1.08; }
    p { margin: 0; color: #536963; font-size: 17px; line-height: 1.55; }
    .status { display: inline-flex; align-items: center; gap: 9px; margin-top: 28px; padding-top: 22px; border-top: 1px solid #e1ebe8; color: #25675e; font-size: 14px; font-weight: 700; }
    .status::before { content: ""; width: 9px; height: 9px; border-radius: 50%; background: #e2a52b; }
    @media (max-width: 520px) { main { padding: 28px 22px; } }
  </style>
</head>
<body>
  <!-- RENT_RK_MAINTENANCE_CONFIG:{$serialized} -->
  <main data-rent-rk-maintenance-page="1">
    <div class="brand"><span class="mark">R</span><span><strong>Rent RK</strong><small>Аренда автомобилей</small></span></div>
    <h1>{$title}</h1>
    <p>{$message}</p>
    <div class="status">{$statusText}</div>
  </main>
</body>
</html>
HTML;
}

function site_maintenance_page_is_valid(array $paths): bool
{
    if (!is_file($paths['page']) || is_link($paths['page']) || filesize($paths['page']) > 65536) {
        return false;
    }
    $body = file_get_contents($paths['page']);
    return is_string($body)
        && str_contains($body, 'data-rent-rk-maintenance-page="1"')
        && str_contains($body, '<!-- RENT_RK_MAINTENANCE_CONFIG:')
        && !str_contains($body, '<?');
}

function site_maintenance_write_atomic(string $path, string $body, int $mode): void
{
    $dir = dirname($path);
    if (!is_dir($dir) || is_link($dir) || is_link($path)) {
        throw new RuntimeException('Небезопасный путь записи режима обслуживания.');
    }
    $temp = $path . '.tmp.' . bin2hex(random_bytes(6));
    $handle = fopen($temp, 'xb');
    if (!is_resource($handle)) {
        throw new RuntimeException('Не удалось создать временный файл режима обслуживания.');
    }
    $writeError = null;
    try {
        if (!chmod($temp, $mode)) {
            throw new RuntimeException('Не удалось установить права временного файла.');
        }
        for ($offset = 0, $length = strlen($body); $offset < $length;) {
            $written = fwrite($handle, substr($body, $offset));
            if (!is_int($written) || $written < 1) {
                throw new RuntimeException('Не удалось полностью записать временный файл.');
            }
            $offset += $written;
        }
        if (!fflush($handle) || (function_exists('fsync') && !fsync($handle))) {
            throw new RuntimeException('Не удалось синхронизировать временный файл.');
        }
    } catch (Throwable $error) {
        $writeError = $error;
    } finally {
        fclose($handle);
    }
    if ($writeError instanceof Throwable) {
        @unlink($temp);
        throw $writeError;
    }
    if (!rename($temp, $path)) {
        @unlink($temp);
        throw new RuntimeException('Не удалось атомарно заменить файл режима обслуживания.');
    }
}

function site_maintenance_snapshot(string $path): array
{
    if (is_link($path)) {
        throw new RuntimeException('Символьная ссылка в режиме обслуживания запрещена.');
    }
    if (!file_exists($path)) {
        return ['exists' => false, 'body' => null, 'mode' => null];
    }
    $body = file_get_contents($path);
    $perms = fileperms($path);
    if (!is_string($body) || !is_int($perms)) {
        throw new RuntimeException('Не удалось прочитать исходный файл режима обслуживания.');
    }
    return ['exists' => true, 'body' => $body, 'mode' => $perms & 0777];
}

function site_maintenance_restore_snapshot(string $path, array $snapshot, int $defaultMode): void
{
    if (!empty($snapshot['exists'])) {
        site_maintenance_write_atomic($path, (string) $snapshot['body'], (int) ($snapshot['mode'] ?? $defaultMode));
        return;
    }
    if (file_exists($path) && (is_link($path) || !unlink($path))) {
        throw new RuntimeException('Не удалось восстановить отсутствие файла режима обслуживания.');
    }
}

function site_maintenance_with_lock(array $paths, callable $callback): mixed
{
    if (is_link($paths['lock'])) {
        throw new RuntimeException('Символьная ссылка блокировки режима обслуживания запрещена.');
    }
    $lock = fopen($paths['lock'], 'c+b');
    if (!is_resource($lock)) {
        throw new RuntimeException('Не удалось открыть блокировку режима обслуживания.');
    }
    try {
        @chmod($paths['lock'], 0600);
        if (!flock($lock, LOCK_EX)) {
            throw new RuntimeException('Не удалось заблокировать параллельное изменение режима обслуживания.');
        }
        return $callback();
    } finally {
        @flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function site_maintenance_business_writes_paused(): bool
{
    if (!empty($GLOBALS['rent_rk_site_maintenance_write_bypass'])) {
        return false;
    }
    try {
        $paths = site_maintenance_paths();
    } catch (Throwable) {
        return false;
    }
    return is_file($paths['flag']) && !is_link($paths['flag']);
}

function site_maintenance_with_write_bypass(callable $callback): mixed
{
    $previous = $GLOBALS['rent_rk_site_maintenance_write_bypass'] ?? null;
    $GLOBALS['rent_rk_site_maintenance_write_bypass'] = true;
    try {
        return $callback();
    } finally {
        if ($previous === null) {
            unset($GLOBALS['rent_rk_site_maintenance_write_bypass']);
        } else {
            $GLOBALS['rent_rk_site_maintenance_write_bypass'] = $previous;
        }
    }
}

function site_maintenance_drain_business_writers(): void
{
    site_maintenance_with_write_bypass(static function (): void {
        RentalReturnStore::enter();
        RentalReturnStore::leave();
    });
}

function site_maintenance_save_content(array $paths, array $input, string $actor, callable $emitAudit): array
{
    return site_maintenance_with_lock($paths, static function () use ($paths, $input, $actor, $emitAudit): array {
        $content = site_maintenance_normalize_content($input, $actor);
        $page = site_maintenance_render_page($content);
        $pageBefore = site_maintenance_snapshot($paths['page']);
        try {
            site_maintenance_write_atomic($paths['page'], $page, 0644);
            if (!site_maintenance_page_is_valid($paths)) {
                throw new RuntimeException('Проверка созданной страницы обслуживания не пройдена.');
            }
            $emitAudit('site_maintenance.page.updated', [
                'title' => $content['title'],
                'pageSha256' => hash_file('sha256', $paths['page']),
            ]);
        } catch (Throwable $error) {
            site_maintenance_restore_snapshot($paths['page'], $pageBefore, 0644);
            throw $error;
        }
        return $content;
    });
}

function site_maintenance_set_active(array $paths, bool $active, callable $emitAudit): array
{
    return site_maintenance_with_lock($paths, static function () use ($paths, $active, $emitAudit): array {
        if ($active && !site_maintenance_routing_ready($paths)) {
            throw new RuntimeException('Маршрутизация режима обслуживания не установлена.');
        }
        if ($active && !site_maintenance_page_is_valid($paths)) {
            throw new RuntimeException('Страница обслуживания отсутствует или не прошла проверку.');
        }
        if (is_link($paths['flag'])) {
            throw new RuntimeException('Символьная ссылка флага режима обслуживания запрещена.');
        }
        $before = is_file($paths['flag']);
        if ($before === $active) {
            return ['active' => $active, 'changed' => false];
        }

        try {
            if ($active) {
                site_maintenance_write_atomic($paths['flag'], "enabled\n", 0600);
                site_maintenance_drain_business_writers();
            } elseif (!unlink($paths['flag'])) {
                throw new RuntimeException('Не удалось удалить флаг режима обслуживания.');
            }
            site_maintenance_with_write_bypass(static function () use ($emitAudit, $active, $paths): void {
                $emitAudit($active ? 'site_maintenance.enabled' : 'site_maintenance.disabled', [
                    'active' => $active,
                    'pageSha256' => is_file($paths['page']) ? hash_file('sha256', $paths['page']) : null,
                ]);
            });
        } catch (Throwable $error) {
            if ($before && !is_file($paths['flag'])) {
                site_maintenance_write_atomic($paths['flag'], "enabled\n", 0600);
            } elseif (!$before && is_file($paths['flag'])) {
                @unlink($paths['flag']);
            }
            throw $error;
        }

        return ['active' => $active, 'changed' => true];
    });
}

function site_maintenance_status(array $paths): array
{
    return [
        'active' => is_file($paths['flag']) && !is_link($paths['flag']),
        'pageExists' => is_file($paths['page']) && !is_link($paths['page']),
        'pageValid' => site_maintenance_page_is_valid($paths),
        'routingReady' => site_maintenance_routing_ready($paths),
        'content' => site_maintenance_read_content($paths),
    ];
}

function site_maintenance_enforce_admin_gate(array $user): void
{
    if (admin_user_is_platform_root($user)) {
        return;
    }

    $paths = site_maintenance_paths();
    if (!is_file($paths['flag']) || is_link($paths['flag'])) {
        return;
    }

    http_response_code(503);
    header('Retry-After: 300');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Content-Type: text/html; charset=UTF-8');

    if (site_maintenance_page_is_valid($paths)) {
        readfile($paths['page']);
    } else {
        echo site_maintenance_render_page(site_maintenance_default_content());
    }
    exit;
}
