<?php

declare(strict_types=1);

function analytics_event_type_definitions(): array
{
    return [
        'page_view' => ['public' => true],
        'car_view' => ['public' => true],
        'car_list_view' => ['public' => true],
        'filter_used' => ['public' => true],
        'car_gallery_view' => ['public' => true],
        'phone_click' => ['public' => true],
        'messenger_click' => ['public' => true],
        'callback_shown' => ['public' => true],
        'callback_submitted' => ['public' => true],
        'request_started' => ['public' => true],
        'request_submitted' => ['public' => true],
        'partner_page_view' => ['public' => true],
        'partner_lead_created' => ['public' => true],
        'rent_rk_fallback_form_shown' => ['public' => true],
        'landing_page_public_view' => ['public' => true],
        'landing_page_car_click' => ['public' => true],
        'landing_page_request_started' => ['public' => true],
        'landing_page_request_submitted' => ['public' => true],
        'landing_page_phone_click' => ['public' => true],
        'landing_page_messenger_click' => ['public' => true],
        'ai_referral_visit' => ['public' => true],
        'ai_referral_landing_view' => ['public' => true],
        'ai_referral_request_started' => ['public' => true],
        'ai_referral_request_submitted' => ['public' => true],
        'ai_referral_phone_click' => ['public' => true],
        'ai_referral_messenger_click' => ['public' => true],
        'request_created' => ['public' => false],
        'booking_created' => ['public' => false],
        'rental_created' => ['public' => false],
        'rental_return_fact_fixed' => ['public' => false],
        'rental_closed' => ['public' => false],
        'request_status_changed' => ['public' => false],
        'booking_status_changed' => ['public' => false],
        'rental_status_changed' => ['public' => false],
        'demand_keyword_imported' => ['public' => false],
        'demand_recommendation_created' => ['public' => false],
        'demand_recommendation_status_changed' => ['public' => false],
        'landing_page_draft_created' => ['public' => false],
        'landing_page_draft_updated' => ['public' => false],
        'landing_page_draft_archived' => ['public' => false],
        'landing_page_published_noindex' => ['public' => false],
        'landing_page_index_requested' => ['public' => false],
        'landing_page_published_indexed' => ['public' => false],
        'landing_page_closed_from_index' => ['public' => false],
        'landing_page_rollback_applied' => ['public' => false],
        'landing_page_archived' => ['public' => false],
        'landing_page_sitemap_added' => ['public' => false],
        'landing_page_sitemap_removed' => ['public' => false],
        'wordstat_connection_tested' => ['public' => false],
        'wordstat_regions_tree_loaded' => ['public' => false],
        'wordstat_dry_run_completed' => ['public' => false],
        'wordstat_live_sync_started' => ['public' => false],
        'wordstat_live_sync_completed' => ['public' => false],
        'wordstat_live_sync_failed' => ['public' => false],
        'wordstat_limit_blocked' => ['public' => false],
        'wordstat_keyword_created' => ['public' => false],
        'wordstat_keyword_updated' => ['public' => false],
        'wordstat_cost_recorded' => ['public' => false],
        'demand_map_recalculated' => ['public' => false],
        'demand_cluster_created' => ['public' => false],
        'demand_cluster_updated' => ['public' => false],
        'seo_launch_plan_created' => ['public' => false],
        'seo_launch_plan_item_updated' => ['public' => false],
        'content_brief_created' => ['public' => false],
        'card_optimization_hint_created' => ['public' => false],
        'launch_plan_draft_created' => ['public' => false],
        'launch_plan_item_blocked' => ['public' => false],
        'launch_plan_item_postponed' => ['public' => false],
        'readiness_checked' => ['public' => false],
        'published_to_noindex_preview' => ['public' => false],
        'opened_for_search' => ['public' => false],
        'closed_from_search' => ['public' => false],
        'admin_note_updated' => ['public' => false],
        'ai_package_generated' => ['public' => false],
        'ai_manual_response_previewed' => ['public' => false],
        'ai_manual_proposal_applied' => ['public' => false],
        'ai_manual_proposal_rejected' => ['public' => false],
        'ai_api_response_previewed' => ['public' => false],
        'ai_api_proposal_applied' => ['public' => false],
        'ai_api_proposal_rejected' => ['public' => false],
        'ai_generated_proposal_applied' => ['public' => false],
        'ai_generated_proposal_edited_and_applied' => ['public' => false],
        'demand_ai_dialog_seed_keywords_saved' => ['public' => false],
    ];
}

function analytics_public_event_types(): array
{
    return array_keys(array_filter(
        analytics_event_type_definitions(),
        static fn(array $definition): bool => !empty($definition['public'])
    ));
}

function analytics_default_events(): array
{
    return [
        'updatedAt' => null,
        'items' => [],
    ];
}

function analytics_default_settings(): array
{
    return [
        'updatedAt' => now_iso(),
        'updatedBy' => 'system',
        'collect_internal_events' => true,
        'collect_public_events' => true,
        'collect_partner_page_events' => true,
        'collect_fallback_events' => true,
        'external_scope_analytics_enabled' => true,
        'max_events' => 20000,
        'max_meta_bytes' => 2048,
        'page_view_dedupe_seconds' => 60,
    ];
}

function analytics_settings(): array
{
    $default = analytics_default_settings();
    $data = is_file(ANALYTICS_SETTINGS_FILE)
        ? read_json_file(ANALYTICS_SETTINGS_FILE, $default)
        : $default;

    foreach ([
        'collect_internal_events',
        'collect_public_events',
        'collect_partner_page_events',
        'collect_fallback_events',
        'external_scope_analytics_enabled',
    ] as $key) {
        $data[$key] = array_key_exists($key, $data) ? !empty($data[$key]) : $default[$key];
    }

    $data['max_events'] = max(1000, min(100000, (int) ($data['max_events'] ?? $default['max_events'])));
    $data['max_meta_bytes'] = max(256, min(8192, (int) ($data['max_meta_bytes'] ?? $default['max_meta_bytes'])));
    $data['page_view_dedupe_seconds'] = max(10, min(3600, (int) ($data['page_view_dedupe_seconds'] ?? $default['page_view_dedupe_seconds'])));
    $data['updatedAt'] = (string) ($data['updatedAt'] ?? '');
    $data['updatedBy'] = (string) ($data['updatedBy'] ?? '');

    return array_merge($default, $data);
}

function save_analytics_settings(array $payload): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => save_analytics_settings($payload));
    if (!current_user_is_platform_admin()) {
        deny_scope_access();
    }

    $current = analytics_settings();
    $next = $current;
    foreach ([
        'collect_internal_events',
        'collect_public_events',
        'collect_partner_page_events',
        'collect_fallback_events',
        'external_scope_analytics_enabled',
    ] as $key) {
        $next[$key] = !empty($payload[$key]);
    }
    $next['max_events'] = max(1000, min(100000, (int) ($payload['max_events'] ?? $current['max_events'])));
    $next['max_meta_bytes'] = max(256, min(8192, (int) ($payload['max_meta_bytes'] ?? $current['max_meta_bytes'])));
    $next['page_view_dedupe_seconds'] = max(10, min(3600, (int) ($payload['page_view_dedupe_seconds'] ?? $current['page_view_dedupe_seconds'])));
    $next['updatedAt'] = now_iso();
    $next['updatedBy'] = current_admin_user() ?: 'system';

    write_json_file(ANALYTICS_SETTINGS_FILE, $next);
    audit_log('analytics.settings.updated', 'analytics', 'settings', 'Изменены настройки внутренней аналитики', [
        'changes' => changed_fields($current, $next, [
            'collect_internal_events',
            'collect_public_events',
            'collect_partner_page_events',
            'collect_fallback_events',
            'external_scope_analytics_enabled',
            'max_events',
            'max_meta_bytes',
            'page_view_dedupe_seconds',
        ]),
    ]);

    return $next;
}

function read_analytics_events(): array
{
    $data = is_file(ANALYTICS_EVENTS_FILE)
        ? read_json_file(ANALYTICS_EVENTS_FILE, analytics_default_events())
        : analytics_default_events();
    $data['items'] = isset($data['items']) && is_array($data['items']) ? $data['items'] : [];

    return $data;
}

function analytics_clean_string($value, int $maxLength = 240): string
{
    $text = trim((string) $value);
    $text = preg_replace('/[\x00-\x1F\x7F]/u', '', $text) ?? '';
    if (function_exists('mb_substr')) {
        return mb_substr($text, 0, $maxLength, 'UTF-8');
    }

    return substr($text, 0, $maxLength);
}

function analytics_clean_id($value, int $maxLength = 100): string
{
    $id = analytics_clean_string($value, $maxLength);
    $id = preg_replace('/[^a-zA-Z0-9_.:@-]+/', '', $id) ?? '';
    return substr($id, 0, $maxLength);
}

function analytics_scope_id($value): string
{
    $scopeId = analytics_clean_id($value, 80);
    if ($scopeId === '') {
        return 'rent_rk';
    }

    return $scopeId === 'rent_rk' ? 'rent_rk' : normalize_lessor_slug($scopeId);
}

function analytics_allowed_page_types(): array
{
    return [
        'main_showcase',
        'car_list',
        'car_page',
        'partner_page',
        'landing_page',
        'route_page',
        'content_page',
        'contacts',
        'unknown',
    ];
}

function analytics_clean_url($value): string
{
    $url = analytics_clean_string($value, 1000);
    if ($url === '') {
        return '';
    }

    $parts = parse_url($url);
    if ($parts === false) {
        return '';
    }

    $query = [];
    if (isset($parts['query'])) {
        parse_str((string) $parts['query'], $query);
        foreach (array_keys($query) as $key) {
            if (analytics_is_sensitive_key((string) $key)) {
                unset($query[$key]);
            }
        }
    }

    $path = (string) ($parts['path'] ?? '');
    $rebuilt = '';
    if (isset($parts['scheme'], $parts['host'])) {
        $rebuilt .= $parts['scheme'] . '://' . $parts['host'];
        if (isset($parts['port'])) {
            $rebuilt .= ':' . $parts['port'];
        }
    }
    $rebuilt .= $path !== '' ? $path : '/';
    if ($query) {
        $rebuilt .= '?' . http_build_query($query);
    }
    if (isset($parts['fragment']) && !analytics_is_sensitive_key((string) $parts['fragment'])) {
        $rebuilt .= '#' . rawurlencode(analytics_clean_string((string) $parts['fragment'], 80));
    }

    return analytics_clean_string($rebuilt, 700);
}

function analytics_is_sensitive_key(string $key): bool
{
    return (bool) preg_match('/phone|tel|name|fio|email|mail|passport|address|driver|license|client|customer|comment|message|birth|card|bank|account|bik|inn|kpp|snils|token|password|secret/i', $key);
}

function analytics_string_looks_sensitive(string $value): bool
{
    $value = trim($value);
    if ($value === '') {
        return false;
    }

    return (bool) preg_match('/(?:\+?\d[\d\s().-]{8,}\d)|(?:[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})/i', $value);
}

function analytics_sanitize_meta($value, int $depth = 0)
{
    if ($depth > 3) {
        return null;
    }
    if (is_bool($value) || is_int($value) || is_float($value) || $value === null) {
        return $value;
    }
    if (is_string($value)) {
        return analytics_string_looks_sensitive($value) ? '' : analytics_clean_string($value, 240);
    }
    if (!is_array($value)) {
        return null;
    }

    $result = [];
    $count = 0;
    foreach ($value as $key => $item) {
        if ($count >= 30) {
            break;
        }
        $key = analytics_clean_string((string) $key, 80);
        if ($key === '' || analytics_is_sensitive_key($key)) {
            continue;
        }
        $clean = analytics_sanitize_meta($item, $depth + 1);
        if ($clean === null || $clean === '') {
            continue;
        }
        $result[$key] = $clean;
        $count++;
    }

    return $result;
}

function analytics_trim_meta_to_limit(array $meta, int $limit): array
{
    $json = json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json !== false && strlen($json) <= $limit) {
        return $meta;
    }

    $trimmed = [];
    foreach ($meta as $key => $value) {
        if (count($trimmed) >= 12) {
            break;
        }
        if (is_array($value)) {
            $trimmed[$key] = '[trimmed]';
        } elseif (is_string($value)) {
            $trimmed[$key] = analytics_clean_string($value, 80);
        } else {
            $trimmed[$key] = $value;
        }
    }
    $trimmed['_trimmed'] = true;

    return $trimmed;
}

function analytics_utm_from_url(string $url): array
{
    $query = (string) (parse_url($url, PHP_URL_QUERY) ?: '');
    parse_str($query, $params);

    return [
        'source' => analytics_clean_string($params['utm_source'] ?? '', 120),
        'medium' => analytics_clean_string($params['utm_medium'] ?? '', 120),
        'campaign' => analytics_clean_string($params['utm_campaign'] ?? '', 160),
        'content' => analytics_clean_string($params['utm_content'] ?? '', 160),
        'term' => analytics_clean_string($params['utm_term'] ?? '', 160),
    ];
}

function analytics_normalize_utm($utm, string $pageUrl = ''): array
{
    $fromUrl = analytics_utm_from_url($pageUrl);
    $utm = is_array($utm) ? $utm : [];
    $result = [];
    foreach (['source', 'medium', 'campaign', 'content', 'term'] as $key) {
        $value = $utm[$key] ?? $utm['utm_' . $key] ?? $fromUrl[$key] ?? '';
        $result[$key] = analytics_clean_string($value, $key === 'source' || $key === 'medium' ? 120 : 160);
    }

    return $result;
}

function analytics_client_payload($client): array
{
    $client = is_array($client) ? $client : [];
    $deviceType = (string) ($client['deviceType'] ?? $client['device_type'] ?? '');
    if (!in_array($deviceType, ['desktop', 'mobile', 'tablet', 'unknown'], true)) {
        $deviceType = function_exists('callback_device_type') ? callback_device_type() : 'unknown';
    }

    return [
        'visitorId' => analytics_clean_id($client['visitorId'] ?? $client['visitor_id'] ?? '', 100),
        'sessionId' => analytics_clean_id($client['sessionId'] ?? $client['session_id'] ?? '', 100),
        'deviceType' => $deviceType,
        'isBot' => array_key_exists('isBot', $client) ? !empty($client['isBot']) : analytics_request_is_bot(),
    ];
}

function analytics_request_is_bot(): bool
{
    $ua = strtolower((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
    if ($ua === '') {
        return false;
    }

    return (bool) preg_match('/bot|crawl|spider|slurp|curl|wget|python-requests|headless|preview/i', $ua);
}

function analytics_page_path_from_url(string $pageUrl): string
{
    $path = (string) (parse_url($pageUrl, PHP_URL_PATH) ?: '');
    if ($path === '' && isset($_SERVER['HTTP_REFERER'])) {
        $path = (string) (parse_url((string) $_SERVER['HTTP_REFERER'], PHP_URL_PATH) ?: '');
    }

    return '/' . ltrim($path, '/');
}

function analytics_partner_slug_from_payload(array $payload, string $pageUrl): string
{
    $partnerId = analytics_clean_id($payload['partnerId'] ?? $payload['partner_id'] ?? $payload['partner_slug'] ?? '', 80);
    if ($partnerId !== '') {
        return normalize_partner_item(['slug' => $partnerId, 'name' => 'x'])['slug'];
    }

    $query = (string) (parse_url($pageUrl, PHP_URL_QUERY) ?: '');
    parse_str($query, $params);
    foreach (['partner', 'partner_slug'] as $key) {
        $value = normalize_partner_item(['slug' => (string) ($params[$key] ?? ''), 'name' => 'x'])['slug'];
        if ($value !== '') {
            return $value;
        }
    }

    $path = analytics_page_path_from_url($pageUrl);
    if (preg_match('~^/partner/([^/?#]+)/?~i', $path, $matches)) {
        return normalize_partner_item(['slug' => (string) $matches[1], 'name' => 'x'])['slug'];
    }

    return '';
}

function analytics_car_slug_from_payload(array $payload, string $pageUrl): string
{
    $path = analytics_page_path_from_url($pageUrl);
    if ($path === '/cars' || $path === '/cars/' || $path === '/cars/index.html') {
        return '';
    }

    $carId = analytics_clean_id($payload['carId'] ?? $payload['car_id'] ?? $payload['car_slug'] ?? '', 100);
    if ($carId !== '') {
        if (preg_match('~^index(?:\.html)?$~i', $carId)) {
            return '';
        }
        return normalize_car_slug($carId);
    }

    if (preg_match('~/cars/([^/?#]+?)(?:\.html)?/?$~i', $path, $matches)) {
        if (preg_match('~^index(?:\.html)?$~i', (string) $matches[1])) {
            return '';
        }
        return normalize_car_slug((string) $matches[1]);
    }

    return '';
}

function analytics_page_type_from_payload(array $payload, string $pageUrl, string $carId, string $partnerId): string
{
    $path = analytics_page_path_from_url($pageUrl);
    if (preg_match('~^/partner/[^/]+/?~i', $path)) {
        return 'partner_page';
    }
    if ($path === '/cars' || $path === '/cars/' || $path === '/cars/index.html') {
        return 'car_list';
    }
    if ($path === '/' || $path === '/index.html') {
        return 'main_showcase';
    }

    $pageType = analytics_clean_id($payload['pageType'] ?? $payload['page_type'] ?? '', 80);
    if (in_array($pageType, analytics_allowed_page_types(), true)) {
        return $pageType;
    }

    if ($carId !== '') {
        return 'car_page';
    }
    if (str_starts_with($path, '/routes/')) {
        return 'route_page';
    }
    if (str_contains($path, 'contacts')) {
        return 'contacts';
    }

    return $partnerId !== '' ? 'partner_page' : 'content_page';
}

function analytics_public_context(string $eventType, array $payload): array
{
    $pageUrl = analytics_clean_url($payload['pageUrl'] ?? $payload['page_url'] ?? '');
    $path = analytics_page_path_from_url($pageUrl);
    if (preg_match('~^/(admin|api|private|data|tools)(/|$)~i', $path)) {
        throw new InvalidArgumentException('Analytics event is not allowed for this path.');
    }

    $carId = analytics_car_slug_from_payload($payload, $pageUrl);
    $partnerId = analytics_partner_slug_from_payload($payload, $pageUrl);
    $pageType = analytics_page_type_from_payload($payload, $pageUrl, $carId, $partnerId);
    $scopeId = 'rent_rk';
    $sourceScopeId = '';
    $entityType = analytics_clean_id($payload['entityType'] ?? $payload['entity_type'] ?? '', 60);
    $entityId = analytics_clean_id($payload['entityId'] ?? $payload['entity_id'] ?? '', 100);

    if ($partnerId !== '') {
        $partner = find_partner_by_slug($partnerId);
        if ($partner) {
            $scopeId = (string) ($partner['partner_owner_scope_id'] ?? 'rent_rk');
            if ($scopeId === '') {
                $scopeId = 'rent_rk';
            }
        }
    }

    if ($carId !== '') {
        $car = find_car($carId);
        if ($car) {
            $carScopeId = car_owner_scope_id($car);
            if ($eventType === 'rent_rk_fallback_form_shown') {
                $scopeId = 'rent_rk';
                $sourceScopeId = $carScopeId !== 'rent_rk' ? $carScopeId : '';
            } elseif ($partnerId === '' || $eventType !== 'partner_page_view') {
                $scopeId = $carScopeId;
            }
        }
    }

    if ($eventType === 'partner_page_view') {
        $pageType = 'partner_page';
        $entityType = 'partner';
        $entityId = $partnerId;
    }
    if ($eventType === 'car_view') {
        $entityType = 'car';
        $entityId = $carId;
    }
    if (str_starts_with($eventType, 'landing_page_')) {
        $pageType = 'landing_page';
        $entityType = $entityType !== '' ? $entityType : 'landing_page';
    }
    if (str_starts_with($eventType, 'ai_referral_') && str_contains($eventType, 'landing')) {
        $pageType = 'landing_page';
        $entityType = $entityType !== '' ? $entityType : 'landing_page';
    }

    return [
        'scopeId' => analytics_scope_id($scopeId),
        'sourceScopeId' => $sourceScopeId,
        'pageType' => $pageType,
        'pageUrl' => $pageUrl,
        'referrer' => analytics_clean_url($payload['referrer'] ?? ''),
        'entityType' => $entityType,
        'entityId' => $entityId,
        'carId' => $carId,
        'partnerId' => $partnerId,
    ];
}

function analytics_should_collect(string $eventType, array $event, string $source): bool
{
    $settings = analytics_settings();
    if (empty($settings['collect_internal_events'])) {
        return false;
    }
    if ($source === 'public' && empty($settings['collect_public_events'])) {
        return false;
    }
    if (
        (str_starts_with($eventType, 'partner_') || (string) ($event['pageType'] ?? '') === 'partner_page')
        && empty($settings['collect_partner_page_events'])
    ) {
        return false;
    }
    if ($eventType === 'rent_rk_fallback_form_shown' && empty($settings['collect_fallback_events'])) {
        return false;
    }

    return true;
}

function analytics_record_public_event(string $eventType, array $payload): array
{
    if (!in_array($eventType, analytics_public_event_types(), true)) {
        return ['ok' => false, 'error' => 'unsupported_event_type'];
    }

    $context = analytics_public_context($eventType, $payload);
    $safe = array_merge($payload, $context);
    unset($safe['scopeId'], $safe['scope_id']);
    $safe = array_merge($safe, $context);

    return analytics_record_event($eventType, $safe, ['source' => 'public']);
}

function analytics_record_event(string $eventType, array $payload = [], array $options = []): array
{
    try {
        if (!array_key_exists($eventType, analytics_event_type_definitions())) {
            return ['ok' => false, 'error' => 'unsupported_event_type'];
        }

        $source = (string) ($options['source'] ?? 'system');
        $pageUrl = analytics_clean_url($payload['pageUrl'] ?? $payload['page_url'] ?? '');
        $settings = analytics_settings();
        $meta = analytics_sanitize_meta($payload['meta'] ?? []);
        $meta = is_array($meta) ? analytics_trim_meta_to_limit($meta, (int) $settings['max_meta_bytes']) : [];

        $event = [
            'id' => 'event_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
            'createdAt' => now_iso(),
            'eventType' => $eventType,
            'scopeId' => analytics_scope_id($payload['scopeId'] ?? $payload['scope_id'] ?? 'rent_rk'),
            'utm' => analytics_normalize_utm($payload['utm'] ?? [], $pageUrl),
            'client' => analytics_client_payload($payload['client'] ?? []),
            'meta' => $meta,
        ];

        foreach ([
            'sourceScopeId',
            'pageType',
            'pageUrl',
            'referrer',
            'entityType',
            'entityId',
            'carId',
            'requestId',
            'bookingId',
            'rentalId',
            'partnerId',
            'lessorId',
        ] as $field) {
            $snake = strtolower((string) preg_replace('/(?<!^)[A-Z]/', '_$0', $field));
            $value = $payload[$field] ?? $payload[$snake] ?? '';
            if ($field === 'pageUrl' || $field === 'referrer') {
                $value = analytics_clean_url($value);
            } elseif ($field === 'pageType') {
                $value = analytics_clean_id($value, 80);
                if (!in_array($value, analytics_allowed_page_types(), true)) {
                    $value = '';
                }
            } else {
                $value = analytics_clean_id($value, 120);
            }
            if ($value !== '') {
                $event[$field] = $value;
            }
        }

        if (!analytics_should_collect($eventType, $event, $source)) {
            return ['ok' => true, 'skipped' => true, 'reason' => 'disabled'];
        }

        $result = analytics_append_event($event, (int) $settings['max_events']);
        return ['ok' => true, 'id' => $result['id']];
    } catch (Throwable $exception) {
        technical_log('analytics_record_failed', [
            'eventType' => $eventType,
            'reason' => $exception->getMessage(),
        ]);

        return ['ok' => false, 'error' => 'analytics_unavailable'];
    }
}

function analytics_append_event(array $event, int $maxEvents): array
{
    $data = read_analytics_events();
    $items = isset($data['items']) && is_array($data['items']) ? $data['items'] : [];

    if (analytics_is_duplicate_event($event, $items)) {
        return ['id' => (string) ($event['id'] ?? ''), 'duplicate' => true];
    }

    array_unshift($items, $event);
    $data['items'] = array_slice($items, 0, $maxEvents);
    $data['updatedAt'] = now_iso();
    write_json_file(ANALYTICS_EVENTS_FILE, $data);

    return ['id' => (string) $event['id'], 'duplicate' => false];
}

function analytics_is_duplicate_event(array $event, array $items): bool
{
    if (in_array((string) ($event['eventType'] ?? ''), ['callback_submitted', 'request_submitted', 'partner_lead_created'], true)) {
        $requestId = (string) ($event['requestId'] ?? '');
        if ($requestId !== '') {
            foreach (array_slice($items, 0, 120) as $item) {
                if (
                    is_array($item)
                    && (string) ($item['eventType'] ?? '') === (string) ($event['eventType'] ?? '')
                    && (string) ($item['requestId'] ?? '') === $requestId
                ) {
                    return true;
                }
            }
        }
    }

    if (!in_array((string) ($event['eventType'] ?? ''), ['page_view', 'car_view', 'car_list_view'], true)) {
        return false;
    }

    $settings = analytics_settings();
    $window = (int) $settings['page_view_dedupe_seconds'];
    $created = strtotime((string) ($event['createdAt'] ?? '')) ?: time();
    $visitorId = (string) ($event['client']['visitorId'] ?? '');
    $sessionId = (string) ($event['client']['sessionId'] ?? '');
    foreach (array_slice($items, 0, 80) as $item) {
        if (!is_array($item) || (string) ($item['eventType'] ?? '') !== (string) $event['eventType']) {
            continue;
        }
        $itemCreated = strtotime((string) ($item['createdAt'] ?? ''));
        if ($itemCreated === false || abs($created - $itemCreated) > $window) {
            continue;
        }
        $sameVisitor = $visitorId !== '' && $visitorId === (string) ($item['client']['visitorId'] ?? '');
        $sameSession = $sessionId !== '' && $sessionId === (string) ($item['client']['sessionId'] ?? '');
        if (!$sameVisitor && !$sameSession) {
            continue;
        }
        if ((string) ($item['pageUrl'] ?? '') === (string) ($event['pageUrl'] ?? '') && (string) ($item['carId'] ?? '') === (string) ($event['carId'] ?? '')) {
            return true;
        }
    }

    return false;
}

function analytics_record_request_event(string $eventType, array $request, array $meta = []): void
{
    try {
    $scopeId = (string) ($request['responsible_scope_id'] ?? $request['receiver_scope_id'] ?? $request['settlement_counterparty_scope_id'] ?? $request['car_owner_scope_id'] ?? 'rent_rk');
    if ($scopeId === '') {
        $scopeId = 'rent_rk';
    }
    $carId = normalize_car_slug((string) ($request['carSlug'] ?? $request['car_id'] ?? ''));
    $partnerId = normalize_partner_item(['slug' => (string) ($request['partner_id'] ?? $request['partnerSlug'] ?? ''), 'name' => 'x'])['slug'];
    $lessorId = normalize_lessor_slug((string) ($request['lessorSlug'] ?? ''));

    analytics_record_event($eventType, [
        'scopeId' => $scopeId,
        'sourceScopeId' => (string) ($request['car_owner_scope_id'] ?? ''),
        'entityType' => 'request',
        'entityId' => (string) ($request['id'] ?? ''),
        'requestId' => (string) ($request['id'] ?? ''),
        'carId' => $carId,
        'partnerId' => $partnerId,
        'lessorId' => $lessorId,
        'pageType' => (string) ($request['source_page_type'] ?? ''),
        'pageUrl' => (string) ($request['page_url'] ?? $request['sourcePage'] ?? ''),
        'referrer' => (string) ($request['referrer'] ?? ''),
        'utm' => [
            'source' => (string) ($request['utm_source'] ?? ''),
            'medium' => (string) ($request['utm_medium'] ?? ''),
            'campaign' => (string) ($request['utm_campaign'] ?? ''),
            'content' => (string) ($request['utm_content'] ?? ''),
            'term' => (string) ($request['utm_term'] ?? ''),
        ],
        'meta' => array_merge([
            'requestKind' => (string) ($request['requestKind'] ?? ''),
            'requestSource' => (string) ($request['request_source'] ?? $request['sourceChannel'] ?? ''),
            'status' => (string) ($request['status'] ?? ''),
            'callbackMode' => (string) ($request['callback_mode'] ?? ''),
            'aiReferralSource' => (string) ($request['aiReferralSource'] ?? ''),
            'aiReferralMatchedBy' => (string) ($request['aiReferralMatchedBy'] ?? ''),
        ], $meta),
    ]);
    } catch (Throwable $exception) {
        technical_log('analytics_request_event_failed', [
            'eventType' => $eventType,
            'reason' => $exception->getMessage(),
        ]);
    }
}

function analytics_record_rental_event(string $eventType, array $rental, array $meta = []): void
{
    try {
    $rental = normalize_rental_item($rental);
    $scopeId = (string) ($rental['car_owner_scope_id'] ?? '');
    if ($scopeId === '') {
        $car = find_car((string) ($rental['carSlug'] ?? ''));
        $scopeId = $car ? car_owner_scope_id($car) : 'rent_rk';
    }
    $isBooking = rental_is_booking($rental);

    analytics_record_event($eventType, [
        'scopeId' => $scopeId,
        'entityType' => $isBooking ? 'booking' : 'rental',
        'entityId' => (string) ($rental['id'] ?? ''),
        'bookingId' => $isBooking ? (string) ($rental['id'] ?? '') : '',
        'rentalId' => !$isBooking ? (string) ($rental['id'] ?? '') : '',
        'requestId' => (string) ($rental['sourceRequestId'] ?? ''),
        'carId' => normalize_car_slug((string) ($rental['carSlug'] ?? '')),
        'partnerId' => normalize_partner_item(['slug' => (string) ($rental['partnerSlug'] ?? ''), 'name' => 'x'])['slug'],
        'lessorId' => lessor_slug_from_scope_id($scopeId),
        'meta' => array_merge([
            'bookingStatus' => (string) ($rental['bookingStatus'] ?? ''),
            'contractStatus' => (string) ($rental['contractStatus'] ?? ''),
            'issueStatus' => (string) ($rental['issueStatus'] ?? ''),
            'returnStatus' => (string) ($rental['returnStatus'] ?? ''),
            'sourceChannel' => (string) ($rental['sourceChannel'] ?? ''),
        ], $meta),
    ]);
    } catch (Throwable $exception) {
        technical_log('analytics_rental_event_failed', [
            'eventType' => $eventType,
            'reason' => $exception->getMessage(),
        ]);
    }
}

function analytics_record_request_status_change(array $before, array $after): void
{
    $old = (string) ($before['status'] ?? '');
    $new = (string) ($after['status'] ?? '');
    if ($old === $new) {
        return;
    }

    analytics_record_request_event('request_status_changed', $after, [
        'oldStatus' => $old,
        'newStatus' => $new,
    ]);
}

function analytics_record_rental_changes(array $before, array $after): void
{
    try {
    $before = normalize_rental_item($before);
    $after = normalize_rental_item($after);

    if ((string) ($before['bookingStatus'] ?? '') !== (string) ($after['bookingStatus'] ?? '')) {
        analytics_record_rental_event('booking_status_changed', $after, [
            'oldStatus' => (string) ($before['bookingStatus'] ?? ''),
            'newStatus' => (string) ($after['bookingStatus'] ?? ''),
        ]);
    }

    $statusFields = ['contractStatus', 'issueStatus', 'returnStatus'];
    $changed = [];
    foreach ($statusFields as $field) {
        if ((string) ($before[$field] ?? '') !== (string) ($after[$field] ?? '')) {
            $changed[$field] = [
                'old' => (string) ($before[$field] ?? ''),
                'new' => (string) ($after[$field] ?? ''),
            ];
        }
    }
    if ($changed) {
        analytics_record_rental_event('rental_status_changed', $after, [
            'changedStatuses' => $changed,
        ]);
    }

    $hadReturnFact = trim((string) ($before['actualReturnDate'] ?? '')) !== '' || trim((string) ($before['actualReturnTime'] ?? '')) !== '';
    $hasReturnFact = trim((string) ($after['actualReturnDate'] ?? '')) !== '' || trim((string) ($after['actualReturnTime'] ?? '')) !== '';
    if (!$hadReturnFact && $hasReturnFact) {
        analytics_record_rental_event('rental_return_fact_fixed', $after);
    }

    if (trim((string) ($before['closedAt'] ?? '')) === '' && trim((string) ($after['closedAt'] ?? '')) !== '') {
        analytics_record_rental_event('rental_closed', $after);
    }
    } catch (Throwable $exception) {
        technical_log('analytics_rental_change_failed', [
            'reason' => $exception->getMessage(),
        ]);
    }
}

function analytics_visible_scope_ids_for_current_user(): array
{
    if (!has_permission('analytics.view')) {
        return [];
    }
    if (current_user_is_platform_admin()) {
        return array_map(static fn(array $item): string => (string) $item['scope_id'], scope_list());
    }
    if (current_admin_role() === 'partner') {
        return [];
    }

    $settings = analytics_settings();
    $scopeId = current_user_data_scope_id();
    if ($scopeId !== '') {
        return !empty($settings['external_scope_analytics_enabled']) ? [$scopeId] : [];
    }
    if (current_admin_role() === 'manager') {
        return ['rent_rk'];
    }

    return [];
}

function analytics_current_user_can_view(): bool
{
    return analytics_visible_scope_ids_for_current_user() !== [];
}

function analytics_current_user_can_view_scope(string $scopeId): bool
{
    return in_array(analytics_scope_id($scopeId), analytics_visible_scope_ids_for_current_user(), true);
}

function analytics_events_for_current_user(DateTimeImmutable $from, DateTimeImmutable $to, string $scopeFilter = ''): array
{
    $allowedScopes = analytics_visible_scope_ids_for_current_user();
    if (!$allowedScopes) {
        return [];
    }

    $scopeFilter = analytics_clean_id($scopeFilter, 80);
    if ($scopeFilter !== '' && $scopeFilter !== 'all') {
        if (!in_array($scopeFilter, $allowedScopes, true)) {
            return [];
        }
        $allowedScopes = [$scopeFilter];
    }

    $fromTs = $from->getTimestamp();
    $toTs = $to->getTimestamp();
    $events = [];
    foreach (read_analytics_events()['items'] as $event) {
        if (!is_array($event)) {
            continue;
        }
        $created = strtotime((string) ($event['createdAt'] ?? ''));
        if ($created === false || $created < $fromTs || $created > $toTs) {
            continue;
        }
        if (!in_array((string) ($event['scopeId'] ?? ''), $allowedScopes, true)) {
            continue;
        }
        $events[] = $event;
    }

    return $events;
}

function analytics_percent(int $part, int $total): ?float
{
    if ($total <= 0) {
        return null;
    }

    return round($part / $total * 100, 1);
}

function analytics_source_bucket(array $event): string
{
    $utmSource = strtolower(trim((string) ($event['utm']['source'] ?? '')));
    $referrer = strtolower((string) ($event['referrer'] ?? ''));
    if (
        str_contains($utmSource, 'chatgpt') || str_contains($referrer, 'chatgpt.com')
        || str_contains($utmSource, 'perplexity') || str_contains($referrer, 'perplexity.ai')
        || str_contains($utmSource, 'copilot') || str_contains($utmSource, 'bing') || str_contains($referrer, 'copilot.microsoft.com')
    ) {
        return 'ai_referral';
    }
    if ($utmSource !== '') {
        foreach (['yandex', 'google', 'vk', 'telegram', 'whatsapp', 'avito', 'partner'] as $known) {
            if (str_contains($utmSource, $known)) {
                return $known;
            }
        }

        return $utmSource;
    }
    if ((string) ($event['pageType'] ?? '') === 'partner_page' || (string) ($event['partnerId'] ?? '') !== '') {
        return 'partner';
    }
    $requestSource = strtolower((string) ($event['meta']['requestSource'] ?? $event['meta']['sourceChannel'] ?? ''));
    if (str_contains($requestSource, 'partner')) {
        return 'partner';
    }
    if (str_contains($requestSource, 'telegram')) {
        return 'telegram';
    }
    if (str_contains($requestSource, 'whatsapp')) {
        return 'whatsapp';
    }

    if ($referrer === '') {
        return 'direct';
    }
    foreach (['yandex', 'google', 'vk', 'telegram', 'whatsapp', 'avito'] as $known) {
        if (str_contains($referrer, $known)) {
            return $known;
        }
    }

    return 'unknown';
}

function analytics_summary(array $events): array
{
    $counts = array_fill_keys(array_keys(analytics_event_type_definitions()), 0);
    $sources = [];
    $cars = [];
    $partners = [];
    $carNames = [];
    foreach (read_cars() as $car) {
        $slug = (string) ($car['slug'] ?? '');
        if ($slug !== '') {
            $carNames[$slug] = (string) (($car['name'] ?? '') ?: $slug);
        }
    }
    $partnerNames = [];
    foreach (read_partners()['items'] as $partner) {
        $slug = (string) ($partner['slug'] ?? '');
        if ($slug !== '') {
            $partnerNames[$slug] = (string) (($partner['name'] ?? '') ?: $slug);
        }
    }

    foreach ($events as $event) {
        $type = (string) ($event['eventType'] ?? '');
        if (isset($counts[$type])) {
            $counts[$type]++;
        }

        $source = analytics_source_bucket($event);
        $sources[$source] = ($sources[$source] ?? 0) + 1;

        $carId = (string) ($event['carId'] ?? '');
        if ($carId !== '') {
            $cars[$carId] = $cars[$carId] ?? [
                'carId' => $carId,
                'name' => $carNames[$carId] ?? $carId,
                'views' => 0,
                'requests' => 0,
                'bookings' => 0,
                'rentals' => 0,
            ];
            if ($type === 'car_view') {
                $cars[$carId]['views']++;
            } elseif ($type === 'request_created') {
                $cars[$carId]['requests']++;
            } elseif ($type === 'booking_created') {
                $cars[$carId]['bookings']++;
            } elseif ($type === 'rental_created') {
                $cars[$carId]['rentals']++;
            }
        }

        $partnerId = (string) ($event['partnerId'] ?? '');
        if ($partnerId !== '') {
            $partners[$partnerId] = $partners[$partnerId] ?? [
                'partnerId' => $partnerId,
                'name' => $partnerNames[$partnerId] ?? $partnerId,
                'views' => 0,
                'leads' => 0,
                'fallbackShows' => 0,
            ];
            if ($type === 'partner_page_view') {
                $partners[$partnerId]['views']++;
            } elseif ($type === 'partner_lead_created') {
                $partners[$partnerId]['leads']++;
            } elseif ($type === 'rent_rk_fallback_form_shown') {
                $partners[$partnerId]['fallbackShows']++;
            }
        }
    }

    foreach ($cars as &$car) {
        $car['viewToRequest'] = analytics_percent((int) $car['requests'], (int) $car['views']);
        $car['interestScore'] = (int) $car['views'] + ((int) $car['requests'] * 5) + ((int) $car['bookings'] * 8) + ((int) $car['rentals'] * 12);
    }
    unset($car);
    usort($cars, static fn(array $left, array $right): int => ($right['interestScore'] <=> $left['interestScore']) ?: strcmp($left['name'], $right['name']));
    arsort($sources);
    usort($partners, static fn(array $left, array $right): int => (($right['views'] + $right['leads']) <=> ($left['views'] + $left['leads'])) ?: strcmp($left['name'], $right['name']));

    return [
        'counts' => $counts,
        'kpi' => [
            'eventsTotal' => count($events),
            'pageViews' => $counts['page_view'],
            'carViews' => $counts['car_view'],
            'phoneClicks' => $counts['phone_click'],
            'messengerClicks' => $counts['messenger_click'],
            'callbackShown' => $counts['callback_shown'],
            'callbackSubmitted' => $counts['callback_submitted'],
            'requestsCreated' => $counts['request_created'],
            'bookingsCreated' => $counts['booking_created'],
            'rentalsCreated' => $counts['rental_created'],
            'callbackConversion' => analytics_percent($counts['callback_submitted'], $counts['callback_shown']),
            'carViewToRequest' => analytics_percent($counts['request_created'], $counts['car_view']),
        ],
        'funnel' => [
            ['label' => 'Просмотры', 'count' => $counts['page_view'] + $counts['car_view']],
            ['label' => 'Интерес', 'count' => $counts['phone_click'] + $counts['messenger_click'] + $counts['callback_submitted'] + $counts['request_created']],
            ['label' => 'Брони', 'count' => $counts['booking_created']],
            ['label' => 'Аренды', 'count' => $counts['rental_created']],
        ],
        'sources' => $sources,
        'cars' => array_values($cars),
        'partners' => array_values($partners),
    ];
}
