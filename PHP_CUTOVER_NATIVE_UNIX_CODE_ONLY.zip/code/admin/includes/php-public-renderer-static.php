<?php
declare(strict_types=1);

final class RentRkPublicStaticPlan
{
    public const PAGES = [
        '/pages/conditions.html', '/pages/faq.html', '/pages/contacts.html',
        '/pages/arenda-avto-v-yalte.html', '/pages/arenda-avto-v-krymu.html',
        '/pages/arenda-avto-bez-voditelya.html', '/pages/arenda-avto-s-voditelem.html',
        '/pages/arenda-krossovera.html', '/pages/arenda-avto-7-mest.html', '/pages/podacha-avtomobilya.html',
    ];

    private const FLEET = [
        '/pages/conditions.html' => 'all', '/pages/arenda-avto-v-yalte.html' => 'all',
        '/pages/arenda-avto-v-krymu.html' => 'all', '/pages/arenda-avto-bez-voditelya.html' => 'all',
        '/pages/arenda-avto-s-voditelem.html' => 'all', '/pages/podacha-avtomobilya.html' => 'all',
        '/pages/arenda-krossovera.html' => 'crossovers', '/pages/arenda-avto-7-mest.html' => 'seven',
    ];

    public static function isFleetPage(string $path): bool { return isset(self::FLEET['/' . $path]); }

    /** Build only a projection; the caller is responsible for checking the existing server decision. */
    public static function paths(array $source): array
    {
        $editorial = array_key_exists('editorial', $source);
        if ($editorial ? (count($source) !== 2 || !is_array($source['editorial']) || !is_array($source['routes'] ?? null))
            : (array_diff(array_keys($source), ['pages', 'routes', 'contactMedia']) || !is_array($source['pages'] ?? null) || !is_array($source['routes'] ?? null)
            || array_diff(self::PAGES, array_keys($source['pages'])) || array_diff(array_keys($source['pages']), self::PAGES))) {
            throw new RuntimeException('BLOCKED_STATIC_PUBLIC_SET_INCOMPLETE');
        }
        if (!is_array($source['routes'] ?? null)
            || !array_is_list($source['routes']) || $source['routes'] === []
        ) {
            throw new RuntimeException('BLOCKED_STATIC_PUBLIC_SET_INCOMPLETE');
        }
        foreach ($source['pages'] ?? [] as $page) {
            if (!is_array($page) || count($page) !== 5) throw new RuntimeException('BLOCKED_STATIC_PUBLIC_PAGE_INVALID');
            self::text($page, ['title', 'heading', 'description']);
            foreach (['sections', 'faq'] as $key) {
                $rows = $page[$key] ?? null;
                if (!is_array($rows) || !array_is_list($rows) || ($key === 'sections' && !$rows)) throw new RuntimeException('BLOCKED_STATIC_PUBLIC_PAGE_INVALID');
                foreach ($rows as $row) {
                    if (!is_array($row) || count($row) !== 2) throw new RuntimeException('BLOCKED_STATIC_PUBLIC_PAGE_INVALID');
                    self::text($row, $key === 'faq' ? ['question', 'answer'] : ['heading', 'text']);
                }
            }
        }
        if (!$editorial && !$source['pages']['/pages/faq.html']['faq']) throw new RuntimeException('BLOCKED_STATIC_PUBLIC_PAGE_INVALID');
        $paths = [...self::PAGES, '/routes/'];
        foreach ($source['routes'] as $route) {
            if (!is_array($route)) throw new RuntimeException('BLOCKED_STATIC_PUBLIC_ROUTE_INVALID');
            self::text($route, ['slug', 'title', 'summary', 'description', 'type', 'duration', 'car']);
            if (!preg_match('/\A[a-z0-9]+(?:-[a-z0-9]+)*\z/D', $route['slug']) || $route['slug'] === 'index'
                || !is_array($route['audience'] ?? null) || !array_is_list($route['audience'])) throw new RuntimeException('BLOCKED_STATIC_PUBLIC_ROUTE_INVALID');
            foreach ($route['audience'] as $label) if (!is_string($label) || trim($label) === '') throw new RuntimeException('BLOCKED_STATIC_PUBLIC_ROUTE_INVALID');
            $paths[] = '/routes/' . $route['slug'] . '.html';
        }
        if (count($paths) !== count(array_unique($paths))) throw new RuntimeException('BLOCKED_STATIC_PUBLIC_SET_INCOMPLETE');
        if (array_key_exists('contactMedia', $source)) self::contactMedia($source['contactMedia']);
        return $paths;
    }

    private static function contactMedia(mixed $media): array
    {
        if (!is_array($media) || count($media) !== 5 || !is_string($media['organizationId'] ?? null)
            || !preg_match('/\A[0-9]{1,16}\z/D', $media['organizationId'])
            || !is_string($media['mapLink'] ?? null)
            || !preg_match('~\Ahttps://yandex\.ru/maps/-/[A-Za-z0-9_-]{1,40}/?\z~D', $media['mapLink'])
            || !is_int($media['zoom'] ?? null) || $media['zoom'] < 1 || $media['zoom'] > 21) {
            throw new RuntimeException('BLOCKED_STATIC_CONTACT_MEDIA_INVALID');
        }
        foreach (['center', 'point'] as $field) {
            if (!is_string($media[$field] ?? null) || !preg_match('/\A(-?[0-9]{1,3}(?:\.[0-9]{1,8})?),(-?[0-9]{1,3}(?:\.[0-9]{1,8})?)\z/D', $media[$field], $m)
                || abs((float) $m[1]) > 180 || abs((float) $m[2]) > 90) throw new RuntimeException('BLOCKED_STATIC_CONTACT_MEDIA_INVALID');
        }
        return $media;
    }

    private static function text(array $value, array $keys): void
    {
        foreach ($keys as $key) if (!is_string($value[$key] ?? null) || trim($value[$key]) === '') throw new RuntimeException('BLOCKED_STATIC_PUBLIC_TEXT_INVALID');
    }

    private static function relevant(array $car, string $group): bool
    {
        return match ($group) {
            'all' => true,
            'seven' => $car['seats'] >= 7,
            'crossovers' => in_array(mb_strtolower(trim($car['type'])), ['crossover', 'suv', 'кроссовер', 'внедорожник'], true),
            default => false,
        };
    }

    public static function render(array $snapshot, string $mode, ?array $selected): array
    {
        $s = $snapshot['staticPublication'];
        if (isset($s['editorial'])) return self::renderEditorial($snapshot, $mode, $selected);
        $e = 'rent_rk_public_escape';
        $out = [];
        foreach (self::PAGES as $path) {
            $group = self::FLEET[$path] ?? '';
            if ($mode === 'Car' && ($selected === null || !self::relevant($selected, $group))) continue;
            $p = $s['pages'][$path];
            $body = '<h1>' . $e($p['heading']) . '</h1>';
            foreach ($p['sections'] as $row) $body .= '<section><h2>' . $e($row['heading']) . '</h2><p>' . $e($row['text']) . '</p></section>';
            if ($p['faq']) {
                $faq = [];
                foreach ($p['faq'] as $row) {
                    $body .= '<details><summary>' . $e($row['question']) . '</summary><p>' . $e($row['answer']) . '</p></details>';
                    $faq[] = ['@type' => 'Question', 'name' => $row['question'], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $row['answer']]];
                }
                $body .= '<script type="application/ld+json">' . json_encode(['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $faq], JSON_HEX_TAG | JSON_HEX_AMP | JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE) . '</script>';
            }
            if ($group !== '') {
                $body .= '<ul>';
                foreach ($snapshot['cars'] as $car) if (self::relevant($car, $group)) {
                    $body .= '<li><a href="../cars/' . $e($car['slug']) . '.html">' . $e($car['name']) . '</a>';
                    if ($path === '/pages/conditions.html') $body .= ' — ' . $e((string) $car['deposit']) . ' ₽';
                    $body .= '</li>';
                }
                $body .= '</ul>';
            }
            if ($path === '/pages/contacts.html') {
                $site = $snapshot['site'];
                $body .= '<address>' . $e($site['address']) . ' <a href="tel:' . $e($site['phone']) . '">' . $e($site['phone'])
                    . '</a> <a href="' . $e($site['telegram']) . '">Telegram</a></address>';
                if (isset($s['contactMedia'])) {
                    $m = self::contactMedia($s['contactMedia']);
                    $map = 'https://yandex.ru/map-widget/v1/?' . http_build_query(['ll' => $m['center'], 'mode' => 'poi',
                        'poi[point]' => $m['point'], 'poi[uri]' => 'ymapsbm1://org?oid=' . $m['organizationId'], 'z' => $m['zoom']], '', '&', PHP_QUERY_RFC3986);
                    $reviews = 'https://yandex.ru/maps-reviews-widget/' . $m['organizationId'] . '?comments';
                    foreach (['Карта' => $map, 'Отзывы на Яндекс Картах' => $reviews] as $label => $url) {
                        $body .= '<section class="map-block"><h2>' . $e($label) . '</h2><a href="' . $e($m['mapLink'])
                            . '" rel="noopener noreferrer">Открыть в Яндекс Картах</a><iframe src="' . $e($url)
                            . '" title="' . $e($label) . '" loading="lazy" sandbox="allow-scripts allow-same-origin" referrerpolicy="no-referrer"></iframe></section>';
                    }
                }
            }
            $body .= '<p><a href="../cars/index.html">Смотреть автомобили</a></p>';
            $out[ltrim($path, '/')] = rent_rk_public_layout($snapshot, $p['title'], $p['description'], $path, $body);
        }
        if ($mode !== 'Full') return $out;
        $cards = []; $groups = [];
        foreach ($s['routes'] as $route) {
            $slug = $e($route['slug']);
            $name = $e($route['title']);
            $link = '<a href="' . $slug . '.html">' . $name . '</a>';
            $cards[] = '<article class="card"><h2>' . $link . '</h2><p>' . $e($route['summary']) . '</p><p>' . $e($route['type']) . ' · ' . $e($route['duration']) . '</p></article>';
            foreach ($route['audience'] as $audience) $groups[$audience][] = '<li>' . $link . '</li>';
            $body = '<h1>' . $name . '</h1><p>' . $e($route['summary']) . '</p><p>' . $e($route['description']) . '</p><ul>';
            foreach ([$route['type'], $route['duration'], implode(', ', $route['audience']), $route['car']] as $text) $body .= '<li>' . $e($text) . '</li>';
            $body .= '</ul><a href="../cars/index.html">Выбрать автомобиль</a> <a href="' . $e($snapshot['site']['telegram']) . '">Обсудить поездку</a>';
            $path = 'routes/' . $route['slug'] . '.html';
            $out[$path] = rent_rk_public_layout($snapshot, $route['title'], $route['summary'], '/' . $path, $body);
        }
        $body = '<h1>Маршруты из Ялты на авто</h1><div class="grid cards">' . implode('', $cards) . '</div>';
        foreach ($groups as $label => $links) $body .= '<section><h2>' . $e((string) $label) . '</h2><ul>' . implode('', $links) . '</ul></section>';
        $out['routes/index.html'] = rent_rk_public_layout($snapshot, 'Маршруты из Ялты на авто', 'Маршруты для поездок на арендованном автомобиле.', '/routes/', $body);
        $out['robots.txt'] = "User-agent: *\nDisallow: /admin/\nDisallow: /api/\nDisallow: /data/\nAllow: /\nSitemap: "
            . rtrim($snapshot['site']['baseUrl'], '/') . "/sitemap.xml\n";
        return $out;
    }

    private static function renderEditorial(array $snapshot, string $mode, ?array $selected): array
    {
        $e = 'rent_rk_public_escape';
        $s = $snapshot['staticPublication'];
        $site = $snapshot['site'];
        $out = [];
        foreach ($s['editorial']['items'] as $item) {
            $path = $item['path'];
            if (in_array($path, ['index.html', 'cars/index.html'], true)) continue;
            $group = self::FLEET['/' . $path] ?? '';
            if ($mode === 'Car' && ($selected === null || !self::relevant($selected, $group))) continue;
            $body = RentRkApprovedEditorialV2::article($item);
            if ($item['id'] === 'contacts-map-review') {
                $m = $s['editorial']['media'];
                self::contactMedia(array_intersect_key($m, array_flip(['organizationId','mapLink','center','point','zoom'])));
                $body .= RentRkApprovedEditorialV2::links($item, ['tel:' . $site['phone'], $site['telegram'], $m['mapLink'], $m['reviewsLink']]);
                $urls = ['Карта' => 'https://yandex.ru/map-widget/v1/?' . http_build_query(['ll' => $m['center'], 'mode' => 'poi',
                    'poi[point]' => $m['point'], 'poi[uri]' => 'ymapsbm1://org?oid=' . $m['organizationId'], 'z' => $m['zoom']], '', '&', PHP_QUERY_RFC3986),
                    'Отзывы на Яндекс Картах' => 'https://yandex.ru/maps-reviews-widget/' . $m['organizationId'] . '?comments'];
                foreach ($urls as $label => $url) $body .= '<div class="map-block"><iframe src="' . $e($url)
                    . '" title="' . $e($label) . '" loading="lazy" sandbox="allow-scripts allow-same-origin" referrerpolicy="no-referrer"></iframe></div>';
                $body .= '<p><a href="' . $e($m['extraLink']) . '">' . $e($m['extraLabel']) . '</a></p>';
            } elseif ($item['id'] === 'faq') {
                $body .= RentRkApprovedEditorialV2::faqSchema($item['text']);
            } elseif ($item['id'] === 'routes_index') {
                $body .= RentRkApprovedEditorialV2::links($item, ['#approved-route-list', '../cars/index.html']);
                $body .= '<ul id="approved-route-list">';
                foreach ($s['routes'] as $r) {
                    $route = RentRkApprovedEditorialV2::item($snapshot, 'routes/' . $r['slug'] . '.html');
                    $heading = substr(explode("\n", $route['text'], 2)[0], 2);
                    $body .= '<li data-route-audience="' . $e(implode(',', $r['audience'])) . '"><a href="' . $e($r['slug']) . '.html">' . $e($heading) . '</a></li>';
                }
                $body .= '</ul>';
            } elseif ($item['buttons'] !== '') {
                $body .= RentRkApprovedEditorialV2::links($item, ['../cars/index.html', $site['telegram']]);
            }
            if ($group !== '') {
                $body .= '<ul>';
                foreach ($snapshot['cars'] as $car) if (self::relevant($car, $group)) {
                    $body .= '<li><a href="../cars/' . $e($car['slug']) . '.html">' . $e($car['name']) . '</a>';
                    if ($item['id'] === 'conditions') $body .= ' — ' . $e((string) $car['deposit']) . ' ₽';
                    $body .= '</li>';
                }
                $body .= '</ul>';
            }
            $url = $path === 'routes/index.html' ? '/routes/' : '/' . $path;
            $out[$path] = rent_rk_public_layout($snapshot, $item['title'], $item['description'], $url, $body);
        }
        if ($mode === 'Full') $out['robots.txt'] = "User-agent: *\nDisallow: /admin/\nDisallow: /api/\nDisallow: /data/\nAllow: /\nSitemap: "
            . rtrim($site['baseUrl'], '/') . "/sitemap.xml\n";
        return $out;
    }
}
