<?php

declare(strict_types=1);

// Monetary storage stays in whole rubles. Floats and lossy syntax are not input formats.
function rental_return_money($value): ?int
{
    if (is_int($value)) {
        return $value >= 0 ? $value : null;
    }
    if (!is_string($value)) {
        return null;
    }
    $text = trim(str_replace(["\u{00a0}", "\u{202f}"], ' ', $value));
    if (!preg_match('/^(?:[0-9]+|[0-9]{1,3}(?: [0-9]{3})+)$/D', $text)) {
        return null;
    }
    $digits = ltrim(str_replace(' ', '', $text), '0');
    $digits = $digits === '' ? '0' : $digits;
    $max = (string) PHP_INT_MAX;
    if (strlen($digits) > strlen($max) || (strlen($digits) === strlen($max) && strcmp($digits, $max) > 0)) {
        return null;
    }
    return (int) $digits;
}

function rental_return_add(int $a, int $b): int
{
    if (($b > 0 && $a > PHP_INT_MAX - $b) || ($b < 0 && $a < PHP_INT_MIN - $b)) {
        throw new InvalidArgumentException('Сумма превышает допустимый диапазон.', 422);
    }
    return $a + $b;
}

function rental_return_percent(int $base, int $percent): int
{
    if ($base < 0 || $percent < 0) {
        throw new InvalidArgumentException('Недопустимая база комиссии.', 422);
    }
    // Split before multiplication; matches positive whole-ruble round-half-up.
    $whole = intdiv($base, 100);
    if ($percent !== 0 && $whole > intdiv(PHP_INT_MAX, $percent)) {
        throw new InvalidArgumentException('Комиссия превышает допустимый диапазон.', 422);
    }
    $remainder = $base % 100;
    if ($percent > intdiv(PHP_INT_MAX - 50, max(1, $remainder))) {
        throw new InvalidArgumentException('Комиссия превышает допустимый диапазон.', 422);
    }
    return rental_return_add($whole * $percent, intdiv($remainder * $percent + 50, 100));
}

function rental_return_ratio(int $amount, int $share, int $total): int
{
    if ($amount < 0 || $share < 0 || $total <= 0 || $share > $total) {
        throw new InvalidArgumentException('Некорректная пропорция расчёта.', 422);
    }
    $quotient = 0;
    $remainder = 0;
    $unit = intdiv($amount, $total);
    $unitRemainder = $amount % $total;
    // Binary multiplication of quotient/remainder pairs avoids an overflowing product.
    while ($share > 0) {
        if ($share % 2) {
            $quotient = rental_return_add($quotient, $unit);
            if ($remainder >= $total - $unitRemainder) {
                $quotient = rental_return_add($quotient, 1);
                $remainder -= $total - $unitRemainder;
            } else { $remainder += $unitRemainder; }
        }
        $share = intdiv($share, 2);
        if ($share === 0) { break; }
        $unit = rental_return_add($unit, $unit);
        if ($unitRemainder >= $total - $unitRemainder) {
            $unit = rental_return_add($unit, 1);
            $unitRemainder -= $total - $unitRemainder;
        } else { $unitRemainder += $unitRemainder; }
    }
    return $remainder >= intdiv($total, 2) + $total % 2 ? rental_return_add($quotient, 1) : $quotient;
}
