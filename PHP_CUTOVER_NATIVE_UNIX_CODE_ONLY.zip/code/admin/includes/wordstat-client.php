<?php

declare(strict_types=1);

function wordstat_supported_methods(): array
{
    return ['getTop', 'getDynamics', 'getRegionsDistribution'];
}

function wordstat_all_methods(): array
{
    return ['getTop', 'getDynamics', 'getRegionsDistribution', 'getRegionsTree'];
}

function wordstat_clean_string($value, int $maxLength = 500): string
{
    return demand_integrations_clean_string($value, $maxLength);
}

function wordstat_default_base_url(): string
{
    return 'https://searchapi.api.cloud.yandex.net/v2/wordstat';
}

function wordstat_normalize_base_url(string $baseUrl): string
{
    $baseUrl = trim($baseUrl);
    if ($baseUrl === '' || str_contains($baseUrl, 'example.invalid')) {
        return wordstat_default_base_url();
    }
    $baseUrl = rtrim($baseUrl, "/ \t\n\r\0\x0B");

    return preg_replace('#/(topRequests|dynamics|regions|getRegionsTree)$#', '', $baseUrl) ?: $baseUrl;
}

function wordstat_method_path(string $method): string
{
    return match ($method) {
        'GetTop' => 'topRequests',
        'GetDynamics' => 'dynamics',
        'GetRegionsDistribution' => 'regions',
        'GetRegionsTree' => 'getRegionsTree',
        default => throw new RuntimeException('Unsupported Wordstat method: ' . $method),
    };
}

function wordstat_parse_datetime_utc($value): ?DateTimeImmutable
{
    $text = trim((string) $value);
    if ($text === '') {
        return null;
    }

    try {
        return (new DateTimeImmutable($text))->setTimezone(new DateTimeZone('UTC'));
    } catch (Throwable) {
        return null;
    }
}

function wordstat_monthly_dynamics_range(array $payload = []): array
{
    $timezone = new DateTimeZone('UTC');
    $thisMonthStart = (new DateTimeImmutable('now', $timezone))->modify('first day of this month')->setTime(0, 0, 0);
    $defaultTo = $thisMonthStart->modify('-1 second');
    $defaultFrom = $defaultTo->modify('first day of this month')->setTime(0, 0, 0)->modify('-11 months');

    $fromInput = wordstat_parse_datetime_utc($payload['fromDate'] ?? $payload['from'] ?? null);
    $toInput = wordstat_parse_datetime_utc($payload['toDate'] ?? $payload['to'] ?? null);

    $from = $fromInput ? $fromInput->modify('first day of this month')->setTime(0, 0, 0) : $defaultFrom;
    $to = $toInput ? $toInput->modify('last day of this month')->setTime(23, 59, 59) : $defaultTo;
    if ($to < $from) {
        $to = $from->modify('last day of this month')->setTime(23, 59, 59);
    }

    return [
        'fromDate' => $from->format('Y-m-d\T00:00:00\Z'),
        'toDate' => $to->format('Y-m-d\T23:59:59\Z'),
    ];
}

function wordstat_get_config_value(string $name): string
{
    $value = getenv($name);
    if (is_string($value) && trim($value) !== '') {
        return trim($value);
    }
    if (defined($name)) {
        $constant = constant($name);
        if (is_scalar($constant) && trim((string) $constant) !== '') {
            return trim((string) $constant);
        }
    }

    return '';
}

function wordstat_credentials_path(): string
{
    return defined('WORDSTAT_CREDENTIALS_FILE')
        ? WORDSTAT_CREDENTIALS_FILE
        : DATA_DIR . 'secrets/wordstat-credentials.local.json';
}

function wordstat_read_private_credentials(): array
{
    $path = wordstat_credentials_path();
    if (!is_file($path)) {
        return [];
    }

    try {
        $data = read_json_file($path, []);
    } catch (Throwable) {
        return [];
    }

    return is_array($data) ? $data : [];
}

function wordstat_write_private_credentials(array $payload): array
{
    $path = wordstat_credentials_path();
    $existing = wordstat_read_private_credentials();
    $authMode = strtolower(trim((string) ($payload['wordstat_auth_mode'] ?? $payload['authMode'] ?? ($existing['authMode'] ?? 'api_key'))));
    if (!in_array($authMode, ['api_key', 'bearer'], true)) {
        $authMode = 'api_key';
    }

    $apiKeyInput = trim((string) ($payload['wordstat_api_key'] ?? $payload['apiKey'] ?? ''));
    $folderIdInput = trim((string) ($payload['wordstat_folder_id'] ?? $payload['folderId'] ?? ''));
    $baseUrlInput = trim((string) ($payload['wordstat_base_url'] ?? $payload['baseUrl'] ?? ''));

    $apiKey = $apiKeyInput !== '' ? $apiKeyInput : trim((string) ($existing['apiKey'] ?? ''));
    $folderId = $folderIdInput !== '' ? $folderIdInput : trim((string) ($existing['folderId'] ?? ''));
    $baseUrl = wordstat_normalize_base_url($baseUrlInput !== '' ? $baseUrlInput : trim((string) ($existing['baseUrl'] ?? '')));

    if (!preg_match('#^https?://#i', $baseUrl)) {
        throw new RuntimeException('Wordstat baseUrl должен начинаться с http:// или https://.');
    }

    $data = [
        'authMode' => $authMode,
        'apiKey' => substr($apiKey, 0, 4000),
        'folderId' => substr($folderId, 0, 500),
        'baseUrl' => substr($baseUrl, 0, 1000),
        'updatedAt' => now_iso(),
        'updatedBy' => current_admin_user() ?: 'admin',
    ];
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if (!is_string($json)) {
        throw new RuntimeException('Не удалось подготовить Wordstat credentials JSON.');
    }
    $json .= PHP_EOL;

    $dir = dirname($path);
    if (!is_dir($dir) && !mkdir($dir, 0775, true)) {
        throw new RuntimeException('Не удалось создать директорию Wordstat secrets.');
    }
    $gitignore = $dir . DIRECTORY_SEPARATOR . '.gitignore';
    if (!is_file($gitignore)) {
        file_put_contents($gitignore, "*\n!.gitignore\n!.htaccess\n", LOCK_EX);
    }
    $htaccess = $dir . DIRECTORY_SEPARATOR . '.htaccess';
    if (!is_file($htaccess)) {
        file_put_contents($htaccess, "Require all denied\nDeny from all\n", LOCK_EX);
    }

    $tempPath = $path . '.tmp.' . bin2hex(random_bytes(6));
    if (file_put_contents($tempPath, $json, LOCK_EX) === false) {
        @unlink($tempPath);
        throw new RuntimeException('Не удалось записать временный Wordstat credentials файл.');
    }
    $verifyRaw = file_get_contents($tempPath);
    $verify = is_string($verifyRaw) ? json_decode($verifyRaw, true) : null;
    if (!is_array($verify)) {
        @unlink($tempPath);
        throw new RuntimeException('Wordstat credentials JSON не прошёл проверку перед сохранением.');
    }
    if (!rename($tempPath, $path)) {
        @unlink($tempPath);
        throw new RuntimeException('Не удалось сохранить Wordstat credentials файл.');
    }
    @chmod($path, 0600);

    return wordstat_refresh_credentials_metadata($apiKey !== '' && $folderId !== '' ? 'configured' : 'not_configured');
}

function wordstat_clear_private_credentials(): array
{
    $path = wordstat_credentials_path();
    if (is_file($path) && !unlink($path)) {
        throw new RuntimeException('Не удалось удалить private Wordstat credentials file.');
    }

    return wordstat_refresh_credentials_metadata(wordstat_is_configured() ? 'configured' : 'not_configured');
}

function wordstat_mask_secret(string $value): string
{
    $value = trim($value);
    if ($value === '') {
        return '';
    }
    $tail = substr($value, -4);

    return '****' . $tail;
}

function wordstat_credentials(): array
{
    $envApiKey = wordstat_get_config_value('WORDSTAT_API_KEY');
    $envFolderId = wordstat_get_config_value('WORDSTAT_FOLDER_ID');
    $envAuthMode = wordstat_get_config_value('WORDSTAT_AUTH_MODE');
    $envBaseUrl = wordstat_normalize_base_url(wordstat_get_config_value('WORDSTAT_BASE_URL'));

    if ($envApiKey !== '' || $envFolderId !== '' || wordstat_get_config_value('WORDSTAT_BASE_URL') !== '') {
        return [
            'credentialSource' => 'env',
            'authMode' => $envAuthMode !== '' ? $envAuthMode : 'api_key',
            'apiKey' => $envApiKey,
            'folderId' => $envFolderId,
            'baseUrl' => $envBaseUrl,
        ];
    }

    $file = wordstat_read_private_credentials();
    $apiKey = trim((string) ($file['apiKey'] ?? ''));
    $folderId = trim((string) ($file['folderId'] ?? ''));
    $fileBaseUrl = trim((string) ($file['baseUrl'] ?? ''));
    $baseUrl = wordstat_normalize_base_url($fileBaseUrl);
    if ($apiKey !== '' || $folderId !== '' || $fileBaseUrl !== '') {
        return [
            'credentialSource' => 'private_file',
            'authMode' => trim((string) ($file['authMode'] ?? 'api_key')) ?: 'api_key',
            'apiKey' => $apiKey,
            'folderId' => $folderId,
            'baseUrl' => $baseUrl,
        ];
    }

    return [
        'credentialSource' => 'not_configured',
        'authMode' => 'api_key',
        'apiKey' => '',
        'folderId' => '',
        'baseUrl' => wordstat_default_base_url(),
    ];
}

function wordstat_safe_credentials_metadata(): array
{
    $credentials = wordstat_credentials();
    $apiKey = (string) ($credentials['apiKey'] ?? '');
    $folderId = (string) ($credentials['folderId'] ?? '');
    $source = (string) ($credentials['credentialSource'] ?? 'not_configured');

    return [
        'credentialSource' => $source,
        'authMode' => wordstat_clean_string((string) ($credentials['authMode'] ?? 'api_key'), 80),
        'apiKeyConfigured' => $apiKey !== '',
        'folderIdConfigured' => $folderId !== '',
        'baseUrlConfigured' => trim((string) ($credentials['baseUrl'] ?? '')) !== '',
        'maskedCredentialLabel' => $apiKey !== '' ? ($source . ':' . wordstat_mask_secret($apiKey)) : null,
        'configured' => $apiKey !== '' && $folderId !== '',
    ];
}

function wordstat_is_configured(): bool
{
    return !empty(wordstat_safe_credentials_metadata()['configured']);
}

function wordstat_get_auth_headers(): array
{
    $credentials = wordstat_credentials();
    $apiKey = trim((string) ($credentials['apiKey'] ?? ''));
    $authMode = strtolower(trim((string) ($credentials['authMode'] ?? 'api_key')));
    $headers = [
        'Content-Type: application/json',
        'Accept: application/json',
    ];
    if ($apiKey !== '') {
        $headers[] = $authMode === 'bearer'
            ? 'Authorization: Bearer ' . $apiKey
            : 'Authorization: Api-Key ' . $apiKey;
    }

    return $headers;
}

function wordstat_current_settings(): array
{
    $settings = demand_integrations_get_source_status('wordstat');
    $metadata = wordstat_safe_credentials_metadata();

    return array_merge($settings, [
        'credentialSource' => $metadata['credentialSource'],
        'folderIdConfigured' => $metadata['folderIdConfigured'],
        'apiKeyConfigured' => $metadata['apiKeyConfigured'],
        'baseUrlConfigured' => $metadata['baseUrlConfigured'],
        'maskedCredentialLabel' => $metadata['maskedCredentialLabel'],
    ]);
}

function wordstat_provider_configuration_version(): string
{
    return business_form_version([DEMAND_INTEGRATIONS_SETTINGS_FILE, wordstat_credentials_path()]);
}

function wordstat_update_source_settings(array $fields): array
{
    foreach (['apiKey', 'token', 'secret', 'Authorization', 'credentials', 'password'] as $secretKey) {
        unset($fields[$secretKey]);
    }

    $settings = demand_integrations_get_settings();
    $current = $settings['rent_rk']['sources']['wordstat'] ?? demand_integrations_default_source_settings('wordstat');
    $settings['rent_rk']['sources']['wordstat'] = demand_integrations_normalize_source_settings('wordstat', array_merge($current, $fields));
    $settings['updatedAt'] = now_iso();
    $settings['updatedBy'] = current_admin_user() ?: 'system';
    write_json_file(DEMAND_INTEGRATIONS_SETTINGS_FILE, $settings);

    return $settings['rent_rk']['sources']['wordstat'];
}

function wordstat_sanitize_error_message(string $message): string
{
    $message = trim($message);
    $credentials = wordstat_credentials();
    foreach (['apiKey'] as $secretKey) {
        $secret = trim((string) ($credentials[$secretKey] ?? ''));
        if ($secret !== '' && strlen($secret) >= 6) {
            $message = str_replace($secret, '***', $message);
        }
    }
    $message = preg_replace('/Authorization:\s*(Api-Key|Bearer)\s+[^,\s;]+/i', 'Authorization: $1 ***', $message) ?? $message;
    $message = preg_replace('/(api[_-]?key|token|secret|password)=([^,\s;]+)/i', '$1=***', $message) ?? $message;
    $message = preg_replace('/\b[A-Za-z0-9_=-]{48,}\b/', '***', $message) ?? $message;

    return wordstat_clean_string($message, 700);
}

function wordstat_connection_error_details(string $message): array
{
    $technical = wordstat_sanitize_error_message($message);
    $lower = strtolower($technical);
    $code = 'connection_failed';
    $human = 'Подключение не прошло. Проверьте API key, folderId и Base URL.';
    $advice = 'Убедитесь, что в мастере указан свежий API key сервисного аккаунта, правильный folderId каталога и Base URL https://searchapi.api.cloud.yandex.net/v2/wordstat.';

    if (str_contains($lower, 'credentials_not_configured') || str_contains($lower, 'not_configured') || str_contains($lower, 'credentials are not configured')) {
        $code = 'credentials_not_configured';
        $human = 'Не хватает API key или Folder ID.';
        $advice = 'Создайте API-ключ сервисного аккаунта Yandex Cloud, скопируйте folderId каталога из console.yandex.cloud и сохраните их в мастере. Публичный RSA-ключ сюда не подходит.';
    } elseif (str_contains($lower, 'base_url_not_configured') || str_contains($lower, 'base url')) {
        $code = 'base_url_not_configured';
        $human = 'Не указан Base URL Wordstat API.';
        $advice = 'Для Yandex Cloud Search API укажите Base URL: https://searchapi.api.cloud.yandex.net/v2/wordstat.';
    } elseif (str_contains($lower, 'auth failed') || str_contains($lower, 'http_401') || str_contains($lower, 'http_403')) {
        $code = str_contains($lower, 'http_403') ? 'auth_forbidden' : 'auth_failed';
        $human = 'Яндекс отклонил авторизацию.';
        $advice = 'Проверьте, что вставлен именно секретный API key, а не RSA public/private key, что ключ не удалён и у сервисного аккаунта есть доступ к Search API (`yc.search-api.execute`) в нужном folderId.';
    } elseif (str_contains($lower, 'first day of the month')) {
        $code = 'dynamics_period_boundary';
        $human = 'Wordstat отклонил период динамики: дата начала должна быть первым днём месяца.';
        $advice = 'Повторите live sync после обновления кода. Rent RK теперь отправляет для GetDynamics только помесячный диапазон: fromDate = первое число месяца, toDate = конец месяца.';
    } elseif (str_contains($lower, 'http_400')) {
        $code = 'bad_request';
        $human = 'Yandex Cloud вернул ошибку запроса 400.';
        $advice = 'Чаще всего это неверный folderId, неподходящий ключ для Search API или несовпадение формата API. Проверьте folderId каталога и права сервисного аккаунта.';
    } elseif (str_contains($lower, 'http_404')) {
        $code = 'endpoint_not_found';
        $human = 'Endpoint Wordstat API не найден.';
        $advice = 'Проверьте Base URL. Для текущей интеграции нужен базовый адрес https://searchapi.api.cloud.yandex.net/v2/wordstat без `/topRequests` в конце.';
    } elseif (str_contains($lower, 'rate limited') || str_contains($lower, 'http_429')) {
        $code = 'rate_limited';
        $human = 'Yandex Cloud ограничил частоту запросов.';
        $advice = 'Подождите и повторите позже. Для live sync уменьшите per-run лимит и увеличьте паузу между запросами.';
    } elseif (str_contains($lower, 'temporary error') || preg_match('/http_5\d\d/', $lower)) {
        $code = 'temporary_provider_error';
        $human = 'На стороне API временная ошибка.';
        $advice = 'Повторите проверку позже. Если ошибка повторяется, проверьте статус сервиса Yandex Cloud и настройки доступа.';
    } elseif (str_contains($lower, 'transport_error') || str_contains($lower, 'could not resolve') || str_contains($lower, 'failed to connect') || str_contains($lower, 'timed out') || str_contains($lower, 'timeout')) {
        $code = 'network_error';
        $human = 'Сервер Rent RK не смог достучаться до Yandex Cloud.';
        $advice = 'Проверьте доступ сервера к интернету, корректность Base URL и отсутствие блокировки исходящих HTTPS-запросов.';
    } elseif (str_contains($lower, 'curl extension')) {
        $code = 'curl_missing';
        $human = 'На сервере недоступно PHP cURL.';
        $advice = 'Включите расширение PHP cURL на хостинге или сервере, иначе live-проверка внешнего API невозможна.';
    } elseif (str_contains($lower, 'empty_response') || str_contains($lower, 'invalid_json_response')) {
        $code = str_contains($lower, 'empty_response') ? 'empty_response' : 'invalid_json_response';
        $human = 'API вернул пустой или не-JSON ответ.';
        $advice = 'Проверьте Base URL: он должен указывать на Yandex Cloud Search API Wordstat, а не на страницу документации, AI Studio UI или другой endpoint.';
    } elseif (str_contains($lower, 'api_error')) {
        $code = 'api_error';
        $human = 'Yandex Cloud вернул прикладную ошибку API.';
        $advice = 'Посмотрите техническую деталь ниже и проверьте права сервисного аккаунта, folderId и параметры запроса.';
    }

    return [
        'code' => $code,
        'message' => $human,
        'advice' => $advice,
        'technical' => $technical,
    ];
}

function wordstat_record_connection_failure(string $message, string $authStatus = 'test_failed', string $severity = 'error'): array
{
    $details = wordstat_connection_error_details($message);
    wordstat_refresh_credentials_metadata($authStatus);
    demand_integrations_record_error('wordstat', 'rent_rk', (string) $details['code'], (string) $details['message'], [
        'advice' => (string) $details['advice'],
        'technical' => (string) $details['technical'],
    ], $severity);
    wordstat_update_source_settings([
        'authStatus' => $authStatus,
        'lastError' => (string) $details['message'],
        'lastErrorAt' => now_iso(),
        'lastErrorCode' => (string) $details['code'],
        'lastErrorAdvice' => (string) $details['advice'],
        'lastErrorTechnical' => (string) $details['technical'],
    ]);

    return [
        'ok' => false,
        'authStatus' => $authStatus,
        'message' => (string) $details['message'],
        'errorCode' => (string) $details['code'],
        'advice' => (string) $details['advice'],
        'technical' => (string) $details['technical'],
    ];
}

function wordstat_refresh_credentials_metadata(?string $authStatus = null): array
{
    $metadata = wordstat_safe_credentials_metadata();
    $fields = [
        'credentialSource' => $metadata['credentialSource'],
        'folderIdConfigured' => $metadata['folderIdConfigured'],
        'apiKeyConfigured' => $metadata['apiKeyConfigured'],
        'baseUrlConfigured' => $metadata['baseUrlConfigured'],
        'maskedCredentialLabel' => $metadata['maskedCredentialLabel'],
    ];
    if ($authStatus !== null) {
        $fields['authStatus'] = $authStatus;
    }

    return wordstat_update_source_settings($fields);
}

function wordstat_mock_response(string $method, array $payload = []): array
{
    $phrase = wordstat_clean_string((string) ($payload['phrase'] ?? $payload['seedPhrase'] ?? 'аренда авто ялта'), 240);
    $normalized = function_exists('demand_normalize_phrase') ? demand_normalize_phrase($phrase) : strtolower(trim($phrase));

    if ($method === 'GetRegionsTree') {
        return [
            'regions' => [
                ['id' => '225', 'name' => 'Россия', 'parentId' => null, 'path' => ['Россия']],
                ['id' => '977', 'name' => 'Крым', 'parentId' => '225', 'path' => ['Россия', 'Крым']],
                ['id' => '11470', 'name' => 'Ялта', 'parentId' => '977', 'path' => ['Россия', 'Крым', 'Ялта']],
                ['id' => '146', 'name' => 'Симферополь', 'parentId' => '977', 'path' => ['Россия', 'Крым', 'Симферополь']],
                ['id' => '11471', 'name' => 'Алушта', 'parentId' => '977', 'path' => ['Россия', 'Крым', 'Алушта']],
            ],
        ];
    }

    if ($method === 'GetTop') {
        $items = [
            ['phrase' => $phrase, 'frequency30d' => str_contains($normalized, 'без залога') ? 64 : 128],
            ['phrase' => 'аренда авто ялта', 'frequency30d' => 120],
            ['phrase' => 'прокат авто ялта', 'frequency30d' => 92],
            ['phrase' => 'аренда минивэна ялта', 'frequency30d' => 48],
        ];
        if (str_contains($normalized, 'без залога')) {
            $items[] = ['phrase' => 'аренда авто без залога ялта', 'frequency30d' => 70];
        }
        if (str_contains($normalized, 'дешев') || str_contains($normalized, 'недорог')) {
            $items[] = ['phrase' => 'аренда авто недорого ялта', 'frequency30d' => 86];
        }

        return ['items' => $items];
    }

    if ($method === 'GetDynamics') {
        return [
            'dynamics' => [
                ['period' => '2026-02', 'frequency' => 78],
                ['period' => '2026-03', 'frequency' => 93],
                ['period' => '2026-04', 'frequency' => 117],
                ['period' => '2026-05', 'frequency' => 128],
            ],
            'trend' => 'growing',
            'seasonality' => ['spring_growth', 'summer_peak'],
        ];
    }

    if ($method === 'GetRegionsDistribution') {
        return [
            'regionsDistribution' => [
                ['regionId' => '11470', 'regionName' => 'Ялта', 'frequency30d' => 88, 'share' => 0.55],
                ['regionId' => '977', 'regionName' => 'Крым', 'frequency30d' => 38, 'share' => 0.24],
                ['regionId' => '146', 'regionName' => 'Симферополь', 'frequency30d' => 34, 'share' => 0.21],
            ],
        ];
    }

    return ['items' => []];
}

function wordstat_build_yandex_cloud_payload(string $method, array $payload, string $folderId): array
{
    $body = [
        'folderId' => $folderId,
    ];
    if ($method === 'GetRegionsTree') {
        return $body;
    }

    $phrase = wordstat_clean_string((string) ($payload['phrase'] ?? $payload['seedPhrase'] ?? ''), 240);
    if ($phrase !== '') {
        $body['phrase'] = $phrase;
    }

    $regionIds = $payload['regionIds'] ?? [];
    if (is_array($regionIds)) {
        $regionIds = array_values(array_unique(array_filter(array_map('strval', $regionIds))));
        if ($regionIds) {
            $body['regions'] = $regionIds;
        }
    }
    $body['devices'] = ['DEVICE_ALL'];

    if ($method === 'GetTop') {
        $body['numPhrases'] = (string) max(1, min(2000, (int) ($payload['numPhrases'] ?? 50)));
    } elseif ($method === 'GetDynamics') {
        $range = wordstat_monthly_dynamics_range($payload);
        $body['period'] = (string) ($payload['period'] ?? 'PERIOD_MONTHLY');
        $body['fromDate'] = $range['fromDate'];
        $body['toDate'] = $range['toDate'];
    } elseif ($method === 'GetRegionsDistribution') {
        unset($body['regions']);
        $body['region'] = (string) ($payload['region'] ?? 'REGION_ALL');
    }

    return $body;
}

function wordstat_http_request(string $method, array $payload = [], array $options = []): array
{
    if (!empty($options['mock']) || !empty($options['mockLive']) || !empty($options['dryRun'])) {
        return wordstat_mock_response($method, $payload);
    }

    $credentials = wordstat_credentials();
    $baseUrl = wordstat_normalize_base_url((string) ($credentials['baseUrl'] ?? ''));
    $folderId = trim((string) ($credentials['folderId'] ?? ''));
    if ($baseUrl === '') {
        throw new RuntimeException('Wordstat base URL is not configured.');
    }
    if (!wordstat_is_configured()) {
        throw new RuntimeException('Wordstat credentials are not configured.');
    }
    $timeout = max(3, min(60, (int) ($options['timeoutSeconds'] ?? 15)));
    $body = json_encode(
        wordstat_build_yandex_cloud_payload($method, $payload, $folderId),
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    if ($body === false) {
        throw new RuntimeException('Could not encode Wordstat request.');
    }

    $url = $baseUrl . '/' . wordstat_method_path($method);
    $headers = wordstat_get_auth_headers();
    $configurationVersion = wordstat_provider_configuration_version();
    $transport = RentalReturnStore::waitOutsideLock(static function () use ($method, $url, $body, $headers, $timeout): array {
        $controlled = demand_integrations_controlled_transport('wordstat', [
            'method' => 'POST',
            'operation' => $method,
            'url' => $url,
            'body' => $body,
            'headerNames' => array_values(array_map(static fn(string $header): string => trim((string) strtok($header, ':')), $headers)),
            'timeoutSeconds' => $timeout,
        ]);
        if ($controlled !== null) {
            return [
                'response' => $controlled['body'] ?? false,
                'errno' => (int) ($controlled['errno'] ?? 0),
                'error' => (string) ($controlled['error'] ?? ''),
                'status' => (int) ($controlled['status'] ?? 0),
            ];
        }
        if (!function_exists('curl_init')) {
            throw new RuntimeException('PHP cURL extension is not available for Wordstat requests.');
        }
        $curl = curl_init($url);
        if (!$curl) {
            throw new RuntimeException('Could not initialize Wordstat request.');
        }
        try {
            curl_setopt_array($curl, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_CONNECTTIMEOUT => min(10, $timeout),
            ]);
            return [
                'response' => curl_exec($curl),
                'errno' => curl_errno($curl),
                'error' => curl_error($curl),
                'status' => (int) curl_getinfo($curl, CURLINFO_HTTP_CODE),
            ];
        } finally {
            curl_close($curl);
        }
    });
    if (!hash_equals($configurationVersion, wordstat_provider_configuration_version())) {
        throw new RuntimeException('Wordstat settings changed while the provider request was running.', 409);
    }
    $response = $transport['response'] ?? false;
    $errno = (int) ($transport['errno'] ?? 0);
    $error = (string) ($transport['error'] ?? '');
    $status = (int) ($transport['status'] ?? 0);

    if ($errno !== 0) {
        throw new RuntimeException('Wordstat request failed: transport_error_' . $errno . ($error !== '' ? (' ' . substr($error, 0, 120)) : ''));
    }
    if (!is_string($response) || trim($response) === '') {
        throw new RuntimeException('Wordstat request failed: empty_response');
    }
    $data = json_decode($response, true);
    if (!is_array($data)) {
        throw new RuntimeException('Wordstat request failed: invalid_json_response');
    }
    $apiError = $data['error']['message'] ?? $data['message'] ?? null;
    if ($status === 401 || $status === 403) {
        throw new RuntimeException('Wordstat auth failed: http_' . $status . ($apiError ? (' ' . substr((string) $apiError, 0, 140)) : ''));
    }
    if ($status === 429) {
        throw new RuntimeException('Wordstat rate limited: http_429');
    }
    if ($status >= 500) {
        throw new RuntimeException('Wordstat temporary error: http_' . $status . ($apiError ? (' ' . substr((string) $apiError, 0, 140)) : ''));
    }
    if ($status >= 400) {
        throw new RuntimeException('Wordstat request failed: http_' . $status . ($apiError ? (' ' . substr((string) $apiError, 0, 140)) : ''));
    }
    if (isset($data['error']) && is_array($data['error'])) {
        throw new RuntimeException('Wordstat request failed: api_error' . ($apiError ? (' ' . substr((string) $apiError, 0, 140)) : ''));
    }

    return $data;
}

function wordstat_normalize_region_name(string $name): string
{
    return demand_normalize_phrase($name);
}

function wordstat_flatten_region_rows(array $rows, array $path = [], ?string $parentId = null): array
{
    $regions = [];
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $id = wordstat_clean_string((string) ($row['id'] ?? $row['regionId'] ?? $row['geoId'] ?? ''), 80);
        $name = wordstat_clean_string((string) ($row['name'] ?? $row['regionName'] ?? $row['label'] ?? $row['title'] ?? ''), 160);
        if ($id === '' || $name === '') {
            $children = $row['children'] ?? $row['regions'] ?? [];
            if (is_array($children)) {
                $regions = array_merge($regions, wordstat_flatten_region_rows($children, $path, $parentId));
            }
            continue;
        }
        $rowPath = $row['path'] ?? array_merge($path, [$name]);
        if (!is_array($rowPath)) {
            $rowPath = $rowPath !== '' ? [(string) $rowPath] : array_merge($path, [$name]);
        }
        $rowParentId = ($row['parentId'] ?? $row['parentRegionId'] ?? $parentId) !== null
            ? wordstat_clean_string((string) ($row['parentId'] ?? $row['parentRegionId'] ?? $parentId), 80)
            : null;
        $regions[] = [
            'id' => $id,
            'name' => $name,
            'parentId' => $rowParentId,
            'path' => array_values(array_map(static fn($value): string => wordstat_clean_string((string) $value, 160), $rowPath)),
            'normalizedName' => wordstat_normalize_region_name($name),
        ];
        $children = $row['children'] ?? $row['regions'] ?? [];
        if (is_array($children) && $children) {
            $regions = array_merge($regions, wordstat_flatten_region_rows($children, $rowPath, $id));
        }
    }

    return $regions;
}

function wordstat_normalize_regions_tree_response(array $response): array
{
    $rawRegions = $response['regions'] ?? $response['items'] ?? $response['results'] ?? $response['data'] ?? [];
    if (!is_array($rawRegions)) {
        $rawRegions = [];
    }

    return wordstat_flatten_region_rows($rawRegions);
}

function wordstat_read_regions_cache(): array
{
    $default = [
        'lastUpdatedAt' => null,
        'source' => 'wordstat_get_regions_tree',
        'regions' => [],
        'lookup' => [],
    ];
    $data = is_file(WORDSTAT_REGIONS_CACHE_FILE) ? read_json_file(WORDSTAT_REGIONS_CACHE_FILE, $default) : $default;
    $data['regions'] = isset($data['regions']) && is_array($data['regions']) ? $data['regions'] : [];
    $data['lookup'] = isset($data['lookup']) && is_array($data['lookup']) ? $data['lookup'] : [];

    return $data;
}

function wordstat_save_regions_cache(array $regions): array
{
    $lookup = [];
    foreach ($regions as $region) {
        if (!is_array($region)) {
            continue;
        }
        $normalized = (string) ($region['normalizedName'] ?? '');
        if ($normalized !== '') {
            $lookup[$normalized] = (string) ($region['id'] ?? '');
        }
    }

    $cache = [
        'lastUpdatedAt' => now_iso(),
        'source' => 'wordstat_get_regions_tree',
        'regions' => array_values($regions),
        'lookup' => $lookup,
    ];
    write_json_file(WORDSTAT_REGIONS_CACHE_FILE, $cache);

    return $cache;
}

function wordstat_get_regions_tree(array $options = []): array
{
    $response = wordstat_http_request('GetRegionsTree', [], $options);
    $regions = wordstat_normalize_regions_tree_response($response);
    if (!empty($options['saveCache'])) {
        if (!$regions) {
            throw new RuntimeException('Wordstat regions response did not contain usable regions.');
        }
        wordstat_save_regions_cache($regions);
    }

    return $regions;
}

function wordstat_frequency_from_row(array $row): int
{
    foreach (['frequency30d', 'frequency', 'shows', 'showsCount', 'impressions', 'count', 'value'] as $key) {
        if (isset($row[$key]) && is_numeric($row[$key])) {
            return max(0, (int) round((float) $row[$key]));
        }
    }

    return 0;
}

function wordstat_normalize_get_top_response(array $response): array
{
    $rawItems = [];
    foreach (['items', 'phrases', 'results', 'data', 'associations'] as $key) {
        if (isset($response[$key]) && is_array($response[$key])) {
            $rawItems = array_merge($rawItems, $response[$key]);
        }
    }
    if (!is_array($rawItems)) {
        $rawItems = [];
    }
    $items = [];
    foreach ($rawItems as $row) {
        if (is_string($row)) {
            $row = ['phrase' => $row, 'frequency30d' => 0];
        }
        if (!is_array($row)) {
            continue;
        }
        $query = $row['query'] ?? null;
        if (is_array($query)) {
            $query = $query['text'] ?? $query['phrase'] ?? '';
        }
        $phrase = wordstat_clean_string((string) ($row['phrase'] ?? $query ?? $row['text'] ?? $row['searchQuery'] ?? $row['request'] ?? $row['keyword'] ?? ''), 240);
        if ($phrase === '') {
            continue;
        }
        $items[] = [
            'phrase' => $phrase,
            'normalizedPhrase' => demand_normalize_phrase($phrase),
            'frequency30d' => wordstat_frequency_from_row($row),
            'regionIds' => isset($row['regionIds']) && is_array($row['regionIds']) ? array_values(array_map('strval', $row['regionIds'])) : [],
        ];
    }

    return $items;
}

function wordstat_normalize_dynamics_response(array $response): array
{
    $raw = $response['dynamics'] ?? $response['items'] ?? $response['results'] ?? $response['data'] ?? [];
    if (!is_array($raw)) {
        $raw = [];
    }
    $dynamics = [];
    foreach ($raw as $row) {
        if (!is_array($row)) {
            continue;
        }
        $date = $row['date'] ?? '';
        if (is_array($date)) {
            $year = (string) ($date['year'] ?? '');
            $month = str_pad((string) ($date['month'] ?? ''), 2, '0', STR_PAD_LEFT);
            $day = str_pad((string) ($date['day'] ?? ''), 2, '0', STR_PAD_LEFT);
            $date = $year !== '' && $month !== '00' ? ($year . '-' . $month . ($day !== '00' ? '-' . $day : '')) : '';
        }
        $period = wordstat_clean_string((string) ($row['period'] ?? $date ?? $row['month'] ?? ''), 40);
        if ($period === '') {
            continue;
        }
        $dynamics[] = [
            'period' => $period,
            'frequency' => wordstat_frequency_from_row($row),
        ];
    }

    return [
        'dynamics' => $dynamics,
        'trend' => wordstat_clean_string((string) ($response['trend'] ?? ''), 80) ?: null,
        'seasonality' => isset($response['seasonality']) && is_array($response['seasonality']) ? array_values($response['seasonality']) : [],
    ];
}

function wordstat_normalize_regions_distribution_response(array $response): array
{
    $raw = $response['regionsDistribution'] ?? $response['regions'] ?? $response['items'] ?? $response['results'] ?? $response['data'] ?? [];
    if (!is_array($raw)) {
        $raw = [];
    }
    $items = [];
    foreach ($raw as $row) {
        if (!is_array($row)) {
            continue;
        }
        $region = $row['region'] ?? null;
        $regionId = wordstat_clean_string((string) ($row['regionId'] ?? $row['id'] ?? (is_array($region) ? ($region['id'] ?? $region['regionId'] ?? '') : $region)), 80);
        $regionName = wordstat_clean_string((string) ($row['regionName'] ?? $row['name'] ?? (is_array($region) ? ($region['label'] ?? $region['name'] ?? '') : '')), 160);
        if ($regionName === '' && $regionId !== '') {
            $regionName = wordstat_region_name_by_id($regionId);
        }
        if ($regionId === '' && $regionName === '') {
            continue;
        }
        $items[] = [
            'regionId' => $regionId,
            'regionName' => $regionName,
            'frequency30d' => wordstat_frequency_from_row($row),
            'share' => isset($row['share']) && is_numeric($row['share']) ? (float) $row['share'] : null,
        ];
    }

    return $items;
}

function wordstat_get_top(string $phrase, array $regionIds = [], array $options = []): array
{
    $response = wordstat_http_request('GetTop', [
        'phrase' => $phrase,
        'regionIds' => array_values($regionIds),
    ], $options);

    return wordstat_normalize_get_top_response($response);
}

function wordstat_get_dynamics(string $phrase, array $regionIds = [], array $options = []): array
{
    $response = wordstat_http_request('GetDynamics', [
        'phrase' => $phrase,
        'regionIds' => array_values($regionIds),
    ], $options);

    return wordstat_normalize_dynamics_response($response);
}

function wordstat_get_regions_distribution(string $phrase, array $options = []): array
{
    $response = wordstat_http_request('GetRegionsDistribution', [
        'phrase' => $phrase,
    ], $options);

    return wordstat_normalize_regions_distribution_response($response);
}

function wordstat_cost_rates(): array
{
    return [
        'GetTop' => 0.02,
        'GetDynamics' => 0.02,
        'GetRegionsDistribution' => 0.02,
        'GetRegionsTree' => 0.01,
    ];
}

function wordstat_method_api_name(string $method): string
{
    return match ($method) {
        'getTop' => 'GetTop',
        'getDynamics' => 'GetDynamics',
        'getRegionsDistribution' => 'GetRegionsDistribution',
        'getRegionsTree' => 'GetRegionsTree',
        default => $method,
    };
}

function wordstat_estimate_cost(string $method, int $requestCount): float
{
    $apiMethod = wordstat_method_api_name($method);
    $rates = wordstat_cost_rates();

    return round(max(0, $requestCount) * (float) ($rates[$apiMethod] ?? 0.02), 4);
}

function wordstat_read_cost_ledger(): array
{
    return demand_read_container(WORDSTAT_COST_LEDGER_FILE);
}

function wordstat_save_cost_ledger(array $data): void
{
    demand_write_container(WORDSTAT_COST_LEDGER_FILE, $data);
}

function wordstat_record_cost(string $runId, string $method, int $requestCount, string $scopeId = 'rent_rk'): array
{
    $apiMethod = wordstat_method_api_name($method);
    $entry = [
        'id' => 'wcl_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'scope_id' => demand_normalize_scope_id($scopeId),
        'runId' => $runId,
        'method' => $apiMethod,
        'requestCount' => max(0, $requestCount),
        'estimatedCostRub' => wordstat_estimate_cost($apiMethod, $requestCount),
        'createdAt' => now_iso(),
    ];
    $data = wordstat_read_cost_ledger();
    array_unshift($data['items'], $entry);
    $data['items'] = array_slice($data['items'], 0, 10000);
    wordstat_save_cost_ledger($data);
    analytics_record_event('wordstat_cost_recorded', [
        'scopeId' => $entry['scope_id'],
        'entityType' => 'wordstat_cost',
        'entityId' => $entry['id'],
        'meta' => [
            'runId' => $runId,
            'method' => $apiMethod,
            'requestCount' => $entry['requestCount'],
            'estimatedCostRub' => $entry['estimatedCostRub'],
        ],
    ]);

    return $entry;
}

function wordstat_cost_totals(): array
{
    $today = date('Y-m-d');
    $month = date('Y-m');
    $totals = [
        'dailyRequests' => 0,
        'monthlyRequests' => 0,
        'monthlyCostRub' => 0.0,
    ];
    foreach (wordstat_read_cost_ledger()['items'] as $item) {
        if (!is_array($item)) {
            continue;
        }
        $createdAt = (string) ($item['createdAt'] ?? '');
        $requests = max(0, (int) ($item['requestCount'] ?? 0));
        $cost = max(0.0, (float) ($item['estimatedCostRub'] ?? 0));
        if (str_starts_with($createdAt, $today)) {
            $totals['dailyRequests'] += $requests;
        }
        if (str_starts_with($createdAt, $month)) {
            $totals['monthlyRequests'] += $requests;
            $totals['monthlyCostRub'] += $cost;
        }
    }
    $totals['monthlyCostRub'] = round($totals['monthlyCostRub'], 4);

    return $totals;
}

function wordstat_check_limits_before_run(int $plannedRequests, ?float $estimatedCostRub = null, ?array $settings = null): array
{
    $settings = $settings ?? wordstat_current_settings();
    $plannedRequests = max(0, $plannedRequests);
    $estimatedCostRub = $estimatedCostRub ?? wordstat_estimate_cost('GetTop', $plannedRequests);
    $totals = wordstat_cost_totals();
    $errors = [];

    $perRunLimit = max(0, (int) ($settings['perRunRequestLimit'] ?? 20));
    $dailyLimit = max(0, (int) ($settings['dailyRequestLimit'] ?? 100));
    $monthlyLimit = max(0, (int) ($settings['monthlyRequestLimit'] ?? 1000));
    $costLimit = max(0.0, (float) ($settings['estimatedCostLimitRub'] ?? 500));

    if ($perRunLimit > 0 && $plannedRequests > $perRunLimit) {
        $errors[] = 'per_run_limit_exceeded';
    }
    if ($dailyLimit > 0 && ($totals['dailyRequests'] + $plannedRequests) > $dailyLimit) {
        $errors[] = 'daily_limit_exceeded';
    }
    if ($monthlyLimit > 0 && ($totals['monthlyRequests'] + $plannedRequests) > $monthlyLimit) {
        $errors[] = 'monthly_limit_exceeded';
    }
    if ($costLimit > 0 && ($totals['monthlyCostRub'] + $estimatedCostRub) > $costLimit) {
        $errors[] = 'estimated_cost_limit_exceeded';
    }

    return [
        'ok' => $errors === [],
        'errors' => $errors,
        'plannedRequests' => $plannedRequests,
        'estimatedCostRub' => round($estimatedCostRub, 4),
        'totals' => $totals,
        'limits' => [
            'perRunRequestLimit' => $perRunLimit,
            'dailyRequestLimit' => $dailyLimit,
            'monthlyRequestLimit' => $monthlyLimit,
            'estimatedCostLimitRub' => $costLimit,
        ],
    ];
}

function wordstat_read_query_queue(): array
{
    return demand_read_container(WORDSTAT_QUERY_QUEUE_FILE);
}

function wordstat_save_query_queue(array $data): void
{
    demand_write_container(WORDSTAT_QUERY_QUEUE_FILE, $data);
}

function wordstat_enqueue_query(string $scopeId, string $phrase, array $regionIds, array $methods, string $priority = 'normal'): array
{
    $scopeId = demand_normalize_scope_id($scopeId);
    $phrase = wordstat_clean_string($phrase, 240);
    $regionIds = array_values(array_unique(array_filter(array_map('strval', $regionIds))));
    sort($regionIds);
    $methods = array_values(array_unique(array_intersect($methods, wordstat_supported_methods())));
    sort($methods);
    $dedupe = implode('|', [$scopeId, demand_normalize_phrase($phrase), implode(',', $regionIds), implode(',', $methods)]);
    $data = wordstat_read_query_queue();

    foreach ($data['items'] as $index => $item) {
        if (is_array($item) && (string) ($item['dedupeKey'] ?? '') === $dedupe) {
            $item['updatedAt'] = now_iso();
            $item['status'] = in_array((string) ($item['status'] ?? ''), ['success', 'partial_success'], true) ? (string) $item['status'] : 'queued';
            $data['items'][$index] = $item;
            wordstat_save_query_queue($data);

            return $item;
        }
    }

    $item = [
        'id' => 'wq_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'scope_id' => $scopeId,
        'phrase' => $phrase,
        'regionIds' => $regionIds,
        'methods' => $methods,
        'status' => 'queued',
        'priority' => in_array($priority, ['low', 'normal', 'high'], true) ? $priority : 'normal',
        'attempts' => 0,
        'lastAttemptAt' => null,
        'dedupeKey' => $dedupe,
        'createdAt' => now_iso(),
        'updatedAt' => now_iso(),
    ];
    array_unshift($data['items'], $item);
    $data['items'] = array_slice($data['items'], 0, 5000);
    wordstat_save_query_queue($data);

    return $item;
}

function wordstat_update_query_status(string $queryId, string $status): void
{
    if (!in_array($status, ['queued', 'running', 'success', 'partial_success', 'failed', 'skipped', 'rate_limited', 'cancelled'], true)) {
        $status = 'failed';
    }
    $data = wordstat_read_query_queue();
    foreach ($data['items'] as $index => $item) {
        if (!is_array($item) || (string) ($item['id'] ?? '') !== $queryId) {
            continue;
        }
        $item['status'] = $status;
        $item['attempts'] = max(0, (int) ($item['attempts'] ?? 0)) + 1;
        $item['lastAttemptAt'] = now_iso();
        $item['updatedAt'] = now_iso();
        $data['items'][$index] = $item;
        break;
    }
    wordstat_save_query_queue($data);
}

function wordstat_parse_seed_phrases($value): array
{
    if (is_array($value)) {
        $parts = $value;
    } else {
        $parts = preg_split('/[\r\n,;]+/u', (string) $value) ?: [];
    }
    $phrases = [];
    foreach ($parts as $part) {
        $phrase = wordstat_clean_string($part, 240);
        if ($phrase !== '') {
            $phrases[demand_normalize_phrase($phrase)] = $phrase;
        }
    }

    return array_values($phrases);
}

function wordstat_parse_region_ids($value): array
{
    if (is_array($value)) {
        $parts = $value;
    } else {
        $parts = preg_split('/[\s,;]+/u', (string) $value) ?: [];
    }

    return array_values(array_unique(array_filter(array_map(static fn($part): string => wordstat_clean_string($part, 80), $parts))));
}

function wordstat_normalize_methods($value): array
{
    $methods = is_array($value) ? $value : preg_split('/[\s,;]+/u', (string) $value);
    $methods = is_array($methods) ? $methods : [];
    $allowed = wordstat_supported_methods();
    $normalized = [];
    foreach ($methods as $method) {
        $method = wordstat_clean_string((string) $method, 80);
        if (in_array($method, $allowed, true)) {
            $normalized[] = $method;
        }
    }

    return array_values(array_unique($normalized)) ?: $allowed;
}

function wordstat_build_sync_plan(string $scopeId, $seedPhrases, $regionIds, $methods): array
{
    $settings = wordstat_current_settings();
    $phrases = wordstat_parse_seed_phrases($seedPhrases);
    if (!$phrases) {
        $defaultSeed = $settings['defaultSeedPhrases'] ?? [];
        $phrases = wordstat_parse_seed_phrases($defaultSeed);
    }
    $regions = wordstat_parse_region_ids($regionIds);
    if (!$regions) {
        $regions = wordstat_parse_region_ids($settings['defaultRegionIds'] ?? []);
    }
    $methods = wordstat_normalize_methods($methods);
    $warnings = [];
    if (!$phrases) {
        $warnings[] = 'seed_phrases_empty';
    }
    if (!$regions) {
        $warnings[] = 'regions_empty';
    }

    $plannedRequests = count($phrases) * count($methods);
    $estimatedCostRub = 0.0;
    foreach ($methods as $method) {
        $estimatedCostRub += wordstat_estimate_cost($method, count($phrases));
    }
    $planBreakdown = [
        'phraseCount' => count($phrases),
        'methodCount' => count($methods),
        'regionCount' => count($regions),
        'formula' => count($phrases) . ' фраз × ' . count($methods) . ' метода',
        'explanation' => 'Регионы передаются внутрь каждого Wordstat-запроса, поэтому смена региона меняет географию, но не всегда меняет количество запросов.',
    ];

    return [
        'scope_id' => demand_normalize_scope_id($scopeId),
        'seedPhrases' => $phrases,
        'regionIds' => $regions,
        'methods' => $methods,
        'plannedRequests' => $plannedRequests,
        'estimatedCostRub' => round($estimatedCostRub, 4),
        'planBreakdown' => $planBreakdown,
        'warnings' => $warnings,
    ];
}

function wordstat_patch_sync_run(string $runId, array $fields): void
{
    $data = demand_integrations_read_sync_runs();
    foreach ($data['items'] as $index => $run) {
        if (!is_array($run) || (string) ($run['id'] ?? '') !== $runId) {
            continue;
        }
        $data['items'][$index] = array_merge($run, analytics_sanitize_meta($fields) ?: []);
        demand_integrations_save_sync_runs($data);
        return;
    }
}

function wordstat_test_connection(array $options = []): array
{
    require_permission('demand.wordstat.test');
    $configurationVersion = wordstat_provider_configuration_version();
    $metadata = wordstat_safe_credentials_metadata();
    if (empty($metadata['configured'])) {
        $result = wordstat_record_connection_failure('credentials_not_configured', 'not_configured', 'warning');
        analytics_record_event('wordstat_connection_tested', [
            'scopeId' => 'rent_rk',
            'entityType' => 'wordstat',
            'entityId' => 'connection',
            'meta' => ['ok' => false, 'reason' => $result['errorCode'] ?? 'not_configured'],
        ]);

        return $result;
    }
    if (empty($metadata['baseUrlConfigured']) && empty($options['mock'])) {
        $result = wordstat_record_connection_failure('base_url_not_configured', 'test_failed', 'warning');
        analytics_record_event('wordstat_connection_tested', [
            'scopeId' => 'rent_rk',
            'entityType' => 'wordstat',
            'entityId' => 'connection',
            'meta' => ['ok' => false, 'reason' => 'base_url_not_configured'],
        ]);

        return $result;
    }

    try {
        $mock = !empty($options['mock']);
        wordstat_get_regions_tree([
            'mock' => $mock,
            'timeoutSeconds' => 8,
        ]);
        return RentalReturnStore::transaction(static function () use ($configurationVersion, $mock): array {
            if (!hash_equals($configurationVersion, wordstat_provider_configuration_version())) {
                return ['ok' => false, 'stale' => true, 'authStatus' => 'not_checked', 'message' => 'Wordstat settings changed while the connection test was running.'];
            }
            wordstat_update_source_settings([
                'authStatus' => 'test_success',
                'lastError' => null,
                'lastErrorAt' => null,
                'lastErrorCode' => null,
                'lastErrorAdvice' => null,
                'lastErrorTechnical' => null,
            ]);
            analytics_record_event('wordstat_connection_tested', [
                'scopeId' => 'rent_rk',
                'entityType' => 'wordstat',
                'entityId' => 'connection',
                'meta' => ['ok' => true, 'mock' => $mock],
            ]);
            return ['ok' => true, 'authStatus' => 'test_success', 'message' => $mock ? 'mock_connection_ok' : 'connection_ok'];
        });
    } catch (Throwable $exception) {
        if (!hash_equals($configurationVersion, wordstat_provider_configuration_version())) {
            return ['ok' => false, 'stale' => true, 'authStatus' => 'not_checked', 'message' => 'Wordstat settings changed while the connection test was running.'];
        }
        return RentalReturnStore::transaction(static function () use ($configurationVersion, $exception): array {
            if (!hash_equals($configurationVersion, wordstat_provider_configuration_version())) {
                return ['ok' => false, 'stale' => true, 'authStatus' => 'not_checked', 'message' => 'Wordstat settings changed while the connection test was running.'];
            }
            $result = wordstat_record_connection_failure($exception->getMessage(), 'test_failed', 'error');
            analytics_record_event('wordstat_connection_tested', [
                'scopeId' => 'rent_rk',
                'entityType' => 'wordstat',
                'entityId' => 'connection',
                'meta' => ['ok' => false, 'reason' => $result['errorCode'] ?? 'connection_failed'],
            ]);
            return $result;
        });
    }
}

function wordstat_load_regions_tree_controlled(array $options = []): array
{
    require_permission('demand.wordstat.sync');
    $mock = !empty($options['mock']) || !wordstat_is_configured();
    $configurationVersion = wordstat_provider_configuration_version();
    $regions = wordstat_get_regions_tree([
        'mock' => $mock,
        'timeoutSeconds' => 20,
    ]);
    if (!$regions) throw new RuntimeException('Wordstat regions response did not contain usable regions.');
    return RentalReturnStore::transaction(static function () use ($configurationVersion, $regions, $mock): array {
        if (!hash_equals($configurationVersion, wordstat_provider_configuration_version())) {
            throw new RuntimeException('Wordstat settings changed while the regions request was running.', 409);
        }
        wordstat_save_regions_cache($regions);
        if (!$mock) {
            wordstat_record_cost('manual_regions_tree_' . date('Ymd_His'), 'GetRegionsTree', 1, 'rent_rk');
        }
        wordstat_update_source_settings([
            'lastRegionsTreeAt' => now_iso(),
            'lastError' => null,
            'lastErrorAt' => null,
        ]);
        analytics_record_event('wordstat_regions_tree_loaded', [
            'scopeId' => 'rent_rk',
            'entityType' => 'wordstat_regions_cache',
            'entityId' => 'wordstat-regions-cache',
            'meta' => ['mock' => $mock, 'regions' => count($regions)],
        ]);
        return ['regions' => $regions, 'mock' => $mock];
    });
}

function wordstat_run_dry_run(string $scopeId, $seedPhrases, $regionIds, $methods): array
{
    require_permission('demand.wordstat.sync');
    if (!current_user_is_platform_admin()) {
        deny_scope_access();
    }
    $plan = wordstat_build_sync_plan($scopeId, $seedPhrases, $regionIds, $methods);
    $limits = wordstat_check_limits_before_run((int) $plan['plannedRequests'], (float) $plan['estimatedCostRub']);
    $run = demand_integrations_create_sync_run('wordstat', $plan['scope_id'], [
        'dryRun' => true,
    ]);
    wordstat_patch_sync_run((string) $run['id'], [
        'seedPhrases' => $plan['seedPhrases'],
        'regionIds' => $plan['regionIds'],
        'methods' => $plan['methods'],
        'plannedRequests' => $plan['plannedRequests'],
        'estimatedCostRub' => $plan['estimatedCostRub'],
        'planBreakdown' => $plan['planBreakdown'] ?? [],
        'warnings' => $plan['warnings'],
        'limitPreview' => $limits,
    ]);
    $finished = demand_integrations_finish_sync_run((string) $run['id'], [
        'status' => 'success',
        'itemsRead' => (int) $plan['plannedRequests'],
        'itemsCreated' => 0,
        'itemsUpdated' => 0,
        'itemsSkipped' => (int) $plan['plannedRequests'],
        'errors' => $plan['warnings'],
    ]);
    analytics_record_event('wordstat_dry_run_completed', [
        'scopeId' => $plan['scope_id'],
        'entityType' => 'wordstat_sync_run',
        'entityId' => (string) $run['id'],
        'meta' => [
            'plannedRequests' => $plan['plannedRequests'],
            'estimatedCostRub' => $plan['estimatedCostRub'],
            'methods' => $plan['methods'],
        ],
    ]);

    return ['run' => $finished, 'plan' => $plan, 'limits' => $limits];
}

function wordstat_keyword_extra_risks(string $phrase, int $frequency, string $regionId = ''): array
{
    $normalized = demand_normalize_phrase($phrase);
    $risks = ['external_api_imported'];
    if (str_contains($normalized, 'без залога')) {
        $risks[] = 'possible_false_promise';
        $risks[] = 'condition_not_supported';
        $risks[] = 'needs_human_review';
    }
    if ($regionId === '') {
        $risks[] = 'region_not_supported';
    }
    if ($frequency > 0 && $frequency < (int) demand_settings()['rent_rk']['minFrequencyForDraftSuggestion']) {
        $risks[] = 'low_frequency';
    }

    return demand_unique_strings($risks);
}

function wordstat_region_name_by_id(string $regionId): string
{
    if ($regionId === '') {
        return '';
    }
    foreach (wordstat_read_regions_cache()['regions'] as $region) {
        if (is_array($region) && (string) ($region['id'] ?? '') === $regionId) {
            return (string) ($region['name'] ?? '');
        }
    }

    return '';
}

function wordstat_upsert_keyword(string $scopeId, string $phrase, int $frequency, ?string $regionId, string $source, array $extra = []): array
{
    $scopeId = demand_normalize_scope_id($scopeId);
    $regionId = wordstat_clean_string((string) $regionId, 80);
    $regionName = wordstat_clean_string((string) ($extra['regionName'] ?? wordstat_region_name_by_id($regionId)), 120);
    $data = read_demand_keywords();
    $normalized = demand_normalize_phrase($phrase);
    $existingIndex = null;
    $existing = null;
    foreach ($data['items'] as $index => $item) {
        if (!is_array($item)) {
            continue;
        }
        if (
            demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')) === $scopeId
            && demand_normalize_phrase((string) ($item['normalizedPhrase'] ?? $item['phrase'] ?? '')) === $normalized
            && (string) ($item['regionId'] ?? '') === $regionId
        ) {
            $existingIndex = $index;
            $existing = $item;
            break;
        }
    }

    $row = [
        'scope_id' => $scopeId,
        'phrase' => $phrase,
        'regionId' => $regionId !== '' ? $regionId : null,
        'regionName' => $regionName,
        'source' => $source,
        'frequency' => $frequency,
        'frequencyPeriod' => 'month',
        'trend' => $extra['trend'] ?? null,
        'seasonality' => is_array($extra['seasonality'] ?? null) ? $extra['seasonality'] : [],
        'riskFlags' => array_merge(
            wordstat_keyword_extra_risks($phrase, $frequency, $regionId),
            is_array($extra['riskFlags'] ?? null) ? $extra['riskFlags'] : []
        ),
        'status' => str_contains(demand_normalize_phrase($phrase), 'без залога') ? 'needs_review' : 'active',
    ];
    $keyword = demand_normalize_keyword_record($row, $existing);
    if ($existingIndex === null) {
        array_unshift($data['items'], $keyword);
        $created = true;
    } else {
        $data['items'][$existingIndex] = $keyword;
        $created = false;
    }
    $data['items'] = array_slice($data['items'], 0, 10000);
    save_demand_keywords($data);

    analytics_record_event($created ? 'wordstat_keyword_created' : 'wordstat_keyword_updated', [
        'scopeId' => $scopeId,
        'entityType' => 'demand_keyword',
        'entityId' => (string) $keyword['id'],
        'meta' => [
            'source' => $source,
            'frequency' => $frequency,
            'regionId' => $regionId,
        ],
    ]);

    return [
        'keyword' => $keyword,
        'created' => $created,
    ];
}

function wordstat_upsert_external_metric(string $scopeId, string $entityType, string $entityId, string $phrase, ?string $regionName, array $metrics): array
{
    $entry = [
        'id' => 'dem_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'scope_id' => demand_normalize_scope_id($scopeId),
        'source' => 'wordstat',
        'entityType' => $entityType,
        'entityId' => $entityId,
        'landingPageId' => null,
        'phrase' => wordstat_clean_string($phrase, 240),
        'regionName' => $regionName !== null ? wordstat_clean_string($regionName, 120) : null,
        'metrics' => analytics_sanitize_meta($metrics) ?: [],
        'rawRef' => null,
        'collectedAt' => now_iso(),
        'createdAt' => now_iso(),
    ];
    $data = demand_integrations_read_external_metrics();
    array_unshift($data['items'], $entry);
    $data['items'] = array_slice($data['items'], 0, 20000);
    demand_integrations_save_external_metrics($data);

    return $entry;
}

function wordstat_live_sync_guard(array $plan, array $options = []): array
{
    if (!current_user_is_platform_admin()) {
        deny_scope_access();
    }
    if (empty($options['confirmed'])) {
        throw new RuntimeException('Manual confirmation is required before Wordstat live sync.');
    }

    $settings = wordstat_current_settings();
    if (empty($settings['enabled'])) {
        throw new RuntimeException('Wordstat source is disabled.');
    }
    if ((string) ($settings['mode'] ?? '') !== 'live_controlled') {
        throw new RuntimeException('Wordstat mode must be live_controlled.');
    }
    if (empty($settings['liveEnabled'])) {
        throw new RuntimeException('Wordstat liveEnabled flag is disabled.');
    }
    if (!in_array((string) ($settings['authStatus'] ?? ''), ['configured', 'test_success'], true)) {
        throw new RuntimeException('Wordstat authStatus must be configured or test_success.');
    }
    if (!wordstat_is_configured()) {
        throw new RuntimeException('Wordstat credentials are not configured outside repository JSON.');
    }
    if (empty($settings['baseUrlConfigured']) && empty($options['mockLive'])) {
        throw new RuntimeException('Wordstat base URL is not configured outside repository JSON.');
    }

    $limits = wordstat_check_limits_before_run((int) $plan['plannedRequests'], (float) $plan['estimatedCostRub'], $settings);
    if (empty($limits['ok'])) {
        analytics_record_event('wordstat_limit_blocked', [
            'scopeId' => $plan['scope_id'],
            'entityType' => 'wordstat',
            'entityId' => 'limits',
            'meta' => $limits,
        ]);
        demand_integrations_record_error('wordstat', (string) $plan['scope_id'], 'limit_blocked', 'Wordstat sync blocked by request/cost limits.', [
            'errors' => $limits['errors'],
            'plannedRequests' => $limits['plannedRequests'],
            'estimatedCostRub' => $limits['estimatedCostRub'],
        ], 'warning');
        throw new RuntimeException('Wordstat sync blocked by limits: ' . implode(', ', (array) $limits['errors']));
    }

    return $limits;
}

function wordstat_prepare_controlled_live_sync(string $scopeId, $seedPhrases, $regionIds, $methods, array $options = []): array
{
    require_permission('demand.wordstat.live');
    $plan = wordstat_build_sync_plan($scopeId, $seedPhrases, $regionIds, $methods);
    return [
        'plan' => $plan,
        'limits' => wordstat_live_sync_guard($plan, $options),
        'mockLive' => !empty($options['mockLive']),
        'configurationVersion' => wordstat_provider_configuration_version(),
    ];
}

function wordstat_fetch_controlled_live_sync(array $prepared): array
{
    $plan = is_array($prepared['plan'] ?? null) ? $prepared['plan'] : [];
    $mockLive = !empty($prepared['mockLive']);
    $responses = [];
    $requestCounts = array_fill_keys((array) ($plan['methods'] ?? []), 0);
    $itemsRead = 0;
    try {
        foreach ((array) ($plan['seedPhrases'] ?? []) as $seedPhrase) {
            $row = ['seedPhrase' => (string) $seedPhrase, 'top' => [], 'dynamics' => null, 'distribution' => []];
            if (in_array('getTop', (array) ($plan['methods'] ?? []), true)) {
                $row['top'] = wordstat_get_top((string) $seedPhrase, (array) ($plan['regionIds'] ?? []), [
                    'mockLive' => $mockLive, 'timeoutSeconds' => 20,
                ]);
                $requestCounts['getTop']++;
                $itemsRead += count($row['top']);
            }
            if (in_array('getDynamics', (array) ($plan['methods'] ?? []), true)) {
                $row['dynamics'] = wordstat_get_dynamics((string) $seedPhrase, (array) ($plan['regionIds'] ?? []), [
                    'mockLive' => $mockLive, 'timeoutSeconds' => 20,
                ]);
                $requestCounts['getDynamics']++;
            }
            if (in_array('getRegionsDistribution', (array) ($plan['methods'] ?? []), true)) {
                $row['distribution'] = wordstat_get_regions_distribution((string) $seedPhrase, [
                    'mockLive' => $mockLive, 'timeoutSeconds' => 20,
                ]);
                $requestCounts['getRegionsDistribution']++;
            }
            $responses[] = $row;
        }
        return ['ok' => true, 'responses' => $responses, 'requestCounts' => $requestCounts, 'itemsRead' => $itemsRead];
    } catch (Throwable $exception) {
        if ((int) $exception->getCode() === 409) throw $exception;
        return [
            'ok' => false,
            'responses' => [],
            'requestCounts' => $requestCounts,
            'itemsRead' => 0,
            'error' => wordstat_sanitize_error_message($exception->getMessage()),
        ];
    }
}

function wordstat_commit_controlled_live_sync(array $prepared, array $fetched): array
{
    if (!hash_equals((string) ($prepared['configurationVersion'] ?? ''), wordstat_provider_configuration_version())) {
        throw new RuntimeException('Wordstat settings changed while the live sync was running.', 409);
    }
    $plan = is_array($prepared['plan'] ?? null) ? $prepared['plan'] : [];
    $limits = is_array($prepared['limits'] ?? null) ? $prepared['limits'] : [];
    $mockLive = !empty($prepared['mockLive']);
    $run = demand_integrations_create_sync_run('wordstat', (string) ($plan['scope_id'] ?? 'rent_rk'), ['dryRun' => false]);
    wordstat_patch_sync_run((string) $run['id'], [
        'seedPhrases' => $plan['seedPhrases'] ?? [],
        'regionIds' => $plan['regionIds'] ?? [],
        'methods' => $plan['methods'] ?? [],
        'plannedRequests' => $plan['plannedRequests'] ?? 0,
        'estimatedCostRub' => $plan['estimatedCostRub'] ?? 0,
        'limitPreview' => $limits,
    ]);
    analytics_record_event('wordstat_live_sync_started', [
        'scopeId' => (string) ($plan['scope_id'] ?? 'rent_rk'),
        'entityType' => 'wordstat_sync_run',
        'entityId' => (string) $run['id'],
        'meta' => ['plannedRequests' => $plan['plannedRequests'] ?? 0, 'methods' => $plan['methods'] ?? []],
    ]);

    if (empty($fetched['ok'])) {
        $message = (string) ($fetched['error'] ?? 'Wordstat provider request failed.');
        demand_integrations_record_error('wordstat', (string) ($plan['scope_id'] ?? 'rent_rk'), 'live_sync_failed', $message, [
            'runId' => (string) $run['id'],
        ], 'error');
        $finished = demand_integrations_finish_sync_run((string) $run['id'], [
            'status' => str_contains($message, 'rate limited') || str_contains($message, 'http_429') ? 'rate_limited' : 'failed',
            'itemsRead' => 0, 'itemsCreated' => 0, 'itemsUpdated' => 0, 'itemsSkipped' => 0, 'errors' => [$message],
        ]);
        analytics_record_event('wordstat_live_sync_failed', [
            'scopeId' => (string) ($plan['scope_id'] ?? 'rent_rk'),
            'entityType' => 'wordstat_sync_run',
            'entityId' => (string) $run['id'],
            'meta' => ['error' => substr($message, 0, 160)],
        ]);
        return ['run' => $finished, 'plan' => $plan, 'created' => 0, 'updated' => 0, 'errors' => [$message]];
    }

    $created = 0;
    $updated = 0;
    $errors = [];
    $keywordIds = [];
    foreach ((array) ($fetched['responses'] ?? []) as $response) {
        $seedPhrase = (string) ($response['seedPhrase'] ?? '');
        $query = wordstat_enqueue_query((string) ($plan['scope_id'] ?? 'rent_rk'), $seedPhrase, (array) ($plan['regionIds'] ?? []), (array) ($plan['methods'] ?? []));
        wordstat_update_query_status((string) $query['id'], 'running');
        $seedKeyword = wordstat_upsert_keyword((string) ($plan['scope_id'] ?? 'rent_rk'), $seedPhrase, 0, (string) (($plan['regionIds'][0] ?? '')), 'wordstat_seed');
        $keywordIds[] = (string) $seedKeyword['keyword']['id'];
        $created += $seedKeyword['created'] ? 1 : 0;
        $updated += $seedKeyword['created'] ? 0 : 1;

        foreach ((array) ($response['top'] ?? []) as $item) {
            $result = wordstat_upsert_keyword(
                (string) ($plan['scope_id'] ?? 'rent_rk'),
                (string) ($item['phrase'] ?? ''),
                (int) ($item['frequency30d'] ?? 0),
                (string) ($plan['regionIds'][0] ?? ''),
                'wordstat_get_top'
            );
            $keyword = $result['keyword'];
            $keywordIds[] = (string) $keyword['id'];
            $created += $result['created'] ? 1 : 0;
            $updated += $result['created'] ? 0 : 1;
            wordstat_upsert_external_metric((string) ($plan['scope_id'] ?? 'rent_rk'), 'keyword', (string) $keyword['id'], (string) $keyword['phrase'], (string) ($keyword['regionName'] ?? ''), [
                'method' => 'GetTop', 'frequency30d' => (int) ($item['frequency30d'] ?? 0), 'regions' => $plan['regionIds'] ?? [],
            ]);
        }
        if (is_array($response['dynamics'] ?? null)) {
            $dynamics = $response['dynamics'];
            wordstat_upsert_external_metric((string) ($plan['scope_id'] ?? 'rent_rk'), 'keyword', (string) $seedKeyword['keyword']['id'], $seedPhrase, (string) ($seedKeyword['keyword']['regionName'] ?? ''), [
                'method' => 'GetDynamics', 'dynamics' => $dynamics['dynamics'] ?? [], 'trend' => $dynamics['trend'] ?? null, 'seasonality' => $dynamics['seasonality'] ?? [],
            ]);
        }
        if (!empty($response['distribution'])) {
            wordstat_upsert_external_metric((string) ($plan['scope_id'] ?? 'rent_rk'), 'keyword', (string) $seedKeyword['keyword']['id'], $seedPhrase, (string) ($seedKeyword['keyword']['regionName'] ?? ''), [
                'method' => 'GetRegionsDistribution', 'regionsDistribution' => (array) $response['distribution'],
            ]);
        }
        wordstat_update_query_status((string) $query['id'], 'success');
    }

    $keywordIds = array_values(array_unique(array_filter($keywordIds)));
    foreach ($keywordIds as $keywordId) {
        try {
            demand_recalculate_keyword_recommendations($keywordId);
        } catch (Throwable $exception) {
            $errors[] = 'recommendation_failed:' . $keywordId;
        }
    }
    foreach ((array) ($fetched['requestCounts'] ?? []) as $method => $count) {
        if ((int) $count > 0) wordstat_record_cost((string) $run['id'], (string) $method, (int) $count, (string) ($plan['scope_id'] ?? 'rent_rk'));
    }
    $finished = demand_integrations_finish_sync_run((string) $run['id'], [
        'status' => $errors ? 'partial_success' : 'success',
        'itemsRead' => (int) ($fetched['itemsRead'] ?? 0),
        'itemsCreated' => $created, 'itemsUpdated' => $updated, 'itemsSkipped' => 0, 'errors' => $errors,
    ]);
    analytics_record_event('wordstat_live_sync_completed', [
        'scopeId' => (string) ($plan['scope_id'] ?? 'rent_rk'),
        'entityType' => 'wordstat_sync_run',
        'entityId' => (string) $run['id'],
        'meta' => ['created' => $created, 'updated' => $updated, 'errors' => count($errors), 'mockLive' => $mockLive],
    ]);
    return ['run' => $finished, 'plan' => $plan, 'created' => $created, 'updated' => $updated, 'errors' => $errors];
}

function wordstat_run_controlled_live_sync(string $scopeId, $seedPhrases, $regionIds, $methods, array $options = []): array
{
    $prepared = wordstat_prepare_controlled_live_sync($scopeId, $seedPhrases, $regionIds, $methods, $options);
    $fetched = RentalReturnStore::waitOutsideLock(static fn(): array => wordstat_fetch_controlled_live_sync($prepared));
    return RentalReturnStore::transaction(static fn(): array => wordstat_commit_controlled_live_sync($prepared, $fetched));
}
