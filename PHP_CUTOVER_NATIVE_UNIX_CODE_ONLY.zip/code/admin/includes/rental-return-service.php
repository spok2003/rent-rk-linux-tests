<?php

declare(strict_types=1);

function rental_return_v2(array $rental): array
{
    $state = $rental['returnCloseV2'] ?? null;
    if (is_array($state)) {
        if (($state['schema'] ?? null) !== 1) {
            throw new RuntimeException('Неизвестная версия возврата. Изменения запрещены.', 409);
        }
        $state += ['balanceDecision' => null];
        return $state;
    }
    return ['schema' => 1, 'revision' => 0, 'acceptedAt' => '', 'acceptedBy' => '', 'condition' => [],
        'finance' => null, 'act' => null, 'history' => [], 'holdId' => '', 'deferred' => false, 'balanceDecision' => null];
}

function rental_return_categories(): array
{
    return ['mileage' => 'Перепробег', 'fuel' => 'Топливо', 'washing' => 'Мойка', 'lateness' => 'Задержка',
        'damage' => 'Повреждение', 'delivery' => 'Доставка', 'other' => 'Другое'];
}

function rental_return_text(array $input, string $key, int $limit = 2000, bool $required = false): string
{
    $value = $input[$key] ?? '';
    if (!is_string($value) || strlen($value) > $limit || preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f]/', $value)) {
        throw new InvalidArgumentException('Некорректное поле: ' . $key, 422);
    }
    $value = trim($value);
    if ($required && $value === '') {
        throw new InvalidArgumentException('Заполните поле: ' . $key, 422);
    }
    return $value;
}

function rental_return_amount(array $input, string $key = 'amount', bool $zero = false): int
{
    $value = rental_return_money($input[$key] ?? null);
    if ($value === null || (!$zero && $value === 0)) {
        throw new InvalidArgumentException('Укажите ' . ($zero ? 'неотрицательную' : 'положительную') . ' сумму в целых рублях.', 422);
    }
    return $value;
}

function rental_return_canonical($value)
{
    if (!is_array($value)) {
        return $value;
    }
    if (!array_is_list($value)) {
        ksort($value);
    }
    return array_map('rental_return_canonical', $value);
}

function rental_return_finance(array $rental): ?array
{
    $state = rental_return_v2($rental);
    $f = $state['finance'];
    if (!is_array($f)) {
        return null;
    }
    $base = $f['baseOriginal'];
    foreach ($f['adjustments'] as $row) {
        $base = rental_return_add($base, $row['delta']);
    }
    $obligations = ['base' => ['amount' => $base, 'allocated' => 0]];
    $extras = 0;
    foreach ($f['charges'] as $row) {
        if ($row['status'] === 'active') {
            $obligations[$row['id']] = ['amount' => $row['amount'], 'allocated' => 0];
            $extras = rental_return_add($extras, $row['amount']);
        }
    }
    $payments = [];
    $paid = 0;
    $pending = 0;
    foreach ($f['receipts'] as $row) {
        // Receipt states are not the ledger's posted/voided enum. Terminal failures carry no cash.
        if (in_array($row['status'], ['failed', 'canceled', 'cancelled', 'voided'], true)) {
            continue;
        }
        if ($row['status'] === 'pending') {
            $pending++;
            continue;
        }
        if ($row['status'] !== 'confirmed') {
            throw new RuntimeException('Неизвестный статус платежа. Требуется сверка.', 409);
        }
        $payments[$row['id']] = ['net' => $row['amount'], 'allocated' => 0];
        $paid = rental_return_add($paid, $row['amount']);
    }
    foreach ($f['refunds'] as $row) {
        if (!isset($payments[$row['paymentId']])) {
            throw new RuntimeException('Возврат ссылается на неподтверждённый платёж.', 409);
        }
        $payments[$row['paymentId']]['net'] -= $row['amount'];
        $paid -= $row['amount'];
    }
    foreach ($f['balanceTransfers'] ?? [] as $row) {
        if (!isset($payments[$row['paymentId']])) {
            throw new RuntimeException('Перенос на баланс ссылается на неподтверждённый платёж.', 409);
        }
        $payments[$row['paymentId']]['net'] -= $row['amount'];
        $paid -= $row['amount'];
    }
    $activeAllocations = [];
    foreach ($f['allocations'] as $row) {
        $amount = $row['amount'];
        foreach ($f['allocationReversals'] as $reverse) {
            if ($reverse['allocationId'] === $row['id']) {
                $amount -= $reverse['amount'];
            }
        }
        if ($amount < 0) {
            throw new RuntimeException('Превышено сторно распределения.', 409);
        }
        if ($amount === 0) {
            continue;
        }
        if (!isset($payments[$row['paymentId']], $obligations[$row['obligationId']])) {
            throw new RuntimeException('Нарушены связи распределения.', 409);
        }
        $payments[$row['paymentId']]['allocated'] = rental_return_add($payments[$row['paymentId']]['allocated'], $amount);
        $obligations[$row['obligationId']]['allocated'] = rental_return_add($obligations[$row['obligationId']]['allocated'], $amount);
        $activeAllocations[$row['id']] = $row + ['remaining' => $amount];
    }
    $free = 0;
    $unpaid = 0;
    foreach ($payments as &$row) {
        $row['capacity'] = $row['net'] - $row['allocated'];
        if ($row['net'] < 0 || $row['capacity'] < 0) {
            throw new RuntimeException('Превышена ёмкость платежа.', 409);
        }
        $free = rental_return_add($free, $row['capacity']);
    }
    unset($row);
    foreach ($obligations as &$row) {
        $row['remaining'] = $row['amount'] - $row['allocated'];
        if ($row['amount'] < 0 || $row['remaining'] < 0) {
            throw new RuntimeException('Превышена сумма обязательства.', 409);
        }
        $unpaid = rental_return_add($unpaid, $row['remaining']);
    }
    unset($row);
    $deposit = ['received' => $f['openingDeposit']['received'], 'returned' => $f['openingDeposit']['returned'], 'retained' => $f['openingDeposit']['retained']];
    foreach ($f['depositEvents'] as $row) {
        $field = ['receive' => 'received', 'return' => 'returned', 'retain' => 'retained', 'reverse' => 'retained'][$row['kind']];
        $deposit[$field] = rental_return_add($deposit[$field], $row['kind'] === 'reverse' ? -$row['amount'] : $row['amount']);
    }
    $deposit['remaining'] = $deposit['received'] - $deposit['returned'] - $deposit['retained'];
    if (min($deposit) < 0) {
        throw new RuntimeException('Превышен фактически полученный залог.', 409);
    }
    $due = rental_return_add($base, $extras);
    $debt = max(0, $due - $paid);
    $excess = max(0, $paid - $due);
    return ['base' => $base, 'extras' => $extras, 'due' => $due, 'paid' => $paid, 'debt' => $debt, 'excess' => $excess,
        'unallocated' => $free, 'unpaidObligations' => $unpaid, 'pending' => $pending, 'payments' => $payments,
        'obligations' => $obligations, 'allocations' => $activeAllocations, 'deposit' => $deposit,
        'settled' => $unpaid === 0 && $free === 0 && $excess === 0 && $deposit['remaining'] === 0 && $pending === 0 && !$state['deferred']];
}

function rental_return_event(string $prefix, array $data, string $operation): array
{
    return ['id' => $prefix . '_' . bin2hex(random_bytes(12)), 'operationId' => $operation,
        'createdAt' => now_iso(), 'createdBy' => current_admin_user()] + $data;
}

function rental_return_allocate(array &$rental, string $payment, string $obligation, int $amount, string $operation): void
{
    $s = rental_return_finance($rental);
    if (!isset($s['payments'][$payment], $s['obligations'][$obligation]) || $amount <= 0
        || $amount > min($s['payments'][$payment]['capacity'], $s['obligations'][$obligation]['remaining'])) {
        throw new InvalidArgumentException('Сумма превышает свободный платёж или остаток обязательства.', 422);
    }
    $rental['returnCloseV2']['finance']['allocations'][] = rental_return_event('allocation',
        ['paymentId' => $payment, 'obligationId' => $obligation, 'amount' => $amount], $operation);
}

function rental_return_release_allocations(array &$rental, callable $filter, int $amount, string $operation): void
{
    $s = rental_return_finance($rental);
    foreach (array_reverse($s['allocations'], true) as $id => $row) {
        if (!$filter($row) || $amount <= 0) {
            continue;
        }
        $released = min($amount, $row['remaining']);
        $rental['returnCloseV2']['finance']['allocationReversals'][] = rental_return_event('allocation_reverse',
            ['allocationId' => $id, 'amount' => $released], $operation);
        $amount -= $released;
    }
    if ($amount !== 0) {
        throw new RuntimeException('Не удалось согласовать распределения.', 409);
    }
}

function rental_return_ledger(array &$payments, array $rental, string $type, int $amount, string $reason, string $operation, array $meta = []): string
{
    $entry = payment_ledger_create_entry(['rentalId' => $rental['id'], 'type' => $type, 'amount' => $amount,
        'reason' => $reason, 'comment' => $reason, 'method' => $meta['method'] ?? 'unknown',
        'meta' => ['returnV2' => true, 'operationId' => $operation] + $meta]);
    foreach ($payments['entries'] as $old) {
        if (($old['id'] ?? '') === $entry['id']) { throw new RuntimeException('Платёж уже существует.', 409); }
    }
    $payments['entries'][] = $entry;
    return $entry['id'];
}

function rental_return_open_finance(array &$rental, array $payments, string $reason, string $operation): void
{
    if ($rental['returnCloseV2']['finance'] !== null) {
        throw new RuntimeException('Начальные остатки уже подтверждены.', 409);
    }
    $base = rental_return_money($rental['rentalCost'] ?? null);
    $paid = rental_return_money($rental['amountPaid'] ?? 0);
    $deposit = rental_return_money($rental['deposit'] ?? 0);
    $retained = rental_return_money($rental['retainedDeposit'] ?? 0);
    if ($base === null || $paid === null || $deposit === null || $retained === null || $retained > $deposit) {
        throw new RuntimeException('Сначала сверяйте исходные финансовые данные аренды.', 409);
    }
    $f = ['baseOriginal' => $base, 'adjustments' => [], 'charges' => [], 'receipts' => [], 'refunds' => [], 'balanceTransfers' => [],
        'allocations' => [], 'allocationReversals' => [], 'depositEvents' => [], 'debts' => [],
        'openingDeposit' => ['received' => 0, 'returned' => 0, 'retained' => 0],
        'openingSnapshot' => ['kind' => 'opening_snapshot_not_cash', 'reason' => $reason, 'actor' => current_admin_user(), 'at' => now_iso(), 'operationId' => $operation]];
    $net = 0;
    $hasLedger = false;
    foreach ($payments['entries'] as $entry) {
        if (($entry['rentalId'] ?? '') !== $rental['id'] || ($entry['status'] ?? '') !== 'posted') {
            continue;
        }
        $type = $entry['type'] ?? '';
        $amount = rental_return_money($entry['amount'] ?? null);
        if ($amount === null) {
            throw new RuntimeException('Некорректная сумма в истории платежей.', 409);
        }
        if ($type === 'rental_payment') {
            $hasLedger = true;
            $rentalAmount = payment_ledger_rental_allocated_amount($entry);
            $net = rental_return_add($net, $rentalAmount);
            $f['receipts'][] = ['id' => $entry['id'], 'amount' => $rentalAmount, 'status' => 'confirmed', 'source' => 'existing_ledger',
                'createdAt' => $entry['createdAt'], 'createdBy' => $entry['createdBy']];
        } elseif ($type === 'rental_payment_refund') {
            // An old unlinked refund cannot safely acquire an invented payment reference.
            throw new RuntimeException('История содержит старый возврат без распределений. Требуется отдельная сверка.', 409);
        } elseif (in_array($type, ['deposit_hold', 'deposit_return', 'deposit_retain'], true)) {
            $field = ['deposit_hold' => 'received', 'deposit_return' => 'returned', 'deposit_retain' => 'retained'][$type];
            $f['openingDeposit'][$field] = rental_return_add($f['openingDeposit'][$field], $amount);
        }
    }
    if ($hasLedger && $net !== $paid) {
        throw new RuntimeException('Платежи не совпадают с карточкой. Требуется сверка, не новый платёж.', 409);
    }
    if (!$hasLedger && $paid > 0) {
        throw new RuntimeException('В карточке есть оплата без истории поступлений. Нужна отдельная сверка: начальный остаток не является подтверждённым платежом.', 409);
    }
    if ($f['openingDeposit']['received'] === 0 && $deposit > 0 && in_array($rental['depositStatus'] ?? '', ['held', 'returned', 'partially_retained'], true)) {
        $f['openingDeposit'] = ['received' => $deposit, 'returned' => ($rental['depositStatus'] ?? '') === 'returned' ? $deposit - $retained : 0, 'retained' => $retained];
    }
    $rental['returnCloseV2']['finance'] = $f;
    // Explicit opening approval links existing confirmed receipts, never appends cash.
    foreach ($f['receipts'] as $receipt) {
        $s = rental_return_finance($rental);
        $amount = min($s['obligations']['base']['remaining'], $s['payments'][$receipt['id']]['capacity']);
        if ($amount > 0) {
            rental_return_allocate($rental, $receipt['id'], 'base', $amount, $operation);
        }
    }
}

function rental_return_validate_facts(array $rental, array $input): array
{
    $date = rental_return_text($input, 'actual_date', 10, true);
    $time = rental_return_text($input, 'actual_time', 5, true);
    $mileage = rental_return_money($input['end_mileage'] ?? null);
    $segment = rental_active_vehicle_segment($rental);
    $start = $segment['startedAt'] ?? rental_datetime_text($rental['startDate'], $rental['startTime']);
    $startMileage = $segment['startMileage'] ?? $rental['startMileage'] ?? null;
    if (!parse_date_value($date) || parse_time_value($time) === null || !$start || $date . ' ' . $time < substr(str_replace('T', ' ', $start), 0, 16)) {
        throw new InvalidArgumentException('Возврат не может быть раньше выдачи.', 422);
    }
    if ($mileage === null || $startMileage === null || $mileage < $startMileage || $mileage > 10000000) {
        throw new InvalidArgumentException('Пробег возврата должен быть не меньше пробега выдачи и не больше 10 000 000 км.', 422);
    }
    return ['actualReturnDate' => $date, 'actualReturnTime' => $time, 'endMileage' => $mileage];
}

function rental_return_act_fingerprint(array $rental): string
{
    $balance = customer_balance_summary((string) ($rental['customerId'] ?? ''), rental_owner_scope_id($rental));
    return hash('sha256', json_encode(rental_return_canonical([
        'date' => $rental['actualReturnDate'] ?? '', 'time' => $rental['actualReturnTime'] ?? '', 'mileage' => $rental['endMileage'] ?? null,
        'car' => $rental['carSlug'], 'customer' => $rental['customerId'], 'scope' => rental_owner_scope_id($rental),
        'condition' => rental_return_v2($rental)['condition'], 'finance' => rental_return_finance($rental),
        'photos' => $rental['returnWorkflow']['photos'] ?? [],
        'debts' => rental_return_v2($rental)['finance']['debts'] ?? [],
        'balanceDecision' => rental_return_v2($rental)['balanceDecision'] ?? null,
        'customerBalance' => ['available' => $balance['available'], 'digest' => $balance['digest']],
    ]), JSON_THROW_ON_ERROR));
}

function rental_return_debt_assignee_allowed(array $user, array $rental): bool
{
    return !empty($user['active']) && lessor_user_is_allowed($user)
        && in_array($user['role'], ['admin', 'manager'], true)
        && (($user['role'] === 'admin' && admin_user_scope_id($user) === 'rent_rk')
            || admin_user_scope_id($user) === rental_owner_scope_id($rental));
}

function rental_return_debt_valid(array $rental): bool
{
    $f = rental_return_finance($rental);
    if (!$f || $f['debt'] <= 0 || $f['unallocated'] !== 0 || $f['excess'] !== 0 || $f['pending'] !== 0 || $f['deposit']['remaining'] !== 0) {
        return false;
    }
    $active = array_values(array_filter($rental['returnCloseV2']['finance']['debts'], static fn(array $d): bool => $d['status'] === 'open'));
    if (count($active) !== 1 || ($active[0]['currentAmount'] ?? $active[0]['amount']) !== $f['debt']) {
        return false;
    }
    $user = find_admin_user($active[0]['responsible']);
    return $user && rental_return_debt_assignee_allowed($user, $rental);
}

function rental_return_execute(string $rentalId, array $input, array $uploads = []): array
{
    return RentalReturnStore::transaction(static function () use ($rentalId, $input, $uploads): array {
        $user = current_admin_record();
        if (!$user || empty($user['active']) || !lessor_user_is_allowed($user)
            || !in_array($user['role'], ['admin', 'manager'], true) || current_admin_role() !== $user['role'] || !has_permission('rentals.view')) {
            throw new RuntimeException('Нет доступа к возврату аренды.', 403);
        }
        $data = read_rentals();
        $index = null;
        foreach ($data['items'] as $i => $item) {
            if (($item['id'] ?? '') === $rentalId) {
                $index = $i;
                break;
            }
        }
        if ($index === null || !rental_belongs_to_current_scope($data['items'][$index])) {
            throw new RuntimeException('Аренда недоступна.', 403);
        }
        $rental = $data['items'][$index];
        $before = $rental;
        $action = rental_return_text($input, 'action', 40, true);
        $allowed = [
            'accept' => ['actual_date', 'actual_time', 'end_mileage', 'fuel', 'body_ok', 'interior_ok', 'keys_ok', 'clean', 'reason', 'confirmed'],
            'correct_facts' => ['actual_date', 'actual_time', 'end_mileage', 'reason', 'confirmed'],
            'finance_open' => ['reason', 'confirmed'], 'charge' => ['amount', 'category', 'reason'],
            'reverse_charge' => ['charge_id', 'reason'], 'adjust_base' => ['amount', 'reason'],
            'payment' => ['amount', 'method', 'reason'], 'allocate' => ['payment_id', 'obligation_id', 'amount', 'reason'],
            'debt_payment' => ['debt_id', 'amount', 'method', 'reason', 'confirmed'],
            'refund' => ['payment_id', 'amount', 'reason', 'confirmed'], 'refund_excess' => ['payment_id', 'amount', 'reason', 'confirmed'],
            'balance_apply' => ['obligation_id', 'amount', 'reason', 'confirmed'],
            'balance_refund' => ['amount', 'method', 'reason', 'confirmed'],
            'balance_leave' => ['reason', 'confirmed'],
            'balance_credit_excess' => ['payment_id', 'amount', 'reason', 'confirmed'],
            'deposit_receive' => ['amount', 'method', 'reason'], 'deposit_return' => ['amount', 'reason', 'confirmed'],
            'deposit_retain' => ['amount', 'category', 'reason', 'confirmed'], 'deposit_reverse' => ['event_id', 'reason', 'confirmed'],
            'register_debt' => ['due_date', 'responsible', 'reason', 'confirmed'], 'void_debt' => ['debt_id', 'reason', 'confirmed'],
            'defer' => ['reason'], 'settle' => ['confirmed'], 'prepare_act' => ['confirmed'],
            'close' => ['confirmed'], 'close_debt' => ['confirmed'], 'release_hold' => ['reason', 'confirmed'],
            'media_upload' => ['category'], 'media_retire' => ['media_id', 'reason', 'confirmed'],
        ];
        if (!isset($allowed[$action])) {
            throw new InvalidArgumentException('Неизвестное действие возврата.', 400);
        }
        $customerId = trim((string) ($rental['customerId'] ?? ''));
        $requiresScopedCustomer = !in_array($action, [
            'accept',
            'correct_facts',
            'release_hold',
            'media_upload',
            'media_retire',
        ], true);
        if ($requiresScopedCustomer && ($customerId === '' || !customer_for_rental_scope($rental))) {
            throw new RuntimeException(
                'Карточка клиента не найдена в контуре аренды. Финансовые действия и закрытие заблокированы.',
                409
            );
        }
        if (array_diff(array_keys($input), array_merge($allowed[$action], ['id', 'action', 'operation_id', 'expected_version', 'csrf_token', 'return_to']))) {
            throw new InvalidArgumentException('Запрос содержит недопустимые поля.', 422);
        }
        $moneyAction = !in_array($action, ['accept', 'correct_facts', 'prepare_act', 'close', 'close_debt', 'release_hold', 'media_upload', 'media_retire'], true);
        if ($moneyAction ? !has_permission('finance.manage') : !current_user_can_accept_rental_return(rental_owner_scope_id($rental))) {
            throw new RuntimeException('Недостаточно прав для действия.', 403);
        }
        if ($action === 'correct_facts' && $user['role'] !== 'admin') {
            throw new RuntimeException('Исправление закрытой аренды доступно администратору.', 403);
        }
        $token = $input['csrf_token'] ?? null;
        if (!is_string($token) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
            throw new RuntimeException('Недействительное подтверждение сессии.', 400);
        }
        $operation = rental_return_text($input, 'operation_id', 80, true);
        if (!preg_match('/^[a-zA-Z0-9_-]{16,80}$/D', $operation)) {
            throw new InvalidArgumentException('Некорректный идентификатор операции.', 422);
        }
        $version = rental_return_money($input['expected_version'] ?? null);
        if ($version === null) {
            throw new InvalidArgumentException('Не указана версия записи.', 422);
        }
        $state = rental_return_v2($rental);
        $semantic = $input;
        unset($semantic['csrf_token'], $semantic['return_to']);
        $upload = null;
        if ($action === 'media_upload') {
            if (array_keys($uploads) !== ['photo'] || !is_array($uploads['photo'])) {
                throw new InvalidArgumentException('Выберите одно фото возврата.', 422);
            }
            try {
                $upload = rental_media_validate_upload($uploads['photo']);
            } catch (InvalidArgumentException $error) {
                throw new InvalidArgumentException($error->getMessage(), 422, $error);
            }
            $upload['bytes'] = file_get_contents($upload['tmp']);
            if (!is_string($upload['bytes']) || strlen($upload['bytes']) !== $upload['size']) {
                throw new RuntimeException('Не удалось проверить загруженное фото.', 503);
            }
            $upload['sha256'] = hash('sha256', $upload['bytes']);
            $semantic['photo'] = array_intersect_key($upload, array_flip(['sha256', 'size', 'mime', 'originalName']));
        } elseif ($uploads) {
            throw new InvalidArgumentException('В этом действии загрузка файлов не поддерживается.', 422);
        }
        $fingerprint = hash('sha256', json_encode(rental_return_canonical([$rentalId, $user['login'], rental_owner_scope_id($rental), $semantic]), JSON_THROW_ON_ERROR));
        $operations = read_json_file(DATA_DIR . 'rental-return-operations.json', ['schema' => 1, 'items' => []]);
        if (isset($operations['items'][$operation])) {
            $previous = $operations['items'][$operation];
            if (!hash_equals($previous['fingerprint'], $fingerprint)) {
                throw new RuntimeException('Идентификатор операции уже использован другим запросом.', 409);
            }
            return $previous['result'] + ['replayed' => true];
        }
        if ($state['revision'] !== $version) {
            throw new RuntimeException('Запись изменена в другом окне. Обновите страницу.', 409);
        }
        RentalReturnStore::checkpoint('service.after_version');
        if ($action === 'correct_facts' && empty($rental['closedAt'])) {
            throw new RuntimeException('Исправление фактов доступно после закрытия аренды.', 409);
        }
        $legacyReturned = !isset($rental['returnCloseV2']) && ($rental['returnStatus'] ?? '') === 'returned';
        if (rental_uses_archive_finance_snapshot($rental) || (!isset($rental['returnCloseV2']) && !empty($rental['closedAt']))) {
            throw new RuntimeException('Историческая аренда не переводится в V2 автоматически.', 409);
        }
        if ($legacyReturned && $action !== 'finance_open') {
            throw new RuntimeException('Сначала явно подтвердите начальные остатки возвращённой аренды.', 409);
        }
        if (!isset($rental['returnCloseV2']) && ($rental['issueStatus'] ?? '') !== 'issued') {
            throw new RuntimeException('Форма возврата доступна после выдачи автомобиля.', 409);
        }
        if (in_array('confirmed', $allowed[$action], true) && ($input['confirmed'] ?? '') !== '1') {
            throw new InvalidArgumentException('Подтвердите действие.', 422);
        }
        if (!isset($rental['returnCloseV2']) && !isset($state['commissionLockedAmount'])
            && in_array($rental['commissionStatus'] ?? '', ['paid', 'earned'], true)) {
            $state['commissionLockedAmount'] = rental_commission_amount($rental) ?? 0;
        }
        if ($legacyReturned) {
            try {
                rental_return_validate_facts($rental, ['actual_date' => $rental['actualReturnDate'] ?? '',
                    'actual_time' => $rental['actualReturnTime'] ?? '', 'end_mileage' => (string) ($rental['endMileage'] ?? '')]);
            } catch (InvalidArgumentException $error) {
                throw new RuntimeException('Не подтверждены исторические дата, время или пробег возврата. Требуется сверочное решение.', 409, $error);
            }
            $state['legacyOpening'] = ['commissionAmount' => rental_commission_amount($rental),
                'commissionEarned' => rental_commission_is_earned($rental), 'returnWorkflow' => $rental['returnWorkflow'] ?? [],
                'confirmedAt' => now_iso(), 'confirmedBy' => $user['login'], 'operationId' => $operation];
            $state['acceptedAt'] = $rental['actualReturnDate'] . 'T' . $rental['actualReturnTime'] . ':00+03:00';
            $state['acceptedBy'] = (string) ($rental['returnWorkflow']['completedBy'] ?? '');
            // This records an existing return, without re-accepting the car or changing availability/mileage.
            $state['condition'] = ['reason' => (string) ($rental['returnWorkflow']['comment'] ?? '')];
        }
        $rental['returnCloseV2'] = $state;
        $reason = rental_return_text($input, 'reason', 2000, in_array('reason', $allowed[$action], true) && $action !== 'accept');
        $payments = read_json_file(PAYMENTS_FILE, ['version' => 1, 'entries' => []]);
        $paymentsBefore = $payments;
        $customerBalances = read_customer_balances(true);
        $customerBalancesBefore = $customerBalances;
        if ($action === 'media_upload' || $action === 'media_retire') {
            if (!empty($rental['closedAt'])) {
                throw new RuntimeException('Фото закрытой аренды доступны только для просмотра.', 409);
            }
            $workflow = normalize_rental_return_workflow($rental['returnWorkflow'] ?? []);
            if ($action === 'media_upload') {
                $category = rental_return_text($input, 'category', 30, true);
                if (!isset(rental_media_categories('return')[$category]) || count($workflow['photos']) >= rental_media_max_stage_photos()) {
                    throw new InvalidArgumentException('Проверьте категорию и лимит фото возврата.', 422);
                }
                $mediaId = 'media_' . bin2hex(random_bytes(12));
                // The path uses an internal digest, never a user-supplied directory name.
                $name = 'rental-media/' . hash('sha256', $rentalId) . '/return/' . $mediaId . '.' . $upload['extension'];
                RentalReturnStore::stageMedia($name, $upload['bytes']);
                $workflow['photos'][] = ['id' => $mediaId, 'stage' => 'return', 'category' => $category,
                    'relativePath' => $name, 'storedName' => basename($name), 'originalName' => $upload['originalName'],
                    'mime' => $upload['mime'], 'size' => $upload['size'], 'sha256' => $upload['sha256'],
                    'uploadedAt' => now_iso(), 'uploadedBy' => $user['login'], 'operationId' => $operation];
            } else {
                $mediaId = rental_return_text($input, 'media_id', 100, true);
                $found = false;
                foreach ($workflow['photos'] as $i => $photo) {
                    if ($photo['id'] === $mediaId) {
                        $rental['returnCloseV2']['retiredPhotos'][] = $photo + ['retiredAt' => now_iso(), 'retiredBy' => $user['login'], 'reason' => $reason, 'retiredOperationId' => $operation];
                        array_splice($workflow['photos'], $i, 1);
                        $found = true;
                        break;
                    }
                }
                if (!$found) { throw new RuntimeException('Фото уже исключено или недоступно.', 409); }
            }
            $rental['returnWorkflow'] = $workflow;
        } elseif ($action === 'finance_open') {
            rental_return_open_finance($rental, $payments, $reason, $operation);
        } elseif ($moneyAction) {
            $s = rental_return_finance($rental);
            if ($s === null) {
                throw new RuntimeException('Сначала подтвердите начальные финансовые остатки.', 409);
            }
            $f =& $rental['returnCloseV2']['finance'];
            if ($action === 'charge') {
                $category = rental_return_text($input, 'category', 20, true);
                if (!isset(rental_return_categories()[$category])) {
                    throw new InvalidArgumentException('Выберите категорию начисления.', 422);
                }
                $f['charges'][] = rental_return_event('charge', ['category' => $category, 'amount' => rental_return_amount($input),
                    'reason' => $reason, 'status' => 'active', 'rentalId' => $rentalId, 'customerId' => $rental['customerId'],
                    'carSlug' => $rental['carSlug'], 'scopeId' => rental_owner_scope_id($rental)], $operation);
            } elseif ($action === 'reverse_charge') {
                $charge = rental_return_text($input, 'charge_id', 100, true);
                if (!isset($s['obligations'][$charge]) || $charge === 'base') {
                    throw new InvalidArgumentException('Начисление недоступно.', 422);
                }
                rental_return_release_allocations($rental, static fn(array $a): bool => $a['obligationId'] === $charge, $s['obligations'][$charge]['allocated'], $operation);
                foreach ($f['charges'] as &$row) {
                    if ($row['id'] === $charge) {
                        $row['status'] = 'reversed';
                        $row['reversal'] = rental_return_event('charge_reverse', ['reason' => $reason, 'originalId' => $charge], $operation);
                    }
                }
                unset($row);
            } elseif ($action === 'adjust_base') {
                $lockReason = partner_deal_financial_lock_reason($rental);
                if ($lockReason !== '') {
                    throw new RuntimeException(
                        'Комиссионная база уже финансово зафиксирована. ' . $lockReason
                        . ' Для пересмотра закрытой сделки нужен отдельный процесс финансовой корректировки.',
                        409
                    );
                }
                $target = rental_return_amount($input, 'amount', true);
                if ($target < $s['obligations']['base']['allocated']) {
                    rental_return_release_allocations($rental, static fn(array $a): bool => $a['obligationId'] === 'base', $s['obligations']['base']['allocated'] - $target, $operation);
                }
                $f['adjustments'][] = rental_return_event('base_adjustment', ['delta' => $target - $s['base'], 'reason' => $reason, 'before' => $s['base'], 'after' => $target], $operation);
            } elseif ($action === 'payment' || $action === 'debt_payment') {
                if ($action === 'debt_payment') {
                    $debtId = rental_return_text($input, 'debt_id', 100, true);
                    $active = array_values(array_filter($f['debts'], static fn(array $d): bool => $d['id'] === $debtId && $d['status'] === 'open'));
                    if (count($active) !== 1 || !rental_return_debt_valid($rental)) {
                        throw new RuntimeException('Долг изменился или есть нераспределённые деньги. Обновите расчёт.', 409);
                    }
                    $amount = array_key_exists('amount', $input) ? rental_return_amount($input) : $s['debt'];
                    if ($amount > $s['debt']) {
                        throw new InvalidArgumentException('Сумма погашения превышает остаток долга.', 422);
                    }
                } else {
                    $amount = rental_return_amount($input);
                }
                $method = rental_return_text($input, 'method', 20, true);
                if (!array_key_exists($method, payment_ledger_allowed_methods())) {
                    throw new InvalidArgumentException('Выберите способ оплаты.', 422);
                }
                $id = rental_return_ledger($payments, $rental, 'rental_payment', $amount, $reason, $operation, ['method' => $method]);
                $f['receipts'][] = ['id' => $id, 'amount' => $amount, 'status' => 'confirmed', 'source' => 'ledger', 'createdAt' => now_iso(), 'createdBy' => $user['login'], 'operationId' => $operation];
                $baseAllocation = min($amount, $s['obligations']['base']['remaining']);
                if ($baseAllocation > 0) {
                    rental_return_allocate($rental, $id, 'base', $baseAllocation, $operation);
                }
                if ($action === 'debt_payment') {
                    // Allocate only this receipt: base first, then the displayed extras in their stable order.
                    $remaining = $amount - $baseAllocation;
                    foreach ($s['obligations'] as $obligationId => $obligation) {
                        if ($obligationId !== 'base' && $obligation['remaining'] > 0 && $remaining > 0) {
                            $allocated = min($remaining, $obligation['remaining']);
                            rental_return_allocate($rental, $id, $obligationId, $allocated, $operation);
                            $remaining -= $allocated;
                        }
                    }
                }
            } elseif ($action === 'allocate') {
                rental_return_allocate($rental, rental_return_text($input, 'payment_id', 100, true), rental_return_text($input, 'obligation_id', 100, true), rental_return_amount($input), $operation);
            } elseif ($action === 'refund' || $action === 'refund_excess') {
                $payment = rental_return_text($input, 'payment_id', 100, true);
                $amount = rental_return_amount($input);
                if (!isset($s['payments'][$payment]) || $amount > $s['payments'][$payment]['net']
                    || ($action === 'refund_excess' && $amount > min($s['excess'], $s['payments'][$payment]['capacity']))) {
                    throw new InvalidArgumentException('Сумма возврата превышает доступный остаток.', 422);
                }
                $release = max(0, $amount - $s['payments'][$payment]['capacity']);
                rental_return_release_allocations($rental, static fn(array $a): bool => $a['paymentId'] === $payment, $release, $operation);
                $id = rental_return_ledger($payments, $rental, 'rental_payment_refund', $amount, $reason, $operation, ['paymentId' => $payment]);
                $f['refunds'][] = ['id' => $id, 'paymentId' => $payment, 'amount' => $amount, 'reason' => $reason, 'operationId' => $operation, 'createdAt' => now_iso(), 'createdBy' => $user['login']];
            } elseif ($action === 'balance_apply') {
                $amount = rental_return_amount($input);
                $obligationId = rental_return_text($input, 'obligation_id', 100, true);
                if (!isset($s['obligations'][$obligationId]) || $amount > $s['obligations'][$obligationId]['remaining']) {
                    throw new InvalidArgumentException('Сумма зачёта превышает остаток выбранного обязательства.', 422);
                }
                $balance = customer_balance_summary((string) $rental['customerId'], rental_owner_scope_id($rental), $customerBalances);
                if ($amount > $balance['available']) {
                    throw new InvalidArgumentException('Сумма зачёта превышает доступный баланс клиента.', 422);
                }
                $id = rental_return_ledger($payments, $rental, 'customer_balance_apply', $amount, $reason, $operation, [
                    'customerId' => (string) $rental['customerId'],
                    'scopeId' => rental_owner_scope_id($rental),
                    'targetObligationId' => $obligationId,
                ]);
                $consumed = customer_balance_consume($customerBalances, [
                    'type' => 'apply',
                    'amount' => $amount,
                    'customerId' => (string) $rental['customerId'],
                    'scopeId' => rental_owner_scope_id($rental),
                    'targetRentalId' => $rentalId,
                    'targetObligationId' => $obligationId,
                    'ledgerEntryId' => $id,
                    'operationId' => $operation,
                    'reason' => $reason,
                ]);
                $customerBalances = $consumed['store'];
                $f['receipts'][] = ['id' => $id, 'amount' => $amount, 'status' => 'confirmed', 'source' => 'customer_balance',
                    'createdAt' => now_iso(), 'createdBy' => $user['login'], 'operationId' => $operation];
                rental_return_allocate($rental, $id, $obligationId, $amount, $operation);
                $rental['returnCloseV2']['balanceDecision'] = null;
            } elseif ($action === 'balance_refund') {
                $amount = rental_return_amount($input);
                $method = rental_return_text($input, 'method', 20, true);
                if (!array_key_exists($method, payment_ledger_allowed_methods())) {
                    throw new InvalidArgumentException('Выберите способ выдачи денег.', 422);
                }
                $balance = customer_balance_summary((string) $rental['customerId'], rental_owner_scope_id($rental), $customerBalances);
                if ($amount > $balance['available']) {
                    throw new InvalidArgumentException('Сумма выдачи превышает доступный баланс клиента.', 422);
                }
                $id = rental_return_ledger($payments, $rental, 'customer_balance_refund', $amount, $reason, $operation, [
                    'customerId' => (string) $rental['customerId'], 'scopeId' => rental_owner_scope_id($rental), 'method' => $method,
                ]);
                $consumed = customer_balance_consume($customerBalances, [
                    'type' => 'refund', 'amount' => $amount, 'customerId' => (string) $rental['customerId'],
                    'scopeId' => rental_owner_scope_id($rental), 'targetRentalId' => $rentalId,
                    'ledgerEntryId' => $id, 'operationId' => $operation, 'reason' => $reason,
                ]);
                $customerBalances = $consumed['store'];
                $rental['returnCloseV2']['balanceDecision'] = null;
            } elseif ($action === 'balance_credit_excess') {
                $payment = rental_return_text($input, 'payment_id', 100, true);
                $amount = rental_return_amount($input);
                if (!isset($s['payments'][$payment]) || $amount > min($s['excess'], $s['payments'][$payment]['capacity'])) {
                    throw new InvalidArgumentException('Сумма переноса превышает свободную переплату выбранного поступления.', 422);
                }
                $creditId = customer_balance_event_id('credit');
                $ledgerId = rental_return_ledger($payments, $rental, 'customer_balance_credit', $amount, $reason, $operation, [
                    'sourcePaymentId' => $payment, 'customerBalanceCreditId' => $creditId,
                    'customerId' => (string) $rental['customerId'], 'scopeId' => rental_owner_scope_id($rental),
                ]);
                $customerBalances = customer_balance_append_credit($customerBalances, [
                    'id' => $creditId, 'amount' => $amount, 'customerId' => (string) $rental['customerId'],
                    'scopeId' => rental_owner_scope_id($rental), 'sourceRentalId' => $rentalId,
                    'sourcePaymentId' => $payment, 'sourceKind' => 'rental_return_overpayment',
                    'ledgerEntryId' => $ledgerId, 'operationId' => $operation, 'reason' => $reason,
                ]);
                $f['balanceTransfers'][] = rental_return_event('balance_transfer', [
                    'paymentId' => $payment, 'amount' => $amount, 'creditId' => $creditId, 'ledgerEntryId' => $ledgerId,
                ], $operation);
                $rental['returnCloseV2']['balanceDecision'] = null;
            } elseif ($action === 'balance_leave') {
                $balance = customer_balance_summary((string) $rental['customerId'], rental_owner_scope_id($rental), $customerBalances);
                if ($balance['available'] <= 0) {
                    throw new RuntimeException('На балансе клиента нет остатка, требующего решения.', 409);
                }
                $rental['returnCloseV2']['balanceDecision'] = [
                    'kind' => 'leave', 'amount' => $balance['available'], 'digest' => $balance['digest'],
                    'scopeId' => rental_owner_scope_id($rental), 'reason' => $reason,
                    'createdAt' => now_iso(), 'createdBy' => $user['login'], 'operationId' => $operation,
                ];
            } elseif (str_starts_with($action, 'deposit_')) {
                $kind = substr($action, 8);
                $category = $kind === 'retain' ? rental_return_text($input, 'category', 20, true) : '';
                if ($kind === 'retain' && !isset(rental_return_categories()[$category])) {
                    throw new InvalidArgumentException('Укажите категорию удержания.', 422);
                }
                $original = '';
                if ($kind === 'reverse') {
                    $original = rental_return_text($input, 'event_id', 100, true);
                    $amount = 0;
                    foreach ($f['depositEvents'] as $event) {
                        if (($event['originalId'] ?? '') === $original) {
                            throw new RuntimeException('Удержание уже отменено.', 409);
                        }
                        if ($event['id'] === $original && $event['kind'] === 'retain') {
                            $amount = $event['amount'];
                        }
                    }
                    if ($amount <= 0) {
                        throw new InvalidArgumentException('Удержание недоступно.', 422);
                    }
                } else {
                    $amount = rental_return_amount($input);
                }
                if (in_array($kind, ['return', 'retain'], true) && $amount > $s['deposit']['remaining']) {
                    throw new InvalidArgumentException('Сумма превышает фактический остаток залога.', 422);
                }
                $type = ['receive' => 'deposit_hold', 'return' => 'deposit_return', 'retain' => 'deposit_retain', 'reverse' => 'manual_adjustment'][$kind];
                $method = $kind === 'receive' ? rental_return_text($input, 'method', 20) : 'unknown';
                $method = $method === '' ? 'unknown' : $method;
                if (!array_key_exists($method, payment_ledger_allowed_methods())) {
                    throw new InvalidArgumentException('Выберите способ оплаты.', 422);
                }
                $id = rental_return_ledger($payments, $rental, $type, $amount, $reason, $operation, ['depositKind' => $kind, 'originalId' => $original, 'method' => $method]);
                $f['depositEvents'][] = ['id' => $id, 'kind' => $kind, 'amount' => $amount, 'category' => $category,
                    'reason' => $reason, 'originalId' => $original, 'createdAt' => now_iso(), 'createdBy' => $user['login'], 'operationId' => $operation];
            } elseif ($action === 'register_debt') {
                if ($s['debt'] <= 0 || $s['unallocated'] !== 0 || $s['excess'] !== 0 || $s['pending'] !== 0 || $s['deposit']['remaining'] !== 0) {
                    throw new RuntimeException('Долг регистрируется после распределения денег и отдельного расчёта залога.', 409);
                }
                if (array_filter($f['debts'], static fn(array $d): bool => $d['status'] === 'open')) {
                    throw new RuntimeException('Активный долг уже зарегистрирован.', 409);
                }
                $due = rental_return_text($input, 'due_date', 10, true);
                if (!parse_date_value($due) || $due < date('Y-m-d')) {
                    throw new InvalidArgumentException('Укажите срок погашения не раньше сегодняшнего дня.', 422);
                }
                $responsible = rental_return_text($input, 'responsible', 100, true);
                $coverage = array_map(static fn(array $o): int => $o['remaining'], $s['obligations']);
                $f['debts'][] = rental_return_event('debt', ['amount' => $s['debt'], 'currentAmount' => $s['debt'], 'coverage' => $coverage, 'dueDate' => $due, 'responsible' => $responsible, 'reason' => $reason, 'status' => 'open'], $operation);
                if (!rental_return_debt_valid($rental)) {
                    throw new InvalidArgumentException('Выберите действующего ответственного своего контура.', 422);
                }
            } elseif ($action === 'void_debt') {
                $id = rental_return_text($input, 'debt_id', 100, true);
                $found = false;
                foreach ($f['debts'] as &$debt) {
                    if ($debt['id'] === $id && $debt['status'] === 'open') {
                        $debt['status'] = 'void';
                        $debt['void'] = rental_return_event('debt_void', ['reason' => $reason], $operation);
                        $found = true;
                    }
                }
                unset($debt);
                if (!$found) {
                    throw new RuntimeException('Активный долг не найден.', 409);
                }
            } elseif ($action === 'defer') {
                $rental['returnCloseV2']['deferred'] = true;
            } elseif ($action === 'settle') {
                $rental['returnCloseV2']['deferred'] = false;
                if (!rental_return_finance($rental)['settled']) {
                    throw new RuntimeException('Остались обязательства, нераспределённые деньги или залог.', 409);
                }
            }
            unset($f);
        } elseif ($action === 'accept' || $action === 'correct_facts') {
            if ($action === 'accept' && ($state['acceptedAt'] !== '' || !empty($rental['closedAt']) || ($rental['issueStatus'] ?? '') !== 'issued')) {
                throw new RuntimeException('Автомобиль уже принят или ещё не выдан.', 409);
            }
            $facts = rental_return_validate_facts($rental, $input);
            $rental = array_merge($rental, $facts);
            if ($action === 'accept') {
                $fuel = rental_return_text($input, 'fuel', 20, true);
                if ($fuel === '' || !isset(rental_fuel_levels()[$fuel])) {
                    throw new InvalidArgumentException('Укажите топливо при возврате.', 422);
                }
                $condition = [];
                foreach (['body_ok', 'interior_ok', 'keys_ok', 'clean'] as $field) {
                    $condition[$field] = ($input[$field] ?? '') === '1';
                }
                $hasIssue = in_array(false, $condition, true);
                if ($hasIssue && $reason === '') {
                    throw new InvalidArgumentException('Укажите замечание по автомобилю.', 422);
                }
                $rental['returnCloseV2']['condition'] = $condition + ['fuel' => $fuel, 'reason' => $reason];
                $rental['returnCloseV2']['acceptedAt'] = now_iso();
                $rental['returnCloseV2']['acceptedBy'] = $user['login'];
                $rental['returnStatus'] = 'returned';
                $workflow = normalize_rental_return_workflow($rental['returnWorkflow'] ?? []);
                $workflow['fuelLevel'] = $fuel;
                $workflow['damageComment'] = $reason;
                $workflow['mileage'] = $facts['endMileage'];
                $workflow['returnedAt'] = $facts['actualReturnDate'] . ' ' . $facts['actualReturnTime'];
                $workflow['status'] = 'completed';
                $workflow['completedAt'] = now_iso();
                $workflow['completedBy'] = $user['login'];
                $rental['returnWorkflow'] = $workflow;
                clear_availability_by_rental($rentalId);
                if ($hasIssue) {
                    $hold = add_service_hold(['carSlug' => $rental['carSlug'], 'rentalId' => $rentalId, 'startedAt' => $workflow['returnedAt'], 'status' => 'inspection', 'reason' => $reason]);
                    $rental['returnCloseV2']['holdId'] = $hold['id'];
                    $conflicts = [];
                    foreach (car_availability($rental['carSlug']) as $date => $entry) {
                        if ($date >= $facts['actualReturnDate'] && ($entry['serviceHoldId'] ?? '') !== $hold['id']
                            && ($entry['status'] ?? 'free') !== 'free') {
                            $conflicts[] = ['date' => $date, 'rentalId' => $entry['rentalId'] ?? '', 'requestId' => $entry['requestId'] ?? ''];
                        }
                    }
                    $rental['returnCloseV2']['holdConflicts'] = $conflicts;
                    if ($conflicts) {
                        $task = add_task(['title' => 'Проверить следующую бронь: автомобиль на осмотре', 'type' => 'other', 'status' => 'new',
                            'priority' => 'urgent', 'carId' => $rental['carSlug'], 'rentalId' => $rentalId,
                            'scopeId' => rental_owner_scope_id($rental), 'assigneeLogin' => $user['login'],
                            'description' => 'Сервисное удержание ' . $hold['id'] . '. Первая занятая дата: ' . $conflicts[0]['date'] . '. Существующие брони не изменены.']);
                        $rental['returnCloseV2']['holdConflictTaskId'] = $task['id'];
                    }
                }
            } else {
                $rental['returnWorkflow']['mileage'] = $facts['endMileage'];
                $rental['returnWorkflow']['returnedAt'] = $facts['actualReturnDate'] . ' ' . $facts['actualReturnTime'];
            }
            $rental['vehicleSegments'] = normalize_rental_vehicle_segments($rental);
            if ($action === 'accept') {
                sync_rental_mileage_to_car($rental);
            }
        } elseif ($action === 'release_hold') {
            $hold = $state['holdId'] !== '' ? find_service_hold($state['holdId']) : null;
            if (!$hold || $hold['rentalId'] !== $rentalId || $hold['carSlug'] !== $rental['carSlug'] || $hold['closedAt'] !== '') {
                throw new RuntimeException('Активное удержание автомобиля не найдено.', 409);
            }
            update_service_hold_item($hold['id'], ['status' => 'ready', 'comment' => $reason]);
            audit_log('car.return_hold_released', 'car', $rental['carSlug'], 'Автомобиль проверен после возврата',
                ['rentalId' => $rentalId, 'before' => $hold['status'], 'after' => 'ready', 'comment' => $reason]);
        } elseif ($action === 'prepare_act') {
            if ($state['acceptedAt'] === '') {
                throw new RuntimeException('Сначала примите автомобиль.', 409);
            }
            $parties = rental_return_document_parties($rental);
            rental_return_document_rows($rental);
            $rental['returnCloseV2']['act'] = ['fingerprint' => rental_return_act_fingerprint($rental), 'preparedAt' => now_iso(), 'preparedBy' => $user['login'], 'parties' => $parties];
        } elseif ($action === 'close' || $action === 'close_debt') {
            $s = rental_return_finance($rental);
            if ($state['acceptedAt'] === '' || !empty($rental['closedAt']) || !$s) {
                throw new RuntimeException('Аренда не готова к закрытию.', 409);
            }
            $balance = customer_balance_summary((string) $rental['customerId'], rental_owner_scope_id($rental), $customerBalances);
            if ($balance['available'] > 0) {
                $decision = $rental['returnCloseV2']['balanceDecision'] ?? null;
                if (!is_array($decision) || ($decision['kind'] ?? '') !== 'leave'
                    || (int) ($decision['amount'] ?? -1) !== (int) $balance['available']
                    || !hash_equals((string) ($decision['digest'] ?? ''), (string) $balance['digest'])) {
                    throw new RuntimeException('Выберите, что сделать с доступным балансом клиента: зачесть, выдать или явно оставить.', 409);
                }
            }
            if ($action === 'close' ? !$s['settled'] : !rental_return_debt_valid($rental)) {
                throw new RuntimeException('Не завершён расчёт или не оформлен точный долг.', 409);
            }
            if (!is_array($state['act']) || !hash_equals($state['act']['fingerprint'], rental_return_act_fingerprint($rental))) {
                throw new RuntimeException('Подготовьте актуальный акт возврата.', 409);
            }
            $rental['closedAt'] = now_iso();
            $rental['closedBy'] = $user['login'];
            $rental['closingChecklist'] = normalize_rental_closing_checklist($rental['closingChecklist'] ?? []);
            $rental['closingChecklist']['closedAt'] = $rental['closedAt'];
            $rental['closingChecklist']['closedBy'] = $rental['closedBy'];
        }
        $summary = rental_return_finance($rental);
        RentalReturnStore::checkpoint('service.after_calculation');
        if ($summary && $moneyAction) {
            foreach ($rental['returnCloseV2']['finance']['debts'] as &$debt) {
                if ($debt['status'] !== 'open') { continue; }
                $covered = 0;
                foreach ($debt['coverage'] as $obligationId => $maximum) {
                    $covered = rental_return_add($covered, min($maximum, $summary['obligations'][$obligationId]['remaining'] ?? 0));
                }
                $debt['currentAmount'] = $covered;
                if ($covered === 0) { $debt['status'] = 'paid'; $debt['resolvedAt'] = now_iso(); $debt['resolvedByOperation'] = $operation; }
            }
            unset($debt);
            $rental['rentalCost'] = $summary['base'];
            $rental['amountPaid'] = $summary['paid'];
            $rental['retainedDeposit'] = $summary['deposit']['retained'];
            $rental['paymentStatus'] = $summary['debt'] > 0 ? ($summary['paid'] > 0 ? 'prepaid' : 'not_paid') : ($summary['excess'] > 0 ? 'refund_due' : 'paid');
            $rental['depositStatus'] = rental_deposit_status_from_totals($summary['deposit']);
        }
        $rental['returnCloseV2']['revision']++;
        $rental['returnCloseV2']['history'][] = rental_return_event('return', ['action' => $action, 'reason' => $reason,
            'beforeVersion' => $version, 'afterVersion' => $version + 1,
            'beforeFacts' => array_intersect_key($before, array_flip(['actualReturnDate', 'actualReturnTime', 'endMileage', 'closedAt'])),
            'afterFacts' => array_intersect_key($rental, array_flip(['actualReturnDate', 'actualReturnTime', 'endMileage', 'closedAt']))], $operation);
        $rental['updatedAt'] = now_iso();
        $data['items'][$index] = $rental;
        if ($action === 'correct_facts') {
            require_once __DIR__ . '/rental-lifecycle-integrity.php';
            RentalLifecycleIntegrity::saveCorrectedReturn($data, $rentalId);
        } else {
            save_rentals($data);
        }
        if ($payments !== $paymentsBefore) {
            write_json_file(PAYMENTS_FILE, $payments);
        }
        if ($customerBalances !== $customerBalancesBefore) {
            write_customer_balances($customerBalances);
        }
        audit_log('rental.return_v2.' . $action, 'rental', $rentalId, 'Возврат аренды: ' . $action, ['operationId' => $operation, 'revision' => $version + 1]);
        $result = ['rentalId' => $rentalId, 'revision' => $version + 1, 'action' => $action];
        $operations['items'][$operation] = ['fingerprint' => $fingerprint, 'result' => $result];
        write_json_file(DATA_DIR . 'rental-return-operations.json', $operations);
        return $result;
    });
}

function rental_return_payout_has_v2(array $ids): bool
{
    foreach (read_rentals()['items'] as $rental) {
        if (isset($rental['returnCloseV2']) && in_array($rental['id'], $ids, true)) { return true; }
    }
    return false;
}

function rental_return_payout_transaction(callable $work): array
{
    $result = [];
    $abort = new RuntimeException('Payout did not complete.');
    try {
        return RentalReturnStore::transaction(static function () use ($work, &$result, $abort): array {
            $result = $work();
            // Legacy failure results must not publish a staged V2 payout prefix.
            if (!in_array($result['status'] ?? '', ['paid', 'voided'], true)) { throw $abort; }
            return $result;
        });
    } catch (Throwable $error) {
        if ($error !== $abort) { throw $error; }
        return $result + ['atomicRollback' => true];
    }
}

function rental_return_guard_legacy_write(string $path, array $data): void
{
    if (RentalReturnStore::active() || !in_array($path, [RENTALS_FILE, PAYMENTS_FILE], true)) {
        return;
    }
    $rentals = read_rentals();
    $v2 = [];
    foreach ($rentals['items'] as $rental) {
        if (isset($rental['returnCloseV2'])) {
            $v2[$rental['id']] = $rental;
        }
    }
    if (!$v2) {
        return;
    }
    if ($path === RENTALS_FILE) {
        $incoming = array_column($data['items'] ?? [], null, 'id');
        foreach ($v2 as $id => $old) {
            // Guarded V2 payouts enter their transaction before the first write.
            $ignore = array_flip(['updatedAt']);
            if (!isset($incoming[$id]) || array_diff_key($old, $ignore) !== array_diff_key($incoming[$id], $ignore)) {
                throw new RuntimeException('Эта аренда использует возврат V2. Старое сохранение запрещено.', 409);
            }
        }
        return;
    }
    $oldEntries = array_column(read_payments(true)['entries'], null, 'id');
    $incoming = array_column($data['entries'] ?? [], null, 'id');
    foreach ($oldEntries as $id => $entry) {
        if (isset($v2[$entry['rentalId'] ?? '']) && (!isset($incoming[$id]) || normalize_payment_ledger_entry_for_read($incoming[$id]) !== $entry)) {
            throw new RuntimeException('Историю денег V2 изменяют только компенсирующие операции.', 409);
        }
    }
    foreach ($incoming as $id => $entry) {
        if (!isset($oldEntries[$id]) && isset($v2[$entry['rentalId'] ?? ''])
            && !in_array($entry['type'] ?? '', ['partner_commission_accrued', 'partner_commission_paid', 'partner_commission_correction'], true)) {
            throw new RuntimeException('Платёж V2 должен пройти защищённый сервис.', 409);
        }
    }
}
