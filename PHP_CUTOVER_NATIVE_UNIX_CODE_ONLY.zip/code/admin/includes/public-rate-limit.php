<?php

declare(strict_types=1);

final class PublicRateLimitExceeded extends RuntimeException
{
    public function __construct(private readonly int $retryAfter)
    {
        parent::__construct('Public request rate limit exceeded.', 429);
    }

    public function retryAfter(): int
    {
        return $this->retryAfter;
    }
}

function public_rate_limit_key(string $namespace, string $type, string $value): string
{
    return $type . ':' . hash('sha256', 'rent-rk-' . $namespace . '-rate:' . $value);
}

function public_rate_limit_command_identity(string $kind, string $commandId, array $intent): array
{
    return [
        'key' => 'public-' . $kind . ':' . $commandId,
        'fingerprint' => hash('sha256', json_encode(business_command_canonical($intent), JSON_THROW_ON_ERROR)),
    ];
}

function public_rate_limit_log(string $event, array $context): void
{
    if (function_exists('technical_log')) {
        technical_log($event, $context);
    }
}

function public_rate_limit_io(string $stage, string $path, callable $operation): mixed
{
    $hook = $GLOBALS['rental_return_test_io_failure'] ?? null;
    if (is_callable($hook) && in_array(PHP_SAPI, ['cli', 'cli-server'], true)
        && getenv('RENT_RK_ALLOW_TEST_DATA_DIR') === '1') {
        $fault = $hook($stage, basename($path));
        if (in_array($fault, ['ENOSPC', 'EACCES', 'WRITE', 'FFLUSH', 'FSYNC', 'RENAME', 'READ', 'LOCK'], true)) {
            return false;
        }
    }
    return $operation();
}

function public_rate_limit_checkpoint(string $point): void
{
    $hook = $GLOBALS['rental_return_test_hook'] ?? null;
    if (is_callable($hook) && in_array(PHP_SAPI, ['cli', 'cli-server'], true)
        && getenv('RENT_RK_ALLOW_TEST_DATA_DIR') === '1') {
        $hook($point);
    }
}

function public_rate_limit_write_atomic(string $path, array $state): bool
{
    if (is_link($path) || is_link($path . '.public-rate-limit-tmp')) {
        public_rate_limit_log('public_rate_limit_unavailable', ['reason' => 'unsafe_file_type']);
        return false;
    }
    try {
        $bytes = json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR) . PHP_EOL;
    } catch (Throwable $exception) {
        public_rate_limit_log('public_rate_limit_unavailable', ['reason' => 'encode_failed']);
        return false;
    }

    $temp = $path . '.public-rate-limit-tmp';
    public_rate_limit_checkpoint('rate_limit.write.before_temp');
    $stream = public_rate_limit_io('open', $path, static fn() => @fopen($temp, 'wb'));
    if (!$stream) {
        public_rate_limit_log('public_rate_limit_unavailable', ['reason' => 'open_temp_failed']);
        return false;
    }

    $complete = false;
    try {
        $offset = 0;
        while ($offset < strlen($bytes)) {
            $written = public_rate_limit_io('write', $path, static fn() => @fwrite($stream, substr($bytes, $offset)));
            if ($written === false || $written === 0) {
                public_rate_limit_log('public_rate_limit_unavailable', ['reason' => 'write_failed']);
                return false;
            }
            $offset += $written;
        }
        if (!public_rate_limit_io('flush', $path, static fn() => @fflush($stream))) {
            public_rate_limit_log('public_rate_limit_unavailable', ['reason' => 'flush_failed']);
            return false;
        }
        if (function_exists('fsync') && !public_rate_limit_io('fsync', $path, static fn() => @fsync($stream))) {
            public_rate_limit_log('public_rate_limit_unavailable', ['reason' => 'fsync_failed']);
            return false;
        }
        $complete = true;
        public_rate_limit_checkpoint('rate_limit.write.after_fsync');
    } finally {
        @fclose($stream);
        if (!$complete) {
            @unlink($temp);
        }
    }

    if (@hash_file('sha256', $temp) !== hash('sha256', $bytes)) {
        @unlink($temp);
        public_rate_limit_log('public_rate_limit_unavailable', ['reason' => 'temp_verify_failed']);
        return false;
    }

    $retries = 0;
    while (!public_rate_limit_io('rename', $path, static fn() => @rename($temp, $path))) {
        if (PHP_OS_FAMILY !== 'Windows' || $retries >= 12) {
            @unlink($temp);
            public_rate_limit_log('public_rate_limit_unavailable', ['reason' => 'rename_failed']);
            return false;
        }
        $retries++;
        usleep(25000);
    }
    public_rate_limit_checkpoint('rate_limit.write.after_rename');
    return true;
}

function public_rate_limit_read_state(string $path): ?array
{
    if (is_link($path)) {
        return null;
    }
    if (!file_exists($path)) {
        return ['updatedAt' => null, 'entries' => [], 'reservations' => []];
    }
    if (!is_file($path) || !is_readable($path)) {
        return null;
    }
    $raw = public_rate_limit_io('read', $path, static fn() => @file_get_contents($path));
    if ($raw === false || trim($raw) === '') {
        return null;
    }
    $state = json_decode($raw, true);
    if (!is_array($state) || !isset($state['entries']) || !is_array($state['entries'])) {
        return null;
    }
    foreach ($state['entries'] as $timestamps) {
        if (!is_array($timestamps)) {
            return null;
        }
        foreach ($timestamps as $timestamp) {
            if (!is_int($timestamp) && !(is_string($timestamp) && preg_match('/^\d+$/D', $timestamp))) {
                return null;
            }
        }
    }
    if (array_key_exists('reservations', $state) && !is_array($state['reservations'])) {
        return null;
    }
    $state['reservations'] = $state['reservations'] ?? [];
    return $state;
}

function public_rate_limit_remove_timestamp(array &$entries, string $key, int $timestamp): void
{
    if (!isset($entries[$key]) || !is_array($entries[$key])) {
        return;
    }
    $index = array_search($timestamp, array_map('intval', $entries[$key]), true);
    if ($index !== false) {
        array_splice($entries[$key], (int) $index, 1);
    }
    if (!$entries[$key]) {
        unset($entries[$key]);
    }
}

function public_rate_limit_prepare_state(array $state, int $now): array
{
    $day = 24 * 60 * 60;
    $entries = $state['entries'];
    foreach ($entries as $key => $timestamps) {
        $entries[$key] = array_values(array_filter(array_map('intval', $timestamps), static fn(int $time): bool => $time >= $now - $day));
        if (!$entries[$key]) {
            unset($entries[$key]);
        }
    }

    $receiptsData = read_json_file(REQUESTS_FILE, default_requests());
    $receipts = $receiptsData['commandReceipts'] ?? [];
    if (!is_array($receipts)) {
        throw new RuntimeException('Повреждён журнал заявок.', 503);
    }
    $reservations = $state['reservations'];
    foreach ($reservations as $reservationId => $reservation) {
        if (!is_array($reservation)
            || !is_int($reservation['at'] ?? null)
            || !is_string($reservation['commandKey'] ?? null)
            || !is_string($reservation['fingerprint'] ?? null)
            || !is_array($reservation['keys'] ?? null)) {
            continue;
        }
        $at = $reservation['at'];
        if ($at < $now - $day) {
            unset($reservations[$reservationId]);
            continue;
        }
        $receipt = $receipts[$reservation['commandKey']] ?? null;
        if ($receipt === null) {
            foreach ($reservation['keys'] as $key) {
                if (is_string($key)) {
                    public_rate_limit_remove_timestamp($entries, $key, $at);
                }
            }
            unset($reservations[$reservationId]);
            continue;
        }
        if (is_array($receipt) && is_string($receipt['fingerprint'] ?? null)
            && hash_equals($reservation['fingerprint'], $receipt['fingerprint'])) {
            unset($reservations[$reservationId]);
        }
    }
    $state['entries'] = $entries;
    $state['reservations'] = $reservations;
    return $state;
}

function public_rate_limit_with_lock(callable $operation): mixed
{
    $path = DATA_DIR . 'request-rate-limit.json';
    $lockPath = $path . '.lock';
    if (is_link($lockPath)) {
        return null;
    }
    $lock = public_rate_limit_io('open_lock', $lockPath, static fn() => @fopen($lockPath, 'c'));
    if (!$lock) {
        return null;
    }
    try {
        if (!public_rate_limit_io('lock', $lockPath, static fn() => @flock($lock, LOCK_EX))) {
            return null;
        }
        return $operation($path);
    } finally {
        @flock($lock, LOCK_UN);
        @fclose($lock);
    }
}

function public_rate_limit_reserve(string $namespace, ?string $phone, string $commandId, array $intent): array
{
    if (!in_array($namespace, ['request', 'callback'], true)) {
        throw new LogicException('Unsupported public rate-limit namespace.');
    }
    $identity = public_rate_limit_command_identity($namespace, $commandId, $intent);
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    $keys = [public_rate_limit_key($namespace, 'ip', $ip)];
    if ($phone !== null && $phone !== '') {
        $keys[] = public_rate_limit_key($namespace, 'phone', $phone);
    }

    try {
        $result = public_rate_limit_with_lock(static function (string $path) use ($namespace, $keys, $identity): array {
            $state = public_rate_limit_read_state($path);
            if ($state === null) {
                return ['status' => 'degraded', 'reason' => 'invalid_or_unreadable_state'];
            }
            $now = time();
            $state = public_rate_limit_prepare_state($state, $now);
            $window = 10 * 60;
            $day = 24 * 60 * 60;
            foreach ($keys as $key) {
                $timestamps = array_map('intval', $state['entries'][$key] ?? []);
                $recent = array_values(array_filter($timestamps, static fn(int $time): bool => $time >= $now - $window));
                $isPhone = str_starts_with($key, 'phone:');
                $shortLimit = $isPhone ? 3 : 4;
                $dayLimit = $isPhone ? 6 : 12;
                if (count($recent) >= $shortLimit || count($timestamps) >= $dayLimit) {
                    $oldest = count($recent) >= $shortLimit ? min($recent) : min($timestamps);
                    return ['status' => 'denied', 'retryAfter' => max(60, ($oldest + (count($recent) >= $shortLimit ? $window : $day)) - $now)];
                }
            }

            $reservationId = bin2hex(random_bytes(16));
            foreach ($keys as $key) {
                $state['entries'][$key] = $state['entries'][$key] ?? [];
                $state['entries'][$key][] = $now;
            }
            $state['reservations'][$reservationId] = [
                'at' => $now,
                'namespace' => $namespace,
                'commandKey' => $identity['key'],
                'fingerprint' => $identity['fingerprint'],
                'keys' => $keys,
            ];
            $state['updatedAt'] = date(DATE_ATOM, $now);
            if (!public_rate_limit_write_atomic($path, $state)) {
                return ['status' => 'degraded', 'reason' => 'reservation_write_failed'];
            }
            return [
                'status' => 'reserved',
                'id' => $reservationId,
                'at' => $now,
                'commandKey' => $identity['key'],
                'fingerprint' => $identity['fingerprint'],
                'keys' => $keys,
            ];
        });
    } catch (Throwable $exception) {
        public_rate_limit_log('public_rate_limit_unavailable', ['namespace' => $namespace, 'reason' => 'reserve_exception']);
        return ['status' => 'degraded', 'reason' => 'reserve_exception'];
    }

    if ($result === null) {
        public_rate_limit_log('public_rate_limit_unavailable', ['namespace' => $namespace, 'reason' => 'lock_unavailable']);
        return ['status' => 'degraded', 'reason' => 'lock_unavailable'];
    }
    if (($result['status'] ?? '') === 'degraded') {
        public_rate_limit_log('public_rate_limit_unavailable', ['namespace' => $namespace, 'reason' => $result['reason'] ?? 'unknown']);
    }
    return $result;
}

function public_rate_limit_finish(array $reservation, bool $committed): bool
{
    if (($reservation['status'] ?? '') !== 'reserved') {
        return true;
    }
    try {
        $result = public_rate_limit_with_lock(static function (string $path) use ($reservation, $committed): bool {
            $state = public_rate_limit_read_state($path);
            if ($state === null) {
                return false;
            }
            $stored = $state['reservations'][$reservation['id']] ?? null;
            if (!is_array($stored)
                || ($stored['at'] ?? null) !== $reservation['at']
                || !hash_equals((string) ($stored['commandKey'] ?? ''), (string) $reservation['commandKey'])
                || !hash_equals((string) ($stored['fingerprint'] ?? ''), (string) $reservation['fingerprint'])) {
                return false;
            }
            if (!$committed) {
                foreach ($stored['keys'] ?? [] as $key) {
                    if (is_string($key)) {
                        public_rate_limit_remove_timestamp($state['entries'], $key, (int) $stored['at']);
                    }
                }
            }
            unset($state['reservations'][$reservation['id']]);
            $state['updatedAt'] = date(DATE_ATOM);
            return public_rate_limit_write_atomic($path, $state);
        });
    } catch (Throwable $exception) {
        $result = false;
    }
    if ($result !== true) {
        public_rate_limit_log('public_rate_limit_reconciliation_pending', [
            'namespace' => (string) ($reservation['namespace'] ?? ''),
            'outcome' => $committed ? 'committed' : 'rolled_back',
        ]);
        return false;
    }
    return true;
}
