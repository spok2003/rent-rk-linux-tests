<?php

declare(strict_types=1);

// One lock order for cooperating JSON readers/writers. Never unlink the lock inode.
final class RentalReturnStore
{
    private static $lock = null;
    private static ?array $pending = null;
    private static array $media = [];
    private static array $removedMedia = [];
    private static array $outputs = [];
    private static bool $recovering = false;
    private static bool $poisoned = false;

    public static function owns(string $path): bool
    {
        $parent = realpath(dirname($path));
        $root = realpath(DATA_DIR);
        return $parent !== false && $root !== false && $parent === $root
            && strtolower(pathinfo($path, PATHINFO_EXTENSION)) === 'json'
            && basename($path) !== 'project-progress-map.json';
    }

    public static function active(): bool
    {
        return self::$pending !== null;
    }

    public static function checkpoint(string $point): void
    {
        $hook = $GLOBALS['rental_return_test_hook'] ?? null;
        if (!is_callable($hook)) { return; }
        $root = str_replace('\\', '/', (string) realpath(PROJECT_ROOT . 'tmp')) . '/';
        $data = str_replace('\\', '/', (string) realpath(DATA_DIR)) . '/';
        if (!in_array(PHP_SAPI, ['cli', 'cli-server'], true) || getenv('RENT_RK_ALLOW_TEST_DATA_DIR') !== '1'
            || $root === '/' || !str_starts_with($data, $root)) {
            throw new LogicException('Instrumentation is confined to isolated tmp data.');
        }
        $hook($point);
    }

    private static function directory(): string
    {
        return rtrim(DATA_DIR, '/\\') . '/.rental-transactions';
    }

    public static function enter(bool $noRecovery = false): void
    {
        if (self::$poisoned) {
            throw new RuntimeException('Требуется восстановление хранилища. Повторите запрос после проверки.', 503);
        }
        if (is_resource(self::$lock)) {
            return;
        }
        self::checkpoint('store.before_lock');
        $lock = @fopen(rtrim(DATA_DIR, '/\\') . '/.rental-store.lock', 'c+b');
        if (!$lock) {
            throw new RuntimeException('Хранилище временно недоступно.', 503);
        }
        $deadline = microtime(true) + 10;
        while (!flock($lock, LOCK_EX | LOCK_NB)) {
            if (microtime(true) >= $deadline) {
                fclose($lock);
                throw new RuntimeException('Хранилище занято. Повторите запрос.', 503);
            }
            usleep(10000);
        }
        self::$lock = $lock;
        self::checkpoint('store.after_lock');
        register_shutdown_function([self::class, 'leave']);
        try {
            if ($noRecovery || (defined('RENT_RK_PHP_CAR_PREVIEW_REQUEST') && RENT_RK_PHP_CAR_PREVIEW_REQUEST
                && class_exists(PhpPublicationCutover::class, false) && PhpPublicationCutover::selected())) {
                $journal = self::directory() . '/journal.json';
                foreach ([$journal, $journal . '.rrv2-tmp'] as $path) {
                    if (is_link($path) || file_exists($path)) throw new RuntimeException('BLOCKED_PHP_PREVIEW_RECOVERY_REQUIRED', 409);
                }
            } else {
                self::recover();
            }
        } catch (Throwable $error) {
            self::leave();
            throw $error;
        }
    }

    public static function leave(): void
    {
        self::$pending = null;
        self::$media = [];
        self::$removedMedia = [];
        self::$outputs = [];
        if (is_resource(self::$lock)) {
            flock(self::$lock, LOCK_UN);
            fclose(self::$lock);
        }
        self::$lock = null;
    }

    public static function waitOutsideLock(callable $wait)
    {
        if (self::$pending !== null || self::$recovering) {
            throw new LogicException('External wait is forbidden inside a store transaction or recovery.');
        }
        $hadLock = is_resource(self::$lock);
        if ($hadLock) {
            self::leave();
        }
        try {
            return $wait();
        } finally {
            if ($hadLock) {
                self::enter();
            }
        }
    }

    public static function read(string $path, array $default): array
    {
        self::enter();
        $key = basename($path);
        if (self::$pending !== null && array_key_exists($key, self::$pending)) {
            return self::$pending[$key];
        }
        if (!is_file($path)) {
            return $default;
        }
        $bytes = file_get_contents($path);
        if ($bytes === false) {
            throw new RuntimeException('Не удалось прочитать хранилище.', 503);
        }
        try {
            $value = json_decode(preg_replace('/^\xEF\xBB\xBF/', '', $bytes), true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $error) {
            throw new RuntimeException('Повреждена запись хранилища. Требуется проверка.', 503, $error);
        }
        if (!is_array($value)) {
            throw new RuntimeException('Повреждена структура хранилища.', 503);
        }
        return $value;
    }

    public static function stage(string $path, array $value): bool
    {
        self::enter();
        if (self::$pending === null && function_exists('site_maintenance_business_writes_paused') && site_maintenance_business_writes_paused()) {
            self::leave();
            throw new RuntimeException('Запись временно недоступна: включён режим обслуживания.', 503);
        }
        if (self::$pending === null) {
            return false;
        }
        // Encoding is validated before any business byte is published.
        json_encode($value, JSON_THROW_ON_ERROR);
        self::$pending[basename($path)] = $value;
        return true;
    }

    public static function transaction(callable $work)
    {
        if (function_exists('site_maintenance_business_writes_paused') && site_maintenance_business_writes_paused()) {
            throw new RuntimeException('Запись временно недоступна: включён режим обслуживания.', 503);
        }
        self::checkpoint('transaction.before_lock');
        self::enter();
        self::checkpoint('transaction.after_lock');
        if (function_exists('site_maintenance_business_writes_paused') && site_maintenance_business_writes_paused()) {
            self::leave();
            throw new RuntimeException('Запись временно недоступна: включён режим обслуживания.', 503);
        }
        if (self::$pending !== null) {
            throw new LogicException('Nested rental transaction is forbidden.');
        }
        self::$pending = [];
        self::$media = [];
        self::$removedMedia = [];
        self::$outputs = [];
        try {
            $result = $work();
            $pending = self::$pending;
            self::$pending = null;
            self::commit($pending);
            return $result;
        } finally {
            self::$pending = null;
            self::$media = [];
            self::$removedMedia = [];
            self::$outputs = [];
        }
    }

    private static function publicationOutputPath(string $name): string
    {
        $normalized = str_replace('\\', '/', trim($name));
        $publicCarPage = (bool) preg_match('~^cars/[a-z0-9-]+\.html$~D', $normalized);
        $publicCarIndex = $normalized === 'cars/index.html';
        $publicHome = $normalized === 'index.html';
        $generatedHtml = (bool) preg_match('~^(?:pages|routes)/[a-z0-9-]+\.html$~D', $normalized)
            || (bool) preg_match('~^partner/[a-z0-9-]+/(?:[a-z0-9-]+/)?index\.html$~D', $normalized);
        $publicPromo = $normalized === 'data/promo-badges.json';
        $demandSitemap = $normalized === 'sitemap.xml';
        $demandRobots = $normalized === 'robots.txt';
        $generatedBackup = (bool) preg_match(
            '~^@data/backups/generated-output-(?:backups|baselines)/(?:[a-zA-Z0-9_.-]+/)?(?:cars/[a-z0-9-]+\.html|(?:index\.html|sitemap\.xml|robots\.txt)|(?:pages|routes)/[a-z0-9-]+\.html|partner/[a-z0-9-]+/(?:[a-z0-9-]+/)?index\.html)$~D',
            $normalized
        );
        $promoBackup = (bool) preg_match(
            '~^@data/backups/promo-badges-public/[a-zA-Z0-9_.-]+/promo-badges\.json$~D',
            $normalized
        );
        $demandSitemapBackup = (bool) preg_match(
            '~^@data/backups/demand-sitemap-[a-zA-Z0-9_.-]+/(?:sitemap\.xml|robots\.txt|manifest\.json)$~D',
            $normalized
        );
        $carPlanBackup = (bool) preg_match(
            '~^@data/backups/car-publication-plans/car-plan-[a-f0-9]{20}/(?:index\.html|sitemap\.xml|cars/(?:index|[a-z0-9-]+)\.html)$~D',
            $normalized
        );
        if (!$publicCarPage && !$publicCarIndex && !$publicHome && !$generatedHtml && !$publicPromo && !$demandSitemap && !$demandRobots && !$generatedBackup && !$promoBackup && !$demandSitemapBackup && !$carPlanBackup) {
            throw new RuntimeException('Недопустимый путь публикационного файла.', 409);
        }

        $dataRelative = str_starts_with($normalized, '@data/');
        if ($dataRelative) {
            $normalized = substr($normalized, strlen('@data/'));
        }
        $root = (string) realpath($dataRelative ? DATA_DIR : PROJECT_ROOT);
        if ($root === '') {
            throw new RuntimeException('Корень проекта недоступен.', 503);
        }
        $path = $root;
        foreach (explode('/', $normalized) as $part) {
            $path .= DIRECTORY_SEPARATOR . $part;
            if (is_link($path) || (file_exists($path) && realpath($path) !== $path)) {
                throw new RuntimeException('Небезопасный путь публикационного файла.', 409);
            }
        }

        return $path;
    }

    public static function publicationOutputBytes(string $name): ?string
    {
        if (self::active() && isset(self::$outputs[$name])) {
            return self::$outputs[$name]['after'];
        }
        $path = self::publicationOutputPath($name);
        if (!is_file($path)) return null;
        $bytes = file_get_contents($path);
        if ($bytes === false) throw new RuntimeException('Не удалось прочитать публикационный файл.', 503);
        return $bytes;
    }

    public static function stagePublicationOutput(string $name, string $bytes, ?string $expectedBeforeHash = null): void
    {
        if (!self::active() || $bytes === '' || strlen($bytes) > 10 * 1024 * 1024) {
            throw new LogicException('Publication output writes require a bounded transaction.');
        }
        $path = self::publicationOutputPath($name);
        $existing = self::$outputs[$name] ?? null;
        $before = $existing['before'] ?? (is_file($path) ? file_get_contents($path) : null);
        if ($before === false) throw new RuntimeException('Не удалось прочитать публикационный файл.', 503);
        $current = $existing['after'] ?? $before;
        $actualHash = $current === null ? null : hash('sha256', $current);
        if ($expectedBeforeHash !== null && !hash_equals(strtolower($expectedBeforeHash), strtolower((string) $actualHash))) {
            throw new RuntimeException('Публикационный файл изменился. Обновите страницу и повторите действие.', 409);
        }
        self::$outputs[$name] = [
            'before' => $before,
            'beforeHash' => $before === null ? null : hash('sha256', $before),
            'after' => $bytes,
            'afterHash' => hash('sha256', $bytes),
        ];
    }

    public static function stagePublicationDeletion(string $name): void
    {
        if (!self::active() || str_starts_with($name, '@data/') || str_starts_with($name, 'data/')) {
            throw new LogicException('Public output deletion requires a transaction.');
        }
        $before = self::publicationOutputBytes($name);
        if ($before === null) { return; }
        self::$outputs[$name] = ['before' => $before, 'beforeHash' => hash('sha256', $before),
            'after' => null, 'afterHash' => null];
    }

    private static function mediaPath(string $name): string
    {
        $publicCarPhoto = (bool) preg_match('~^assets/img/cars/[a-z0-9-]+/[a-zA-Z0-9_-]+\.(jpe?g|png|webp)$~Di', $name);
        $privateTemplate = (bool) preg_match('~^document-templates/[a-zA-Z0-9_.-]+/(contract|issue-act|return-act|personal-data-consent|replacement-agreement)/[a-zA-Z0-9_.-]+\.(html|htm|doc|docx)$~D', $name);
        if (str_contains($name, '..') || (!$publicCarPhoto && !$privateTemplate && !preg_match('~^rental-media/[a-zA-Z0-9_.-]+/(issue|return)/[a-zA-Z0-9_.-]+\.(jpe?g|png|webp)$~D', $name))) {
            throw new RuntimeException('Недопустимый путь фото возврата.', 409);
        }
        $root = (string) realpath($publicCarPhoto ? PROJECT_ROOT : DATA_DIR);
        $path = $root;
        foreach (explode('/', $name) as $part) {
            $path .= DIRECTORY_SEPARATOR . $part;
            if (is_link($path) || (file_exists($path) && realpath($path) !== $path)) {
                throw new RuntimeException('Небезопасный путь фото возврата.', 409);
            }
        }
        return $path;
    }

    public static function stagedMediaExists(string $name): ?bool
    {
        if (isset(self::$media[$name])) return true;
        if (isset(self::$removedMedia[$name])) return false;
        return null;
    }

    public static function stageMedia(string $name, string $bytes): void
    {
        if (!self::active() || $bytes === '' || strlen($bytes) > 10 * 1024 * 1024) {
            throw new LogicException('Photo writes require a bounded rental transaction.');
        }
        if (file_exists(self::mediaPath($name)) || isset(self::$media[$name]) || isset(self::$removedMedia[$name])) {
            throw new RuntimeException('Фото с таким идентификатором уже существует.', 409);
        }
        self::$media[$name] = $bytes;
    }

    public static function stageMediaDeletion(string $name): void
    {
        if (!self::active() || isset(self::$media[$name])) {
            throw new LogicException('Photo deletion requires its metadata transaction.');
        }
        $path = self::mediaPath($name);
        if (!is_file($path)) return;
        $bytes = file_get_contents($path);
        if ($bytes === false || $bytes === '' || strlen($bytes) > 10 * 1024 * 1024) {
            throw new RuntimeException('Не удалось сохранить исходное фото для восстановления.', 503);
        }
        self::$removedMedia[$name] = $bytes;
    }

    private static function target(string $name, array $entry): string
    {
        if (($entry['kind'] ?? '') === 'output-delete' && (str_starts_with($name, '@data/') || str_starts_with($name, 'data/'))) {
            throw new RuntimeException('Private or data output deletion refused.', 503);
        }
        if (in_array($entry['kind'] ?? 'json', ['output', 'output-delete'], true)) { return self::publicationOutputPath($name); }
        if (in_array($entry['kind'] ?? 'json', ['media', 'media-delete'], true)) { return self::mediaPath($name); }
        if (basename($name) !== $name || !self::owns(DATA_DIR . $name)) {
            throw new RuntimeException('Недопустимый путь журнала.', 503);
        }
        return DATA_DIR . $name;
    }

    private static function encode(array $value): string
    {
        return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR) . "\n";
    }

    private static function writeFailure(string $stage, string $path, string $message, ?array $last = null): RuntimeException
    {
        $last ??= error_get_last();
        $reason = 'unspecified';
        foreach (['permission denied', 'access is denied', 'being used by another process', 'no such file', 'invalid argument', 'no space left', 'disk quota'] as $known) {
            if (stripos($last['message'] ?? '', $known) !== false) { $reason = $known; break; }
        }
        // No paths, content, tokens or user data. QA may inspect this in-memory diagnostic.
        $GLOBALS['rental_return_io_failures'][] = ['stage' => $stage, 'file' => basename($path), 'reason' => $reason,
            'windowsCode' => self::windowsErrorCode($last),
            'targetExists' => is_file($path), 'tempExists' => is_file($path . '.rrv2-tmp')];
        return new RuntimeException($message, 503);
    }

    private static function windowsErrorCode(?array $error): ?int
    {
        return preg_match('/code:\s*(\d+)/i', $error['message'] ?? '', $match) ? (int) $match[1] : null;
    }

    private static function io(string $stage, string $path, callable $operation): mixed
    {
        $hook = $GLOBALS['rental_return_test_io_failure'] ?? null;
        if (is_callable($hook) && in_array(PHP_SAPI, ['cli', 'cli-server'], true)
            && getenv('RENT_RK_ALLOW_TEST_DATA_DIR') === '1') {
            $tmp = realpath(dirname(__DIR__, 2) . '/tmp');
            $data = realpath(DATA_DIR);
            if (!$tmp || !$data || !str_starts_with($data, $tmp . DIRECTORY_SEPARATOR)) {
                throw new RuntimeException('I/O injection outside isolated data is forbidden.', 503);
            }
            $fault = $hook($stage, basename($path));
            if (in_array($fault, ['ENOSPC', 'EACCES', 'WRITE', 'FFLUSH', 'FSYNC', 'RENAME'], true)) {
                $GLOBALS['rental_return_io_failures'][] = ['kind' => 'injected_not_os', 'stage' => $stage, 'fault' => $fault, 'file' => basename($path)];
                return false;
            }
        }
        return $operation();
    }

    private static function replace(string $path, string $bytes): void
    {
        $temp = $path . '.rrv2-tmp';
        self::checkpoint('write.before_temp.' . basename($path));
        $stream = self::io('open', $path, static fn() => @fopen($temp, 'wb'));
        if (!$stream) {
            throw self::writeFailure('open_temp', $path, 'Не удалось подготовить запись.');
        }
        try {
            $offset = 0;
            while ($offset < strlen($bytes)) {
                $count = self::io('write', $path, static fn() => fwrite($stream, substr($bytes, $offset)));
                if ($count === false || $count === 0) {
                    throw self::writeFailure('write_bytes', $path, 'Неполная запись хранилища.');
                }
                $offset += $count;
            }
            if (!self::io('flush', $path, static fn() => fflush($stream)) || !self::io('fsync', $path, static fn() => fsync($stream))) {
                throw self::writeFailure('flush_sync', $path, 'Не удалось подтвердить запись на диск.');
            }
            self::checkpoint('write.after_fsync.' . basename($path));
        } finally {
            fclose($stream);
        }
        if (hash_file('sha256', $temp) !== hash('sha256', $bytes)) {
            throw self::writeFailure('verify_temp', $path, 'Не удалось проверить запись.');
        }
        error_clear_last();
        $renameRetries = 0;
        while (!self::io('rename', $path, static fn() => @rename($temp, $path))) {
            $last = error_get_last();
            $code = self::windowsErrorCode($last);
            // Keep the same lock, prepared bytes and transaction. Never replay the business action.
            if (PHP_OS_FAMILY !== 'Windows' || !in_array($code, [5, 32, 33], true) || $renameRetries >= 12) {
                throw self::writeFailure('publish_rename', $path, 'Не удалось опубликовать запись.', $last);
            }
            $renameRetries++;
            self::checkpoint('write.rename_denied');
            usleep(25000);
            error_clear_last();
        }
        if ($renameRetries > 0) {
            $GLOBALS['rental_return_io_failures'][] = ['stage' => 'publish_retry_resolved', 'file' => basename($path), 'attempts' => $renameRetries];
        }
        self::checkpoint('write.after_rename.' . basename($path));
    }

    private static function commit(array $pending): void
    {
        if (!$pending && !self::$media && !self::$removedMedia && !self::$outputs) {
            return;
        }
        $dir = self::directory();
        if (!is_dir($dir) && !@mkdir($dir, 0700)) {
            throw new RuntimeException('Не удалось создать журнал транзакций.', 503);
        }
        $files = [];
        ksort($pending);
        foreach ($pending as $name => $value) {
            $path = DATA_DIR . $name;
            $before = is_file($path) ? file_get_contents($path) : null;
            if ($before === false) {
                throw new RuntimeException('Не удалось прочитать исходную запись.', 503);
            }
            if ($before !== null) {
                json_decode(preg_replace('/^\xEF\xBB\xBF/', '', $before), true, 512, JSON_THROW_ON_ERROR);
            }
            $after = self::encode($value);
            if ($before === $after) {
                continue;
            }
            $files[$name] = ['before' => $before === null ? null : base64_encode($before), 'after' => base64_encode($after),
                'beforeHash' => $before === null ? null : hash('sha256', $before), 'afterHash' => hash('sha256', $after)];
        }
        foreach (self::$media as $name => $bytes) {
            $files[$name] = ['kind' => 'media', 'before' => null, 'beforeHash' => null,
                'after' => base64_encode($bytes), 'afterHash' => hash('sha256', $bytes)];
        }
        foreach (self::$removedMedia as $name => $bytes) {
            if (hash_file('sha256', self::mediaPath($name)) !== hash('sha256', $bytes)) {
                throw new RuntimeException('Фото изменилось во время удаления.', 409);
            }
            $files[$name] = ['kind' => 'media-delete', 'before' => base64_encode($bytes), 'beforeHash' => hash('sha256', $bytes),
                'after' => null, 'afterHash' => null];
        }
        foreach (self::$outputs as $name => $output) {
            $files[$name] = [
                'kind' => $output['after'] === null ? 'output-delete' : 'output',
                'before' => $output['before'] === null ? null : base64_encode($output['before']),
                'beforeHash' => $output['beforeHash'],
                'after' => $output['after'] === null ? null : base64_encode($output['after']),
                'afterHash' => $output['afterHash'],
            ];
        }
        if (!$files) {
            return;
        }
        $journal = ['format' => 1, 'decision' => 'prepared', 'files' => $files];
        $journalPath = $dir . '/journal.json';
        self::replace($journalPath, self::encode($journal));
        self::checkpoint('journal.prepared');
        try {
            foreach ($files as $name => $entry) {
                $target = self::target($name, $entry);
                if (!is_dir(dirname($target)) && !@mkdir(dirname($target), 0700, true)) {
                    throw new RuntimeException('Не удалось подготовить папку фото.', 503);
                }
                if (in_array($entry['kind'] ?? '', ['media-delete', 'output-delete'], true)) {
                    if (!self::io('unlink', $target, static fn() => @unlink($target))) {
                        throw self::writeFailure('delete_media', $target, 'Не удалось удалить фото.');
                    }
                    self::checkpoint('write.after_unlink.' . basename($target));
                } else {
                    self::replace($target, base64_decode($entry['after'], true));
                }
            }
            $journal['decision'] = 'committed';
            self::replace($journalPath, self::encode($journal));
            self::checkpoint('journal.committed');
        } catch (Throwable $error) {
            // Prepared decisions roll back; a durable committed decision rolls forward.
            self::recover();
            throw $error;
        }
        self::recover();
    }

    private static function recover(): void
    {
        $journalPath = self::directory() . '/journal.json';
        if (self::$recovering) {
            return;
        }
        if (!is_file($journalPath)) {
            if (is_file($journalPath . '.rrv2-tmp') && !unlink($journalPath . '.rrv2-tmp')) {
                throw new RuntimeException('Не удалось убрать неподтверждённый журнал.', 503);
            }
            return;
        }
        self::$recovering = true;
        try {
            $journal = json_decode((string) file_get_contents($journalPath), true, 512, JSON_THROW_ON_ERROR);
            if (($journal['format'] ?? null) !== 1 || !in_array($journal['decision'] ?? '', ['prepared', 'committed'], true)
                || !is_array($journal['files'] ?? null) || !$journal['files']) {
                throw new RuntimeException('Неоднозначный журнал: требуется проверка хранилища.', 503);
            }
            // Validate the complete recovery set BEFORE restoring any individual file.
            foreach ($journal['files'] as $name => $entry) {
                if (!is_string($name) || !is_array($entry) || !in_array($entry['kind'] ?? 'json', ['json', 'media', 'media-delete', 'output', 'output-delete'], true)) {
                    throw new RuntimeException('Недопустимый путь журнала.', 503);
                }
                $target = self::target($name, $entry);
                $deletion = in_array($entry['kind'] ?? 'json', ['media-delete', 'output-delete'], true);
                $media = in_array($entry['kind'] ?? 'json', ['media', 'media-delete'], true);
                $output = in_array($entry['kind'] ?? 'json', ['output', 'output-delete'], true);
                if ($media && !$deletion && (($entry['before'] ?? null) !== null || ($entry['beforeHash'] ?? null) !== null)) {
                    throw new RuntimeException('Журнал не может перезаписывать историческое фото.', 503);
                }
                if ($deletion && (!isset($entry['before'], $entry['beforeHash']) || !array_key_exists('after', $entry)
                    || !array_key_exists('afterHash', $entry) || $entry['after'] !== null || $entry['afterHash'] !== null)) {
                    throw new RuntimeException('Повреждён журнал удаления фото.', 503);
                }
                foreach (['before', 'after'] as $side) {
                    $encoded = $entry[$side] ?? null;
                    $bytes = $encoded === null ? null : base64_decode($encoded, true);
                    if (($side === 'after' && $bytes === null && !$deletion) || $bytes === false
                        || ($bytes === null ? null : hash('sha256', $bytes)) !== ($entry[$side . 'Hash'] ?? null)) {
                        throw new RuntimeException('Повреждено содержимое журнала.', 503);
                    }
                    if ($bytes !== null && ((($media || $output) && (strlen($bytes) === 0 || strlen($bytes) > 10 * 1024 * 1024))
                        || (!$media && !$output && !is_array(json_decode(preg_replace('/^\xEF\xBB\xBF/', '', $bytes), true, 512, JSON_THROW_ON_ERROR))))) {
                        throw new RuntimeException('Повреждена запись журнала.', 503);
                    }
                }
                $actual = is_file($target) ? hash_file('sha256', $target) : null;
                if ($actual !== $entry['beforeHash'] && $actual !== $entry['afterHash']) {
                    throw new RuntimeException('Конфликт восстановления. Записи не изменены.', 503);
                }
            }
            $side = $journal['decision'] === 'committed' ? 'after' : 'before';
            self::checkpoint('recovery.before_apply');
            foreach ($journal['files'] as $name => $entry) {
                $target = self::target($name, $entry);
                if ($entry[$side] === null) {
                    if (is_file($target) && !unlink($target)) {
                        throw new RuntimeException('Не удалось восстановить отсутствие записи.', 503);
                    }
                } elseif (!is_file($target) || hash_file('sha256', $target) !== $entry[$side . 'Hash']) {
                    if (!is_dir(dirname($target)) && !@mkdir(dirname($target), 0700, true)) {
                        throw new RuntimeException('Не удалось восстановить папку фото.', 503);
                    }
                    self::replace($target, base64_decode($entry[$side], true));
                }
                if (is_file($target . '.rrv2-tmp') && !unlink($target . '.rrv2-tmp')) {
                    throw new RuntimeException('Не удалось завершить восстановление.', 503);
                }
                self::checkpoint('recovery.after_file.' . basename($target));
            }
            if (!unlink($journalPath)) {
                throw new RuntimeException('Не удалось завершить журнал транзакции.', 503);
            }
            if (is_file($journalPath . '.rrv2-tmp') && !unlink($journalPath . '.rrv2-tmp')) {
                throw new RuntimeException('Не удалось убрать временный журнал.', 503);
            }
            self::checkpoint('journal.cleaned');
        } catch (Throwable $error) {
            self::$poisoned = true;
            throw new RuntimeException('Восстановление хранилища не подтверждено. Требуется проверка.', 503, $error);
        } finally {
            self::$recovering = false;
        }
    }
}
