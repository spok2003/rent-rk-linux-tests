<?php

declare(strict_types=1);

const CAR_PUBLICATION_PLAN_SCHEMA = 1;
const CAR_PUBLICATION_RENDERER_VERSION = 'php-native-car-v1';

function default_car_publication_plan_store(): array
{
    return ['schemaVersion' => CAR_PUBLICATION_PLAN_SCHEMA, 'updatedAt' => null, 'items' => []];
}

function read_car_publication_plan_store(): array
{
    $store = read_json_file(CAR_PUBLICATION_PLANS_FILE, default_car_publication_plan_store());
    $store['schemaVersion'] = CAR_PUBLICATION_PLAN_SCHEMA;
    $store['items'] = isset($store['items']) && is_array($store['items']) ? $store['items'] : [];

    return $store;
}

function save_car_publication_plan_store(array $store): void
{
    if (!RentalReturnStore::active()) {
        throw new LogicException('Publication plan storage requires a transaction.');
    }
    $store['schemaVersion'] = CAR_PUBLICATION_PLAN_SCHEMA;
    $store['updatedAt'] = now_iso();
    $store['items'] = isset($store['items']) && is_array($store['items']) ? $store['items'] : [];
    write_json_file(CAR_PUBLICATION_PLANS_FILE, $store);
}

function car_publication_canonical_value(mixed $value): mixed
{
    if (!is_array($value)) {
        return $value;
    }
    if (array_is_list($value)) {
        return array_map('car_publication_canonical_value', $value);
    }
    ksort($value, SORT_STRING);
    foreach ($value as $key => $item) {
        $value[$key] = car_publication_canonical_value($item);
    }

    return $value;
}

function car_publication_digest(array $value): string
{
    return hash('sha256', json_encode(
        car_publication_canonical_value($value),
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
    ));
}

function car_publication_file_hash(string $path): ?string
{
    if (!is_file($path)) {
        return null;
    }
    $hash = hash_file('sha256', $path);
    if (!is_string($hash)) {
        throw new RuntimeException('Не удалось вычислить SHA публикационного файла.', 503);
    }

    return $hash;
}

function car_publication_output_paths(string $slug): array
{
    return ['cars/' . normalize_car_slug($slug) . '.html', 'cars/index.html', 'index.html', 'sitemap.xml'];
}

function car_publication_assert_access(string $slug): array
{
    if (!has_permission('cars.publish') && !has_permission('content.publish.single_page')) {
        throw new RuntimeException('Недостаточно прав для публикации.', 403);
    }
    $slug = normalize_car_slug($slug);
    if ($slug === '') {
        throw new InvalidArgumentException('Некорректный slug автомобиля.');
    }
    PhpPublicationAutomation::assertNewOperationAllowed($slug);
    $car = find_car($slug);
    if (!is_array($car)) {
        throw new RuntimeException('Автомобиль не найден.', 404);
    }
    $allowed = false;
    foreach (scope_cars_for_current_user(read_cars()) as $candidate) {
        if ((string) ($candidate['slug'] ?? '') === $slug) {
            $allowed = true;
            break;
        }
    }
    if (!$allowed) {
        throw new RuntimeException('Автомобиль находится вне доступного контура.', 403);
    }
    if (!car_visible_in_public_rent_rk_showcase($car)) {
        throw new RuntimeException('Публикация заблокирована: автомобиль не включён в публичную витрину.', 409);
    }

    return $car;
}

function car_publication_actor_binding(): array
{
    return [
        'login' => current_admin_user(),
        'role' => current_admin_role(),
        'scopeId' => current_user_data_scope_id() ?: 'rent_rk',
    ];
}

function car_publication_money(?int $value): string
{
    return $value === null ? '' : number_format($value, 0, '.', ' ');
}

function car_publication_display_price(array $car, array $rate): ?int
{
    foreach (['manual', 'base', 'day', 'daily'] as $key) {
        $value = normalize_rate_price($rate[$key] ?? null);
        if ($value !== null) {
            return $value;
        }
    }
    foreach (['price', 'basePrice', 'dailyRate'] as $key) {
        $value = normalize_rate_price($car[$key] ?? null);
        if ($value !== null) {
            return $value;
        }
    }

    return null;
}

function car_publication_render_card_page(string $html, string $slug, ?int $price, ?int $deposit): string
{
    $quoted = preg_quote($slug, '~');
    $pattern = '~<article class="card car-card"(?=[^>]*(?:data-slug|data-car-slug)="' . $quoted . '")[\s\S]*?</article>~u';

    return preg_replace_callback($pattern, static function (array $match) use ($price, $deposit): string {
        $block = $match[0];
        $number = car_publication_money($price);
        $priceValue = $price === null ? '' : (string) $price;
        $badge = $price === null ? 'Цена по запросу' : 'от ' . str_replace(' ', "\u{00A0}", $number) . ' ₽/сут';
        $daily = $price === null ? 'Цена по запросу' : 'от ' . str_replace(' ', '&#160;', $number) . ' ₽/сут';
        $depositText = $deposit === null ? '' : 'Залог: ' . car_publication_money($deposit) . ' ₽';
        $block = preg_replace('~data-price="[^"]*"~u', 'data-price="' . $priceValue . '"', $block) ?? $block;
        $block = preg_replace('~(<div class="car-card__price-badge">).*?(</div>)~su', '$1' . htmlspecialchars($badge, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '$2', $block, 1) ?? $block;
        $block = preg_replace('~(<span class="car-card__daily">).*?(</span>)~su', '$1' . $daily . '$2', $block, 1) ?? $block;
        if ($depositText === '') {
            $block = preg_replace('~\s*<span class="car-card__(?:deposit|condition)">Залог:.*?</span>~su', '', $block) ?? $block;
        } elseif (preg_match('~<span class="car-card__deposit">.*?</span>~su', $block)) {
            $block = preg_replace('~(<span class="car-card__deposit">).*?(</span>)~su', '$1' . htmlspecialchars($depositText, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '$2', $block, 1) ?? $block;
        } else {
            $block = preg_replace('~(<span class="car-card__daily">.*?</span>)~su', '$1' . PHP_EOL . '      <span class="car-card__deposit">' . htmlspecialchars($depositText, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</span>', $block, 1) ?? $block;
        }

        return $block;
    }, $html) ?? $html;
}

function car_publication_render_detail(string $slug, array $car, array $rate): string
{
    $render = render_car_page_content_html($slug);
    $html = (string) ($render['html'] ?? '');
    if ($html === '') {
        throw new RuntimeException('PHP-native renderer вернул пустую страницу.', 503);
    }
    $price = car_publication_display_price($car, $rate);
    $deposit = normalize_rate_price($rate['depositAmount'] ?? $rate['deposit'] ?? $car['depositAmount'] ?? null);
    $priceText = $price === null ? 'Цена уточняется' : 'от ' . car_publication_money($price) . ' р./сутки';
    $depositText = $deposit === null ? '' : 'Залог: ' . car_publication_money($deposit) . ' ₽';
    $html = preg_replace('~(<p class="car-hero-price"[^>]*>).*?(</p>)~su', '$1' . htmlspecialchars($priceText, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '$2', $html, 1) ?? $html;
    $html = preg_replace('~(<tr><th>Цена от</th><td>).*?(</td></tr>)~su', '$1' . htmlspecialchars($priceText, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '$2', $html, 1) ?? $html;
    if ($depositText !== '' && preg_match('~(<tr><th>Залог</th><td>).*?(</td></tr>)~su', $html)) {
        $html = preg_replace('~(<tr><th>Залог</th><td>).*?(</td></tr>)~su', '$1' . htmlspecialchars($depositText, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '$2', $html, 1) ?? $html;
    }

    return $html;
}

function car_publication_render_sitemap(string $xml, string $slug): string
{
    $url = rtrim(RENT_RK_PUBLIC_BASE_URL, '/') . '/cars/' . $slug . '.html';
    if (str_contains($xml, '<loc>' . $url . '</loc>')) {
        return $xml;
    }
    $entry = "  <url>\n    <loc>" . htmlspecialchars($url, ENT_XML1 | ENT_COMPAT, 'UTF-8') . "</loc>\n  </url>\n";
    $updated = preg_replace('~</urlset>\s*$~', $entry . '</urlset>' . PHP_EOL, $xml, 1);
    if (!is_string($updated) || $updated === $xml) {
        throw new RuntimeException('Sitemap не содержит допустимый корневой элемент urlset.', 409);
    }

    return $updated;
}

function car_publication_render_outputs(string $slug, array $car): array
{
    $rate = rate_for_car($slug, $car);
    $price = car_publication_display_price($car, $rate);
    $deposit = normalize_rate_price($rate['depositAmount'] ?? $rate['deposit'] ?? $car['depositAmount'] ?? null);
    $result = [];
    foreach (car_publication_output_paths($slug) as $outputPath) {
        $fullPath = build_state_public_output_full_path($outputPath);
        $before = is_file($fullPath) ? file_get_contents($fullPath) : false;
        if (!is_string($before) || $before === '') {
            throw new RuntimeException('Отсутствует обязательный publication target: ' . $outputPath, 409);
        }
        $after = match ($outputPath) {
            'cars/' . $slug . '.html' => car_publication_render_detail($slug, $car, $rate),
            'cars/index.html', 'index.html' => car_publication_render_card_page($before, $slug, $price, $deposit),
            'sitemap.xml' => car_publication_render_sitemap($before, $slug),
            default => throw new LogicException('Unexpected publication output.'),
        };
        $result[] = [
            'path' => $outputPath,
            'beforeHash' => hash('sha256', $before),
            'afterHash' => hash('sha256', $after),
            'changed' => !hash_equals(hash('sha256', $before), hash('sha256', $after)),
            'payloadBase64' => base64_encode($after),
        ];
    }

    return $result;
}

function car_publication_build_binding(array $buildState, string $slug, array $outputPaths): array
{
    $outputSet = array_fill_keys($outputPaths, true);
    $outputs = [];
    foreach ($outputPaths as $path) {
        $outputs[$path] = $buildState['outputs'][$path] ?? null;
    }
    $dirty = array_values(array_filter($buildState['dirty'] ?? [], static function ($row) use ($slug): bool {
        return is_array($row) && (string) ($row['entityId'] ?? '') === $slug;
    }));
    $conflicts = array_values(array_filter($buildState['conflicts'] ?? [], static function ($row) use ($slug, $outputSet): bool {
        return is_array($row) && ((string) ($row['entityId'] ?? '') === $slug || isset($outputSet[(string) ($row['outputPath'] ?? '')]));
    }));

    return ['outputs' => $outputs, 'dirty' => $dirty, 'conflicts' => $conflicts];
}

function car_publication_assert_no_public_data_drift(array $buildState, string $slug): void
{
    foreach (($buildState['dirty'] ?? []) as $row) {
        if (!is_array($row)) {
            continue;
        }
        $entityType = (string) ($row['entityType'] ?? '');
        $entityId = (string) ($row['entityId'] ?? '');
        if ($entityType === 'public_data' && ($entityId === $slug || $entityId === 'current-cars')) {
            throw new RuntimeException('Публикация заблокирована: для автомобиля отмечено расхождение public data.', 409);
        }
    }
    foreach (($buildState['conflicts'] ?? []) as $row) {
        if (!is_array($row)) {
            continue;
        }
        $path = str_replace('\\', '/', (string) ($row['outputPath'] ?? ''));
        if ((string) ($row['entityId'] ?? '') === $slug && str_starts_with($path, 'data/')) {
            throw new RuntimeException('Публикация заблокирована: public data находится в conflict.', 409);
        }
    }
}

function car_publication_source_binding(string $slug, array $car, array $outputPaths): array
{
    $settings = [
        'renderer' => CAR_PUBLICATION_RENDERER_VERSION,
        'baseUrl' => RENT_RK_PUBLIC_BASE_URL,
        'outputs' => $outputPaths,
        'publicDataPolicy' => 'excluded_php_api_runtime',
        'deletePolicy' => 'forbidden',
    ];
    $buildBinding = car_publication_build_binding(read_build_state(), $slug, $outputPaths);

    return [
        'carsHash' => car_publication_file_hash(CARS_FILE),
        'ratesHash' => car_publication_file_hash(RATES_FILE),
        'pageContentHash' => car_publication_file_hash(CAR_PAGE_CONTENT_FILE),
        'carVersion' => business_record_version(CARS_FILE, $slug, 'slug'),
        'carHash' => car_publication_digest($car),
        'settingsHash' => car_publication_digest($settings),
        'buildBindingHash' => car_publication_digest($buildBinding),
        'settings' => $settings,
    ];
}

function car_publication_prepare_plan(string $slug): array
{
    if (!RentalReturnStore::active()) {
        return RentalReturnStore::transaction(static fn(): array => car_publication_prepare_plan($slug));
    }
    $car = car_publication_assert_access($slug);
    $slug = normalize_car_slug($slug);
    car_publication_assert_no_public_data_drift(read_build_state(), $slug);
    $outputs = car_publication_render_outputs($slug, $car);
    if (!array_filter($outputs, static fn(array $row): bool => !empty($row['changed']))) {
        throw new RuntimeException('Публикационный план не создан: все целевые файлы уже актуальны.', 409);
    }
    $paths = array_column($outputs, 'path');
    $immutable = [
        'schemaVersion' => CAR_PUBLICATION_PLAN_SCHEMA,
        'rendererVersion' => CAR_PUBLICATION_RENDERER_VERSION,
        'slug' => $slug,
        'actor' => car_publication_actor_binding(),
        'source' => car_publication_source_binding($slug, $car, $paths),
        'outputs' => $outputs,
        'deletePaths' => [],
        'publicDataPaths' => [],
    ];
    $digest = car_publication_digest($immutable);
    $id = 'cpp_' . substr($digest, 0, 32);
    $store = read_car_publication_plan_store();
    $existing = $store['items'][$id] ?? null;
    if (is_array($existing)) {
        if (!hash_equals((string) ($existing['digest'] ?? ''), $digest)) {
            throw new RuntimeException('Конфликт идентификатора публикационного плана.', 409);
        }
        return $existing;
    }
    $plan = [
        'id' => $id,
        'digest' => $digest,
        'state' => 'prepared',
        'preparedAt' => now_iso(),
        'appliedAt' => null,
        'appliedBy' => null,
        'immutable' => $immutable,
    ];
    $store['items'][$id] = $plan;
    save_car_publication_plan_store($store);
    audit_log('car_publication.plan_prepared', 'car_publication_plan', $id, 'Подготовлен двухфазный план публикации автомобиля', [
        'slug' => $slug,
        'planDigest' => $digest,
        'outputs' => array_map(static fn(array $row): array => array_diff_key($row, ['payloadBase64' => true]), $outputs),
        'publicDataWritten' => false,
        'deleteCount' => 0,
    ]);

    return $plan;
}

function car_publication_find_plan(string $id): ?array
{
    $plan = read_car_publication_plan_store()['items'][trim($id)] ?? null;
    return is_array($plan) ? $plan : null;
}

function car_publication_public_plan_view(array $plan): array
{
    $immutable = is_array($plan['immutable'] ?? null) ? $plan['immutable'] : [];
    $outputs = [];
    foreach (($immutable['outputs'] ?? []) as $row) {
        if (!is_array($row)) {
            continue;
        }
        unset($row['payloadBase64']);
        $outputs[] = $row;
    }

    return [
        'id' => (string) ($plan['id'] ?? ''),
        'digest' => (string) ($plan['digest'] ?? ''),
        'state' => (string) ($plan['state'] ?? ''),
        'preparedAt' => (string) ($plan['preparedAt'] ?? ''),
        'appliedAt' => (string) ($plan['appliedAt'] ?? ''),
        'slug' => (string) ($immutable['slug'] ?? ''),
        'actor' => $immutable['actor'] ?? [],
        'outputs' => $outputs,
        'source' => $immutable['source'] ?? [],
    ];
}

function car_publication_apply_plan(string $id, string $submittedDigest, string $expectedSlug = ''): array
{
    if (!RentalReturnStore::active()) {
        return RentalReturnStore::transaction(static fn(): array => car_publication_apply_plan($id, $submittedDigest, $expectedSlug));
    }
    $store = read_car_publication_plan_store();
    $plan = $store['items'][trim($id)] ?? null;
    if (!is_array($plan)) {
        throw new RuntimeException('Публикационный план не найден.', 404);
    }
    $immutable = is_array($plan['immutable'] ?? null) ? $plan['immutable'] : [];
    $digest = car_publication_digest($immutable);
    if (!hash_equals((string) ($plan['digest'] ?? ''), $digest) || !hash_equals($digest, trim($submittedDigest))) {
        throw new RuntimeException('Публикационный план повреждён или был подменён.', 409);
    }
    if (!hash_equals('cpp_' . substr($digest, 0, 32), (string) ($plan['id'] ?? '')) || !hash_equals((string) ($plan['id'] ?? ''), trim($id))) {
        throw new RuntimeException('Идентификатор публикационного плана не соответствует payload.', 409);
    }
    if ((string) ($plan['state'] ?? '') === 'applied') {
        return ['success' => true, 'alreadyApplied' => true, 'plan' => car_publication_public_plan_view($plan)];
    }
    if ((string) ($plan['state'] ?? '') !== 'prepared') {
        throw new RuntimeException('Публикационный план находится в недопустимом состоянии.', 409);
    }
    $slug = normalize_car_slug((string) ($immutable['slug'] ?? ''));
    $expectedSlug = normalize_car_slug($expectedSlug);
    if ($expectedSlug === '' || !hash_equals($slug, $expectedSlug)) {
        throw new RuntimeException('План относится к другому автомобилю.', 409);
    }
    $car = car_publication_assert_access($slug);
    if (!hash_equals(car_publication_digest($immutable['actor'] ?? []), car_publication_digest(car_publication_actor_binding()))) {
        throw new RuntimeException('План подтверждает другой пользователь или контур.', 403);
    }
    $outputs = isset($immutable['outputs']) && is_array($immutable['outputs']) ? $immutable['outputs'] : [];
    $paths = array_column($outputs, 'path');
    if ($paths !== car_publication_output_paths($slug) || ($immutable['deletePaths'] ?? null) !== [] || ($immutable['publicDataPaths'] ?? null) !== []) {
        throw new RuntimeException('Публикационный plan выходит за разрешённый car-scoped allowlist.', 409);
    }
    $currentSource = car_publication_source_binding($slug, $car, $paths);
    if (!hash_equals(car_publication_digest($immutable['source'] ?? []), car_publication_digest($currentSource))) {
        throw new RuntimeException('Источник, настройки или build-state изменились после просмотра плана.', 409);
    }
    $changed = [];
    $runId = 'car-plan-' . substr($digest, 0, 20);
    foreach ($outputs as $row) {
        if (!is_array($row)) {
            throw new RuntimeException('Некорректный output manifest публикационного плана.', 409);
        }
        $path = (string) ($row['path'] ?? '');
        $payload = base64_decode((string) ($row['payloadBase64'] ?? ''), true);
        if (!is_string($payload) || $payload === '' || !hash_equals((string) ($row['afterHash'] ?? ''), hash('sha256', $payload))) {
            throw new RuntimeException('Payload публикационного плана повреждён.', 409);
        }
        $fullPath = build_state_public_output_full_path($path);
        $before = is_file($fullPath) ? file_get_contents($fullPath) : false;
        if (!is_string($before) || !hash_equals((string) ($row['beforeHash'] ?? ''), hash('sha256', $before))) {
            throw new RuntimeException('Целевой файл изменился после просмотра плана.', 409);
        }
        RentalReturnStore::stagePublicationOutput('@data/backups/car-publication-plans/' . $runId . '/' . $path, $before);
        RentalReturnStore::stagePublicationOutput($path, $payload, (string) $row['beforeHash']);
        if ($path === 'sitemap.xml' && $before !== $payload) {
            require_once __DIR__ . '/approved-public-car-snapshot.php';
            ApprovedPublicCarSnapshots::recordOptionCSitemap($slug, $digest, $before, $payload);
        }
        if (!empty($row['changed'])) {
            $changed[] = $path;
        }
    }
    $buildState = read_build_state();
    foreach ($outputs as $row) {
        $path = (string) $row['path'];
        $buildState['outputs'][$path] = [
            'outputPath' => $path,
            'entityType' => 'car',
            'entityId' => $slug,
            'sourcePath' => 'car-publication-plans.json',
            'sourceHash' => 'sha256:' . $digest,
            'outputHash' => 'sha256:' . (string) $row['afterHash'],
            'generator' => CAR_PUBLICATION_RENDERER_VERSION,
            'generatedAt' => now_iso(),
            'backupPath' => 'backups/car-publication-plans/' . $runId . '/' . $path,
        ];
    }
    $buildState['dirty'] = array_values(array_filter($buildState['dirty'] ?? [], static fn($row): bool => !is_array($row) || (string) ($row['entityId'] ?? '') !== $slug));
    $outputSet = array_fill_keys($paths, true);
    $buildState['conflicts'] = array_values(array_filter(
        $buildState['conflicts'] ?? [],
        static fn($row): bool => !is_array($row)
            || ((string) ($row['entityId'] ?? '') !== $slug
                && !isset($outputSet[(string) ($row['outputPath'] ?? '')]))
    ));
    $buildState['lastRun'] = [
        'id' => $runId,
        'mode' => 'CarPublicationPlan',
        'engine' => 'php-native',
        'status' => 'completed',
        'outputs' => $paths,
        'changedFiles' => $changed,
        'deleteCount' => 0,
        'publicDataWritten' => false,
        'planId' => $id,
        'planDigest' => $digest,
        'completedAt' => now_iso(),
    ];
    $buildState['runs'][] = $buildState['lastRun'];
    $buildState['runs'] = array_slice($buildState['runs'], -50);
    save_build_state($buildState);
    $plan['state'] = 'applied';
    $plan['appliedAt'] = now_iso();
    $plan['appliedBy'] = current_admin_user();
    $store['items'][$id] = $plan;
    save_car_publication_plan_store($store);
    audit_log('car_publication.plan_applied', 'car_publication_plan', $id, 'Применён подтверждённый план публикации автомобиля', [
        'slug' => $slug,
        'planDigest' => $digest,
        'outputs' => $paths,
        'changedFiles' => $changed,
        'backupRoot' => 'private/rent-rk-data/backups/car-publication-plans/' . $runId,
        'publicDataWritten' => false,
        'deleteCount' => 0,
        'payloadRegenerated' => false,
    ]);

    return ['success' => true, 'alreadyApplied' => false, 'changedFiles' => $changed, 'plan' => car_publication_public_plan_view($plan)];
}
