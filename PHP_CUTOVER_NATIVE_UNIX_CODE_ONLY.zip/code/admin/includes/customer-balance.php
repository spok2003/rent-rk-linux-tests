<?php

declare(strict_types=1);

function default_customer_balances(): array
{
    return ['schema' => 1, 'events' => []];
}

function customer_balance_event_defaults(): array
{
    return [
        'id' => '',
        'type' => '',
        'amount' => 0,
        'customerId' => '',
        'scopeId' => '',
        'sourceRentalId' => '',
        'sourcePaymentId' => '',
        'sourceKind' => '',
        'sourceCreditId' => '',
        'targetRentalId' => '',
        'targetObligationId' => '',
        'ledgerEntryId' => '',
        'operationId' => '',
        'relatedEventId' => '',
        'reason' => '',
        'createdAt' => '',
        'createdBy' => '',
    ];
}

function normalize_customer_balance_event(array $event): array
{
    $event = array_merge(customer_balance_event_defaults(), $event);
    $type = trim((string) $event['type']);
    if (!in_array($type, ['credit', 'apply', 'refund', 'source_void', 'restore'], true)) {
        throw new RuntimeException('Журнал баланса клиента содержит неизвестный тип операции.', 409);
    }

    $amount = normalize_rate_price($event['amount'] ?? null);
    if ($amount === null || $amount <= 0) {
        throw new RuntimeException('Журнал баланса клиента содержит некорректную сумму.', 409);
    }

    $normalized = customer_balance_event_defaults();
    foreach ($normalized as $field => $_) {
        $normalized[$field] = $field === 'amount'
            ? $amount
            : trim((string) ($event[$field] ?? ''));
    }
    $normalized['type'] = $type;

    if ($normalized['id'] === '' || $normalized['customerId'] === '' || $normalized['scopeId'] === '') {
        throw new RuntimeException('Журнал баланса клиента содержит операцию без обязательной связи.', 409);
    }
    if ($type === 'credit' && ($normalized['sourcePaymentId'] === '' || $normalized['ledgerEntryId'] === '')) {
        throw new RuntimeException('Зачисление баланса не связано с исходным поступлением.', 409);
    }
    if ($type === 'credit' && $normalized['sourceRentalId'] === '' && $normalized['sourceKind'] !== 'manual_topup') {
        throw new RuntimeException('Переплата на балансе не связана с исходной арендой.', 409);
    }
    if (in_array($type, ['apply', 'refund', 'source_void'], true) && $normalized['sourceCreditId'] === '') {
        throw new RuntimeException('Списание баланса не связано с источником.', 409);
    }
    if ($type === 'restore' && ($normalized['sourceCreditId'] === '' || $normalized['relatedEventId'] === '')) {
        throw new RuntimeException('Восстановление баланса не связано с исходным списанием.', 409);
    }

    return $normalized;
}

function customer_balance_validate_store(array $store): array
{
    if ((int) ($store['schema'] ?? 0) !== 1 || !isset($store['events']) || !is_array($store['events'])) {
        throw new RuntimeException('Хранилище баланса клиентов имеет неподдерживаемую структуру.', 409);
    }

    $events = [];
    $ids = [];
    $credits = [];
    $debits = [];
    $available = [];
    $sourcePayments = [];
    foreach ($store['events'] as $rawEvent) {
        if (!is_array($rawEvent)) {
            throw new RuntimeException('Хранилище баланса клиентов содержит повреждённую операцию.', 409);
        }
        $event = normalize_customer_balance_event($rawEvent);
        if (isset($ids[$event['id']])) {
            throw new RuntimeException('Хранилище баланса клиентов содержит повторяющийся ID.', 409);
        }
        $ids[$event['id']] = true;

        if ($event['type'] === 'credit') {
            if (isset($sourcePayments[$event['sourcePaymentId']])) {
                throw new RuntimeException('Одно поступление повторно зачислено на баланс клиента.', 409);
            }
            $sourcePayments[$event['sourcePaymentId']] = true;
            $credits[$event['id']] = $event;
            $available[$event['id']] = $event['amount'];
        } elseif (in_array($event['type'], ['apply', 'refund', 'source_void'], true)) {
            $credit = $credits[$event['sourceCreditId']] ?? null;
            if (!$credit
                || $credit['customerId'] !== $event['customerId']
                || $credit['scopeId'] !== $event['scopeId']
                || $event['amount'] > ($available[$event['sourceCreditId']] ?? 0)) {
                throw new RuntimeException('Списание превышает доступный клиентский остаток или нарушает его принадлежность.', 409);
            }
            $available[$event['sourceCreditId']] -= $event['amount'];
            $debits[$event['id']] = $event + ['restored' => 0];
        } else {
            $credit = $credits[$event['sourceCreditId']] ?? null;
            $debit = $debits[$event['relatedEventId']] ?? null;
            if (!$credit || !$debit || $debit['sourceCreditId'] !== $event['sourceCreditId']
                || $event['customerId'] !== $credit['customerId'] || $event['scopeId'] !== $credit['scopeId']
                || $event['amount'] > $debit['amount'] - $debit['restored']) {
                throw new RuntimeException('Восстановление клиентского остатка превышает исходное списание.', 409);
            }
            $debits[$event['relatedEventId']]['restored'] += $event['amount'];
            $available[$event['sourceCreditId']] += $event['amount'];
        }
        $events[] = $event;
    }

    return ['schema' => 1, 'events' => $events];
}

function read_customer_balances(bool $strict = false): array
{
    if (!is_file(CUSTOMER_BALANCES_FILE)) {
        return default_customer_balances();
    }
    try {
        return customer_balance_validate_store(read_json_file(CUSTOMER_BALANCES_FILE, default_customer_balances()));
    } catch (Throwable $exception) {
        if ($strict) {
            throw $exception;
        }
        throw new RuntimeException('Баланс клиентов временно недоступен: требуется проверка журнала.', 409, $exception);
    }
}

function write_customer_balances(array $store): void
{
    write_json_file(CUSTOMER_BALANCES_FILE, customer_balance_validate_store($store));
}

function customer_balance_event_id(string $prefix): string
{
    return 'cb_' . $prefix . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(5));
}

function customer_balance_credit_availability(array $store): array
{
    $store = customer_balance_validate_store($store);
    $credits = [];
    $available = [];
    $debits = [];
    foreach ($store['events'] as $event) {
        if ($event['type'] === 'credit') {
            $credits[$event['id']] = $event;
            $available[$event['id']] = $event['amount'];
        } elseif (in_array($event['type'], ['apply', 'refund', 'source_void'], true)) {
            $available[$event['sourceCreditId']] -= $event['amount'];
            $debits[$event['id']] = $event;
        } elseif ($event['type'] === 'restore') {
            $available[$event['sourceCreditId']] += $event['amount'];
        }
    }
    return ['credits' => $credits, 'available' => $available, 'debits' => $debits];
}

function customer_balance_summary(string $customerId, ?string $scopeId = null, ?array $store = null): array
{
    $customerId = trim($customerId);
    $scopeId = $scopeId === null ? null : trim($scopeId);
    $state = customer_balance_credit_availability($store ?? read_customer_balances(true));
    $total = 0;
    $byScope = [];
    $sources = [];
    foreach ($state['credits'] as $creditId => $credit) {
        if ($credit['customerId'] !== $customerId || ($scopeId !== null && $credit['scopeId'] !== $scopeId)) {
            continue;
        }
        $amount = max(0, (int) ($state['available'][$creditId] ?? 0));
        $total += $amount;
        $byScope[$credit['scopeId']] = ($byScope[$credit['scopeId']] ?? 0) + $amount;
        $sources[] = $credit + ['available' => $amount];
    }
    ksort($byScope);

    return [
        'customerId' => $customerId,
        'scopeId' => $scopeId,
        'available' => $total,
        'byScope' => $byScope,
        'sources' => $sources,
        'digest' => hash('sha256', json_encode([$customerId, $scopeId, $byScope, array_map(
            static fn(array $source): array => [$source['id'], $source['available']],
            $sources
        )], JSON_THROW_ON_ERROR)),
    ];
}

function customer_balance_history(string $customerId, ?string $scopeId = null): array
{
    $customerId = trim($customerId);
    if ($customerId === '') {
        return [];
    }

    $entries = [];
    foreach (read_payments(true)['entries'] as $entry) {
        $entries[(string) ($entry['id'] ?? '')] = $entry;
    }
    $labels = [
        'credit' => 'Зачисление',
        'apply' => 'Зачтено в аренду',
        'refund' => 'Выдано клиенту',
        'source_void' => 'Источник отменён',
        'restore' => 'Остаток восстановлен',
    ];
    $history = [];
    foreach (read_customer_balances(true)['events'] as $event) {
        if ((string) ($event['customerId'] ?? '') !== $customerId) {
            continue;
        }
        $eventScopeId = (string) ($event['scopeId'] ?? '');
        if ($scopeId !== null && $eventScopeId !== $scopeId) {
            continue;
        }
        $ledger = $entries[(string) ($event['ledgerEntryId'] ?? '')] ?? null;
        $type = (string) ($event['type'] ?? '');
        $isIncrease = in_array($type, ['credit', 'restore'], true);
        $history[] = [
            'id' => (string) ($event['id'] ?? ''),
            'type' => $type,
            'typeLabel' => (string) ($labels[$type] ?? $type),
            'amount' => (int) ($event['amount'] ?? 0),
            'signedAmount' => ($isIncrease ? 1 : -1) * (int) ($event['amount'] ?? 0),
            'status' => is_array($ledger) ? (string) ($ledger['status'] ?? 'posted') : 'journaled',
            'reason' => (string) (($event['reason'] ?? '') ?: (is_array($ledger) ? ($ledger['reason'] ?? '') : '')),
            'createdAt' => (string) ($event['createdAt'] ?? ''),
            'createdBy' => (string) ($event['createdBy'] ?? ''),
            'scopeId' => $eventScopeId,
            'sourceRentalId' => (string) ($event['sourceRentalId'] ?? ''),
            'targetRentalId' => (string) ($event['targetRentalId'] ?? ''),
            'sourcePaymentId' => (string) ($event['sourcePaymentId'] ?? ''),
            'ledgerEntryId' => (string) ($event['ledgerEntryId'] ?? ''),
            'relatedEventId' => (string) ($event['relatedEventId'] ?? ''),
        ];
    }
    usort($history, static fn(array $left, array $right): int => strcmp(
        (string) ($right['createdAt'] ?? ''),
        (string) ($left['createdAt'] ?? '')
    ));

    return $history;
}

function customer_balance_append_credit(array $store, array $payload): array
{
    $store = customer_balance_validate_store($store);
    $sourcePaymentId = trim((string) ($payload['sourcePaymentId'] ?? ''));
    foreach ($store['events'] as $event) {
        if ($event['type'] === 'credit' && $event['sourcePaymentId'] === $sourcePaymentId) {
            throw new RuntimeException('Это поступление уже распределено на баланс клиента.', 409);
        }
    }
    $store['events'][] = normalize_customer_balance_event([
        'id' => (string) ($payload['id'] ?? customer_balance_event_id('credit')),
        'type' => 'credit',
        'amount' => $payload['amount'] ?? 0,
        'customerId' => $payload['customerId'] ?? '',
        'scopeId' => $payload['scopeId'] ?? '',
        'sourceRentalId' => $payload['sourceRentalId'] ?? '',
        'sourcePaymentId' => $sourcePaymentId,
        'sourceKind' => $payload['sourceKind'] ?? 'rental_overpayment',
        'ledgerEntryId' => $payload['ledgerEntryId'] ?? '',
        'operationId' => $payload['operationId'] ?? '',
        'reason' => $payload['reason'] ?? '',
        'createdAt' => now_iso(),
        'createdBy' => current_admin_user() ?: 'system',
    ]);

    return customer_balance_validate_store($store);
}

function customer_balance_consume(array $store, array $payload): array
{
    $store = customer_balance_validate_store($store);
    $customerId = trim((string) ($payload['customerId'] ?? ''));
    $scopeId = trim((string) ($payload['scopeId'] ?? ''));
    $amount = normalize_rate_price($payload['amount'] ?? null);
    $type = trim((string) ($payload['type'] ?? ''));
    if ($customerId === '' || $scopeId === '' || $amount === null || $amount <= 0 || !in_array($type, ['apply', 'refund', 'source_void'], true)) {
        throw new InvalidArgumentException('Некорректная операция с балансом клиента.', 422);
    }

    $summary = customer_balance_summary($customerId, $scopeId, $store);
    if ($amount > $summary['available']) {
        throw new InvalidArgumentException('Сумма превышает доступный баланс клиента.', 422);
    }

    $remaining = $amount;
    $created = [];
    foreach ($summary['sources'] as $source) {
        if ($remaining <= 0 || $source['available'] <= 0) {
            continue;
        }
        if ($type === 'source_void' && $source['id'] !== (string) ($payload['sourceCreditId'] ?? '')) {
            continue;
        }
        $part = min($remaining, (int) $source['available']);
        $event = normalize_customer_balance_event([
            'id' => customer_balance_event_id($type),
            'type' => $type,
            'amount' => $part,
            'customerId' => $customerId,
            'scopeId' => $scopeId,
            'sourceRentalId' => $source['sourceRentalId'],
            'sourcePaymentId' => $source['sourcePaymentId'],
            'sourceCreditId' => $source['id'],
            'targetRentalId' => $payload['targetRentalId'] ?? '',
            'targetObligationId' => $payload['targetObligationId'] ?? '',
            'ledgerEntryId' => $payload['ledgerEntryId'] ?? '',
            'operationId' => $payload['operationId'] ?? '',
            'reason' => $payload['reason'] ?? '',
            'createdAt' => now_iso(),
            'createdBy' => current_admin_user() ?: 'system',
        ]);
        $store['events'][] = $event;
        $created[] = $event;
        $remaining -= $part;
    }
    if ($remaining !== 0) {
        throw new RuntimeException('Не удалось однозначно распределить клиентский остаток по источникам.', 409);
    }

    return ['store' => customer_balance_validate_store($store), 'events' => $created];
}

function customer_balance_reverse_unused_source(array $store, string $sourcePaymentId, string $operationId, string $reason): array
{
    $store = customer_balance_validate_store($store);
    $state = customer_balance_credit_availability($store);
    $credit = null;
    foreach ($state['credits'] as $candidate) {
        if ($candidate['sourcePaymentId'] === $sourcePaymentId) {
            $credit = $candidate;
            break;
        }
    }
    if (!$credit) {
        return ['store' => $store, 'events' => []];
    }
    if ((int) ($state['available'][$credit['id']] ?? 0) !== (int) $credit['amount']) {
        throw new RuntimeException('Исходное поступление нельзя отменить: часть клиентского остатка уже зачтена или возвращена.', 409);
    }

    return customer_balance_consume($store, [
        'type' => 'source_void',
        'amount' => $credit['amount'],
        'customerId' => $credit['customerId'],
        'scopeId' => $credit['scopeId'],
        'sourceCreditId' => $credit['id'],
        'targetRentalId' => $credit['sourceRentalId'],
        'operationId' => $operationId,
        'reason' => $reason,
    ]);
}

function customer_balance_operation_id($value): string
{
    $value = trim((string) $value);
    if ($value !== '' && preg_match('/^cbop_[a-zA-Z0-9_-]{16,96}$/', $value)) {
        return $value;
    }

    return 'cbop_' . bin2hex(random_bytes(16));
}

function customer_balance_effective_scope_id(string $requestedScopeId = ''): string
{
    $requestedScopeId = trim($requestedScopeId);
    if (current_user_is_scoped_data_user()) {
        $currentScopeId = current_user_data_scope_id();
        if ($currentScopeId === '' || ($requestedScopeId !== '' && $requestedScopeId !== $currentScopeId)) {
            throw new RuntimeException('Баланс клиента недоступен вне вашего контура.', 403);
        }
        return $currentScopeId;
    }
    if (current_admin_role() !== 'admin' && $requestedScopeId !== '' && $requestedScopeId !== 'rent_rk') {
        throw new RuntimeException('Баланс клиента недоступен вне основного контура.', 403);
    }

    return $requestedScopeId !== '' ? $requestedScopeId : 'rent_rk';
}

function customer_balance_find_ledger_operation(array $payments, string $operationId): ?array
{
    foreach ($payments['entries'] ?? [] as $entry) {
        if (is_array($entry) && (string) ($entry['meta']['customerBalanceOperationId'] ?? '') === $operationId) {
            return $entry;
        }
    }
    return null;
}

function customer_balance_cash_operation_fingerprint(array $payload): string
{
    $canonical = [
        'type' => (string) ($payload['type'] ?? ''),
        'customerId' => (string) ($payload['customerId'] ?? ''),
        'scopeId' => (string) ($payload['scopeId'] ?? ''),
        'amount' => (int) ($payload['amount'] ?? 0),
        'method' => (string) ($payload['method'] ?? ''),
        'reason' => (string) ($payload['reason'] ?? ''),
    ];

    return hash('sha256', json_encode($canonical, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function customer_balance_assert_customer_scope(string $customerId, string $scopeId): void
{
    $customer = require_customer_access($customerId);
    if (customer_owner_scope_id($customer) !== $scopeId) {
        throw new RuntimeException('Финансовые операции клиента доступны только в контуре его карточки.', 403);
    }
    if (current_user_is_scoped_data_user()) {
        $currentScopeId = current_user_data_scope_id();
        if ($currentScopeId === '' || $scopeId !== $currentScopeId || customer_owner_scope_id($customer) !== $currentScopeId) {
            throw new RuntimeException('Клиент недоступен в вашем контуре.', 403);
        }
    }
}

function customer_balance_cash_operation(array $payload): array
{
    if (!RentalReturnStore::active()) {
        return RentalReturnStore::transaction(static fn(): array => customer_balance_cash_operation($payload));
    }

    if (!has_permission('finance.manage')) {
        throw new RuntimeException('Нет права управлять финансами.', 403);
    }

    $type = trim((string) ($payload['type'] ?? ''));
    if (!in_array($type, ['topup', 'refund'], true)) {
        throw new InvalidArgumentException('Неизвестная операция с балансом клиента.', 422);
    }
    $customerId = trim((string) ($payload['customerId'] ?? ''));
    if ($customerId === '' || !find_customer($customerId)) {
        throw new InvalidArgumentException('Клиент не найден.', 422);
    }
    $scopeId = customer_balance_effective_scope_id((string) ($payload['scopeId'] ?? ''));
    customer_balance_assert_customer_scope($customerId, $scopeId);
    $amount = rental_return_money($payload['amount'] ?? null);
    $reason = finance_audit_comment((string) ($payload['reason'] ?? ''), 180);
    if ($amount === null || $amount <= 0) {
        throw new InvalidArgumentException('Укажите сумму целыми рублями больше нуля.', 422);
    }
    if ($reason === '') {
        throw new InvalidArgumentException('Укажите основание кассовой операции.', 422);
    }
    $method = (string) ($payload['method'] ?? 'unknown');
    if (!array_key_exists($method, payment_ledger_allowed_methods())) {
        throw new InvalidArgumentException('Выберите способ оплаты.', 422);
    }
    $operationId = customer_balance_operation_id($payload['operationId'] ?? '');
    $fingerprint = customer_balance_cash_operation_fingerprint([
        'type' => $type,
        'customerId' => $customerId,
        'scopeId' => $scopeId,
        'amount' => $amount,
        'method' => $method,
        'reason' => $reason,
    ]);
    $payments = read_payments(true);
    $existing = customer_balance_find_ledger_operation($payments, $operationId);
    if ($existing) {
        $existingFingerprint = (string) ($existing['meta']['customerBalanceOperationFingerprint'] ?? '');
        if ($existingFingerprint === '' || !hash_equals($existingFingerprint, $fingerprint)) {
            throw new RuntimeException('Повторная кассовая операция содержит изменённые данные.', 409);
        }
        return ['replayed' => true, 'entry' => $existing, 'summary' => customer_balance_summary($customerId, $scopeId)];
    }

    $entry = payment_ledger_create_entry([
        'rentalId' => '',
        'type' => $type === 'topup' ? 'customer_balance_topup' : 'customer_balance_refund',
        'amount' => $amount,
        'method' => $method,
        'reason' => $reason,
        'comment' => 'Операция из карточки клиента.',
        'source' => 'customer_card_balance',
        'relatedField' => 'customerBalance',
        'meta' => [
            'customerId' => $customerId,
            'scopeId' => $scopeId,
            'customerBalanceOperationId' => $operationId,
            'customerBalanceOperationFingerprint' => $fingerprint,
        ],
    ]);
    $balances = read_customer_balances(true);
    if ($type === 'topup') {
        $creditId = customer_balance_event_id('credit');
        $entry['meta']['customerBalanceCreditId'] = $creditId;
        $balances = customer_balance_append_credit($balances, [
            'id' => $creditId,
            'amount' => $amount,
            'customerId' => $customerId,
            'scopeId' => $scopeId,
            'sourceRentalId' => '',
            'sourcePaymentId' => (string) $entry['id'],
            'sourceKind' => 'manual_topup',
            'ledgerEntryId' => (string) $entry['id'],
            'operationId' => $operationId,
            'reason' => $reason,
        ]);
    } else {
        $consumed = customer_balance_consume($balances, [
            'type' => 'refund',
            'amount' => $amount,
            'customerId' => $customerId,
            'scopeId' => $scopeId,
            'ledgerEntryId' => (string) $entry['id'],
            'operationId' => $operationId,
            'reason' => $reason,
        ]);
        $balances = $consumed['store'];
        $entry['meta']['customerBalanceEventIds'] = array_values(array_map(
            static fn(array $event): string => (string) $event['id'],
            $consumed['events']
        ));
    }

    $payments = payment_ledger_append_entry($payments, $entry);
    write_payments($payments);
    write_customer_balances($balances);
    audit_log(
        $type === 'topup' ? 'customer.balance.topup' : 'customer.balance.refund',
        'customer',
        $customerId,
        $type === 'topup' ? 'Внесены деньги на баланс клиента.' : 'Выданы деньги с баланса клиента.',
        ['amount' => $amount, 'scopeId' => $scopeId, 'ledgerEntryId' => (string) $entry['id'], 'operationId' => $operationId]
    );

    return ['replayed' => false, 'entry' => $entry, 'summary' => customer_balance_summary($customerId, $scopeId, $balances)];
}
