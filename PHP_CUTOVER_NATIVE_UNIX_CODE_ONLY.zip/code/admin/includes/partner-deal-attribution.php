<?php

declare(strict_types=1);

const PARTNER_DEAL_ATTRIBUTION_SCHEMA = 1;
const PARTNER_DEAL_POLICY_VERSION = 1;

function partner_deal_attribution_states(): array
{
    return ['none', 'confirmed', 'removed'];
}

function partner_deal_attribution_methods(): array
{
    return ['none', 'partner_request', 'manual', 'legacy_policy'];
}

function partner_deal_public_context_key(string $partnerSlug, string $agentSlug = ''): string
{
    return hash('sha256', trim($partnerSlug) . '|' . trim($agentSlug));
}

function partner_deal_public_context_prune(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return;
    }
    $contexts = isset($_SESSION['partner_deal_public_contexts']) && is_array($_SESSION['partner_deal_public_contexts'])
        ? $_SESSION['partner_deal_public_contexts']
        : [];
    $minimumIssuedAt = time() - 21600;
    foreach ($contexts as $key => $context) {
        if (!is_array($context) || (int) ($context['issuedAt'] ?? 0) < $minimumIssuedAt) {
            unset($contexts[$key]);
        }
    }
    if (count($contexts) > 12) {
        uasort($contexts, static fn(array $left, array $right): int => (int) ($left['issuedAt'] ?? 0) <=> (int) ($right['issuedAt'] ?? 0));
        $contexts = array_slice($contexts, -12, null, true);
    }
    $_SESSION['partner_deal_public_contexts'] = $contexts;
}

function partner_deal_register_public_context(string $partnerSlug, string $agentSlug = ''): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        throw new RuntimeException('Не удалось открыть защищённый контекст партнёрской ссылки.', 503);
    }
    partner_deal_public_context_prune();
    $_SESSION['partner_deal_public_contexts'][partner_deal_public_context_key($partnerSlug, $agentSlug)] = [
        'partnerSlug' => trim($partnerSlug),
        'agentSlug' => trim($agentSlug),
        'issuedAt' => time(),
    ];
}

function partner_deal_public_context_is_valid(string $partnerSlug, string $agentSlug = ''): bool
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return false;
    }
    partner_deal_public_context_prune();
    $context = $_SESSION['partner_deal_public_contexts'][partner_deal_public_context_key($partnerSlug, $agentSlug)] ?? null;

    return is_array($context)
        && hash_equals((string) ($context['partnerSlug'] ?? ''), trim($partnerSlug))
        && hash_equals((string) ($context['agentSlug'] ?? ''), trim($agentSlug));
}

function partner_deal_iso_time($value): string
{
    $value = trim((string) $value);
    if ($value === '') {
        return '';
    }

    try {
        return (new DateTimeImmutable($value))
            ->setTimezone(new DateTimeZone(defined('APP_TIMEZONE') ? APP_TIMEZONE : date_default_timezone_get()))
            ->format(DateTimeInterface::ATOM);
    } catch (Throwable) {
        return '';
    }
}

function partner_deal_started_at(array $item, bool $fallbackToNow = false): string
{
    $attribution = isset($item['partnerAttribution']) && is_array($item['partnerAttribution'])
        ? $item['partnerAttribution']
        : [];
    foreach (['dealStartedAt', 'createdAt', 'bookingCreatedAt', 'created_at'] as $field) {
        $value = $field === 'dealStartedAt'
            ? ($attribution[$field] ?? '')
            : ($item[$field] ?? '');
        $normalized = partner_deal_iso_time($value);
        if ($normalized !== '') {
            return $normalized;
        }
    }

    // A future service date and the conversion time are not evidence of when a deal began.
    // New writers persist createdAt before policy evaluation; unknown history remains unknown.
    return '';
}

function partner_deal_policy_context(array $item, ?array $settings = null): array
{
    $settings = $settings ?? read_settings();
    $partnerSettings = isset($settings['partners']) && is_array($settings['partners'])
        ? $settings['partners']
        : [];
    $configured = (string) ($partnerSettings['commissionPolicy'] ?? 'first_deal');
    $legacy = (string) ($partnerSettings['legacyCommissionPolicy'] ?? 'first_deal');
    if ($legacy === 'attributed_deal' || !isset(partner_commission_policies()[$legacy])) {
        $legacy = 'first_deal';
    }
    $activationAt = partner_deal_iso_time($partnerSettings['attributedDealActivationAt'] ?? '');
    $dealStartedAt = partner_deal_started_at($item);
    $effective = $configured;
    $reason = 'configured_policy';

    if ($configured === 'attributed_deal') {
        if ($activationAt === '' || $dealStartedAt === '') {
            $effective = $legacy;
            $reason = 'attributed_deal_not_activated';
        } else {
            $activation = new DateTimeImmutable($activationAt);
            $dealStart = new DateTimeImmutable($dealStartedAt);
            if ($dealStart < $activation) {
                $effective = $legacy;
                $reason = 'deal_started_before_activation';
            } else {
                $effective = 'attributed_deal';
                $reason = $dealStart == $activation
                    ? 'deal_started_at_activation'
                    : 'deal_started_after_activation';
            }
        }
    }

    return [
        'key' => $effective,
        'configuredKey' => $configured,
        'legacyKey' => $legacy,
        'version' => PARTNER_DEAL_POLICY_VERSION,
        'activationAt' => $activationAt,
        'dealStartedAt' => $dealStartedAt,
        'reason' => $reason,
        'commissionDays' => max(1, (int) ($partnerSettings['commissionDays'] ?? 30)),
    ];
}

function partner_deal_attribution_default(array $item = []): array
{
    $policy = partner_deal_policy_context($item);
    return [
        'schema' => PARTNER_DEAL_ATTRIBUTION_SCHEMA,
        'state' => 'none',
        'version' => 1,
        'method' => 'none',
        'partnerSlug' => '',
        'partnerName' => '',
        'partnerAgentSlug' => '',
        'partnerAgentName' => '',
        'partnerAgentLogin' => '',
        'sourceRequestId' => '',
        'sourceRequestCreatedAt' => '',
        'dealStartedAt' => $policy['dealStartedAt'],
        'confirmedAt' => '',
        'confirmedBy' => '',
        'reason' => '',
        'policyKey' => $policy['key'],
        'policyConfiguredKey' => $policy['configuredKey'],
        'policyVersion' => $policy['version'],
        'policyActivationAt' => $policy['activationAt'],
        'policyDecisionReason' => $policy['reason'],
        'eligible' => false,
        'eligibilityReason' => 'no_confirmed_partner_for_deal',
        'commissionSnapshotPresent' => false,
        'commissionType' => '',
        'commissionValue' => null,
        'partnerOwnerType' => '',
        'partnerOwnerScopeId' => '',
        'commissionPayer' => 'none',
        'commissionPayerScopeId' => '',
        'carOwnerScopeId' => trim((string) ($item['car_owner_scope_id'] ?? '')),
        'history' => [],
    ];
}

function partner_deal_attribution_normalize($raw, array $item = []): ?array
{
    if (!is_array($raw) || (int) ($raw['schema'] ?? 0) !== PARTNER_DEAL_ATTRIBUTION_SCHEMA) {
        return null;
    }

    $result = array_merge(partner_deal_attribution_default($item), $raw);
    $result['schema'] = PARTNER_DEAL_ATTRIBUTION_SCHEMA;
    $result['state'] = in_array((string) $result['state'], partner_deal_attribution_states(), true)
        ? (string) $result['state']
        : 'none';
    $result['version'] = max(1, (int) $result['version']);
    $result['method'] = in_array((string) $result['method'], partner_deal_attribution_methods(), true)
        ? (string) $result['method']
        : 'none';
    foreach ([
        'partnerSlug', 'partnerName', 'partnerAgentSlug', 'partnerAgentName', 'partnerAgentLogin',
        'sourceRequestId', 'confirmedBy', 'reason', 'policyKey', 'policyConfiguredKey',
        'policyActivationAt', 'policyDecisionReason', 'eligibilityReason', 'commissionType',
        'partnerOwnerType', 'partnerOwnerScopeId', 'commissionPayer', 'commissionPayerScopeId',
        'carOwnerScopeId',
    ] as $field) {
        $result[$field] = trim((string) ($result[$field] ?? ''));
    }
    foreach (['sourceRequestCreatedAt', 'dealStartedAt', 'confirmedAt'] as $field) {
        $result[$field] = partner_deal_iso_time($result[$field] ?? '');
    }
    $result['policyVersion'] = max(1, (int) ($result['policyVersion'] ?? PARTNER_DEAL_POLICY_VERSION));
    $result['eligible'] = !empty($result['eligible']);
    $result['commissionSnapshotPresent'] = !empty($result['commissionSnapshotPresent']);
    $result['commissionValue'] = $result['commissionSnapshotPresent']
        ? normalize_rate_price($result['commissionValue'] ?? null)
        : null;
    if (!in_array($result['commissionType'], ['percent', 'fixed', ''], true)) {
        $result['commissionType'] = '';
    }
    if (!in_array($result['policyKey'], array_keys(partner_commission_policies()), true)) {
        $result['policyKey'] = 'first_deal';
        $result['policyDecisionReason'] = 'invalid_policy_key_normalized';
    }
    $result['history'] = isset($raw['history']) && is_array($raw['history'])
        ? array_values(array_filter($raw['history'], 'is_array'))
        : [];

    if ($result['state'] !== 'confirmed') {
        $result['eligible'] = false;
        $result['commissionSnapshotPresent'] = false;
        $result['commissionType'] = '';
        $result['commissionValue'] = null;
        $result['commissionPayer'] = 'none';
        $result['commissionPayerScopeId'] = '';
    }

    return $result;
}

function partner_deal_attribution_flat_fields(array $item, array $attribution): array
{
    $confirmed = $attribution['state'] === 'confirmed';
    $eligible = $confirmed && !empty($attribution['eligible']);
    $currentStatus = (string) ($item['commissionStatus'] ?? '');
    $status = $eligible
        ? (isset(commission_statuses()[$currentStatus]) && $currentStatus !== 'not_applicable' ? $currentStatus : 'pending')
        : 'not_applicable';

    return [
        'sourceChannel' => $confirmed ? 'partner' : '',
        'request_source' => $confirmed
            ? ((string) $attribution['partnerOwnerType'] === 'lessor' ? 'lessor_partner' : 'rent_rk_partner')
            : ((string) ($item['request_source'] ?? '') ?: 'public_site'),
        'partnerSlug' => $confirmed ? (string) $attribution['partnerSlug'] : '',
        'partnerName' => $confirmed ? (string) $attribution['partnerName'] : '',
        'partner_id' => $confirmed ? (string) $attribution['partnerSlug'] : '',
        'partnerAgentSlug' => $confirmed ? (string) $attribution['partnerAgentSlug'] : '',
        'partnerAgentName' => $confirmed ? (string) $attribution['partnerAgentName'] : '',
        'partnerAgentLogin' => $confirmed ? (string) $attribution['partnerAgentLogin'] : '',
        'partner_owner_type' => $confirmed ? (string) $attribution['partnerOwnerType'] : '',
        'partner_owner_scope_id' => $confirmed ? (string) $attribution['partnerOwnerScopeId'] : '',
        'partner_commission_payer' => $eligible ? (string) $attribution['commissionPayer'] : 'none',
        'partner_commission_payer_scope_id' => $eligible ? (string) $attribution['commissionPayerScopeId'] : '',
        'partner_commission_amount' => $eligible ? ($item['partner_commission_amount'] ?? null) : null,
        'partner_commission_status' => $eligible ? ($status === 'paid' ? 'paid' : 'pending') : 'not_required',
        'commissionType' => $eligible ? (string) $attribution['commissionType'] : '',
        'commissionValue' => $eligible ? $attribution['commissionValue'] : null,
        'commissionStatus' => $status,
    ];
}

function partner_deal_apply_attribution(array $item, array $attribution): array
{
    $normalized = partner_deal_attribution_normalize($attribution, $item);
    if ($normalized === null) {
        throw new RuntimeException('Повреждены сведения об источнике партнёрской сделки.', 409);
    }

    return array_merge($item, partner_deal_attribution_flat_fields($item, $normalized), [
        'partnerAttribution' => $normalized,
    ]);
}

function partner_deal_legacy_eligibility(array $item, string $policy, array $policyContext): array
{
    $customerId = trim((string) ($item['customerId'] ?? ''));
    if ($policy === 'manual_only') {
        return [false, 'legacy_manual_confirmation_missing'];
    }
    if ($policy === 'first_deal') {
        $eligible = count(customer_partner_rentals($customerId, '', (string) ($item['id'] ?? ''))) === 0;
        return [$eligible, $eligible ? 'legacy_first_deal' : 'legacy_repeat_deal'];
    }
    if ($policy === 'within_days') {
        $customer = $customerId !== '' ? find_customer($customerId) : null;
        $originAt = $customer && (string) ($customer['createdAt'] ?? '') !== ''
            ? new DateTimeImmutable((string) $customer['createdAt'])
            : null;
        $rentalDate = parse_date_value((string) ($item['startDate'] ?? '')) ?? new DateTimeImmutable('today');
        $limit = $originAt ? $originAt->modify('+' . (int) $policyContext['commissionDays'] . ' days') : null;
        $eligible = $limit ? $rentalDate <= $limit : true;
        return [$eligible, $eligible ? 'legacy_within_days' : 'legacy_outside_days'];
    }

    return [false, 'unsupported_legacy_policy'];
}

function partner_deal_build_attribution(
    array $item,
    ?array $partner,
    ?array $car,
    string $method,
    string $confirmedBy,
    string $reason,
    ?array $policyContext = null,
    ?bool $eligible = null,
    string $eligibilityReason = ''
): array {
    $policyContext = $policyContext ?? partner_deal_policy_context($item);
    $attribution = partner_deal_attribution_default($item);
    $attribution['method'] = $method;
    $sourceRequestId = $item['sourceRequestId'] ?? '';
    if ($method === 'partner_request' && trim((string) $sourceRequestId) === '') {
        $sourceRequestId = $item['id'] ?? '';
    }
    $attribution['sourceRequestId'] = trim((string) $sourceRequestId);
    $attribution['sourceRequestCreatedAt'] = partner_deal_iso_time($item['createdAt'] ?? '');
    $attribution['dealStartedAt'] = $policyContext['dealStartedAt'];
    $attribution['confirmedAt'] = $partner ? now_iso() : '';
    $attribution['confirmedBy'] = $partner ? $confirmedBy : '';
    $attribution['reason'] = trim($reason);
    $attribution['policyKey'] = $policyContext['key'];
    $attribution['policyConfiguredKey'] = $policyContext['configuredKey'];
    $attribution['policyVersion'] = $policyContext['version'];
    $attribution['policyActivationAt'] = $policyContext['activationAt'];
    $attribution['policyDecisionReason'] = $policyContext['reason'];
    $attribution['carOwnerScopeId'] = $car ? car_owner_scope_id($car) : trim((string) ($item['car_owner_scope_id'] ?? ''));

    if (!$partner) {
        return $attribution;
    }

    $partner = normalize_partner_item($partner);
    $context = request_partner_context_fields($partner, $car);
    $agentSlug = trim((string) ($item['partnerAgentSlug'] ?? ''));
    $agent = $agentSlug !== '' ? find_partner_agent((string) $partner['slug'], $agentSlug) : null;
    if ($agentSlug !== '' && !$agent) {
        throw new RuntimeException('Представитель не относится к выбранному партнёрскому каналу.', 409);
    }
    if ($car && !partner_can_access_car($partner, $car)) {
        throw new RuntimeException('Партнёрский канал не имеет доступа к выбранному автомобилю.', 403);
    }

    if ($eligible === null) {
        if ($policyContext['key'] === 'attributed_deal') {
            $eligible = true;
            $eligibilityReason = $eligibilityReason ?: 'confirmed_partner_for_this_deal';
        } else {
            [$eligible, $eligibilityReason] = partner_deal_legacy_eligibility($item, $policyContext['key'], $policyContext);
        }
    }

    $attribution['state'] = 'confirmed';
    $attribution['partnerSlug'] = (string) $partner['slug'];
    $attribution['partnerName'] = (string) $partner['name'];
    $attribution['partnerAgentSlug'] = (string) ($agent['slug'] ?? '');
    $attribution['partnerAgentName'] = (string) ($agent['name'] ?? '');
    $attribution['partnerAgentLogin'] = (string) ($agent['login'] ?? '');
    $attribution['eligible'] = (bool) $eligible;
    $attribution['eligibilityReason'] = $eligibilityReason ?: 'confirmed_partner_for_this_deal';
    $commissionType = $eligible ? (string) $partner['commissionType'] : '';
    $commissionValue = $eligible ? normalize_rate_price($partner['commissionValue'] ?? null) : null;
    $commissionPayer = $eligible ? (string) ($context['partner_commission_payer'] ?? 'none') : 'none';
    $commissionPayerScopeId = $eligible ? (string) ($context['partner_commission_payer_scope_id'] ?? '') : '';
    if (
        $eligible
        && $policyContext['key'] === 'attributed_deal'
        && (
            !in_array($commissionType, ['percent', 'fixed'], true)
            || $commissionValue === null
            || !in_array($commissionPayer, ['rent_rk', 'lessor'], true)
            || $commissionPayerScopeId === ''
        )
    ) {
        throw new RuntimeException('Не удалось зафиксировать ставку или плательщика партнёрской комиссии.', 409);
    }
    $attribution['commissionSnapshotPresent'] = (bool) $eligible;
    $attribution['commissionType'] = $commissionType;
    $attribution['commissionValue'] = $commissionValue;
    $attribution['partnerOwnerType'] = (string) $partner['partner_owner_type'];
    $attribution['partnerOwnerScopeId'] = (string) $partner['partner_owner_scope_id'];
    $attribution['commissionPayer'] = $commissionPayer;
    $attribution['commissionPayerScopeId'] = $commissionPayerScopeId;

    return $attribution;
}

function partner_deal_capture_request_attribution(array $request, ?array $car): array
{
    $partnerSlug = trim((string) ($request['partnerSlug'] ?? ''));
    $isPartnerRequest = (string) ($request['sourceChannel'] ?? '') === 'partner' || $partnerSlug !== '';
    if (!$isPartnerRequest) {
        return partner_deal_apply_attribution(
            $request,
            partner_deal_build_attribution($request, null, $car, 'none', '', '')
        );
    }

    $partner = $partnerSlug !== '' ? find_partner_by_slug($partnerSlug) : null;
    if (!$partner || empty($partner['active'])) {
        throw new RuntimeException('Партнёрский источник заявки не подтверждён сервером.', 409);
    }
    if (!$car && (string) ($request['requestKind'] ?? 'specific') !== 'selection') {
        throw new RuntimeException('Для партнёрской заявки не найден автомобиль.', 409);
    }

    $attribution = partner_deal_build_attribution(
        $request,
        $partner,
        $car,
        'partner_request',
        'public_request_handler',
        'Заявка принята сервером из разрешённого партнёрского канала.'
    );
    return partner_deal_apply_attribution($request, $attribution);
}

function partner_deal_identity_name_key($value): string
{
    $value = trim(preg_replace('/\s+/u', ' ', (string) $value) ?? '');
    $value = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
    return preg_replace('/[^\p{L}\p{N}]+/u', '', $value) ?? '';
}

function partner_deal_assert_source_request_customer(array $request, array $rental): void
{
    $requestCustomerId = trim((string) ($request['customerId'] ?? ''));
    $rentalCustomerId = trim((string) ($rental['customerId'] ?? ''));
    if ($requestCustomerId !== '') {
        if ($rentalCustomerId === '' || !hash_equals($requestCustomerId, $rentalCustomerId)) {
            throw new RuntimeException('Исходная заявка относится к другому клиенту.', 409);
        }
        return;
    }

    $linkedCustomer = $rentalCustomerId !== '' ? find_customer($rentalCustomerId) : null;
    $requestPhone = normalize_phone_for_storage($request['phone'] ?? '');
    $rentalPhone = normalize_phone_for_storage(($linkedCustomer['phone'] ?? '') ?: ($rental['phone'] ?? ''));
    $requestName = partner_deal_identity_name_key($request['customerName'] ?? $request['clientName'] ?? '');
    $rentalName = partner_deal_identity_name_key(($linkedCustomer['fullName'] ?? '') ?: ($rental['clientName'] ?? ''));
    if (
        $requestPhone === '' || $rentalPhone === '' || !hash_equals($requestPhone, $rentalPhone)
        || $requestName === '' || $rentalName === '' || !hash_equals($requestName, $rentalName)
    ) {
        throw new RuntimeException('Историческая исходная заявка не совпадает с клиентским контекстом аренды.', 409);
    }
}

function partner_deal_assert_selected_car_allowed(array $attribution, array $rental): void
{
    if ((string) ($attribution['state'] ?? '') !== 'confirmed') {
        return;
    }
    $partnerSlug = trim((string) ($attribution['partnerSlug'] ?? ''));
    $partner = $partnerSlug !== '' ? find_partner_by_slug($partnerSlug) : null;
    $car = find_car((string) ($rental['carSlug'] ?? ''));
    if (!$partner || empty($partner['active'])) {
        throw new RuntimeException('Подтверждённый партнёрский канал отключён или не найден.', 409);
    }
    if (!$car || !partner_can_access_car($partner, $car)) {
        throw new RuntimeException('Партнёрский канал не имеет доступа к выбранному автомобилю.', 403);
    }
}

function partner_deal_copy_commission_snapshot(array $target, array $source, bool $eligible): array
{
    if (!$eligible) {
        $target['commissionSnapshotPresent'] = false;
        $target['commissionType'] = '';
        $target['commissionValue'] = null;
        $target['commissionPayer'] = 'none';
        $target['commissionPayerScopeId'] = '';
        return $target;
    }
    foreach ([
        'commissionSnapshotPresent', 'commissionType', 'commissionValue', 'partnerOwnerType',
        'partnerOwnerScopeId', 'commissionPayer', 'commissionPayerScopeId',
    ] as $field) {
        $target[$field] = $source[$field] ?? $target[$field];
    }
    return $target;
}

function partner_deal_request_attribution_for_rental(array $request, array $rental, array $requestAttribution): array
{
    $sourceRequestId = trim((string) ($request['id'] ?? ''));
    if (
        (string) ($requestAttribution['method'] ?? '') === 'partner_request'
        && !hash_equals($sourceRequestId, trim((string) ($requestAttribution['sourceRequestId'] ?? '')))
    ) {
        throw new RuntimeException('Исходная заявка содержит несогласованную ссылку на источник.', 409);
    }

    $dealItem = array_merge($rental, [
        'createdAt' => (string) ($request['createdAt'] ?? ''),
        'sourceRequestId' => $sourceRequestId,
    ]);
    $policy = partner_deal_policy_context($dealItem);
    $state = (string) ($requestAttribution['state'] ?? 'none');
    if ($state !== 'confirmed') {
        if ($policy['key'] !== 'attributed_deal') {
            return partner_deal_apply_legacy_policy($dealItem)['partnerAttribution'];
        }
        return partner_deal_build_attribution($dealItem, null, find_car((string) ($rental['carSlug'] ?? '')), 'none', '', '', $policy);
    }

    $partnerSlug = trim((string) ($requestAttribution['partnerSlug'] ?? ''));
    $partner = $partnerSlug !== '' ? find_partner_by_slug($partnerSlug) : null;
    if (!$partner || empty($partner['active'])) {
        throw new RuntimeException('Подтверждённый партнёрский канал исходной заявки отключён или не найден.', 409);
    }
    $dealItem['partnerAgentSlug'] = (string) ($requestAttribution['partnerAgentSlug'] ?? '');
    $eligible = true;
    $eligibilityReason = 'confirmed_partner_for_this_deal';
    if ($policy['key'] !== 'attributed_deal') {
        [$eligible, $eligibilityReason] = partner_deal_legacy_eligibility($dealItem, $policy['key'], $policy);
    }
    $attribution = partner_deal_build_attribution(
        $dealItem,
        $partner,
        find_car((string) ($rental['carSlug'] ?? '')),
        'partner_request',
        (string) (($requestAttribution['confirmedBy'] ?? '') ?: 'public_request_handler'),
        (string) (($requestAttribution['reason'] ?? '') ?: 'Источник перенесён из подтверждённой заявки.'),
        $policy,
        $eligible,
        $eligibilityReason
    );
    $attribution = partner_deal_copy_commission_snapshot($attribution, $requestAttribution, $eligible);
    $attribution['sourceRequestId'] = $sourceRequestId;
    $attribution['sourceRequestCreatedAt'] = partner_deal_iso_time($request['createdAt'] ?? '');
    $attribution['confirmedAt'] = (string) ($requestAttribution['confirmedAt'] ?? $attribution['confirmedAt']);
    return $attribution;
}

function partner_deal_manual_reason(string $reason): string
{
    $reason = trim(preg_replace('/\s+/u', ' ', $reason) ?? '');
    $length = function_exists('mb_strlen') ? mb_strlen($reason, 'UTF-8') : strlen($reason);
    if ($length < 24 || $length > 500) {
        throw new InvalidArgumentException('Основание должно содержать от 24 до 500 символов.');
    }
    preg_match_all('/[\p{L}]{2,}/u', $reason, $matches);
    $words = array_map(static fn(string $word): string => function_exists('mb_strtolower') ? mb_strtolower($word, 'UTF-8') : strtolower($word), $matches[0] ?? []);
    $letters = preg_replace('/[^\p{L}]+/u', '', $reason) ?? '';
    $letterCount = function_exists('mb_strlen') ? mb_strlen($letters, 'UTF-8') : strlen($letters);
    $distinctWords = array_values(array_unique($words));
    if (count($words) < 4 || count($distinctWords) < 3 || $letterCount < 16) {
        throw new InvalidArgumentException('Опишите фактическую причину минимум четырьмя осмысленными словами.');
    }
    if (preg_match('/(.)\1{7,}/u', $reason) === 1) {
        throw new InvalidArgumentException('Основание не должно состоять из повторяющихся символов.');
    }

    return $reason;
}

function partner_deal_financial_lock_reason(array $rental): string
{
    if (in_array((string) ($rental['commissionStatus'] ?? ''), ['earned', 'paid'], true)) {
        return 'Комиссия уже заработана или выплачена.';
    }
    if (isset($rental['returnCloseV2']['legacyOpening']) || array_key_exists('commissionLockedAmount', (array) ($rental['returnCloseV2'] ?? []))) {
        return 'Сумма комиссии уже зафиксирована формой возврата.';
    }
    if (trim((string) (($rental['commissionPayoutBatchId'] ?? '') ?: ($rental['partnerPayoutBatchId'] ?? ''))) !== '') {
        return 'Аренда уже связана с пакетом партнёрской выплаты.';
    }

    $rentalId = trim((string) ($rental['id'] ?? ''));
    if ($rentalId !== '' && function_exists('read_payments')) {
        foreach ((array) (read_payments(true)['entries'] ?? []) as $entry) {
            if (!is_array($entry) || (string) ($entry['rentalId'] ?? '') !== $rentalId || (string) ($entry['status'] ?? 'posted') === 'voided') {
                continue;
            }
            if (in_array((string) ($entry['type'] ?? ''), ['partner_commission_accrued', 'partner_commission_paid', 'partner_commission_correction'], true)) {
                return 'По комиссии уже существует финансовая запись.';
            }
        }
    }

    return '';
}

function partner_deal_manual_command(array $item): ?array
{
    $raw = $item['_partnerAttributionCommand'] ?? null;
    if (!is_array($raw)) {
        return null;
    }

    return [
        'partnerSlug' => trim((string) ($raw['partnerSlug'] ?? '')),
        'partnerAgentSlug' => trim((string) ($raw['partnerAgentSlug'] ?? '')),
        'partnerAgentProvided' => array_key_exists('partnerAgentSlug', $raw),
        'reason' => (string) ($raw['reason'] ?? ''),
        'expectedVersion' => max(0, (int) ($raw['expectedVersion'] ?? 0)),
    ];
}

function partner_deal_assert_manual_access(array $rental): void
{
    if (!has_permission('finance.manage')) {
        throw new RuntimeException('Ручное изменение партнёра сделки требует права управления финансами.', 403);
    }
    if (!rental_belongs_to_current_scope($rental)) {
        throw new RuntimeException('Нет доступа к контуру этой аренды.', 403);
    }
    $car = find_car((string) ($rental['carSlug'] ?? ''));
    if (!$car || !car_visible_to_current_scope($car)) {
        throw new RuntimeException('Нет доступа к автомобилю этой аренды.', 403);
    }
}

function partner_deal_apply_manual_command(
    array $rental,
    array $command,
    ?array $existingAttribution = null,
    ?array $authoritativeBefore = null
): array
{
    $authoritativeBefore = $authoritativeBefore ?? $rental;
    partner_deal_assert_manual_access($authoritativeBefore);
    partner_deal_assert_manual_access($rental);
    $lockReason = trim((string) ($authoritativeBefore['id'] ?? '')) !== ''
        ? partner_deal_financial_lock_reason($authoritativeBefore)
        : '';
    if ($lockReason !== '') {
        throw new RuntimeException($lockReason . ' Простое изменение источника запрещено; требуется отдельная финансовая корректировка.', 409);
    }

    $reason = partner_deal_manual_reason((string) $command['reason']);
    $existing = partner_deal_attribution_normalize($existingAttribution, $authoritativeBefore);
    $currentVersion = $existing ? (int) $existing['version'] : 0;
    if ((int) $command['expectedVersion'] !== $currentVersion) {
        throw new RuntimeException('Источник сделки уже изменён в другом окне. Обновите карточку и повторите проверку.', 409);
    }

    $partnerSlug = trim((string) $command['partnerSlug']);
    $car = find_car((string) ($rental['carSlug'] ?? ''));
    $partner = $partnerSlug !== '' ? find_partner_by_slug($partnerSlug) : null;
    if ($partnerSlug !== '' && (!$partner || empty($partner['active']))) {
        throw new RuntimeException('Выбранный партнёр отключён или не найден.', 409);
    }
    if ($partner && (!$car || !partner_can_access_car($partner, $car))) {
        throw new RuntimeException('Выбранный партнёр не может привлекать сделки по этому автомобилю.', 403);
    }

    $existingPartnerSlug = $existing && (string) ($existing['state'] ?? '') === 'confirmed'
        ? trim((string) ($existing['partnerSlug'] ?? ''))
        : trim((string) ($authoritativeBefore['partnerSlug'] ?? $authoritativeBefore['partner_id'] ?? ''));
    $existingAgentSlug = $existing && (string) ($existing['state'] ?? '') === 'confirmed'
        ? trim((string) ($existing['partnerAgentSlug'] ?? ''))
        : trim((string) ($authoritativeBefore['partnerAgentSlug'] ?? ''));
    $selectedAgentSlug = !empty($command['partnerAgentProvided'])
        ? trim((string) ($command['partnerAgentSlug'] ?? ''))
        : ($partnerSlug !== '' && $partnerSlug === $existingPartnerSlug ? $existingAgentSlug : '');
    if ($partnerSlug === '') {
        $selectedAgentSlug = '';
    }
    $buildItem = $rental;
    $buildItem['partnerAgentSlug'] = $selectedAgentSlug;

    $policyContext = $existing
        ? [
            'key' => (string) $existing['policyKey'],
            'configuredKey' => (string) $existing['policyConfiguredKey'],
            'legacyKey' => (string) (read_settings()['partners']['legacyCommissionPolicy'] ?? 'first_deal'),
            'version' => (int) $existing['policyVersion'],
            'activationAt' => (string) $existing['policyActivationAt'],
            'dealStartedAt' => (string) $existing['dealStartedAt'],
            'reason' => (string) $existing['policyDecisionReason'],
            'commissionDays' => (int) (read_settings()['partners']['commissionDays'] ?? 30),
        ]
        : partner_deal_policy_context($rental);
    $next = partner_deal_build_attribution(
        $buildItem,
        $partner,
        $car,
        'manual',
        current_admin_user() ?: 'system',
        $reason,
        $policyContext,
        $partner ? true : false,
        $partner ? 'manual_confirmation_by_authorized_finance_actor' : 'manual_attribution_removed'
    );
    $next['state'] = $partner ? 'confirmed' : 'removed';
    $next['version'] = $currentVersion + 1;
    $history = $existing ? (array) $existing['history'] : [];
    $history[] = [
        'version' => $next['version'],
        'action' => $partner ? ($existing && $existing['state'] === 'confirmed' ? 'changed' : 'confirmed') : 'removed',
        'fromPartnerSlug' => $existing && $existing['state'] === 'confirmed'
            ? (string) $existing['partnerSlug']
            : trim((string) ($rental['partnerSlug'] ?? $rental['partner_id'] ?? '')),
        'toPartnerSlug' => $partner ? (string) $partner['slug'] : '',
        'fromPartnerAgentSlug' => $existingAgentSlug,
        'fromPartnerAgentName' => $existing && $existing['state'] === 'confirmed' ? (string) ($existing['partnerAgentName'] ?? '') : '',
        'fromPartnerAgentLogin' => $existing && $existing['state'] === 'confirmed' ? (string) ($existing['partnerAgentLogin'] ?? '') : '',
        'toPartnerAgentSlug' => (string) ($next['partnerAgentSlug'] ?? ''),
        'toPartnerAgentName' => (string) ($next['partnerAgentName'] ?? ''),
        'toPartnerAgentLogin' => (string) ($next['partnerAgentLogin'] ?? ''),
        'reason' => $reason,
        'actor' => current_admin_user() ?: 'system',
        'at' => now_iso(),
    ];
    $next['history'] = $history;

    return partner_deal_apply_attribution($rental, $next);
}

function partner_deal_build_legacy_attribution(array $item, array $resolved, string $method = 'legacy_policy'): array
{
    $partnerSlug = trim((string) ($resolved['partnerSlug'] ?? ''));
    $partner = $partnerSlug !== '' ? find_partner_by_slug($partnerSlug) : null;
    $car = find_car((string) ($resolved['carSlug'] ?? ''));
    $policy = partner_deal_policy_context($item);
    $eligible = $partnerSlug !== '' && (string) ($resolved['commissionStatus'] ?? '') !== 'not_applicable';
    if (!$partner && $partnerSlug !== '') {
        $partner = normalize_partner_item([
            'slug' => $partnerSlug,
            'name' => (string) ($resolved['partnerName'] ?? $partnerSlug),
            'commissionType' => (string) ($resolved['commissionType'] ?? ''),
            'commissionValue' => $resolved['commissionValue'] ?? null,
            'partner_owner_type' => (string) ($resolved['partner_owner_type'] ?? 'rent_rk'),
            'partner_owner_scope_id' => (string) ($resolved['partner_owner_scope_id'] ?? 'rent_rk'),
            'active' => true,
        ]);
    }
    $attribution = partner_deal_build_attribution(
        $item,
        $partner,
        $car,
        $method,
        'legacy_compatibility',
        'Условия сохранены совместимым writer-путём прежней политики.',
        $policy,
        $eligible,
        $eligible ? 'legacy_policy_eligible' : 'legacy_policy_not_eligible'
    );
    if ($eligible) {
        $attribution['commissionSnapshotPresent'] = array_key_exists('commissionValue', $resolved);
        $attribution['commissionType'] = (string) ($resolved['commissionType'] ?? '');
        $attribution['commissionValue'] = normalize_rate_price($resolved['commissionValue'] ?? null);
        $attribution['commissionPayer'] = (string) ($resolved['partner_commission_payer'] ?? $attribution['commissionPayer']);
        $attribution['commissionPayerScopeId'] = (string) ($resolved['partner_commission_payer_scope_id'] ?? $attribution['commissionPayerScopeId']);
    }
    return $attribution;
}

function partner_deal_apply_legacy_policy(array $rental): array
{
    $policy = partner_deal_policy_context($rental);
    $partnerSlug = trim((string) ($rental['partnerSlug'] ?? ''));
    $customerId = trim((string) ($rental['customerId'] ?? ''));
    if ($partnerSlug === '' && $policy['key'] === 'within_days' && $customerId !== '') {
        $customer = find_customer($customerId);
        if ($customer && (string) ($customer['partnerSlug'] ?? '') !== '') {
            $partnerSlug = (string) $customer['partnerSlug'];
            $rental['partnerSlug'] = $partnerSlug;
            $rental['partnerName'] = (string) ($customer['partnerName'] ?? '');
        }
    }
    if ($partnerSlug === '') {
        return partner_deal_apply_attribution(
            $rental,
            partner_deal_build_attribution($rental, null, find_car((string) ($rental['carSlug'] ?? '')), 'legacy_policy', '', '', $policy)
        );
    }
    $partner = find_partner_by_slug($partnerSlug);
    if (!$partner || empty($partner['active'])) {
        return partner_deal_apply_attribution(
            $rental,
            partner_deal_build_attribution($rental, null, find_car((string) ($rental['carSlug'] ?? '')), 'legacy_policy', '', '', $policy)
        );
    }
    [$eligible, $reason] = partner_deal_legacy_eligibility($rental, $policy['key'], $policy);
    $attribution = partner_deal_build_attribution(
        $rental,
        $partner,
        find_car((string) ($rental['carSlug'] ?? '')),
        'legacy_policy',
        'legacy_policy_engine',
        'Решение принято совместимой версией прежней политики.',
        $policy,
        $eligible,
        $reason
    );
    return partner_deal_apply_attribution($rental, $attribution);
}

function partner_deal_prepare_new_rental(array $rental): array
{
    $command = partner_deal_manual_command($rental);
    unset($rental['_partnerAttributionCommand'], $rental['partnerAttribution']);
    $sourceRequestId = trim((string) ($rental['sourceRequestId'] ?? ''));
    if ($sourceRequestId !== '') {
        $request = find_request_item($sourceRequestId);
        if (!$request) {
            throw new RuntimeException('Исходная заявка не найдена.', 409);
        }
        if (!request_belongs_to_current_scope($request)) {
            throw new RuntimeException('Нет доступа к контуру исходной заявки.', 403);
        }
        partner_deal_assert_source_request_customer($request, $rental);
        $requestAttribution = partner_deal_attribution_normalize($request['partnerAttribution'] ?? null, $request);
        if ($requestAttribution === null) {
            $resolved = partner_deal_apply_legacy_policy(array_merge($rental, [
                'partnerSlug' => (string) ($request['partnerSlug'] ?? ''),
                'partnerName' => (string) ($request['partnerName'] ?? ''),
                'partnerAgentSlug' => (string) ($request['partnerAgentSlug'] ?? ''),
                'partnerAgentName' => (string) ($request['partnerAgentName'] ?? ''),
                'partnerAgentLogin' => (string) ($request['partnerAgentLogin'] ?? ''),
                'createdAt' => (string) ($request['createdAt'] ?? ''),
            ]));
            $requestAttribution = partner_deal_attribution_normalize($resolved['partnerAttribution'] ?? null, $resolved);
        }
        if ($requestAttribution === null) {
            throw new RuntimeException('Не удалось определить источник исходной заявки.', 409);
        }
        $requestAttribution = partner_deal_request_attribution_for_rental($request, $rental, $requestAttribution);
        partner_deal_assert_selected_car_allowed($requestAttribution, $rental);
        $rental = partner_deal_apply_attribution($rental, $requestAttribution);
        if ($command !== null) {
            $rental = partner_deal_apply_manual_command($rental, $command, $requestAttribution);
        }
        return $rental;
    }

    if ($command !== null) {
        return partner_deal_apply_manual_command($rental, $command, null, $rental);
    }

    $policy = partner_deal_policy_context($rental);
    if ($policy['key'] === 'attributed_deal') {
        return partner_deal_apply_attribution(
            $rental,
            partner_deal_build_attribution($rental, null, find_car((string) ($rental['carSlug'] ?? '')), 'none', '', '', $policy)
        );
    }

    return partner_deal_apply_legacy_policy($rental);
}

function partner_deal_prepare_existing_rental(array $before, array $changes, array $merged): array
{
    $command = partner_deal_manual_command($changes);
    unset($merged['_partnerAttributionCommand']);
    $existing = partner_deal_attribution_normalize($before['partnerAttribution'] ?? null, $before);
    $baseChanged = (int) ($before['rentalCost'] ?? 0) !== (int) ($merged['rentalCost'] ?? 0);
    $financialLockReason = $baseChanged ? partner_deal_financial_lock_reason($before) : '';
    if ($financialLockReason !== '') {
        throw new RuntimeException(
            'Стоимость аренды уже финансово зафиксирована. Используйте предусмотренную финансовую корректировку. ' . $financialLockReason,
            409
        );
    }
    if ($command !== null) {
        return partner_deal_apply_manual_command($merged, $command, $existing, $before);
    }

    if ($existing !== null) {
        $beforeCarSlug = normalize_car_slug((string) ($before['carSlug'] ?? ''));
        $nextCarSlug = normalize_car_slug((string) ($merged['carSlug'] ?? ''));
        if ($beforeCarSlug !== $nextCarSlug) {
            partner_deal_assert_selected_car_allowed($existing, $merged);
            $nextCar = find_car($nextCarSlug);
            $existing['carOwnerScopeId'] = $nextCar ? car_owner_scope_id($nextCar) : '';
        }
        return partner_deal_apply_attribution($merged, $existing);
    }

    foreach ([
        'sourceChannel', 'request_source', 'partnerSlug', 'partnerName', 'partner_id',
        'partnerAgentSlug', 'partnerAgentName', 'partnerAgentLogin', 'partner_owner_type',
        'partner_owner_scope_id', 'partner_commission_payer', 'partner_commission_payer_scope_id',
        'partner_commission_amount', 'partner_commission_status', 'commissionType',
        'commissionValue', 'commissionStatus', 'commissionPaidAt',
    ] as $field) {
        if (array_key_exists($field, $before)) {
            $merged[$field] = $before[$field];
        }
    }
    unset($merged['partnerAttribution']);
    return $merged;
}

function partner_deal_attribution_payout_error(array $rental): string
{
    $attribution = partner_deal_attribution_normalize($rental['partnerAttribution'] ?? null, $rental);
    if ($attribution === null || (string) $attribution['policyKey'] !== 'attributed_deal') {
        return '';
    }
    if ($attribution['state'] !== 'confirmed' || empty($attribution['eligible'])) {
        if (
            trim((string) ($attribution['partnerSlug'] ?? '')) === ''
            && trim((string) ($rental['partnerSlug'] ?? '')) === ''
            && in_array((string) ($rental['commissionStatus'] ?? 'not_applicable'), ['', 'not_applicable'], true)
        ) {
            return '';
        }
        return 'Новая политика не содержит подтверждённого партнёра этой сделки.';
    }
    if (trim((string) $attribution['partnerSlug']) === '' || empty($attribution['commissionSnapshotPresent'])) {
        return 'Не зафиксированы партнёр или условия комиссии этой сделки.';
    }
    if (!in_array((string) $attribution['commissionType'], ['percent', 'fixed'], true) || $attribution['commissionValue'] === null) {
        return 'Снимок ставки комиссии повреждён или неполон.';
    }
    if (!in_array((string) $attribution['commissionPayer'], ['rent_rk', 'lessor'], true) || trim((string) $attribution['commissionPayerScopeId']) === '') {
        return 'Не зафиксирован плательщик партнёрской комиссии.';
    }
    if ((string) ($rental['partnerSlug'] ?? '') !== (string) $attribution['partnerSlug']) {
        return 'Плоские поля аренды расходятся с подтверждённой атрибуцией.';
    }

    return '';
}
