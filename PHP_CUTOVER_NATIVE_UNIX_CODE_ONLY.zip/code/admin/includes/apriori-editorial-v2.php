<?php
declare(strict_types=1);

final class RentRkApprovedEditorialV2
{
    public const EDITION = 'editorial-20261108-v2';
    public const SOURCE_SHA256 = 'b4b0d98607b1b6db099c1792a9563afa5fb15921a7d39dafef0a520cfddd6bb5';
    public const PROJECTION_SHA256 = '334b3cbe1c999cf429c91776f91ea3a744b779fee0041022cd781852a427e3ac';

    public static function load(): array
    {
        $file = __DIR__ . '/apriori-editorial-v2-content.php';
        $raw = is_link($file) ? false : file_get_contents($file);
        if (!is_string($raw) || !preg_match("~\A<\?php\r?\ndeclare\(strict_types=1\);\r?\n\r?\nreturn <<<'EDITORIAL_JSON'\r?\n([^\r\n]+)\r?\nEDITORIAL_JSON;\r?\n?\z~D", $raw, $m)
            || !hash_equals(self::PROJECTION_SHA256, hash('sha256', $m[1]))) {
            throw new RuntimeException('BLOCKED_APPROVED_EDITORIAL_SOURCE_MISMATCH');
        }
        return json_decode($m[1], true, 512, JSON_THROW_ON_ERROR);
    }

    public static function assertProjection(array $editorial, array $site, array $routes): void
    {
        if (!hash_equals(self::PROJECTION_SHA256, hash('sha256', RentRkPublicRenderer::canonical($editorial)))) {
            throw new RuntimeException('BLOCKED_APPROVED_EDITORIAL_SOURCE_MISMATCH');
        }
        $contacts = $editorial['contacts'];
        if ($site['name'] !== $editorial['brand'] || $site['phone'] !== preg_replace('/[^+0-9]/', '', $contacts['phone'])
            || $site['telegram'] !== 'https://t.me/' . ltrim($contacts['telegram'], '@') || $site['address'] !== $contacts['address']) {
            throw new RuntimeException('BLOCKED_APPROVED_EDITORIAL_SITE_MISMATCH');
        }
        $expected = ['index.html', 'cars/index.html', ...array_map(static fn(string $p): string => ltrim($p, '/'), RentRkPublicStaticPlan::PAGES), 'routes/index.html'];
        foreach ($routes as $route) $expected[] = 'routes/' . $route['slug'] . '.html';
        $actual = array_column($editorial['items'], 'path');
        sort($expected, SORT_STRING); sort($actual, SORT_STRING);
        if ($actual !== $expected || count($actual) !== 30) throw new RuntimeException('BLOCKED_APPROVED_EDITORIAL_URL_SET_MISMATCH');
    }

    public static function item(array $snapshot, string $path): ?array
    {
        foreach ($snapshot['staticPublication']['editorial']['items'] ?? [] as $item) if ($item['path'] === $path) return $item;
        return null;
    }

    public static function markdown(string $markdown): string
    {
        $html = ''; $list = null; $paragraph = [];
        $e = 'rent_rk_public_escape';
        $flush = static function () use (&$html, &$paragraph, $e): void {
            if ($paragraph) { $html .= '<p>' . implode('<br>', array_map($e, $paragraph)) . '</p>'; $paragraph = []; }
        };
        foreach (explode("\n", $markdown) as $line) {
            if (preg_match('/\A(- |[1-9][0-9]*\. )(.+)\z/uD', $line, $m)) {
                $flush();
                $kind = $m[1] === '- ' ? 'ul' : 'ol';
                if ($kind !== $list) { if ($list !== null) $html .= "</$list>"; $html .= "<$kind>"; $list = $kind; }
                $html .= '<li>' . $e($m[2]) . '</li>';
                continue;
            }
            if ($list !== null) { $html .= "</$list>"; $list = null; }
            if (preg_match('/\A(#{1,3}) (.+)\z/uD', $line, $m)) {
                $flush(); $level = strlen($m[1]); $html .= "<h$level>" . $e($m[2]) . "</h$level>";
            } elseif ($line === '') $flush();
            else $paragraph[] = $line;
        }
        if ($list !== null) $html .= "</$list>";
        $flush();
        return $html;
    }

    public static function article(array $item, ?string $text = null): string
    {
        return '<article class="text-page" data-approved-editorial="' . rent_rk_public_escape($item['id']) . '">'
            . self::markdown($text ?? $item['text']) . '</article>';
    }

    public static function links(array $item, array $hrefs): string
    {
        $labels = $item['buttons'] === '' ? [] : explode("\n", $item['buttons']);
        if (count($labels) !== count($hrefs)) throw new RuntimeException('BLOCKED_APPROVED_EDITORIAL_BUTTON_MISMATCH');
        $html = '';
        foreach ($labels as $i => $label) $html .= '<a class="btn secondary" data-approved-editorial-button href="'
            . rent_rk_public_escape($hrefs[$i]) . '">' . rent_rk_public_escape($label) . '</a> ';
        return $html === '' ? '' : '<div class="hero-actions">' . $html . '</div>';
    }

    public static function faqSchema(string $markdown): string
    {
        preg_match_all('/^## ([^\n]+\?)\n+([^#]+?)(?=^## |\z)/mu', $markdown, $matches, PREG_SET_ORDER);
        if (!$matches) return '';
        $faq = array_map(static fn(array $m): array => ['@type' => 'Question', 'name' => $m[1],
            'acceptedAnswer' => ['@type' => 'Answer', 'text' => trim($m[2])]], $matches);
        return '<script type="application/ld+json">' . json_encode(['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $faq],
            JSON_HEX_TAG | JSON_HEX_AMP | JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE) . '</script>';
    }
}
