<?php
declare(strict_types=1);

final class BusinessDataIntegrityException extends RuntimeException {}

function business_data_install_error_handler(): void
{
    $previous = null;
    $previous = set_exception_handler(static function (Throwable $error) use (&$previous): void {
        if (!$error instanceof BusinessDataIntegrityException) {
            if ($previous !== null) { $previous($error); return; }
            throw $error;
        }
        http_response_code(503);
        if (!headers_sent()) {
            header('Content-Type: text/html; charset=UTF-8');
            header('Cache-Control: no-store');
        }
        echo '<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Данные требуют проверки</title><main><h1>Данные требуют проверки</h1><p>',
            htmlspecialchars($error->getMessage(), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
            '</p><p>Операция не выполнена. Сообщите администратору, на какой странице возникла ошибка. Не повторяйте сохранение до проверки источника.</p></main></html>';
    });
}

// Empty legacy defaults are supported; nonempty documents require their real envelope.
function business_data_assert_store_shape(string $path, array $data): void
{
    $key = null;
    if (in_array($path, [
        SCOPE_BALANCES_FILE,
        SCOPE_BILLING_LOG_FILE,
        FINES_FILE,
        SERVICE_HOLDS_FILE,
        SERVICE_LOG_FILE,
        AUDIT_LOG_FILE,
        DEMAND_KEYWORDS_FILE,
        DEMAND_RECOMMENDATIONS_FILE,
        LANDING_PAGE_DRAFTS_FILE,
        LANDING_PAGE_VERSIONS_FILE,
        SEO_PAGE_LIFECYCLE_FILE,
        DEMAND_CLUSTERS_FILE,
        SEO_LAUNCH_PLAN_FILE,
        DEMAND_CARD_OPTIMIZATION_HINTS_FILE,
        DEMAND_CONTENT_BRIEFS_FILE,
        ANALYTICS_EVENTS_FILE,
    ], true)) {
        $key = 'items';
    } elseif (in_array($path, [RATES_FILE, AVAILABILITY_FILE], true)) {
        $key = 'cars';
    }
    if ($path === CARS_FILE) {
        if (!array_is_list($data) || array_filter($data, static fn($row): bool => !is_array($row))) {
            throw new BusinessDataIntegrityException('Повреждена структура автопарка. Требуется проверка хранилища.', 503);
        }
    } elseif ($key !== null && $data !== []) {
        if (!array_key_exists($key, $data) || !is_array($data[$key]) || array_filter($data[$key], static fn($row): bool => !is_array($row))) {
            $labels = [SCOPE_BALANCES_FILE => 'Баланс контура', SCOPE_BILLING_LOG_FILE => 'Операции контура', FINES_FILE => 'Штрафы',
                SERVICE_HOLDS_FILE => 'Сервисные удержания', SERVICE_LOG_FILE => 'Обслуживание', AUDIT_LOG_FILE => 'Журнал действий',
                RATES_FILE => 'Тарифы', AVAILABILITY_FILE => 'Занятость автомобилей'];
            throw new BusinessDataIntegrityException(($labels[$path] ?? 'Источник данных') . ': повреждена структура записей. Расчёт и сохранение остановлены.', 503);
        }
    }
    if ($path === RATES_FILE && array_key_exists('settings', $data) && !is_array($data['settings'])) {
        throw new BusinessDataIntegrityException('Повреждена структура настроек тарифов. Требуется проверка хранилища.', 503);
    }
    if ($path === AVAILABILITY_FILE) {
        foreach ($data['cars'] ?? [] as $days) {
            foreach ($days as $date => $entry) {
                if (!is_array($entry) || !isset($entry['status']) || !is_string($entry['status'])
                    || !array_key_exists($entry['status'], availability_statuses_with_free())
                    || !is_string($date) || !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $date)
                    || !parse_date_value($date)) {
                    throw new BusinessDataIntegrityException('Повреждены данные занятости автомобиля. Свободные даты не подтверждены. Требуется проверка источника данных.', 503);
                }
            }
        }
    }
}

function rates_form_version(string $scopeId): string
{
    $cars = is_file(CARS_FILE) ? read_json_file(CARS_FILE, []) : read_cars();
    $rates = is_file(RATES_FILE) ? read_json_file(RATES_FILE, []) : read_rates();
    $selected = [];
    $prices = [];
    foreach ($cars as $car) {
        if ($scopeId !== '' && car_owner_scope_id($car) !== $scopeId) continue;
        $slug = (string) ($car['slug'] ?? '');
        $selected[$slug] = $car;
        $prices[$slug] = $rates['cars'][$slug] ?? null;
    }
    return hash('sha256', json_encode([$scopeId, $selected, $prices,
        current_user_is_platform_admin() ? ($rates['settings'] ?? []) : null], JSON_THROW_ON_ERROR));
}

function business_record_version(string $path, string $id, string $key = 'id'): string
{
    $data = read_json_file($path, []);
    $rows = $path === CARS_FILE ? $data : ($data['items'] ?? []);
    foreach ($rows as $row) {
        if ((string) ($row[$key] ?? '') === $id) return hash('sha256', json_encode($row, JSON_THROW_ON_ERROR));
    }
    return hash('sha256', 'missing:' . $id);
}

// Low-frequency configuration forms use a conservative snapshot of server-selected stores.
function business_form_version(array $paths): string
{
    $values = [];
    foreach ($paths as $path) $values[$path] = read_json_file($path, []);
    return hash('sha256', json_encode($values, JSON_THROW_ON_ERROR));
}

function business_assert_form_version(array $paths, mixed $expected): void
{
    if (!RentalReturnStore::active()) throw new LogicException('Form version must be checked in its write transaction.');
    if (!is_string($expected) || !hash_equals(business_form_version($paths), $expected)) {
        throw new RuntimeException('Данные изменены. Обновите страницу перед сохранением.', 409);
    }
}

function business_form_version_field(array $paths): string
{
    $posted = $_POST['expected_version'] ?? null;
    $version = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && is_string($posted) ? $posted : business_form_version($paths);
    return '<input type="hidden" name="expected_version" value="' . e($version) . '">';
}
