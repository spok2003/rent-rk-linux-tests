<?php

declare(strict_types=1);

function ai_text_allowed_fields(): array
{
    return [
        'shortScenario' => [
            'label' => 'Сценарий для карточки',
            'type' => 'text',
            'max' => 180,
            'hint' => '80-120 символов, один короткий сценарий выбора.',
        ],
        'cardDescription' => [
            'label' => 'Описание для карточки',
            'type' => 'text',
            'max' => 320,
            'hint' => '180-240 символов, без рекламного давления.',
        ],
        'detailDescription' => [
            'label' => 'Описание для детальной страницы',
            'type' => 'text',
            'max' => 1400,
            'hint' => 'Подробнее, но без воды и выдуманных фактов.',
        ],
        'bestFor' => [
            'label' => 'Кому подойдёт',
            'type' => 'list',
            'maxItems' => 8,
            'itemMax' => 80,
        ],
        'strongPoints' => [
            'label' => 'Что удобно',
            'type' => 'list',
            'maxItems' => 8,
            'itemMax' => 80,
        ],
        'cardBadgesCustom' => [
            'label' => 'Кастомные бейджи',
            'type' => 'list',
            'maxItems' => 3,
            'itemMax' => 40,
            'hint' => '2-3 коротких бейджа для карточки, без дубля стандартных характеристик.',
        ],
        'seoTitle' => [
            'label' => 'SEO title',
            'type' => 'text',
            'max' => 90,
        ],
        'seoDescription' => [
            'label' => 'SEO description',
            'type' => 'text',
            'max' => 180,
        ],
    ];
}

function ai_text_generation_targets(): array
{
    return ['all' => 'Сгенерировать всё'] + array_map(
        static fn(array $field): string => (string) $field['label'],
        ai_text_allowed_fields()
    );
}

function ai_text_tone_presets(): array
{
    return [
        'calm' => 'Спокойно и информативно',
        'soft_sales' => 'Продающе, но без давления',
        'family' => 'Для семьи',
        'crimea_travel' => 'Для путешествий по Крыму',
        'premium' => 'Для премиум-авто',
        'economy' => 'Для экономичного авто',
        'cabriolet' => 'Для кабриолета / фотосессий',
        'seo_human' => 'SEO + польза для человека',
    ];
}

function ai_text_field_is_list(string $field): bool
{
    $meta = ai_text_allowed_fields()[$field] ?? [];

    return (string) ($meta['type'] ?? 'text') === 'list';
}

function ai_text_requested_fields(array $options): array
{
    $target = (string) ($options['target'] ?? 'all');
    $allowed = array_keys(ai_text_allowed_fields());
    if ($target !== 'all' && in_array($target, $allowed, true)) {
        return [$target];
    }

    return $allowed;
}

function ai_text_redact_sensitive(string $text, bool $preserveWhitespace = false): string
{
    if (!$preserveWhitespace && function_exists('openai_ai_sanitize_error')) {
        $text = openai_ai_sanitize_error($text);
    }
    $text = preg_replace('/Bearer\s+[A-Za-z0-9._\-]+/i', 'Bearer ***', $text) ?? $text;
    $text = preg_replace('/(api[_-]?key|token|secret|password)\s*[:=]\s*[^\s,;]+/iu', '$1=***', $text) ?? $text;
    $text = preg_replace('/[A-Za-z0-9_\-]{40,}/', '***', $text) ?? $text;

    return $text;
}

function ai_text_clean_string($value, int $limit = 800): string
{
    $text = html_entity_decode(strip_tags((string) $value), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $text = str_replace(["\0", "\x0B"], ' ', $text);
    $text = preg_replace('/\s+/u', ' ', trim($text)) ?? '';
    $text = ai_text_redact_sensitive($text);
    if ($limit > 0 && mb_strlen($text) > $limit) {
        $text = mb_substr($text, 0, $limit);
    }

    return trim($text);
}

function ai_text_clean_list($value, int $limit = 8, int $itemLimit = 80): array
{
    $items = is_array($value) ? $value : preg_split('/\r\n|\r|\n|,/', (string) $value);
    $items = is_array($items) ? $items : [];
    $clean = [];
    foreach ($items as $item) {
        $text = ai_text_clean_string($item, $itemLimit);
        if ($text === '' || in_array($text, $clean, true)) {
            continue;
        }
        $clean[] = $text;
        if (count($clean) >= $limit) {
            break;
        }
    }

    return $clean;
}

function ai_text_sanitize_response(string $text, bool $preserveWhitespace = false): string
{
    $text = trim($text);
    $text = preg_replace('/^```(?:[a-z0-9_-]+)?\s*/iu', '', $text) ?? $text;
    $text = preg_replace('/\s*```$/u', '', $text) ?? $text;
    $text = str_replace(["\0", "\x0B"], ' ', $text);

    return trim(ai_text_redact_sensitive($text, $preserveWhitespace));
}

function ai_text_decode_json_response(string $text): ?array
{
    $text = preg_replace('/^\xEF\xBB\xBF/u', '', ai_text_sanitize_response($text)) ?? $text;
    $decoded = ai_text_decode_json_candidate($text);
    if (is_array($decoded)) {
        return $decoded;
    }

    foreach (ai_text_extract_json_candidates($text) as $candidate) {
        $decoded = ai_text_decode_json_candidate($candidate);
        if (is_array($decoded)) {
            return $decoded;
        }
    }

    return null;
}

function ai_text_decode_json_candidate(string $text, int $depth = 0): ?array
{
    $text = trim($text);
    if ($text === '') {
        return null;
    }

    $candidates = [$text];
    $withoutTrailingCommas = preg_replace('/,\s*(?=[}\]])/u', '', $text) ?? $text;
    if ($withoutTrailingCommas !== $text) {
        $candidates[] = $withoutTrailingCommas;
    }

    foreach (array_unique($candidates) as $candidate) {
        $decoded = json_decode($candidate, true);
        if (is_array($decoded)) {
            return $decoded;
        }
        if (is_string($decoded) && $depth < 2) {
            $nested = ai_text_decode_json_candidate(ai_text_sanitize_response($decoded), $depth + 1);
            if (is_array($nested)) {
                return $nested;
            }
        }
    }

    return null;
}

function ai_text_extract_json_candidates(string $text): array
{
    $candidates = [];
    $length = strlen($text);
    for ($start = 0; $start < $length; $start++) {
        $opening = $text[$start];
        if ($opening !== '{' && $opening !== '[') {
            continue;
        }

        $stack = [$opening === '{' ? '}' : ']'];
        $inString = false;
        $escaped = false;
        for ($index = $start + 1; $index < $length; $index++) {
            $char = $text[$index];
            if ($inString) {
                if ($escaped) {
                    $escaped = false;
                } elseif ($char === '\\') {
                    $escaped = true;
                } elseif ($char === '"') {
                    $inString = false;
                }
                continue;
            }

            if ($char === '"') {
                $inString = true;
                continue;
            }
            if ($char === '{') {
                $stack[] = '}';
                continue;
            }
            if ($char === '[') {
                $stack[] = ']';
                continue;
            }
            if ($char !== '}' && $char !== ']') {
                continue;
            }

            $expected = array_pop($stack);
            if ($char !== $expected) {
                break;
            }
            if ($stack === []) {
                $candidates[] = substr($text, $start, $index - $start + 1);
                break;
            }
        }
    }

    return array_values(array_unique($candidates));
}

function ai_text_car_display_price(array $car): ?int
{
    $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
    if ($slug !== '' && function_exists('rate_for_car')) {
        $rate = rate_for_car($slug, $car);
        foreach (['manual', 'base'] as $field) {
            $value = normalize_rate_price($rate[$field] ?? null);
            if ($value !== null) {
                return $value;
            }
        }
    }

    return normalize_rate_price($car['price'] ?? null);
}

function ai_text_safe_car_context(array $car): array
{
    $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
    $price = ai_text_car_display_price($car);
    $terms = isset($car['specialRentalTerms']) && is_array($car['specialRentalTerms']) ? $car['specialRentalTerms'] : [];
    $name = ai_text_clean_string($car['name'] ?? '', 120);
    $class = ai_text_clean_string($car['class'] ?? '', 80);
    $seats = isset($car['seats']) ? (int) $car['seats'] : null;
    $transmission = ai_text_clean_string($car['transmission'] ?? '', 80);
    $drive = ai_text_clean_string($car['drive'] ?? '', 80);
    $engine = ai_text_clean_string($car['engine'] ?? '', 140);
    $power = '';
    if ($engine !== '' && preg_match('/\b\d{2,4}\s*л\.?\s*с\.?/u', $engine, $powerMatch)) {
        $power = ai_text_clean_string($powerMatch[0] ?? '', 40);
    }
    $commonRentalTerms = [
        'minRental' => 'Минимальный срок — от 1 суток',
        'yaltaDelivery' => 'Подача по Ялте — бесплатно',
        'crimeaDelivery' => 'Подача по Крыму — по договорённости',
    ];
    $specialRentalTerms = [
        'enabled' => !empty($terms['enabled']),
        'minDays' => isset($terms['minDays']) && $terms['minDays'] !== '' ? (int) $terms['minDays'] : null,
        'deliveryText' => ai_text_clean_string($terms['deliveryText'] ?? '', 160),
        'note' => ai_text_clean_string($terms['note'] ?? '', 220),
    ];
    $currentText = [
        'shortScenario' => ai_text_clean_string($car['shortScenario'] ?? '', 180),
        'cardDescription' => ai_text_clean_string($car['cardDescription'] ?? '', 320),
        'detailDescription' => ai_text_clean_string($car['detailDescription'] ?? '', 1400),
        'bestFor' => ai_text_clean_list($car['bestFor'] ?? [], 8, 80),
        'strongPoints' => ai_text_clean_list($car['strongPoints'] ?? [], 8, 80),
        'cardBadgesCustom' => ai_text_clean_list($car['cardBadgesCustom'] ?? [], 3, 40),
        'seoTitle' => ai_text_clean_string($car['seoTitle'] ?? '', 90),
        'seoDescription' => ai_text_clean_string($car['seoDescription'] ?? '', 180),
    ];
    $features = array_values(array_unique(array_filter(array_merge(
        [
            $class,
            $seats !== null ? ($seats . ' мест') : '',
            $transmission,
            $drive,
            $engine,
            !empty($car['hourlyAvailable']) ? 'почасовая аренда доступна' : '',
        ],
        $currentText['cardBadgesCustom']
    ), static fn($value): bool => is_string($value) && $value !== '')));
    $termsText = array_values(array_filter(array_merge(
        array_values($commonRentalTerms),
        $specialRentalTerms['enabled'] ? [
            $specialRentalTerms['minDays'] !== null ? ('Минимальный срок — от ' . $specialRentalTerms['minDays'] . ' суток') : '',
            $specialRentalTerms['deliveryText'],
            $specialRentalTerms['note'],
        ] : []
    ), static fn($value): bool => is_string($value) && $value !== ''));

    return [
        'slug' => $slug,
        'name' => $name,
        'brandModel' => $name,
        'year' => isset($car['year']) && $car['year'] !== '' ? (int) $car['year'] : null,
        'class' => $class,
        'type' => $class,
        'seats' => $seats,
        'transmission' => $transmission,
        'drive' => $drive,
        'engine' => $engine,
        'power' => $power,
        'hourlyAvailable' => !empty($car['hourlyAvailable']),
        'priceFrom' => $price,
        'priceFromText' => $price !== null ? ('от ' . number_format($price, 0, '.', ' ') . ' ₽/сут') : 'цена уточняется',
        'features' => $features,
        'terms' => $termsText,
        'commonRentalTerms' => $commonRentalTerms,
        'specialRentalTerms' => $specialRentalTerms,
        'currentText' => $currentText,
        'currentTexts' => $currentText,
        'region' => [
            'city' => 'Ялта',
            'region' => 'Крым',
        ],
    ];
}

function ai_text_response_schema(): array
{
    $textField = ['type' => 'string'];
    $listField = ['type' => 'array', 'items' => ['type' => 'string']];

    return [
        'type' => 'object',
        'additionalProperties' => false,
        'required' => ['variants', 'warnings'],
        'properties' => [
            'variants' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'additionalProperties' => false,
                    'required' => ['label', 'fields'],
                    'properties' => [
                        'label' => ['type' => 'string'],
                        'fields' => [
                            'type' => 'object',
                            'additionalProperties' => false,
                            'required' => array_keys(ai_text_allowed_fields()),
                            'properties' => [
                                'shortScenario' => $textField,
                                'cardDescription' => $textField,
                                'detailDescription' => $textField,
                                'bestFor' => $listField,
                                'strongPoints' => $listField,
                                'cardBadgesCustom' => $listField,
                                'seoTitle' => $textField,
                                'seoDescription' => $textField,
                            ],
                        ],
                    ],
                ],
            ],
            'warnings' => $listField,
        ],
    ];
}

function ai_text_system_instructions(): string
{
    return implode("\n", [
        'Ты — редактор сайта проката автомобилей Rent RK в Ялте.',
        'Твоя задача — создать полезные для пользователя и аккуратные для SEO тексты для карточки автомобиля и детальной страницы.',
        'Пиши на русском языке.',
        '',
        'Главный принцип: текст должен помогать человеку выбрать автомобиль для реальной поездки по Ялте и Крыму, а не выглядеть как рекламный шаблон или SEO-простыня.',
        'Используй только факты из переданного safe context. Не выдумывай комплектацию, расход, багажник, состояние, страховку, доставку, детские кресла, ограничения, наличие, скидки, цену или условия, если этого нет во входных данных.',
        '',
        'Регион и контекст: Ялта, Крым, Южный берег Крыма, серпантины, парковки у пляжей и достопримечательностей, поездки к морю, маршруты по Крыму.',
        'Подачу по Ялте упоминай только если это есть в условиях. Подачу по Крыму упоминай только если это указано или разрешено условиями.',
        '',
        'Стиль: живой, спокойный, уверенный, без давления на пользователя, без канцелярита, без сухого перечисления характеристик, без набивки ключевыми словами.',
        'Не повторяй одну и ту же конструкцию в разных полях.',
        'Не используй клише и запрещённые формулы: идеальный выбор, лучшее решение, незабываемые впечатления, максимальный комфорт, автомобиль мечты, широкий выбор, самые выгодные условия.',
        'Не используй слова роскошный, премиальный, идеальный, если это не задано явно.',
        'Не пиши внедорожник для обычного кроссовера, не предлагай бездорожье, не обещай самую низкую цену, гарантию, медицинские, юридические или страховые условия.',
        'Не используй emoji, markdown, HTML и восклицательные знаки.',
        '',
        'SEO должен быть естественным. Используй ключевые смыслы: аренда авто, прокат автомобиля, Ялта, Крым, модель автомобиля. Не повторяй ключи несколько раз подряд.',
        'SEO title должен быть конкретным и отличаться от других машин. Не вставляй цену в title, потому что цена может меняться.',
        'SEO description должен объяснять, что это за автомобиль, где его можно арендовать и в каком сценарии он полезен. Не превращай description в список ключевых слов.',
        '',
        'Требования к полям внутри variants[].fields:',
        'shortScenario: 70-110 знаков, максимум 130; одна короткая фраза о поездке или человеке.',
        'cardDescription: 170-240 знаков, максимум 280; 1-2 предложения для карточки каталога, практическая польза без повтора всех характеристик.',
        'detailDescription: 700-1300 знаков, максимум 1400; кому подойдёт автомобиль, в каких поездках удобен, что важно для Крыма и Ялты, без рекламной воды.',
        'bestFor: 3-5 коротких пунктов, не больше 3 слов в пункте.',
        'strongPoints: 3-6 пунктов, только подтверждённые или логично вытекающие из данных удобства.',
        'cardBadgesCustom: 2-3 коротких бейджа для карточки, не дублируй полностью стандартные технические бейджи.',
        'seoTitle: 50-65 знаков, максимум 75; формула “Аренда [модель] в Ялте — [1 сильный смысл] | Rent RK”.',
        'seoDescription: 140-170 знаков, максимум 180; модель, аренда в Ялте/Крыму и главный сценарий, человеческим языком.',
        '',
        'Если поле не входит в requestedFields, верни для него пустую строку или пустой массив. Если данных не хватает, формулируй нейтрально и добавь предупреждение в warnings.',
        'Перед ответом проверь: все requestedFields заполнены, JSON валидный, лимиты соблюдены, характеристики не выдуманы, тексты не похожи друг на друга.',
        'Возвращай только JSON object по переданной схеме без markdown, пояснений и комментариев.',
    ]);
}

function ai_text_build_car_prompt(array $carData, array $options): string
{
    $targets = ai_text_generation_targets();
    $tones = ai_text_tone_presets();
    $target = (string) ($options['target'] ?? 'all');
    if (!isset($targets[$target])) {
        $target = 'all';
    }
    $tone = (string) ($options['tone'] ?? 'calm');
    if (!isset($tones[$tone])) {
        $tone = 'calm';
    }
    $variantCount = max(1, min(3, (int) ($options['variantCount'] ?? 1)));
    $requestedFields = ai_text_requested_fields(['target' => $target]);
    $fieldMeta = ai_text_allowed_fields();
    $fieldHints = [];
    foreach ($requestedFields as $field) {
        $fieldHints[$field] = [
            'label' => (string) ($fieldMeta[$field]['label'] ?? $field),
            'hint' => (string) ($fieldMeta[$field]['hint'] ?? ''),
        ];
    }

    $payload = [
        'task' => 'car_public_content_generation',
        'target' => $target,
        'targetLabel' => (string) $targets[$target],
        'requestedFields' => $requestedFields,
        'fieldHints' => $fieldHints,
        'variantCount' => $variantCount,
        'tone' => [
            'id' => $tone,
            'label' => (string) $tones[$tone],
        ],
        'directionPrompt' => ai_text_clean_string($options['userPrompt'] ?? '', 1000),
        'car' => ai_text_safe_car_context($carData),
        'rules' => [
            'Do not overwrite existing text; this is only a proposal for manual preview.',
            'Return empty string/array for fields outside requestedFields.',
            'Never include secrets, tokens, internal IDs, VIN, license plates, registration documents, owner commissions or customer data.',
            'Never add features that are absent from car data.',
            'Return exactly variants.length = variantCount where possible.',
        ],
        'responseShape' => [
            'variants' => [
                [
                    'label' => 'Вариант 1',
                    'fields' => [
                        'shortScenario' => '',
                        'cardDescription' => '',
                        'detailDescription' => '',
                        'bestFor' => [],
                        'strongPoints' => [],
                        'cardBadgesCustom' => [],
                        'seoTitle' => '',
                        'seoDescription' => '',
                    ],
                ],
            ],
            'warnings' => [],
        ],
    ];

    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

    return is_string($json) ? $json : '{}';
}

function ai_text_plain_response_field(array $options): ?string
{
    $target = (string) ($options['target'] ?? 'all');
    if ($target === 'all' || !array_key_exists($target, ai_text_allowed_fields())) {
        return null;
    }

    return $target;
}

function ai_text_plain_all_response(array $options): bool
{
    return (string) ($options['target'] ?? 'all') === 'all';
}

function ai_text_plain_system_instructions(string $field, int $variantCount): string
{
    $meta = ai_text_allowed_fields()[$field] ?? [];
    $base = ai_text_system_instructions();
    $base = str_replace(
        'Если поле не входит в requestedFields, верни для него пустую строку или пустой массив. Если данных не хватает, формулируй нейтрально и добавь предупреждение в warnings.',
        '',
        $base
    );
    $base = str_replace(
        'Перед ответом проверь: все requestedFields заполнены, JSON валидный, лимиты соблюдены, характеристики не выдуманы, тексты не похожи друг на друга.',
        'Перед ответом проверь: поле заполнено, лимиты соблюдены, характеристики не выдуманы, текст не похож на шаблон.',
        $base
    );
    $base = str_replace(
        'Возвращай только JSON object по переданной схеме без markdown, пояснений и комментариев.',
        '',
        $base
    );
    $jsonValueRule = ai_text_field_is_list($field)
        ? 'value должен быть массивом строк, каждый пункт без нумерации и markdown.'
        : 'value должен быть строкой с готовым текстом поля.';

    $rules = [
        'Текущий запрос генерирует одно поле: ' . (string) ($meta['label'] ?? $field) . '.',
        'Верни только простой JSON object без markdown, пояснений и code fences.',
        'Формат ответа: {"field":"' . $field . '","value":...}.',
        'field должен быть строго "' . $field . '". ' . $jsonValueRule,
    ];
    if ($variantCount > 1) {
        $rules[] = 'Если запрошено несколько вариантов, верни JSON object с ключом variants, где каждый элемент имеет field и value.';
    }

    return trim($base) . "\n\n" . implode("\n", $rules);
}

function ai_text_plain_all_system_instructions(int $variantCount): string
{
    $base = ai_text_system_instructions();
    $base = str_replace(
        'Если поле не входит в requestedFields, верни для него пустую строку или пустой массив. Если данных не хватает, формулируй нейтрально и добавь предупреждение в warnings.',
        'Если данных не хватает, формулируй нейтрально и не выдумывай факты.',
        $base
    );
    $base = str_replace(
        'Перед ответом проверь: все requestedFields заполнены, JSON валидный, лимиты соблюдены, характеристики не выдуманы, тексты не похожи друг на друга.',
        'Перед ответом проверь: все блоки заполнены, лимиты соблюдены, характеристики не выдуманы, тексты не похожи друг на друга.',
        $base
    );
    $base = str_replace(
        'Возвращай только JSON object по переданной схеме без markdown, пояснений и комментариев.',
        '',
        $base
    );

    $rules = [
        'Текущий запрос генерирует все поля для ручной проверки в админке.',
        'Верни только подписанные текстовые блоки без JSON, markdown, code fences, вступления и пояснений.',
        'Используй ровно такие заголовки и порядок:',
        'Сценарий для карточки:',
        'Описание для карточки:',
        'Описание для детальной страницы:',
        'Кому подойдёт:',
        'Что удобно:',
        'Кастомные бейджи:',
        'SEO title:',
        'SEO description:',
        'Для списков пиши каждый пункт с новой строки, без нумерации и маркеров.',
    ];
    if ($variantCount > 1) {
        $rules[] = 'Верни ровно ' . $variantCount . ' разных варианта.';
        $rules[] = 'Каждый вариант начни отдельным заголовком строго в таком виде: "Вариант 1:", "Вариант 2:", "Вариант 3:".';
        $rules[] = 'Внутри каждого варианта используй тот же порядок подписанных полей.';
    }

    return trim($base) . "\n\n" . implode("\n", $rules);
}

function ai_text_build_plain_field_prompt(array $carData, array $options, string $field): string
{
    $targets = ai_text_generation_targets();
    $tones = ai_text_tone_presets();
    $fieldMeta = ai_text_allowed_fields();
    $variantCount = max(1, min(3, (int) ($options['variantCount'] ?? 1)));
    $tone = (string) ($options['tone'] ?? 'calm');
    if (!isset($tones[$tone])) {
        $tone = 'calm';
    }

    $payload = [
        'task' => 'car_public_content_single_field_generation',
        'target' => $field,
        'targetLabel' => (string) ($targets[$field] ?? $field),
        'variantCount' => $variantCount,
        'fieldHint' => [
            'label' => (string) ($fieldMeta[$field]['label'] ?? $field),
            'hint' => (string) ($fieldMeta[$field]['hint'] ?? ''),
        ],
        'tone' => [
            'id' => $tone,
            'label' => (string) $tones[$tone],
        ],
        'directionPrompt' => ai_text_clean_string($options['userPrompt'] ?? '', 1000),
        'car' => ai_text_safe_car_context($carData),
        'rules' => [
            $variantCount > 1
                ? 'Return exactly ' . $variantCount . ' plain text variants with headers "Вариант 1:", "Вариант 2:", "Вариант 3:".'
                : 'Return only a JSON object with field and value keys for manual admin review.',
            $variantCount > 1
                ? 'Inside each variant return only the final field value, without field names or explanations.'
                : 'The field key must be exactly "' . $field . '". Do not return markdown, code fences or explanations.',
            $variantCount > 1
                ? 'Do not merge variants into one paragraph; every variant must start on a new line with its own header.'
                : 'For list fields, value must be an array of strings. For text fields, value must be a string.',
            'Never include secrets, tokens, internal IDs, VIN, license plates, registration documents, owner commissions or customer data.',
            'Never add features that are absent from car data.',
        ],
        'responseShape' => [
            'field' => $field,
            'value' => ai_text_field_is_list($field) ? [] : '',
        ],
    ];
    if ($variantCount > 1) {
        $payload['strictOutputTemplate'] = implode("\n\n", [
            "Вариант 1:\n<готовый текст варианта 1>",
            "Вариант 2:\n<готовый текст варианта 2>",
            "Вариант 3:\n<готовый текст варианта 3>",
        ]);
    }

    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

    return is_string($json) ? $json : '{}';
}

function ai_text_build_plain_all_prompt(array $carData, array $options): string
{
    $targets = ai_text_generation_targets();
    $tones = ai_text_tone_presets();
    $variantCount = max(1, min(3, (int) ($options['variantCount'] ?? 1)));
    $tone = (string) ($options['tone'] ?? 'calm');
    if (!isset($tones[$tone])) {
        $tone = 'calm';
    }

    $fieldHints = [];
    foreach (ai_text_allowed_fields() as $field => $meta) {
        $fieldHints[$field] = [
            'label' => (string) ($meta['label'] ?? $field),
            'hint' => (string) ($meta['hint'] ?? ''),
        ];
    }

    $payload = [
        'task' => 'car_public_content_all_fields_plain_generation',
        'target' => 'all',
        'targetLabel' => (string) ($targets['all'] ?? 'all'),
        'variantCount' => $variantCount,
        'requestedFields' => array_keys(ai_text_allowed_fields()),
        'fieldHints' => $fieldHints,
        'tone' => [
            'id' => $tone,
            'label' => (string) $tones[$tone],
        ],
        'directionPrompt' => ai_text_clean_string($options['userPrompt'] ?? '', 1000),
        'car' => ai_text_safe_car_context($carData),
        'rules' => [
            $variantCount > 1
                ? 'Return exactly ' . $variantCount . ' plain text variants with headers "Вариант 1:", "Вариант 2:", "Вариант 3:".'
                : 'Return only labeled plain text blocks for manual admin review.',
            'Inside each variant return labeled plain text blocks for manual admin review.',
            $variantCount > 1
                ? 'Do not merge variants; repeat the full labeled field set inside every variant.'
                : 'Return one complete labeled field set.',
            'Do not return JSON, markdown, code fences or explanations.',
            'Never include secrets, tokens, internal IDs, VIN, license plates, registration documents, owner commissions or customer data.',
            'Never add features that are absent from car data.',
        ],
    ];
    if ($variantCount > 1) {
        $fieldTemplate = implode("\n", [
            'Сценарий для карточки:',
            'Описание для карточки:',
            'Описание для детальной страницы:',
            'Кому подойдёт:',
            'Что удобно:',
            'Кастомные бейджи:',
            'SEO title:',
            'SEO description:',
        ]);
        $payload['strictOutputTemplate'] = implode("\n\n", [
            "Вариант 1:\n" . $fieldTemplate,
            "Вариант 2:\n" . $fieldTemplate,
            "Вариант 3:\n" . $fieldTemplate,
        ]);
    }

    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

    return is_string($json) ? $json : '{}';
}

function ai_text_completion_token_limit(array $options, ?string $plainField): int
{
    $variantCount = max(1, min(3, (int) ($options['variantCount'] ?? 1)));
    if ($plainField !== null) {
        if (ai_text_field_is_list($plainField)) {
            return $variantCount > 1 ? 1800 : 900;
        }

        return $variantCount > 1 ? 2800 : 1200;
    }

    $target = (string) ($options['target'] ?? 'all');
    if ($target === 'all') {
        return $variantCount > 1 ? 7000 : 4500;
    }

    return $variantCount > 1 ? 2800 : 1600;
}

function ai_text_variant_label(int $variantNumber): string
{
    return 'Вариант ' . max(1, $variantNumber);
}

function ai_text_split_plain_variants(string $text, int $variantCount): array
{
    $text = ai_text_sanitize_response($text, true);
    if ($text === '') {
        return [];
    }

    $variantCount = max(1, min(3, $variantCount));
    if ($variantCount <= 1) {
        return [
            [
                'number' => 1,
                'text' => $text,
            ],
        ];
    }

    $variantWord = '\x{0412}\x{0430}\x{0440}\x{0438}\x{0430}\x{043d}\x{0442}';
    $pattern = '/(?:^|[\r\n]+|\s{2,})(?:[#>*\-\s]+)?(?:\*\*)?\s*(?:' . $variantWord . '|Variant|Option)\s*(?:#|№|No\.?)?\s*(\d{1,2})(?:\s*[:\).\-\x{2014}])?\s*(?:\*\*)?\s*/iu';
    if (!preg_match_all($pattern, $text, $matches, PREG_OFFSET_CAPTURE)) {
        return [
            [
                'number' => 1,
                'text' => $text,
            ],
        ];
    }

    $blocks = [];
    $count = count($matches[0]);
    for ($index = 0; $index < $count; $index++) {
        $number = (int) ($matches[1][$index][0] ?? ($index + 1));
        if ($number < 1 || $number > 3) {
            $number = $index + 1;
        }
        $start = (int) $matches[0][$index][1] + strlen((string) $matches[0][$index][0]);
        $end = $index + 1 < $count ? (int) $matches[0][$index + 1][1] : strlen($text);
        $blockText = trim(substr($text, $start, max(0, $end - $start)));
        if ($blockText === '') {
            continue;
        }
        $blocks[] = [
            'number' => $number,
            'text' => $blockText,
        ];
        if (count($blocks) >= $variantCount) {
            break;
        }
    }

    return $blocks ?: [
        [
            'number' => 1,
            'text' => $text,
        ],
    ];
}

function ai_text_variant_has_value(array $fields): bool
{
    foreach ($fields as $value) {
        if ((is_array($value) && $value) || (is_string($value) && $value !== '')) {
            return true;
        }
    }

    return false;
}

function ai_text_normalize_plain_response(string $text, array $options, ?string $plainField): ?array
{
    $variantCount = max(1, min(3, (int) ($options['variantCount'] ?? 1)));
    $requestedFields = $plainField !== null ? [$plainField] : ai_text_requested_fields($options);
    $blocks = ai_text_split_plain_variants($text, $variantCount);
    if (!$blocks) {
        return null;
    }

    $variants = [];
    foreach ($blocks as $index => $block) {
        $blockText = (string) ($block['text'] ?? '');
        if ($blockText === '') {
            continue;
        }

        $fields = [];
        if ($plainField !== null) {
            $labeledFields = ai_text_fields_from_labeled_text($blockText);
            if (array_key_exists($plainField, $labeledFields)) {
                $fields = ai_text_normalize_variant_fields([$plainField => $labeledFields[$plainField]], [$plainField]);
            } else {
                $single = ai_text_normalize_plain_field_response($plainField, $blockText);
                $fields = is_array($single) ? (array) ($single['variants'][0]['fields'] ?? []) : [];
            }
        } else {
            $fields = ai_text_fields_from_labeled_text($blockText);
            $fields = ai_text_normalize_variant_fields($fields, $requestedFields);
        }

        if (!ai_text_variant_has_value($fields)) {
            continue;
        }

        $variantNumber = (int) ($block['number'] ?? ($index + 1));
        $variants[] = [
            'label' => ai_text_variant_label($variantNumber),
            'fields' => $fields,
        ];
        if (count($variants) >= $variantCount) {
            break;
        }
    }

    if (!$variants) {
        return null;
    }

    $warnings = [];
    if ($variantCount > 1 && count($variants) < $variantCount) {
        $warnings[] = 'DeepSeek вернул меньше вариантов, чем запрошено. Проверьте результат перед вставкой.';
    }

    return [
        'variants' => $variants,
        'warnings' => $warnings,
        'requestedFields' => $requestedFields,
    ];
}

function ai_text_normalize_plain_all_response(string $text, array $options): ?array
{
    $fields = ai_text_fields_from_labeled_text($text);
    if (!$fields) {
        return null;
    }

    $requestedFields = ai_text_requested_fields($options);
    $normalizedFields = ai_text_normalize_variant_fields($fields, $requestedFields);
    $hasAny = false;
    foreach ($normalizedFields as $value) {
        if ((is_array($value) && $value) || (is_string($value) && $value !== '')) {
            $hasAny = true;
            break;
        }
    }
    if (!$hasAny) {
        return null;
    }

    return [
        'variants' => [
            [
                'label' => 'Вариант 1',
                'fields' => $normalizedFields,
            ],
        ],
        'warnings' => [],
        'requestedFields' => $requestedFields,
    ];
}

function ai_text_normalize_plain_field_response(string $field, string $text): ?array
{
    $allowed = ai_text_allowed_fields();
    if (!isset($allowed[$field])) {
        return null;
    }

    $isList = ai_text_field_is_list($field);
    $text = ai_text_sanitize_response($text, $isList);
    $label = (string) ($allowed[$field]['label'] ?? $field);
    foreach ([$label, $field] as $prefix) {
        if ($prefix === '') {
            continue;
        }
        $text = preg_replace('/^\s*' . preg_quote($prefix, '/') . '\s*[:：—-]\s*/iu', '', $text) ?? $text;
    }

    $value = '';
    if ($isList) {
        $items = preg_split('/\r\n|\r|\n|;|•/u', $text);
        $items = is_array($items) ? $items : [];
        $items = array_map(static function ($item): string {
            $item = preg_replace('/^\s*(?:[-*]+|\d+[\).\:-])\s*/u', '', (string) $item) ?? (string) $item;

            return trim($item);
        }, $items);
        $value = ai_text_clean_list(
            $items,
            (int) ($allowed[$field]['maxItems'] ?? 8),
            (int) ($allowed[$field]['itemMax'] ?? 80)
        );
    } else {
        $text = preg_replace('/^\s*["\'«“„]+|["\'»”]+\s*$/u', '', $text) ?? $text;
        $value = ai_text_clean_string($text, (int) ($allowed[$field]['max'] ?? 800));
    }

    $fields = ai_text_normalize_variant_fields([$field => $value], [$field]);
    $hasValue = false;
    foreach ($fields as $fieldValue) {
        if ((is_array($fieldValue) && $fieldValue) || (is_string($fieldValue) && $fieldValue !== '')) {
            $hasValue = true;
            break;
        }
    }
    if (!$hasValue) {
        return null;
    }

    return [
        'variants' => [
            [
                'label' => 'Вариант 1',
                'fields' => $fields,
            ],
        ],
        'warnings' => [],
        'requestedFields' => [$field],
    ];
}

function ai_text_array_is_list(array $value): bool
{
    return $value === [] || array_keys($value) === range(0, count($value) - 1);
}

function ai_text_response_key_id(string $key): string
{
    $key = mb_strtolower(trim($key), 'UTF-8');
    $key = str_replace('ё', 'е', $key);
    $key = preg_replace('/[^a-zа-я0-9]+/u', '', $key) ?? $key;

    return $key;
}

function ai_text_response_field_aliases(): array
{
    $aliases = [];
    foreach (ai_text_allowed_fields() as $field => $meta) {
        foreach ([$field, (string) ($meta['label'] ?? '')] as $alias) {
            if ($alias !== '') {
                $aliases[ai_text_response_key_id($alias)] = $field;
            }
        }
    }

    foreach ([
        'short_scenario' => 'shortScenario',
        'scenario' => 'shortScenario',
        'card_description' => 'cardDescription',
        'card_text' => 'cardDescription',
        'card_copy' => 'cardDescription',
        'description_for_card' => 'cardDescription',
        'detail_description' => 'detailDescription',
        'detail_text' => 'detailDescription',
        'long_description' => 'detailDescription',
        'best_for' => 'bestFor',
        'for_whom' => 'bestFor',
        'strong_points' => 'strongPoints',
        'advantages' => 'strongPoints',
        'card_badges_custom' => 'cardBadgesCustom',
        'badges' => 'cardBadgesCustom',
        'seo_title' => 'seoTitle',
        'meta_title' => 'seoTitle',
        'seo_description' => 'seoDescription',
        'meta_description' => 'seoDescription',
        'сценарий' => 'shortScenario',
        'короткийсценарий' => 'shortScenario',
        'описаниедлякарточки' => 'cardDescription',
        'текстдлякарточки' => 'cardDescription',
        'описаниедлядетальнойстраницы' => 'detailDescription',
        'подробноеописание' => 'detailDescription',
        'комуподойдет' => 'bestFor',
        'сильныестороны' => 'strongPoints',
        'чтoудобно' => 'strongPoints',
        'чтоудобно' => 'strongPoints',
        'кастомныебейджи' => 'cardBadgesCustom',
        'бейджи' => 'cardBadgesCustom',
    ] as $alias => $field) {
        $aliases[ai_text_response_key_id($alias)] = $field;
    }

    return $aliases;
}

function ai_text_labeled_text_aliases(): array
{
    return [
        'shortScenario' => ['shortScenario', 'short_scenario', 'Короткий сценарий', 'Сценарий для карточки', 'Сценарий'],
        'cardDescription' => ['cardDescription', 'card_description', 'card_text', 'Описание для карточки', 'Текст для карточки'],
        'detailDescription' => ['detailDescription', 'detail_description', 'detail_text', 'Описание для детальной страницы', 'Подробное описание'],
        'bestFor' => ['bestFor', 'best_for', 'Кому подойдёт', 'Кому подойдет'],
        'strongPoints' => ['strongPoints', 'strong_points', 'Сильные стороны', 'Что удобно'],
        'cardBadgesCustom' => ['cardBadgesCustom', 'card_badges_custom', 'Кастомные бейджи', 'Бейджи'],
        'seoTitle' => ['seoTitle', 'seo_title', 'SEO title', 'Meta title'],
        'seoDescription' => ['seoDescription', 'seo_description', 'SEO description', 'Meta description'],
    ];
}

function ai_text_response_field_from_key(string $key): ?string
{
    $aliases = ai_text_response_field_aliases();
    $id = ai_text_response_key_id($key);

    return $aliases[$id] ?? null;
}

function ai_text_fields_from_labeled_text(string $text): array
{
    $text = ai_text_sanitize_response($text, true);
    if ($text === '') {
        return [];
    }

    $aliasToField = [];
    $patterns = [];
    foreach (ai_text_labeled_text_aliases() as $field => $aliases) {
        foreach ($aliases as $alias) {
            $aliasToField[ai_text_response_key_id($alias)] = $field;
            $patterns[] = preg_quote($alias, '/');
        }
    }
    $patterns = array_values(array_unique($patterns));
    if (!$patterns) {
        return [];
    }

    $pattern = '/(' . implode('|', $patterns) . ')\s*[:：]\s*/iu';
    if (!preg_match_all($pattern, $text, $matches, PREG_OFFSET_CAPTURE)) {
        return [];
    }

    $fields = [];
    $count = count($matches[0]);
    for ($index = 0; $index < $count; $index++) {
        $alias = (string) ($matches[1][$index][0] ?? '');
        $field = $aliasToField[ai_text_response_key_id($alias)] ?? null;
        if ($field === null) {
            continue;
        }

        $valueStart = (int) $matches[0][$index][1] + strlen((string) $matches[0][$index][0]);
        $valueEnd = $index + 1 < $count ? (int) $matches[0][$index + 1][1] : strlen($text);
        $value = trim(substr($text, $valueStart, max(0, $valueEnd - $valueStart)));
        if ($value !== '') {
            $fields[$field] = $value;
        }
    }

    return $fields;
}

function ai_text_fields_from_assoc(array $source): array
{
    $fieldName = '';
    foreach (['field', 'name', 'key', 'id', 'target', 'label'] as $nameKey) {
        if (isset($source[$nameKey]) && is_string($source[$nameKey])) {
            $fieldName = $source[$nameKey];
            break;
        }
    }
    $field = $fieldName !== '' ? ai_text_response_field_from_key($fieldName) : null;
    if ($field !== null) {
        foreach (['value', 'text', 'content', 'items', 'lines', 'result'] as $valueKey) {
            if (array_key_exists($valueKey, $source)) {
                return [$field => $source[$valueKey]];
            }
        }
    }

    $fields = [];
    foreach ($source as $key => $value) {
        if (!is_string($key)) {
            continue;
        }
        $field = ai_text_response_field_from_key($key);
        if ($field !== null) {
            $fields[$field] = $value;
        }
    }

    return $fields;
}

function ai_text_fields_from_list(array $source): array
{
    $fields = [];
    foreach ($source as $item) {
        if (!is_array($item)) {
            continue;
        }

        $direct = ai_text_fields_from_assoc($item);
        if ($direct) {
            $fields = array_merge($fields, $direct);
            continue;
        }

        $fieldName = '';
        foreach (['field', 'name', 'key', 'id', 'target', 'label'] as $nameKey) {
            if (isset($item[$nameKey]) && is_string($item[$nameKey])) {
                $fieldName = $item[$nameKey];
                break;
            }
        }
        $field = $fieldName !== '' ? ai_text_response_field_from_key($fieldName) : null;
        if ($field === null) {
            continue;
        }

        $fieldValue = null;
        $hasValue = false;
        foreach (['value', 'text', 'content', 'items', 'lines', 'result'] as $valueKey) {
            if (array_key_exists($valueKey, $item)) {
                $fieldValue = $item[$valueKey];
                $hasValue = true;
                break;
            }
        }
        if ($hasValue) {
            $fields[$field] = $fieldValue;
        }
    }

    return $fields;
}

function ai_text_extract_variant_fields(array $variant): array
{
    $fieldName = '';
    foreach (['field', 'name', 'key', 'id', 'target', 'label'] as $nameKey) {
        if (isset($variant[$nameKey]) && is_string($variant[$nameKey])) {
            $fieldName = $variant[$nameKey];
            break;
        }
    }
    $field = $fieldName !== '' ? ai_text_response_field_from_key($fieldName) : null;
    if ($field !== null) {
        foreach (['value', 'text', 'content', 'items', 'lines', 'result'] as $valueKey) {
            if (array_key_exists($valueKey, $variant)) {
                return [$field => $variant[$valueKey]];
            }
        }
    }

    foreach (['fields', 'content', 'texts', 'proposal', 'data', 'result', 'copy'] as $key) {
        if (!isset($variant[$key])) {
            continue;
        }
        if (is_string($variant[$key])) {
            $fields = ai_text_fields_from_labeled_text($variant[$key]);
        } elseif (is_array($variant[$key])) {
            $fields = ai_text_array_is_list($variant[$key])
                ? ai_text_fields_from_list($variant[$key])
                : ai_text_fields_from_assoc($variant[$key]);
        } else {
            $fields = [];
        }
        if ($fields) {
            return $fields;
        }
    }

    $fields = ai_text_fields_from_assoc($variant);
    if ($fields) {
        return $fields;
    }

    $bestFields = [];
    foreach ($variant as $value) {
        if (is_string($value)) {
            $fields = ai_text_fields_from_labeled_text($value);
        } elseif (is_array($value)) {
            $fields = ai_text_array_is_list($value)
                ? ai_text_fields_from_list($value)
                : ai_text_fields_from_assoc($value);
        } else {
            continue;
        }
        if (count($fields) > count($bestFields)) {
            $bestFields = $fields;
        }
    }

    return $bestFields;
}

function ai_text_normalize_variant_fields(array $fields, array $requestedFields): array
{
    $allowed = ai_text_allowed_fields();
    $normalized = [];
    foreach ($allowed as $field => $meta) {
        if (!in_array($field, $requestedFields, true)) {
            $normalized[$field] = ai_text_field_is_list($field) ? [] : '';
            continue;
        }
        if (ai_text_field_is_list($field)) {
            $normalized[$field] = ai_text_clean_list(
                $fields[$field] ?? [],
                (int) ($meta['maxItems'] ?? 8),
                (int) ($meta['itemMax'] ?? 80)
            );
        } else {
            $normalized[$field] = ai_text_clean_string($fields[$field] ?? '', (int) ($meta['max'] ?? 800));
        }
    }

    return $normalized;
}

function ai_text_normalize_response(array $payload, array $options): array
{
    $requestedFields = ai_text_requested_fields($options);
    $variants = [];
    $sourceVariants = [];
    if (isset($payload['variants']) && is_array($payload['variants'])) {
        $sourceVariants = $payload['variants'];
    } elseif (isset($payload['fields']) && is_array($payload['fields'])) {
        $sourceVariants = [['label' => 'Вариант 1', 'fields' => $payload['fields']]];
    } else {
        $sourceVariants = [['label' => 'Вариант 1', 'fields' => $payload]];
    }

    foreach ($sourceVariants as $index => $variant) {
        $variantNumber = count($variants) + 1;
        if (is_string($variant)) {
            $fields = ai_text_fields_from_labeled_text($variant);
            $variant = ['label' => 'Вариант ' . $variantNumber];
        } elseif (is_array($variant)) {
            $fields = ai_text_extract_variant_fields($variant);
        } else {
            $fields = [];
        }
        $normalizedFields = ai_text_normalize_variant_fields($fields, $requestedFields);
        $hasAny = false;
        foreach ($normalizedFields as $value) {
            if ((is_array($value) && $value) || (is_string($value) && $value !== '')) {
                $hasAny = true;
                break;
            }
        }
        if (!$hasAny) {
            continue;
        }
        $variants[] = [
            'label' => ai_text_clean_string($variant['label'] ?? ('Вариант ' . $variantNumber), 80) ?: ('Вариант ' . $variantNumber),
            'fields' => $normalizedFields,
        ];
        if (count($variants) >= 3) {
            break;
        }
    }

    return [
        'variants' => $variants,
        'warnings' => ai_text_clean_list($payload['warnings'] ?? [], 8, 180),
        'requestedFields' => $requestedFields,
    ];
}

function ai_text_generate_plain_variant_series(array $carData, array $options): ?array
{
    $requestedCount = max(1, min(3, (int) ($options['variantCount'] ?? 1)));
    if ($requestedCount <= 1) {
        return null;
    }

    $plainField = ai_text_plain_response_field($options);
    $plainAll = ai_text_plain_all_response($options);
    if ($plainField === null && !$plainAll) {
        return null;
    }
    if ($plainField === null) {
        return null;
    }

    $baseUserPrompt = ai_text_clean_string($options['userPrompt'] ?? '', 1000);
    $variants = [];
    $warnings = [];
    $requestedFields = $plainField !== null ? [$plainField] : ai_text_requested_fields($options);
    $totalDurationMs = 0;
    $model = '';
    $lastError = '';

    for ($variantNumber = 1; $variantNumber <= $requestedCount; $variantNumber++) {
        $singleOptions = $options;
        $singleOptions['variantCount'] = 1;
        $variantPrompt = 'Вариант ' . $variantNumber . ' из ' . $requestedCount . ': сделай самостоятельную редакцию, не повторяй формулировки предыдущих вариантов.';
        $singleOptions['userPrompt'] = ai_text_clean_string(trim($baseUserPrompt . "\n\n" . $variantPrompt), 1000);

        $singlePlainField = ai_text_plain_response_field($singleOptions);
        $prompt = $singlePlainField !== null
            ? ai_text_build_plain_field_prompt($carData, $singleOptions, $singlePlainField)
            : ai_text_build_plain_all_prompt($carData, $singleOptions);

        try {
            $partial = ai_text_call_deepseek($prompt, $singleOptions);
        } catch (Throwable $exception) {
            $lastError = ai_text_clean_string($exception->getMessage(), 700);
            $warnings[] = 'Не удалось сгенерировать вариант ' . $variantNumber . '.';
            continue;
        }

        $totalDurationMs += (int) ($partial['durationMs'] ?? 0);
        $model = $model !== '' ? $model : (string) ($partial['model'] ?? '');
        if (!empty($partial['requestedFields']) && is_array($partial['requestedFields'])) {
            $requestedFields = array_values(array_intersect((array) $partial['requestedFields'], $requestedFields));
            if (!$requestedFields) {
                $requestedFields = $plainField !== null ? [$plainField] : ai_text_requested_fields($options);
            }
        }
        foreach ((array) ($partial['warnings'] ?? []) as $warning) {
            $warning = ai_text_clean_string($warning, 180);
            if ($warning !== '') {
                $warnings[] = $warning;
            }
        }

        $partialVariants = array_values((array) ($partial['variants'] ?? []));
        $fields = isset($partialVariants[0]['fields']) && is_array($partialVariants[0]['fields'])
            ? $partialVariants[0]['fields']
            : [];
        if (!ai_text_variant_has_value($fields)) {
            $warnings[] = 'DeepSeek не вернул вставляемые поля для варианта ' . $variantNumber . '.';
            continue;
        }

        $variants[] = [
            'label' => ai_text_variant_label($variantNumber),
            'fields' => $fields,
        ];
    }

    $warnings = array_values(array_unique(ai_text_clean_list($warnings, 8, 180)));
    if (!$variants) {
        throw new RuntimeException($lastError !== '' ? $lastError : 'DeepSeek не вернул варианты для вставки.');
    }
    if (count($variants) < $requestedCount) {
        $warnings[] = 'DeepSeek вернул меньше вариантов, чем запрошено. Проверьте результат перед вставкой.';
        $warnings = array_values(array_unique(ai_text_clean_list($warnings, 8, 180)));
    }

    return [
        'parsed' => true,
        'plainTextMode' => true,
        'multiCallMode' => true,
        'rawText' => '',
        'variants' => $variants,
        'warnings' => $warnings,
        'requestedFields' => $requestedFields,
        'durationMs' => $totalDurationMs,
        'model' => $model,
    ];
}

function ai_text_call_deepseek(string $prompt, array $options): array
{
    $settings = openai_ai_settings();
    $actor = current_admin_user() ?: 'system';
    $model = (string) ($settings['model'] ?? 'deepseek-v4-flash');
    $plainField = ai_text_plain_response_field($options);
    $plainAll = ai_text_plain_all_response($options);
    $runBase = [
        'id' => 'carai_' . bin2hex(random_bytes(8)),
        'createdAt' => now_iso(),
        'actor' => $actor,
        'scope_id' => demand_normalize_scope_id((string) ($options['scopeId'] ?? 'rent_rk')),
        'task' => 'car_content:' . ai_text_clean_string($options['target'] ?? 'all', 60),
        'entityType' => 'car',
        'entityId' => normalize_car_slug((string) ($options['carSlug'] ?? '')),
        'model' => $model,
        'promptHash' => openai_ai_hash_value($prompt),
    ];

    if (empty($settings['enabled']) || empty($settings['apiKeyConfigured'])) {
        openai_ai_log_run(array_merge($runBase, [
            'status' => 'error',
            'errorCode' => 'not_configured',
            'sanitizedError' => 'DeepSeek не настроен',
        ]));
        throw new RuntimeException('DeepSeek не настроен');
    }

    $limit = openai_ai_limit_status($actor, $settings);
    if (!empty($limit['blocked'])) {
        $message = ai_text_clean_string($limit['message'] ?? 'Лимит DeepSeek исчерпан.', 500);
        openai_ai_log_run(array_merge($runBase, [
            'status' => 'error',
            'errorCode' => 'limit_blocked',
            'sanitizedError' => $message,
        ]));
        throw new RuntimeException($message);
    }

    $credentials = openai_ai_private_credentials();
    $apiKey = (string) ($credentials['apiKey'] ?? '');
    if ($apiKey === '') {
        openai_ai_log_run(array_merge($runBase, [
            'status' => 'error',
            'errorCode' => 'missing_api_key',
            'sanitizedError' => 'DeepSeek не настроен',
        ]));
        throw new RuntimeException('DeepSeek не настроен');
    }
    if (!function_exists('curl_init')) {
        openai_ai_log_run(array_merge($runBase, [
            'status' => 'error',
            'errorCode' => 'curl_missing',
            'sanitizedError' => 'PHP cURL extension is not available.',
        ]));
        throw new RuntimeException('PHP cURL extension is not available.');
    }
    $configurationVersion = openai_ai_provider_configuration_version($settings, $credentials);

    $model = demand_clean_string((string) ($options['model'] ?? $credentials['model'] ?: $settings['model'] ?? 'deepseek-v4-flash'), 80) ?: 'deepseek-v4-flash';
    $timeout = openai_ai_clamp_int($options['timeoutSeconds'] ?? ($credentials['timeoutSeconds'] ?: $settings['perRequestTimeoutSeconds']), 5, 120, 45);
    $baseUrl = openai_ai_normalize_base_url((string) ($credentials['baseUrl'] ?? 'https://api.deepseek.com'));
    $variantCount = max(1, min(3, (int) ($options['variantCount'] ?? 1)));
    $payload = [
        'model' => $model,
        'messages' => [
            [
                'role' => 'system',
                'content' => $plainField !== null
                    ? ai_text_plain_system_instructions($plainField, $variantCount)
                    : ($plainAll
                        ? ai_text_plain_all_system_instructions($variantCount)
                        : ai_text_system_instructions() . "\n\nВерни только JSON object по этой схеме: " . json_encode(ai_text_response_schema(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)),
            ],
            ['role' => 'user', 'content' => $prompt],
        ],
        'thinking' => ['type' => 'disabled'],
        'stream' => false,
        'temperature' => ($plainField !== null || $plainAll) ? 0.35 : 0.25,
        'max_tokens' => ai_text_completion_token_limit($options, $plainField),
    ];
    if ($plainField !== null || ($plainField === null && !$plainAll)) {
        $payload['response_format'] = ['type' => 'json_object'];
    }
    $body = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($body === false) {
        throw new RuntimeException('DeepSeek request payload could not be encoded.');
    }

    $attempts = 1 + openai_ai_clamp_int($settings['retryCount'] ?? 0, 0, 1, 0);
    $lastError = '';
    $httpCode = 0;
    for ($attempt = 1; $attempt <= $attempts; $attempt++) {
        $started = microtime(true);
        $url = $baseUrl . '/chat/completions';
        $transport = RentalReturnStore::waitOutsideLock(static function () use ($url, $body, $timeout, $attempt, $apiKey): array {
            $controlled = demand_integrations_controlled_transport('deepseek', [
                'method' => 'POST',
                'operation' => 'car-text.generate',
                'url' => $url,
                'body' => $body,
                'headerNames' => ['Authorization', 'Content-Type'],
                'timeoutSeconds' => $timeout,
                'attempt' => $attempt,
            ]);
            if ($controlled !== null) {
                return [
                    'raw' => $controlled['body'] ?? false,
                    'httpCode' => (int) ($controlled['status'] ?? 0),
                    'error' => (string) ($controlled['error'] ?? ''),
                ];
            }

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $apiKey,
                    'Content-Type: application/json',
                ],
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_TIMEOUT => $timeout,
            ]);
            $raw = curl_exec($ch);
            $httpCode = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            return ['raw' => $raw, 'httpCode' => $httpCode, 'error' => $curlError];
        });
        if (!hash_equals($configurationVersion, openai_ai_provider_configuration_version())) {
            throw new RuntimeException('Настройки AI-провайдера изменились во время запроса. Повторите операцию.', 409);
        }
        $raw = $transport['raw'] ?? false;
        $httpCode = (int) ($transport['httpCode'] ?? 0);
        $curlError = (string) ($transport['error'] ?? '');
        $durationMs = (int) round((microtime(true) - $started) * 1000);

        if ($raw !== false && $httpCode >= 200 && $httpCode < 300) {
            $decoded = json_decode((string) $raw, true);
            if (!is_array($decoded)) {
                $error = 'DeepSeek response was not valid transport JSON.';
                openai_ai_log_run(array_merge($runBase, [
                    'model' => $model,
                    'status' => 'error',
                    'errorCode' => 'transport_json_invalid',
                    'sanitizedError' => $error,
                ]));
                throw new RuntimeException($error);
            }
            $usage = openai_ai_usage_from_response($decoded);
            $responseText = ai_text_sanitize_response(openai_ai_extract_response_text($decoded));
            if ($responseText === '') {
                $error = 'DeepSeek response did not contain usable output text.';
                openai_ai_log_run(array_merge($runBase, [
                    'model' => $model,
                    'status' => 'error',
                    'errorCode' => 'empty_output',
                    'sanitizedError' => $error,
                ]));
                throw new RuntimeException($error);
            }
            $parsed = ai_text_decode_json_response($responseText);
            if ($plainField !== null || $plainAll) {
                $normalized = null;
                if (is_array($parsed)) {
                    $candidate = ai_text_normalize_response($parsed, $options);
                    if (!empty($candidate['variants'])) {
                        $normalized = $candidate;
                    }
                }
                if (!is_array($normalized)) {
                    $normalized = ai_text_normalize_plain_response($responseText, $options, $plainField);
                }
                if (is_array($normalized)) {
                    openai_ai_log_run(array_merge($runBase, [
                        'model' => $model,
                        'status' => 'success',
                        'responseHash' => openai_ai_hash_value($normalized),
                        'inputTokens' => (int) $usage['inputTokens'],
                        'outputTokens' => (int) $usage['outputTokens'],
                    ]));
                    openai_ai_update_settings_meta([
                        'lastSuccessAt' => now_iso(),
                        'lastErrorAt' => null,
                        'lastError' => null,
                        'lastErrorCode' => null,
                        'lastErrorTechnical' => null,
                    ]);

                    return [
                        'parsed' => true,
                        'plainTextMode' => true,
                        'rawText' => '',
                        'variants' => $normalized['variants'],
                        'warnings' => $normalized['warnings'],
                        'requestedFields' => $normalized['requestedFields'],
                        'durationMs' => $durationMs,
                        'model' => $model,
                    ];
                }
            }
            if (!is_array($parsed)) {
                openai_ai_log_run(array_merge($runBase, [
                    'model' => $model,
                    'status' => 'error',
                    'responseHash' => openai_ai_hash_value($responseText),
                    'inputTokens' => (int) $usage['inputTokens'],
                    'outputTokens' => (int) $usage['outputTokens'],
                    'errorCode' => 'invalid_structured_json',
                    'sanitizedError' => 'DeepSeek returned text, but not valid JSON.',
                ]));
                return [
                    'parsed' => false,
                    'rawText' => ai_text_clean_string($responseText, 4000),
                    'variants' => [],
                    'warnings' => ['DeepSeek вернул невалидный JSON. Текст можно скопировать и вставить вручную.'],
                    'durationMs' => $durationMs,
                    'model' => $model,
                ];
            }

            $normalized = ai_text_normalize_response($parsed, $options);
            if (empty($normalized['variants'])) {
                $error = 'DeepSeek response did not contain usable fields.';
                openai_ai_log_run(array_merge($runBase, [
                    'model' => $model,
                    'status' => 'error',
                    'responseHash' => openai_ai_hash_value($normalized),
                    'inputTokens' => (int) $usage['inputTokens'],
                    'outputTokens' => (int) $usage['outputTokens'],
                    'errorCode' => 'empty_fields',
                    'sanitizedError' => $error,
                ]));
                throw new RuntimeException($error);
            }
            openai_ai_log_run(array_merge($runBase, [
                'model' => $model,
                'status' => 'success',
                'responseHash' => openai_ai_hash_value($normalized),
                'inputTokens' => (int) $usage['inputTokens'],
                'outputTokens' => (int) $usage['outputTokens'],
            ]));
            openai_ai_update_settings_meta([
                'lastSuccessAt' => now_iso(),
                'lastErrorAt' => null,
                'lastError' => null,
                'lastErrorCode' => null,
                'lastErrorTechnical' => null,
            ]);

            return [
                'parsed' => true,
                'rawText' => '',
                'variants' => $normalized['variants'],
                'warnings' => $normalized['warnings'],
                'requestedFields' => $normalized['requestedFields'],
                'durationMs' => $durationMs,
                'model' => $model,
            ];
        }

        $lastError = $raw === false ? $curlError : (string) $raw;
    }

    $error = 'DeepSeek request failed: HTTP ' . $httpCode . ' ' . openai_ai_sanitize_error($lastError);
    openai_ai_log_run(array_merge($runBase, [
        'model' => $model,
        'status' => 'error',
        'errorCode' => 'request_failed',
        'sanitizedError' => $error,
    ]));
    openai_ai_update_settings_meta([
        'lastErrorAt' => now_iso(),
        'lastError' => 'DeepSeek API request failed.',
        'lastErrorCode' => 'car_text_request_failed',
        'lastErrorTechnical' => $error,
    ]);

    throw new RuntimeException($error);
}

function ai_text_generate_car_content(array $carData, array $options): array
{
    if (PHP_SAPI !== 'cli' && !has_permission('cars.edit')) {
        throw new RuntimeException('Недостаточно прав.');
    }

    $options['target'] = (string) ($options['target'] ?? 'all');
    $options['variantCount'] = max(1, min(3, (int) ($options['variantCount'] ?? 1)));
    $options['tone'] = (string) ($options['tone'] ?? 'calm');
    $options['userPrompt'] = ai_text_clean_string($options['userPrompt'] ?? '', 1000);
    $options['carSlug'] = normalize_car_slug((string) ($carData['slug'] ?? ''));
    $options['scopeId'] = car_owner_scope_id($carData);

    $seriesResult = ai_text_generate_plain_variant_series($carData, $options);
    if (is_array($seriesResult)) {
        $seriesResult['target'] = $options['target'];
        $seriesResult['variantCount'] = $options['variantCount'];
        $seriesResult['tone'] = $options['tone'];
        $seriesResult['generatedAt'] = now_iso();

        return $seriesResult;
    }

    $plainField = ai_text_plain_response_field($options);
    if ($plainField !== null) {
        $prompt = ai_text_build_plain_field_prompt($carData, $options, $plainField);
    } elseif (ai_text_plain_all_response($options)) {
        $prompt = ai_text_build_plain_all_prompt($carData, $options);
    } else {
        $prompt = ai_text_build_car_prompt($carData, $options);
    }
    $result = ai_text_call_deepseek($prompt, $options);
    $result['target'] = $options['target'];
    $result['variantCount'] = $options['variantCount'];
    $result['tone'] = $options['tone'];
    $result['generatedAt'] = now_iso();

    return $result;
}
