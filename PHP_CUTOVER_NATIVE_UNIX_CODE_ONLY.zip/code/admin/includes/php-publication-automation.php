<?php
declare(strict_types=1);

/** The producer hooks call this only from their existing authorized transaction. */
final class PhpPublicationAutomation
{
    public static function enabled(): bool
    {
        return defined('RENT_RK_PHP_PUBLICATION_AUTOMATION') && RENT_RK_PHP_PUBLICATION_AUTOMATION === true
            && self::isolated();
    }

    private static function isolated(): bool
    {
        return defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') && RENT_RK_AUDIT_ISOLATION_VERIFIED === true
            && in_array(PHP_SAPI, ['cli', 'cli-server'], true) && getenv('RENT_RK_ALLOW_TEST_DATA_DIR') === '1'
            && is_file(PROJECT_ROOT . '.rent-rk-test-lab')
            && realpath((string) getenv('RENT_RK_AUDIT_LAB_ROOT')) === realpath(PROJECT_ROOT);
    }

    private static function path(): string { return DATA_DIR . 'php-publication-jobs.json'; }

    public static function store(): array
    {
        if (!self::enabled()) throw new RuntimeException('BLOCKED_PHP_AUTOMATION_DISABLED', 403);
        return self::readStore();
    }

    private static function readStore(): array
    {
        if (is_link(self::path()) || (file_exists(self::path()) && !is_file(self::path()))) {
            throw new RuntimeException('BLOCKED_PHP_AUTOMATION_STORE', 503);
        }
        $s = RentalReturnStore::read(self::path(), ['version' => 1, 'cars' => [], 'jobs' => [], 'handoffs' => []]);
        if (($s['version'] ?? null) !== 1 || !is_array($s['cars'] ?? null) || !is_array($s['jobs'] ?? null)) {
            throw new RuntimeException('BLOCKED_PHP_AUTOMATION_STORE', 503);
        }
        return $s;
    }

    private static function save(array $s): void
    {
        if (!RentalReturnStore::stage(self::path(), $s)) throw new LogicException('Publication queue requires a transaction');
    }

    private static function approval(string $slug): ?array
    {
        require_once __DIR__ . '/approved-public-car-snapshot.php';
        $s = ApprovedPublicCarSnapshots::store();
        $h = $s['active'][$slug] ?? null;
        return ($h['state'] ?? null) === 'approved' ? $s['objects'][$h['id']]['immutable'] : null;
    }

    public static function unavailable(string $slug): bool
    {
        if ($slug === '' || (!self::enabled() && !(self::isolated() && PhpPublicationCutover::selected()))) return false;
        return (self::readStore()['cars'][$slug]['withdrawn'] ?? false) === true;
    }

    public static function assertNewOperationAllowed(string $slug): void
    {
        if (self::unavailable($slug)) throw new RuntimeException('Автомобиль сейчас недоступен.', 409);
    }

    public static function message(string $slug): string
    {
        $s = self::store();
        $head = $s['cars'][$slug] ?? [];
        $job = $s['jobs'][$head['job'] ?? ''] ?? [];
        $status = match ($job['status'] ?? '') {
            'pending', 'retry' => 'Сохранено. Ожидает публикации.',
            'published' => self::publishedMessage($job, !empty($head['withdrawn'])),
            'blocked' => 'Не опубликовано: требуется действие.',
            default => 'Сохранено. Публичные файлы не изменялись.',
        };
        if (PhpPublicationCutover::selected() && in_array($job['status'] ?? '', ['pending', 'retry'], true)) {
            try { PhpPublicationCutover::generation(); }
            catch (RuntimeException $e) {
                $status = $e->getMessage() === 'BLOCKED_PHP_CUTOVER_PAUSED'
                    ? 'Сохранено. Задание ожидает: исполнитель приостановлен.'
                    : 'Сохранено. Не опубликовано: проверьте режим публикации.';
            }
        }
        return !empty($head['withdrawn']) ? 'Новые заявки и выдача запрещены. ' . $status : $status;
    }

    private static function publishedMessage(array $job, bool $withdrawn): string
    {
        require_once __DIR__ . '/approved-public-car-snapshot.php';
        $last = $job['attempts'][array_key_last($job['attempts'])]['result'] ?? [];
        $state = ApprovedPhpPlanApply::state();
        if (($state['lastRun']['id'] ?? null) !== ($last['id'] ?? false)) return 'Актуальность страниц не подтверждена.';
        foreach ($state['lastRun']['outputs'] as $path) {
            $bytes = RentalReturnStore::publicationOutputBytes($path);
            if ($bytes === null || ($state['outputs'][$path]['outputHash'] ?? null) !== 'sha256:' . hash('sha256', $bytes)) {
                return 'Не опубликовано: требуется действие.';
            }
        }
        return $withdrawn ? 'Публичные страницы обновлены.' : 'Опубликовано: утверждённая версия.';
    }

    private static function append(string $kind, string $slug, string $scope, ?string $approvalId, array $patch = []): void
    {
        if (!RentalReturnStore::active() || !preg_match('/\A[a-z0-9]+(?:-[a-z0-9]+)*\z/D', $slug) || $slug === 'index'
            || current_admin_user() === '') throw new RuntimeException('BLOCKED_PHP_AUTOMATION_ACTION', 409);
        $s = self::store();
        $old = $s['cars'][$slug] ?? [];
        $gen = ($old['generation'] ?? 0) + 1;
        $id = bin2hex(random_bytes(16));
        $event = ['kind' => $kind, 'id' => $id, 'actor' => current_admin_user(), 'scope' => $scope, 'patch' => $patch];
        $withdraw = in_array($kind, ['hide', 'archive', 'delete', 'revoke'], true);
        if (!$withdraw && $kind !== 'publish' && (!empty($old['withdrawn']) || $approvalId === null)) return;
        $prior = $old['job'] ?? '';
        $desired = [];
        if (!$withdraw && ($old['approvalId'] ?? null) === $approvalId) {
            $published = $old['published'] ?? [];
            $desired = ($s['jobs'][$prior]['status'] ?? null) === 'blocked'
                ? (($published['approvalId'] ?? null) === $approvalId ? $published['desired'] : [])
                : ($old['desired'] ?? []);
        }
        if (in_array($kind, ['rates', 'photos'], true)) $desired[$kind] = $event;
        if (in_array($s['jobs'][$prior]['status'] ?? '', ['pending', 'retry', 'blocked'], true)) $s['jobs'][$prior]['status'] = 'superseded';
        $s['jobs'][$id] = $event + ['slug' => $slug, 'approvalId' => $approvalId, 'generation' => $gen, 'status' => 'pending',
            'desired' => $desired, 'attempts' => [], 'at' => now_iso()];
        $s['cars'][$slug] = ['generation' => $gen, 'job' => $id, 'withdrawn' => $withdraw || !empty($old['withdrawn']), 'approvalId' => $approvalId,
            'desired' => $desired, 'published' => $old['published'] ?? null];
        self::save($s);
        audit_log('site.php_automation.queued', 'car', $slug, 'Publication action queued',
            ['id' => $id, 'action' => $kind, 'generation' => $gen, 'scope' => $scope, 'approvalId' => $approvalId]);
    }

    public static function publish(string $slug): void
    {
        if (!self::enabled()) return;
        $car = require_car_scope($slug);
        if (!current_user_is_platform_admin() || !has_permission('cars.publish')) {
            throw new RuntimeException('BLOCKED_PHP_AUTOMATION_ACTION', 403);
        }
        $o = self::approval($slug);
        if (!car_visible_in_public_rent_rk_showcase($car)
            || ($o && ($o['material']['car']['scopeId'] ?? null) !== car_owner_scope_id($car))) {
            throw new RuntimeException('BLOCKED_PHP_AUTOMATION_APPROVAL_REQUIRED', 409);
        }
        self::append('publish', $slug, car_owner_scope_id($car), $o['id'] ?? null);
    }

    public static function withdraw(string $kind, string $slug, string $scope): void
    {
        if (!self::enabled()) return;
        if (!in_array($kind, ['hide', 'archive', 'delete', 'revoke'], true) || !has_permission('cars.edit')) {
            throw new RuntimeException('BLOCKED_PHP_AUTOMATION_ACTION', 403);
        }
        self::append($kind, $slug, $scope, null);
    }

    public static function tariff(string $slug): ?array
    {
        if (!self::enabled()) return null;
        $car = find_car($slug);
        if (!$car) return null;
        $rate = rate_for_car($slug, $car);
        $price = car_publication_display_price($car, $rate);
        $deposit = normalize_rate_price($rate['depositAmount'] ?? $car['depositAmount'] ?? null);
        if ($price === null || $deposit === null) return null;
        return ['price' => $price, 'deposit' => $deposit,
            'relatedPrice' => normalize_rate_price($rate['manual'] ?? null) ?? normalize_rate_price($rate['base'] ?? null)
                ?? normalize_rate_price($car['price'] ?? null)];
    }

    public static function ratesSaved(string $slug, ?array $before): bool
    {
        if (!self::enabled() || self::unavailable($slug)) return false;
        $car = require_car_scope($slug);
        $scope = car_owner_scope_id($car);
        if (!current_user_can_edit_tariffs($scope)) throw new RuntimeException('BLOCKED_PHP_AUTOMATION_ACTION', 403);
        $o = self::approval($slug);
        $after = self::tariff($slug);
        if (!$o || !$after || !car_visible_in_public_rent_rk_showcase($car) || $after === $before) return false;
        if ($o['material']['car']['scopeId'] !== $scope) throw new RuntimeException('BLOCKED_PHP_AUTOMATION_SCOPE', 409);
        self::append('rates', $slug, $scope, $o['id'], $after);
        return true;
    }

    public static function photosMoved(string $slug): void
    {
        if (!self::enabled() || self::unavailable($slug)) return;
        $car = require_car_scope($slug);
        if (!has_permission('cars.edit')) throw new RuntimeException('BLOCKED_PHP_AUTOMATION_ACTION', 403);
        $o = self::approval($slug);
        if (!$o || !car_visible_in_public_rent_rk_showcase($car)) return;
        $approved = $o['material']['car'];
        $main = ltrim((string) $car['image'], '/');
        $gallery = array_values(array_unique(array_merge([$main], array_column(car_photos($car), 'path'))));
        if ($approved['scopeId'] !== car_owner_scope_id($car) || $main !== $approved['image']
            || count($gallery) !== count($approved['gallery']) || array_diff($gallery, $approved['gallery'])) return;
        $previous = self::store()['cars'][$slug]['desired']['photos']['patch']['gallery'] ?? $approved['gallery'];
        if ($gallery === $previous) return;
        self::append('photos', $slug, $approved['scopeId'], $o['id'], ['gallery' => $gallery]);
    }

    public static function preservesPhoto(string $path): bool
    {
        if (!self::enabled()) return false;
        require_once __DIR__ . '/approved-public-car-snapshot.php';
        foreach (ApprovedPublicCarSnapshots::store()['objects'] as $row) {
            if (isset($row['immutable']['material']['assets'][$path])) return true;
        }
        return false;
    }

    private static function optionProof(string $slug, string $path, array $row, string $hash): bool
    {
        if (!in_array($path, car_publication_output_paths($slug), true) || ($row['outputPath'] ?? '') !== $path
            || ($row['entityType'] ?? '') !== 'car' || ($row['entityId'] ?? '') !== $slug
            || ($row['generator'] ?? '') !== CAR_PUBLICATION_RENDERER_VERSION || ($row['sourcePath'] ?? '') !== 'car-publication-plans.json'
            || ($row['outputHash'] ?? '') !== 'sha256:' . $hash
            || !preg_match('/\Asha256:([a-f0-9]{64})\z/D', $row['sourceHash'] ?? '', $m)) return false;
        $id = 'cpp_' . substr($m[1], 0, 32);
        $receipt = read_car_publication_plan_store()['items'][$id] ?? null;
        if (($receipt['id'] ?? null) !== $id || ($receipt['state'] ?? null) !== 'applied'
            || ($receipt['digest'] ?? null) !== $m[1] || ($receipt['immutable']['slug'] ?? null) !== $slug
            || car_publication_digest($receipt['immutable']) !== $m[1]) return false;
        foreach ($receipt['immutable']['outputs'] as $o) {
            if (($o['path'] ?? null) === $path && ($o['afterHash'] ?? null) === $hash) return true;
        }
        return false;
    }

    public static function transferredOwner(string $path, array $row, string $hash): bool
    {
        if (!self::enabled()) return false;
        $transfer = self::store()['handoffs'][$path] ?? null;
        return is_array($transfer) && self::optionProof($transfer['slug'], $path, $row, $hash);
    }

    public static function handoffPreview(string $slug): array
    {
        if (!self::enabled()) return [];
        require_once __DIR__ . '/approved-public-car-snapshot.php';
        ApprovedPhpPlanApply::assertGlobalAccess();
        if (!ApprovedPublicCarSnapshots::canApprove($slug)) throw new RuntimeException('BLOCKED_PHP_AUTOMATION_SCOPE', 403);
        $state = ApprovedPhpPlanApply::state();
        $s = self::store();
        $result = [];
        foreach (car_publication_output_paths($slug) as $path) {
            // Sitemap authority is shared and cannot be transferred by a car page action.
            if ($path === 'sitemap.xml' || isset($s['handoffs'][$path])) continue;
            $row = $state['outputs'][$path] ?? [];
            $before = RentalReturnStore::publicationOutputBytes($path);
            if ($before === null || !self::optionProof($slug, $path, $row, hash('sha256', $before))) continue;
            $result[$path] = car_publication_digest(['path' => $path, 'row' => $row, 'actor' => car_publication_actor_binding()]);
        }
        return $result;
    }

    public static function handoff(string $slug, array $selected, bool $confirmed): void
    {
        if (!$confirmed || !$selected) throw new RuntimeException('BLOCKED_PHP_HANDOFF_CONFIRMATION', 403);
        RentalReturnStore::transaction(static function () use ($slug, $selected): void {
            $current = self::handoffPreview($slug);
            foreach ($selected as $path => $token) {
                if (!is_string($token) || !isset($current[$path]) || !hash_equals($current[$path], $token)) {
                    throw new RuntimeException('BLOCKED_PHP_HANDOFF_STALE_OR_FOREIGN', 409);
                }
            }
            $state = ApprovedPhpPlanApply::state();
            $s = self::store();
            foreach ($selected as $path => $_) {
                $prior = $state['outputs'][$path];
                [$type, $id] = ApprovedPhpPlanApply::entity($path);
                $s['handoffs'][$path] = ['slug' => $slug, 'before' => $prior, 'by' => car_publication_actor_binding(), 'at' => now_iso()];
                $state['outputs'][$path] = array_replace($prior, ['entityType' => $type, 'entityId' => $id,
                    'generator' => ApprovedPhpPlanApply::GENERATOR]);
            }
            self::save($s);
            if (!RentalReturnStore::stage(BUILD_STATE_FILE, $state)) throw new LogicException('Handoff requires staged state');
            audit_log('site.php_automation.handoff', 'car', $slug, 'Explicit Option C handoff',
                ['paths' => array_keys($selected), 'priorGenerator' => CAR_PUBLICATION_RENDERER_VERSION, 'newGenerator' => ApprovedPhpPlanApply::GENERATOR]);
        });
    }

    private static function authorized(array $event): bool
    {
        $user = find_admin_user($event['actor']);
        if (!$user || empty($user['active']) || !lessor_user_is_allowed($user)) return false;
        if ($event['kind'] === 'rates') return admin_user_can_edit_tariffs_for_scope($user, $event['scope']);
        $root = admin_user_is_platform_root($user);
        if (!$root && admin_user_scope_id($user) !== $event['scope']) return false;
        if (!admin_user_has_permission_key($user, 'cars.edit')) return false;
        if (in_array($event['kind'], ['publish', 'hide', 'delete', 'revoke'], true)) {
            return $root && admin_user_has_permission_key($user, 'cars.publish');
        }
        return in_array($event['kind'], ['photos', 'archive'], true);
    }

    public static function assertJob(array $job, array $s): void
    {
        $h = $s['cars'][$job['slug']] ?? [];
        if (!RentalReturnStore::active() || ($h['job'] ?? null) !== $job['id'] || ($h['generation'] ?? null) !== $job['generation']
            || ($s['jobs'][$job['id']] ?? null) !== $job || !in_array($job['status'], ['pending', 'retry'], true)
            || !self::authorized($job)) throw new RuntimeException('BLOCKED_PHP_AUTOMATION_AUTHORITY', 403);
        $published = $h['published'] ?? [];
        foreach ($job['desired'] as $kind => $event) {
            if (($published['approvalId'] ?? null) === $job['approvalId'] && ($published['desired'][$kind] ?? null) === $event) continue;
            if (!self::authorized($event)) throw new RuntimeException('BLOCKED_PHP_AUTOMATION_AUTHORITY', 403);
        }
    }

    public static function once(): array
    {
        if (!self::enabled()) throw new RuntimeException('BLOCKED_PHP_AUTOMATION_DISABLED', 403);
        require_once __DIR__ . '/approved-public-car-snapshot.php';
        $chosen = null;
        try {
            return RentalReturnStore::transaction(static function () use (&$chosen): array {
                if (PhpPublicationCutover::selected()) {
                    try { PhpPublicationCutover::assertApply(); }
                    catch (RuntimeException $e) {
                        if ($e->getMessage() === 'BLOCKED_PHP_CUTOVER_PAUSED') return ['status' => 'PAUSED'];
                        throw $e;
                    }
                }
                $s = self::store();
                foreach ($s['jobs'] as $job) {
                    if (!in_array($job['status'], ['pending', 'retry'], true) || ($job['retryAt'] ?? 0) > time()) continue;
                    $chosen = $job;
                    self::assertJob($job, $s);
                    $result = ApprovedPublicCarSnapshots::fromServer()->applyAutomationJob($job);
                    $s['jobs'][$job['id']]['status'] = 'published';
                    $s['jobs'][$job['id']]['attempts'][] = ['at' => now_iso(), 'result' => $result];
                    $s['cars'][$job['slug']]['published'] = ['approvalId' => $job['approvalId'], 'desired' => $job['desired']];
                    if ($job['kind'] === 'publish') $s['cars'][$job['slug']]['withdrawn'] = false;
                    self::save($s);
                    return ['status' => 'PUBLISHED', 'job' => $job['id'], 'result' => $result];
                }
                return ['status' => 'IDLE'];
            });
        } catch (Throwable $e) {
            if ($chosen === null) throw $e;
            return RentalReturnStore::transaction(static function () use ($e, $chosen): array {
                $s = self::store();
                $current = $s['jobs'][$chosen['id']] ?? [];
                if (($current['status'] ?? '') === 'published') return ['status' => 'ALREADY_PUBLISHED', 'job' => $chosen['id']];
                if ($current !== $chosen) return ['status' => 'SUPERSEDED'];
                $reason = preg_match('/\ABLOCKED_[A-Z0-9_]+\z/D', $e->getMessage()) ? $e->getMessage() : 'PUBLICATION_OPERATION_FAILED';
                // Explicit trust and integrity denials stay terminal even if their HTTP code is 503.
                $temporary = $e instanceof RuntimeException && $e->getCode() === 503 && $reason === 'PUBLICATION_OPERATION_FAILED';
                $status = $temporary ? 'retry' : 'blocked';
                $s['jobs'][$chosen['id']]['status'] = $status;
                unset($s['jobs'][$chosen['id']]['retryAt']);
                if ($temporary) {
                    $reason = 'PUBLICATION_TEMPORARY_UNAVAILABLE';
                    $delay = min(300, 5 * (2 ** min(6, count($chosen['attempts']))));
                    $s['jobs'][$chosen['id']]['retryAt'] = time() + $delay;
                }
                $s['jobs'][$chosen['id']]['attempts'][] = ['at' => now_iso(), 'reason' => $reason, 'status' => $status];
                self::save($s);
                return ['status' => strtoupper($status), 'job' => $chosen['id'], 'reason' => $reason];
            });
        }
    }
}
