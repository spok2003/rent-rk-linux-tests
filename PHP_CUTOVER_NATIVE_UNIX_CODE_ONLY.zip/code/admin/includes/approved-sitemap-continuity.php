<?php
declare(strict_types=1);

/** Evidence only: no public writes or alternate publication path. */
final class ApprovedSitemapContinuity
{
    private static function fail(string $reason): never
    {
        throw new RuntimeException('BLOCKED_SITEMAP_CONTINUITY_' . $reason, 409);
    }

    private static function digest(array $value): string
    {
        return hash('sha256', RentRkPublicRenderer::canonical($value));
    }

    public static function signingBytes(array $value): string
    {
        return "RentRK native sitemap transition v1\0" . RentRkPublicRenderer::canonical($value);
    }

    private static function urls(string $bytes): array
    {
        $doc = new DOMDocument();
        $previous = libxml_use_internal_errors(true);
        try { $valid = $doc->loadXML($bytes, LIBXML_NONET); }
        finally { libxml_clear_errors(); libxml_use_internal_errors($previous); }
        if (!$valid || $doc->doctype !== null || $doc->documentElement?->localName !== 'urlset') self::fail('INVALID_XML');
        $urls = [];
        foreach ($doc->documentElement->childNodes as $entry) {
            if (!$entry instanceof DOMElement) continue;
            $loc = $entry->getElementsByTagName('loc');
            if ($entry->localName !== 'url' || $loc->length !== 1 || $loc->item(0)?->parentNode !== $entry) self::fail('INVALID_XML');
            $url = $loc->item(0)->textContent;
            if ($url === '' || isset($urls[$url])) self::fail('INVALID_URL_SET');
            $urls[$url] = true;
        }
        $list = array_keys($urls);
        sort($list, SORT_STRING);
        return $list;
    }

    private static function staticDigest(array $urls): string
    {
        return self::digest(array_values(array_filter($urls, static fn(string $url): bool => !preg_match(
            '~\Ahttps://(?:base-rent\.ru/partner/[a-z0-9-]+/|rent-rk\.ru/landing\.php\?slug=[a-z0-9]+(?:-[a-z0-9]+)*)\z~D', $url))));
    }

    private static function validateDelta(array $event): void
    {
        $allowed = $event['targets'] ?? null;
        $added = $event['added'] ?? null;
        $removed = $event['removed'] ?? null;
        if (!is_array($allowed) || !array_is_list($allowed) || !is_array($added) || !array_is_list($added)
            || !is_array($removed) || !array_is_list($removed)) self::fail('SCOPE');
        if (($event['writer'] ?? null) === 'php_plan') {
            $action = $event['action'] ?? null;
            if (!in_array($action, ['apply', 'publish', 'withdraw'], true) || !is_string($event['reference'] ?? null)
                || !preg_match('/\A[a-f0-9]{64}\z/D', $event['reference']) || $allowed === []
                || array_filter($allowed, static fn($url): bool => !is_string($url) || $url === '')
                || count(array_unique($allowed)) !== count($allowed) || array_diff($added, $allowed)
                || self::staticDigest($allowed) !== ($event['after']['staticUrlsSha256'] ?? null)) {
                self::fail('SCOPE');
            }
            $old = $allowed;
            if ($action !== 'apply') {
                $url = $event['targetCarUrl'] ?? null;
                if (!is_string($url) || !preg_match('~\Ahttps://base-rent\.ru/cars/[a-z0-9]+(?:-[a-z0-9]+)*\.html\z~D', $url)
                    || ($action === 'withdraw' && (in_array($url, $allowed, true) || $added !== [] || !in_array($removed, [[], [$url]], true)))
                    || ($action === 'publish' && (!in_array($url, $allowed, true)
                        || (($event['before']['beforeSha256'] ?? null) !== null && !in_array($added, [[], [$url]], true))))) self::fail('SCOPE');
                if ($action === 'withdraw' && $removed === [$url]) $old[] = $url;
                if ($action === 'publish' && $added === [$url]) $old = array_values(array_diff($old, [$url]));
            }
            sort($old, SORT_STRING);
            if (($action !== 'withdraw' && $removed !== [])
                || self::staticDigest($old) !== ($event['before']['staticUrlsSha256'] ?? null)) self::fail('SCOPE');
            return;
        }
        if (($event['writer'] ?? null) === 'option_c') {
            if (($event['action'] ?? null) !== 'apply' || !is_string($event['slug'] ?? null)
                || !preg_match('/\A[a-z0-9]+(?:-[a-z0-9]+)*\z/D', $event['slug'])
                || $allowed !== [rtrim(RENT_RK_PUBLIC_BASE_URL, '/') . '/cars/' . $event['slug'] . '.html']
                || $added !== $allowed || $removed !== []) self::fail('SCOPE');
            return;
        }
        if (($event['writer'] ?? null) !== 'demand' || !is_string($event['action'] ?? null)
            || !demand_publication_changes_sitemap($event['action']) || count($allowed) < 1 || count($allowed) > 2) self::fail('SCOPE');
        foreach ($allowed as $url) {
            if (!is_string($url) || !preg_match('~\Ahttps://rent-rk\.ru/landing\.php\?slug=[a-z0-9]+(?:-[a-z0-9]+)*\z~D', $url)) self::fail('SCOPE');
        }
        if (!is_string($event['oldUrl'] ?? null) || !is_string($event['finalUrl'] ?? null) || !is_bool($event['indexed'] ?? null)
            || $allowed !== array_values(array_unique([$event['oldUrl'], $event['finalUrl']]))
            || ($added !== [] && (!$event['indexed'] || $added !== [$event['finalUrl']]))
            || ($removed !== [] && $removed !== [$event['oldUrl']])
            || ($added !== [] && !in_array($event['action'], ['workflow_publish_indexed', 'wizard_open_search', 'workflow_rollback'], true))) self::fail('SCOPE');
    }

    private static function chain(array $store, array $origin, array $context): array
    {
        $before = $origin;
        $head = null;
        $lastTime = 0;
        $history = $store['sitemapContinuity'] ?? null;
        if (array_key_exists('sitemapContinuity', $store) && (!is_array($history) || !array_is_list($history) || $history === [])) self::fail('HISTORY');
        $history ??= [];
        foreach ($history as $signed) {
            $p = $signed['payload'] ?? null;
            $key = $p['keyId'] ?? null;
            $signature = is_string($signed['signature'] ?? null) ? base64_decode($signed['signature'], true) : false;
            if (!is_array($p) || !is_string($key) || !is_string($signature) || strlen($signature) !== SODIUM_CRYPTO_SIGN_BYTES
                || ($p['schemaVersion'] ?? null) !== 1 || ($p['issuer'] ?? null) !== $context['issuer']
                || !array_key_exists('previousSha256', $p) || $p['previousSha256'] !== $head
                || ($p['before'] ?? null) !== $before || !is_int($p['issuedAt'] ?? null)
                || $p['issuedAt'] < max(1, $lastTime) || $p['issuedAt'] > time()
                || !is_array($p['after'] ?? null) || !is_string($p['after']['beforeSha256'] ?? null)
                || !is_string($p['after']['staticUrlsSha256'] ?? null)) self::fail('HISTORY');
            if (in_array($key, $context['revokedKeyIds'] ?? [], true)) self::fail('KEY_REVOKED');
            $retired = $context['retiredKeys'][$key] ?? null;
            $public = $key === $context['keyId'] ? $context['publicKeyBase64'] : ($retired['publicKeyBase64'] ?? null);
            if ($public === null || ($retired !== null && $p['issuedAt'] > $retired['retiredAt'])
                || !sodium_crypto_sign_verify_detached($signature, self::signingBytes($p), base64_decode($public, true))) self::fail('SIGNATURE');
            self::validateDelta($p);
            if ($p['writer'] === 'demand' && $p['before']['staticUrlsSha256'] !== $p['after']['staticUrlsSha256']) self::fail('SCOPE');
            $before = $p['after'];
            $head = self::digest($signed);
            $lastTime = $p['issuedAt'];
        }
        foreach (read_audit_log()['items'] ?? [] as $audit) {
            if (($audit['action'] ?? '') !== 'public_inventory.sitemap_transition') continue;
            if ($head === null || ($audit['meta']['transitionSha256'] ?? null) !== $head) self::fail('AUDIT_HEAD');
            break;
        }
        return ['baseline' => $before, 'sha256' => $head];
    }

    public static function observe(array $store, array $origin, array $context): array
    {
        return self::chain($store, $origin, $context);
    }

    public static function currentUrls(array $store, array $origin, array $context): array
    {
        $head = self::chain($store, $origin, $context)['baseline'];
        $bytes = RentalReturnStore::publicationOutputBytes('sitemap.xml');
        if ($bytes === null && $head['beforeSha256'] === null) return [];
        if ($bytes === null || !hash_equals((string) $head['beforeSha256'], hash('sha256', $bytes))) self::fail('UNTRUSTED_BEFORE');
        $urls = self::urls($bytes);
        if (self::staticDigest($urls) !== $head['staticUrlsSha256']) self::fail('UNTRUSTED_BEFORE');
        return $urls;
    }

    public static function record(array $store, array $origin, array $context, ?string $before, string $after, array $operation): void
    {
        if (!RentalReturnStore::active() || RentalReturnStore::publicationOutputBytes('sitemap.xml') !== $after) self::fail('NOT_STAGED');
        if ($before === $after) return;
        $chain = self::chain($store, $origin, $context);
        $head = $chain['baseline'];
        $phpPlan = ($operation['writer'] ?? null) === 'php_plan';
        if ($before === null ? (!$phpPlan || $head['beforeSha256'] !== null)
            : !hash_equals((string) $head['beforeSha256'], hash('sha256', $before))) self::fail('UNTRUSTED_BEFORE');
        $old = $before === null ? [] : self::urls($before);
        $next = self::urls($after);
        if ($before !== null && self::staticDigest($old) !== $head['staticUrlsSha256']) self::fail('UNTRUSTED_BEFORE');
        if ($phpPlan && ($operation['targets'] ?? null) !== $next) self::fail('SCOPE');
        $payload = ['schemaVersion' => 1, 'issuer' => $context['issuer'], 'keyId' => $context['keyId'], 'issuedAt' => time(),
            'previousSha256' => $chain['sha256'], 'before' => $head,
            'after' => ['beforeSha256' => hash('sha256', $after), 'staticUrlsSha256' => self::staticDigest($next)],
            'added' => array_values(array_diff($next, $old)), 'removed' => array_values(array_diff($old, $next))] + $operation;
        self::validateDelta($payload);
        if ($payload['writer'] === 'demand') {
            if ($payload['after']['staticUrlsSha256'] !== $head['staticUrlsSha256']
                || in_array($operation['finalUrl'], $next, true) !== $operation['indexed']) self::fail('SCOPE');
        }
        $secret = base64_decode($context['secretKeyBase64'], true);
        try { $signature = sodium_crypto_sign_detached(self::signingBytes($payload), $secret); }
        finally { sodium_memzero($secret); }
        $signed = ['payload' => $payload, 'signature' => base64_encode($signature)];
        $store['sitemapContinuity'][] = $signed;
        if (!RentalReturnStore::stage(ApprovedPublicCarSnapshots::path(), $store)) self::fail('NOT_STAGED');
        audit_log('public_inventory.sitemap_transition', 'sitemap', 'global', 'Подтверждено штатное изменение карты сайта',
            ['transitionSha256' => self::digest($signed), 'writer' => $operation['writer'], 'action' => $operation['action']]);
    }
}
