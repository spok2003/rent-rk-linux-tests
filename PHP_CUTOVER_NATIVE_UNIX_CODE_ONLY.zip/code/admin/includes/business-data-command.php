<?php
declare(strict_types=1);

function business_command_id(mixed $value): string
{
    if (!is_string($value) || !preg_match('/^[A-Za-z0-9_-]{24,100}$/D', $value)) {
        throw new InvalidArgumentException('Не указан идентификатор операции. Обновите форму перед новой операцией.');
    }
    return $value;
}

function business_command_form_id(): string
{
    $posted = $_POST['command_id'] ?? null;
    return is_string($posted) && preg_match('/^[A-Za-z0-9_-]{24,100}$/D', $posted)
        ? $posted : bin2hex(random_bytes(16));
}

function business_command_canonical(mixed $value): mixed
{
    if (is_array($value)) {
        if (!array_is_list($value)) ksort($value, SORT_STRING);
        foreach ($value as $key => $item) $value[$key] = business_command_canonical($item);
    } elseif (is_object($value) || is_resource($value) || is_float($value) && !is_finite($value)) {
        throw new InvalidArgumentException('Некорректные данные операции.');
    }
    return $value;
}

// Receipts live in the owning store and commit with the effects, never in a rolling log.
function business_command(string $store, string $kind, string $id, array $intent, callable $authorize, callable $work): array
{
    $id = business_command_id($id);
    if (!in_array($store, business_command_stores(), true)) {
        throw new LogicException('Unsupported command store.');
    }
    if (!RentalReturnStore::active()) {
        return RentalReturnStore::transaction(static fn(): array => business_command($store, $kind, $id, $intent, $authorize, $work));
    }
    if (!is_admin_logged_in()) deny_scope_access();
    $authorize();
    $fingerprint = hash('sha256', json_encode(business_command_canonical([
        'kind'=>$kind, 'actor'=>current_admin_user(), 'intent'=>$intent,
    ]), JSON_THROW_ON_ERROR | JSON_PRESERVE_ZERO_FRACTION));
    $data = read_json_file($store, ['items'=>[]]);
    $receipts = array_key_exists('commandReceipts', $data) ? $data['commandReceipts'] : [];
    if (!is_array($receipts)) throw new RuntimeException('Повреждён журнал операций. Запись остановлена.', 503);
    $key = $kind . ':' . $id;
    if (array_key_exists($key, $receipts)) {
        $receipt = $receipts[$key];
        if (!is_array($receipt) || !is_string($receipt['fingerprint'] ?? null) || !is_array($receipt['result'] ?? null)) {
            throw new RuntimeException('Повреждена запись результата операции.', 503);
        }
        if (!hash_equals($receipt['fingerprint'], $fingerprint)) throw new RuntimeException('Идентификатор уже использован для другой операции. Откройте новую форму.', 409);
        return $receipt['result'];
    }
    $result = $work();
    if (!is_array($result)) throw new LogicException('Command result must be an array.');
    $data = read_json_file($store, ['items'=>[]]);
    $data['commandReceipts'][$key] = ['fingerprint'=>$fingerprint, 'result'=>$result, 'committedAt'=>now_iso()];
    write_json_file($store, $data);
    return $result;
}

function business_command_stores(): array
{
    return [
        SCOPE_BALANCES_FILE,
        SCOPE_BILLING_LOG_FILE,
        SERVICE_LOG_FILE,
        SERVICE_HOLDS_FILE,
        TASKS_FILE,
        FINE_CHECK_JOBS_FILE,
        FINES_FILE,
        REQUESTS_FILE,
        RENTALS_FILE,
        BACKUP_IMPORT_COMMANDS_FILE,
        DEMAND_KEYWORDS_FILE,
        DEMAND_RECOMMENDATIONS_FILE,
        LANDING_PAGE_DRAFTS_FILE,
        SEO_LAUNCH_PLAN_FILE,
        DEMAND_CONTENT_BRIEFS_FILE,
        DEMAND_CARD_OPTIMIZATION_HINTS_FILE,
        DEMAND_INTEGRATIONS_SETTINGS_FILE,
        DEMAND_SYNC_RUNS_FILE,
        DEMAND_EXTERNAL_METRICS_FILE,
        DEMAND_INTEGRATION_ERRORS_FILE,
        DEMAND_PERFORMANCE_SNAPSHOTS_FILE,
        WORDSTAT_REGIONS_CACHE_FILE,
        WORDSTAT_QUERY_QUEUE_FILE,
        WORDSTAT_COST_LEDGER_FILE,
        DEMAND_AI_SETTINGS_FILE,
    ];
}

// Public leads have no admin identity. Keep their receipt namespace and store fixed.
function public_request_command(string $kind, mixed $id, array $intent, callable $work): array
{
    if (!in_array($kind, ['request', 'callback'], true)) throw new LogicException('Unsupported public lead command.');
    $id = business_command_id($id);
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => public_request_command($kind, $id, $intent, $work));
    $key = 'public-' . $kind . ':' . $id;
    $fingerprint = hash('sha256', json_encode(business_command_canonical($intent), JSON_THROW_ON_ERROR));
    $data = read_json_file(REQUESTS_FILE, default_requests());
    $receipts = $data['commandReceipts'] ?? [];
    if (!is_array($receipts)) throw new RuntimeException('Повреждён журнал заявок.', 503);
    if (array_key_exists($key, $receipts)) {
        $receipt = $receipts[$key];
        if (!is_array($receipt) || !is_string($receipt['fingerprint'] ?? null) || !is_string($receipt['result']['id'] ?? null)) throw new RuntimeException('Повреждён результат заявки.', 503);
        if (!hash_equals($receipt['fingerprint'], $fingerprint)) throw new RuntimeException('Эта форма уже отправлена с другими данными. Откройте новую форму.', 409);
        return ['request' => ['id' => $receipt['result']['id']], 'replayed' => true];
    }
    $request = $work();
    if (!is_array($request) || !is_string($request['id'] ?? null)) throw new LogicException('Missing public lead result.');
    $data = read_json_file(REQUESTS_FILE, default_requests());
    $data['commandReceipts'][$key] = ['fingerprint' => $fingerprint, 'result' => ['id' => $request['id']], 'committedAt' => now_iso()];
    write_json_file(REQUESTS_FILE, $data);
    return ['request' => $request, 'replayed' => false];
}

function business_command_guard_receipts(string $path, array $incoming): void
{
    if (!in_array($path, business_command_stores(), true)) return;
    $current = RentalReturnStore::read($path, []);
    foreach ([$current, $incoming] as $data) {
        if (array_key_exists('commandReceipts', $data) && !is_array($data['commandReceipts'])) {
            throw new RuntimeException('Повреждён журнал результатов операций. Запись остановлена.', 503);
        }
    }
    foreach ($current['commandReceipts'] ?? [] as $id => $receipt) {
        if (!array_key_exists($id, $incoming['commandReceipts'] ?? []) || $receipt !== $incoming['commandReceipts'][$id]) {
            throw new RuntimeException('Нельзя удалить или заменить подтверждение выполненной операции старым снимком.', 409);
        }
    }
}
