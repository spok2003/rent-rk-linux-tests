<?php
declare(strict_types=1);

/** Approved category silhouettes. UI/navigation icons remain in admin_icon(). */
function admin_asset_icon_registry(): array
{
    static $registry = null;
    if (is_array($registry)) {
        return $registry;
    }
    $registry = [];
    $file = dirname(__DIR__) . '/assets/icons/asset-manifest.json';
    $manifest = is_file($file) ? json_decode((string) file_get_contents($file), true) : [];
    foreach (($manifest['items'] ?? []) as $item) {
        $id = (string) ($item['id'] ?? '');
        $symbol = (string) ($item['symbol'] ?? '');
        if (preg_match('/^[a-z0-9-]+$/D', $id) && $symbol === 'asset-' . $id) {
            $registry[$id] = $symbol;
        }
    }
    return $registry;
}

/** Use a visible type label at 32px or larger; compact vehicle slots use car-any. */
function admin_asset_icon(string $name, string $class = '', ?string $label = null): string
{
    $registry = admin_asset_icon_registry();
    $classes = trim('rr-asset-icon ' . $class);
    if (!isset($registry[$name])) {
        return '<span class="' . e(trim($classes . ' rr-icon--missing')) . '" aria-hidden="true"></span>';
    }
    $href = admin_asset_url('assets/icons/rent-rk-asset-icons-sprite.svg') . '#' . $registry[$name];
    $a11y = $label === null
        ? ' aria-hidden="true" focusable="false"'
        : ' role="img" aria-label="' . e($label) . '" focusable="false"';
    return '<svg class="' . e($classes) . '"' . $a11y . '><use href="' . e($href) . '"></use></svg>';
}
