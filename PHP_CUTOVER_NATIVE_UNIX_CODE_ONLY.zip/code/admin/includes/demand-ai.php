<?php

declare(strict_types=1);

function demand_ai_get_allowed_tasks(): array
{
    return [
        'draft' => [
            'improve_landing_draft',
            'create_faq',
            'create_title_description',
            'check_false_promises',
            'compare_with_demand',
            'suggest_internal_links',
            'regenerate_internal_links',
            'apply_internal_link_suggestions',
            'regenerate_landing_draft_human',
            'regenerate_landing_intro',
            'regenerate_content_blocks',
            'regenerate_single_content_block',
            'regenerate_faq',
            'rewrite_block_human',
            'reduce_seo_overoptimization',
            'make_copy_more_human',
            'generate_alternative_variant',
            'evaluate_copy_human_quality',
            'regenerate_preview_block_human',
            'rewrite_preview_block_shorter',
            'reduce_preview_block_seo_overuse',
            'regenerate_preview_faq',
            'suggest_preview_internal_links',
        ],
        'content_brief' => [
            'improve_content_brief',
            'create_faq',
            'create_page_outline',
        ],
        'launch_plan_item' => [
            'create_page_outline',
            'compare_with_demand',
        ],
        'demand_cluster' => [
            'compare_with_demand',
            'create_page_outline',
        ],
        'car_hint' => [
            'improve_car_hint',
            'check_false_promises',
            'generate_car_hint_text',
            'generate_car_description_suggestion',
        ],
    ];
}

function demand_ai_task_label(string $task): string
{
    return [
        'improve_landing_draft' => 'Улучшение черновика страницы',
        'create_faq' => 'FAQ',
        'create_title_description' => 'Title и description',
        'check_false_promises' => 'Проверка рисков и ложных обещаний',
        'compare_with_demand' => 'Сравнение с реальным спросом',
        'suggest_internal_links' => 'Подобрать внутренние ссылки',
        'regenerate_internal_links' => 'Подобрать другие внутренние ссылки',
        'apply_internal_link_suggestions' => 'Добавить выбранные внутренние ссылки',
        'improve_content_brief' => 'Уточнение ТЗ для страницы',
        'create_page_outline' => 'Структура будущей страницы',
        'improve_car_hint' => 'Текст подсказки для авто',
        'generate_car_hint_text' => 'Сформировать текст подсказки',
        'generate_car_description_suggestion' => 'Сформировать текст описания',
        'regenerate_landing_draft_human' => 'Живой вариант страницы',
        'regenerate_landing_intro' => 'Перегенерация intro',
        'regenerate_content_blocks' => 'Перегенерация блоков',
        'regenerate_single_content_block' => 'Перегенерация одного блока',
        'regenerate_faq' => 'Перегенерация FAQ',
        'rewrite_block_human' => 'Переписать блок живее',
        'reduce_seo_overoptimization' => 'Убрать SEO-переспам',
        'make_copy_more_human' => 'Оживить текст',
        'generate_alternative_variant' => 'Еще один вариант',
        'evaluate_copy_human_quality' => 'Оценить живость текста',
        'regenerate_preview_block_human' => 'Оживить блок на preview',
        'rewrite_preview_block_shorter' => 'Сделать preview-блок короче',
        'reduce_preview_block_seo_overuse' => 'Убрать SEO-повторы в preview-блоке',
        'regenerate_preview_faq' => 'Перегенерировать FAQ на preview',
        'suggest_preview_internal_links' => 'Подобрать внутренние ссылки на preview',
    ][$task] ?? $task;
}

function demand_ai_human_copy_tasks(): array
{
    return [
        'regenerate_landing_draft_human',
        'regenerate_landing_intro',
        'regenerate_content_blocks',
        'regenerate_single_content_block',
        'regenerate_faq',
        'rewrite_block_human',
        'reduce_seo_overoptimization',
        'make_copy_more_human',
        'generate_alternative_variant',
        'evaluate_copy_human_quality',
        'regenerate_preview_block_human',
        'rewrite_preview_block_shorter',
        'reduce_preview_block_seo_overuse',
        'regenerate_preview_faq',
        'suggest_preview_internal_links',
    ];
}

function demand_ai_is_human_copy_task(string $task): bool
{
    return in_array($task, demand_ai_human_copy_tasks(), true);
}

function demand_ai_entity_label(string $entityType): string
{
    return [
        'draft' => 'Черновик страницы',
        'content_brief' => 'ТЗ для страницы',
        'launch_plan_item' => 'Пункт плана страниц',
        'demand_cluster' => 'Группа запросов',
        'car_hint' => 'Подсказка для авто',
    ][$entityType] ?? $entityType;
}

function demand_ai_task_allowed_for_entity(string $entityType, string $task): bool
{
    $allowed = demand_ai_get_allowed_tasks();

    return in_array($task, (array) ($allowed[$entityType] ?? []), true);
}

function demand_ai_safe_string($value, int $maxLength = 1000): string
{
    return demand_clean_string($value, $maxLength);
}

function demand_ai_safe_list($values, int $maxItems = 30, int $maxLength = 200): array
{
    $result = [];
    foreach ((array) $values as $value) {
        $clean = demand_ai_safe_string($value, $maxLength);
        if ($clean !== '') {
            $result[$clean] = $clean;
        }
        if (count($result) >= $maxItems) {
            break;
        }
    }

    return array_values($result);
}

function demand_ai_copy_style_options(): array
{
    return [
        'calm_human' => 'Живой и спокойный',
        'short_clear' => 'Короткий и понятный',
        'family_company' => 'Для семьи / компании',
        'trust_focus' => 'С акцентом на доверие',
        'soft_sales' => 'Более продающий, но без давления',
        'informational' => 'Информационный без рекламы',
        'scenario' => 'Сценарный: как человек будет пользоваться авто',
    ];
}

function demand_ai_copy_style_label(string $style): string
{
    $styles = demand_ai_copy_style_options();

    return $styles[$style] ?? $styles['calm_human'];
}

function demand_ai_copy_default_base_instruction(): string
{
    return 'Пиши живой, спокойный текст для обычного человека, который выбирает автомобиль в аренду. Не делай SEO-простыню. Не повторяй ключевые фразы механически. Объясняй пользу через реальные сценарии поездки: семья, багаж, город, аэропорт, маршрут, залог, документы. Не обещай того, чего нет в данных. Если условие не подтверждено — пиши, что его нужно уточнить перед бронированием.';
}

function demand_ai_copy_avoid_options(): array
{
    return [
        'seo_overuse' => 'SEO-переспам',
        'ad_cliches' => 'Рекламные штампы',
        'aggressive_cta' => 'Агрессивные призывы',
        'false_promises' => 'Ложные обещания',
        'no_deposit_without_proof' => 'Обещание “без залога” без подтверждения',
        'lowest_prices' => '“Самые низкие цены”',
        'always_available' => '“Машина всегда доступна”',
        'delivery_anytime_without_proof' => '“Подача в любое время” без подтверждения',
    ];
}

function demand_ai_copy_emphasis_options(): array
{
    return [
        'family' => 'Семья',
        'company' => 'Компания',
        'luggage' => 'Багаж',
        'seven_seats' => '7 мест',
        'crimea_trips' => 'Поездки по Крыму',
        'airport_delivery' => 'Аэропорт / подача',
        'deposit' => 'Залог',
        'budget' => 'Цена / бюджет',
        'documents' => 'Документы',
        'calm_terms' => 'Спокойное объяснение условий',
    ];
}

function demand_ai_copy_default_settings(): array
{
    return [
        'defaultStyle' => 'calm_human',
        'defaultBaseInstruction' => demand_ai_copy_default_base_instruction(),
        'avoidList' => array_keys(demand_ai_copy_avoid_options()),
        'defaultEmphasisList' => ['family', 'company', 'luggage', 'crimea_trips', 'deposit', 'documents', 'calm_terms'],
        'updatedAt' => null,
        'updatedBy' => 'system',
    ];
}

function demand_ai_normalize_copy_list($values, array $allowed, int $maxItems = 12): array
{
    $values = is_array($values) ? $values : [];
    $allowedMap = array_fill_keys(array_keys($allowed), true);
    $result = [];
    foreach ($values as $value) {
        $key = demand_ai_safe_string((string) $value, 80);
        if ($key !== '' && isset($allowedMap[$key])) {
            $result[$key] = $key;
        }
        if (count($result) >= $maxItems) {
            break;
        }
    }

    return array_values($result);
}

function demand_ai_copy_normalize_settings(array $settings): array
{
    $default = demand_ai_copy_default_settings();
    $style = demand_ai_safe_string($settings['defaultStyle'] ?? $settings['style'] ?? $default['defaultStyle'], 80);
    if (!isset(demand_ai_copy_style_options()[$style])) {
        $style = $default['defaultStyle'];
    }
    $baseInstruction = demand_ai_safe_string($settings['defaultBaseInstruction'] ?? $settings['baseInstruction'] ?? $default['defaultBaseInstruction'], 1800);
    if ($baseInstruction === '') {
        $baseInstruction = $default['defaultBaseInstruction'];
    }
    $avoid = demand_ai_normalize_copy_list($settings['avoidList'] ?? $settings['avoid'] ?? $default['avoidList'], demand_ai_copy_avoid_options());
    $emphasis = demand_ai_normalize_copy_list($settings['defaultEmphasisList'] ?? $settings['emphasis'] ?? $default['defaultEmphasisList'], demand_ai_copy_emphasis_options());

    return [
        'defaultStyle' => $style,
        'defaultBaseInstruction' => $baseInstruction,
        'avoidList' => $avoid,
        'defaultEmphasisList' => $emphasis,
        'updatedAt' => demand_ai_safe_string($settings['updatedAt'] ?? $default['updatedAt'], 40),
        'updatedBy' => demand_ai_safe_string($settings['updatedBy'] ?? $default['updatedBy'], 120),
    ];
}

function demand_ai_copy_settings(): array
{
    $default = demand_ai_copy_default_settings();
    $path = defined('DEMAND_AI_COPY_SETTINGS_FILE') ? DEMAND_AI_COPY_SETTINGS_FILE : '';
    if ($path === '' || !is_file($path)) {
        return $default;
    }

    return demand_ai_copy_normalize_settings(read_json_file($path, $default));
}

function demand_ai_save_copy_settings(array $payload): array
{
    require_permission('demand.ai_api.settings.manage');

    $next = demand_ai_copy_normalize_settings([
        'defaultStyle' => $payload['style'] ?? $payload['defaultStyle'] ?? 'calm_human',
        'defaultBaseInstruction' => $payload['baseInstruction'] ?? $payload['defaultBaseInstruction'] ?? '',
        'avoidList' => $payload['avoid'] ?? $payload['avoidList'] ?? [],
        'defaultEmphasisList' => $payload['emphasis'] ?? $payload['defaultEmphasisList'] ?? [],
        'updatedAt' => now_iso(),
        'updatedBy' => current_admin_user() ?: 'system',
    ]);
    write_json_file(DEMAND_AI_COPY_SETTINGS_FILE, $next);

    return $next;
}

function demand_ai_draft_copy_settings(array $draft): array
{
    $global = demand_ai_copy_settings();
    $draftSettings = is_array($draft['aiCopySettings'] ?? null) ? (array) $draft['aiCopySettings'] : [];

    return demand_ai_copy_normalize_settings([
        'defaultStyle' => $draftSettings['style'] ?? $global['defaultStyle'],
        'defaultBaseInstruction' => $draftSettings['baseInstruction'] ?? $global['defaultBaseInstruction'],
        'avoidList' => $draftSettings['avoid'] ?? $global['avoidList'],
        'defaultEmphasisList' => $draftSettings['emphasis'] ?? $global['defaultEmphasisList'],
        'updatedAt' => $draftSettings['updatedAt'] ?? $global['updatedAt'],
        'updatedBy' => $draftSettings['updatedBy'] ?? $global['updatedBy'],
    ]);
}

function demand_ai_save_draft_copy_settings(string $draftId, array $payload, string $scopeFilter = ''): array
{
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.drafts.edit');
    $scope = demand_normalize_scope_id($scopeFilter);
    $draftScope = demand_normalize_scope_id((string) ($draft['scope_id'] ?? 'rent_rk'));
    if ($scope !== '' && $scope !== 'all' && $scope !== $draftScope) {
        deny_scope_access();
    }
    $settings = demand_ai_copy_normalize_settings([
        'defaultStyle' => $payload['style'] ?? 'calm_human',
        'defaultBaseInstruction' => $payload['baseInstruction'] ?? '',
        'avoidList' => $payload['avoid'] ?? [],
        'defaultEmphasisList' => $payload['emphasis'] ?? [],
        'updatedAt' => now_iso(),
        'updatedBy' => current_admin_user() ?: 'system',
    ]);

    $data = read_landing_page_drafts();
    foreach ($data['items'] as $index => $item) {
        if (!is_array($item) || (string) ($item['id'] ?? '') !== $draftId) {
            continue;
        }
        $data['items'][$index]['aiCopySettings'] = [
            'style' => $settings['defaultStyle'],
            'baseInstruction' => $settings['defaultBaseInstruction'],
            'avoid' => $settings['avoidList'],
            'emphasis' => $settings['defaultEmphasisList'],
            'updatedAt' => $settings['updatedAt'],
            'updatedBy' => $settings['updatedBy'],
        ];
        $data['items'][$index]['updatedAt'] = now_iso();
        save_landing_page_drafts($data);
        demand_ai_record_event('draft', $draftId, 'ai_copy_settings_saved', 'AI copy settings saved for draft. Publication and indexing were not changed.', [
            'settingsHash' => demand_ai_hash($data['items'][$index]['aiCopySettings']),
        ]);

        return $data['items'][$index];
    }

    throw new RuntimeException('Черновик не найден.');
}

function demand_ai_copy_default_options(): array
{
    $settings = demand_ai_copy_settings();

    return [
        'style' => (string) ($settings['defaultStyle'] ?? 'calm_human'),
        'baseInstruction' => (string) ($settings['defaultBaseInstruction'] ?? demand_ai_copy_default_base_instruction()),
        'avoid' => (array) ($settings['avoidList'] ?? array_keys(demand_ai_copy_avoid_options())),
        'emphasis' => (array) ($settings['defaultEmphasisList'] ?? []),
        'oneTimeInstruction' => '',
        'preserveSeoMeaning' => true,
        'reduceKeywordRepeats' => true,
        'preserveFacts' => true,
        'noUnconfirmedPromises' => true,
        'targetBlockIndex' => null,
        'regenerateAgain' => false,
        'previousVariantHash' => '',
    ];
}

function demand_ai_normalize_copy_options(array $options): array
{
    $defaults = demand_ai_copy_default_options();
    $style = demand_ai_safe_string($options['style'] ?? $defaults['style'], 80);
    if (!isset(demand_ai_copy_style_options()[$style])) {
        $style = $defaults['style'];
    }
    $targetBlockIndex = null;
    if (array_key_exists('targetBlockIndex', $options) && $options['targetBlockIndex'] !== '' && $options['targetBlockIndex'] !== null) {
        $targetBlockIndex = max(0, (int) $options['targetBlockIndex']);
    }
    $baseInstruction = demand_ai_safe_string($options['baseInstruction'] ?? $defaults['baseInstruction'], 1800);
    if ($baseInstruction === '') {
        $baseInstruction = (string) $defaults['baseInstruction'];
    }

    return [
        'style' => $style,
        'baseInstruction' => $baseInstruction,
        'avoid' => demand_ai_normalize_copy_list($options['avoid'] ?? $defaults['avoid'], demand_ai_copy_avoid_options()),
        'emphasis' => demand_ai_normalize_copy_list($options['emphasis'] ?? $defaults['emphasis'], demand_ai_copy_emphasis_options()),
        'oneTimeInstruction' => demand_ai_safe_string($options['oneTimeInstruction'] ?? '', 900),
        'preserveSeoMeaning' => array_key_exists('preserveSeoMeaning', $options) ? !empty($options['preserveSeoMeaning']) : $defaults['preserveSeoMeaning'],
        'reduceKeywordRepeats' => array_key_exists('reduceKeywordRepeats', $options) ? !empty($options['reduceKeywordRepeats']) : $defaults['reduceKeywordRepeats'],
        'preserveFacts' => array_key_exists('preserveFacts', $options) ? !empty($options['preserveFacts']) : $defaults['preserveFacts'],
        'noUnconfirmedPromises' => array_key_exists('noUnconfirmedPromises', $options) ? !empty($options['noUnconfirmedPromises']) : $defaults['noUnconfirmedPromises'],
        'targetBlockIndex' => $targetBlockIndex,
        'regenerateAgain' => !empty($options['regenerateAgain']),
        'previousVariantHash' => demand_ai_safe_string($options['previousVariantHash'] ?? '', 120),
    ];
}

function demand_ai_copy_quality_default(): array
{
    return [
        'clarity' => 'good',
        'humanTone' => 'good',
        'seoOveruse' => 'none',
        'promiseRisk' => 'none',
        'specificity' => 'good',
    ];
}

function demand_ai_normalize_copy_quality($quality): array
{
    $quality = is_array($quality) ? $quality : [];
    $result = demand_ai_copy_quality_default();
    $allowed = [
        'clarity' => ['good', 'needs_simpler'],
        'humanTone' => ['good', 'too_dry', 'too_salesy'],
        'seoOveruse' => ['none', 'possible', 'high'],
        'promiseRisk' => ['none', 'needs_check', 'high'],
        'specificity' => ['good', 'needs_more_facts'],
    ];
    foreach ($allowed as $field => $values) {
        $value = demand_ai_safe_string($quality[$field] ?? $result[$field], 40);
        $result[$field] = in_array($value, $values, true) ? $value : $result[$field];
    }

    return $result;
}

function demand_ai_copy_forbidden_cliches(): array
{
    return [
        'идеальный вариант',
        'лучшее решение',
        'широкий выбор',
        'доступные цены',
        'высокий уровень сервиса',
        'индивидуальный подход',
        'быстро и качественно',
        'максимальный комфорт',
        'самые выгодные условия',
        'машина всегда доступна',
        'без лишних хлопот',
        'оставьте заявку прямо сейчас',
        'самая низкая цена',
        'самые низкие цены',
    ];
}

function demand_ai_copy_generation_rules(): array
{
    return [
        'mode' => 'human_landing_copy_generation',
        'goal' => 'Писать для живого человека, который выбирает автомобиль для поездки, а не SEO-текст ради ключей.',
        'tone' => [
            'Спокойно, уверенно и без давления.',
            'Без канцелярита, штампов и механического повторения ключевых фраз.',
            'Каждый блок отвечает на реальный вопрос пользователя.',
            'SEO-смысл сохраняется, но ключи не повторяются в каждом абзаце.',
        ],
        'blockStructure' => [
            'Короткий понятный заголовок.',
            '2-4 живых предложения.',
            'Конкретная польза для поездки.',
            'Оговорка, если факт требует проверки.',
        ],
        'publicOnlyRules' => [
            'Пиши финальный текст для посетителя, а не редакторское задание.',
            'Не используй публично заголовки "Короткий прямой ответ", "Внутренние связи", "Что должна объяснить страница", "Рекомендуемые блоки", "content gap", "must answer" или "must not promise".',
            'Не пиши фразы "страница должна", "блок должен", "рекомендуется добавить", "перечислить", "показать только" или Stage A/B/C.',
            'Для contentBlocks ставь visibility=public только у текста для клиента; служебные подсказки оставляй admin_only.',
        ],
        'mustNotInvent' => [
            'цену',
            'залог',
            'наличие авто',
            'подачу',
            'детское кресло',
            '24/7',
            'отсутствие залога',
            'скидку',
            'самые низкие цены',
        ],
        'safeFallbacks' => [
            'условия уточняются перед бронированием',
            'точный залог зависит от автомобиля',
            'наличие и подача проверяются перед поездкой',
        ],
        'forbiddenCliches' => demand_ai_copy_forbidden_cliches(),
    ];
}

function demand_ai_region_policy(string $regionName, array $keyword = []): array
{
    $regionName = demand_ai_safe_string($regionName, 160);
    if ($regionName === '') {
        $regionName = demand_ai_safe_string($keyword['detectedCity'] ?? $keyword['detectedRegion'] ?? '', 160);
    }

    $canonical = function_exists('demand_canonical_service_region_name')
        ? demand_canonical_service_region_name($regionName)
        : $regionName;
    $status = function_exists('demand_service_region_status')
        ? demand_service_region_status($regionName)
        : ($canonical !== '' ? 'confirmed_service_region' : 'unknown_region');

    if ($canonical === '' && $regionName !== '') {
        $canonical = $regionName;
    }

    return [
        'originalRegion' => $regionName,
        'normalizedRegion' => demand_ai_safe_string($canonical, 160),
        'serviceRegionStatus' => $status,
        'isConfirmed' => $status === 'confirmed_service_region',
        'requiresBusinessDecision' => in_array($status, ['conditional_service_region', 'unknown_region'], true),
        'adminExplanation' => match ($status) {
            'confirmed_service_region' => 'Регион входит в подтверждённую зону Rent RK.',
            'conditional_service_region' => 'Регион может обслуживаться по условиям, но требует ручного подтверждения перед страницей.',
            'not_supported_region' => 'Регион не входит в рабочую зону Rent RK для этой SEO-логики.',
            default => 'Регион не подтверждён. Нужно решить, работаем ли мы с этим городом.',
        },
    ];
}

function demand_ai_effective_risk_flags(array $riskFlags, array $regionPolicy = []): array
{
    $riskFlags = demand_ai_safe_list($riskFlags, 40, 100);
    $status = (string) ($regionPolicy['serviceRegionStatus'] ?? '');

    if ($status === 'confirmed_service_region') {
        $riskFlags = array_values(array_diff($riskFlags, ['unknown_region', 'region_not_confirmed', 'needs_business_decision']));
    } elseif (in_array($status, ['unknown_region', 'conditional_service_region'], true)) {
        $riskFlags = demand_unique_strings(array_merge($riskFlags, ['unknown_region', 'region_not_confirmed', 'needs_business_decision']));
    } elseif ($status === 'not_supported_region') {
        $riskFlags = demand_unique_strings(array_merge($riskFlags, ['region_not_confirmed', 'not_supported_region', 'needs_business_decision']));
    }

    return demand_unique_strings($riskFlags);
}

function demand_ai_package_test_mode(array $source, array $facts): bool
{
    $sourceValues = [
        (string) ($source['entityId'] ?? ''),
        (string) ($source['entityType'] ?? ''),
        (string) ($source['scopeId'] ?? ''),
    ];

    foreach ((array) ($facts['demand']['keywords'] ?? []) as $keyword) {
        if (is_array($keyword)) {
            $sourceValues[] = (string) ($keyword['source'] ?? '');
            $sourceValues[] = (string) ($keyword['id'] ?? '');
        }
    }
    foreach (['launchPlanItem', 'demandCluster', 'contentBrief', 'currentDraft', 'carHint'] as $field) {
        if (is_array($facts[$field] ?? null)) {
            $sourceValues[] = (string) ($facts[$field]['id'] ?? '');
            $sourceValues[] = (string) ($facts[$field]['source'] ?? '');
        }
    }

    foreach ($sourceValues as $value) {
        if ($value !== '' && (str_contains($value, 'demand_ai_smoke') || str_contains($value, 'slp_ai_smoke'))) {
            return true;
        }
    }

    return false;
}

function demand_ai_available_car_slugs(array $facts): array
{
    $slugs = [];
    foreach ((array) ($facts['cars'] ?? []) as $car) {
        if (!is_array($car)) {
            continue;
        }
        $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
        if ($slug !== '') {
            $slugs[$slug] = true;
        }
    }

    return array_keys($slugs);
}

function demand_ai_filter_stage_c_car_hints(array $hints, array $allowedCarSlugs, array &$notesForAdmin): array
{
    $allowed = array_fill_keys(array_map('strval', $allowedCarSlugs), true);
    $filtered = [];
    foreach ($hints as $hint) {
        if (!is_array($hint)) {
            continue;
        }
        $slug = normalize_car_slug((string) ($hint['carSlug'] ?? ''));
        $name = demand_ai_safe_string($hint['carName'] ?? $slug, 160);
        if ($slug !== '' && isset($allowed[$slug])) {
            $filtered[] = $hint;
            continue;
        }
        $label = $name !== '' ? $name : ($slug !== '' ? $slug : 'авто без slug');
        $notesForAdmin[] = 'Кандидат из подсказок авто не передан в facts.cars: ' . $label . '. AI не должен писать, что этот автомобиль доступен; его можно только проверить вручную.';
    }

    return $filtered;
}

function demand_ai_filter_car_hints_recursive($value, array $allowedCarSlugs, array &$notesForAdmin)
{
    if (!is_array($value)) {
        return $value;
    }

    $result = [];
    foreach ($value as $key => $item) {
        if ($key === 'recommendedCarCardHints' && is_array($item)) {
            $result[$key] = demand_ai_filter_stage_c_car_hints($item, $allowedCarSlugs, $notesForAdmin);
            continue;
        }
        if ($key === 'notesForAdmin') {
            $result[$key] = $item;
            continue;
        }
        $result[$key] = demand_ai_filter_car_hints_recursive($item, $allowedCarSlugs, $notesForAdmin);
    }

    return $result;
}

function demand_ai_reconcile_car_hints_with_facts(array $facts): array
{
    $allowedCarSlugs = demand_ai_available_car_slugs($facts);
    $notesForAdmin = demand_ai_safe_list($facts['notesForAdmin'] ?? [], 30, 260);
    $facts = demand_ai_filter_car_hints_recursive($facts, $allowedCarSlugs, $notesForAdmin);

    $facts['notesForAdmin'] = demand_ai_safe_list($notesForAdmin, 40, 320);

    return $facts;
}

function demand_ai_detect_family_demand(array $facts): bool
{
    $haystack = [];
    $haystack[] = (string) ($facts['demand']['primaryPhrase'] ?? '');
    foreach ((array) ($facts['demand']['keywords'] ?? []) as $keyword) {
        if (!is_array($keyword)) {
            continue;
        }
        $haystack[] = (string) ($keyword['phrase'] ?? '');
        $haystack[] = (string) ($keyword['normalizedPhrase'] ?? '');
        $haystack[] = implode(' ', (array) ($keyword['secondaryIntents'] ?? []));
        $haystack[] = (string) ($keyword['intent'] ?? '');
        $haystack[] = implode(' ', (array) ($keyword['features']['tokens'] ?? []));
    }
    $normalized = demand_normalize_phrase(implode(' ', $haystack));

    return str_contains($normalized, 'family')
        || str_contains($normalized, 'family car')
        || str_contains($normalized, 'семей')
        || str_contains($normalized, 'для семьи')
        || str_contains($normalized, '7 мест')
        || str_contains($normalized, 'семимест')
        || str_contains($normalized, 'багаж')
        || str_contains($normalized, 'family_trip')
        || str_contains($normalized, 'luggage_and_seats');
}

function demand_ai_supply_fit_analysis(array $facts): array
{
    $cars = array_values(array_filter((array) ($facts['cars'] ?? []), 'is_array'));
    if (!$cars) {
        return [
            'status' => 'no_confirmed_fit',
            'summary' => 'В facts.cars нет подтверждённых автомобилей для этого спроса.',
            'familyScenario' => demand_ai_detect_family_demand($facts),
            'matchingCarSlugs' => [],
            'notes' => ['AI не должен писать, что автомобиль доступен, если его нет в facts.cars.'],
        ];
    }

    $family = demand_ai_detect_family_demand($facts);
    $strong = [];
    $partial = [];
    $weak = [];

    foreach ($cars as $car) {
        $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
        $text = demand_normalize_phrase(implode(' ', [
            (string) ($car['name'] ?? ''),
            (string) ($car['class'] ?? ''),
            (string) ($car['bodyType'] ?? ''),
            (string) ($car['slug'] ?? ''),
        ]));
        $seats = (int) ($car['seats'] ?? 0);
        $isCabriolet = str_contains($text, 'кабриолет') || str_contains($text, 'cabriolet');
        $isFamilyBody = str_contains($text, 'минивен') || str_contains($text, 'минивэн') || str_contains($text, 'minivan')
            || str_contains($text, 'кроссовер') || str_contains($text, 'внедорожник') || str_contains($text, 'suv');

        if ($family) {
            if ($seats >= 7 || ($seats >= 5 && $isFamilyBody && !$isCabriolet)) {
                $strong[] = $slug;
            } elseif ($seats >= 5 && !$isCabriolet) {
                $partial[] = $slug;
            } else {
                $weak[] = $slug;
            }
            continue;
        }

        if ($seats >= 5 || !$isCabriolet) {
            $strong[] = $slug;
        } else {
            $partial[] = $slug;
        }
    }

    if ($family) {
        if ($strong) {
            $status = 'strong_fit';
            $summary = 'Есть подтверждённые авто из facts.cars, которые подходят семейному сценарию по местам/типу кузова.';
        } elseif ($partial) {
            $status = 'partial_fit';
            $summary = 'Есть авто на 5 мест, но семейный сценарий требует ручной проверки багажа, кузова и условий.';
        } elseif ($weak) {
            $status = 'weak_fit';
            $summary = 'Связанные авто слабо подходят семейному сценарию. Кабриолет на 4 места нельзя считать сильным семейным совпадением.';
        } else {
            $status = 'no_confirmed_fit';
            $summary = 'Нет подтверждённого автомобиля под семейный сценарий.';
        }
    } else {
        $status = $strong ? 'strong_fit' : ($partial ? 'partial_fit' : 'weak_fit');
        $summary = $strong
            ? 'В facts.cars есть подтверждённые автомобили для работы с этим спросом.'
            : 'Совпадение по автомобилям требует ручной проверки.';
    }

    return [
        'status' => $status,
        'summary' => $summary,
        'familyScenario' => $family,
        'matchingCarSlugs' => demand_ai_safe_list(array_merge($strong, $partial), 40, 120),
        'weakCarSlugs' => demand_ai_safe_list($weak, 40, 120),
        'notes' => $family ? ['Для family/family car/семейных запросов проверяются места, кузов, багаж и класс авто.'] : [],
    ];
}

function demand_ai_collect_package_risks(array $facts): array
{
    $riskFlags = demand_ai_safe_list((array) ($facts['demand']['riskFlags'] ?? []), 40, 100);
    foreach ((array) ($facts['demand']['keywords'] ?? []) as $keyword) {
        if (is_array($keyword)) {
            $riskFlags = array_merge($riskFlags, (array) ($keyword['riskFlags'] ?? []), (array) ($keyword['riskProfile']['flags'] ?? []));
        }
    }
    foreach (['launchPlanItem', 'demandCluster', 'contentBrief', 'currentDraft', 'carHint'] as $field) {
        if (is_array($facts[$field] ?? null)) {
            $riskFlags = array_merge($riskFlags, (array) ($facts[$field]['riskFlags'] ?? []), (array) ($facts[$field]['pageRiskProfile']['flags'] ?? []));
        }
    }

    return demand_unique_strings(array_map('strval', $riskFlags));
}

function demand_ai_final_decision(array $facts, bool $testMode): array
{
    $riskFlags = demand_ai_collect_package_risks($facts);
    $supply = demand_ai_supply_fit_analysis($facts);
    $regionPolicies = [];
    foreach ((array) ($facts['demand']['keywords'] ?? []) as $keyword) {
        if (is_array($keyword) && is_array($keyword['regionPolicy'] ?? null)) {
            $regionPolicies[] = $keyword['regionPolicy'];
        }
    }

    $hasReviewRisk = (bool) array_intersect($riskFlags, ['needs_human_review', 'unknown_region', 'region_not_confirmed', 'needs_business_decision']);
    foreach ($regionPolicies as $policy) {
        if (in_array((string) ($policy['serviceRegionStatus'] ?? ''), ['unknown_region', 'conditional_service_region', 'not_supported_region'], true)) {
            $hasReviewRisk = true;
        }
    }

    $hasBlockedRisk = (bool) array_intersect($riskFlags, ['not_relevant_for_car_rental', 'unsupported_legal_request', 'possible_false_promise', 'condition_not_supported']);
    $clusterPriority = (string) ($facts['demand']['cluster']['priorityLevel'] ?? $facts['demand']['cluster']['priority'] ?? '');
    $planPriority = (string) ($facts['launchPlanItem']['priorityLevel'] ?? $facts['launchPlanItem']['priority'] ?? '');
    $priority = in_array('high', [$clusterPriority, $planPriority], true) ? 'high' : 'medium';
    $action = 'prepare_draft_for_review';
    $reasons = [];
    $blockedActions = ['auto_publish', 'auto_create_page', 'create_landing_without_review'];

    if ($testMode) {
        return [
            'testMode' => true,
            'priority' => 'test_only',
            'action' => 'do_not_use_for_seo_decision',
            'recommendedDecision' => 'test_package_only',
            'supplyFitStatus' => (string) ($supply['status'] ?? 'no_confirmed_fit'),
            'riskFlags' => $riskFlags,
            'blockedActions' => $blockedActions,
            'reasons' => ['Пакет собран из smoke/test данных и не должен использоваться для реального SEO-плана, публикации или приоритизации.'],
        ];
    }

    if ($hasBlockedRisk) {
        $priority = 'blocked';
        $action = 'do_not_create_page';
        $reasons[] = 'Есть критический риск или неподдерживаемое обещание.';
    } elseif ($hasReviewRisk) {
        $priority = in_array('high', [$clusterPriority, $planPriority], true) ? 'high_for_review' : 'needs_business_decision';
        $action = 'manual_review_before_draft';
        $reasons[] = 'Keyword-level риск требует ручной проверки перед любым черновиком.';
    } elseif (in_array((string) ($supply['status'] ?? ''), ['weak_fit', 'no_confirmed_fit'], true)) {
        $priority = $priority === 'high' ? 'high_for_review' : 'medium_for_review';
        $action = 'manual_review_before_draft';
        $reasons[] = 'Совпадение спроса и фактов по автомобилям слабое.';
    } else {
        $reasons[] = 'Критичных рисков не найдено, но действие остаётся в ручном workflow.';
    }

    return [
        'testMode' => false,
        'priority' => $priority,
        'action' => $action,
        'recommendedDecision' => $action,
        'supplyFitStatus' => (string) ($supply['status'] ?? 'no_confirmed_fit'),
        'riskFlags' => $riskFlags,
        'blockedActions' => $blockedActions,
        'reasons' => demand_ai_safe_list($reasons, 12, 260),
    ];
}

function demand_ai_safe_stage_c(array $source): array
{
    $questions = [];
    foreach (array_slice((array) ($source['userQuestionMap'] ?? []), 0, 20) as $item) {
        if (!is_array($item)) {
            continue;
        }
        $question = demand_ai_safe_string($item['question'] ?? '', 260);
        if ($question !== '') {
            $questions[] = [
                'question' => $question,
                'sourceIntent' => demand_ai_safe_string($item['sourceIntent'] ?? '', 80),
                'priority' => demand_ai_safe_string($item['priority'] ?? '', 40),
            ];
        }
    }

    $blocks = [];
    foreach (array_slice((array) ($source['safeContentBlocks'] ?? []), 0, 20) as $block) {
        if (!is_array($block)) {
            continue;
        }
        $type = demand_ai_safe_string($block['type'] ?? '', 100);
        if ($type !== '') {
            $blocks[] = [
                'type' => $type,
                'title' => demand_ai_safe_string($block['title'] ?? '', 180),
                'whyNeeded' => demand_ai_safe_string($block['whyNeeded'] ?? '', 700),
                'suggestedTextTemplate' => demand_ai_safe_string($block['suggestedTextTemplate'] ?? '', 1200),
                'requiredFacts' => demand_ai_safe_list($block['requiredFacts'] ?? [], 20, 160),
                'forbiddenPromises' => demand_ai_safe_list($block['forbiddenPromises'] ?? [], 20, 160),
                'linkedIntents' => demand_ai_safe_list($block['linkedIntents'] ?? [], 20, 80),
                'priority' => demand_ai_safe_string($block['priority'] ?? '', 40),
            ];
        }
    }

    $faq = [];
    foreach (array_slice((array) ($source['recommendedFaq'] ?? []), 0, 20) as $item) {
        if (!is_array($item)) {
            continue;
        }
        $question = demand_ai_safe_string($item['question'] ?? '', 260);
        if ($question !== '') {
            $faq[] = [
                'question' => $question,
                'answerGuidance' => demand_ai_safe_string($item['answerGuidance'] ?? '', 900),
                'sourceIntent' => demand_ai_safe_string($item['sourceIntent'] ?? '', 100),
                'riskLevel' => demand_ai_safe_string($item['riskLevel'] ?? '', 40),
            ];
        }
    }

    $links = [];
    foreach (array_slice((array) ($source['recommendedInternalLinks'] ?? []), 0, 20) as $link) {
        if (!is_array($link)) {
            continue;
        }
        $links[] = [
            'linkType' => demand_ai_safe_string($link['linkType'] ?? '', 100),
            'fromContext' => demand_ai_safe_string($link['fromContext'] ?? '', 220),
            'toTargetType' => demand_ai_safe_string($link['toTargetType'] ?? '', 100),
            'targetHint' => demand_ai_safe_string($link['targetHint'] ?? '', 220),
            'reason' => demand_ai_safe_string($link['reason'] ?? '', 500),
        ];
    }

    $carHints = [];
    foreach (array_slice((array) ($source['recommendedCarCardHints'] ?? []), 0, 20) as $hint) {
        if (!is_array($hint)) {
            continue;
        }
        $carHints[] = [
            'carSlug' => demand_ai_safe_string($hint['carSlug'] ?? '', 120),
            'carName' => demand_ai_safe_string($hint['carName'] ?? '', 180),
            'hints' => demand_ai_safe_list($hint['hints'] ?? [], 12, 240),
        ];
    }

    $gap = is_array($source['contentGapReport'] ?? null) ? $source['contentGapReport'] : [];
    $clarity = is_array($source['userClarityScore'] ?? null) ? $source['userClarityScore'] : [];
    $aiReadiness = is_array($source['aiSearchReadiness'] ?? null) ? $source['aiSearchReadiness'] : [];

    return [
        'userQuestionMap' => $questions,
        'safeContentBlocks' => $blocks,
        'contentGapReport' => [
            'missingBlocks' => demand_ai_safe_list($gap['missingBlocks'] ?? [], 30, 120),
            'weakBlocks' => demand_ai_safe_list($gap['weakBlocks'] ?? [], 30, 120),
            'dangerousClaims' => demand_ai_safe_list($gap['dangerousClaims'] ?? [], 30, 260),
            'recommendedFixes' => demand_ai_safe_list($gap['recommendedFixes'] ?? [], 30, 260),
            'clarityWarnings' => demand_ai_safe_list($gap['clarityWarnings'] ?? [], 30, 260),
        ],
        'firstScreenAnswer' => demand_ai_safe_string($source['firstScreenAnswer'] ?? '', 1200),
        'mustAnswer' => demand_ai_safe_list($source['mustAnswer'] ?? [], 30, 260),
        'mustNotPromise' => demand_ai_safe_list($source['mustNotPromise'] ?? [], 30, 260),
        'recommendedFaq' => $faq,
        'recommendedInternalLinks' => $links,
        'recommendedCarCardHints' => $carHints,
        'userClarityScore' => [
            'level' => demand_ai_safe_string($clarity['level'] ?? '', 40),
            'score' => (int) ($clarity['score'] ?? 0),
            'summary' => demand_ai_safe_string($clarity['summary'] ?? '', 700),
        ],
        'aiSearchReadiness' => [
            'level' => demand_ai_safe_string($aiReadiness['level'] ?? '', 40),
            'score' => (int) ($aiReadiness['score'] ?? 0),
            'summary' => demand_ai_safe_string($aiReadiness['summary'] ?? '', 700),
        ],
    ];
}

function demand_ai_safe_keyword(?array $keyword): ?array
{
    if (!$keyword) {
        return null;
    }
    $regionPolicy = demand_ai_region_policy((string) ($keyword['regionName'] ?? ''), $keyword);
    $riskFlags = demand_ai_effective_risk_flags((array) ($keyword['riskFlags'] ?? []), $regionPolicy);
    $keywordForScore = $keyword;
    $keywordForScore['riskFlags'] = $riskFlags;
    $stageB = function_exists('demand_stage_b_score_keyword') ? demand_stage_b_score_keyword($keywordForScore) : [];
    $stageC = function_exists('demand_stage_c_analyze_keyword') ? demand_stage_c_analyze_keyword($keywordForScore, ['stageB' => $stageB]) : [];

    return array_merge([
        'id' => demand_ai_safe_string($keyword['id'] ?? '', 80),
        'phrase' => demand_ai_safe_string($keyword['phrase'] ?? '', 240),
        'normalizedPhrase' => demand_ai_safe_string($keyword['normalizedPhrase'] ?? demand_normalize_phrase((string) ($keyword['phrase'] ?? '')), 240),
        'regionName' => demand_ai_safe_string($regionPolicy['normalizedRegion'] ?? ($keyword['regionName'] ?? ''), 160),
        'originalRegionName' => demand_ai_safe_string($regionPolicy['originalRegion'] ?? ($keyword['regionName'] ?? ''), 160),
        'regionPolicy' => $regionPolicy,
        'regionId' => demand_ai_safe_string($keyword['regionId'] ?? '', 80),
        'frequency' => max(0, (int) ($keyword['frequency'] ?? 0)),
        'source' => demand_ai_safe_string($keyword['source'] ?? '', 120),
        'category' => demand_ai_safe_string($keyword['category'] ?? '', 80),
        'intent' => demand_ai_safe_string($keyword['intent'] ?? '', 80),
        'secondaryIntents' => demand_ai_safe_list($keyword['secondaryIntents'] ?? [], 12, 80),
        'demandType' => demand_ai_safe_string($keyword['demandType'] ?? '', 80),
        'decisionHint' => demand_ai_safe_string($keyword['decisionHint'] ?? '', 120),
        'adminExplanation' => demand_ai_safe_string($keyword['adminExplanation'] ?? '', 700),
        'detectedModifiers' => array_filter([
            'city' => demand_ai_safe_string($keyword['detectedCity'] ?? '', 120),
            'region' => demand_ai_safe_string($keyword['detectedRegion'] ?? '', 120),
            'carClass' => demand_ai_safe_string($keyword['detectedCarClass'] ?? '', 120),
            'condition' => demand_ai_safe_string($keyword['detectedCondition'] ?? '', 120),
            'scenario' => demand_ai_safe_string($keyword['detectedScenario'] ?? '', 120),
            'price' => demand_ai_safe_string($keyword['detectedPriceModifier'] ?? '', 120),
            'duration' => demand_ai_safe_string($keyword['detectedDuration'] ?? '', 120),
        ], static fn($value): bool => $value !== ''),
        'features' => [
            'tokens' => demand_ai_safe_list((array) ($keyword['features']['tokens'] ?? []), 20, 80),
            'synonymGroups' => demand_ai_safe_list((array) ($keyword['features']['synonymGroups'] ?? []), 12, 80),
            'isCommercial' => !empty($keyword['features']['isCommercial']),
            'isInformational' => !empty($keyword['features']['isInformational']),
            'needsHumanReview' => !empty($keyword['features']['needsHumanReview']),
        ],
        'riskProfile' => [
            'flags' => demand_ai_safe_list($riskFlags, 20, 80),
            'negativeIntent' => demand_ai_safe_string($keyword['negativeIntent'] ?? '', 120),
            'exclusionReason' => demand_ai_safe_string($keyword['exclusionReason'] ?? '', 500),
        ],
        'demandVolumeScore' => (int) ($stageB['demandVolumeScore'] ?? 0),
        'commercialScore' => (int) ($stageB['commercialScore'] ?? 0),
        'supplyFitScore' => (int) ($stageB['supplyFitScore'] ?? 0),
        'pageFitScore' => (int) ($stageB['pageFitScore'] ?? 0),
        'contentGapScore' => (int) ($stageB['contentGapScore'] ?? 0),
        'riskScore' => (int) ($stageB['riskScore'] ?? 0),
        'regionFitScore' => (int) ($stageB['regionFitScore'] ?? 0),
        'seasonalityScore' => (int) ($stageB['seasonalityScore'] ?? 0),
        'decisionScore' => (int) ($stageB['decisionScore'] ?? 0),
        'priorityLevel' => demand_ai_safe_string($stageB['priorityLevel'] ?? '', 80),
        'recommendedDecision' => demand_ai_safe_string($stageB['recommendedDecision'] ?? '', 120),
        'scoringExplanation' => demand_ai_safe_string($stageB['scoringExplanation'] ?? '', 900),
        'contentGapSummary' => demand_ai_safe_string($stageB['contentGapSummary'] ?? '', 900),
        'pageFitStatus' => demand_ai_safe_string($stageB['pageFitStatus'] ?? '', 120),
        'supplyFitSummary' => demand_ai_safe_string($stageB['supplyFitSummary'] ?? '', 900),
        'pageRiskProfile' => [
            'level' => demand_ai_safe_string($stageB['pageRiskProfile']['level'] ?? '', 80),
            'summary' => demand_ai_safe_string($stageB['pageRiskProfile']['summary'] ?? '', 700),
            'flags' => demand_ai_safe_list($stageB['pageRiskProfile']['flags'] ?? [], 30, 80),
        ],
        'mustNotPromise' => demand_ai_safe_list($keyword['mustNotPromise'] ?? [], 20, 220),
        'riskFlags' => demand_ai_safe_list($riskFlags, 20, 80),
    ], demand_ai_safe_stage_c($stageC));
}

function demand_ai_keywords_by_ids(array $keywordIds): array
{
    $items = [];
    foreach ($keywordIds as $keywordId) {
        $keyword = demand_find_keyword((string) $keywordId);
        $safe = demand_ai_safe_keyword($keyword);
        if ($safe) {
            $items[] = $safe;
        }
    }

    return $items;
}

function demand_ai_safe_car(?array $car): ?array
{
    if (!$car) {
        return null;
    }

    $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
    if ($slug === '') {
        return null;
    }

    $isPublic = function_exists('car_visible_in_public_rent_rk_showcase') && car_visible_in_public_rent_rk_showcase($car);
    $safe = [
        'slug' => $slug,
        'name' => demand_ai_safe_string($car['name'] ?? '', 160),
        'class' => demand_ai_safe_string($car['class'] ?? $car['body'] ?? '', 120),
        'bodyType' => demand_ai_safe_string($car['bodyType'] ?? $car['body'] ?? '', 120),
        'seats' => max(0, (int) ($car['seats'] ?? 0)),
        'transmission' => demand_ai_safe_string($car['transmission'] ?? '', 120),
        'drive' => demand_ai_safe_string($car['drive'] ?? '', 120),
        'engine' => demand_ai_safe_string($car['engine'] ?? '', 160),
        'publicConditions' => [],
    ];

    if ($isPublic) {
        $price = normalize_rate_price($car['price'] ?? null);
        if ($price !== null) {
            $safe['publicPrice'] = $price;
        }
        $deposit = car_deposit_amount($slug, $car);
        if ($deposit !== null) {
            $safe['publicDeposit'] = $deposit;
        }
        $image = demand_ai_safe_string($car['image'] ?? '', 240);
        if ($image !== '') {
            $safe['publicImage'] = $image;
        }
    }

    $mileage = car_mileage_policy($car);
    if ((int) ($mileage['limitPerDay'] ?? 0) > 0) {
        $safe['publicConditions'][] = 'Лимит пробега в сутки: ' . (int) $mileage['limitPerDay'] . ' км.';
    }
    if ((int) ($mileage['extraMileageRate'] ?? 0) > 0) {
        $safe['publicConditions'][] = 'Дополнительный пробег: ' . (int) $mileage['extraMileageRate'] . ' руб./км.';
    }

    return $safe;
}

function demand_ai_safe_cars(array $slugs): array
{
    $cars = [];
    foreach ($slugs as $slug) {
        $safe = demand_ai_safe_car(find_car((string) $slug));
        if ($safe) {
            $cars[] = $safe;
        }
    }

    return $cars;
}

function demand_ai_safe_content_blocks($blocks): array
{
    $allowedTypes = array_fill_keys(demand_allowed_content_block_types(), true);
    $result = [];
    foreach ((array) $blocks as $block) {
        if (!is_array($block)) {
            continue;
        }
        $type = demand_ai_safe_string($block['type'] ?? 'text', 80);
        if (!isset($allowedTypes[$type])) {
            $type = 'text';
        }
        $safe = [
            'type' => $type,
            'visibility' => function_exists('demand_normalize_content_block_visibility')
                ? demand_normalize_content_block_visibility((string) ($block['visibility'] ?? ''), $type, (string) ($block['title'] ?? ''))
                : 'public',
            'title' => demand_ai_safe_string($block['title'] ?? '', 180),
        ];
        if ($type === 'faq') {
            $items = [];
            foreach ((array) ($block['items'] ?? []) as $item) {
                if (!is_array($item)) {
                    continue;
                }
                $question = demand_ai_safe_string($item['question'] ?? '', 220);
                $answer = demand_ai_safe_string($item['answer'] ?? '', 600);
                if ($question !== '' && $answer !== '') {
                    $items[] = ['question' => $question, 'answer' => $answer];
                }
            }
            $safe['items'] = array_slice($items, 0, 20);
        } else {
            $safe['body'] = demand_ai_safe_string($block['body'] ?? $block['text'] ?? '', 1600);
        }
        $result[] = $safe;
        if (count($result) >= 20) {
            break;
        }
    }

    return $result;
}

function demand_ai_safe_faq($items): array
{
    $faq = [];
    foreach ((array) $items as $item) {
        if (!is_array($item)) {
            continue;
        }
        $question = demand_ai_safe_string($item['question'] ?? '', 220);
        $answer = demand_ai_safe_string($item['answer'] ?? '', 800);
        if ($question !== '' && $answer !== '') {
            $faq[] = ['question' => $question, 'answer' => $answer];
        }
        if (count($faq) >= 20) {
            break;
        }
    }

    return $faq;
}

function demand_ai_extract_faq_from_blocks(array $blocks): array
{
    $faq = [];
    foreach ($blocks as $block) {
        if (!is_array($block) || (string) ($block['type'] ?? '') !== 'faq') {
            continue;
        }
        foreach ((array) ($block['items'] ?? []) as $item) {
            if (is_array($item)) {
                $faq[] = $item;
            }
        }
    }

    return demand_ai_safe_faq($faq);
}

function demand_ai_safe_draft(array $draft): array
{
    $blocks = demand_ai_safe_content_blocks($draft['contentBlocks'] ?? []);

    return array_merge([
        'slug' => demand_ai_safe_string($draft['slug'] ?? '', 160),
        'title' => demand_ai_safe_string($draft['title'] ?? '', 180),
        'h1' => demand_ai_safe_string($draft['h1'] ?? '', 180),
        'metaDescription' => demand_ai_safe_string($draft['metaDescription'] ?? '', 300),
        'intro' => demand_ai_safe_string($draft['intro'] ?? '', 1200),
        'contentBlocks' => $blocks,
        'faq' => demand_ai_extract_faq_from_blocks($blocks),
        'internalLinks' => demand_normalize_internal_links($draft['internalLinks'] ?? []),
        'internalLinkSuggestions' => array_slice((array) ($draft['internalLinkSuggestions']['internalLinkSuggestions'] ?? []), 0, 10),
        'readinessStatus' => demand_ai_safe_string($draft['readinessStatus'] ?? 'not_checked', 80),
        'readinessChecks' => array_values(array_map(static function ($check): array {
            $check = is_array($check) ? $check : [];

            return [
                'code' => demand_ai_safe_string($check['code'] ?? '', 100),
                'status' => demand_ai_safe_string($check['status'] ?? '', 40),
                'message' => demand_ai_safe_string($check['message'] ?? '', 300),
            ];
        }, array_slice((array) ($draft['readinessChecks'] ?? []), 0, 40))),
        'riskFlags' => demand_ai_safe_list(demand_landing_risk_flags($draft), 30, 80),
    ], demand_ai_safe_stage_c($draft));
}

function demand_ai_safe_brief(array $brief): array
{
    return array_merge([
        'id' => demand_ai_safe_string($brief['id'] ?? '', 90),
        'title' => demand_ai_safe_string($brief['title'] ?? '', 180),
        'targetIntent' => demand_ai_safe_string($brief['targetIntent'] ?? '', 1200),
        'mustAnswer' => demand_ai_safe_list($brief['mustAnswer'] ?? [], 30, 260),
        'mustNotPromise' => demand_ai_safe_list($brief['mustNotPromise'] ?? [], 30, 260),
        'recommendedBlocks' => demand_ai_safe_list($brief['recommendedBlocks'] ?? [], 30, 120),
        'faqQuestions' => demand_ai_safe_list($brief['faqQuestions'] ?? [], 30, 240),
        'linkedCars' => demand_ai_safe_list($brief['linkedCars'] ?? [], 30, 120),
        'status' => demand_ai_safe_string($brief['status'] ?? '', 80),
        'pageRiskProfile' => [
            'level' => demand_ai_safe_string($brief['pageRiskProfile']['level'] ?? '', 80),
            'summary' => demand_ai_safe_string($brief['pageRiskProfile']['summary'] ?? '', 700),
            'flags' => demand_ai_safe_list($brief['pageRiskProfile']['flags'] ?? [], 30, 80),
        ],
        'userClarityGoals' => [
            'level' => demand_ai_safe_string($brief['userClarityGoals']['level'] ?? '', 40),
            'score' => (int) ($brief['userClarityGoals']['score'] ?? 0),
            'summary' => demand_ai_safe_string($brief['userClarityGoals']['summary'] ?? '', 700),
        ],
        'aiSearchReadinessGoals' => [
            'level' => demand_ai_safe_string($brief['aiSearchReadinessGoals']['level'] ?? '', 40),
            'score' => (int) ($brief['aiSearchReadinessGoals']['score'] ?? 0),
            'summary' => demand_ai_safe_string($brief['aiSearchReadinessGoals']['summary'] ?? '', 700),
        ],
    ], demand_ai_safe_stage_c($brief));
}

function demand_ai_safe_cluster(array $cluster): array
{
    return array_merge([
        'id' => demand_ai_safe_string($cluster['id'] ?? '', 90),
        'name' => demand_ai_safe_string($cluster['name'] ?? '', 180),
        'clusterType' => demand_ai_safe_string($cluster['clusterType'] ?? '', 80),
        'intent' => demand_ai_safe_string($cluster['intent'] ?? '', 120),
        'primaryPhrase' => demand_ai_safe_string($cluster['primaryPhrase'] ?? '', 240),
        'totalFrequency' => max(0, (int) ($cluster['totalFrequency'] ?? 0)),
        'priority' => demand_ai_safe_string($cluster['priority'] ?? '', 80),
        'priorityScore' => (int) ($cluster['priorityScore'] ?? 0),
        'demandVolumeScore' => (int) ($cluster['demandVolumeScore'] ?? 0),
        'commercialScore' => (int) ($cluster['commercialScore'] ?? 0),
        'supplyScore' => (int) ($cluster['supplyScore'] ?? $cluster['supplyFitScore'] ?? 0),
        'supplyFitScore' => (int) ($cluster['supplyFitScore'] ?? $cluster['supplyScore'] ?? 0),
        'pageFitScore' => (int) ($cluster['pageFitScore'] ?? 0),
        'contentGapScore' => (int) ($cluster['contentGapScore'] ?? 0),
        'riskScore' => (int) ($cluster['riskScore'] ?? 0),
        'regionFitScore' => (int) ($cluster['regionFitScore'] ?? 0),
        'seasonalityScore' => (int) ($cluster['seasonalityScore'] ?? 0),
        'decisionScore' => (int) ($cluster['decisionScore'] ?? $cluster['priorityScore'] ?? 0),
        'priorityLevel' => demand_ai_safe_string($cluster['priorityLevel'] ?? $cluster['priority'] ?? '', 80),
        'recommendedDecision' => demand_ai_safe_string($cluster['recommendedDecision'] ?? '', 120),
        'scoringExplanation' => demand_ai_safe_string($cluster['scoringExplanation'] ?? '', 900),
        'contentGapSummary' => demand_ai_safe_string($cluster['contentGapSummary'] ?? '', 900),
        'pageFitStatus' => demand_ai_safe_string($cluster['pageFitStatus'] ?? '', 120),
        'supplyFitSummary' => demand_ai_safe_string($cluster['supplyFitSummary'] ?? '', 900),
        'pageRiskProfile' => [
            'level' => demand_ai_safe_string($cluster['pageRiskProfile']['level'] ?? '', 80),
            'summary' => demand_ai_safe_string($cluster['pageRiskProfile']['summary'] ?? '', 700),
            'flags' => demand_ai_safe_list($cluster['pageRiskProfile']['flags'] ?? [], 30, 80),
        ],
        'riskFlags' => demand_ai_safe_list($cluster['riskFlags'] ?? [], 30, 80),
        'linkedCars' => demand_ai_safe_list($cluster['linkedCars'] ?? [], 30, 120),
    ], demand_ai_safe_stage_c($cluster));
}

function demand_ai_safe_plan(array $plan): array
{
    return array_merge([
        'id' => demand_ai_safe_string($plan['id'] ?? '', 90),
        'title' => demand_ai_safe_string($plan['title'] ?? '', 180),
        'planType' => demand_ai_safe_string($plan['planType'] ?? '', 80),
        'recommendedAction' => demand_ai_safe_string($plan['recommendedAction'] ?? '', 100),
        'reason' => demand_ai_safe_string($plan['reason'] ?? '', 1200),
        'requiredWork' => demand_ai_safe_list($plan['requiredWork'] ?? [], 30, 140),
        'launchStatus' => demand_ai_safe_string($plan['launchStatus'] ?? '', 80),
        'priority' => demand_ai_safe_string($plan['priority'] ?? '', 80),
        'priorityScore' => (int) ($plan['priorityScore'] ?? 0),
        'demandVolumeScore' => (int) ($plan['demandVolumeScore'] ?? 0),
        'commercialScore' => (int) ($plan['commercialScore'] ?? 0),
        'supplyFitScore' => (int) ($plan['supplyFitScore'] ?? 0),
        'pageFitScore' => (int) ($plan['pageFitScore'] ?? 0),
        'contentGapScore' => (int) ($plan['contentGapScore'] ?? 0),
        'riskScore' => (int) ($plan['riskScore'] ?? 0),
        'regionFitScore' => (int) ($plan['regionFitScore'] ?? 0),
        'seasonalityScore' => (int) ($plan['seasonalityScore'] ?? 0),
        'decisionScore' => (int) ($plan['decisionScore'] ?? $plan['priorityScore'] ?? 0),
        'priorityLevel' => demand_ai_safe_string($plan['priorityLevel'] ?? $plan['priority'] ?? '', 80),
        'recommendedDecision' => demand_ai_safe_string($plan['recommendedDecision'] ?? '', 120),
        'scoringExplanation' => demand_ai_safe_string($plan['scoringExplanation'] ?? '', 900),
        'contentGapSummary' => demand_ai_safe_string($plan['contentGapSummary'] ?? '', 900),
        'pageFitStatus' => demand_ai_safe_string($plan['pageFitStatus'] ?? '', 120),
        'supplyFitSummary' => demand_ai_safe_string($plan['supplyFitSummary'] ?? '', 900),
        'pageRiskProfile' => [
            'level' => demand_ai_safe_string($plan['pageRiskProfile']['level'] ?? '', 80),
            'summary' => demand_ai_safe_string($plan['pageRiskProfile']['summary'] ?? '', 700),
            'flags' => demand_ai_safe_list($plan['pageRiskProfile']['flags'] ?? [], 30, 80),
        ],
        'riskFlags' => demand_ai_safe_list($plan['riskFlags'] ?? [], 30, 80),
        'linkedCars' => demand_ai_safe_list($plan['linkedCars'] ?? [], 30, 120),
    ], demand_ai_safe_stage_c($plan));
}

function demand_ai_safe_hint(array $hint): array
{
    return [
        'id' => demand_ai_safe_string($hint['id'] ?? '', 90),
        'carId' => demand_ai_safe_string($hint['carId'] ?? '', 120),
        'hintType' => demand_ai_safe_string($hint['hintType'] ?? '', 100),
        'priority' => demand_ai_safe_string($hint['priority'] ?? '', 80),
        'message' => demand_ai_safe_string($hint['message'] ?? '', 1200),
        'suggestedText' => demand_ai_safe_string($hint['suggestedText'] ?? '', 1600),
        'descriptionSuggestion' => demand_ai_safe_string($hint['descriptionSuggestion'] ?? '', 2200),
        'status' => demand_ai_safe_string($hint['status'] ?? '', 80),
    ];
}

function demand_ai_find_content_brief(string $briefId): ?array
{
    foreach (demand_map_read_content_briefs()['items'] as $brief) {
        if (is_array($brief) && (string) ($brief['id'] ?? '') === $briefId) {
            return $brief;
        }
    }

    return null;
}

function demand_ai_find_car_hint(string $hintId): ?array
{
    foreach (demand_map_read_card_hints()['items'] as $hint) {
        if (is_array($hint) && (string) ($hint['id'] ?? '') === $hintId) {
            return $hint;
        }
    }

    return null;
}

function demand_ai_find_entity(string $entityType, string $entityId): ?array
{
    return match ($entityType) {
        'draft' => demand_find_draft($entityId),
        'content_brief' => demand_ai_find_content_brief($entityId),
        'launch_plan_item' => demand_map_find_plan($entityId),
        'demand_cluster' => demand_map_find_cluster($entityId),
        'car_hint' => demand_ai_find_car_hint($entityId),
        default => null,
    };
}

function demand_ai_entity_scope(array $entity): string
{
    return demand_normalize_scope_id((string) ($entity['scope_id'] ?? 'rent_rk'));
}

function demand_ai_entity_view_permission(string $entityType): string
{
    return match ($entityType) {
        'draft' => 'demand.view',
        'content_brief' => 'demand.content_briefs.view',
        'launch_plan_item' => 'demand.launch_plan.view',
        'demand_cluster' => 'demand.map.view',
        'car_hint' => 'demand.card_hints.view',
        default => 'demand.view',
    };
}

function demand_ai_filter_safe_context(string $entityType = '', array $context = []): array
{
    return match ($entityType) {
        'draft' => ['currentDraft' => demand_ai_safe_draft($context)],
        'content_brief' => ['contentBrief' => demand_ai_safe_brief($context)],
        'launch_plan_item' => ['launchPlanItem' => demand_ai_safe_plan($context)],
        'demand_cluster' => ['demandCluster' => demand_ai_safe_cluster($context)],
        'car_hint' => ['carHint' => demand_ai_safe_hint($context)],
        default => [],
    };
}

function demand_ai_base_instructions(): array
{
    return [
        'mustPreserve' => [
            'Не менять цены, залог и условия.',
            'Если данных нет, писать, что условия уточняются менеджером.',
            'Сохранять честную формулировку: наличие авто, подача, цена и залог подтверждаются перед поездкой.',
            'Использовать как доступные только автомобили из facts.cars.',
            'Если пакет помечен testMode=true, не использовать его для реального SEO-плана, публикации или приоритизации.',
            'Возвращать только JSON по expectedResponse без HTML и Markdown.',
        ],
        'mustNotPromise' => [
            'Не обещать аренду без залога, если это не подтверждено.',
            'Не обещать самую низкую цену.',
            'Не обещать наличие авто без проверки.',
            'Не обещать подачу, документы или условия, которых нет в фактах.',
            'Не писать, что автомобиль доступен, если его нет в facts.cars.',
        ],
        'forbiddenActions' => [
            'Не публиковать страницу.',
            'Не открывать индексацию.',
            'Не менять sitemap.',
            'Не менять robots.',
            'Не менять canonical, publishStatus или indexStatus.',
            'Не менять цены, залоги, тарифы, заявки, аренды, клиентов, штрафы и финансы.',
            'Не запускать Wordstat live sync.',
            'Не отправлять уведомления клиентам или в Telegram.',
        ],
    ];
}

function demand_ai_expected_response_schema(string $entityType, string $task): array
{
    if ($entityType === 'draft' && demand_ai_is_human_copy_task($task)) {
        return [
            'format' => 'json',
            'schema' => [
                'summary' => 'string',
                'styleUsed' => 'string',
                'copyQuality' => [
                    'clarity' => 'good|needs_simpler',
                    'humanTone' => 'good|too_dry|too_salesy',
                    'seoOveruse' => 'none|possible|high',
                    'promiseRisk' => 'none|needs_check|high',
                    'specificity' => 'good|needs_more_facts',
                ],
                'draftProposal' => [
                    'title' => 'string|null',
                    'h1' => 'string|null',
                    'metaDescription' => 'string|null',
                    'intro' => 'string|null',
                    'contentBlocks' => [['type' => 'string', 'title' => 'string', 'text' => 'string']],
                    'faq' => [['question' => 'string', 'answer' => 'string']],
                ],
                'mustCheckBeforeApply' => ['string'],
                'notAllowed' => ['string'],
            ],
            'copyGenerationRules' => demand_ai_copy_generation_rules(),
        ];
    }

    if ($entityType === 'content_brief') {
        return [
            'format' => 'json',
            'schema' => [
                'targetIntent' => 'string',
                'mustAnswer' => ['string'],
                'mustNotPromise' => ['string'],
                'recommendedBlocks' => ['string'],
                'faqQuestions' => ['string'],
                'userQuestionMap' => [],
                'safeContentBlocks' => [],
                'contentGapReport' => [],
                'firstScreenAnswer' => 'string',
                'recommendedFaq' => [],
                'recommendedInternalLinks' => [],
                'recommendedCarCardHints' => [],
                'userClarityGoals' => [],
                'aiSearchReadinessGoals' => [],
                'risks' => ['string'],
                'notesForAdmin' => ['string'],
            ],
        ];
    }

    if ($entityType === 'car_hint') {
        return [
            'format' => 'json',
            'schema' => [
                'suggestedText' => 'string',
                'message' => 'string',
                'descriptionSuggestion' => 'string',
                'risks' => ['string'],
                'notesForAdmin' => ['string'],
            ],
        ];
    }

    if (in_array($entityType, ['launch_plan_item', 'demand_cluster'], true)) {
        return [
            'format' => 'json',
            'schema' => [
                'title' => 'string',
                'outline' => ['string'],
                'mustAnswer' => ['string'],
                'safeContentBlocks' => [],
                'firstScreenAnswer' => 'string',
                'recommendedFaq' => [],
                'faq' => [['question' => 'string', 'answer' => 'string']],
                'risks' => ['string'],
                'notesForAdmin' => ['string'],
            ],
        ];
    }

    return [
        'format' => 'json',
        'schema' => [
            'title' => 'string',
            'h1' => 'string',
            'metaDescription' => 'string',
            'intro' => 'string',
            'contentBlocks' => [],
            'faq' => [],
            'internalLinks' => [],
            'safeContentBlocks' => [],
            'contentGapReport' => [],
            'firstScreenAnswer' => 'string',
            'recommendedFaq' => [],
            'recommendedInternalLinks' => [],
            'recommendedCarCardHints' => [],
            'adminNote' => 'string',
            'risks' => [],
            'notesForAdmin' => [],
        ],
    ];
}

function demand_ai_build_facts_to_preserve(array $facts): array
{
    $currentDraft = is_array($facts['currentDraft'] ?? null) ? $facts['currentDraft'] : [];
    $cluster = is_array($facts['demand']['cluster'] ?? null) ? $facts['demand']['cluster'] : [];
    $keywords = array_values(array_filter((array) ($facts['demand']['keywords'] ?? []), 'is_array'));
    $firstKeyword = is_array($keywords[0] ?? null) ? $keywords[0] : [];
    $cars = [];
    foreach ((array) ($facts['cars'] ?? []) as $car) {
        if (!is_array($car)) {
            continue;
        }
        $cars[] = array_filter([
            'slug' => demand_ai_safe_string($car['slug'] ?? '', 120),
            'name' => demand_ai_safe_string($car['name'] ?? '', 160),
            'class' => demand_ai_safe_string($car['class'] ?? $car['bodyType'] ?? '', 120),
            'seats' => (int) ($car['seats'] ?? 0),
        ], static fn($value): bool => $value !== '' && $value !== 0);
    }

    return [
        'region' => demand_ai_safe_string($firstKeyword['detected']['region'] ?? $firstKeyword['regionName'] ?? $cluster['regionName'] ?? '', 160),
        'city' => demand_ai_safe_string($firstKeyword['detected']['city'] ?? '', 120),
        'carType' => demand_ai_safe_string($firstKeyword['detected']['carClass'] ?? $cluster['clusterType'] ?? '', 120),
        'primaryPhrase' => demand_ai_safe_string($facts['demand']['primaryPhrase'] ?? '', 220),
        'linkedCars' => $cars,
        'conditions' => demand_ai_safe_list($facts['conditions'] ?? [], 20, 260),
        'mustAnswer' => demand_ai_safe_list($currentDraft['mustAnswer'] ?? [], 30, 260),
        'mustNotPromise' => demand_ai_safe_list($currentDraft['mustNotPromise'] ?? ($facts['demand']['riskFlags'] ?? []), 30, 260),
        'riskFlags' => demand_ai_safe_list($facts['demand']['riskFlags'] ?? [], 30, 100),
        'contentGapReport' => is_array($currentDraft['contentGapReport'] ?? null) ? $currentDraft['contentGapReport'] : [],
        'userQuestionMap' => is_array($currentDraft['userQuestionMap'] ?? null) ? $currentDraft['userQuestionMap'] : [],
        'safeContentBlocks' => is_array($currentDraft['safeContentBlocks'] ?? null) ? $currentDraft['safeContentBlocks'] : [],
    ];
}

function demand_ai_finalize_facts(array $facts): array
{
    $facts = demand_ai_reconcile_car_hints_with_facts($facts);
    $supplyFit = demand_ai_supply_fit_analysis($facts);
    $facts['supplyFit'] = $supplyFit;
    $facts['supplyFitStatus'] = (string) ($supplyFit['status'] ?? 'no_confirmed_fit');
    $facts['factsToPreserve'] = demand_ai_build_facts_to_preserve($facts);
    $facts['humanCopyRules'] = demand_ai_copy_generation_rules();

    return $facts;
}

function demand_ai_build_facts(string $entityType, array $entity): array
{
    $facts = [
        'demand' => [
            'primaryPhrase' => '',
            'keywords' => [],
            'cluster' => null,
            'riskFlags' => [],
        ],
        'cars' => [],
        'conditions' => [
            'Цены, залог, подача и наличие авто должны сверяться менеджером перед публикацией.',
        ],
    ];

    if ($entityType === 'draft') {
        $draft = $entity;
        $cluster = null;
        if ((string) ($draft['linkedClusterId'] ?? '') !== '') {
            $cluster = demand_map_find_cluster((string) $draft['linkedClusterId']);
        }
        $keywords = demand_ai_keywords_by_ids((array) ($draft['sourceKeywordIds'] ?? []));
        $facts['demand']['keywords'] = $keywords;
        $facts['demand']['cluster'] = $cluster ? demand_ai_safe_cluster($cluster) : null;
        $facts['demand']['primaryPhrase'] = (string) ($cluster['primaryPhrase'] ?? ($keywords[0]['phrase'] ?? ''));
        $facts['demand']['riskFlags'] = demand_ai_safe_list(demand_landing_risk_flags($draft), 30, 80);
        $facts['cars'] = demand_ai_safe_cars((array) ($draft['linkedCars'] ?? []));
        $facts['currentDraft'] = demand_ai_safe_draft($draft);
        $facts['internalLinkSources'] = demand_suggest_internal_links_for_draft($draft);

        return demand_ai_finalize_facts($facts);
    }

    if ($entityType === 'content_brief') {
        $brief = $entity;
        $cluster = demand_map_find_cluster((string) ($brief['clusterId'] ?? ''));
        $plan = demand_map_find_plan((string) ($brief['launchPlanId'] ?? ''));
        $keywordIds = is_array($plan) ? (array) ($plan['linkedKeywordIds'] ?? []) : (array) ($cluster['keywordIds'] ?? []);
        $keywords = demand_ai_keywords_by_ids($keywordIds);
        $facts['demand']['keywords'] = $keywords;
        $facts['demand']['cluster'] = $cluster ? demand_ai_safe_cluster($cluster) : null;
        $facts['demand']['primaryPhrase'] = (string) ($cluster['primaryPhrase'] ?? ($keywords[0]['phrase'] ?? ''));
        $facts['demand']['riskFlags'] = demand_ai_safe_list(array_merge((array) ($cluster['riskFlags'] ?? []), (array) ($plan['riskFlags'] ?? [])), 30, 80);
        $facts['cars'] = demand_ai_safe_cars((array) ($brief['linkedCars'] ?? []));
        $facts['contentBrief'] = demand_ai_safe_brief($brief);
        if ($plan) {
            $facts['launchPlanItem'] = demand_ai_safe_plan($plan);
        }

        return demand_ai_finalize_facts($facts);
    }

    if ($entityType === 'launch_plan_item') {
        $plan = $entity;
        $cluster = demand_map_find_cluster((string) ($plan['clusterId'] ?? ''));
        $keywords = demand_ai_keywords_by_ids((array) ($plan['linkedKeywordIds'] ?? []));
        $facts['demand']['keywords'] = $keywords;
        $facts['demand']['cluster'] = $cluster ? demand_ai_safe_cluster($cluster) : null;
        $facts['demand']['primaryPhrase'] = (string) ($cluster['primaryPhrase'] ?? ($keywords[0]['phrase'] ?? $plan['title'] ?? ''));
        $facts['demand']['riskFlags'] = demand_ai_safe_list((array) ($plan['riskFlags'] ?? []), 30, 80);
        $facts['cars'] = demand_ai_safe_cars((array) ($plan['linkedCars'] ?? []));
        $facts['launchPlanItem'] = demand_ai_safe_plan($plan);

        return demand_ai_finalize_facts($facts);
    }

    if ($entityType === 'demand_cluster') {
        $cluster = $entity;
        $keywords = demand_ai_keywords_by_ids((array) ($cluster['keywordIds'] ?? []));
        $facts['demand']['keywords'] = $keywords;
        $facts['demand']['cluster'] = demand_ai_safe_cluster($cluster);
        $facts['demand']['primaryPhrase'] = (string) ($cluster['primaryPhrase'] ?? ($keywords[0]['phrase'] ?? ''));
        $facts['demand']['riskFlags'] = demand_ai_safe_list((array) ($cluster['riskFlags'] ?? []), 30, 80);
        $facts['cars'] = demand_ai_safe_cars((array) ($cluster['linkedCars'] ?? []));

        return demand_ai_finalize_facts($facts);
    }

    if ($entityType === 'car_hint') {
        $hint = $entity;
        $cluster = demand_map_find_cluster((string) ($hint['clusterId'] ?? ''));
        $plan = demand_map_find_plan((string) ($hint['launchPlanId'] ?? ''));
        $keywords = demand_ai_keywords_by_ids((array) ($hint['keywordIds'] ?? []));
        $facts['demand']['keywords'] = $keywords;
        $facts['demand']['cluster'] = $cluster ? demand_ai_safe_cluster($cluster) : null;
        $facts['demand']['primaryPhrase'] = (string) ($cluster['primaryPhrase'] ?? ($keywords[0]['phrase'] ?? ''));
        $facts['demand']['riskFlags'] = demand_ai_safe_list(array_merge((array) ($cluster['riskFlags'] ?? []), (array) ($plan['riskFlags'] ?? [])), 30, 80);
        $facts['cars'] = demand_ai_safe_cars([(string) ($hint['carId'] ?? '')]);
        $facts['carHint'] = demand_ai_safe_hint($hint);
        if ($plan) {
            $facts['launchPlanItem'] = demand_ai_safe_plan($plan);
        }

        return demand_ai_finalize_facts($facts);
    }

    return demand_ai_finalize_facts($facts);
}

function demand_ai_hash(array $payload): string
{
    return hash('sha256', json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function demand_ai_content_actions(): array
{
    return [
        'demand_car_hint_ai_generate',
        'demand_car_hint_ai_apply_edited',
        'demand_ai_generate_package',
        'demand_ai_preview_response',
        'demand_ai_apply_proposal',
        'demand_ai_reject_proposal',
        'demand_ai_api_ask',
        'demand_ai_api_apply_proposal',
        'demand_ai_api_reject',
        'demand_ai_copy_regenerate',
        'demand_ai_copy_apply',
        'demand_ai_copy_apply_edited',
        'demand_ai_copy_reject',
        'demand_ai_dialog_ask',
        'demand_ai_dialog_run_action',
        'demand_ai_dialog_clear',
        'demand_ai_dialog_stop',
    ];
}

function demand_ai_content_require_action_permission(string $action): void
{
    if ($action === 'demand_ai_reject_proposal' || $action === 'demand_ai_copy_reject') {
        require_permission('demand.ai.view');
        return;
    }
    if ($action === 'demand_ai_api_reject') {
        require_permission('demand.ai_api.view');
        return;
    }
    if ($action === 'demand_ai_dialog_clear' || $action === 'demand_ai_dialog_stop') {
        demand_ai_dialog_require('demand.ai_dialog.use');
    }
}

function demand_ai_content_entity_store(string $entityType): string
{
    return match ($entityType) {
        'draft' => LANDING_PAGE_DRAFTS_FILE,
        'content_brief' => DEMAND_CONTENT_BRIEFS_FILE,
        'car_hint' => DEMAND_CARD_OPTIMIZATION_HINTS_FILE,
        'launch_plan_item' => SEO_LAUNCH_PLAN_FILE,
        'demand_cluster' => DEMAND_KEYWORDS_FILE,
        default => '',
    };
}

function demand_ai_entity_version(string $entityType, string $entityId): string
{
    $entityType = demand_ai_safe_string($entityType, 80);
    $entityId = demand_ai_safe_string($entityId, 120);
    if ($entityType === '' || $entityId === '') {
        return hash('sha256', 'demand-ai:no-entity');
    }
    $entity = demand_ai_find_entity($entityType, $entityId);
    if (!$entity) {
        throw new RuntimeException('Связанный объект AI больше не существует. Обновите страницу.', 409);
    }
    return demand_ai_hash($entity);
}

function demand_ai_assert_entity_version(string $entityType, string $entityId, mixed $expected): void
{
    if (!is_string($expected) || $expected === '') {
        throw new RuntimeException('Форма AI устарела. Обновите страницу.', 409);
    }
    $current = demand_ai_entity_version($entityType, $entityId);
    if (!hash_equals($current, $expected)) {
        throw new RuntimeException('Данные изменились после подготовки AI-варианта. Сформируйте его заново.', 409);
    }
}

function demand_ai_content_payload_entity(array $payload): array
{
    $entityType = demand_ai_safe_string($payload['entity_type'] ?? '', 80);
    $entityId = demand_ai_safe_string($payload['entity_id'] ?? '', 120);
    if ($entityType === '' && !empty($payload['hint_id'])) {
        $entityType = 'car_hint';
        $entityId = demand_ai_safe_string($payload['hint_id'], 120);
    } elseif ($entityType === '' && !empty($payload['draft_id'])) {
        $entityType = 'draft';
        $entityId = demand_ai_safe_string($payload['draft_id'], 120);
    }
    return [$entityType, $entityId];
}

function demand_ai_content_intent(string $action, array $payload, string $scopeFilter): array
{
    foreach (['csrf_token', 'command_id', 'expected_version', 'tab', 'view'] as $technical) {
        unset($payload[$technical]);
    }
    if (isset($payload['ai_response_json'])) {
        $payload['ai_response_json_hash'] = hash('sha256', (string) $payload['ai_response_json']);
        unset($payload['ai_response_json']);
    }
    return [
        'action' => $action,
        'scopeFilter' => demand_normalize_scope_id($scopeFilter),
        'payload' => $payload,
    ];
}

function demand_ai_content_session_execute(string $action, array $payload, string $scopeFilter, callable $work): array
{
    if (!in_array($action, demand_ai_content_actions(), true)) {
        throw new LogicException('Unsupported Demand AI-content action.');
    }
    demand_ai_content_require_action_permission($action);
    $commandId = business_command_id($payload['command_id'] ?? null);
    [$entityType, $entityId] = demand_ai_content_payload_entity($payload);
    if ($entityType !== '' && $entityId !== '') {
        demand_ai_assert_entity_version($entityType, $entityId, $payload['expected_version'] ?? null);
    }
    $fingerprint = hash('sha256', json_encode(business_command_canonical([
        'actor' => current_admin_user(),
        'intent' => demand_ai_content_intent($action, $payload, $scopeFilter),
    ]), JSON_THROW_ON_ERROR | JSON_PRESERVE_ZERO_FRACTION));
    $key = $action . ':' . $commandId;
    $receipts = is_array($_SESSION['demand_ai_content_receipts'] ?? null) ? $_SESSION['demand_ai_content_receipts'] : [];
    if (array_key_exists($key, $receipts)) {
        $receipt = $receipts[$key];
        if (!is_array($receipt) || !is_string($receipt['fingerprint'] ?? null) || !is_array($receipt['result'] ?? null)) {
            throw new RuntimeException('Повреждён результат сессионной AI-операции.', 503);
        }
        if (!hash_equals($receipt['fingerprint'], $fingerprint)) {
            throw new RuntimeException('Идентификатор уже использован для другой AI-операции. Откройте новую форму.', 409);
        }
        return $receipt['result'];
    }
    $result = $work();
    if (!is_array($result)) {
        $result = [];
    }
    $receipts[$key] = [
        'fingerprint' => $fingerprint,
        'result' => $result,
        'completedAt' => now_iso(),
    ];
    $_SESSION['demand_ai_content_receipts'] = array_slice($receipts, -100, null, true);
    return $result;
}

function demand_ai_content_durable_execute(
    string $action,
    array $payload,
    string $scopeFilter,
    string $entityType,
    string $entityId,
    callable $work
): array {
    if (!in_array($action, demand_ai_content_actions(), true)) {
        throw new LogicException('Unsupported Demand AI-content action.');
    }
    demand_ai_content_require_action_permission($action);
    $store = demand_ai_content_entity_store($entityType);
    if ($store === '') {
        throw new RuntimeException('Для этого AI-действия не настроено защищённое хранилище.', 409);
    }
    $entity = demand_ai_find_entity($entityType, $entityId);
    if (!$entity) {
        throw new RuntimeException('Связанный объект AI не найден.', 409);
    }
    $receipt = business_command(
        $store,
        'demand-' . $action,
        business_command_id($payload['command_id'] ?? null),
        demand_ai_content_intent($action, $payload, $scopeFilter),
        static function () use ($entityType, $entityId): void {
            $current = demand_ai_find_entity($entityType, $entityId);
            if (!$current) {
                throw new RuntimeException('Связанный объект AI не найден.', 409);
            }
            demand_scope_guard($current, demand_ai_entity_view_permission($entityType));
        },
        static function () use ($entityType, $entityId, $payload, $work): array {
            demand_ai_assert_entity_version($entityType, $entityId, $payload['expected_version'] ?? null);
            $value = $work();
            return ['value' => is_array($value) ? $value : []];
        }
    );
    return is_array($receipt['value'] ?? null) ? $receipt['value'] : [];
}

function demand_ai_content_command_fields(string $action, string $entityType = '', string $entityId = ''): string
{
    if (!in_array($action, demand_ai_content_actions(), true)) {
        throw new LogicException('Unsupported Demand AI-content command fields.');
    }
    $version = demand_ai_entity_version($entityType, $entityId);
    return '<input type="hidden" name="command_id" value="' . e(bin2hex(random_bytes(16))) . '">'
        . '<input type="hidden" name="expected_version" value="' . e($version) . '">';
}

function demand_ai_record_event(string $entityType, string $entityId, string $event, string $message, array $meta = [], string $actor = ''): void
{
    $entity = demand_ai_find_entity($entityType, $entityId);
    $scopeId = $entity ? demand_ai_entity_scope($entity) : 'rent_rk';
    $actor = $actor !== '' ? $actor : (current_admin_user() ?: 'system');

    if ($entityType === 'draft') {
        demand_append_lifecycle_event($scopeId, 'landing_page_draft', $entityId, $event, $message, $actor, $meta);
        return;
    }

    analytics_record_event($event, [
        'scopeId' => $scopeId,
        'entityType' => $entityType,
        'entityId' => $entityId,
        'meta' => $meta,
    ]);
}

function demand_ai_build_package($entityType, $entityId, $task, $scopeId = ''): array
{
    require_permission('demand.ai.package');

    $entityType = demand_ai_safe_string($entityType, 80);
    $entityId = demand_ai_safe_string($entityId, 120);
    $task = demand_ai_safe_string($task, 100);
    $scopeId = demand_normalize_scope_id((string) $scopeId);

    if (!demand_ai_task_allowed_for_entity($entityType, $task)) {
        throw new RuntimeException('Эта задача AI недоступна для выбранного контекста.');
    }

    $entity = demand_ai_find_entity($entityType, $entityId);
    if (!$entity) {
        throw new RuntimeException('Контекст для AI не найден.');
    }
    demand_scope_guard($entity, demand_ai_entity_view_permission($entityType));

    $entityScope = demand_ai_entity_scope($entity);
    if ($scopeId !== '' && $scopeId !== 'all' && $scopeId !== $entityScope) {
        deny_scope_access();
    }

    $instructions = demand_ai_base_instructions();
    $source = [
        'entityType' => $entityType,
        'entityId' => $entityId,
        'scopeId' => $entityScope,
    ];
    $facts = demand_ai_build_facts($entityType, $entity);
    $testMode = demand_ai_package_test_mode($source, $facts);
    $finalDecision = demand_ai_final_decision($facts, $testMode);
    $facts['testMode'] = $testMode;
    $facts['finalDecision'] = $finalDecision;
    $source['testMode'] = $testMode;

    $package = [
        'schemaVersion' => 'rent-rk-ai-package-v1',
        'createdAt' => now_iso(),
        'task' => $task,
        'taskLabel' => demand_ai_task_label($task),
        'language' => 'ru',
        'testMode' => $testMode,
        'source' => $source,
        'facts' => $facts,
        'finalDecision' => $finalDecision,
        'mustPreserve' => $instructions['mustPreserve'],
        'mustNotPromise' => $instructions['mustNotPromise'],
        'forbiddenActions' => $instructions['forbiddenActions'],
        'expectedResponse' => demand_ai_expected_response_schema($entityType, $task),
    ];

    if (!$testMode) {
        demand_ai_record_event($entityType, $entityId, 'ai_package_generated', 'Сформирован безопасный пакет для ручного AI-помощника.', [
            'task' => $task,
            'packageHash' => demand_ai_hash($package),
        ]);
    }

    return $package;
}

function demand_ai_build_text_package(array $package): string
{
    $lines = [
        'Rent RK: безопасный пакет для AI',
        'Задача: ' . (string) ($package['taskLabel'] ?? $package['task'] ?? ''),
        'Контекст: ' . (string) ($package['source']['entityType'] ?? '') . ' / ' . (string) ($package['source']['entityId'] ?? ''),
        '',
        'Правила:',
    ];
    foreach ((array) ($package['mustPreserve'] ?? []) as $item) {
        $lines[] = '- ' . (string) $item;
    }
    foreach ((array) ($package['mustNotPromise'] ?? []) as $item) {
        $lines[] = '- ' . (string) $item;
    }
    foreach ((array) ($package['forbiddenActions'] ?? []) as $item) {
        $lines[] = '- ' . (string) $item;
    }
    $lines[] = '';
    $lines[] = 'Верни только JSON по expectedResponse. Не добавляй HTML, Markdown-обертки или действия публикации.';
    $lines[] = '';
    $lines[] = 'JSON package:';
    $lines[] = json_encode($package, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

    return implode("\n", $lines);
}

function demand_ai_allowed_response_fields(string $task): array
{
    return [
        'title',
        'h1',
        'metaDescription',
        'intro',
        'contentBlocks',
        'faq',
        'internalLinks',
        'internalLinkSuggestions',
        'publicBlockProposal',
        'adminNotes',
        'adminNote',
        'targetIntent',
        'mustAnswer',
        'mustNotPromise',
        'recommendedBlocks',
        'faqQuestions',
        'userQuestionMap',
        'safeContentBlocks',
        'contentGapReport',
        'firstScreenAnswer',
        'recommendedFaq',
        'recommendedInternalLinks',
        'recommendedCarCardHints',
        'userClarityScore',
        'aiSearchReadiness',
        'userClarityGoals',
        'aiSearchReadinessGoals',
        'pageRiskProfile',
        'suggestedText',
        'descriptionSuggestion',
        'message',
        'risks',
        'notesForAdmin',
        'outline',
    ];
}

function demand_ai_normalize_content_blocks($blocks): array
{
    return demand_ai_safe_content_blocks($blocks);
}

function demand_ai_validate_manual_response($task, $payload): array
{
    $task = demand_ai_safe_string($task, 100);
    if (!is_array($payload)) {
        throw new RuntimeException('Ответ AI должен быть JSON-объектом.');
    }

    if (isset($payload['task']) && demand_ai_safe_string($payload['task'], 100) !== $task) {
        throw new RuntimeException('Task в ответе AI не совпадает с выбранной задачей.');
    }

    $candidate = isset($payload['proposal']) && is_array($payload['proposal'])
        ? $payload['proposal']
        : (isset($payload['draftProposal']) && is_array($payload['draftProposal']) ? $payload['draftProposal'] : $payload);
    $allowed = array_fill_keys(demand_ai_allowed_response_fields($task), true);
    $ignored = [];
    $proposal = [];

    foreach ($candidate as $field => $value) {
        $field = (string) $field;
        if (!isset($allowed[$field])) {
            $ignored[] = $field;
            continue;
        }

        if (in_array($field, ['title', 'h1'], true)) {
            $proposal[$field] = demand_ai_safe_string($value, 160);
        } elseif ($field === 'metaDescription') {
            $proposal[$field] = demand_ai_safe_string($value, 260);
        } elseif (in_array($field, ['intro', 'adminNote', 'message'], true)) {
            $proposal[$field] = demand_ai_safe_string($value, 1200);
        } elseif ($field === 'suggestedText') {
            $proposal[$field] = demand_ai_safe_string($value, 1800);
        } elseif ($field === 'descriptionSuggestion') {
            $proposal[$field] = demand_ai_safe_string($value, 2200);
        } elseif ($field === 'contentBlocks') {
            $proposal[$field] = demand_ai_normalize_content_blocks($value);
        } elseif ($field === 'faq') {
            $proposal[$field] = demand_ai_safe_faq($value);
        } elseif (in_array($field, ['userQuestionMap', 'safeContentBlocks', 'contentGapReport', 'recommendedFaq', 'recommendedInternalLinks', 'recommendedCarCardHints', 'userClarityScore', 'aiSearchReadiness'], true)) {
            $proposal[$field] = demand_ai_safe_stage_c([$field => $value])[$field] ?? [];
        } elseif ($field === 'firstScreenAnswer') {
            $proposal[$field] = demand_ai_safe_string($value, 1200);
        } elseif (in_array($field, ['userClarityGoals', 'aiSearchReadinessGoals'], true)) {
            $score = is_array($value) ? $value : [];
            $proposal[$field] = [
                'level' => demand_ai_safe_string($score['level'] ?? '', 40),
                'score' => (int) ($score['score'] ?? 0),
                'summary' => demand_ai_safe_string($score['summary'] ?? '', 700),
            ];
        } elseif ($field === 'pageRiskProfile') {
            $risk = is_array($value) ? $value : [];
            $proposal[$field] = [
                'level' => demand_ai_safe_string($risk['level'] ?? '', 80),
                'summary' => demand_ai_safe_string($risk['summary'] ?? '', 700),
                'flags' => demand_ai_safe_list($risk['flags'] ?? [], 30, 80),
            ];
        } elseif ($field === 'internalLinks') {
            $proposal[$field] = demand_normalize_internal_links($value);
        } elseif ($field === 'internalLinkSuggestions') {
            $items = [];
            foreach ((array) $value as $suggestion) {
                $link = demand_normalize_internal_link($suggestion, ['source' => 'ai_response']);
                if ($link) {
                    $items[] = $link;
                }
            }
            $proposal[$field] = array_slice($items, 0, 20);
        } elseif ($field === 'publicBlockProposal') {
            $block = is_array($value) ? $value : [];
            $proposal[$field] = [
                'title' => demand_ai_safe_string($block['title'] ?? '', 120),
                'intro' => demand_ai_safe_string($block['intro'] ?? '', 400),
                'links' => demand_normalize_internal_links($block['links'] ?? []),
            ];
        } elseif ($field === 'adminNotes') {
            $proposal[$field] = demand_ai_safe_list($value, 20, 400);
        } elseif (in_array($field, ['mustAnswer', 'mustNotPromise', 'recommendedBlocks', 'faqQuestions', 'risks', 'notesForAdmin', 'outline'], true)) {
            $proposal[$field] = demand_ai_safe_list($value, 40, 300);
        } elseif ($field === 'targetIntent') {
            $proposal[$field] = demand_ai_safe_string($value, 1200);
        }
    }

    $proposal = array_filter($proposal, static fn($value): bool => !(is_string($value) && $value === '') && !(is_array($value) && $value === []));
    if ($proposal === []) {
        throw new RuntimeException('В ответе AI нет разрешенных полей для preview.');
    }

    return [
        'task' => $task,
        'proposal' => $proposal,
        'ignoredFields' => array_values(array_unique($ignored)),
        'summary' => demand_ai_safe_string($payload['summary'] ?? '', 1200),
        'styleUsed' => demand_ai_safe_string($payload['styleUsed'] ?? '', 120),
        'copyQuality' => demand_ai_normalize_copy_quality($payload['copyQuality'] ?? []),
        'mustCheckBeforeApply' => demand_ai_safe_list($payload['mustCheckBeforeApply'] ?? [], 16, 400),
        'notAllowed' => demand_ai_safe_list($payload['notAllowed'] ?? [], 16, 400),
        'warnings' => [
            'AI мог ошибиться.',
            'Проверьте цены, залог, наличие авто, условия подачи и любые обещания клиенту.',
            'Публикация и индексация не выполняются.',
        ],
    ];
}

function demand_ai_value_to_preview($value): string
{
    if (is_array($value)) {
        return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    }

    return (string) $value;
}

function demand_ai_diff_row(string $field, string $label, $before, $after): array
{
    $beforeText = demand_ai_value_to_preview($before);
    $afterText = demand_ai_value_to_preview($after);

    return [
        'field' => $field,
        'label' => $label,
        'before' => $beforeText,
        'after' => $afterText,
        'changed' => $beforeText !== $afterText,
    ];
}

function demand_ai_build_preview_diff($entityType, $entityId, $proposal): array
{
    if (!has_permission('demand.ai.view') && !has_permission('demand.ai_api.view')) {
        require_permission('demand.ai.view');
    }

    $entityType = demand_ai_safe_string($entityType, 80);
    $entityId = demand_ai_safe_string($entityId, 120);
    $proposal = is_array($proposal) ? $proposal : [];
    $entity = demand_ai_find_entity($entityType, $entityId);
    if (!$entity) {
        throw new RuntimeException('Контекст для preview не найден.');
    }
    demand_scope_guard($entity, demand_ai_entity_view_permission($entityType));

    $rows = [];
    $applySupported = in_array($entityType, ['draft', 'content_brief', 'car_hint'], true);

    if ($entityType === 'draft') {
        foreach ([
            'title' => 'title',
            'h1' => 'H1',
            'metaDescription' => 'meta description',
            'intro' => 'intro',
            'contentBlocks' => 'content blocks',
            'faq' => 'FAQ',
            'internalLinks' => 'internal links',
            'internalLinkSuggestions' => 'internal link suggestions',
            'adminNote' => 'admin note',
        ] as $field => $label) {
            if (!array_key_exists($field, $proposal)) {
                continue;
            }
            $before = $field === 'faq'
                ? demand_ai_extract_faq_from_blocks((array) ($entity['contentBlocks'] ?? []))
                : ($entity[$field] ?? ($field === 'internalLinks' ? [] : ''));
            $rows[] = demand_ai_diff_row($field, $label, $before, $proposal[$field]);
        }
    } elseif ($entityType === 'content_brief') {
        foreach ([
            'targetIntent' => 'targetIntent',
            'mustAnswer' => 'mustAnswer',
            'mustNotPromise' => 'mustNotPromise',
            'recommendedBlocks' => 'recommendedBlocks',
            'faqQuestions' => 'faqQuestions',
            'userQuestionMap' => 'userQuestionMap',
            'safeContentBlocks' => 'safeContentBlocks',
            'contentGapReport' => 'contentGapReport',
            'firstScreenAnswer' => 'firstScreenAnswer',
            'recommendedFaq' => 'recommendedFaq',
            'recommendedInternalLinks' => 'recommendedInternalLinks',
            'recommendedCarCardHints' => 'recommendedCarCardHints',
            'pageRiskProfile' => 'pageRiskProfile',
            'userClarityGoals' => 'userClarityGoals',
            'aiSearchReadinessGoals' => 'aiSearchReadinessGoals',
        ] as $field => $label) {
            if (array_key_exists($field, $proposal)) {
                $rows[] = demand_ai_diff_row($field, $label, $entity[$field] ?? [], $proposal[$field]);
            }
        }
    } elseif ($entityType === 'car_hint') {
        foreach ([
            'suggestedText' => 'suggestedText',
            'descriptionSuggestion' => 'descriptionSuggestion',
            'message' => 'message',
        ] as $field => $label) {
            if (array_key_exists($field, $proposal)) {
                $rows[] = demand_ai_diff_row($field, $label, $entity[$field] ?? '', $proposal[$field]);
            }
        }
    } else {
        foreach ([
            'title' => 'title',
            'outline' => 'outline',
            'mustAnswer' => 'mustAnswer',
            'faq' => 'FAQ',
        ] as $field => $label) {
            if (array_key_exists($field, $proposal)) {
                $rows[] = demand_ai_diff_row($field, $label, '', $proposal[$field]);
            }
        }
    }

    foreach (['risks' => 'risks', 'notesForAdmin' => 'notesForAdmin'] as $field => $label) {
        if (array_key_exists($field, $proposal)) {
            $rows[] = demand_ai_diff_row($field, $label, '', $proposal[$field]);
        }
    }

    return [
        'entityType' => $entityType,
        'entityId' => $entityId,
        'scopeId' => demand_ai_entity_scope($entity),
        'applySupported' => $applySupported,
        'rows' => $rows,
        'changedCount' => count(array_filter($rows, static fn(array $row): bool => !empty($row['changed']))),
        'warnings' => [
            'AI мог ошибиться.',
            'Проверьте цены, залог, наличие авто, условия подачи и любые обещания клиенту.',
            'Публикация и индексация не выполняются.',
        ],
    ];
}

function demand_ai_merge_faq_into_blocks(array $blocks, array $faq): array
{
    if (!$faq) {
        return $blocks;
    }

    foreach ($blocks as $index => $block) {
        if (is_array($block) && (string) ($block['type'] ?? '') === 'faq') {
            $blocks[$index]['items'] = $faq;
            if ((string) ($blocks[$index]['title'] ?? '') === '') {
                $blocks[$index]['title'] = 'FAQ';
            }
            return $blocks;
        }
    }

    $blocks[] = [
        'type' => 'faq',
        'visibility' => 'public',
        'title' => 'FAQ',
        'items' => $faq,
    ];

    return $blocks;
}

function demand_ai_proposal_changes_draft(array $draft, array $updates): bool
{
    foreach (['title', 'h1', 'metaDescription', 'intro', 'contentBlocks', 'internalLinks', 'internalLinkSuggestions', 'adminNote'] as $field) {
        if (!array_key_exists($field, $updates)) {
            continue;
        }
        if (json_encode($draft[$field] ?? null, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !== json_encode($updates[$field], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) {
            return true;
        }
    }

    return false;
}

function demand_ai_car_hint_allowed_apply_fields(): array
{
    return ['message', 'suggestedText', 'descriptionSuggestion'];
}

function demand_ai_clean_car_hint_text($value, int $maxLength): string
{
    $text = (string) $value;
    $text = preg_replace('/<\s*(script|style)[^>]*>.*?<\s*\/\s*\1\s*>/is', ' ', $text) ?? $text;
    $text = strip_tags($text);
    $text = preg_replace('/\b(?:javascript|data):/i', '', $text) ?? $text;

    return demand_ai_safe_string($text, $maxLength);
}

function demand_ai_sanitize_car_hint_proposal(array $proposal): array
{
    $clean = [];
    foreach (demand_ai_car_hint_allowed_apply_fields() as $field) {
        if (!array_key_exists($field, $proposal)) {
            continue;
        }
        $limit = $field === 'descriptionSuggestion' ? 2200 : ($field === 'suggestedText' ? 1800 : 1200);
        $value = demand_ai_clean_car_hint_text($proposal[$field], $limit);
        if ($value !== '') {
            $clean[$field] = $value;
        }
    }

    return $clean;
}

function demand_ai_apply_car_hint_proposal(string $entityId, array $proposal, string $adminUser, array $options = []): array
{
    if (!has_permission('demand.ai.apply') && !has_permission('demand.ai_api.apply')) {
        require_permission('demand.ai.apply');
    }

    $hint = demand_ai_find_car_hint($entityId);
    if (!$hint) {
        throw new RuntimeException('Подсказка для авто не найдена.');
    }
    demand_scope_guard($hint, 'demand.card_hints.manage');

    $updates = demand_ai_sanitize_car_hint_proposal($proposal);
    if (!$updates) {
        return ['entity' => $hint, 'changed' => false];
    }

    $data = demand_map_read_card_hints();
    foreach ($data['items'] as $index => $item) {
        if (!is_array($item) || (string) ($item['id'] ?? '') !== $entityId) {
            continue;
        }

        $edited = !empty($options['edited']);
        $eventName = (string) ($options['eventName'] ?? ($edited ? 'ai_generated_proposal_edited_and_applied' : 'ai_generated_proposal_applied'));
        $status = $edited ? 'applied_with_manual_edit' : 'applied_to_hint';
        $data['items'][$index] = array_merge($item, $updates, [
            'aiProposalStatus' => $status,
            'aiProposalAppliedAt' => now_iso(),
            'aiProposalAppliedBy' => demand_ai_safe_string($adminUser ?: 'system', 120),
            'aiProposalSource' => demand_ai_safe_string($options['source'] ?? 'ai_preview', 80),
            'aiProposalEdited' => $edited,
            'aiProposalHash' => demand_ai_hash($updates),
            'updatedAt' => now_iso(),
        ]);
        demand_map_save_card_hints($data);
        analytics_record_event($eventName, [
            'scopeId' => (string) ($item['scope_id'] ?? 'rent_rk'),
            'entityType' => 'car_hint',
            'entityId' => $entityId,
            'meta' => [
                'proposalHash' => demand_ai_hash($updates),
                'source' => demand_ai_safe_string($options['source'] ?? 'ai_preview', 80),
                'runId' => demand_ai_safe_string($options['runId'] ?? '', 80),
                'edited' => $edited,
                'message' => $edited
                    ? 'AI подготовил текст, пользователь отредактировал его перед применением.'
                    : 'AI подготовил текст, пользователь применил вариант к подсказке.',
            ],
        ]);

        return ['entity' => $data['items'][$index], 'changed' => true];
    }

    return ['entity' => $hint, 'changed' => false];
}

function demand_ai_apply_manual_proposal($entityType, $entityId, $proposal, $adminUser): array
{
    if (!has_permission('demand.ai.apply') && !has_permission('demand.ai_api.apply')) {
        require_permission('demand.ai.apply');
    }

    $entityType = demand_ai_safe_string($entityType, 80);
    $entityId = demand_ai_safe_string($entityId, 120);
    $proposal = is_array($proposal) ? $proposal : [];
    $adminUser = demand_ai_safe_string($adminUser, 120) ?: (current_admin_user() ?: 'system');

    if ($entityType === 'draft') {
        $draft = demand_find_draft($entityId);
        if (!$draft) {
            throw new RuntimeException('Черновик не найден.');
        }
        demand_scope_guard($draft, 'demand.drafts.edit');
        $updates = [];
        foreach (['title', 'h1', 'metaDescription', 'intro', 'adminNote'] as $field) {
            if (array_key_exists($field, $proposal)) {
                $updates[$field] = $proposal[$field];
            }
        }
        if (array_key_exists('contentBlocks', $proposal)) {
            $updates['contentBlocks'] = demand_ai_normalize_content_blocks($proposal['contentBlocks']);
        }
        if (array_key_exists('faq', $proposal)) {
            $updates['contentBlocks'] = demand_ai_merge_faq_into_blocks(
                $updates['contentBlocks'] ?? demand_ai_safe_content_blocks($draft['contentBlocks'] ?? []),
                demand_ai_safe_faq($proposal['faq'])
            );
        }
        if (array_key_exists('internalLinks', $proposal)) {
            $updates['internalLinks'] = demand_normalize_internal_links($proposal['internalLinks']);
        }
        if (array_key_exists('internalLinkSuggestions', $proposal)) {
            $updates['internalLinkSuggestions'] = [
                'summary' => 'AI подготовил варианты внутренних ссылок. Применение выполняется отдельным подтверждением.',
                'internalLinkSuggestions' => array_values(array_filter((array) $proposal['internalLinkSuggestions'], 'is_array')),
                'publicBlockProposal' => is_array($proposal['publicBlockProposal'] ?? null) ? $proposal['publicBlockProposal'] : [],
                'adminNotes' => demand_ai_safe_list($proposal['adminNotes'] ?? [], 20, 400),
                'updatedAt' => now_iso(),
            ];
        }
        if ($updates) {
            $stageCKeyword = null;
            foreach ((array) ($draft['sourceKeywordIds'] ?? []) as $sourceKeywordId) {
                $stageCKeyword = demand_find_keyword((string) $sourceKeywordId);
                if ($stageCKeyword) {
                    break;
                }
            }
            if ($stageCKeyword) {
                $linkedCars = array_values(array_filter(array_map('strval', (array) ($draft['linkedCars'] ?? []))));
                $cars = array_values(array_filter(array_map(static fn(string $slug): ?array => find_car($slug), $linkedCars)));
                $stageC = demand_stage_c_analyze_keyword($stageCKeyword, [
                    'cars' => $cars,
                    'contentBlocks' => (array) ($updates['contentBlocks'] ?? $draft['contentBlocks'] ?? []),
                    'intro' => (string) ($updates['intro'] ?? $draft['intro'] ?? ''),
                ]);
                foreach ([
                    'userQuestionMap',
                    'safeContentBlocks',
                    'contentGapReport',
                    'mustAnswer',
                    'mustNotPromise',
                    'recommendedFaq',
                    'recommendedInternalLinks',
                    'recommendedCarCardHints',
                    'userClarityScore',
                    'aiSearchReadiness',
                ] as $field) {
                    $updates[$field] = $stageC[$field] ?? [];
                }
            }
        }

        if (!demand_ai_proposal_changes_draft($draft, $updates)) {
            return ['entity' => $draft, 'changed' => false];
        }

        demand_create_landing_page_version($draft, 'before_ai_manual_proposal_apply', $adminUser);
        $updated = array_merge($draft, $updates, [
            'readinessStatus' => 'not_checked',
            'readinessChecks' => [],
            'lastReadinessCheckAt' => null,
            'updatedAt' => now_iso(),
        ]);
        $updated = demand_update_draft_item($updated);
        demand_append_lifecycle_event(
            (string) ($updated['scope_id'] ?? 'rent_rk'),
            'landing_page_draft',
            $entityId,
            'ai_manual_proposal_applied',
            'Применено ручное предложение AI. Публикация и индексация не выполнялись; готовность нужно проверить заново.',
            $adminUser,
            ['proposalHash' => demand_ai_hash($proposal)]
        );
        analytics_record_event('ai_manual_proposal_applied', [
            'scopeId' => (string) ($updated['scope_id'] ?? 'rent_rk'),
            'entityType' => 'landing_page_draft',
            'entityId' => $entityId,
            'meta' => ['proposalHash' => demand_ai_hash($proposal)],
        ]);

        return ['entity' => $updated, 'changed' => true];
    }

    if ($entityType === 'content_brief') {
        $brief = demand_ai_find_content_brief($entityId);
        if (!$brief) {
            throw new RuntimeException('ТЗ для страницы не найдено.');
        }
        demand_scope_guard($brief, 'demand.content_briefs.manage');
        $updates = [];
        foreach ([
            'targetIntent',
            'mustAnswer',
            'mustNotPromise',
            'recommendedBlocks',
            'faqQuestions',
            'userQuestionMap',
            'safeContentBlocks',
            'contentGapReport',
            'firstScreenAnswer',
            'recommendedFaq',
            'recommendedInternalLinks',
            'recommendedCarCardHints',
            'pageRiskProfile',
            'userClarityGoals',
            'aiSearchReadinessGoals',
        ] as $field) {
            if (array_key_exists($field, $proposal)) {
                $updates[$field] = $proposal[$field];
            }
        }
        if (!$updates) {
            return ['entity' => $brief, 'changed' => false];
        }
        $data = demand_map_read_content_briefs();
        foreach ($data['items'] as $index => $item) {
            if (is_array($item) && (string) ($item['id'] ?? '') === $entityId) {
                $data['items'][$index] = array_merge($item, $updates, ['updatedAt' => now_iso()]);
                demand_map_save_content_briefs($data);
                analytics_record_event('ai_manual_proposal_applied', [
                    'scopeId' => (string) ($item['scope_id'] ?? 'rent_rk'),
                    'entityType' => 'content_brief',
                    'entityId' => $entityId,
                    'meta' => ['proposalHash' => demand_ai_hash($proposal)],
                ]);

                return ['entity' => $data['items'][$index], 'changed' => true];
            }
        }
    }

    if ($entityType === 'car_hint') {
        return demand_ai_apply_car_hint_proposal((string) $entityId, (array) $proposal, (string) $adminUser, [
            'source' => 'manual_package',
            'eventName' => 'ai_manual_proposal_applied',
            'edited' => false,
        ]);
    }

    throw new RuntimeException('Для этого контекста MVP поддерживает только preview без применения.');
}
