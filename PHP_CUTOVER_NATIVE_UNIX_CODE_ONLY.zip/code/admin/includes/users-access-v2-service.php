<?php

declare(strict_types=1);

/**
 * Users & Access V2 domain service.
 *
 * This file intentionally contains no request handling. HTTP controllers, legacy
 * writers and QA call the same locked operations below.
 */

function uav2_permission_catalog(): array
{
    static $catalog = null;
    if (is_array($catalog)) {
        return $catalog;
    }

    $catalog = [
        ['id' => 'work', 'label' => 'Рабочий день и задачи', 'items' => [
            ['key' => 'dashboard.view', 'label' => 'Открывать рабочий день', 'detail' => 'Сводка текущих задач и операций.'],
            ['key' => 'tasks.view', 'label' => 'Просматривать задачи', 'detail' => 'Список и карточки доступных задач.'],
            ['key' => 'tasks.edit', 'label' => 'Выполнять задачи', 'detail' => 'Изменение статуса и рабочих данных задачи.'],
            ['key' => 'tasks.manage', 'label' => 'Управлять задачами', 'detail' => 'Создание, назначение и контроль задач.'],
        ]],
        ['id' => 'requests', 'label' => 'Заявки', 'items' => [
            ['key' => 'requests.view', 'label' => 'Просматривать заявки', 'detail' => 'Список и карточки заявок в разрешённом парке.'],
            ['key' => 'requests.edit', 'label' => 'Редактировать заявки', 'detail' => 'Обработка и изменение заявок.'],
            ['key' => 'requests.scoped_edit', 'label' => 'Редактировать заявки своего парка', 'detail' => 'Изменения только в назначенном внешнем парке.'],
            ['key' => 'requests.delete', 'label' => 'Удалять заявки', 'detail' => 'Опасное действие для отменённых заявок.'],
        ]],
        ['id' => 'rentals', 'label' => 'Аренды и возврат', 'items' => [
            ['key' => 'rentals.view', 'label' => 'Просматривать аренды', 'detail' => 'Список и карточки аренд в разрешённом парке.'],
            ['key' => 'rentals.edit', 'label' => 'Создавать и изменять аренды', 'detail' => 'Операционная работа с арендой и выдачей.'],
            ['key' => 'rentals.return.accept', 'label' => 'Принимать возврат автомобиля', 'detail' => 'Рабочая форма возврата в разрешённом контуре.'],
            ['key' => 'rentals.issue.allow_without_photos', 'label' => 'Разрешать выдачу без фотографий', 'detail' => 'Исключение для выдачи; требует осознанного назначения.'],
            ['key' => 'rentals.archive_finance.manage', 'label' => 'Управлять финансами архивных договоров', 'detail' => 'Точечная работа с подтверждёнными архивными данными.'],
            ['key' => 'rentals.delete', 'label' => 'Удалять аренды', 'detail' => 'Опасное действие через защищённый сценарий.'],
        ]],
        ['id' => 'customers', 'label' => 'Клиенты', 'items' => [
            ['key' => 'customers.view', 'label' => 'Просматривать клиентов', 'detail' => 'Список и карточки клиентов в разрешённом парке.'],
            ['key' => 'customers.manage', 'label' => 'Редактировать клиентов', 'detail' => 'Создание и изменение карточек клиентов.'],
            ['key' => 'customers.delete', 'label' => 'Удалять клиентов', 'detail' => 'Опасное действие с карточками клиентов.'],
        ]],
        ['id' => 'fleet', 'label' => 'Автопарк и календарь', 'items' => [
            ['key' => 'cars.manage', 'label' => 'Управлять автопарком', 'detail' => 'Операции со списком и карточками автомобилей.'],
            ['key' => 'cars.view', 'label' => 'Просматривать автомобили', 'detail' => 'Автопарк и безопасные данные карточек.'],
            ['key' => 'cars.edit', 'label' => 'Редактировать автомобили', 'detail' => 'Контент и рабочие параметры карточки.'],
            ['key' => 'cars.publish', 'label' => 'Публиковать карточки автомобилей', 'detail' => 'Обновление публичной карточки после изменений.'],
            ['key' => 'cars.identity.edit', 'label' => 'Редактировать VIN, госномер и СТС', 'detail' => 'Идентификационные и регистрационные сведения.'],
            ['key' => 'cars.market_value.edit', 'label' => 'Редактировать рыночную стоимость', 'detail' => 'Служебная стоимость автомобиля.'],
            ['key' => 'calendar.view', 'label' => 'Просматривать календарь парка', 'detail' => 'Занятость и доступность автомобилей.'],
            ['key' => 'calendar.edit', 'label' => 'Редактировать календарь', 'detail' => 'Изменение доступности автомобилей.'],
            ['key' => 'calendar.scoped_edit', 'label' => 'Редактировать календарь своего парка', 'detail' => 'Изменения только в назначенном внешнем парке.'],
        ]],
        ['id' => 'finance', 'label' => 'Финансы', 'items' => [
            ['key' => 'analytics.view', 'label' => 'Просматривать аналитику', 'detail' => 'Показатели и отчёты разрешённого парка.'],
            ['key' => 'finance.view', 'label' => 'Просматривать финансы', 'detail' => 'Суммы, оплаты, залоги и отчёты.'],
            ['key' => 'finance.manage', 'label' => 'Управлять финансами', 'detail' => 'Оплаты, залоги, возвраты и финансовые действия.', 'requires' => 'finance.view'],
            ['key' => 'billing.view', 'label' => 'Просматривать расчёты своего парка', 'detail' => 'Биллинг и взаиморасчёты внешнего парка.'],
        ]],
        ['id' => 'tariffs', 'label' => 'Тарифы и залог', 'items' => [
            ['key' => 'tariffs.view', 'label' => 'Просматривать тарифы и залоги', 'detail' => 'Условия тарифа в своём разрешённом контуре.'],
            ['key' => 'tariffs.edit', 'label' => 'Редактировать тарифы и залоги', 'detail' => 'Изменение условий; просмотр обязателен.', 'requires' => 'tariffs.view'],
        ]],
        ['id' => 'fines', 'label' => 'Штрафы', 'items' => [
            ['key' => 'fines.view', 'label' => 'Просматривать штрафы', 'detail' => 'Список штрафов разрешённого парка.'],
            ['key' => 'fines.check', 'label' => 'Проверять штрафы', 'detail' => 'Запуск и обработка штатной проверки.'],
            ['key' => 'fines.settings', 'label' => 'Настраивать штрафы своего парка', 'detail' => 'Параметры проверки для внешнего парка.'],
        ]],
        ['id' => 'showcase', 'label' => 'Витрина и продвижение', 'items' => [
            ['key' => 'promo.manage', 'label' => 'Редактировать продвижение', 'detail' => 'Промо-данные и настройки показа.'],
            ['key' => 'promo.publish', 'label' => 'Публиковать продвижение', 'detail' => 'Применение подготовленных промо-изменений.'],
            ['key' => 'promo.moderate', 'label' => 'Проверять промо-материалы', 'detail' => 'Модерация подготовленных материалов.'],
            ['key' => 'promo.policy.manage', 'label' => 'Настраивать правила продвижения', 'detail' => 'Политики и ограничения публикации.'],
        ]],
        ['id' => 'demand', 'label' => 'Спрос и AI', 'items' => [
            ['key' => 'demand.ai.view', 'label' => 'Просматривать AI-помощника спроса', 'detail' => 'Безопасный AI-блок в разделе спроса.'],
            ['key' => 'demand.ai.package', 'label' => 'Формировать пакет для AI', 'detail' => 'Подготовка безопасного набора данных для анализа.'],
            ['key' => 'demand.ai.apply', 'label' => 'Применять предложения AI', 'detail' => 'Ручное применение после просмотра изменений.'],
            ['key' => 'demand.ai_api.view', 'label' => 'Просматривать API-помощника', 'detail' => 'Контекстный помощник без показа секретов.'],
            ['key' => 'demand.ai_api.use', 'label' => 'Использовать API-помощника', 'detail' => 'Отправка только разрешённого контекста.'],
            ['key' => 'demand.ai_api.apply', 'label' => 'Применять предложения API-помощника', 'detail' => 'Ручное применение разрешённых полей.'],
            ['key' => 'demand.ai_api.settings.manage', 'label' => 'Настраивать API-помощника', 'detail' => 'Модель, лимиты и включение помощника.'],
            ['key' => 'demand.ai_api.logs.view', 'label' => 'Просматривать журнал API-помощника', 'detail' => 'Безопасные статусы и метаданные запусков.'],
            ['key' => 'demand.ai_dialog.view', 'label' => 'Просматривать диалоговый AI', 'detail' => 'Правая AI-панель раздела спроса.'],
            ['key' => 'demand.ai_dialog.use', 'label' => 'Использовать диалоговый AI', 'detail' => 'Создание безопасного плана действий.'],
            ['key' => 'demand.ai_workflow.run', 'label' => 'Запускать AI-сценарий без записи', 'detail' => 'Выполнение только действий просмотра.'],
            ['key' => 'demand.ai_workflow.apply', 'label' => 'Подтверждать AI-сценарий', 'detail' => 'Ручное подтверждение разрешённых действий.'],
        ]],
        ['id' => 'partners', 'label' => 'Партнёры', 'items' => [
            ['key' => 'partner.portal', 'label' => 'Открывать кабинет представителя', 'detail' => 'Личные ссылки и заявки назначенного канала.'],
            ['key' => 'partners.manage', 'label' => 'Управлять партнёрскими каналами', 'detail' => 'Каналы, представители и параметры комиссии.'],
        ]],
        ['id' => 'system', 'label' => 'Система и настройки', 'items' => [
            ['key' => 'scope.self.view', 'label' => 'Открывать настройки своего парка', 'detail' => 'Собственный внешний парк без доступа к чужим.'],
            ['key' => 'database.scoped_export', 'label' => 'Выгружать данные своего парка', 'detail' => 'Ограниченный экспорт только своего контура.'],
            ['key' => 'users.scoped.manage', 'label' => 'Управлять менеджерами своего парка', 'detail' => 'Создание, отключение и разрешённые тарифные права сотрудников своего парка.'],
            ['key' => 'users.manage', 'label' => 'Управлять пользователями', 'detail' => 'Глобальное управление учётными записями.'],
            ['key' => 'scopes.manage', 'label' => 'Управлять парками и контурами', 'detail' => 'Глобальные настройки контуров.'],
            ['key' => 'settings.manage', 'label' => 'Изменять системные настройки', 'detail' => 'Глобальные параметры Rent RK.'],
            ['key' => 'access-rules.manage', 'label' => 'Управлять межконтурными доступами', 'detail' => 'Правила доступа к автомобилям других парков.'],
            ['key' => 'audit.view', 'label' => 'Просматривать журнал действий', 'detail' => 'История административных операций.'],
            ['key' => 'publication.manage', 'label' => 'Управлять публикацией сайта', 'detail' => 'Глобальные операции публикации.'],
        ]],
    ];

    return $catalog;
}

function uav2_permission_keys(): array
{
    $keys = [];
    foreach (uav2_permission_catalog() as $group) {
        foreach ((array) ($group['items'] ?? []) as $item) {
            $key = (string) ($item['key'] ?? '');
            if ($key !== '') {
                $keys[$key] = true;
            }
        }
    }
    return array_keys($keys);
}

function uav2_permission_dependencies(): array
{
    $dependencies = [];
    foreach (uav2_permission_catalog() as $group) {
        foreach ((array) ($group['items'] ?? []) as $item) {
            if (!empty($item['requires'])) {
                $dependencies[(string) $item['key']] = (string) $item['requires'];
            }
        }
    }
    return $dependencies;
}

function uav2_normalize_string_list(mixed $value, bool $strict = false): array
{
    if (!is_array($value)) {
        if ($strict) {
            throw new InvalidArgumentException('Список разрешений имеет неверный формат.');
        }
        return [];
    }
    $result = [];
    foreach ($value as $item) {
        if (!is_string($item)) {
            if ($strict) {
                throw new InvalidArgumentException('Разрешение должно быть строкой.');
            }
            continue;
        }
        $item = trim($item);
        if ($item !== '') {
            $result[$item] = true;
        }
    }
    $result = array_keys($result);
    sort($result);
    return $result;
}

function uav2_user_denied_permissions(array $user): array
{
    if (!array_key_exists('deniedPermissions', $user)) {
        return [];
    }
    if (!is_array($user['deniedPermissions'])) {
        return ['*'];
    }
    $known = array_fill_keys(uav2_permission_keys(), true);
    $result = [];
    foreach ($user['deniedPermissions'] as $permission) {
        if (!is_string($permission) || !isset($known[$permission])) {
            return ['*'];
        }
        $result[$permission] = true;
    }
    return array_keys($result);
}

function uav2_user_permission_state_error(array $user): string
{
    if (array_key_exists('deniedPermissions', $user) && !is_array($user['deniedPermissions'])) {
        return 'Список персональных запретов имеет неверный формат.';
    }
    $known = array_fill_keys(uav2_permission_keys(), true);
    foreach ((array) ($user['deniedPermissions'] ?? []) as $permission) {
        if (!is_string($permission) || !isset($known[$permission])) {
            return 'Список персональных запретов содержит неизвестное разрешение.';
        }
    }
    $grants = admin_user_permissions($user);
    $denied = uav2_user_denied_permissions($user);
    if (array_intersect($grants, $denied)) {
        return 'Одно разрешение одновременно выдано и запрещено.';
    }
    if (admin_user_is_platform_root($user) && $denied) {
        return 'Для Root обнаружен недопустимый персональный запрет.';
    }
    return '';
}

function uav2_user_base_permissions(array $user): array
{
    $role = (string) ($user['role'] ?? '');
    if (admin_user_is_platform_root($user)) {
        return uav2_permission_keys();
    }
    if ($role === 'admin') {
        return [];
    }
    $base = role_permissions()[$role] ?? [];
    if ($role === 'manager' && !admin_user_is_scoped_manager($user)) {
        $base[] = rental_return_accept_permission_key();
        $base[] = rental_issue_without_photos_permission_key();
    }
    if ($role === 'lessor') {
        $base = array_merge($base, [
            'users.scoped.manage', 'tariffs.view', 'tariffs.edit', 'cars.identity.edit',
            'cars.market_value.edit', 'rentals.delete',
        ]);
    }
    $base = array_values(array_unique(array_filter(array_map('strval', $base), static fn(string $key): bool => $key !== '*')));
    sort($base);
    return $base;
}

function uav2_user_has_permission(array $user, string $permission): bool
{
    if ($permission === '' || empty($user['active']) || !lessor_user_is_allowed($user)
        || uav2_user_permission_state_error($user) !== '') {
        return false;
    }
    if (admin_user_is_platform_root($user)) {
        return true;
    }
    $denied = uav2_user_denied_permissions($user);
    if (in_array('*', $denied, true) || in_array($permission, $denied, true)) {
        return false;
    }
    $dependency = uav2_permission_dependencies()[$permission] ?? '';
    if ($dependency !== '' && !uav2_user_has_permission($user, $dependency)) {
        return false;
    }
    $granted = array_fill_keys(array_merge(uav2_user_base_permissions($user), admin_user_permissions($user)), true);
    if (isset($granted[$permission])) {
        return true;
    }
    foreach (uav2_permission_dependencies() as $child => $parent) {
        if ($parent === $permission && isset($granted[$child]) && !in_array($child, $denied, true)) {
            return true;
        }
    }
    return false;
}

function uav2_user_effective_permissions(array $user): array
{
    $result = [];
    foreach (uav2_permission_keys() as $permission) {
        if (uav2_user_has_permission($user, $permission)) {
            $result[] = $permission;
        }
    }
    return $result;
}

function uav2_manager_extra_permission_keys(bool $scoped): array
{
    if ($scoped) {
        return [
            'tariffs.view', 'tariffs.edit', 'cars.identity.edit', 'cars.market_value.edit',
            rental_return_accept_permission_key(), rental_issue_without_photos_permission_key(),
            rental_archive_finance_manage_permission_key(),
        ];
    }
    return [
        'cars.view', 'cars.edit', 'cars.publish', 'analytics.view', 'finance.view', 'finance.manage',
        rental_return_accept_permission_key(), rental_issue_without_photos_permission_key(),
        rental_archive_finance_manage_permission_key(),
        'demand.ai.view', 'demand.ai.package', 'demand.ai.apply', 'demand.ai_api.view',
        'demand.ai_api.use', 'demand.ai_api.apply', 'demand.ai_api.settings.manage',
        'demand.ai_api.logs.view', 'demand.ai_dialog.view', 'demand.ai_dialog.use',
        'demand.ai_workflow.run', 'demand.ai_workflow.apply', 'partners.manage',
        'tariffs.view', 'tariffs.edit', 'cars.identity.edit', 'cars.market_value.edit',
        'customers.delete', 'requests.delete', 'rentals.delete',
    ];
}

function uav2_profile_definitions(): array
{
    return [
        ['id' => 'admin', 'role' => 'admin', 'label' => 'Root', 'description' => 'Управляет всей системой, пользователями, парками и настройками.', 'scope' => 'Rent RK', 'summary' => 'Все полномочия'],
        ['id' => 'manager', 'role' => 'manager', 'label' => 'Менеджер', 'description' => 'Работает с операционными разделами в одном назначенном парке.', 'scope' => 'Один парк', 'summary' => 'Профиль и точечные настройки'],
        ['id' => 'manager_cashier', 'role' => 'manager', 'label' => 'Менеджер-кассир', 'description' => 'Менеджер Rent RK с просмотром и управлением финансами.', 'scope' => 'Только Rent RK', 'summary' => 'Включены финансовые действия'],
        ['id' => 'lessor_admin', 'role' => 'lessor', 'label' => 'Администратор парка', 'description' => 'Управляет своим парком и менеджерами этого парка в пределах делегирования.', 'scope' => 'Один внешний парк', 'summary' => 'Без глобальных прав'],
        ['id' => 'partner', 'role' => 'partner', 'label' => 'Партнёр / представитель', 'description' => 'Видит кабинет и историю своего партнёрского канала.', 'scope' => 'Один канал', 'summary' => 'Нет доступа к внутренней CRM'],
        ['id' => 'executor', 'role' => 'executor', 'label' => 'Исполнитель', 'description' => 'Работает только с назначенными задачами.', 'scope' => 'Rent RK', 'summary' => 'Без пользовательских настроек'],
    ];
}

function uav2_profile_for_user(array $user): string
{
    $role = (string) ($user['role'] ?? 'manager');
    if ($role === 'admin') {
        return admin_user_is_platform_root($user) ? 'admin' : 'invalid_admin';
    }
    if ($role === 'lessor') {
        return 'lessor_admin';
    }
    if ($role === 'manager' && !admin_user_is_scoped_manager($user) && uav2_user_has_permission($user, 'finance.manage')) {
        return 'manager_cashier';
    }
    return $role;
}

function uav2_record_token(array $record): string
{
    $secret = hash('sha256', (defined('ADMIN_PASSWORD_HASH') ? ADMIN_PASSWORD_HASH : '') . '|' . (defined('ADMIN_PASSWORD_SALT') ? ADMIN_PASSWORD_SALT : '') . '|uav2-record-v1');
    ksort($record);
    $json = json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return hash_hmac('sha256', is_string($json) ? $json : '', $secret);
}

function uav2_user_record_token(array $user): string
{
    return uav2_record_token([
        'login' => (string) ($user['login'] ?? ''),
        'name' => (string) ($user['name'] ?? ''),
        'role' => (string) ($user['role'] ?? ''),
        'active' => !empty($user['active']),
        'archived' => !empty($user['archived']),
        'lessorSlug' => (string) ($user['lessorSlug'] ?? ''),
        'partnerSlug' => (string) ($user['partnerSlug'] ?? ''),
        'partnerAgentSlug' => (string) ($user['partnerAgentSlug'] ?? ''),
        'permissions' => admin_user_permissions($user),
        'deniedPermissions' => uav2_user_denied_permissions($user),
        'passwordState' => hash('sha256', (string) ($user['passwordSalt'] ?? '') . '|' . (string) ($user['passwordHash'] ?? '')),
    ]);
}

function uav2_normalize_users_container(array $data): array
{
    $users = isset($data['users']) && is_array($data['users']) ? $data['users'] : [];
    $normalized = [];
    foreach ($users as $user) {
        if (!is_array($user) || trim((string) ($user['login'] ?? '')) === '') {
            continue;
        }
        $normalized[] = $user;
    }
    $data['users'] = $normalized;

    $hasConfigAdminPassword = defined('ADMIN_PASSWORD_SALT') && defined('ADMIN_PASSWORD_HASH') && ADMIN_PASSWORD_SALT !== '' && ADMIN_PASSWORD_HASH !== '';
    $found = false;
    foreach ($data['users'] as $index => $user) {
        if ((string) ($user['login'] ?? '') !== ADMIN_USER) {
            continue;
        }
        $found = true;
        $data['users'][$index]['role'] = 'admin';
        $data['users'][$index]['active'] = true;
        $data['users'][$index]['archived'] = false;
        $data['users'][$index]['lessorSlug'] = '';
        $data['users'][$index]['partnerSlug'] = '';
        $data['users'][$index]['partnerAgentSlug'] = '';
        if ($hasConfigAdminPassword && !admin_user_password_is_profile_managed($data['users'][$index])) {
            $data['users'][$index]['passwordSalt'] = ADMIN_PASSWORD_SALT;
            $data['users'][$index]['passwordHash'] = ADMIN_PASSWORD_HASH;
        }
    }
    if (!$found && $hasConfigAdminPassword) {
        $user = default_admin_users()['users'][0];
        $data['users'][] = $user;
    }
    return $data;
}

function uav2_lock_file(string $path, int $mode)
{
    // All cooperating readers/writers acquire the recovery lock before a per-file lock.
    if (RentalReturnStore::owns($path)) RentalReturnStore::enter();
    RentalReturnStore::checkpoint('users.before_lock.' . basename($path));
    $dir = dirname($path);
    if (!is_dir($dir) && !mkdir($dir, 0775, true)) {
        throw new RuntimeException('Не удалось подготовить каталог хранилища.');
    }
    $handle = @fopen($path . '.lock', 'c');
    if (!$handle || !flock($handle, $mode)) {
        if (is_resource($handle)) {
            fclose($handle);
        }
        throw new RuntimeException('Не удалось заблокировать хранилище. Повторите позже.');
    }
    RentalReturnStore::checkpoint('users.after_lock.' . basename($path));
    return $handle;
}

function uav2_unlock_files(array $handles): void
{
    foreach (array_reverse($handles) as $handle) {
        if (is_resource($handle)) {
            @flock($handle, LOCK_UN);
            @fclose($handle);
        }
    }
}

function uav2_lock_files(array $specifications): array
{
    $handles = [];
    try {
        foreach ($specifications as $specification) {
            $handles[] = uav2_lock_file((string) $specification[0], (int) $specification[1]);
        }
        return $handles;
    } catch (Throwable $exception) {
        uav2_unlock_files($handles);
        throw $exception;
    }
}

function uav2_read_json_unlocked(string $path, array $default): array
{
    if (RentalReturnStore::owns($path)) return read_json_file($path, $default);
    if (!is_file($path)) {
        return $default;
    }
    $raw = file_get_contents($path);
    $decoded = is_string($raw) ? json_decode(preg_replace('/^\xEF\xBB\xBF/', '', $raw) ?? $raw, true) : null;
    if (!is_array($decoded)) {
        throw new RuntimeException('Хранилище не читается как JSON. Запись остановлена.');
    }
    return $decoded;
}

function uav2_write_json_unlocked(string $path, array $data): void
{
    if (RentalReturnStore::owns($path)) { write_json_file($path, $data); return; }
    rental_return_guard_legacy_write($path, $data);
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if (!is_string($json)) {
        throw new RuntimeException('Не удалось подготовить JSON для записи.');
    }
    $json .= PHP_EOL;
    if (is_file($path)) {
        $existing = file_get_contents($path);
        if (!is_string($existing) || !is_array(json_decode(preg_replace('/^\xEF\xBB\xBF/', '', $existing) ?? $existing, true))) {
            throw new RuntimeException('Текущий JSON повреждён. Запись остановлена.');
        }
        if (!copy($path, $path . '.bak')) {
            throw new RuntimeException('Не удалось создать страховочную копию JSON.');
        }
    }
    $temp = $path . '.tmp.' . bin2hex(random_bytes(6));
    $handle = @fopen($temp, 'xb');
    if (!$handle) {
        throw new RuntimeException('Не удалось создать временный файл записи.');
    }
    try {
        $written = fwrite($handle, $json);
        if ($written !== strlen($json) || !fflush($handle)) {
            throw new RuntimeException('Не удалось полностью записать временный JSON.');
        }
        if (function_exists('fsync') && !fsync($handle)) {
            throw new RuntimeException('Не удалось подтвердить запись временного JSON.');
        }
    } finally {
        fclose($handle);
    }
    $verify = json_decode((string) file_get_contents($temp), true);
    if (!is_array($verify) || !rename($temp, $path)) {
        @unlink($temp);
        throw new RuntimeException('Атомарная замена JSON не выполнена.');
    }
}

function uav2_audit_log(string $action, string $entityType, string $entityId, string $summary, array $meta = []): void
{
    if (!RentalReturnStore::active()) {
        RentalReturnStore::transaction(static fn() => uav2_audit_log($action, $entityType, $entityId, $summary, $meta));
        return;
    }
    $lock = uav2_lock_file(AUDIT_LOG_FILE, LOCK_EX);
    try {
        $data = uav2_read_json_unlocked(AUDIT_LOG_FILE, default_audit_log());
        $items = isset($data['items']) && is_array($data['items']) ? array_values($data['items']) : [];
        $entry = [
            'id' => 'log_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3)),
            'createdAt' => now_iso(),
            'user' => current_admin_user() ?: 'system',
            'role' => current_admin_role(),
            'action' => $action,
            'entityType' => $entityType,
            'entityId' => $entityId,
            'summary' => $summary,
            'meta' => $meta,
        ];
        array_unshift($items, audit_log_json_safe_value($entry));
        $data['items'] = array_slice($items, 0, 1000);
        $data['updatedAt'] = now_iso();
        uav2_write_json_unlocked(AUDIT_LOG_FILE, $data);
    } finally {
        uav2_unlock_files([$lock]);
    }
}

function uav2_actor_from_container(array $data): array
{
    $login = current_admin_user();
    foreach ((array) ($data['users'] ?? []) as $user) {
        if (is_array($user) && (string) ($user['login'] ?? '') === $login) {
            if (empty($user['active']) || !empty($user['archived'])) {
                throw new RuntimeException('Текущая учётная запись отключена.', 403);
            }
            return $user;
        }
    }
    throw new RuntimeException('Текущая учётная запись не найдена.', 403);
}

function uav2_is_root(array $user): bool
{
    return admin_user_is_platform_root($user);
}

function uav2_is_scoped_admin(array $user): bool
{
    return (string) ($user['role'] ?? '') === 'lessor'
        && uav2_user_has_permission($user, 'users.scoped.manage')
        && normalize_lessor_slug((string) ($user['lessorSlug'] ?? '')) !== '';
}

function uav2_assert_actor_can_manage_users(array $actor): void
{
    if (!uav2_is_root($actor) && !uav2_is_scoped_admin($actor)) {
        throw new RuntimeException('Недостаточно прав для управления пользователями.', 403);
    }
}

function uav2_find_user_index(array $users, string $login): ?int
{
    foreach ($users as $index => $user) {
        if (is_array($user) && strcasecmp((string) ($user['login'] ?? ''), $login) === 0) {
            return (int) $index;
        }
    }
    return null;
}

function uav2_profile_role(string $profile): string
{
    return match ($profile) {
        'admin' => 'admin',
        'manager', 'manager_cashier' => 'manager',
        'lessor_admin' => 'lessor',
        'partner' => 'partner',
        'executor' => 'executor',
        default => throw new InvalidArgumentException('Выберите существующий профиль доступа.'),
    };
}

function uav2_desired_permissions(mixed $value): array
{
    $permissions = uav2_normalize_string_list($value, true);
    $known = array_fill_keys(uav2_permission_keys(), true);
    foreach ($permissions as $permission) {
        if (!isset($known[$permission])) {
            throw new InvalidArgumentException('Передано неизвестное разрешение.');
        }
    }
    $selected = array_fill_keys($permissions, true);
    foreach (uav2_permission_dependencies() as $child => $parent) {
        if (isset($selected[$child]) && !isset($selected[$parent])) {
            throw new InvalidArgumentException('Зависимое разрешение нельзя включить без обязательного базового доступа.');
        }
    }
    return $permissions;
}

function uav2_permissions_from_desired(array $draft, array $desired, bool $rootActor, ?array $existing = null): array
{
    if ((string) ($draft['role'] ?? '') === 'admin') {
        return ['permissions' => [], 'deniedPermissions' => []];
    }

    $base = uav2_user_base_permissions($draft);
    $baseMap = array_fill_keys($base, true);
    $desiredMap = array_fill_keys($desired, true);
    $allowedExtras = (string) ($draft['role'] ?? '') === 'manager'
        ? uav2_manager_extra_permission_keys(admin_user_is_scoped_manager($draft))
        : [];
    $allowedExtrasMap = array_fill_keys($allowedExtras, true);

    if (!$rootActor) {
        $existing ??= $draft;
        $grants = array_fill_keys(admin_user_permissions($existing), true);
        foreach (['tariffs.view', 'tariffs.edit'] as $permission) {
            if (isset($desiredMap[$permission])) {
                $grants[$permission] = true;
            } else {
                unset($grants[$permission]);
            }
        }
        if (isset($grants['tariffs.edit'])) {
            $grants['tariffs.view'] = true;
        }
        $result = array_keys($grants);
        sort($result);
        return ['permissions' => $result, 'deniedPermissions' => uav2_user_denied_permissions($existing)];
    }

    $grants = [];
    $denied = [];
    foreach ($desiredMap as $permission => $_) {
        if (!isset($baseMap[$permission]) && isset($allowedExtrasMap[$permission])) {
            $grants[] = $permission;
        } elseif (!isset($baseMap[$permission])) {
            throw new InvalidArgumentException('Это разрешение нельзя добавить выбранному профилю.');
        }
    }
    foreach ($base as $permission) {
        if (!isset($desiredMap[$permission])) {
            $denied[] = $permission;
        }
    }
    $conflict = array_intersect($grants, $denied);
    if ($conflict) {
        throw new InvalidArgumentException('Одно разрешение нельзя одновременно выдать и запретить.');
    }
    sort($grants);
    sort($denied);
    return ['permissions' => $grants, 'deniedPermissions' => $denied];
}

function uav2_validate_lessor_slug(string $scopeId, bool $requireActive = true, ?array $lessorsData = null): string
{
    if ($scopeId === 'rent_rk') {
        return '';
    }
    $slug = normalize_lessor_slug(preg_replace('/^lessor:/', '', $scopeId) ?? $scopeId);
    $lessor = null;
    if ($slug !== '' && is_array($lessorsData)) {
        foreach ((array) ($lessorsData['items'] ?? []) as $candidate) {
            if (is_array($candidate) && normalize_lessor_slug((string) ($candidate['slug'] ?? '')) === $slug) {
                $lessor = normalize_lessor_item($candidate);
                break;
            }
        }
    } elseif ($slug !== '') {
        $lessor = find_lessor_by_slug($slug);
    }
    if (!$lessor || ($requireActive && empty($lessor['active']))) {
        throw new InvalidArgumentException('Выберите действующий парк.');
    }
    return $slug;
}

function uav2_save_user(array $payload): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn() => uav2_save_user($payload));
    $locks = uav2_lock_files([
        [LESSORS_FILE, LOCK_SH],
        [PARTNERS_FILE, LOCK_SH],
        [ADMIN_USERS_FILE, LOCK_EX],
    ]);
    $audit = [];
    $updated = [];
    try {
        $lessorsData = uav2_read_json_unlocked(LESSORS_FILE, default_lessors());
        $partnersData = uav2_read_json_unlocked(PARTNERS_FILE, default_partners());
        $data = uav2_normalize_users_container(uav2_read_json_unlocked(ADMIN_USERS_FILE, default_admin_users()));
        $actor = uav2_actor_from_container($data);
        uav2_assert_actor_can_manage_users($actor);
        $rootActor = uav2_is_root($actor);

        $originalLogin = trim((string) ($payload['originalLogin'] ?? ''));
        $isCreate = $originalLogin === '';
        $login = strtolower(trim((string) ($payload['login'] ?? '')));
        if (!preg_match('/^[a-z0-9_.-]{3,40}$/', $login)) {
            throw new InvalidArgumentException('Логин: 3–40 латинских букв, цифр, точек, дефисов или подчёркиваний.');
        }
        if (!$isCreate && strcasecmp($login, $originalLogin) !== 0) {
            throw new InvalidArgumentException('Логин существующего пользователя изменять нельзя.');
        }
        $index = uav2_find_user_index($data['users'], $isCreate ? $login : $originalLogin);
        if ($isCreate && $index !== null) {
            throw new RuntimeException('Пользователь с таким логином уже существует. Существующая запись не изменена.', 409);
        }
        if (!$isCreate && $index === null) {
            throw new RuntimeException('Пользователь больше не существует.', 409);
        }
        $existing = $index !== null ? $data['users'][$index] : null;
        $expected = (string) ($payload['expectedRecordHash'] ?? '');
        if ($isCreate) {
            if ($expected !== 'new') {
                throw new RuntimeException('Форма создания устарела. Откройте её заново.', 409);
            }
        } elseif ($expected === '' || !hash_equals(uav2_user_record_token((array) $existing), $expected)) {
            throw new RuntimeException('Запись уже изменилась в другой сессии. Обновите страницу и повторите.', 409);
        }
        if ($existing && uav2_user_permission_state_error($existing) !== '') {
            throw new RuntimeException('Права пользователя повреждены: ' . uav2_user_permission_state_error($existing) . ' Запись оставлена без изменений и требует отдельного разбора.', 409);
        }
        if ($existing && !empty($existing['archived'])) {
            throw new RuntimeException('Сначала верните пользователя из архива.', 409);
        }

        if (!$rootActor) {
            $actorScope = normalize_lessor_slug((string) ($actor['lessorSlug'] ?? ''));
            if (!$isCreate && ((string) ($existing['role'] ?? '') !== 'manager' || normalize_lessor_slug((string) ($existing['lessorSlug'] ?? '')) !== $actorScope)) {
                throw new RuntimeException('Можно управлять только менеджерами своего парка.', 403);
            }
            $profile = 'manager';
            $scopeId = $actorScope;
        } else {
            $profile = trim((string) ($payload['profile'] ?? 'manager'));
            $scopeId = trim((string) ($payload['scopeId'] ?? 'rent_rk'));
        }
        $role = uav2_profile_role($profile);
        if ($role === 'admin' && $login !== ADMIN_USER) {
            throw new RuntimeException('Профиль Root зарезервирован только за системным логином admin.', 403);
        }
        if ($role === 'executor' && !executor_role_enabled() && (!$existing || (string) ($existing['role'] ?? '') !== 'executor')) {
            throw new InvalidArgumentException('Профиль исполнителя отключён в настройках.');
        }
        $name = trim((string) ($payload['name'] ?? ''));
        if ($name === '' || mb_strlen($name) > 80) {
            throw new InvalidArgumentException('Укажите имя длиной до 80 символов.');
        }
        $active = filter_var($payload['active'] ?? false, FILTER_VALIDATE_BOOL);
        $password = (string) ($payload['password'] ?? '');
        if ($isCreate && $password === '') {
            throw new InvalidArgumentException('Для нового пользователя нужен пароль.');
        }
        if (!$rootActor && !$isCreate && $password !== '') {
            throw new RuntimeException('Администратор парка не может менять пароль существующего пользователя.', 403);
        }

        $lessorSlug = '';
        $partnerSlug = '';
        $partnerAgentSlug = '';
        if ($role === 'manager') {
            if ($profile === 'manager_cashier') {
                $scopeId = 'rent_rk';
            }
            $lessorSlug = uav2_validate_lessor_slug($scopeId, $isCreate, $lessorsData);
        } elseif ($role === 'lessor') {
            $lessorSlug = uav2_validate_lessor_slug($scopeId, $isCreate, $lessorsData);
            if ($lessorSlug === '') {
                throw new InvalidArgumentException('Администратор парка должен быть привязан к внешнему парку.');
            }
        } elseif ($role === 'partner') {
            $partnerSlug = normalize_partner_item(['slug' => (string) ($payload['channelId'] ?? ''), 'name' => 'x'])['slug'];
            $partner = null;
            foreach ((array) ($partnersData['items'] ?? []) as $candidate) {
                if (is_array($candidate) && (string) ($candidate['slug'] ?? '') === $partnerSlug) {
                    $partner = normalize_partner_item($candidate);
                    break;
                }
            }
            if (!$partner || empty($partner['active'])) {
                throw new InvalidArgumentException('Выберите действующий партнёрский канал.');
            }
            $partnerAgentSlug = normalize_partner_agent_slug((string) ($payload['agentCode'] ?? ''));
            if (!preg_match('/^[a-z0-9-]{2,40}$/', $partnerAgentSlug)) {
                throw new InvalidArgumentException('Код представителя: 2–40 латинских букв, цифр или дефисов.');
            }
            foreach ($data['users'] as $candidate) {
                if (!is_array($candidate) || ($existing && (string) ($candidate['login'] ?? '') === (string) ($existing['login'] ?? ''))) {
                    continue;
                }
                if ((string) ($candidate['role'] ?? '') === 'partner'
                    && (string) ($candidate['partnerSlug'] ?? '') === $partnerSlug
                    && normalize_partner_agent_slug((string) ($candidate['partnerAgentSlug'] ?? '')) === $partnerAgentSlug
                ) {
                    throw new RuntimeException('Такой код представителя уже занят в выбранном канале.', 409);
                }
            }
        }

        $draft = [
            'login' => $login,
            'name' => $name,
            'role' => $role,
            'active' => $active,
            'archived' => false,
            'lessorSlug' => $lessorSlug,
            'partnerSlug' => $partnerSlug,
            'partnerAgentSlug' => $partnerAgentSlug,
        ];
        if (!$rootActor) {
            if (array_key_exists('profile', $payload) && (string) $payload['profile'] !== 'manager') {
                throw new RuntimeException('Администратор парка не может менять профиль пользователя.', 403);
            }
            if (array_key_exists('scopeId', $payload) && normalize_lessor_slug((string) $payload['scopeId']) !== $lessorSlug) {
                throw new RuntimeException('Администратор парка не может менять контур пользователя.', 403);
            }
        }
        $desired = uav2_desired_permissions($payload['effectivePermissions'] ?? []);
        if (!$rootActor) {
            foreach ($desired as $permission) {
                if (!in_array($permission, ['tariffs.view', 'tariffs.edit'], true)) {
                    $baseOrExisting = array_fill_keys(array_merge(uav2_user_base_permissions($draft), admin_user_permissions((array) $existing)), true);
                    if (!isset($baseOrExisting[$permission])) {
                        throw new RuntimeException('Администратор парка может менять только тарифные права.', 403);
                    }
                }
            }
        }
        $permissionState = uav2_permissions_from_desired($draft, $desired, $rootActor, $existing);
        $draft = array_merge($draft, $permissionState);

        if ($existing) {
            $draft = array_merge($existing, $draft);
        }
        if ($password !== '') {
            $draft = array_merge($draft, admin_password_record($password));
            if ($login === ADMIN_USER && ADMIN_PASSWORD_SALT !== '' && ADMIN_PASSWORD_HASH !== '') {
                $draft['passwordSource'] = 'profile';
            }
        }
        if ($login === ADMIN_USER) {
            if ($role !== 'admin' || !$active) {
                throw new RuntimeException('Системную Root-запись нельзя отключить или понизить.', 409);
            }
            $draft['deniedPermissions'] = [];
        }
        if ($existing && (string) ($existing['login'] ?? '') === current_admin_user() && !$active) {
            throw new RuntimeException('Нельзя отключить текущую учётную запись.', 409);
        }
        if ($existing && (string) ($existing['login'] ?? '') === current_admin_user()
            && admin_user_is_platform_root($existing) && $role !== 'admin') {
            throw new RuntimeException('Текущую Root-запись нельзя понизить в собственной сессии.', 409);
        }
        if ($role === 'admin' && $draft['deniedPermissions']) {
            throw new InvalidArgumentException('Для Root персональные запреты не применяются.');
        }

        $beforeToken = $existing ? uav2_user_record_token($existing) : '';
        $afterToken = uav2_user_record_token($draft);
        if ($existing && hash_equals($beforeToken, $afterToken)) {
            throw new InvalidArgumentException('Нет изменений для сохранения.');
        }
        if ($index === null) {
            $data['users'][] = $draft;
        } else {
            $data['users'][$index] = $draft;
        }
        uav2_write_json_unlocked(ADMIN_USERS_FILE, $data);
        $updated = $draft;
        $audit = [
            'action' => $existing ? 'user.update' : 'user.create',
            'summary' => $existing ? 'Пользователь изменён через Users & Access V2' : 'Пользователь создан через Users & Access V2',
            'login' => $login,
            'before' => $existing ? uav2_safe_user($existing, false) : null,
            'after' => uav2_safe_user($draft, false),
        ];
    } finally {
        uav2_unlock_files($locks);
    }

    if (!empty($audit)) {
        try {
            uav2_audit_log($audit['action'], 'user', $audit['login'], $audit['summary'], ['before' => $audit['before'], 'after' => $audit['after']]);
        } catch (Throwable $exception) {
            technical_log('users_access_v2.audit_failed', ['entity' => 'user', 'operation' => $audit['action']]);
            throw $exception;
        }
    }
    if ($password !== '' || empty($updated['active'])) {
        revoke_admin_remember_tokens_for_login((string) $updated['login']);
    }
    return $updated;
}

function uav2_set_user_archived(string $login, bool $archived, string $expectedRecordHash): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn() => uav2_set_user_archived($login, $archived, $expectedRecordHash));
    $locks = uav2_lock_files([[ADMIN_USERS_FILE, LOCK_EX]]);
    $updated = [];
    $before = [];
    try {
        $data = uav2_normalize_users_container(uav2_read_json_unlocked(ADMIN_USERS_FILE, default_admin_users()));
        $actor = uav2_actor_from_container($data);
        uav2_assert_actor_can_manage_users($actor);
        $index = uav2_find_user_index($data['users'], trim($login));
        if ($index === null) {
            throw new RuntimeException('Пользователь больше не существует.', 409);
        }
        $target = $data['users'][$index];
        if ($expectedRecordHash === '' || !hash_equals(uav2_user_record_token($target), $expectedRecordHash)) {
            throw new RuntimeException('Запись уже изменилась в другой сессии. Обновите страницу и повторите.', 409);
        }
        $targetLogin = (string) ($target['login'] ?? '');
        if ($targetLogin === ADMIN_USER || $targetLogin === current_admin_user()) {
            throw new RuntimeException('Защищённую или текущую учётную запись нельзя перенести в архив.', 409);
        }
        if (!uav2_is_root($actor)) {
            $actorScope = normalize_lessor_slug((string) ($actor['lessorSlug'] ?? ''));
            if ((string) ($target['role'] ?? '') !== 'manager'
                || normalize_lessor_slug((string) ($target['lessorSlug'] ?? '')) !== $actorScope) {
                throw new RuntimeException('Можно управлять только менеджерами своего парка.', 403);
            }
        }
        if ($archived && !empty($target['active'])) {
            throw new RuntimeException('Перед переносом в архив отключите учётную запись.', 409);
        }
        if (!empty($target['archived']) === $archived) {
            throw new InvalidArgumentException($archived ? 'Пользователь уже в архиве.' : 'Пользователь уже возвращён из архива.');
        }
        $before = $target;
        $target['archived'] = $archived;
        $target['active'] = false;
        $data['users'][$index] = $target;
        uav2_write_json_unlocked(ADMIN_USERS_FILE, $data);
        $updated = $target;
    } finally {
        uav2_unlock_files($locks);
    }

    try {
        uav2_audit_log(
            $archived ? 'user.archive' : 'user.unarchive',
            'user',
            (string) ($updated['login'] ?? ''),
            $archived ? 'Отключённый пользователь перенесён в архив' : 'Пользователь возвращён из архива',
            ['before' => uav2_safe_user($before, false), 'after' => uav2_safe_user($updated, false)]
        );
    } catch (Throwable $exception) {
        technical_log('users_access_v2.audit_failed', ['entity' => 'user', 'operation' => $archived ? 'user.archive' : 'user.unarchive']);
        throw $exception;
    }
    if ($archived) {
        revoke_admin_remember_tokens_for_login((string) ($updated['login'] ?? ''));
    }
    return $updated;
}

function uav2_legacy_upsert_user(array $payload): array
{
    $login = trim((string) ($payload['login'] ?? ''));
    $existing = $login !== '' ? find_admin_user($login) : null;
    $profile = (string) ($payload['role'] ?? 'manager');
    if ($profile === 'lessor') {
        $profile = 'lessor_admin';
    }
    $desiredUser = array_merge($existing ?? [], [
        'role' => uav2_profile_role($profile),
        'lessorSlug' => (string) ($payload['lessorSlug'] ?? ''),
        'permissions' => (array) ($payload['permissions'] ?? ($existing['permissions'] ?? [])),
        'deniedPermissions' => $existing['deniedPermissions'] ?? [],
        'active' => !empty($payload['active']),
    ]);
    return uav2_save_user([
        'originalLogin' => $existing ? $login : '',
        'login' => $login,
        'name' => (string) ($payload['name'] ?? $login),
        'profile' => $profile,
        'scopeId' => (string) ($payload['lessorSlug'] ?? '') ?: 'rent_rk',
        'channelId' => (string) ($payload['partnerSlug'] ?? ''),
        'agentCode' => (string) ($payload['partnerAgentSlug'] ?? ''),
        'password' => (string) ($payload['password'] ?? ''),
        'active' => !empty($payload['active']),
        'effectivePermissions' => uav2_user_effective_permissions($desiredUser),
        'expectedRecordHash' => $existing ? uav2_user_record_token($existing) : 'new',
    ]);
}

function uav2_legacy_change_password(string $login, string $password): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn() => uav2_legacy_change_password($login, $password));
    $login = trim($login);
    if ($login === '' || $login !== current_admin_user()) {
        throw new RuntimeException('Самостоятельно можно менять только свой пароль.', 403);
    }
    if ($password === '') {
        throw new InvalidArgumentException('Введите новый пароль.');
    }
    $lock = uav2_lock_file(ADMIN_USERS_FILE, LOCK_EX);
    try {
        $raw = uav2_read_json_unlocked(ADMIN_USERS_FILE, default_admin_users());
        $data = uav2_normalize_users_container($raw);
        $index = uav2_find_user_index($data['users'], $login);
        $rawIndex = uav2_find_user_index($raw['users'] ?? [], $login);
        if ($index === null || empty($data['users'][$index]['active']) || !empty($data['users'][$index]['archived'])
            || ($rawIndex === null && $login !== ADMIN_USER)) {
            throw new InvalidArgumentException('Пользователь не найден или отключён.');
        }
        if ($rawIndex === null) {
            $raw['users'][] = $data['users'][$index];
            $rawIndex = array_key_last($raw['users']);
        }
        $raw['users'][$rawIndex] = array_merge($raw['users'][$rawIndex], admin_password_record($password));
        if ($login === ADMIN_USER && ADMIN_PASSWORD_SALT !== '' && ADMIN_PASSWORD_HASH !== '') {
            $raw['users'][$rawIndex]['passwordSource'] = 'profile';
        }
        uav2_write_json_unlocked(ADMIN_USERS_FILE, $raw);
        $updated = $raw['users'][$rawIndex];
    } finally {
        uav2_unlock_files([$lock]);
    }
    revoke_admin_remember_tokens_for_login($login);
    uav2_audit_log('user.password_change', 'user', $login, 'Пользователь сменил пароль в личном кабинете', ['selfService' => true]);
    return $updated;
}

function uav2_update_selected_permissions(string $login, array $changes): array
{
    $user = find_admin_user($login);
    if (!$user) {
        throw new InvalidArgumentException('Пользователь не найден.');
    }
    $desired = array_fill_keys(uav2_user_effective_permissions($user), true);
    foreach ($changes as $permission => $enabled) {
        if (!in_array((string) $permission, uav2_permission_keys(), true)) {
            throw new InvalidArgumentException('Передано неизвестное разрешение.');
        }
        if ($enabled) {
            $desired[(string) $permission] = true;
        } else {
            unset($desired[(string) $permission]);
        }
    }
    if (!empty($desired['finance.manage'])) {
        $desired['finance.view'] = true;
    }
    if (!empty($desired['tariffs.edit'])) {
        $desired['tariffs.view'] = true;
    }
    return uav2_save_user([
        'originalLogin' => (string) $user['login'],
        'login' => (string) $user['login'],
        'name' => (string) ($user['name'] ?? $user['login']),
        'profile' => uav2_profile_for_user($user),
        'scopeId' => admin_user_is_scoped_manager($user) ? (string) ($user['lessorSlug'] ?? '') : 'rent_rk',
        'channelId' => (string) ($user['partnerSlug'] ?? ''),
        'agentCode' => (string) ($user['partnerAgentSlug'] ?? ''),
        'password' => '',
        'active' => !empty($user['active']),
        'effectivePermissions' => array_keys($desired),
        'expectedRecordHash' => uav2_user_record_token($user),
    ]);
}

function uav2_safe_history(string $entityType, string $entityId): array
{
    $events = [];
    foreach (read_audit_log()['items'] as $item) {
        if (!is_array($item) || (string) ($item['entityType'] ?? '') !== $entityType || (string) ($item['entityId'] ?? '') !== $entityId) {
            continue;
        }
        $events[] = [
            'at' => format_admin_datetime((string) ($item['createdAt'] ?? '')),
            'actor' => (string) ($item['user'] ?? 'Система'),
            'title' => (string) ($item['summary'] ?? 'Изменение'),
            'detail' => '',
        ];
        if (count($events) >= 30) {
            break;
        }
    }
    return $events;
}

function uav2_safe_user(array $user, bool $includeHistory = true): array
{
    $profile = uav2_profile_for_user($user);
    $scopeId = admin_user_scope_id($user);
    return [
        'id' => 'user-' . substr(hash('sha256', (string) ($user['login'] ?? '')), 0, 16),
        'login' => (string) ($user['login'] ?? ''),
        'name' => trim((string) ($user['name'] ?? '')) ?: (string) ($user['login'] ?? ''),
        'role' => (string) ($user['role'] ?? ''),
        'profile' => $profile,
        'profileInvalid' => $profile === 'invalid_admin',
        'active' => !empty($user['active']),
        'archived' => !empty($user['archived']),
        'scopeId' => $scopeId,
        'channelId' => (string) ($user['partnerSlug'] ?? ''),
        'agentCode' => (string) ($user['partnerAgentSlug'] ?? ''),
        'permissions' => admin_user_permissions($user),
        'deniedPermissions' => uav2_user_denied_permissions($user),
        'effectivePermissions' => uav2_user_effective_permissions($user),
        'protected' => (string) ($user['login'] ?? '') === ADMIN_USER || (string) ($user['login'] ?? '') === current_admin_user(),
        'recordHash' => uav2_user_record_token($user),
        'permissionsCorrupt' => uav2_user_permission_state_error($user) !== '',
        'permissionsCorruptReason' => uav2_user_permission_state_error($user),
        'history' => $includeHistory ? uav2_safe_history('user', (string) ($user['login'] ?? '')) : [],
    ];
}

function uav2_entity_record_token(array $record): string
{
    unset($record['history'], $record['recordHash']);
    return uav2_record_token($record);
}

function uav2_entity_meaningful_token(array $record): string
{
    unset($record['updatedAt'], $record['history'], $record['recordHash']);
    return uav2_record_token($record);
}

function uav2_save_lessor(array $payload): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn() => uav2_save_lessor($payload));
    $locks = uav2_lock_files([
        [LESSORS_FILE, LOCK_EX],
        [ADMIN_USERS_FILE, LOCK_SH],
    ]);
    $saved = [];
    $created = false;
    try {
        $usersData = uav2_normalize_users_container(uav2_read_json_unlocked(ADMIN_USERS_FILE, default_admin_users()));
        $actor = uav2_actor_from_container($usersData);
        if (!uav2_is_root($actor)) {
            throw new RuntimeException('Только Root может изменять список парков.', 403);
        }
        $data = uav2_read_json_unlocked(LESSORS_FILE, default_lessors());
        $data['items'] = isset($data['items']) && is_array($data['items']) ? array_values($data['items']) : [];
        $originalSlug = normalize_lessor_slug((string) ($payload['originalSlug'] ?? ''));
        $slug = normalize_lessor_slug((string) ($payload['slug'] ?? ''));
        if ($slug === '' || !preg_match('/^[a-z0-9-]{2,50}$/', $slug)) {
            throw new InvalidArgumentException('Код парка: 2–50 латинских букв, цифр или дефисов.');
        }
        if ($originalSlug !== '' && $originalSlug !== $slug) {
            throw new InvalidArgumentException('Код существующего парка изменять нельзя.');
        }
        $index = null;
        foreach ($data['items'] as $i => $item) {
            if (is_array($item) && normalize_lessor_slug((string) ($item['slug'] ?? '')) === $slug) {
                $index = (int) $i;
                break;
            }
        }
        if ($originalSlug === '' && $index !== null) {
            throw new RuntimeException('Парк с таким кодом уже существует.', 409);
        }
        if ($originalSlug !== '' && $index === null) {
            throw new RuntimeException('Парк больше не существует.', 409);
        }
        $existing = $index !== null ? normalize_lessor_item((array) $data['items'][$index]) : null;
        $expected = (string) ($payload['expectedRecordHash'] ?? '');
        if ($existing && ($expected === '' || !hash_equals(uav2_entity_record_token($existing), $expected))) {
            throw new RuntimeException('Парк уже изменён в другой сессии.', 409);
        }
        if (!$existing && $expected !== 'new') {
            throw new RuntimeException('Форма создания парка устарела.', 409);
        }
        $name = trim((string) ($payload['name'] ?? ''));
        if ($name === '') {
            throw new InvalidArgumentException('Укажите название парка.');
        }
        $saved = normalize_lessor_item([
            'slug' => $slug,
            'name' => $name,
            'active' => filter_var($payload['active'] ?? false, FILTER_VALIDATE_BOOL),
            'visible_in_rent_rk_showcase' => filter_var($payload['showcase'] ?? false, FILTER_VALIDATE_BOOL),
            'allow_lessor_rental_delete' => filter_var($payload['allowRentalDelete'] ?? false, FILTER_VALIDATE_BOOL),
            'createdAt' => (string) ($existing['createdAt'] ?? now_iso()),
            'updatedAt' => now_iso(),
        ]);
        if ($existing && uav2_entity_meaningful_token($existing) === uav2_entity_meaningful_token($saved)) {
            throw new InvalidArgumentException('Нет изменений для сохранения.');
        }
        $created = !$existing;
        if ($index === null) {
            array_unshift($data['items'], $saved);
        } else {
            $data['items'][$index] = array_replace($data['items'][$index], $saved);
        }
        $data['updatedAt'] = now_iso();
        uav2_write_json_unlocked(LESSORS_FILE, $data);
    } finally {
        uav2_unlock_files($locks);
    }
    uav2_audit_log($created ? 'lessor.create' : 'lessor.update', 'lessor', (string) $saved['slug'], $created ? 'Создан парк через Users & Access V2' : 'Парк изменён через Users & Access V2');
    return $saved;
}

function uav2_legacy_upsert_lessor(array $payload): array
{
    $slug = normalize_lessor_slug((string) ($payload['slug'] ?? ''));
    $existing = $slug !== '' ? find_lessor_by_slug($slug) : null;
    return uav2_save_lessor([
        'originalSlug' => $existing ? $slug : '',
        'slug' => $slug,
        'name' => (string) ($payload['name'] ?? ''),
        'active' => !empty($payload['active']),
        'showcase' => !empty($payload['visible_in_rent_rk_showcase']) || !empty($payload['visibleInRentRkShowcase']),
        'allowRentalDelete' => !empty($payload['allow_lessor_rental_delete']) || !empty($payload['allowLessorRentalDelete']),
        'expectedRecordHash' => $existing ? uav2_entity_record_token($existing) : 'new',
    ]);
}

function uav2_validate_partner_payload(array $payload, ?array $existing, ?array $lessorsData = null): array
{
    $slug = normalize_partner_item(['slug' => (string) ($payload['slug'] ?? ''), 'name' => 'x'])['slug'];
    if ($slug === '' || !preg_match('/^[a-z0-9-]{2,50}$/', $slug)) {
        throw new InvalidArgumentException('Код канала: 2–50 латинских букв, цифр или дефисов.');
    }
    $name = trim((string) ($payload['name'] ?? ''));
    if ($name === '') {
        throw new InvalidArgumentException('Укажите название канала.');
    }
    $ownerType = (string) ($payload['ownerType'] ?? 'rent_rk');
    if (!in_array($ownerType, ['rent_rk', 'lessor'], true)) {
        throw new InvalidArgumentException('Выберите допустимого владельца заявки.');
    }
    $ownerScopeId = 'rent_rk';
    if ($ownerType === 'lessor') {
        $ownerScopeId = normalize_lessor_slug((string) ($payload['ownerScopeId'] ?? ''));
        $lessor = null;
        foreach ((array) ($lessorsData['items'] ?? []) as $candidate) {
            if (is_array($candidate) && normalize_lessor_slug((string) ($candidate['slug'] ?? '')) === $ownerScopeId) {
                $lessor = normalize_lessor_item($candidate);
                break;
            }
        }
        if ($lessor === null && $lessorsData === null && $ownerScopeId !== '') {
            $lessor = find_lessor_by_slug($ownerScopeId);
        }
        if (!$lessor || empty($lessor['active'])) {
            throw new InvalidArgumentException('Выберите действующий внешний парк.');
        }
    }
    $commissionType = (string) ($payload['commissionType'] ?? 'percent');
    if (!in_array($commissionType, ['percent', 'fixed'], true)) {
        throw new InvalidArgumentException('Выберите способ комиссии.');
    }
    $commissionRaw = $payload['commissionValue'] ?? null;
    if (!is_int($commissionRaw) && !is_float($commissionRaw) && !(is_string($commissionRaw) && preg_match('/^\d+(?:[.,]\d{1,2})?$/', trim($commissionRaw)))) {
        throw new InvalidArgumentException('Комиссия должна быть числом.');
    }
    $commissionValue = (float) str_replace(',', '.', (string) $commissionRaw);
    if ($commissionValue <= 0 || ($commissionType === 'percent' && $commissionValue > 100)) {
        throw new InvalidArgumentException($commissionType === 'percent' ? 'Процент комиссии должен быть больше 0 и не выше 100.' : 'Сумма комиссии должна быть больше 0.');
    }
    return normalize_partner_item([
        'slug' => $slug,
        'name' => $name,
        'type' => trim((string) ($payload['type'] ?? '')) ?: 'Партнёр',
        'partner_owner_type' => $ownerType,
        'partner_owner_scope_id' => $ownerScopeId,
        'contactPerson' => (string) ($payload['contactPerson'] ?? ($existing['contactPerson'] ?? '')),
        'phone' => (string) ($payload['phone'] ?? ($existing['phone'] ?? '')),
        'defaultPickupPlace' => (string) ($payload['defaultPickupPlace'] ?? ($existing['defaultPickupPlace'] ?? '')),
        'commissionType' => $commissionType,
        'commissionValue' => $commissionValue,
        'active' => filter_var($payload['active'] ?? false, FILTER_VALIDATE_BOOL),
        'createdAt' => (string) ($existing['createdAt'] ?? now_iso()),
        'updatedAt' => now_iso(),
    ]);
}

function uav2_save_partner(array $payload): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn() => uav2_save_partner($payload));
    $locks = uav2_lock_files([
        [LESSORS_FILE, LOCK_SH],
        [PARTNERS_FILE, LOCK_EX],
        [ADMIN_USERS_FILE, LOCK_SH],
        [REQUESTS_FILE, LOCK_SH],
        [RENTALS_FILE, LOCK_SH],
        [partner_payout_batches_file_path(), LOCK_SH],
        [AUDIT_LOG_FILE, LOCK_SH],
    ]);
    $saved = [];
    $created = false;
    $disableImpact = [];
    try {
        $lessorsData = uav2_read_json_unlocked(LESSORS_FILE, default_lessors());
        $usersData = uav2_normalize_users_container(uav2_read_json_unlocked(ADMIN_USERS_FILE, default_admin_users()));
        $actor = uav2_actor_from_container($usersData);
        if (!uav2_is_root($actor) || !uav2_user_has_permission($actor, 'partners.manage')) {
            throw new RuntimeException('Только Root может изменять партнёрские каналы.', 403);
        }
        $data = uav2_read_json_unlocked(PARTNERS_FILE, default_partners());
        $data['items'] = isset($data['items']) && is_array($data['items']) ? array_values($data['items']) : [];
        $originalSlug = normalize_partner_item(['slug' => (string) ($payload['originalSlug'] ?? ''), 'name' => 'x'])['slug'];
        $slug = normalize_partner_item(['slug' => (string) ($payload['slug'] ?? ''), 'name' => 'x'])['slug'];
        if ($originalSlug !== '' && $originalSlug !== $slug) {
            throw new InvalidArgumentException('Код существующего канала изменять нельзя.');
        }
        $index = null;
        foreach ($data['items'] as $i => $item) {
            if (is_array($item) && (string) ($item['slug'] ?? '') === $slug) {
                $index = (int) $i;
                break;
            }
        }
        if ($originalSlug === '' && $index !== null) {
            throw new RuntimeException('Канал с таким кодом уже существует.', 409);
        }
        if ($originalSlug !== '' && $index === null) {
            throw new RuntimeException('Канал больше не существует.', 409);
        }
        $existing = $index !== null ? normalize_partner_item((array) $data['items'][$index]) : null;
        $expected = (string) ($payload['expectedRecordHash'] ?? '');
        if ($existing && ($expected === '' || !hash_equals(uav2_entity_record_token($existing), $expected))) {
            throw new RuntimeException('Канал уже изменён в другой сессии.', 409);
        }
        if (!$existing && $expected !== 'new') {
            throw new RuntimeException('Форма создания канала устарела.', 409);
        }
        $saved = uav2_validate_partner_payload(array_merge($payload, ['slug' => $slug]), $existing, $lessorsData);
        if ($existing && !empty($existing['active']) && empty($saved['active'])) {
            $disableImpact = uav2_partner_dependency_counts_from_data(
                $slug,
                $usersData,
                uav2_read_json_unlocked(REQUESTS_FILE, default_requests()),
                uav2_read_json_unlocked(RENTALS_FILE, default_rentals()),
                uav2_read_json_unlocked(partner_payout_batches_file_path(), ['batches' => []]),
                uav2_read_json_unlocked(AUDIT_LOG_FILE, default_audit_log())
            );
        }
        if ($existing && uav2_entity_meaningful_token($existing) === uav2_entity_meaningful_token($saved)) {
            throw new InvalidArgumentException('Нет изменений для сохранения.');
        }
        $created = !$existing;
        if ($index === null) {
            array_unshift($data['items'], $saved);
        } else {
            $data['items'][$index] = array_replace($data['items'][$index], $saved);
        }
        $data['updatedAt'] = now_iso();
        uav2_write_json_unlocked(PARTNERS_FILE, $data);
    } finally {
        uav2_unlock_files($locks);
    }
    uav2_audit_log(
        $created ? 'partner.create' : (!empty($disableImpact) ? 'partner.disable' : 'partner.update'),
        'partner',
        (string) $saved['slug'],
        $created ? 'Создан партнёрский канал через Users & Access V2' : (!empty($disableImpact) ? 'Партнёрский канал отключён через Users & Access V2' : 'Партнёрский канал изменён через Users & Access V2'),
        $disableImpact ? ['dependenciesPreserved' => $disableImpact] : []
    );
    return $saved;
}

function uav2_partner_dependency_counts_from_data(string $slug, array $users, array $requests, array $rentals, array $payouts, array $audit): array
{
    $counts = ['representatives' => 0, 'requests' => 0, 'rentals' => 0, 'payouts' => 0, 'history' => 0];
    foreach ($users['users'] ?? [] as $item) {
        if (is_array($item) && (string) ($item['partnerSlug'] ?? '') === $slug) {
            $counts['representatives']++;
        }
    }
    foreach ($requests['items'] ?? [] as $item) {
        if (is_array($item) && (string) ($item['partnerSlug'] ?? '') === $slug) {
            $counts['requests']++;
        }
    }
    foreach ($rentals['items'] ?? [] as $item) {
        if (is_array($item) && (string) ($item['partnerSlug'] ?? '') === $slug) {
            $counts['rentals']++;
        }
    }
    foreach ($payouts['batches'] ?? [] as $item) {
        if (is_array($item) && (string) ($item['partnerSlug'] ?? '') === $slug) {
            $counts['payouts']++;
        }
    }
    foreach ($audit['items'] ?? [] as $item) {
        $action = is_array($item) ? (string) ($item['action'] ?? '') : '';
        if (is_array($item)
            && (string) ($item['entityType'] ?? '') === 'partner'
            && (string) ($item['entityId'] ?? '') === $slug
            && !in_array($action, ['partner.create', 'partner.update', 'partner.disable'], true)) {
            $counts['history']++;
        }
    }
    return $counts;
}

function uav2_delete_partner(string $slug, string $expectedRecordHash): bool
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn() => uav2_delete_partner($slug, $expectedRecordHash));
    $slug = normalize_partner_item(['slug' => $slug, 'name' => 'x'])['slug'];
    if ($slug === '') {
        throw new InvalidArgumentException('Канал не указан.');
    }
    $paths = [PARTNERS_FILE, ADMIN_USERS_FILE, REQUESTS_FILE, RENTALS_FILE, partner_payout_batches_file_path(), AUDIT_LOG_FILE];
    $handles = [];
    try {
        foreach ($paths as $index => $path) {
            $handles[] = uav2_lock_file($path, $index === 0 ? LOCK_EX : LOCK_SH);
        }
        $usersData = uav2_normalize_users_container(uav2_read_json_unlocked(ADMIN_USERS_FILE, default_admin_users()));
        $actor = uav2_actor_from_container($usersData);
        if (!uav2_is_root($actor) || !uav2_user_has_permission($actor, 'partners.manage')) {
            throw new RuntimeException('Только Root может удалить пустой канал.', 403);
        }
        $partners = uav2_read_json_unlocked(PARTNERS_FILE, default_partners());
        $index = null;
        foreach ($partners['items'] ?? [] as $i => $item) {
            if (is_array($item) && (string) ($item['slug'] ?? '') === $slug) {
                $index = (int) $i;
                break;
            }
        }
        if ($index === null) {
            throw new RuntimeException('Канал больше не существует.', 409);
        }
        $partner = normalize_partner_item((array) $partners['items'][$index]);
        if ($expectedRecordHash === '' || !hash_equals(uav2_entity_record_token($partner), $expectedRecordHash)) {
            throw new RuntimeException('Канал уже изменён в другой сессии.', 409);
        }
        $counts = uav2_partner_dependency_counts_from_data(
            $slug,
            $usersData,
            uav2_read_json_unlocked(REQUESTS_FILE, default_requests()),
            uav2_read_json_unlocked(RENTALS_FILE, default_rentals()),
            uav2_read_json_unlocked(partner_payout_batches_file_path(), ['batches' => []]),
            uav2_read_json_unlocked(AUDIT_LOG_FILE, default_audit_log())
        );
        if (array_sum($counts) > 0) {
            throw new RuntimeException('Канал связан с пользователями или историей и может быть только отключён.', 409);
        }
        array_splice($partners['items'], $index, 1);
        $partners['updatedAt'] = now_iso();
        uav2_write_json_unlocked(PARTNERS_FILE, $partners);
    } finally {
        uav2_unlock_files($handles);
    }
    uav2_audit_log('partner.delete', 'partner', $slug, 'Удалён пустой партнёрский канал через Users & Access V2');
    return true;
}

function uav2_partner_submission_guard_begin(string $partnerSlug): array
{
    if ($partnerSlug === '') {
        return [];
    }
    return uav2_lock_files([
        [PARTNERS_FILE, LOCK_SH],
        [ADMIN_USERS_FILE, LOCK_SH],
    ]);
}

function uav2_partner_submission_guard_end(array $handles): void
{
    uav2_unlock_files($handles);
}

function uav2_safe_state(): array
{
    $actor = current_admin_record();
    if (!is_array($actor)) {
        throw new RuntimeException('Пользователь не найден.', 403);
    }
    uav2_assert_actor_can_manage_users($actor);
    $root = uav2_is_root($actor);
    $actorDataScope = admin_user_scope_id($actor);
    $actorScope = $root ? 'rent_rk' : admin_user_lessor_slug($actor);
    $lessors = read_lessors()['items'];
    $scopes = [[
        'id' => 'rent_rk', 'name' => 'Rent RK', 'code' => 'rent-rk', 'active' => true,
        'showcase' => true, 'allowRentalDelete' => false, 'recordHash' => '', 'history' => [],
    ]];
    foreach ($lessors as $lessor) {
        if (!$root && scope_id_from_lessor_slug((string) $lessor['slug']) !== $actorDataScope) {
            continue;
        }
        $scope = [
            'id' => (string) $lessor['slug'], 'name' => (string) $lessor['name'], 'code' => (string) $lessor['slug'],
            'active' => !empty($lessor['active']), 'showcase' => !empty($lessor['visible_in_rent_rk_showcase']),
            'allowRentalDelete' => !empty($lessor['allow_lessor_rental_delete']),
            'recordHash' => uav2_entity_record_token($lessor),
            'history' => uav2_safe_history('lessor', (string) $lessor['slug']),
        ];
        $scopes[] = $scope;
    }
    $channels = [];
    if ($root) {
        $usersData = read_admin_users();
        $requests = read_requests();
        $rentals = read_rentals();
        $payouts = read_partner_payout_batches();
        $audit = read_audit_log();
        foreach (read_partners()['items'] as $partner) {
            $counts = uav2_partner_dependency_counts_from_data((string) $partner['slug'], $usersData, $requests, $rentals, $payouts, $audit);
            $channels[] = [
                'id' => (string) $partner['slug'], 'name' => (string) $partner['name'], 'code' => (string) $partner['slug'],
                'type' => (string) $partner['type'], 'active' => !empty($partner['active']),
                'ownerType' => (string) $partner['partner_owner_type'], 'ownerScopeId' => (string) $partner['partner_owner_scope_id'],
                'commissionType' => (string) $partner['commissionType'], 'commissionValue' => $partner['commissionValue'],
                'contactPerson' => (string) ($partner['contactPerson'] ?? ''), 'phone' => (string) ($partner['phone'] ?? ''),
                'defaultPickupPlace' => (string) ($partner['defaultPickupPlace'] ?? ''),
                'historyCount' => array_sum($counts), 'dependencies' => $counts,
                'recordHash' => uav2_entity_record_token($partner),
                'history' => uav2_safe_history('partner', (string) $partner['slug']),
            ];
        }
    }
    $users = [];
    foreach (read_admin_users()['users'] as $user) {
        if (!$root && ((string) ($user['role'] ?? '') !== 'manager' || admin_user_scope_id($user) !== $actorDataScope)) {
            continue;
        }
        $users[] = uav2_safe_user($user);
    }
    $profiles = array_values(array_filter(uav2_profile_definitions(), static function (array $profile) use ($root): bool {
        return $root || $profile['id'] === 'manager';
    }));
    $baseByProfile = [];
    foreach ($profiles as $profile) {
        $scopedProfile = in_array($profile['id'], ['manager', 'manager_cashier', 'lessor_admin'], true);
        $draft = ['role' => $profile['role'], 'lessorSlug' => $scopedProfile ? '__scope__' : ''];
        $baseByProfile[$profile['id']] = $profile['id'] === 'admin' ? uav2_permission_keys() : uav2_user_base_permissions($draft);
    }
    $baseByProfile['manager_cashier'] = $baseByProfile['manager'] ?? [];
    return [
        'generatedAt' => now_iso(),
        'csrfToken' => csrf_token(),
        'actor' => ['id' => (string) ($actor['login'] ?? ''), 'label' => $root ? 'Root' : ('Администратор парка «' . admin_topbar_scope_label($actor) . '»'), 'kind' => $root ? 'platform' : 'scope', 'scopeId' => $actorScope],
        'profiles' => $profiles,
        'scopes' => $scopes,
        'channels' => $channels,
        'users' => $users,
        'permissions' => [
            'catalogSize' => count(uav2_permission_keys()), 'reservedCount' => 8,
            'groups' => uav2_permission_catalog(),
            'dangerousKeys' => ['customers.delete', 'requests.delete', 'rentals.delete'],
            'managerExtraKeys' => uav2_manager_extra_permission_keys(false),
            'scopedManagerExtraKeys' => uav2_manager_extra_permission_keys(true),
            'externalAdminEditableKeys' => ['tariffs.view', 'tariffs.edit'],
            'profileAdds' => ['manager_cashier' => ['finance.view', 'finance.manage']],
            'baseByProfile' => $baseByProfile,
        ],
        'routes' => ['scopeSettings' => 'scope-settings.php', 'partnerStats' => 'finance.php'],
    ];
}
