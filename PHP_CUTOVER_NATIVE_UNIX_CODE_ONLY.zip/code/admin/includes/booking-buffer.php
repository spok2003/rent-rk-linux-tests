<?php

declare(strict_types=1);

const BOOKING_BUFFER_MAX_MINUTES = 10080;

function booking_buffer_modes(): array
{
    return [
        'warning' => 'Предупреждать и разрешать оформление',
        'block' => 'Запрещать оформление при коротком интервале',
    ];
}

function booking_buffer_normalize_scope_rules(mixed $rules): array
{
    if (!is_array($rules)) {
        return [];
    }

    $normalized = [];
    foreach ($rules as $rawScopeId => $rawRule) {
        $scopeId = trim((string) $rawScopeId);
        if ($scopeId === '' || !is_array($rawRule)) {
            continue;
        }
        $minutes = filter_var($rawRule['minutes'] ?? null, FILTER_VALIDATE_INT, [
            'options' => ['min_range' => 0, 'max_range' => BOOKING_BUFFER_MAX_MINUTES],
        ]);
        $mode = trim((string) ($rawRule['mode'] ?? ''));
        if ($minutes === false || !isset(booking_buffer_modes()[$mode])) {
            continue;
        }
        $normalized[$scopeId] = [
            'minutes' => (int) $minutes,
            'mode' => $mode,
            'updatedAt' => trim((string) ($rawRule['updatedAt'] ?? '')),
            'updatedBy' => trim((string) ($rawRule['updatedBy'] ?? '')),
        ];
    }
    ksort($normalized);

    return $normalized;
}

function booking_buffer_rule_for_scope(string $scopeId, ?array $settings = null): array
{
    $scopeId = trim($scopeId) ?: 'rent_rk';
    $settings ??= read_settings();
    $booking = isset($settings['booking']) && is_array($settings['booking']) ? $settings['booking'] : [];
    $rules = booking_buffer_normalize_scope_rules($booking['scopeRules'] ?? []);
    if (isset($rules[$scopeId])) {
        return $rules[$scopeId] + [
            'scopeId' => $scopeId,
            'scopeLabel' => scope_display_name($scopeId),
            'configured' => true,
            'source' => 'scope',
        ];
    }

    $legacyHours = (int) ($booking['bufferHours'] ?? 2);
    if ($legacyHours < 0) {
        $legacyHours = 2;
    }

    return [
        'scopeId' => $scopeId,
        'scopeLabel' => scope_display_name($scopeId),
        'minutes' => $legacyHours * 60,
        'mode' => 'block',
        'configured' => false,
        'source' => 'legacy_buffer_hours',
        'updatedAt' => '',
        'updatedBy' => '',
    ];
}

function booking_buffer_rule_for_car(string $carSlug, ?array $settings = null): array
{
    $car = $carSlug !== '' ? find_car($carSlug) : null;
    $scopeId = $car ? car_owner_scope_id($car) : 'rent_rk';

    return booking_buffer_rule_for_scope($scopeId, $settings);
}

function booking_buffer_duration_label(int $minutes): string
{
    return format_minutes_duration(max(0, $minutes));
}

function booking_buffer_can_manage_scope(string $scopeId): bool
{
    $scopeId = trim($scopeId);
    if ($scopeId === '' || !scope_control_item($scopeId)) {
        return false;
    }
    if (current_user_is_platform_admin() && has_permission('scopes.manage')) {
        return scope_control_can_view($scopeId);
    }

    return current_admin_role() === 'lessor'
        && current_user_can_view_my_scope()
        && $scopeId === current_lessor_scope_id();
}

function booking_buffer_parse_minutes(mixed $raw): int
{
    $value = trim((string) $raw);
    if ($value === '' || preg_match('/^\d+$/D', $value) !== 1) {
        throw new InvalidArgumentException('Время подготовки указывается целым числом минут.');
    }
    if (strlen($value) > 5 || (int) $value > BOOKING_BUFFER_MAX_MINUTES) {
        throw new InvalidArgumentException('Время подготовки должно быть от 0 до 10 080 минут.');
    }

    return (int) $value;
}

function save_booking_buffer_scope_rule(string $scopeId, mixed $minutesRaw, string $mode, ?string $expectedVersion = null): array
{
    $scopeId = trim($scopeId);
    if (!booking_buffer_can_manage_scope($scopeId)) {
        deny_scope_access();
    }
    $minutes = booking_buffer_parse_minutes($minutesRaw);
    if (!isset(booking_buffer_modes()[$mode])) {
        throw new InvalidArgumentException('Выберите корректный режим короткого интервала.');
    }

    $work = static function () use ($scopeId, $minutes, $mode, $expectedVersion): array {
        if (!booking_buffer_can_manage_scope($scopeId)) deny_scope_access();
        if ($expectedVersion !== null) business_assert_form_version([SETTINGS_FILE], $expectedVersion);
        $settings = read_settings();
        $before = booking_buffer_rule_for_scope($scopeId, $settings);
        $rules = booking_buffer_normalize_scope_rules($settings['booking']['scopeRules'] ?? []);
        $rules[$scopeId] = [
            'minutes' => $minutes,
            'mode' => $mode,
            'updatedAt' => now_iso(),
            'updatedBy' => current_admin_user() ?: 'system',
        ];
        $settings['booking']['scopeRules'] = $rules;
        save_settings($settings);
        $after = booking_buffer_rule_for_scope($scopeId);
        audit_log('booking.buffer_scope_rule.updated', 'scope', $scopeId, 'Изменено время подготовки между арендами', [
            'scopeId' => $scopeId,
            'before' => ['minutes' => (int) $before['minutes'], 'mode' => (string) $before['mode'], 'configured' => !empty($before['configured'])],
            'after' => ['minutes' => (int) $after['minutes'], 'mode' => (string) $after['mode'], 'configured' => true],
        ]);

        return $after;
    };
    return RentalReturnStore::active() ? $work() : RentalReturnStore::transaction($work);
}

function normalize_booking_buffer_acceptance(mixed $value): array
{
    $value = is_array($value) ? $value : [];
    $conditions = isset($value['conditions']) && is_array($value['conditions']) ? $value['conditions'] : [];

    return [
        'fingerprint' => trim((string) ($value['fingerprint'] ?? '')),
        'acceptedAt' => trim((string) ($value['acceptedAt'] ?? '')),
        'acceptedBy' => trim((string) ($value['acceptedBy'] ?? '')),
        'conditions' => array_values(array_filter($conditions, 'is_array')),
    ];
}

function booking_buffer_conflict_item_key(array $item): string
{
    return implode('|', [
        (string) ($item['code'] ?? ''),
        (string) ($item['carSlug'] ?? ''),
        (string) ($item['neighborRentalId'] ?? ''),
        (string) ($item['direction'] ?? ''),
        (string) ($item['date'] ?? ''),
        (string) ($item['message'] ?? ''),
    ]);
}

function booking_buffer_conflict_add(array &$items, array &$seen, array $item): void
{
    $item += [
        'code' => 'unknown',
        'message' => 'Проверка доступности не пройдена.',
        'carSlug' => '',
        'scopeId' => '',
        'neighborRentalId' => '',
        'direction' => '',
    ];
    $key = booking_buffer_conflict_item_key($item);
    if (!isset($seen[$key])) {
        $seen[$key] = true;
        $items[] = $item;
    }
}

function booking_buffer_rental_evaluation(array $rental, ?string $ignoreId = null): array
{
    $rental = normalize_rental_item($rental);
    $blockers = [];
    $warnings = [];
    $seenBlockers = [];
    $seenWarnings = [];

    if (!$rental['vehicleSegments']) {
        booking_buffer_conflict_add($blockers, $seenBlockers, ['code' => 'car_missing', 'message' => 'Выберите автомобиль.']);
    }
    $period = rental_period_bounds($rental);
    if (!$period) {
        booking_buffer_conflict_add($blockers, $seenBlockers, ['code' => 'period_invalid', 'message' => 'Укажите корректные даты и время подачи/возврата.']);
        return ['blockers' => $blockers, 'warnings' => $warnings];
    }
    if (!$rental['vehicleSegments']) {
        return ['blockers' => $blockers, 'warnings' => $warnings];
    }

    $availabilityStatuses = availability_statuses();
    foreach ($rental['vehicleSegments'] as $segment) {
        $carSlug = trim((string) ($segment['carSlug'] ?? ''));
        if ($carSlug === '') {
            continue;
        }
        $segmentPeriod = rental_segment_period_bounds($segment, $rental);
        if (!$segmentPeriod) {
            continue;
        }
        [$startAt, $endAt] = $segmentPeriod;
        $rule = booking_buffer_rule_for_car($carSlug);
        $thresholdSeconds = (int) $rule['minutes'] * 60;

        foreach (rental_segment_date_keys($segment, $rental) as $date) {
            $entry = availability_entry_for_date($carSlug, $date);
            if (!$entry) {
                continue;
            }
            $entryRentalId = (string) ($entry['rentalId'] ?? '');
            $entryRequestId = (string) ($entry['requestId'] ?? '');
            $entrySourceRentalId = (string) ($entry['sourceRentalId'] ?? '');
            $sameRental = $ignoreId !== null && $entryRentalId === $ignoreId;
            $sameServiceHoldRental = $ignoreId !== null && $entrySourceRentalId === $ignoreId;
            $sameSourceRequest = $entryRequestId !== '' && $entryRequestId === (string) ($rental['sourceRequestId'] ?? '');
            if ($sameRental || $sameServiceHoldRental || $sameSourceRequest) {
                continue;
            }
            $status = (string) ($entry['status'] ?? '');
            $isManualEntry = $entryRentalId === '' && $entryRequestId === '';
            if (rental_is_historical($rental) && $isManualEntry && $status !== 'service') {
                continue;
            }
            if (linked_rental_availability_entry_overlaps_period($entry, $carSlug, $startAt, $endAt) === false) {
                continue;
            }
            if ($status === 'service') {
                booking_buffer_conflict_add($blockers, $seenBlockers, [
                    'code' => 'service_hold',
                    'message' => car_name($carSlug) . ': машина в сервисе ' . format_ru_date($date) . '.',
                    'carSlug' => $carSlug,
                    'scopeId' => (string) $rule['scopeId'],
                    'date' => $date,
                ]);
            } elseif (isset($availabilityStatuses[$status])) {
                booking_buffer_conflict_add($blockers, $seenBlockers, [
                    'code' => 'calendar_block',
                    'message' => car_name($carSlug) . ': в календаре уже стоит статус "' . $availabilityStatuses[$status] . '" на ' . format_ru_date($date) . '.',
                    'carSlug' => $carSlug,
                    'scopeId' => (string) $rule['scopeId'],
                    'date' => $date,
                ]);
            }
        }

        foreach (read_rentals()['items'] as $existingRaw) {
            $existing = normalize_rental_item(is_array($existingRaw) ? $existingRaw : []);
            $existingId = (string) ($existing['id'] ?? '');
            if (($ignoreId !== null && $existingId === $ignoreId) || !rental_blocks_availability($existing)) {
                continue;
            }
            foreach ($existing['vehicleSegments'] as $existingSegment) {
                if ((string) ($existingSegment['carSlug'] ?? '') !== $carSlug) {
                    continue;
                }
                $existingPeriod = rental_segment_period_bounds($existingSegment, $existing);
                if (!$existingPeriod) {
                    continue;
                }
                [$existingStart, $existingEnd] = $existingPeriod;
                $intersects = $startAt < $existingEnd && $endAt > $existingStart;
                if ($intersects) {
                    booking_buffer_conflict_add($blockers, $seenBlockers, [
                        'code' => 'rental_overlap',
                        'message' => car_name($carSlug) . ': период пересекается с ' . format_rental_number($existing) . ': ' . format_request_period($existing) . '.'
                            . rental_overlap_correction_hint($rental, $existing, $startAt, $endAt, $existingStart, $existingEnd),
                        'carSlug' => $carSlug,
                        'scopeId' => (string) $rule['scopeId'],
                        'neighborRentalId' => $existingId,
                    ]);
                    continue;
                }
                if (rental_should_skip_operational_buffer_conflict($rental)) {
                    continue;
                }

                $direction = '';
                $gapSeconds = null;
                $neighborAt = null;
                $currentAt = null;
                if ($startAt >= $existingEnd) {
                    $direction = 'before';
                    $gapSeconds = $startAt->getTimestamp() - $existingEnd->getTimestamp();
                    $neighborAt = $existingEnd;
                    $currentAt = $startAt;
                } elseif ($existingStart >= $endAt) {
                    $direction = 'after';
                    $gapSeconds = $existingStart->getTimestamp() - $endAt->getTimestamp();
                    $neighborAt = $existingStart;
                    $currentAt = $endAt;
                }
                if ($gapSeconds === null || $gapSeconds >= $thresholdSeconds) {
                    continue;
                }

                $actualMinutes = intdiv(max(0, $gapSeconds), 60);
                $message = car_name($carSlug) . ': между арендами ' . booking_buffer_duration_label($actualMinutes)
                    . ', в контуре «' . (string) $rule['scopeLabel'] . '» установлено ' . booking_buffer_duration_label((int) $rule['minutes']) . '. '
                    . ($direction === 'before' ? 'Предыдущий возврат: ' : 'Следующая выдача: ')
                    . ($neighborAt ? $neighborAt->format('d.m.Y H:i') : '') . ', '
                    . ($direction === 'before' ? 'новая выдача: ' : 'новый возврат: ')
                    . ($currentAt ? $currentAt->format('d.m.Y H:i') : '') . '.';
                $item = [
                    'code' => 'preparation_gap_short',
                    'message' => $message,
                    'carSlug' => $carSlug,
                    'carName' => car_name($carSlug),
                    'scopeId' => (string) $rule['scopeId'],
                    'scopeLabel' => (string) $rule['scopeLabel'],
                    'neighborRentalId' => $existingId,
                    'neighborRentalNumber' => format_rental_number($existing),
                    'neighborPeriod' => format_request_period($existing),
                    'direction' => $direction,
                    'gapSeconds' => $gapSeconds,
                    'gapMinutes' => $actualMinutes,
                    'thresholdMinutes' => (int) $rule['minutes'],
                    'mode' => (string) $rule['mode'],
                    'segmentStart' => $startAt->format(DateTimeInterface::ATOM),
                    'segmentEnd' => $endAt->format(DateTimeInterface::ATOM),
                    'neighborStart' => $existingStart->format(DateTimeInterface::ATOM),
                    'neighborEnd' => $existingEnd->format(DateTimeInterface::ATOM),
                ];
                if ((string) $rule['mode'] === 'warning') {
                    booking_buffer_conflict_add($warnings, $seenWarnings, $item);
                } else {
                    booking_buffer_conflict_add($blockers, $seenBlockers, $item);
                }
            }
        }
    }

    return ['blockers' => $blockers, 'warnings' => $warnings];
}

function booking_buffer_warning_fingerprint(array $warnings): string
{
    $conditions = [];
    foreach ($warnings as $warning) {
        if ((string) ($warning['code'] ?? '') !== 'preparation_gap_short') {
            continue;
        }
        $conditions[] = array_intersect_key($warning, array_flip([
            'code', 'carSlug', 'scopeId', 'neighborRentalId', 'direction', 'gapSeconds',
            'thresholdMinutes', 'mode', 'segmentStart', 'segmentEnd', 'neighborStart', 'neighborEnd',
        ]));
    }
    usort($conditions, static fn(array $left, array $right): int => strcmp(
        json_encode($left, JSON_UNESCAPED_SLASHES),
        json_encode($right, JSON_UNESCAPED_SLASHES)
    ));

    return $conditions ? hash('sha256', json_encode($conditions, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES)) : '';
}

function booking_buffer_schedule_signature(array $rental): string
{
    $rental = normalize_rental_item($rental);
    $segments = array_map(static fn(array $segment): array => array_intersect_key($segment, array_flip([
        'carSlug', 'startedAt', 'endedAt',
    ])), $rental['vehicleSegments']);

    return hash('sha256', json_encode([
        'startDate' => $rental['startDate'],
        'startTime' => $rental['startTime'],
        'endDate' => $rental['endDate'],
        'endTime' => $rental['endTime'],
        'segments' => $segments,
    ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
}

function booking_buffer_prepare_rental_for_save(array $rental, ?string $ignoreId = null, string $submittedFingerprint = '', bool $allowUnchangedLegacy = false, ?array $before = null): array
{
    $rental = normalize_rental_item($rental);
    $evaluation = booking_buffer_rental_evaluation($rental, $ignoreId);
    if ($evaluation['blockers']) {
        throw new RuntimeException(implode(' ', array_column($evaluation['blockers'], 'message')));
    }
    if (!$evaluation['warnings']) {
        $rental['bookingBufferAcceptance'] = normalize_booking_buffer_acceptance([]);
        return $rental;
    }

    $fingerprint = booking_buffer_warning_fingerprint($evaluation['warnings']);
    $existingAcceptance = normalize_booking_buffer_acceptance($rental['bookingBufferAcceptance'] ?? []);
    if ($existingAcceptance['fingerprint'] !== '' && hash_equals($existingAcceptance['fingerprint'], $fingerprint)) {
        return $rental;
    }
    if ($allowUnchangedLegacy && $before && booking_buffer_schedule_signature($before) === booking_buffer_schedule_signature($rental)) {
        return $rental;
    }
    if ($submittedFingerprint === '' || !hash_equals($fingerprint, trim($submittedFingerprint))) {
        throw new RuntimeException('Для выбранного автомобиля действует короткий интервал подготовки. Проверьте актуальное предупреждение и нажмите «Оформить с коротким интервалом».', 409);
    }

    $rental['bookingBufferAcceptance'] = [
        'fingerprint' => $fingerprint,
        'acceptedAt' => now_iso(),
        'acceptedBy' => current_admin_user() ?: 'system',
        'conditions' => array_values(array_map(static fn(array $warning): array => array_intersect_key($warning, array_flip([
            'code', 'carSlug', 'carName', 'scopeId', 'scopeLabel', 'neighborRentalId',
            'neighborRentalNumber', 'direction', 'gapSeconds', 'gapMinutes', 'thresholdMinutes',
            'mode', 'segmentStart', 'segmentEnd', 'neighborStart', 'neighborEnd',
        ])), $evaluation['warnings'])),
    ];

    return $rental;
}

function booking_buffer_audit_acceptance_if_new(array $before, array $after): void
{
    $old = normalize_booking_buffer_acceptance($before['bookingBufferAcceptance'] ?? []);
    $new = normalize_booking_buffer_acceptance($after['bookingBufferAcceptance'] ?? []);
    if ($new['fingerprint'] === '' || $old['fingerprint'] === $new['fingerprint']) {
        return;
    }
    foreach ($new['conditions'] as $condition) {
        audit_log('rental.booking_buffer_warning.accepted', 'rental', (string) ($after['id'] ?? ''), 'Подтверждён короткий интервал подготовки', [
            'rentalId' => (string) ($after['id'] ?? ''),
            'carSlug' => (string) ($condition['carSlug'] ?? ''),
            'scopeId' => (string) ($condition['scopeId'] ?? ''),
            'neighborRentalId' => (string) ($condition['neighborRentalId'] ?? ''),
            'direction' => (string) ($condition['direction'] ?? ''),
            'gapSeconds' => (int) ($condition['gapSeconds'] ?? 0),
            'thresholdMinutes' => (int) ($condition['thresholdMinutes'] ?? 0),
            'mode' => (string) ($condition['mode'] ?? ''),
            'acceptedBy' => (string) $new['acceptedBy'],
            'acceptedAt' => (string) $new['acceptedAt'],
        ]);
    }
}
