<?php

declare(strict_types=1);

function demand_integration_actions(): array
{
    return [
        'save_integrations_settings', 'wordstat_refresh_credentials_status',
        'wordstat_wizard_save_credentials', 'wordstat_wizard_clear_credentials',
        'wordstat_wizard_save_dry_run_settings', 'wordstat_wizard_enable_live',
        'wordstat_wizard_disable_live', 'wordstat_test_connection', 'wordstat_load_regions',
        'wordstat_dry_run', 'direction_wordstat_dry_run', 'wordstat_live_sync',
        'integration_mock_sync', 'integration_build_snapshot', 'save_ai_api_settings',
        'save_ai_api_credentials', 'clear_ai_api_credentials', 'openai_test_connection',
    ];
}

function demand_integration_action_paths(string $action): array
{
    $wordstatCredentials = wordstat_credentials_path();
    $aiCredentials = openai_ai_credentials_path();
    return match ($action) {
        'save_integrations_settings', 'wordstat_refresh_credentials_status',
        'wordstat_wizard_save_dry_run_settings', 'wordstat_wizard_enable_live',
        'wordstat_wizard_disable_live' => [DEMAND_INTEGRATIONS_SETTINGS_FILE],
        'wordstat_wizard_save_credentials', 'wordstat_wizard_clear_credentials',
        'wordstat_test_connection' => [DEMAND_INTEGRATIONS_SETTINGS_FILE, $wordstatCredentials],
        'wordstat_load_regions' => [DEMAND_INTEGRATIONS_SETTINGS_FILE, WORDSTAT_REGIONS_CACHE_FILE, WORDSTAT_COST_LEDGER_FILE, $wordstatCredentials],
        'wordstat_dry_run', 'direction_wordstat_dry_run' => [DEMAND_INTEGRATIONS_SETTINGS_FILE, DEMAND_SYNC_RUNS_FILE, ANALYTICS_EVENTS_FILE],
        'wordstat_live_sync' => [DEMAND_INTEGRATIONS_SETTINGS_FILE, DEMAND_SYNC_RUNS_FILE, DEMAND_KEYWORDS_FILE,
            DEMAND_RECOMMENDATIONS_FILE, DEMAND_EXTERNAL_METRICS_FILE, DEMAND_INTEGRATION_ERRORS_FILE,
            WORDSTAT_QUERY_QUEUE_FILE, WORDSTAT_COST_LEDGER_FILE, ANALYTICS_EVENTS_FILE, $wordstatCredentials],
        'integration_mock_sync' => [DEMAND_INTEGRATIONS_SETTINGS_FILE, DEMAND_SYNC_RUNS_FILE,
            DEMAND_EXTERNAL_METRICS_FILE, DEMAND_INTEGRATION_ERRORS_FILE, ANALYTICS_EVENTS_FILE],
        'integration_build_snapshot' => [DEMAND_PERFORMANCE_SNAPSHOTS_FILE],
        'save_ai_api_settings' => [DEMAND_AI_SETTINGS_FILE],
        'save_ai_api_credentials', 'clear_ai_api_credentials', 'openai_test_connection' => [DEMAND_AI_SETTINGS_FILE, $aiCredentials],
        default => [],
    };
}

function demand_integration_primary_store(string $action): string
{
    return match ($action) {
        'save_integrations_settings', 'wordstat_refresh_credentials_status',
        'wordstat_wizard_save_credentials', 'wordstat_wizard_clear_credentials',
        'wordstat_wizard_save_dry_run_settings', 'wordstat_wizard_enable_live',
        'wordstat_wizard_disable_live', 'wordstat_test_connection', 'wordstat_load_regions' => DEMAND_INTEGRATIONS_SETTINGS_FILE,
        'wordstat_dry_run', 'direction_wordstat_dry_run', 'wordstat_live_sync', 'integration_mock_sync' => DEMAND_SYNC_RUNS_FILE,
        'integration_build_snapshot' => DEMAND_PERFORMANCE_SNAPSHOTS_FILE,
        'save_ai_api_settings', 'save_ai_api_credentials', 'clear_ai_api_credentials', 'openai_test_connection' => DEMAND_AI_SETTINGS_FILE,
        default => '',
    };
}

function demand_integration_transport_actions(): array
{
    return ['wordstat_test_connection', 'wordstat_load_regions', 'openai_test_connection'];
}

function demand_integration_authorize(string $action, array $payload): void
{
    $permission = match ($action) {
        'save_integrations_settings' => 'demand.integrations.manage',
        'wordstat_refresh_credentials_status', 'wordstat_test_connection' => 'demand.wordstat.test',
        'wordstat_wizard_save_credentials', 'wordstat_wizard_clear_credentials',
        'wordstat_wizard_save_dry_run_settings', 'wordstat_wizard_disable_live' => 'demand.wordstat.manage',
        'wordstat_wizard_enable_live' => 'demand.wordstat.live',
        'wordstat_load_regions', 'wordstat_dry_run', 'direction_wordstat_dry_run' => 'demand.wordstat.sync',
        'wordstat_live_sync' => 'demand.wordstat.live',
        'integration_mock_sync' => 'demand.integrations.sync',
        'integration_build_snapshot' => 'demand.performance.view',
        'save_ai_api_settings', 'save_ai_api_credentials', 'clear_ai_api_credentials', 'openai_test_connection' => 'demand.ai_api.settings.manage',
        default => throw new LogicException('Unsupported Demand integration action.'),
    };
    require_permission($permission);
    if ($action === 'wordstat_wizard_enable_live') {
        require_permission('demand.wordstat.manage');
    }
    if (in_array($action, ['wordstat_dry_run', 'direction_wordstat_dry_run', 'wordstat_live_sync'], true)
        && !current_user_is_platform_admin()) {
        deny_scope_access();
    }
    if (in_array($action, ['integration_mock_sync', 'integration_build_snapshot'], true)) {
        $scopeId = demand_normalize_scope_id((string) ($payload['target_scope_id'] ?? 'rent_rk'));
        if (!current_user_is_platform_admin() && !in_array($scopeId, demand_integrations_visible_scope_ids_for_current_user(), true)) {
            deny_scope_access();
        }
    }
}

function demand_integration_intent(string $action, array $payload, string $scopeFilter): array
{
    foreach (['csrf_token', 'command_id', 'expected_version', 'tab'] as $technical) unset($payload[$technical]);
    foreach (['wordstat_api_key', 'apiKey', 'deepseek_api_key'] as $secret) {
        if (!array_key_exists($secret, $payload)) continue;
        $value = trim((string) $payload[$secret]);
        $payload[$secret] = $value === '' ? 'unchanged' : ('sha256:' . hash('sha256', $value));
    }
    return ['action' => $action, 'scopeFilter' => $scopeFilter, 'payload' => $payload];
}

function demand_integration_execute(string $action, array $payload, string $scopeFilter, callable $work): array
{
    $paths = demand_integration_action_paths($action);
    $store = demand_integration_primary_store($action);
    if (!$paths || $store === '') throw new LogicException('Demand integration command storage is not configured.');
    $commandId = business_command_id($payload['command_id'] ?? null);
    $intent = demand_integration_intent($action, $payload, $scopeFilter);
    $authorize = static fn() => demand_integration_authorize($action, $payload);

    if (in_array($action, demand_integration_transport_actions(), true)) {
        $authorize();
        $fingerprint = hash('sha256', json_encode(business_command_canonical([
            'actor' => current_admin_user(), 'intent' => $intent,
        ]), JSON_THROW_ON_ERROR | JSON_PRESERVE_ZERO_FRACTION));
        $key = $action . ':' . $commandId;
        $receipts = is_array($_SESSION['demand_integration_receipts'] ?? null) ? $_SESSION['demand_integration_receipts'] : [];
        if (isset($receipts[$key])) {
            $receipt = $receipts[$key];
            if (!is_array($receipt) || !is_string($receipt['fingerprint'] ?? null) || !is_array($receipt['result'] ?? null)) {
                throw new RuntimeException('Повреждён результат интеграционной операции.', 503);
            }
            if (!hash_equals($receipt['fingerprint'], $fingerprint)) {
                throw new RuntimeException('Идентификатор уже использован для другой операции. Откройте новую форму.', 409);
            }
            return $receipt['result'];
        }
        RentalReturnStore::transaction(static function () use ($paths, $payload): void {
            business_assert_form_version($paths, $payload['expected_version'] ?? null);
        });
        $result = $work();
        if (!is_array($result)) $result = [];
        $receipts[$key] = ['fingerprint' => $fingerprint, 'result' => $result, 'completedAt' => now_iso()];
        $_SESSION['demand_integration_receipts'] = array_slice($receipts, -100, null, true);
        return $result;
    }

    $receipt = business_command(
        $store,
        'demand-' . $action,
        $commandId,
        $intent,
        $authorize,
        static function () use ($paths, $payload, $work): array {
            business_assert_form_version($paths, $payload['expected_version'] ?? null);
            $value = $work();
            return ['value' => is_array($value) ? $value : []];
        }
    );
    return is_array($receipt['value'] ?? null) ? $receipt['value'] : [];
}

function demand_integration_execute_waiting_command(
    string $action,
    array $payload,
    string $scopeFilter,
    callable $prepare,
    callable $wait,
    callable $commit
): array {
    $paths = demand_integration_action_paths($action);
    $store = demand_integration_primary_store($action);
    if (!$paths || $store === '') throw new LogicException('Demand integration command storage is not configured.');
    $commandId = business_command_id($payload['command_id'] ?? null);
    $intent = demand_integration_intent($action, $payload, $scopeFilter);
    $kind = 'demand-' . $action;
    $authorize = static fn() => demand_integration_authorize($action, $payload);

    $prepared = RentalReturnStore::transaction(static function () use (
        $store, $kind, $commandId, $intent, $authorize, $paths, $payload, $prepare
    ): array {
        $authorize();
        $fingerprint = hash('sha256', json_encode(business_command_canonical([
            'kind' => $kind, 'actor' => current_admin_user(), 'intent' => $intent,
        ]), JSON_THROW_ON_ERROR | JSON_PRESERVE_ZERO_FRACTION));
        $data = read_json_file($store, ['items' => []]);
        $receipts = $data['commandReceipts'] ?? [];
        if (!is_array($receipts)) throw new RuntimeException('Повреждён журнал операций. Запись остановлена.', 503);
        $key = $kind . ':' . $commandId;
        if (array_key_exists($key, $receipts)) {
            $receipt = $receipts[$key];
            if (!is_array($receipt) || !is_string($receipt['fingerprint'] ?? null) || !is_array($receipt['result'] ?? null)) {
                throw new RuntimeException('Повреждена запись результата операции.', 503);
            }
            if (!hash_equals($receipt['fingerprint'], $fingerprint)) {
                throw new RuntimeException('Идентификатор уже использован для другой операции. Откройте новую форму.', 409);
            }
            return ['replayed' => true, 'result' => $receipt['result']];
        }
        business_assert_form_version($paths, $payload['expected_version'] ?? null);
        $value = $prepare();
        if (!is_array($value)) throw new LogicException('Prepared integration command state must be an array.');
        return ['replayed' => false, 'prepared' => $value];
    });
    if (!empty($prepared['replayed'])) {
        return is_array($prepared['result']['value'] ?? null) ? $prepared['result']['value'] : [];
    }

    $waitResult = RentalReturnStore::waitOutsideLock(static fn() => $wait($prepared['prepared']));
    if (!is_array($waitResult)) throw new LogicException('Integration wait result must be an array.');
    $receipt = business_command(
        $store,
        $kind,
        $commandId,
        $intent,
        $authorize,
        static function () use ($paths, $payload, $commit, $prepared, $waitResult): array {
            business_assert_form_version($paths, $payload['expected_version'] ?? null);
            $value = $commit($prepared['prepared'], $waitResult);
            return ['value' => is_array($value) ? $value : []];
        }
    );
    return is_array($receipt['value'] ?? null) ? $receipt['value'] : [];
}

function demand_integration_command_fields(string $action): string
{
    $paths = demand_integration_action_paths($action);
    if (!$paths) throw new LogicException('Demand integration command fields are not configured.');
    return '<input type="hidden" name="command_id" value="' . e(bin2hex(random_bytes(16))) . '">'
        . '<input type="hidden" name="expected_version" value="' . e(business_form_version($paths)) . '">';
}

function demand_integrations_controlled_transport(string $provider, array $request): ?array
{
    $transport = $GLOBALS['rent_rk_demand_test_transport'] ?? null;
    if (is_callable($transport)) {
        $result = $transport($provider, $request);
        if (!is_array($result)) throw new RuntimeException('Controlled transport returned an invalid result.');
        return $result;
    }
    if (getenv('RENT_RK_QA_BLOCK_EXTERNAL_TRANSPORT') === '1') {
        throw new RuntimeException('External transport is blocked in the isolated laboratory.');
    }
    return null;
}

function demand_integrations_supported_sources(): array
{
    return [
        'wordstat' => [
            'label' => 'Wordstat',
            'description' => 'Источник внешнего спроса: частотность, динамика, регионы и похожие запросы. Этап 3.2 поддерживает mock/dry-run и controlled live sync без автопубликации.',
            'allowedModes' => ['disabled', 'mock', 'dry_run', 'manual_import', 'live_controlled'],
            'defaultMode' => 'dry_run',
            'defaultAuthStatus' => 'not_configured',
            'forcedDryRunOnly' => false,
        ],
        'yandex_webmaster' => [
            'label' => 'Yandex Webmaster',
            'description' => 'Источник поисковой обратной связи: показы, клики, индексирование, проблемы URL. На этапе 3.1 работает только как подготовленный источник без реального API.',
            'allowedModes' => ['disabled', 'mock', 'manual_import', 'api_ready_placeholder'],
            'defaultMode' => 'mock',
            'defaultAuthStatus' => 'not_configured',
            'forcedDryRunOnly' => true,
        ],
        'yandex_metrica' => [
            'label' => 'Yandex Metrica',
            'description' => 'Источник поведения и конверсий: визиты, цели, заявки, клики, страницы. На этапе 3.1 без реального API.',
            'allowedModes' => ['disabled', 'mock', 'manual_import', 'api_ready_placeholder'],
            'defaultMode' => 'mock',
            'defaultAuthStatus' => 'not_configured',
            'forcedDryRunOnly' => true,
        ],
        'ai_referrals' => [
            'label' => 'AI-referrals',
            'description' => 'Локальный источник на основе referrer/utm и внутренней аналитики: ChatGPT, Perplexity, Copilot и другие AI-переходы.',
            'allowedModes' => ['disabled', 'mock', 'manual_import', 'local_analytics'],
            'defaultMode' => 'local_analytics',
            'defaultAuthStatus' => 'not_required',
            'forcedDryRunOnly' => false,
        ],
    ];
}

function demand_integrations_default_source_settings(string $source): array
{
    $definition = demand_integrations_supported_sources()[$source] ?? [];
    $isAi = $source === 'ai_referrals';

    $base = [
        'enabled' => $isAi,
        'mode' => (string) ($definition['defaultMode'] ?? 'mock'),
        'authStatus' => (string) ($definition['defaultAuthStatus'] ?? 'not_configured'),
        'lastSyncAt' => null,
        'lastSuccessAt' => null,
        'lastErrorAt' => null,
        'lastError' => null,
        'allowExternalScopes' => false,
        'dryRunOnly' => !$isAi,
    ];

    if ($source === 'wordstat') {
        $base = array_merge($base, [
            'credentialSource' => 'not_configured',
            'folderIdConfigured' => false,
            'apiKeyConfigured' => false,
            'baseUrlConfigured' => false,
            'maskedCredentialLabel' => null,
            'liveEnabled' => false,
            'dailyRequestLimit' => 100,
            'monthlyRequestLimit' => 1000,
            'perRunRequestLimit' => 20,
            'estimatedCostLimitRub' => 500,
            'cooldownSecondsBetweenRequests' => 2,
            'retryAttempts' => 2,
            'retryBackoffSeconds' => 5,
            'defaultRegionIds' => ['11470', '977'],
            'defaultSeedPhrases' => ['аренда авто ялта'],
            'lastRegionsTreeAt' => null,
        ]);
    }

    return $base;
}

function demand_integrations_default_settings(): array
{
    $sources = [];
    foreach (array_keys(demand_integrations_supported_sources()) as $source) {
        $sources[$source] = demand_integrations_default_source_settings($source);
    }

    return [
        'updatedAt' => null,
        'updatedBy' => 'system',
        'rent_rk' => [
            'enabled' => true,
            'sources' => $sources,
        ],
    ];
}

function demand_integrations_clean_string($value, int $maxLength = 500): string
{
    return function_exists('demand_clean_string')
        ? demand_clean_string($value, $maxLength)
        : substr(trim((string) $value), 0, $maxLength);
}

function demand_integrations_normalize_source_settings(string $source, array $settings): array
{
    $definitions = demand_integrations_supported_sources();
    $definition = $definitions[$source] ?? null;
    if (!$definition) {
        return [];
    }

    foreach (['token', 'accessToken', 'oauthToken', 'apiKey', 'secret', 'clientSecret', 'credentials', 'password'] as $secretKey) {
        unset($settings[$secretKey]);
    }

    $default = demand_integrations_default_source_settings($source);
    $allowedModes = (array) ($definition['allowedModes'] ?? ['mock']);
    $mode = demand_integrations_clean_string((string) ($settings['mode'] ?? $default['mode']), 80);
    if (in_array($mode, ['live', 'api_enabled', 'production'], true)) {
        $mode = 'api_ready_placeholder';
    }
    if (!in_array($mode, $allowedModes, true)) {
        $mode = (string) $default['mode'];
    }
    if ($mode === 'disabled') {
        $settings['enabled'] = false;
    }

    $authStatus = demand_integrations_clean_string((string) ($settings['authStatus'] ?? $default['authStatus']), 80);
    $allowedAuthStatuses = $source === 'wordstat'
        ? ['not_configured', 'configured', 'test_success', 'test_failed', 'error', 'not_required']
        : ['not_configured', 'configured', 'error', 'not_required'];
    if (!in_array($authStatus, $allowedAuthStatuses, true)) {
        $authStatus = (string) $default['authStatus'];
    }
    if ($source === 'ai_referrals') {
        $authStatus = 'not_required';
    }

    $forcedDryRun = !empty($definition['forcedDryRunOnly']);

    $normalized = array_merge($settings, [
        'enabled' => !empty($settings['enabled']),
        'mode' => $mode,
        'authStatus' => $authStatus,
        'lastSyncAt' => isset($settings['lastSyncAt']) && $settings['lastSyncAt'] !== '' ? (string) $settings['lastSyncAt'] : null,
        'lastSuccessAt' => isset($settings['lastSuccessAt']) && $settings['lastSuccessAt'] !== '' ? (string) $settings['lastSuccessAt'] : null,
        'lastErrorAt' => isset($settings['lastErrorAt']) && $settings['lastErrorAt'] !== '' ? (string) $settings['lastErrorAt'] : null,
        'lastError' => isset($settings['lastError']) && $settings['lastError'] !== '' ? demand_integrations_clean_string($settings['lastError'], 1000) : null,
        'allowExternalScopes' => !empty($settings['allowExternalScopes']),
        'dryRunOnly' => $forcedDryRun ? true : !empty($settings['dryRunOnly']),
    ]);
    unset($normalized['apiKey'], $normalized['secret'], $normalized['credentials']);

    if ($source === 'wordstat') {
        $regions = is_array($settings['defaultRegionIds'] ?? null)
            ? $settings['defaultRegionIds']
            : (is_array($default['defaultRegionIds'] ?? null) ? $default['defaultRegionIds'] : []);
        $seeds = is_array($settings['defaultSeedPhrases'] ?? null)
            ? $settings['defaultSeedPhrases']
            : (is_array($default['defaultSeedPhrases'] ?? null) ? $default['defaultSeedPhrases'] : []);
        $normalized = array_merge($normalized, [
            'credentialSource' => in_array((string) ($settings['credentialSource'] ?? ''), ['env', 'private_file', 'not_configured'], true) ? (string) $settings['credentialSource'] : 'not_configured',
            'folderIdConfigured' => !empty($settings['folderIdConfigured']),
            'apiKeyConfigured' => !empty($settings['apiKeyConfigured']),
            'baseUrlConfigured' => !empty($settings['baseUrlConfigured']),
            'maskedCredentialLabel' => isset($settings['maskedCredentialLabel']) && $settings['maskedCredentialLabel'] !== '' ? demand_integrations_clean_string((string) $settings['maskedCredentialLabel'], 120) : null,
            'lastErrorCode' => isset($settings['lastErrorCode']) && $settings['lastErrorCode'] !== '' ? demand_integrations_clean_string((string) $settings['lastErrorCode'], 120) : null,
            'lastErrorAdvice' => isset($settings['lastErrorAdvice']) && $settings['lastErrorAdvice'] !== '' ? demand_integrations_clean_string((string) $settings['lastErrorAdvice'], 1000) : null,
            'lastErrorTechnical' => isset($settings['lastErrorTechnical']) && $settings['lastErrorTechnical'] !== '' ? demand_integrations_clean_string((string) $settings['lastErrorTechnical'], 1000) : null,
            'liveEnabled' => $mode === 'live_controlled' && !empty($settings['liveEnabled']),
            'dailyRequestLimit' => max(0, min(100000, (int) ($settings['dailyRequestLimit'] ?? 100))),
            'monthlyRequestLimit' => max(0, min(1000000, (int) ($settings['monthlyRequestLimit'] ?? 1000))),
            'perRunRequestLimit' => max(0, min(10000, (int) ($settings['perRunRequestLimit'] ?? 20))),
            'estimatedCostLimitRub' => max(0, min(1000000, (float) ($settings['estimatedCostLimitRub'] ?? 500))),
            'cooldownSecondsBetweenRequests' => max(0, min(3600, (int) ($settings['cooldownSecondsBetweenRequests'] ?? 2))),
            'retryAttempts' => max(0, min(10, (int) ($settings['retryAttempts'] ?? 2))),
            'retryBackoffSeconds' => max(0, min(3600, (int) ($settings['retryBackoffSeconds'] ?? 5))),
            'defaultRegionIds' => array_values(array_unique(array_filter(array_map(
                static fn($value): string => demand_integrations_clean_string((string) $value, 80),
                $regions
            )))),
            'defaultSeedPhrases' => array_values(array_unique(array_filter(array_map(
                static fn($value): string => demand_integrations_clean_string((string) $value, 240),
                $seeds
            )))),
            'lastRegionsTreeAt' => isset($settings['lastRegionsTreeAt']) && $settings['lastRegionsTreeAt'] !== '' ? (string) $settings['lastRegionsTreeAt'] : null,
        ]);
        $normalized['dryRunOnly'] = $mode !== 'live_controlled' || empty($normalized['liveEnabled']);
    }

    return $normalized;
}

function demand_integrations_normalize_settings(array $data): array
{
    $default = demand_integrations_default_settings();
    $rentRk = isset($data['rent_rk']) && is_array($data['rent_rk']) ? $data['rent_rk'] : [];
    $sourcesPayload = isset($rentRk['sources']) && is_array($rentRk['sources']) ? $rentRk['sources'] : [];
    $sources = [];
    foreach (array_keys(demand_integrations_supported_sources()) as $source) {
        $sourcePayload = isset($sourcesPayload[$source]) && is_array($sourcesPayload[$source]) ? $sourcesPayload[$source] : [];
        $sources[$source] = demand_integrations_normalize_source_settings($source, array_merge(
            demand_integrations_default_source_settings($source),
            $sourcePayload
        ));
    }

    $normalized = array_merge($data, [
        'updatedAt' => isset($data['updatedAt']) && $data['updatedAt'] !== '' ? (string) $data['updatedAt'] : null,
        'updatedBy' => (string) ($data['updatedBy'] ?? 'system'),
        'rent_rk' => [
            'enabled' => array_key_exists('enabled', $rentRk) ? !empty($rentRk['enabled']) : true,
            'sources' => $sources,
        ],
    ]);
    unset($normalized['apiKey'], $normalized['secret'], $normalized['credentials']);
    return $normalized;
}

function demand_integrations_get_settings(): array
{
    $default = demand_integrations_default_settings();
    $data = is_file(DEMAND_INTEGRATIONS_SETTINGS_FILE)
        ? read_json_file(DEMAND_INTEGRATIONS_SETTINGS_FILE, $default)
        : $default;

    return demand_integrations_normalize_settings(is_array($data) ? $data : $default);
}

function demand_integrations_save_settings(array $payload): array
{
    require_permission('demand.integrations.manage');

    $current = demand_integrations_get_settings();
    $sourcesPayload = isset($payload['sources']) && is_array($payload['sources']) ? $payload['sources'] : [];
    $next = $current;
    $next['rent_rk']['enabled'] = isset($payload['enabled']);
    foreach (array_keys(demand_integrations_supported_sources()) as $source) {
        $sourcePayload = isset($sourcesPayload[$source]) && is_array($sourcesPayload[$source]) ? $sourcesPayload[$source] : [];
        $existing = $current['rent_rk']['sources'][$source] ?? demand_integrations_default_source_settings($source);
        $next['rent_rk']['sources'][$source] = demand_integrations_normalize_source_settings($source, array_merge($existing, [
            'enabled' => isset($sourcePayload['enabled']),
            'mode' => (string) ($sourcePayload['mode'] ?? ($existing['mode'] ?? 'mock')),
            'authStatus' => (string) ($sourcePayload['authStatus'] ?? ($existing['authStatus'] ?? 'not_configured')),
            'allowExternalScopes' => isset($sourcePayload['allowExternalScopes']),
            'dryRunOnly' => isset($sourcePayload['dryRunOnly']),
            'liveEnabled' => isset($sourcePayload['liveEnabled']),
            'dailyRequestLimit' => $sourcePayload['dailyRequestLimit'] ?? ($existing['dailyRequestLimit'] ?? null),
            'monthlyRequestLimit' => $sourcePayload['monthlyRequestLimit'] ?? ($existing['monthlyRequestLimit'] ?? null),
            'perRunRequestLimit' => $sourcePayload['perRunRequestLimit'] ?? ($existing['perRunRequestLimit'] ?? null),
            'estimatedCostLimitRub' => $sourcePayload['estimatedCostLimitRub'] ?? ($existing['estimatedCostLimitRub'] ?? null),
            'cooldownSecondsBetweenRequests' => $sourcePayload['cooldownSecondsBetweenRequests'] ?? ($existing['cooldownSecondsBetweenRequests'] ?? null),
            'retryAttempts' => $sourcePayload['retryAttempts'] ?? ($existing['retryAttempts'] ?? null),
            'retryBackoffSeconds' => $sourcePayload['retryBackoffSeconds'] ?? ($existing['retryBackoffSeconds'] ?? null),
            'defaultRegionIds' => isset($sourcePayload['defaultRegionIds'])
                ? preg_split('/[\s,;]+/u', (string) $sourcePayload['defaultRegionIds'])
                : ($existing['defaultRegionIds'] ?? []),
            'defaultSeedPhrases' => isset($sourcePayload['defaultSeedPhrases'])
                ? preg_split('/[\r\n,;]+/u', (string) $sourcePayload['defaultSeedPhrases'])
                : ($existing['defaultSeedPhrases'] ?? []),
        ]));
    }
    $next['updatedAt'] = now_iso();
    $next['updatedBy'] = current_admin_user() ?: 'system';
    write_json_file(DEMAND_INTEGRATIONS_SETTINGS_FILE, $next);

    audit_log('demand.integrations.settings.updated', 'demand_integrations', 'settings', 'Demand integration settings updated', [
        'sources' => array_keys(demand_integrations_supported_sources()),
        'liveApiEnabled' => !empty($next['rent_rk']['sources']['wordstat']['liveEnabled']),
    ]);

    return $next;
}

function demand_integrations_list_sources(): array
{
    $settings = demand_integrations_get_settings();
    $sources = [];
    foreach (demand_integrations_supported_sources() as $source => $definition) {
        $sources[$source] = array_merge($definition, $settings['rent_rk']['sources'][$source] ?? demand_integrations_default_source_settings($source), [
            'source' => $source,
        ]);
    }

    return $sources;
}

function demand_integrations_get_source_status(string $source): array
{
    return demand_integrations_list_sources()[$source] ?? [];
}

function demand_integrations_external_access_allowed(): bool
{
    $settings = demand_integrations_get_settings();
    if (empty($settings['rent_rk']['enabled'])) {
        return false;
    }
    foreach ($settings['rent_rk']['sources'] as $sourceSettings) {
        if (!empty($sourceSettings['allowExternalScopes'])) {
            return true;
        }
    }

    return false;
}

function demand_integrations_visible_scope_ids_for_current_user(): array
{
    if (current_user_is_platform_admin()) {
        return array_map(static fn(array $scope): string => (string) $scope['scope_id'], scope_list());
    }
    if (!demand_integrations_external_access_allowed()) {
        return [];
    }
    $demandSettings = demand_settings()['rent_rk'];
    if (empty($demandSettings['enabled']) || empty($demandSettings['externalScopesEnabled'])) {
        return [];
    }
    $scopeId = current_user_data_scope_id();
    if ($scopeId === '' || $scopeId === 'rent_rk' || !demand_scope_feature_enabled($scopeId, 'demand_module_enabled')) {
        return [];
    }

    return [$scopeId];
}

function demand_integrations_scope_filter(string $requestedScope = ''): array
{
    $allowed = demand_integrations_visible_scope_ids_for_current_user();
    if (!$allowed) {
        return [];
    }
    $requestedScope = demand_normalize_scope_id($requestedScope);
    if ($requestedScope !== '' && $requestedScope !== 'all' && in_array($requestedScope, $allowed, true)) {
        return [$requestedScope];
    }

    return $allowed;
}

function demand_integrations_can_user_view_source(string $source): bool
{
    if (current_user_is_platform_admin()) {
        return true;
    }
    $settings = demand_integrations_get_settings();
    return !empty($settings['rent_rk']['sources'][$source]['allowExternalScopes']) && demand_integrations_visible_scope_ids_for_current_user() !== [];
}

function demand_integrations_read_sync_runs(): array
{
    return demand_read_container(DEMAND_SYNC_RUNS_FILE);
}

function demand_integrations_save_sync_runs(array $data): void
{
    demand_write_container(DEMAND_SYNC_RUNS_FILE, $data);
}

function demand_integrations_read_external_metrics(): array
{
    return demand_read_container(DEMAND_EXTERNAL_METRICS_FILE);
}

function demand_integrations_save_external_metrics(array $data): void
{
    demand_write_container(DEMAND_EXTERNAL_METRICS_FILE, $data);
}

function demand_integrations_read_errors(): array
{
    return demand_read_container(DEMAND_INTEGRATION_ERRORS_FILE);
}

function demand_integrations_save_errors(array $data): void
{
    demand_write_container(DEMAND_INTEGRATION_ERRORS_FILE, $data);
}

function demand_integrations_read_performance_snapshots(): array
{
    return demand_read_container(DEMAND_PERFORMANCE_SNAPSHOTS_FILE);
}

function demand_integrations_save_performance_snapshots(array $data): void
{
    demand_write_container(DEMAND_PERFORMANCE_SNAPSHOTS_FILE, $data);
}

function demand_integrations_allowed_run_statuses(): array
{
    return ['queued', 'running', 'success', 'partial_success', 'failed', 'rate_limited', 'cancelled'];
}

function demand_integrations_create_sync_run(string $source, string $scopeId, array $options = []): array
{
    if (!isset(demand_integrations_supported_sources()[$source])) {
        throw new RuntimeException('Unknown demand integration source.');
    }
    $scopeId = demand_normalize_scope_id($scopeId);
    $settings = demand_integrations_get_source_status($source);
    $now = now_iso();
    $run = [
        'id' => 'dsr_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'scope_id' => $scopeId,
        'source' => $source,
        'mode' => (string) ($settings['mode'] ?? 'mock'),
        'status' => 'running',
        'dryRun' => array_key_exists('dryRun', $options) ? !empty($options['dryRun']) : true,
        'startedAt' => $now,
        'finishedAt' => null,
        'itemsRead' => 0,
        'itemsCreated' => 0,
        'itemsUpdated' => 0,
        'itemsSkipped' => 0,
        'errors' => [],
        'createdBy' => demand_integrations_clean_string($options['createdBy'] ?? (current_admin_user() ?: 'system'), 120),
    ];

    $data = demand_integrations_read_sync_runs();
    array_unshift($data['items'], $run);
    $data['items'] = array_slice($data['items'], 0, 3000);
    demand_integrations_save_sync_runs($data);

    return $run;
}

function demand_integrations_finish_sync_run(string $runId, array $result): array
{
    $data = demand_integrations_read_sync_runs();
    $updated = null;
    foreach ($data['items'] as $index => $run) {
        if (!is_array($run) || (string) ($run['id'] ?? '') !== $runId) {
            continue;
        }
        $status = demand_integrations_clean_string((string) ($result['status'] ?? 'success'), 80);
        if (!in_array($status, demand_integrations_allowed_run_statuses(), true)) {
            $status = 'failed';
        }
        $run['status'] = $status;
        $run['finishedAt'] = now_iso();
        foreach (['itemsRead', 'itemsCreated', 'itemsUpdated', 'itemsSkipped'] as $key) {
            $run[$key] = max(0, (int) ($result[$key] ?? $run[$key] ?? 0));
        }
        $run['errors'] = array_values(array_filter(array_map(
            static fn($value): string => demand_integrations_clean_string($value, 500),
            is_array($result['errors'] ?? null) ? $result['errors'] : []
        )));
        $data['items'][$index] = $run;
        $updated = $run;
        break;
    }
    if (!$updated) {
        throw new RuntimeException('Demand integration sync run not found.');
    }
    demand_integrations_save_sync_runs($data);
    demand_integrations_update_source_after_run($updated);

    return $updated;
}

function demand_integrations_update_source_after_run(array $run): void
{
    $settings = demand_integrations_get_settings();
    $source = (string) ($run['source'] ?? '');
    if (!isset($settings['rent_rk']['sources'][$source])) {
        return;
    }
    $status = (string) ($run['status'] ?? 'failed');
    $settings['rent_rk']['sources'][$source]['lastSyncAt'] = (string) ($run['finishedAt'] ?? now_iso());
    if (in_array($status, ['success', 'partial_success'], true)) {
        $settings['rent_rk']['sources'][$source]['lastSuccessAt'] = (string) ($run['finishedAt'] ?? now_iso());
        $settings['rent_rk']['sources'][$source]['lastError'] = null;
        $settings['rent_rk']['sources'][$source]['lastErrorAt'] = null;
    } else {
        $settings['rent_rk']['sources'][$source]['lastErrorAt'] = (string) ($run['finishedAt'] ?? now_iso());
        $settings['rent_rk']['sources'][$source]['lastError'] = implode('; ', (array) ($run['errors'] ?? [])) ?: $status;
    }
    $settings['updatedAt'] = now_iso();
    $settings['updatedBy'] = current_admin_user() ?: 'system';
    write_json_file(DEMAND_INTEGRATIONS_SETTINGS_FILE, $settings);
}

function demand_integrations_record_error(string $source, string $scopeId, string $code, string $message, array $context = [], string $severity = 'warning'): array
{
    if (!isset(demand_integrations_supported_sources()[$source])) {
        $source = 'wordstat';
    }
    if (!in_array($severity, ['info', 'warning', 'error', 'critical'], true)) {
        $severity = 'warning';
    }
    $entry = [
        'id' => 'die_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'scope_id' => demand_normalize_scope_id($scopeId),
        'source' => $source,
        'severity' => $severity,
        'code' => demand_integrations_clean_string($code, 120),
        'message' => demand_integrations_clean_string($message, 1000),
        'context' => analytics_sanitize_meta($context) ?: [],
        'createdAt' => now_iso(),
    ];
    $data = demand_integrations_read_errors();
    array_unshift($data['items'], $entry);
    $data['items'] = array_slice($data['items'], 0, 5000);
    demand_integrations_save_errors($data);

    $settings = demand_integrations_get_settings();
    if (isset($settings['rent_rk']['sources'][$source])) {
        $settings['rent_rk']['sources'][$source]['lastErrorAt'] = $entry['createdAt'];
        $settings['rent_rk']['sources'][$source]['lastError'] = $entry['message'];
        if ($source === 'wordstat') {
            $settings['rent_rk']['sources'][$source]['lastErrorCode'] = $entry['code'];
            $settings['rent_rk']['sources'][$source]['lastErrorAdvice'] = isset($entry['context']['advice'])
                ? demand_integrations_clean_string((string) $entry['context']['advice'], 1000)
                : null;
            $settings['rent_rk']['sources'][$source]['lastErrorTechnical'] = isset($entry['context']['technical'])
                ? demand_integrations_clean_string((string) $entry['context']['technical'], 1000)
                : null;
        }
        $settings['updatedAt'] = now_iso();
        $settings['updatedBy'] = current_admin_user() ?: 'system';
        write_json_file(DEMAND_INTEGRATIONS_SETTINGS_FILE, $settings);
    }

    return $entry;
}

function demand_integrations_mock_metric_for_source(string $source, string $scopeId): array
{
    $now = now_iso();
    $keywords = array_values(array_filter(read_demand_keywords()['items'], static fn($item): bool => is_array($item) && demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')) === $scopeId));
    $drafts = array_values(array_filter(read_landing_page_drafts()['items'], static fn($item): bool => is_array($item) && demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')) === $scopeId));
    $items = [];

    if ($source === 'wordstat') {
        $sample = $keywords ?: [[
            'id' => null,
            'phrase' => 'аренда авто ялта',
            'regionName' => 'Ялта',
            'frequency' => 120,
        ]];
        foreach (array_slice($sample, 0, 10) as $index => $keyword) {
            $items[] = [
                'id' => 'dem_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
                'scope_id' => $scopeId,
                'source' => 'wordstat',
                'entityType' => 'keyword',
                'entityId' => (string) ($keyword['id'] ?? ''),
                'landingPageId' => null,
                'phrase' => (string) ($keyword['phrase'] ?? 'аренда авто ялта'),
                'regionName' => (string) ($keyword['regionName'] ?? 'Ялта'),
                'metrics' => [
                    'frequency30d' => max(10, (int) ($keyword['frequency'] ?? 0) + ($index * 7)),
                    'trend' => null,
                    'seasonality' => [],
                    'regionsDistribution' => [],
                ],
                'rawRef' => null,
                'collectedAt' => $now,
                'createdAt' => $now,
            ];
        }

        return $items;
    }

    $sampleDrafts = $drafts ?: [[
        'id' => '',
        'slug' => 'mock-landing-page',
        'sourceKeywordIds' => [],
    ]];
    foreach (array_slice($sampleDrafts, 0, 10) as $index => $draft) {
        $landingPageId = (string) ($draft['id'] ?? '');
        $base = [
            'id' => 'dem_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
            'scope_id' => $scopeId,
            'source' => $source,
            'entityType' => 'landing_page',
            'entityId' => $landingPageId,
            'landingPageId' => $landingPageId !== '' ? $landingPageId : null,
            'phrase' => '',
            'regionName' => '',
            'rawRef' => null,
            'collectedAt' => $now,
            'createdAt' => $now,
        ];
        if ($source === 'yandex_webmaster') {
            $base['metrics'] = [
                'impressions' => 25 + ($index * 5),
                'clicks' => 2 + $index,
                'ctr' => 8.0,
                'avgPosition' => 18.5,
                'indexedStatus' => 'mock_not_checked',
                'excludedReason' => null,
            ];
        } elseif ($source === 'yandex_metrica') {
            $base['metrics'] = [
                'visits' => 12 + ($index * 3),
                'users' => 10 + ($index * 2),
                'bounceRate' => null,
                'avgTimeOnPage' => null,
                'goals' => [],
                'requests' => 1,
                'phoneClicks' => 1,
                'messengerClicks' => 1,
            ];
        } else {
            $base['metrics'] = [
                'chatgptVisits' => 1 + $index,
                'perplexityVisits' => 1,
                'copilotVisits' => 0,
                'otherAiVisits' => 0,
                'requests' => 0,
                'phoneClicks' => 0,
                'messengerClicks' => 0,
            ];
        }
        $items[] = $base;
    }

    return $items;
}

function demand_integrations_import_mock_metrics(string $source, string $scopeId): array
{
    require_permission('demand.integrations.sync');
    if (!isset(demand_integrations_supported_sources()[$source])) {
        throw new RuntimeException('Unknown demand integration source.');
    }
    $scopeId = demand_normalize_scope_id($scopeId);
    if (!current_user_is_platform_admin() && !demand_integrations_can_user_view_source($source)) {
        deny_scope_access();
    }
    $run = demand_integrations_create_sync_run($source, $scopeId, [
        'dryRun' => $source !== 'ai_referrals',
    ]);
    $metrics = demand_integrations_mock_metric_for_source($source, $scopeId);
    $data = demand_integrations_read_external_metrics();
    foreach ($metrics as $metric) {
        array_unshift($data['items'], $metric);
    }
    $data['items'] = array_slice($data['items'], 0, 10000);
    demand_integrations_save_external_metrics($data);
    $finished = demand_integrations_finish_sync_run((string) $run['id'], [
        'status' => 'success',
        'itemsRead' => count($metrics),
        'itemsCreated' => count($metrics),
        'itemsUpdated' => 0,
        'itemsSkipped' => 0,
        'errors' => [],
    ]);
    if ($source !== 'ai_referrals') {
        demand_integrations_record_error($source, $scopeId, 'mock_only', 'Источник работает в mock/dry-run режиме; реальные API-запросы отключены на этапе 3.1.', [
            'runId' => (string) $run['id'],
        ], 'info');
    }

    return [
        'run' => $finished,
        'metrics' => $metrics,
    ];
}

function demand_integrations_detect_ai_referrer(string $referrer, string $utmSource = ''): array
{
    $referrer = strtolower(trim($referrer));
    $utmSource = strtolower(trim($utmSource));
    $haystack = $referrer . ' ' . $utmSource;
    $source = '';
    if (str_contains($haystack, 'chatgpt.com') || str_contains($utmSource, 'chatgpt')) {
        $source = 'chatgpt';
    } elseif (str_contains($haystack, 'perplexity.ai') || str_contains($utmSource, 'perplexity')) {
        $source = 'perplexity';
    } elseif (str_contains($haystack, 'copilot.microsoft.com') || str_contains($utmSource, 'copilot') || str_contains($utmSource, 'bing') || str_contains($referrer, 'bing.com')) {
        $source = 'copilot';
    } elseif (preg_match('/you\.com|claude\.ai|gemini\.google\.com|poe\.com|phind\.com|arc\.net/i', $haystack)) {
        $source = 'other_ai';
    }

    return [
        'isAi' => $source !== '',
        'source' => $source,
        'label' => $source !== '' ? str_replace('_', ' ', $source) : '',
        'matchedBy' => $source !== '' ? ($utmSource !== '' ? 'utm_or_referrer' : 'referrer') : '',
    ];
}

function demand_integrations_metric_number(array $metric, string $key): int
{
    $metrics = is_array($metric['metrics'] ?? null) ? $metric['metrics'] : [];
    return max(0, (int) ($metrics[$key] ?? 0));
}

function demand_integrations_build_performance_snapshot(string $scopeId, string $periodFrom, string $periodTo): array
{
    $scopeId = demand_normalize_scope_id($scopeId);
    if (!current_user_is_platform_admin() && !in_array($scopeId, demand_integrations_visible_scope_ids_for_current_user(), true)) {
        deny_scope_access();
    }
    $periodFrom = preg_match('/^\d{4}-\d{2}-\d{2}$/', $periodFrom) ? $periodFrom : date('Y-m-01');
    $periodTo = preg_match('/^\d{4}-\d{2}-\d{2}$/', $periodTo) ? $periodTo : date('Y-m-t');
    $metrics = array_values(array_filter(demand_integrations_read_external_metrics()['items'], static fn($item): bool => is_array($item) && demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')) === $scopeId));
    $drafts = array_values(array_filter(read_landing_page_drafts()['items'], static fn($item): bool => is_array($item) && demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')) === $scopeId));
    $events = function_exists('read_analytics_events') ? read_analytics_events()['items'] : [];
    $requestData = function_exists('read_requests') ? read_requests() : ['items' => []];
    $requests = isset($requestData['items']) && is_array($requestData['items']) ? $requestData['items'] : [];
    $snapshots = [];

    if (!$drafts) {
        $drafts = [[
            'id' => '',
            'slug' => 'no-landing-pages',
            'sourceKeywordIds' => [],
            'publishStatus' => 'no_data',
        ]];
    }

    foreach ($drafts as $draft) {
        $landingPageId = (string) ($draft['id'] ?? '');
        $keywordIds = is_array($draft['sourceKeywordIds'] ?? null) ? array_values($draft['sourceKeywordIds']) : [];
        $summary = [
            'wordstatFrequency' => 0,
            'searchImpressions' => 0,
            'searchClicks' => 0,
            'visits' => 0,
            'requests' => 0,
            'phoneClicks' => 0,
            'messengerClicks' => 0,
            'aiReferralVisits' => 0,
        ];
        foreach ($metrics as $metric) {
            $source = (string) ($metric['source'] ?? '');
            $entityId = (string) ($metric['entityId'] ?? '');
            $metricLandingId = (string) ($metric['landingPageId'] ?? '');
            $matchesLanding = $landingPageId !== '' && ($entityId === $landingPageId || $metricLandingId === $landingPageId);
            $matchesKeyword = $source === 'wordstat' && $entityId !== '' && in_array($entityId, $keywordIds, true);
            if (!$matchesLanding && !$matchesKeyword && $landingPageId !== '') {
                continue;
            }
            if ($source === 'wordstat') {
                $summary['wordstatFrequency'] += demand_integrations_metric_number($metric, 'frequency30d');
            } elseif ($source === 'yandex_webmaster') {
                $summary['searchImpressions'] += demand_integrations_metric_number($metric, 'impressions');
                $summary['searchClicks'] += demand_integrations_metric_number($metric, 'clicks');
            } elseif ($source === 'yandex_metrica') {
                $summary['visits'] += demand_integrations_metric_number($metric, 'visits');
                $summary['requests'] += demand_integrations_metric_number($metric, 'requests');
                $summary['phoneClicks'] += demand_integrations_metric_number($metric, 'phoneClicks');
                $summary['messengerClicks'] += demand_integrations_metric_number($metric, 'messengerClicks');
            } elseif ($source === 'ai_referrals') {
                $summary['aiReferralVisits'] += demand_integrations_metric_number($metric, 'chatgptVisits')
                    + demand_integrations_metric_number($metric, 'perplexityVisits')
                    + demand_integrations_metric_number($metric, 'copilotVisits')
                    + demand_integrations_metric_number($metric, 'otherAiVisits');
                $summary['requests'] += demand_integrations_metric_number($metric, 'requests');
                $summary['phoneClicks'] += demand_integrations_metric_number($metric, 'phoneClicks');
                $summary['messengerClicks'] += demand_integrations_metric_number($metric, 'messengerClicks');
            }
        }

        foreach ($events as $event) {
            if (!is_array($event) || (string) ($event['scopeId'] ?? 'rent_rk') !== $scopeId) {
                continue;
            }
            $created = substr((string) ($event['createdAt'] ?? ''), 0, 10);
            if ($created !== '' && ($created < $periodFrom || $created > $periodTo)) {
                continue;
            }
            if ($landingPageId !== '') {
                $eventEntityId = (string) ($event['entityId'] ?? '');
                $eventUrl = (string) ($event['pageUrl'] ?? '');
                $slug = (string) ($draft['slug'] ?? '');
                if ($eventEntityId !== '' && $eventEntityId !== $landingPageId) {
                    continue;
                }
                if ($eventEntityId === '' && $slug !== '' && !str_contains($eventUrl, $slug)) {
                    continue;
                }
            }
            $type = (string) ($event['eventType'] ?? '');
            if (in_array($type, ['landing_page_public_view', 'page_view'], true)) {
                $summary['visits']++;
            } elseif (in_array($type, ['landing_page_request_submitted', 'ai_referral_request_submitted'], true)) {
                $summary['requests']++;
            } elseif (in_array($type, ['landing_page_phone_click', 'ai_referral_phone_click'], true)) {
                $summary['phoneClicks']++;
            } elseif (in_array($type, ['landing_page_messenger_click', 'ai_referral_messenger_click'], true)) {
                $summary['messengerClicks']++;
            } elseif (str_starts_with($type, 'ai_referral_')) {
                $summary['aiReferralVisits']++;
            }
        }

        foreach ($requests as $request) {
            if (!is_array($request)) {
                continue;
            }
            if ($landingPageId !== '' && (string) ($request['sourceLandingPageId'] ?? '') !== $landingPageId) {
                continue;
            }
            $created = substr((string) ($request['createdAt'] ?? ''), 0, 10);
            if ($created !== '' && ($created < $periodFrom || $created > $periodTo)) {
                continue;
            }
            $summary['requests']++;
            if ((string) ($request['aiReferralSource'] ?? '') !== '') {
                $summary['aiReferralVisits']++;
            }
        }

        $snapshots[] = [
            'id' => 'dps_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
            'scope_id' => $scopeId,
            'periodFrom' => $periodFrom,
            'periodTo' => $periodTo,
            'landingPageId' => $landingPageId !== '' ? $landingPageId : null,
            'slug' => (string) ($draft['slug'] ?? ''),
            'keywordIds' => $keywordIds,
            'summary' => $summary,
            'status' => array_sum($summary) > 0 ? 'has_data' : 'no_data',
            'createdAt' => now_iso(),
        ];
    }

    $data = demand_integrations_read_performance_snapshots();
    foreach (array_reverse($snapshots) as $snapshot) {
        array_unshift($data['items'], $snapshot);
    }
    $data['items'] = array_slice($data['items'], 0, 5000);
    demand_integrations_save_performance_snapshots($data);

    return $snapshots;
}

function demand_integrations_visible_sync_runs(string $scopeFilter = ''): array
{
    $scopes = demand_integrations_scope_filter($scopeFilter);
    if (!$scopes) {
        return [];
    }
    return array_values(array_filter(demand_integrations_read_sync_runs()['items'], static fn($item): bool => is_array($item) && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopes, true)));
}

function demand_integrations_visible_metrics(string $scopeFilter = ''): array
{
    $scopes = demand_integrations_scope_filter($scopeFilter);
    if (!$scopes) {
        return [];
    }
    return array_values(array_filter(demand_integrations_read_external_metrics()['items'], static fn($item): bool => is_array($item) && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopes, true)));
}

function demand_integrations_visible_errors(string $scopeFilter = ''): array
{
    if (!has_permission('demand.integrations.logs.view')) {
        return [];
    }
    $scopes = demand_integrations_scope_filter($scopeFilter);
    if (!$scopes) {
        return [];
    }
    return array_values(array_filter(demand_integrations_read_errors()['items'], static fn($item): bool => is_array($item) && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopes, true)));
}

function demand_integrations_visible_performance_snapshots(string $scopeFilter = ''): array
{
    $scopes = demand_integrations_scope_filter($scopeFilter);
    if (!$scopes) {
        return [];
    }
    return array_values(array_filter(demand_integrations_read_performance_snapshots()['items'], static fn($item): bool => is_array($item) && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopes, true)));
}
