<?php
declare(strict_types=1);

/** Internal apply contract; does not authorize any HTTP or scheduled entrypoint. */
final class ApprovedPhpPlanApply
{
    public const GENERATOR = 'approved-php-plan-apply-v1';

    public static function assertGlobalAccess(): void
    {
        if (!current_user_is_platform_admin() || current_user_is_scoped_data_user()
            || current_admin_user() === '' || !has_permission('cars.publish') || !has_permission('settings.manage')) {
            throw new RuntimeException('BLOCKED_PHP_APPLY_ACCESS', 403);
        }
    }

    private static function digest(array $value): string
    {
        return hash('sha256', RentRkPublicRenderer::canonical($value));
    }

    public static function binding(array $plan): string
    {
        // The aggregate envelope is freshly signed on each render. Its clock is not an output dependency.
        unset($plan['snapshotSha256'], $plan['approval']['issuedAt'], $plan['approval']['expiresAt']);
        return self::digest($plan);
    }

    private static function signingBytes(array $payload): string
    {
        return "RentRK approved PHP apply ticket v1\0" . RentRkPublicRenderer::canonical($payload);
    }

    public static function issue(array $plan, int $expiry, array $state, array $actor, string $slug, string $mode, array $context): array
    {
        $payload = ['id' => 'php-plan-' . bin2hex(random_bytes(16)), 'issuer' => $context['issuer'], 'keyId' => $context['keyId'],
            'expiresAt' => $expiry, 'actor' => $actor, 'slug' => $slug, 'mode' => $mode,
            'planDigest' => self::digest($plan), 'buildStateSha256' => self::digest($state)];
        $key = base64_decode($context['secretKeyBase64'], true);
        try { $signature = sodium_crypto_sign_detached(self::signingBytes($payload), $key); }
        finally { sodium_memzero($key); }
        return ['payload' => $payload, 'signature' => base64_encode($signature)];
    }

    public static function verify(array $plan, array $ticket, array $actor, string $slug, string $mode, array $context): array
    {
        $p = $ticket['payload'] ?? null;
        $sig = is_string($ticket['signature'] ?? null) ? base64_decode($ticket['signature'], true) : false;
        if (count($ticket) !== 2 || !is_array($p) || count($p) !== 9 || !is_string($sig) || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES
            || ($p['issuer'] ?? null) !== $context['issuer'] || ($p['keyId'] ?? null) !== $context['keyId']
            || !sodium_crypto_sign_verify_detached($sig, self::signingBytes($p), base64_decode($context['publicKeyBase64'], true))
            || !is_string($p['id'] ?? null) || !preg_match('/\Aphp-plan-[a-f0-9]{32}\z/D', $p['id'])
            || !is_int($p['expiresAt'] ?? null) || $p['expiresAt'] <= time()
            || ($p['actor'] ?? null) !== $actor || ($p['slug'] ?? null) !== $slug || ($p['mode'] ?? null) !== $mode
            || ($p['planDigest'] ?? null) !== self::digest($plan) || !is_string($p['buildStateSha256'] ?? null)) {
            throw new RuntimeException('BLOCKED_PHP_APPLY_TICKET_INVALID', 409);
        }
        return $p;
    }

    public static function state(): array
    {
        if (is_link(BUILD_STATE_FILE) || (file_exists(BUILD_STATE_FILE) && !is_file(BUILD_STATE_FILE))) {
            throw new RuntimeException('BLOCKED_PHP_APPLY_BUILD_STATE_INVALID', 409);
        }
        $state = RentalReturnStore::read(BUILD_STATE_FILE, default_build_state());
        if (!is_array($state['outputs'] ?? null) || !is_array($state['runs'] ?? null) || !array_is_list($state['runs'])
            || !is_array($state['conflicts'] ?? null)) {
            throw new RuntimeException('BLOCKED_PHP_APPLY_BUILD_STATE_INVALID', 409);
        }
        return $state;
    }

    public static function entity(string $path): array
    {
        return match ($path) {
            'index.html' => ['home', 'index'],
            'cars/index.html' => ['catalog', 'cars'],
            'sitemap.xml' => ['sitemap', 'root'],
            'robots.txt' => ['robots', 'root'],
            default => preg_match('~\A(cars|pages|routes)/([a-z0-9-]+)\.html\z~D', $path, $m)
                ? [(['cars' => 'car', 'pages' => 'page', 'routes' => 'route'])[$m[1]], $m[2]]
                : throw new RuntimeException('BLOCKED_PHP_APPLY_TARGET', 409),
        };
    }

    private static function matchesOwner(array $row, string $path, string $hash): bool
    {
        [$type, $id] = self::entity($path);
        return ($row['outputPath'] ?? null) === $path && ($row['outputHash'] ?? null) === 'sha256:' . $hash
            && ($row['entityType'] ?? null) === $type && ($row['entityId'] ?? null) === $id;
    }

    public static function ownsGenerated(string $path, string $hash): bool
    {
        $row = self::state()['outputs'][$path] ?? null;
        return is_array($row) && ($row['generator'] ?? null) === self::GENERATOR && self::matchesOwner($row, $path, $hash);
    }

    public static function checkOutputs(array $plan, array $state, string $slug, string $mode): array
    {
        if (!in_array($mode, ['Car', 'Full'], true) || ($plan['mode'] ?? null) !== $mode
            || ($plan['status'] ?? '') !== 'PLAN_ONLY' || ($plan['canApply'] ?? null) !== false
            || ($plan['deletePaths'] ?? null) !== [] || ($plan['publicDataPaths'] ?? null) !== []
            || !is_array($plan['outputs'] ?? null) || !array_is_list($plan['outputs'])) {
            throw new RuntimeException('BLOCKED_PHP_APPLY_PLAN', 409);
        }
        $outputs = [];
        foreach ($plan['outputs'] as $row) {
            $path = $row['path'];
            [$type, $entity] = self::entity($path);
            if (isset($outputs[$path]) || ($mode === 'Car' && $type === 'car' && $entity !== $slug)) {
                throw new RuntimeException('BLOCKED_PHP_APPLY_TARGET', 409);
            }
            $bytes = base64_decode($row['payloadBase64'], true);
            if ($bytes === false || $bytes === '' || strlen($bytes) > 10 * 1024 * 1024 || hash('sha256', $bytes) !== $row['sha256']) {
                throw new RuntimeException('BLOCKED_PHP_APPLY_PAYLOAD', 409);
            }
            $before = RentalReturnStore::publicationOutputBytes($path);
            $hash = $before === null ? null : hash('sha256', $before);
            if ($hash !== $row['beforeSha256']) throw new RuntimeException('BLOCKED_PHP_APPLY_STALE_TARGET', 409);
            foreach ($state['conflicts'] as $conflict) {
                if (($conflict['outputPath'] ?? null) === $path) throw new RuntimeException('BLOCKED_PHP_APPLY_OUTPUT_CONFLICT', 409);
            }
            $owner = $state['outputs'][$path] ?? null;
            // The sitemap is shared; its authority is the separate signed continuity chain.
            if ($path !== 'sitemap.xml' && ($hash === null ? $owner !== null
                : !is_array($owner) || (!(in_array($owner['generator'] ?? null, PhpPublicationCutover::selected() ? [self::GENERATOR] : [self::GENERATOR, 'tools/build-site.ps1'], true)
                    && self::matchesOwner($owner, $path, $hash)) && !PhpPublicationAutomation::transferredOwner($path, $owner, $hash)))) {
                throw new RuntimeException('BLOCKED_PHP_APPLY_UNKNOWN_OWNERSHIP', 409);
            }
            $outputs[$path] = ['before' => $before, 'beforeHash' => $hash, 'bytes' => $bytes, 'sha256' => $row['sha256'],
                'entityType' => $type, 'entityId' => $entity];
        }
        foreach (['index.html', 'cars/index.html', 'sitemap.xml', 'cars/' . $slug . '.html'] as $path) {
            if (!isset($outputs[$path])) throw new RuntimeException('BLOCKED_PHP_APPLY_TARGET_SET', 409);
        }
        return $outputs;
    }

    public static function stage(array $ticket, array $state, array $outputs, array $store, array $origin, array $context, array $urls,
        string $action = 'apply', ?string $targetCarUrl = null): array
    {
        if (!RentalReturnStore::active()) throw new LogicException('BLOCKED_PHP_APPLY_REQUIRES_OWN_TRANSACTION');
        $id = $ticket['id'];
        $changed = [];
        foreach ($outputs as $path => $row) {
            if (RentalReturnStore::publicationOutputBytes($path) !== $row['before']) {
                throw new RuntimeException('BLOCKED_PHP_APPLY_STALE_TARGET', 409);
            }
            $backup = null;
            if ($row['before'] !== null) {
                $backup = 'backups/generated-output-backups/' . $id . '/' . $path;
                if (RentalReturnStore::publicationOutputBytes('@data/' . $backup) !== null) {
                    throw new RuntimeException('BLOCKED_PHP_APPLY_BACKUP_COLLISION', 409);
                }
                RentalReturnStore::stagePublicationOutput('@data/' . $backup, $row['before']);
            }
            RentalReturnStore::stagePublicationOutput($path, $row['bytes'], $row['beforeHash']);
            if ($row['before'] !== $row['bytes']) $changed[] = $path;
            $state['outputs'][$path] = ['outputPath' => $path, 'entityType' => $row['entityType'], 'entityId' => $row['entityId'],
                'sourcePath' => 'approved-public-car-snapshots.json', 'sourceHash' => 'sha256:' . $ticket['planDigest'],
                'outputHash' => 'sha256:' . $row['sha256'], 'generator' => self::GENERATOR, 'generatedAt' => now_iso(), 'backupPath' => $backup];
        }
        $site = $outputs['sitemap.xml'];
        ApprovedSitemapContinuity::record($store, $origin, $context, $site['before'], $site['bytes'],
            ['writer' => 'php_plan', 'action' => $action, 'reference' => $ticket['planDigest'], 'targets' => $urls,
                'targetCarUrl' => $targetCarUrl]);
        $run = ['id' => $id, 'mode' => $ticket['mode'], 'status' => 'completed', 'generator' => self::GENERATOR,
            'planDigest' => $ticket['planDigest'], 'outputs' => array_keys($outputs), 'changedFiles' => $changed,
            'deleteCount' => 0, 'publicDataWritten' => false];
        array_unshift($state['runs'], $run);
        $state['lastRun'] = $run;
        $state['updatedAt'] = now_iso();
        if (!RentalReturnStore::stage(BUILD_STATE_FILE, $state)) throw new LogicException('BLOCKED_PHP_APPLY_BUILD_STATE_NOT_STAGED');
        audit_log('site.php_plan.apply', 'site', $id, 'Approved PHP plan applied',
            ['planDigest' => $ticket['planDigest'], 'mode' => $ticket['mode'], 'outputs' => array_keys($outputs), 'changedFiles' => $changed]
            + (isset($ticket['actor']['job']) ? ['authorizedAction' => $ticket['actor']] : []));
        return ['status' => 'APPLIED', 'id' => $id, 'wrote' => true, 'changedFiles' => $changed];
    }
}
