<?php
declare(strict_types=1);

/** Read-only inventory of existing canonical endpoints, not a publisher. */
final class ApprovedPublicDynamicInventory
{
    private static function digest(mixed $value): string
    {
        return hash('sha256', RentRkPublicRenderer::canonical($value));
    }

    public static function signingBytes(array $payload): string
    {
        return "RentRK approved dynamic sitemap inventory v1\0" . RentRkPublicRenderer::canonical($payload);
    }

    public static function projection(): array
    {
        $entries = []; $partners = []; $landings = []; $scopes = [];
        foreach (scope_control_items() as $scope) {
            $id = $scope['scope_id'];
            if (isset($scopes[$id])) throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_SCOPE_AMBIGUOUS', 409);
            $scopes[$id] = $scope['owner_type'];
        }
        foreach (self::items(PARTNERS_FILE) as $row) {
            $partner = normalize_partner_item($row);
            $slug = $partner['slug'];
            if ($slug === '' || $partner['name'] === '') {
                if (!empty($row['active'])) throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_PARTNER_INVALID', 409);
                continue;
            }
            if (isset($partners[$slug])) throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_DUPLICATE', 409);
            $partners[$slug] = true;
            if (!$partner['active']) continue;
            $ownerType = $row['partner_owner_type'] ?? $row['partnerOwnerType'] ?? 'rent_rk';
            $ownerScope = $row['partner_owner_scope_id'] ?? $row['partnerOwnerScopeId'] ?? '';
            $scopeId = $partner['partner_owner_scope_id'];
            if (($row['partnerOwnerType'] ?? $ownerType) !== $ownerType || ($row['partnerOwnerScopeId'] ?? $ownerScope) !== $ownerScope
                || $ownerType !== $partner['partner_owner_type'] || ($scopes[$scopeId] ?? null) !== $ownerType
                || ($ownerType === 'lessor' ? $ownerScope !== $scopeId : !in_array($ownerScope, ['', 'rent_rk'], true))) {
                throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_SCOPE_INVALID', 409);
            }
            // Agent routes are noindex; only the canonical partner root belongs here.
            $entries[] = ['kind' => 'partner', 'id' => $slug, 'scopeId' => $scopeId,
                'url' => 'https://base-rent.ru/partner/' . $slug . '/', 'sourceSha256' => self::digest($row)];
        }
        $demandIds = [];
        foreach (self::items(LANDING_PAGE_DRAFTS_FILE) as $row) {
            $indexed = ($row['publishStatus'] ?? '') === 'published_indexed';
            $id = $row['id'] ?? null;
            if (is_string($id) && $id !== '') {
                if (isset($demandIds[$id])) throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_DUPLICATE', 409);
                $demandIds[$id] = true;
            }
            $slug = $row['slug'] ?? '';
            if (!is_string($slug) || $slug === '') {
                if ($indexed) throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_DEMAND_INVALID', 409);
                continue;
            }
            $canonical = demand_transliterate($slug);
            if ($canonical !== '') {
                if (isset($landings[$canonical])) throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_DUPLICATE', 409);
                $landings[$canonical] = true;
            }
            if (!$indexed) continue;
            $scopeId = $row['scope_id'] ?? null;
            if (!is_string($scopeId) || !isset($scopes[$scopeId])) throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_SCOPE_INVALID', 409);
            if ($slug !== $canonical || !preg_match('/\A[a-z0-9]+(?:-[a-z0-9]+)*\z/D', $slug)
                || !is_string($id) || $id === '' || ($row['indexStatus'] ?? null) !== 'in_sitemap') {
                throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_DEMAND_INVALID', 409);
            }
            $entries[] = ['kind' => 'demand', 'id' => $id, 'scopeId' => $scopeId,
                'url' => demand_public_landing_url($row), 'sourceSha256' => self::digest($row)];
        }
        usort($entries, static fn(array $a, array $b): int => strcmp($a['url'], $b['url']));
        return $entries;
    }

    private static function items(string $path): array
    {
        $items = RentalReturnStore::read($path, [])['items'] ?? null;
        if (!is_array($items) || !array_is_list($items)) throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_SOURCE_INVALID', 409);
        foreach ($items as $row) if (!is_array($row)) throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_SOURCE_INVALID', 409);
        return $items;
    }

    public static function sources(array $inventory): array
    {
        $hashes = array_intersect_key($inventory['dependencies'], array_flip(['routes', 'partners', 'representatives', 'demand']));
        foreach (['scopes' => LESSORS_FILE, 'partnerEndpoint' => PROJECT_ROOT . 'partner/index.php',
            'demandEndpoint' => PROJECT_ROOT . 'landing.php', 'demandRules' => __DIR__ . '/demand.php',
            'partnerRules' => __DIR__ . '/bootstrap.php', 'projector' => __FILE__] as $key => $path) {
            if (!is_file($path) || is_link($path) || !is_string($hash = hash_file('sha256', $path))) {
                throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_SOURCE_INVALID', 409);
            }
            $hashes[$key] = $hash;
        }
        return $hashes;
    }

    public static function verify(array $inventory, string $issuer, string $keyId, string $publicKey): ?array
    {
        $entries = self::projection();
        if (!array_key_exists('dynamicEnvelope', $inventory) && $entries === []) return null;
        $envelope = $inventory['dynamicEnvelope'] ?? null;
        $payload = $envelope['payload'] ?? null;
        $signature = is_string($envelope['signature'] ?? null) ? base64_decode($envelope['signature'], true) : false;
        if (!is_array($envelope) || count($envelope) !== 2 || !is_array($payload) || !is_string($signature)
            || strlen($signature) !== SODIUM_CRYPTO_SIGN_BYTES
            || !sodium_crypto_sign_verify_detached($signature, self::signingBytes($payload), $publicKey)) {
            throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_SIGNATURE', 409);
        }
        $issuedAt = $payload['issuedAt'] ?? null; $expiresAt = $payload['expiresAt'] ?? null;
        if (!is_int($issuedAt) || !is_int($expiresAt) || $issuedAt <= 0 || $issuedAt > time() || $expiresAt <= time()) {
            throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_EXPIRED_OR_FUTURE', 409);
        }
        $expected = ['schemaVersion' => 1, 'audience' => 'rent-rk-global-sitemap', 'issuer' => $issuer, 'keyId' => $keyId,
            'decisionId' => $inventory['decisionId'], 'siteDigest' => $inventory['siteDigest'], 'issuedAt' => $issuedAt, 'expiresAt' => $expiresAt,
            'sources' => self::sources($inventory), 'entries' => $entries];
        if (!hash_equals(self::digest($expected), self::digest($payload))) throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_MISMATCH', 409);
        return ['urls' => array_column($entries, 'url'), 'sha256' => self::digest($payload), 'expiresAt' => $expiresAt];
    }
}
