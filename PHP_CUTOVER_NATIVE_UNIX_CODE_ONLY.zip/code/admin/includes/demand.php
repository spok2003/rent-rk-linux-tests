<?php

declare(strict_types=1);

function demand_default_container(): array
{
    return [
        'updatedAt' => null,
        'items' => [],
    ];
}

function demand_read_container(string $path): array
{
    $data = is_file($path) ? read_json_file($path, demand_default_container()) : demand_default_container();
    $data['items'] = isset($data['items']) && is_array($data['items']) ? $data['items'] : [];

    return $data;
}

function demand_write_container(string $path, array $data): void
{
    $data['items'] = isset($data['items']) && is_array($data['items']) ? array_values($data['items']) : [];
    $data['updatedAt'] = now_iso();
    write_json_file($path, $data);
}

function demand_editorial_action_paths(string $action): array
{
    $draftInputs = [LANDING_PAGE_DRAFTS_FILE, DEMAND_KEYWORDS_FILE, CARS_FILE, RATES_FILE];
    $mapInputs = [DEMAND_KEYWORDS_FILE, LANDING_PAGE_DRAFTS_FILE, CARS_FILE, RATES_FILE, DEMAND_EXTERNAL_METRICS_FILE];

    return match ($action) {
        'apply_import' => [DEMAND_KEYWORDS_FILE, DEMAND_RECOMMENDATIONS_FILE],
        'recalculate_keyword' => [DEMAND_KEYWORDS_FILE, DEMAND_RECOMMENDATIONS_FILE, CARS_FILE, RATES_FILE, DEMAND_SETTINGS_FILE],
        'keyword_status' => [DEMAND_KEYWORDS_FILE],
        'create_draft' => [DEMAND_RECOMMENDATIONS_FILE, DEMAND_KEYWORDS_FILE, LANDING_PAGE_DRAFTS_FILE, CARS_FILE, RATES_FILE, DEMAND_SETTINGS_FILE],
        'recommendation_status' => [DEMAND_RECOMMENDATIONS_FILE],
        'save_draft', 'preview_text_save', 'draft_internal_links_apply',
        'draft_editorial_add_block', 'draft_editorial_add_faq', 'draft_status',
        'refresh_draft_cars', 'wizard_check_readiness', 'wizard_save_admin_note' => $draftInputs,
        'demand_map_recalculate' => array_values(array_unique(array_merge(
            $mapInputs,
            [DEMAND_CLUSTERS_FILE, SEO_LAUNCH_PLAN_FILE, DEMAND_RECOMMENDATIONS_FILE]
        ))),
        'demand_map_create_brief' => [SEO_LAUNCH_PLAN_FILE, DEMAND_CLUSTERS_FILE, DEMAND_KEYWORDS_FILE, DEMAND_CONTENT_BRIEFS_FILE],
        'demand_map_create_card_hints' => [SEO_LAUNCH_PLAN_FILE, DEMAND_CLUSTERS_FILE, CARS_FILE, DEMAND_CARD_OPTIMIZATION_HINTS_FILE],
        'demand_map_create_draft' => [SEO_LAUNCH_PLAN_FILE, DEMAND_CLUSTERS_FILE, DEMAND_KEYWORDS_FILE, LANDING_PAGE_DRAFTS_FILE, CARS_FILE, RATES_FILE],
        'demand_map_plan_status' => [SEO_LAUNCH_PLAN_FILE],
        default => [],
    };
}

function demand_editorial_primary_store(string $action): string
{
    return match ($action) {
        'apply_import', 'recalculate_keyword', 'keyword_status' => DEMAND_KEYWORDS_FILE,
        'create_draft', 'recommendation_status' => DEMAND_RECOMMENDATIONS_FILE,
        'save_draft', 'preview_text_save', 'draft_internal_links_apply',
        'draft_editorial_add_block', 'draft_editorial_add_faq', 'draft_status',
        'refresh_draft_cars', 'wizard_check_readiness', 'wizard_save_admin_note',
        'demand_map_create_draft' => LANDING_PAGE_DRAFTS_FILE,
        'demand_map_recalculate', 'demand_map_plan_status' => SEO_LAUNCH_PLAN_FILE,
        'demand_map_create_brief' => DEMAND_CONTENT_BRIEFS_FILE,
        'demand_map_create_card_hints' => DEMAND_CARD_OPTIMIZATION_HINTS_FILE,
        default => '',
    };
}

function demand_editorial_session_actions(): array
{
    return [
        'preview_import',
        'draft_internal_links_suggest',
        'draft_internal_links_reject',
        'demand_direction_neighbor_decision',
    ];
}

function demand_editorial_authorize(string $action, array $payload, string $scopeFilter): void
{
    if (in_array($action, ['preview_import', 'apply_import'], true)) {
        require_permission('demand.import');
        return;
    }
    if (in_array($action, ['recalculate_keyword', 'keyword_status'], true)) {
        $keyword = demand_find_keyword((string) ($payload['keyword_id'] ?? ''));
        if (!$keyword) throw new RuntimeException('Ключевой запрос не найден.');
        if ($action === 'keyword_status') require_permission('demand.manage');
        else demand_scope_guard($keyword, 'demand.recommendations.view');
        return;
    }
    if (in_array($action, ['create_draft', 'recommendation_status'], true)) {
        $recommendation = demand_find_recommendation((string) ($payload['recommendation_id'] ?? ''));
        if (!$recommendation) throw new RuntimeException('Рекомендация не найдена.');
        demand_scope_guard($recommendation, $action === 'create_draft' ? 'demand.drafts.create' : 'demand.recommendations.view');
        return;
    }
    if (in_array($action, [
        'save_draft', 'preview_text_save', 'draft_internal_links_suggest', 'draft_internal_links_apply',
        'draft_internal_links_reject', 'draft_editorial_add_block', 'draft_editorial_add_faq',
        'refresh_draft_cars',
    ], true)) {
        $draft = demand_find_draft((string) ($payload['draft_id'] ?? ''));
        if (!$draft) throw new RuntimeException('Черновик не найден.');
        demand_scope_guard($draft, 'demand.drafts.edit');
        return;
    }
    if (in_array($action, ['wizard_check_readiness', 'wizard_save_admin_note'], true)) {
        $draft = demand_find_draft((string) ($payload['draft_id'] ?? ''));
        if (!$draft) throw new RuntimeException('Черновик не найден.');
        demand_scope_guard($draft, 'demand.publish_wizard.manage');
        return;
    }
    if ($action === 'draft_status') {
        require_permission('demand.rollback');
        $draft = demand_find_draft((string) ($payload['draft_id'] ?? ''));
        if (!$draft) throw new RuntimeException('Черновик не найден.');
        demand_scope_guard($draft, 'demand.rollback');
        return;
    }
    if ($action === 'demand_direction_neighbor_decision') {
        require_permission('demand.ai_dialog.use');
        return;
    }
    if ($action === 'demand_map_recalculate') {
        require_permission('demand.map.manage');
        if (!demand_current_scope_filter($scopeFilter)) deny_scope_access();
        return;
    }
    $planPermissions = [
        'demand_map_create_brief' => 'demand.content_briefs.manage',
        'demand_map_create_card_hints' => 'demand.card_hints.manage',
        'demand_map_create_draft' => 'demand.drafts.create',
        'demand_map_plan_status' => 'demand.launch_plan.manage',
    ];
    if (isset($planPermissions[$action])) {
        $plan = demand_map_find_plan((string) ($payload['plan_id'] ?? ''));
        if (!$plan) throw new RuntimeException('Пункт SEO-плана не найден.');
        demand_scope_guard($plan, $planPermissions[$action]);
        return;
    }
    throw new LogicException('Unsupported Demand editorial action.');
}

function demand_editorial_intent(string $action, array $payload, string $scopeFilter): array
{
    foreach (['csrf_token', 'command_id', 'expected_version', 'return_to_preview', 'preview_mode'] as $technical) {
        unset($payload[$technical]);
    }
    return ['action' => $action, 'scopeFilter' => $scopeFilter, 'payload' => $payload];
}

function demand_editorial_execute(string $action, array $payload, string $scopeFilter, callable $work): array
{
    $commandId = business_command_id($payload['command_id'] ?? null);
    $intent = demand_editorial_intent($action, $payload, $scopeFilter);
    $authorize = static function () use ($action, $payload, $scopeFilter): void {
        demand_editorial_authorize($action, $payload, $scopeFilter);
    };

    if (in_array($action, demand_editorial_session_actions(), true)) {
        $authorize();
        $fingerprint = hash('sha256', json_encode(business_command_canonical([
            'actor' => current_admin_user(),
            'intent' => $intent,
        ]), JSON_THROW_ON_ERROR | JSON_PRESERVE_ZERO_FRACTION));
        $key = $action . ':' . $commandId;
        $receipts = is_array($_SESSION['demand_editorial_receipts'] ?? null) ? $_SESSION['demand_editorial_receipts'] : [];
        if (isset($receipts[$key])) {
            $receipt = $receipts[$key];
            if (!is_array($receipt) || !is_string($receipt['fingerprint'] ?? null) || !is_array($receipt['result'] ?? null)) {
                throw new RuntimeException('Повреждён результат сессионной операции.', 503);
            }
            if (!hash_equals($receipt['fingerprint'], $fingerprint)) {
                throw new RuntimeException('Идентификатор уже использован для другой операции. Откройте новую форму.', 409);
            }
            return $receipt['result'];
        }
        $result = $work();
        if (!is_array($result)) $result = [];
        $receipts[$key] = ['fingerprint' => $fingerprint, 'result' => $result, 'completedAt' => now_iso()];
        $_SESSION['demand_editorial_receipts'] = array_slice($receipts, -100, null, true);
        return $result;
    }

    $paths = demand_editorial_action_paths($action);
    $store = demand_editorial_primary_store($action);
    if (!$paths || $store === '') throw new LogicException('Demand editorial command storage is not configured.');
    $receipt = business_command(
        $store,
        'demand-' . $action,
        $commandId,
        $intent,
        $authorize,
        static function () use ($paths, $payload, $work): array {
            business_assert_form_version($paths, $payload['expected_version'] ?? null);
            $value = $work();
            return ['value' => is_array($value) ? $value : []];
        }
    );
    return is_array($receipt['value'] ?? null) ? $receipt['value'] : [];
}

function demand_editorial_command_fields(string $action): string
{
    static $versions = [];
    $commandId = bin2hex(random_bytes(16));
    $html = '<input type="hidden" name="command_id" value="' . e($commandId) . '">';
    $paths = demand_editorial_action_paths($action);
    if ($paths) {
        if (!isset($versions[$action])) $versions[$action] = business_form_version($paths);
        $html .= '<input type="hidden" name="expected_version" value="' . e($versions[$action]) . '">';
    }
    return $html;
}

function demand_publication_actions(): array
{
    return [
        'workflow_submit_review', 'workflow_approve', 'workflow_reject', 'workflow_publish_noindex',
        'workflow_request_index', 'workflow_publish_indexed', 'workflow_return_noindex', 'workflow_close_index',
        'workflow_archive', 'workflow_merge', 'workflow_restore_draft', 'workflow_rollback',
        'wizard_publish_noindex', 'wizard_open_search', 'wizard_close_search',
    ];
}

function demand_publication_action_paths(string $action): array
{
    $base = [LANDING_PAGE_DRAFTS_FILE, SEO_PAGE_LIFECYCLE_FILE];
    $versions = array_merge($base, [LANDING_PAGE_VERSIONS_FILE]);
    $analytics = array_merge($base, [ANALYTICS_EVENTS_FILE]);
    return match ($action) {
        'workflow_submit_review', 'workflow_approve', 'workflow_reject', 'workflow_return_noindex' => $base,
        'workflow_request_index' => $analytics,
        'workflow_publish_noindex', 'workflow_close_index', 'workflow_archive',
        'wizard_publish_noindex', 'wizard_close_search' => array_merge($versions, [ANALYTICS_EVENTS_FILE]),
        'workflow_merge', 'workflow_restore_draft' => $versions,
        'workflow_publish_indexed', 'workflow_rollback', 'wizard_open_search' => array_merge($versions, [ANALYTICS_EVENTS_FILE]),
        default => [],
    };
}

function demand_publication_changes_sitemap(string $action): bool
{
    return in_array($action, [
        'workflow_publish_indexed', 'workflow_close_index', 'workflow_archive', 'workflow_merge',
        'workflow_rollback', 'wizard_open_search', 'wizard_close_search',
    ], true);
}

function demand_publication_authorize(string $action, array $payload): void
{
    if (!in_array($action, demand_publication_actions(), true)) throw new LogicException('Unsupported Demand publication action.');
    $draft = demand_find_draft((string) ($payload['draft_id'] ?? ''));
    if (!$draft) throw new RuntimeException('Черновик не найден.');
    $permission = match ($action) {
        'workflow_submit_review', 'workflow_request_index' => 'demand.drafts.edit',
        'workflow_approve', 'workflow_reject', 'workflow_publish_noindex', 'wizard_publish_noindex' => 'demand.publish.noindex',
        'workflow_publish_indexed', 'workflow_return_noindex', 'workflow_close_index', 'wizard_open_search', 'wizard_close_search' => 'demand.publish.index',
        default => 'demand.rollback',
    };
    require_permission($permission);
    if (demand_publication_changes_sitemap($action)) require_permission('demand.sitemap.manage');
    demand_scope_guard($draft, $permission);
}

function demand_publication_intent(string $action, array $payload, string $scopeFilter): array
{
    foreach (['csrf_token', 'command_id', 'expected_version', 'expected_sitemap_hash', 'tab', 'view'] as $technical) unset($payload[$technical]);
    return ['action' => $action, 'scopeFilter' => $scopeFilter, 'payload' => $payload];
}

function demand_sitemap_version(): string
{
    $bytes = RentalReturnStore::publicationOutputBytes('sitemap.xml');
    return $bytes === null ? 'missing' : hash('sha256', $bytes);
}

function demand_publication_execute(string $action, array $payload, string $scopeFilter, callable $work): array
{
    $paths = demand_publication_action_paths($action);
    if (!$paths) throw new LogicException('Demand publication command storage is not configured.');
    $receipt = business_command(
        LANDING_PAGE_DRAFTS_FILE,
        'demand-' . $action,
        business_command_id($payload['command_id'] ?? null),
        demand_publication_intent($action, $payload, $scopeFilter),
        static fn() => demand_publication_authorize($action, $payload),
        static function () use ($action, $paths, $payload, $work): array {
            business_assert_form_version($paths, $payload['expected_version'] ?? null);
            $beforeSitemap = null;
            $beforeDraft = null;
            if (demand_publication_changes_sitemap($action)) {
                $expected = $payload['expected_sitemap_hash'] ?? null;
                if (!is_string($expected) || !hash_equals(demand_sitemap_version(), $expected)) {
                    throw new RuntimeException('Карта сайта изменилась. Обновите страницу перед сохранением.', 409);
                }
                $beforeSitemap = RentalReturnStore::publicationOutputBytes('sitemap.xml');
                $beforeDraft = demand_find_draft((string) ($payload['draft_id'] ?? ''));
            }
            $value = $work();
            if ($beforeDraft !== null) {
                $afterSitemap = RentalReturnStore::publicationOutputBytes('sitemap.xml');
                if (is_string($afterSitemap) && $afterSitemap !== $beforeSitemap) {
                    require_once __DIR__ . '/approved-public-car-snapshot.php';
                    ApprovedPublicCarSnapshots::recordDemandSitemap($action, business_command_id($payload['command_id'] ?? null),
                        $beforeDraft, demand_find_draft((string) $beforeDraft['id']) ?? [], $beforeSitemap, $afterSitemap);
                }
            }
            return ['value' => is_array($value) ? $value : []];
        }
    );
    return is_array($receipt['value'] ?? null) ? $receipt['value'] : [];
}

function demand_publication_command_fields(string $action): string
{
    $paths = demand_publication_action_paths($action);
    if (!$paths) throw new LogicException('Demand publication command fields are not configured.');
    $html = '<input type="hidden" name="command_id" value="' . e(bin2hex(random_bytes(16))) . '">';
    $html .= '<input type="hidden" name="expected_version" value="' . e(business_form_version($paths)) . '">';
    if (demand_publication_changes_sitemap($action)) {
        $html .= '<input type="hidden" name="expected_sitemap_hash" value="' . e(demand_sitemap_version()) . '">';
    }
    return $html;
}

function demand_default_settings(): array
{
    return [
        'updatedAt' => now_iso(),
        'updatedBy' => 'system',
        'rent_rk' => [
            'enabled' => true,
            'externalScopesEnabled' => false,
            'allowExternalScopeDrafts' => false,
            'allowAutoDraftCreation' => true,
            'allowAutoIndexing' => false,
            'minFrequencyForDraftSuggestion' => 10,
            'requireHumanReviewBeforeIndex' => true,
        ],
    ];
}

function demand_settings(): array
{
    $default = demand_default_settings();
    $data = is_file(DEMAND_SETTINGS_FILE) ? read_json_file(DEMAND_SETTINGS_FILE, $default) : $default;
    $rentRk = isset($data['rent_rk']) && is_array($data['rent_rk']) ? $data['rent_rk'] : [];
    $settings = array_merge($default['rent_rk'], $rentRk);
    foreach (['enabled', 'externalScopesEnabled', 'allowExternalScopeDrafts', 'allowAutoDraftCreation'] as $key) {
        $settings[$key] = !empty($settings[$key]);
    }
    $settings['allowAutoIndexing'] = false;
    $settings['requireHumanReviewBeforeIndex'] = true;
    $settings['minFrequencyForDraftSuggestion'] = max(0, min(1000000, (int) ($settings['minFrequencyForDraftSuggestion'] ?? 10)));

    return [
        'updatedAt' => (string) ($data['updatedAt'] ?? $default['updatedAt']),
        'updatedBy' => (string) ($data['updatedBy'] ?? $default['updatedBy']),
        'rent_rk' => $settings,
    ];
}

function save_demand_settings(array $payload): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn() => save_demand_settings($payload));
    if (!current_user_is_platform_admin()) {
        deny_scope_access();
    }

    business_assert_form_version([DEMAND_SETTINGS_FILE], $payload['expected_version'] ?? null);

    $before = demand_settings();
    $next = $before;
    $next['rent_rk']['enabled'] = isset($payload['enabled']);
    $next['rent_rk']['externalScopesEnabled'] = isset($payload['externalScopesEnabled']);
    $next['rent_rk']['allowExternalScopeDrafts'] = isset($payload['allowExternalScopeDrafts']);
    $next['rent_rk']['allowAutoDraftCreation'] = isset($payload['allowAutoDraftCreation']);
    $next['rent_rk']['allowAutoIndexing'] = false;
    $next['rent_rk']['requireHumanReviewBeforeIndex'] = true;
    $next['rent_rk']['minFrequencyForDraftSuggestion'] = max(0, min(1000000, (int) ($payload['minFrequencyForDraftSuggestion'] ?? 10)));
    $next['updatedAt'] = now_iso();
    $next['updatedBy'] = current_admin_user() ?: 'system';
    $raw = is_file(DEMAND_SETTINGS_FILE) ? read_json_file(DEMAND_SETTINGS_FILE, []) : [];
    $raw = array_replace($raw, array_diff_key($next, ['rent_rk' => true]));
    $raw['rent_rk'] = array_replace($raw['rent_rk'] ?? [], $next['rent_rk']);
    write_json_file(DEMAND_SETTINGS_FILE, $raw);

    audit_log('demand.settings.updated', 'demand', 'settings', 'Изменены настройки модуля спроса', [
        'changes' => changed_fields($before['rent_rk'], $next['rent_rk'], array_keys($next['rent_rk'])),
    ]);

    return $next;
}

function demand_scope_feature_enabled(string $scopeId, string $feature): bool
{
    if ($scopeId === 'rent_rk') {
        return true;
    }

    return scope_feature_enabled($scopeId, $feature);
}

function demand_current_user_can(string $permission): bool
{
    $user = current_admin_record();
    if (!is_array($user)) {
        return false;
    }

    if (current_user_is_platform_admin()) {
        return true;
    }

    $explicitWordstatTestPermissions = [
        'demand.view',
        'demand.wordstat.view',
        'demand.wordstat.test',
    ];
    if (in_array($permission, $explicitWordstatTestPermissions, true)
        && function_exists('admin_user_has_permission_key')
        && admin_user_has_permission_key($user, $permission)
    ) {
        return true;
    }

    $explicitAiPermissions = [
        'demand.ai.view',
        'demand.ai.package',
        'demand.ai.apply',
        'demand.ai_api.view',
        'demand.ai_api.use',
        'demand.ai_api.apply',
        'demand.ai_api.settings.manage',
        'demand.ai_api.logs.view',
        'demand.ai_dialog.view',
        'demand.ai_dialog.use',
        'demand.ai_workflow.run',
        'demand.ai_workflow.apply',
    ];
    if (function_exists('admin_user_has_permission_key')) {
        if ($permission === 'demand.view'
            && (admin_user_has_permission_key($user, 'demand.ai.view')
                || admin_user_has_permission_key($user, 'demand.ai_api.view')
                || admin_user_has_permission_key($user, 'demand.ai_api.use')
                || admin_user_has_permission_key($user, 'demand.ai_dialog.view')
                || admin_user_has_permission_key($user, 'demand.ai_dialog.use'))
        ) {
            return true;
        }
        if (in_array($permission, $explicitAiPermissions, true) && admin_user_has_permission_key($user, $permission)) {
            return true;
        }
    }

    if (in_array($permission, [
        'demand.import',
        'demand.manage',
        'demand.settings.manage',
        'demand.publish.noindex',
        'demand.publish.index',
        'demand.rollback',
        'demand.sitemap.manage',
        'demand.integrations.manage',
        'demand.integrations.sync',
        'demand.integrations.logs.view',
        'demand.wordstat.manage',
        'demand.wordstat.test',
        'demand.wordstat.sync',
        'demand.wordstat.live',
        'demand.wordstat.logs.view',
        'demand.wordstat.costs.view',
        'demand.map.manage',
        'demand.launch_plan.manage',
        'demand.ai_api.view',
        'demand.ai_api.use',
        'demand.ai_api.apply',
        'demand.ai_api.settings.manage',
        'demand.ai_api.logs.view',
        'demand.ai_dialog.view',
        'demand.ai_dialog.use',
        'demand.ai_workflow.run',
        'demand.ai_workflow.apply',
    ], true)) {
        return false;
    }

    $settings = demand_settings()['rent_rk'];
    if (empty($settings['enabled']) || empty($settings['externalScopesEnabled'])) {
        return false;
    }

    $scopeId = current_user_data_scope_id();
    if ($scopeId === '' || $scopeId === 'rent_rk' || !demand_scope_feature_enabled($scopeId, 'demand_module_enabled')) {
        return false;
    }

    if (in_array($permission, ['demand.view', 'demand.recommendations.view', 'demand.lifecycle.view', 'demand.ai.view', 'demand.ai.package'], true)) {
        return true;
    }

    if (in_array($permission, [
        'demand.map.view',
        'demand.launch_plan.view',
        'demand.content_briefs.view',
        'demand.card_hints.view',
        'demand.publish_wizard.view',
    ], true)) {
        return true;
    }

    if (in_array($permission, ['demand.integrations.view', 'demand.performance.view'], true)) {
        return function_exists('demand_integrations_external_access_allowed') && demand_integrations_external_access_allowed();
    }

    if ($permission === 'demand.wordstat.view') {
        return function_exists('demand_integrations_can_user_view_source') && demand_integrations_can_user_view_source('wordstat');
    }

    if (in_array($permission, ['demand.drafts.create', 'demand.drafts.edit'], true)) {
        return !empty($settings['allowExternalScopeDrafts']) && demand_scope_feature_enabled($scopeId, 'demand_drafts_enabled');
    }

    if (in_array($permission, ['demand.content_briefs.manage', 'demand.card_hints.manage'], true)) {
        return !empty($settings['allowExternalScopeDrafts']) && demand_scope_feature_enabled($scopeId, 'demand_drafts_enabled');
    }

    if ($permission === 'demand.publish_wizard.manage') {
        return !empty($settings['allowExternalScopeDrafts']) && demand_scope_feature_enabled($scopeId, 'demand_drafts_enabled');
    }

    if ($permission === 'demand.ai.apply') {
        return !empty($settings['allowExternalScopeDrafts']) && demand_scope_feature_enabled($scopeId, 'demand_drafts_enabled');
    }

    return false;
}

function demand_visible_scope_ids_for_current_user(): array
{
    if (!has_permission('demand.view')) {
        return [];
    }
    if (current_user_is_platform_admin()) {
        return array_map(static fn(array $scope): string => (string) $scope['scope_id'], scope_list());
    }

    $user = current_admin_record();
    if (is_array($user)
        && function_exists('admin_user_has_permission_key')
        && admin_user_has_permission_key($user, 'demand.view')
        && (admin_user_has_permission_key($user, 'demand.wordstat.view') || admin_user_has_permission_key($user, 'demand.wordstat.test'))
    ) {
        return ['rent_rk'];
    }

    $scopeId = current_user_data_scope_id();
    return $scopeId !== '' ? [$scopeId] : [];
}

function demand_current_scope_filter(string $requestedScope = ''): array
{
    $allowed = demand_visible_scope_ids_for_current_user();
    if (!$allowed) {
        return [];
    }

    $requestedScope = demand_normalize_scope_id($requestedScope);
    if ($requestedScope !== '' && $requestedScope !== 'all' && in_array($requestedScope, $allowed, true)) {
        return [$requestedScope];
    }

    return $allowed;
}

function demand_normalize_scope_id(string $scopeId): string
{
    $scopeId = trim($scopeId);
    if ($scopeId === '' || $scopeId === 'rent-rk') {
        return 'rent_rk';
    }

    return $scopeId === 'rent_rk' ? 'rent_rk' : normalize_lessor_slug($scopeId);
}

function demand_clean_string($value, int $maxLength = 500): string
{
    $text = trim((string) $value);
    $text = preg_replace('/[\x00-\x1F\x7F]/u', '', $text) ?? '';
    if (function_exists('mb_substr')) {
        return mb_substr($text, 0, $maxLength, 'UTF-8');
    }

    return substr($text, 0, $maxLength);
}

function demand_lower(string $text): string
{
    return function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
}

function demand_normalize_phrase(string $phrase): string
{
    $phrase = demand_lower(demand_clean_string($phrase, 240));
    $phrase = str_replace('ё', 'е', $phrase);
    $phrase = preg_replace('/[^\p{L}\p{N}\s:+-]/u', ' ', $phrase) ?? $phrase;
    $phrase = preg_replace('/(.)\1{2,}/u', '$1$1', $phrase) ?? $phrase;
    $phrase = preg_replace('/\s+/u', ' ', $phrase) ?? $phrase;

    return trim($phrase);
}

function demand_normalize_landing_text(string $text): string
{
    $text = demand_lower(demand_clean_string($text, 8000));
    $text = str_replace('ё', 'е', $text);
    $text = preg_replace('/[^\p{L}\p{N}\s:+-]/u', ' ', $text) ?? $text;
    $text = preg_replace('/\s+/u', ' ', $text) ?? $text;

    return trim($text);
}

function demand_unique_strings(array $values): array
{
    $result = [];
    foreach ($values as $value) {
        $value = demand_clean_string($value, 120);
        if ($value !== '') {
            $result[$value] = true;
        }
    }

    return array_values(array_keys($result));
}

function demand_priority_region_names(): array
{
    return [
        'Крым',
        'Республика Крым',
        'Ялта',
        'Симферополь',
        'Севастополь',
        'Алушта',
        'Евпатория',
        'Феодосия',
        'Керчь',
        'Саки',
    ];
}

function demand_service_region_aliases(): array
{
    return [
        'крым' => 'Крым',
        'crimea' => 'Крым',
        'republic of crimea' => 'Крым',
        'республика крым' => 'Крым',
        'ялта' => 'Ялта',
        'ялте' => 'Ялта',
        'yalta' => 'Ялта',
        'симферополь' => 'Симферополь',
        'симферополе' => 'Симферополь',
        'simferopol' => 'Симферополь',
        'севастополь' => 'Севастополь',
        'севастополе' => 'Севастополь',
        'sevastopol' => 'Севастополь',
        'алушта' => 'Алушта',
        'алуште' => 'Алушта',
        'alushta' => 'Алушта',
        'евпатория' => 'Евпатория',
        'евпатории' => 'Евпатория',
        'yevpatoria' => 'Евпатория',
        'evpatoria' => 'Евпатория',
        'феодосия' => 'Феодосия',
        'феодосии' => 'Феодосия',
        'feodosia' => 'Феодосия',
        'керчь' => 'Керчь',
        'керчи' => 'Керчь',
        'kerch' => 'Керчь',
        'саки' => 'Саки',
        'saki' => 'Саки',
    ];
}

function demand_canonical_service_region_name(string $regionName): string
{
    $normalized = demand_normalize_phrase($regionName);
    if ($normalized === '') {
        return '';
    }

    $aliases = demand_service_region_aliases();
    if (isset($aliases[$normalized])) {
        return $aliases[$normalized];
    }

    foreach (demand_priority_region_names() as $name) {
        if ($normalized === demand_normalize_phrase($name)) {
            return $name === 'Республика Крым' ? 'Крым' : $name;
        }
    }

    return demand_clean_string($regionName, 120);
}

function demand_service_region_status(string $regionName): string
{
    $canonical = demand_canonical_service_region_name($regionName);
    if ($canonical === '') {
        return 'unknown_region';
    }

    $normalized = demand_normalize_phrase($canonical);
    if (in_array($normalized, ['сочи', 'краснодарский край', 'крымский район'], true)) {
        return 'not_supported_region';
    }

    foreach (demand_priority_region_names() as $name) {
        $candidate = $name === 'Республика Крым' ? 'Крым' : $name;
        if ($normalized === demand_normalize_phrase($candidate)) {
            return 'confirmed_service_region';
        }
    }

    return 'unknown_region';
}

function demand_region_is_priority(string $regionName): bool
{
    $canonical = demand_canonical_service_region_name($regionName);
    if ($canonical === '') {
        return false;
    }

    $normalized = demand_normalize_phrase($canonical);
    foreach (demand_priority_region_names() as $name) {
        $candidate = $name === 'Республика Крым' ? 'Крым' : $name;
        if ($normalized === demand_normalize_phrase($candidate)) {
            return true;
        }
    }

    return false;
}

function demand_wordstat_region_lookup(): array
{
    static $lookup = null;
    if (is_array($lookup)) {
        return $lookup;
    }

    $lookup = [];
    $path = defined('WORDSTAT_REGIONS_CACHE_FILE') ? WORDSTAT_REGIONS_CACHE_FILE : '';
    if ($path === '' || !is_file($path)) {
        return $lookup;
    }

    $raw = file_get_contents($path);
    $data = is_string($raw) ? json_decode($raw, true) : null;
    foreach ((array) ($data['regions'] ?? []) as $region) {
        if (!is_array($region)) {
            continue;
        }
        $name = demand_clean_string($region['name'] ?? '', 120);
        $normalized = demand_normalize_phrase((string) ($region['normalizedName'] ?? $name));
        if ($name === '' || $normalized === '' || in_array($normalized, ['россия', 'центр'], true)) {
            continue;
        }
        if ((function_exists('mb_strlen') ? mb_strlen($normalized, 'UTF-8') : strlen($normalized)) < 4) {
            continue;
        }
        $lookup[$normalized] = [
            'name' => $name,
            'path' => array_values(array_filter(array_map('strval', (array) ($region['path'] ?? [])))),
            'id' => demand_clean_string($region['id'] ?? '', 80),
            'isPriority' => demand_region_is_priority($name),
        ];
    }
    uksort($lookup, static function (string $a, string $b): int {
        $lenA = function_exists('mb_strlen') ? mb_strlen($a, 'UTF-8') : strlen($a);
        $lenB = function_exists('mb_strlen') ? mb_strlen($b, 'UTF-8') : strlen($b);

        return $lenB <=> $lenA;
    });

    return $lookup;
}

function demand_find_region_in_phrase(string $normalizedPhrase): ?array
{
    foreach (demand_wordstat_region_lookup() as $normalizedName => $region) {
        if (str_contains($normalizedPhrase, $normalizedName)) {
            return $region;
        }
    }

    return null;
}

function demand_phrase_contains_any(string $normalizedPhrase, array $needles): bool
{
    foreach ($needles as $needle) {
        $needle = demand_normalize_phrase((string) $needle);
        if ($needle !== '' && str_contains($normalizedPhrase, $needle)) {
            return true;
        }
    }

    return false;
}

function demand_phrase_has_word(string $normalizedPhrase, string $word): bool
{
    $word = preg_quote(demand_normalize_phrase($word), '/');
    if ($word === '') {
        return false;
    }

    return (bool) preg_match('/(^|\s)' . $word . '($|\s)/u', $normalizedPhrase);
}

function demand_phrase_has_stem_word(string $normalizedPhrase, string $stem): bool
{
    $stem = preg_quote(demand_normalize_phrase($stem), '/');
    if ($stem === '') {
        return false;
    }

    return (bool) preg_match('/(^|\s)' . $stem . '[\p{L}]*($|\s)/u', $normalizedPhrase);
}

function demand_negative_intent_details(string $negativeIntent): array
{
    return match ($negativeIntent) {
        'taxi_transfer' => [
            'decisionHint' => 'ignore_as_irrelevant',
            'reason' => 'Запрос относится к такси, трансферу или пассажирской перевозке, а не к самостоятельной аренде авто.',
            'explanation' => 'Это запрос на такси/перевозку, а не на самостоятельную аренду авто. Не создаём страницу, чтобы не получать нецелевые обращения.',
        ],
        'car_sales' => [
            'decisionHint' => 'ignore_as_irrelevant',
            'reason' => 'Запрос относится к покупке или продаже авто, а не к аренде.',
            'explanation' => 'Запрос про покупку или продажу автомобиля. Для модуля аренды он не используется.',
        ],
        'repair_parts_service' => [
            'decisionHint' => 'ignore_as_irrelevant',
            'reason' => 'Запрос относится к ремонту, сервису или запчастям, а не к аренде авто.',
            'explanation' => 'Запрос относится к автосервису, ремонту или запчастям, а не к аренде авто. Для модуля аренды не используется.',
        ],
        'job_driver' => [
            'decisionHint' => 'ignore_as_irrelevant',
            'reason' => 'Запрос про работу или вакансию водителя, а не про аренду авто.',
            'explanation' => 'Это запрос соискателя работы водителем. Он не должен превращаться в посадочную страницу аренды.',
        ],
        'commercial_use_not_supported' => [
            'decisionHint' => 'needs_business_decision',
            'reason' => 'Запрос связан с коммерческим использованием автомобиля.',
            'explanation' => 'Запрос связан с коммерческим использованием автомобиля. Если Rent RK не сдаёт авто под такси, курьерскую работу или доставку, страницу создавать нельзя.',
        ],
        'carsharing' => [
            'decisionHint' => 'ignore_as_irrelevant',
            'reason' => 'Запрос про каршеринг или поминутную аренду, а не обычную аренду Rent RK.',
            'explanation' => 'Запрос относится к каршерингу или поминутной аренде. Если Rent RK не оказывает такую услугу, страницу не создаём.',
        ],
        'driver_service_not_supported' => [
            'decisionHint' => 'do_not_create_page',
            'reason' => 'Запрос про аренду с водителем, услуга не подтверждена для посадочной страницы.',
            'explanation' => 'Запрос про машину с водителем. Если Rent RK не оказывает такую услугу, страницу создавать нельзя.',
        ],
        'unsupported_vehicle_type' => [
            'decisionHint' => 'do_not_create_page',
            'reason' => 'Запрос про неподдерживаемый тип транспорта.',
            'explanation' => 'Запрос относится к типу транспорта, которого нет в предложении Rent RK. Посадочную страницу создавать нельзя.',
        ],
        'unsafe_legal_request' => [
            'decisionHint' => 'do_not_create_page',
            'reason' => 'Запрос содержит неподдерживаемое или небезопасное юридическое условие.',
            'explanation' => 'Небезопасный и неподдерживаемый запрос. Для самостоятельной аренды нужны действующие водительские права, документы и договор.',
        ],
        'irrelevant_rental_object' => [
            'decisionHint' => 'ignore_as_irrelevant',
            'reason' => 'Запрос про аренду другого объекта, не автомобиля.',
            'explanation' => 'Запрос относится к аренде жилья, помещения или другого объекта, а не автомобиля. Для модуля аренды авто не используется.',
        ],
        'competitor_or_platform_query' => [
            'decisionHint' => 'maybe_use_as_negative_ad_keyword',
            'reason' => 'Запрос связан с внешней площадкой или конкурентным брендом.',
            'explanation' => 'Запрос связан с внешней площадкой или конкурентом. Для SEO-страниц Rent RK его лучше не использовать; можно учесть как минус-фразу в рекламе.',
        ],
        'generic_noise' => [
            'decisionHint' => 'maybe_use_as_negative_ad_keyword',
            'reason' => 'Запрос слишком шумный и не показывает понятный спрос на аренду авто.',
            'explanation' => 'Фраза слишком общая или шумная. Её лучше не превращать в страницу и использовать только для ручной проверки.',
        ],
        default => [
            'decisionHint' => 'ignore_as_irrelevant',
            'reason' => 'Запрос не относится к целевой самостоятельной аренде авто.',
            'explanation' => 'Запрос не относится к самостоятельной аренде авто Rent RK. Страницу по нему не создаём.',
        ],
    };
}

function demand_detect_negative_intent(string $normalizedPhrase): array
{
    $negativeIntent = null;
    if (demand_phrase_contains_any($normalizedPhrase, ['без прав', 'без водительских прав', 'без паспорта', 'без договора', 'без стажа', 'несовершеннолетним'])) {
        $negativeIntent = 'unsafe_legal_request';
    } elseif (demand_phrase_contains_any($normalizedPhrase, ['аренда квартиры', 'аренда жилья', 'аренда дома', 'аренда помещения', 'аренда гаража', 'аренда беседки'])) {
        $negativeIntent = 'irrelevant_rental_object';
    } elseif (demand_phrase_contains_any($normalizedPhrase, ['авито', 'дром', 'юла'])) {
        $negativeIntent = 'competitor_or_platform_query';
    } elseif (demand_phrase_contains_any($normalizedPhrase, ['купить авто', 'купить машину', 'купить автомобиль', 'продажа авто', 'продажа машины', 'авто с пробегом', 'бу авто', 'б у авто', 'купить кабриолет', 'купить минивэн', 'купить минивен'])) {
        $negativeIntent = 'car_sales';
    } elseif (demand_phrase_contains_any($normalizedPhrase, ['ремонт авто', 'ремонт машины', 'автосервис', 'шиномонтаж', 'замена масла', 'диагностика', 'запчасти', 'купить масло', 'грм', 'шрус', 'аккумулятор'])) {
        $negativeIntent = 'repair_parts_service';
    } elseif (demand_phrase_contains_any($normalizedPhrase, ['работа водитель', 'вакансия водитель', 'работа в такси', 'водитель курьер', 'работа на своем авто', 'работа на своём авто'])) {
        $negativeIntent = 'job_driver';
    } elseif (demand_phrase_contains_any($normalizedPhrase, ['аренда авто под такси', 'аренда машины под такси', 'аренда авто для курьера', 'аренда авто под доставку', 'машина для работы в такси', 'авто под такси'])) {
        $negativeIntent = 'commercial_use_not_supported';
    } elseif (demand_phrase_contains_any($normalizedPhrase, ['каршеринг', 'поминутная аренда', 'делимобиль', 'машина по минутам'])) {
        $negativeIntent = 'carsharing';
    } elseif (demand_phrase_contains_any($normalizedPhrase, ['аренда авто с водителем', 'аренда машины с водителем', 'машина с водителем', 'водитель на день', 'минивэн с водителем', 'минивен с водителем', 'микроавтобус с водителем'])) {
        $negativeIntent = 'driver_service_not_supported';
    } elseif (demand_phrase_contains_any($normalizedPhrase, ['такси', 'вызвать такси', 'заказать такси', 'межгород такси', 'пассажирские перевозки', 'минивэн такси', 'минивен такси', 'трансфер'])) {
        $negativeIntent = 'taxi_transfer';
    } elseif (
        demand_phrase_contains_any($normalizedPhrase, ['микроавтобус 20', '20 мест', 'газель', 'грузовик', 'фургон', 'эвакуатор', 'спецтехника', 'мотоцикл', 'скутер', 'квадроцикл', 'катер'])
        || demand_phrase_has_stem_word($normalizedPhrase, 'автобус')
    ) {
        $negativeIntent = 'unsupported_vehicle_type';
    } elseif (count(array_filter(preg_split('/\s+/u', $normalizedPhrase) ?: [])) <= 1) {
        $negativeIntent = 'generic_noise';
    }

    if ($negativeIntent === null) {
        return [
            'negativeIntent' => null,
            'decisionHint' => null,
            'exclusionReason' => '',
            'adminExplanation' => '',
        ];
    }

    $details = demand_negative_intent_details($negativeIntent);

    return [
        'negativeIntent' => $negativeIntent,
        'decisionHint' => (string) $details['decisionHint'],
        'exclusionReason' => (string) $details['reason'],
        'adminExplanation' => (string) $details['explanation'],
    ];
}

function demand_apply_region_confirmation(array $context, string $regionName): array
{
    $regionName = demand_clean_string($regionName, 120);
    if ($regionName === '') {
        return $context;
    }
    if (!empty($context['isExcluded']) || trim((string) ($context['negativeIntent'] ?? '')) !== '') {
        return $context;
    }
    if (demand_region_is_priority($regionName)) {
        return $context;
    }

    $context['categories'] = demand_unique_strings(array_merge((array) ($context['categories'] ?? []), ['region']));
    $context['riskFlags'] = demand_unique_strings(array_merge((array) ($context['riskFlags'] ?? []), ['unknown_region', 'region_not_confirmed', 'needs_business_decision']));
    $context['detectedRiskMarkers'] = demand_unique_strings(array_merge((array) ($context['detectedRiskMarkers'] ?? []), ['unknown_region', 'region_not_confirmed', 'needs_business_decision']));
    $context['decisionHint'] = 'needs_business_decision';
    $context['adminExplanation'] = 'Спрос найден по региону, который не входит в подтверждённую зону Rent RK. Нужно решить, работаем ли мы с этим городом.';
    $context['detectedModifiers']['regionConfirmation'] = 'not_confirmed';
    $context['detectedModifiers']['unknownRegion'] = $regionName;
    if (empty($context['detectedCity']) && empty($context['detectedRegion'])) {
        $context['detectedRegion'] = $regionName;
        $context['features']['detectedRegion'] = $regionName;
    }

    return $context;
}

function demand_detect_context(string $phrase): array
{
    $normalized = demand_normalize_phrase($phrase);
    $tokens = array_values(array_filter(preg_split('/\s+/u', $normalized) ?: [], static fn(string $token): bool => $token !== ''));
    $categories = [];
    $riskFlags = [];
    $secondaryIntents = [];
    $synonymGroups = [];
    $detectedModifiers = [];
    $mustNotPromise = [];
    $detectedCity = null;
    $detectedRegion = null;
    $detectedCarClass = null;
    $detectedCondition = null;
    $detectedScenario = null;
    $detectedPriceModifier = null;
    $detectedDuration = null;

    $containsAny = static function (array $needles) use ($normalized): bool {
        foreach ($needles as $needle) {
            $needle = demand_normalize_phrase((string) $needle);
            if ($needle !== '' && str_contains($normalized, $needle)) {
                return true;
            }
        }

        return false;
    };
    $negative = demand_detect_negative_intent($normalized);

    $cityMap = [
        'ялт' => 'Ялта',
        'симферопол' => 'Симферополь',
        'алушт' => 'Алушта',
        'севастопол' => 'Севастополь',
        'евпатори' => 'Евпатория',
        'феодоси' => 'Феодосия',
        'керч' => 'Керчь',
        'саки' => 'Саки',
    ];
    foreach ($cityMap as $needle => $city) {
        if (str_contains($normalized, $needle)) {
            $detectedCity = $city;
            $categories[] = 'city';
            $detectedModifiers['city'] = $city;
            break;
        }
    }
    if ((bool) preg_match('/(^|\s)(крым|крыма|крыму|крыме|крымом)($|\s)/u', $normalized)) {
        $detectedRegion = 'Крым';
        $categories[] = 'region';
        $detectedModifiers['region'] = 'Крым';
    }
    if ($detectedCity === null && $detectedRegion === null) {
        $cacheRegion = demand_find_region_in_phrase($normalized);
        if (is_array($cacheRegion)) {
            $detectedRegion = (string) ($cacheRegion['name'] ?? '');
            $categories[] = 'region';
            $detectedModifiers['region'] = $detectedRegion;
            if (!empty($cacheRegion['path'])) {
                $detectedModifiers['regionPath'] = implode(' / ', (array) $cacheRegion['path']);
            }
            if (empty($cacheRegion['isPriority'])) {
                $riskFlags[] = 'unknown_region';
                $riskFlags[] = 'region_not_confirmed';
                $riskFlags[] = 'needs_business_decision';
            }
        }
    }

    if ($containsAny(['аренда', 'прокат', 'взять напрокат', 'напрокат', 'в аренду', 'снять'])) {
        $synonymGroups[] = 'rental';
    }
    if ($containsAny(['авто', 'автомобиль', 'машина', 'машину', 'машины'])) {
        $synonymGroups[] = 'car';
    }

    $classPatterns = [
        'минивэн' => ['минивен', 'минивэн', '7 мест', 'семимест', 'семи мест', 'семей'],
        'кабриолет' => ['кабриолет'],
        'кроссовер' => ['кроссовер', 'внедорожник', 'джип'],
        'седан' => ['седан'],
        'компакт' => ['компакт'],
        'бизнес' => ['бизнес'],
        'эконом' => ['эконом'],
        'микроавтобус' => ['микроавтобус'],
    ];
    foreach ($classPatterns as $class => $needles) {
        foreach ($needles as $needle) {
            if (str_contains($normalized, $needle)) {
                $detectedCarClass = $class;
                $categories[] = 'car_class';
                $detectedModifiers['carClass'] = $class;
                break 2;
            }
        }
    }

    if (str_contains($normalized, 'без залога')) {
        $detectedCondition = 'без залога';
        $categories[] = 'condition';
        $riskFlags[] = 'possible_false_promise';
        $riskFlags[] = 'condition_not_supported';
        $riskFlags[] = 'needs_human_review';
        $detectedModifiers['condition'] = 'без залога';
        $mustNotPromise[] = 'аренду без залога, если это не подтверждено условиями автопарка';
        $secondaryIntents[] = 'condition_rental';
    } elseif (str_contains($normalized, 'без водителя')) {
        $detectedCondition = 'без водителя';
        $categories[] = 'condition';
        $detectedModifiers['condition'] = 'без водителя';
        $secondaryIntents[] = 'driverless';
    } elseif (str_contains($normalized, 'с водителем')) {
        $detectedCondition = 'с водителем';
        $categories[] = 'condition';
        $riskFlags[] = 'driver_service_not_confirmed';
        $riskFlags[] = 'needs_human_review';
        $detectedModifiers['condition'] = 'с водителем';
        $secondaryIntents[] = 'condition_rental';
    } elseif (str_contains($normalized, 'подач')) {
        $detectedCondition = 'подача';
        $categories[] = 'condition';
        $riskFlags[] = 'airport_delivery_not_confirmed';
        $riskFlags[] = 'needs_human_review';
        $detectedModifiers['condition'] = 'подача';
        $secondaryIntents[] = 'condition_rental';
    } elseif (str_contains($normalized, 'детск') || str_contains($normalized, 'кресл')) {
        $detectedCondition = 'детское кресло';
        $categories[] = 'family';
        $detectedScenario = 'family_trip';
        $detectedModifiers['scenario'] = 'family_trip';
    }
    if (str_contains($normalized, 'аэропорт')) {
        $categories[] = 'airport';
        $riskFlags[] = 'airport_delivery_not_confirmed';
        $riskFlags[] = 'needs_human_review';
        $detectedModifiers['airport'] = 'аэропорт';
        $secondaryIntents[] = 'airport_delivery';
        $mustNotPromise[] = 'подачу в аэропорт без подтверждения условий и стоимости подачи';
    }
    if ($containsAny(['цена', 'стоимость', 'дешев', 'дешёв', 'недорог', 'доступно'])) {
        $categories[] = 'price';
        $riskFlags[] = 'price_claim_risk';
        $detectedPriceModifier = 'price_sensitive';
        $detectedModifiers['price'] = 'price_sensitive';
        $secondaryIntents[] = 'price_sensitive';
        $mustNotPromise[] = 'самую низкую цену или фиксированную стоимость без подтверждения тарифами';
    }
    if ($containsAny(['посуточно', 'на сутки', 'сутки', 'сутк', 'на день'])) {
        $categories[] = 'price';
        $detectedDuration = 'day';
        $detectedModifiers['duration'] = 'day';
    } elseif ($containsAny(['на неделю', 'недел'])) {
        $categories[] = 'price';
        $detectedDuration = 'week';
        $detectedModifiers['duration'] = 'week';
    } elseif ($containsAny(['на месяц', 'месяц'])) {
        $categories[] = 'price';
        $detectedDuration = 'month';
        $detectedModifiers['duration'] = 'month';
    }
    if (str_contains($normalized, 'летом') || str_contains($normalized, 'летн')) {
        $categories[] = 'season';
        $detectedModifiers['season'] = 'summer';
    }
    if (str_contains($normalized, 'семь') || str_contains($normalized, 'семей')) {
        $categories[] = 'family';
        $detectedScenario = $detectedScenario ?: 'family_trip';
        $detectedModifiers['scenario'] = 'family_trip';
        $secondaryIntents[] = 'family_trip';
    }
    if ($containsAny(['маршрут', 'поездка', 'из ялты в', 'из симферополя в', 'трансфер'])) {
        $categories[] = 'route';
        $secondaryIntents[] = 'route_trip';
        $detectedModifiers['route'] = 'route_trip';
    }
    if ($containsAny(['что нужно', 'какие документы', 'как арендовать', 'как взять', 'условия аренды', 'нужен ли', 'можно ли'])) {
        $categories[] = 'faq';
        $secondaryIntents[] = 'informational';
    }
    if ($containsAny(['сравнить', 'лучше', 'какой выбрать', 'что выбрать'])) {
        $secondaryIntents[] = 'comparison';
    }
    if ($containsAny(['без прав', 'без водительских прав', 'без паспорта', 'без договора', 'без стажа'])) {
        $categories[] = 'condition';
        $riskFlags[] = 'unsupported_legal_request';
        $riskFlags[] = 'condition_not_supported';
        $riskFlags[] = 'needs_human_review';
        $detectedModifiers['unsafe'] = 'unsupported_legal_request';
        $mustNotPromise[] = 'аренду без прав, паспорта, договора или обязательных документов';
    }
    if ($containsAny(['круглосуточно', 'срочно', 'прямо сейчас', 'сегодня ночью'])) {
        $riskFlags[] = 'availability_claim_risk';
        $riskFlags[] = 'needs_human_review';
        $detectedModifiers['availability'] = 'urgent_or_24h';
        $mustNotPromise[] = 'круглосуточную или срочную выдачу без подтвержденного режима работы';
    }
    $negativeIntent = (string) ($negative['negativeIntent'] ?? '');
    if ($negativeIntent !== '') {
        $categories[] = 'excluded';
        $riskFlags[] = 'not_relevant_for_car_rental';
        $detectedModifiers['negativeIntent'] = $negativeIntent;
        if ($negativeIntent === 'unsafe_legal_request') {
            $riskFlags[] = 'unsupported_legal_request';
            $riskFlags[] = 'condition_not_supported';
        }
        if ($negativeIntent === 'driver_service_not_supported') {
            $riskFlags[] = 'driver_service_not_confirmed';
        }
        $mustNotPromise[] = 'посадочную страницу по нецелевому или неподдерживаемому запросу';
    }

    $genericPhrases = ['аренда авто', 'прокат авто', 'аренда машины', 'прокат машины', 'авто в аренду'];
    if (in_array($normalized, $genericPhrases, true) || count($tokens) <= 2) {
        $riskFlags[] = 'too_generic';
    }

    $categories = demand_unique_strings($categories);
    if (!$categories) {
        $categories[] = 'unknown';
    }

    $intent = 'unknown';
    if ($negativeIntent !== '') {
        $intent = 'unsafe_or_unsupported';
    } elseif (in_array('unsupported_legal_request', $riskFlags, true)) {
        $intent = 'unsafe_or_unsupported';
    } elseif ($detectedCondition === 'без залога') {
        $intent = 'deposit_sensitive';
    } elseif (in_array('airport_delivery', $secondaryIntents, true)) {
        $intent = 'airport_delivery';
    } elseif ($detectedCarClass !== null) {
        $intent = 'car_class_rental';
    } elseif ($detectedCondition === 'без водителя') {
        $intent = 'driverless';
    } elseif ($detectedCondition !== null) {
        $intent = 'condition_rental';
    } elseif ($detectedPriceModifier === 'price_sensitive') {
        $intent = 'price_sensitive';
    } elseif ($detectedScenario === 'family_trip') {
        $intent = 'family_trip';
    } elseif (in_array('informational', $secondaryIntents, true) && !in_array('rental', $synonymGroups, true)) {
        $intent = 'informational';
    } elseif ($detectedCity !== null) {
        $intent = 'city_rental';
    } elseif ($detectedRegion !== null) {
        $intent = 'region_rental';
    } elseif (in_array('route_trip', $secondaryIntents, true)) {
        $intent = 'route_trip';
    } elseif (in_array('comparison', $secondaryIntents, true)) {
        $intent = 'comparison';
    } elseif (in_array('informational', $secondaryIntents, true)) {
        $intent = 'informational';
    }

    foreach ([
        $detectedCity !== null ? 'city_rental' : '',
        $detectedRegion !== null ? 'region_rental' : '',
        $detectedCarClass !== null ? 'car_class_rental' : '',
        $detectedCondition !== null ? 'condition_rental' : '',
        $detectedCondition === 'без залога' ? 'deposit_sensitive' : '',
        $detectedCondition === 'без водителя' ? 'driverless' : '',
        $detectedPriceModifier === 'price_sensitive' ? 'price_sensitive' : '',
    ] as $secondary) {
        if ($secondary !== '' && $secondary !== $intent) {
            $secondaryIntents[] = $secondary;
        }
    }
    $secondaryIntents = demand_unique_strings(array_filter($secondaryIntents, static fn(string $value): bool => $value !== $intent));

    $decisionHint = 'needs_human_review';
    if ($intent === 'unsafe_or_unsupported' || $intent === 'deposit_sensitive') {
        $decisionHint = 'do_not_create_page';
    } elseif ($intent === 'informational') {
        $decisionHint = 'create_faq';
    } elseif ($intent === 'price_sensitive' || $intent === 'condition_rental') {
        $decisionHint = 'add_condition_block';
    } elseif ($intent === 'airport_delivery' || $intent === 'route_trip') {
        $decisionHint = 'needs_business_decision';
    } elseif (in_array($intent, ['city_rental', 'region_rental', 'car_class_rental', 'family_trip', 'driverless'], true)) {
        $decisionHint = in_array('too_generic', $riskFlags, true) ? 'needs_human_review' : 'create_landing_page';
    } elseif ($intent === 'comparison') {
        $decisionHint = 'create_content_brief';
    } elseif ($intent === 'unknown' && in_array('too_generic', $riskFlags, true)) {
        $decisionHint = 'needs_human_review';
    }
    if (in_array('region_not_confirmed', $riskFlags, true)) {
        $decisionHint = 'needs_business_decision';
    }
    if ($negativeIntent !== '') {
        $decisionHint = (string) ($negative['decisionHint'] ?? 'ignore_as_irrelevant');
    }

    $adminExplanation = 'Фраза пока распознана слабо. Лучше проверить её вручную и не создавать страницу автоматически.';
    if ($intent === 'unsafe_or_unsupported') {
        $adminExplanation = 'Запрос небезопасный и не должен становиться посадочной страницей. Для самостоятельной аренды нужны действующие права, документы и договор.';
    } elseif ($intent === 'deposit_sensitive') {
        $adminExplanation = 'Запрос есть, но страница с обещанием "без залога" может создать ложное ожидание. Если залог в условиях есть или не подтверждено обратное, лучше сделать FAQ о том, как работает залог.';
    } elseif ($intent === 'car_class_rental') {
        $adminExplanation = 'Люди ищут конкретный класс авто' . ($detectedCarClass ? ' (' . $detectedCarClass . ')' : '') . '. Если в парке есть подходящие машины, стоит подготовить страницу или доработать карточки этих авто.';
    } elseif ($intent === 'city_rental') {
        $adminExplanation = 'Люди ищут аренду авто в городе' . ($detectedCity ? ' ' . $detectedCity : '') . '. Если выдача или подача там подтверждена, можно готовить городскую страницу через ручной workflow.';
    } elseif ($intent === 'region_rental') {
        $adminExplanation = 'Запрос относится к региону' . ($detectedRegion ? ' ' . $detectedRegion : '') . '. Стоит проверить реальную географию работы и затем готовить страницу или блок условий.';
    } elseif ($intent === 'airport_delivery') {
        $adminExplanation = 'Запрос связан с аэропортом или подачей. Нужна ручная проверка: где реально выдаётся авто, сколько стоит подача и какие ограничения есть.';
    } elseif ($intent === 'driverless') {
        $adminExplanation = 'Пользователь ищет аренду без водителя. Если такая услуга соответствует текущим условиям, можно готовить страницу или FAQ без лишних обещаний.';
    } elseif ($intent === 'condition_rental') {
        $adminExplanation = 'Фраза про условие аренды. Безопаснее добавить понятный блок условий или FAQ, чем создавать отдельную страницу с неподтвержденным обещанием.';
    } elseif ($intent === 'price_sensitive') {
        $adminExplanation = 'Пользователь чувствителен к цене. Нельзя обещать самую низкую стоимость; можно объяснить тарифы и показать экономичные варианты, если они реально есть.';
    } elseif ($intent === 'family_trip') {
        $adminExplanation = 'Запрос похож на семейный сценарий. Полезно выделить места, багаж, детское кресло и подходящие автомобили, если эти данные подтверждены.';
    } elseif ($intent === 'informational') {
        $adminExplanation = 'Пользователь задаёт вопрос, а не обязательно ищет отдельную страницу. Лучше подготовить FAQ или блок ответа в существующей странице.';
    } elseif ($intent === 'comparison') {
        $adminExplanation = 'Пользователь сравнивает варианты. Лучше подготовить ТЗ или объясняющий блок, который помогает выбрать авто без ложных обещаний.';
    }
    if (in_array('region_not_confirmed', $riskFlags, true)) {
        $adminExplanation = 'Спрос найден по региону, который не входит в подтверждённую зону Rent RK. Нужно решить, работаем ли мы с этим городом.';
    }
    if ($negativeIntent !== '') {
        $adminExplanation = (string) ($negative['adminExplanation'] ?? $adminExplanation);
    }

    $isInformational = in_array($intent, ['informational', 'comparison'], true);
    $isCommercial = !$isInformational && (in_array('rental', $synonymGroups, true) || in_array('car', $synonymGroups, true));
    $demandType = $negativeIntent !== ''
        ? 'excluded'
        : ($intent === 'unsafe_or_unsupported' ? 'unsafe' : ($isInformational ? 'informational' : ($isCommercial ? 'commercial' : 'unknown')));

    $priority = ['excluded', 'airport', 'car_class', 'condition', 'price', 'route', 'season', 'family', 'city', 'region', 'faq', 'unknown'];
    $category = 'unknown';
    foreach ($priority as $candidate) {
        if (in_array($candidate, $categories, true)) {
            $category = $candidate;
            break;
        }
    }

    return [
        'normalizedPhrase' => $normalized,
        'category' => $category,
        'categories' => $categories,
        'intent' => $intent,
        'secondaryIntents' => $secondaryIntents,
        'demandType' => $demandType,
        'features' => [
            'tokens' => $tokens,
            'synonymGroups' => demand_unique_strings($synonymGroups),
            'detectedRegion' => $detectedRegion,
            'detectedCity' => $detectedCity,
            'detectedCarClass' => $detectedCarClass,
            'detectedScenario' => $detectedScenario,
            'detectedCondition' => $detectedCondition,
            'detectedPriceModifier' => $detectedPriceModifier,
            'detectedDuration' => $detectedDuration,
            'detectedRiskMarkers' => demand_unique_strings($riskFlags),
            'negativeIntent' => $negativeIntent !== '' ? $negativeIntent : null,
            'isCommercial' => $isCommercial,
            'isInformational' => $isInformational,
            'needsHumanReview' => in_array('needs_human_review', $riskFlags, true),
        ],
        'detectedModifiers' => $detectedModifiers,
        'detectedCity' => $detectedCity,
        'detectedRegion' => $detectedRegion,
        'detectedCarClass' => $detectedCarClass,
        'detectedCondition' => $detectedCondition,
        'detectedScenario' => $detectedScenario,
        'detectedPriceModifier' => $detectedPriceModifier,
        'detectedDuration' => $detectedDuration,
        'detectedRiskMarkers' => demand_unique_strings($riskFlags),
        'negativeIntent' => $negativeIntent !== '' ? $negativeIntent : null,
        'exclusionReason' => $negativeIntent !== '' ? (string) ($negative['exclusionReason'] ?? '') : '',
        'isExcluded' => $negativeIntent !== '',
        'decisionHint' => $decisionHint,
        'adminExplanation' => $adminExplanation,
        'mustNotPromise' => demand_unique_strings($mustNotPromise),
        'riskFlags' => demand_unique_strings($riskFlags),
    ];
}

function demand_keyword_duplicate_key(array $keyword): string
{
    return implode('|', [
        demand_normalize_scope_id((string) ($keyword['scope_id'] ?? 'rent_rk')),
        demand_normalize_phrase((string) ($keyword['normalizedPhrase'] ?? $keyword['phrase'] ?? '')),
        demand_lower(demand_clean_string((string) ($keyword['regionName'] ?? ''), 120)),
    ]);
}

function demand_normalize_keyword_record(array $row, ?array $existing = null): array
{
    $now = now_iso();
    $phrase = demand_clean_string($row['phrase'] ?? ($existing['phrase'] ?? ''), 240);
    $context = demand_detect_context($phrase);
    $frequency = isset($row['frequency']) && is_numeric($row['frequency']) ? max(0, (int) $row['frequency']) : (int) ($existing['frequency'] ?? 0);
    $settings = demand_settings()['rent_rk'];
    $riskFlags = array_merge(
        is_array($existing['riskFlags'] ?? null) ? $existing['riskFlags'] : [],
        is_array($row['riskFlags'] ?? null) ? $row['riskFlags'] : [],
        $context['riskFlags']
    );
    if ($frequency > 0 && $frequency < (int) $settings['minFrequencyForDraftSuggestion']) {
        $riskFlags[] = 'low_frequency';
    }

    $scopeId = demand_normalize_scope_id((string) ($row['scope_id'] ?? $row['scopeId'] ?? ($existing['scope_id'] ?? 'rent_rk')));
    $regionName = demand_clean_string($row['regionName'] ?? ($existing['regionName'] ?? ($context['detectedCity'] ?? $context['detectedRegion'] ?? '')), 120);
    $context = demand_apply_region_confirmation($context, $regionName);
    $riskFlags = array_merge($riskFlags, (array) ($context['riskFlags'] ?? []));
    $negativeIntent = demand_clean_string($context['negativeIntent'] ?? '', 120);
    $statusInput = demand_clean_string($row['status'] ?? ($existing['status'] ?? ''), 40);
    if ($negativeIntent !== '' && ($statusInput === '' || $statusInput === 'active')) {
        $statusInput = 'excluded';
    }
    if ($statusInput === '') {
        $statusInput = 'active';
    }

    return [
        'id' => (string) ($existing['id'] ?? ('dk_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)))),
        'scope_id' => $scopeId,
        'phrase' => $phrase,
        'normalizedPhrase' => $context['normalizedPhrase'],
        'regionId' => demand_clean_string($row['regionId'] ?? ($existing['regionId'] ?? ''), 80) ?: null,
        'regionName' => $regionName,
        'source' => demand_clean_string($row['source'] ?? ($existing['source'] ?? 'manual_wordstat_import'), 120) ?: 'manual_wordstat_import',
        'frequency' => $frequency,
        'frequencyPeriod' => demand_clean_string($row['frequencyPeriod'] ?? ($existing['frequencyPeriod'] ?? 'month'), 40) ?: 'month',
        'trend' => demand_clean_string($row['trend'] ?? ($existing['trend'] ?? ''), 80) ?: null,
        'seasonality' => is_array($row['seasonality'] ?? null) ? array_values($row['seasonality']) : (is_array($existing['seasonality'] ?? null) ? array_values($existing['seasonality']) : []),
        'category' => demand_clean_string($row['category'] ?? ($existing['category'] ?? $context['category']), 80) ?: $context['category'],
        'categories' => $context['categories'],
        'intent' => demand_clean_string($row['intent'] ?? ($existing['intent'] ?? $context['intent']), 120) ?: $context['intent'],
        'secondaryIntents' => demand_unique_strings((array) ($context['secondaryIntents'] ?? [])),
        'demandType' => demand_clean_string($context['demandType'] ?? '', 80) ?: 'unknown',
        'features' => is_array($context['features'] ?? null) ? $context['features'] : [],
        'detectedModifiers' => is_array($context['detectedModifiers'] ?? null) ? $context['detectedModifiers'] : [],
        'detectedCity' => $context['detectedCity'],
        'detectedRegion' => $context['detectedRegion'],
        'detectedCarClass' => $context['detectedCarClass'],
        'detectedCondition' => $context['detectedCondition'],
        'detectedScenario' => $context['detectedScenario'] ?? null,
        'detectedPriceModifier' => $context['detectedPriceModifier'] ?? null,
        'detectedDuration' => $context['detectedDuration'] ?? null,
        'detectedRiskMarkers' => demand_unique_strings((array) ($context['detectedRiskMarkers'] ?? [])),
        'negativeIntent' => $negativeIntent !== '' ? $negativeIntent : null,
        'exclusionReason' => demand_clean_string($context['exclusionReason'] ?? '', 800),
        'isExcluded' => !empty($context['isExcluded']),
        'decisionHint' => demand_clean_string($context['decisionHint'] ?? '', 120) ?: 'needs_human_review',
        'adminExplanation' => demand_clean_string($context['adminExplanation'] ?? '', 1000),
        'mustNotPromise' => demand_unique_strings((array) ($context['mustNotPromise'] ?? [])),
        'riskFlags' => demand_unique_strings($riskFlags),
        'status' => $statusInput,
        'comment' => demand_clean_string($row['comment'] ?? ($existing['comment'] ?? ''), 500),
        'createdAt' => (string) ($existing['createdAt'] ?? $now),
        'updatedAt' => $now,
    ];
}

function read_demand_keywords(): array
{
    return demand_read_container(DEMAND_KEYWORDS_FILE);
}

function save_demand_keywords(array $data): void
{
    demand_write_container(DEMAND_KEYWORDS_FILE, $data);
}

function read_demand_recommendations(): array
{
    return demand_read_container(DEMAND_RECOMMENDATIONS_FILE);
}

function save_demand_recommendations(array $data): void
{
    demand_write_container(DEMAND_RECOMMENDATIONS_FILE, $data);
}

function read_landing_page_drafts(): array
{
    return demand_read_container(LANDING_PAGE_DRAFTS_FILE);
}

function save_landing_page_drafts(array $data): void
{
    demand_write_container(LANDING_PAGE_DRAFTS_FILE, $data);
}

function read_landing_page_versions(): array
{
    return demand_read_container(LANDING_PAGE_VERSIONS_FILE);
}

function save_landing_page_versions(array $data): void
{
    demand_write_container(LANDING_PAGE_VERSIONS_FILE, $data);
}

function read_seo_page_lifecycle(): array
{
    return demand_read_container(SEO_PAGE_LIFECYCLE_FILE);
}

function save_seo_page_lifecycle(array $data): void
{
    demand_write_container(SEO_PAGE_LIFECYCLE_FILE, $data);
}

function demand_append_lifecycle_event(string $scopeId, string $entityType, string $entityId, string $event, string $message, string $createdBy = '', array $meta = []): void
{
    $data = read_seo_page_lifecycle();
    $entry = [
        'id' => 'spl_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'scope_id' => demand_normalize_scope_id($scopeId),
        'entityType' => $entityType,
        'entityId' => $entityId,
        'event' => $event,
        'message' => $message,
        'previousStatus' => (string) ($meta['previousStatus'] ?? ''),
        'newStatus' => (string) ($meta['newStatus'] ?? ''),
        'createdBy' => $createdBy !== '' ? $createdBy : (current_admin_user() ?: 'system'),
        'createdAt' => now_iso(),
    ];
    foreach (['previousIndexStatus', 'newIndexStatus', 'reason', 'targetPageId', 'targetUrl', 'versionId'] as $key) {
        if (isset($meta[$key]) && trim((string) $meta[$key]) !== '') {
            $entry[$key] = (string) $meta[$key];
        }
    }
    array_unshift($data['items'], $entry);
    $data['items'] = array_slice($data['items'], 0, 5000);
    save_seo_page_lifecycle($data);
}

function demand_parse_frequency($value, array &$warnings, int $rowNumber): int
{
    $raw = trim((string) $value);
    if ($raw === '') {
        return 0;
    }
    $normalized = preg_replace('/[^\d]/', '', $raw) ?? '';
    if ($normalized === '') {
        $warnings[] = 'Строка ' . $rowNumber . ': частотность "' . $raw . '" некорректна, сохранено 0.';
        return 0;
    }

    return max(0, (int) $normalized);
}

function demand_csv_delimiter(string $header): string
{
    $candidates = [',' => substr_count($header, ','), ';' => substr_count($header, ';'), "\t" => substr_count($header, "\t")];
    arsort($candidates);

    return (string) array_key_first($candidates);
}

function demand_parse_csv_rows(string $raw, string $defaultScopeId = 'rent_rk'): array
{
    $raw = preg_replace('/^\xEF\xBB\xBF/', '', $raw) ?? $raw;
    $lines = preg_split('/\r\n|\r|\n/', $raw) ?: [];
    $lines = array_values(array_filter($lines, static fn(string $line): bool => trim($line) !== ''));
    if (!$lines) {
        return ['rows' => [], 'errors' => ['CSV пустой.'], 'warnings' => []];
    }

    $delimiter = demand_csv_delimiter($lines[0]);
    $headers = array_map(static fn($value): string => demand_lower(trim((string) $value)), str_getcsv($lines[0], $delimiter));
    $aliases = [
        'phrase' => ['phrase', 'query', 'keyword', 'фраза', 'запрос'],
        'regionName' => ['regionname', 'region_name', 'region', 'регион', 'город'],
        'frequency' => ['frequency', 'freq', 'частотность', 'показы'],
        'regionId' => ['regionid', 'region_id'],
        'source' => ['source', 'источник'],
        'frequencyPeriod' => ['frequencyperiod', 'frequency_period', 'period'],
        'trend' => ['trend', 'тренд'],
        'comment' => ['comment', 'комментарий'],
        'scope_id' => ['scope_id', 'scopeid', 'scope'],
    ];
    $map = [];
    foreach ($aliases as $field => $names) {
        foreach ($headers as $index => $header) {
            $header = str_replace([' ', '-'], ['', '_'], $header);
            if (in_array($header, $names, true)) {
                $map[$field] = $index;
                break;
            }
        }
    }
    if (!isset($map['phrase'])) {
        return ['rows' => [], 'errors' => ['В CSV нужна колонка phrase.'], 'warnings' => []];
    }

    $rows = [];
    $warnings = [];
    for ($i = 1; $i < count($lines); $i++) {
        $values = str_getcsv($lines[$i], $delimiter);
        $rowNumber = $i + 1;
        $phrase = trim((string) ($values[$map['phrase']] ?? ''));
        if ($phrase === '') {
            $warnings[] = 'Строка ' . $rowNumber . ': пустая фраза пропущена.';
            continue;
        }
        $row = [
            'scope_id' => $defaultScopeId,
            'phrase' => $phrase,
            'regionName' => isset($map['regionName']) ? (string) ($values[$map['regionName']] ?? '') : '',
            'frequency' => isset($map['frequency']) ? demand_parse_frequency($values[$map['frequency']] ?? '', $warnings, $rowNumber) : 0,
            'source' => 'manual_wordstat_import',
        ];
        foreach (['regionId', 'source', 'frequencyPeriod', 'trend', 'comment', 'scope_id'] as $field) {
            if (isset($map[$field])) {
                $row[$field] = (string) ($values[$map[$field]] ?? '');
            }
        }
        if (trim((string) ($row['source'] ?? '')) === '') {
            $row['source'] = 'manual_wordstat_import';
        }
        $rows[] = $row;
    }

    return ['rows' => $rows, 'errors' => [], 'warnings' => $warnings];
}

function demand_parse_json_rows(string $raw, string $defaultScopeId = 'rent_rk'): array
{
    $raw = preg_replace('/^\xEF\xBB\xBF/', '', $raw) ?? $raw;
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        return ['rows' => [], 'errors' => ['JSON не удалось прочитать: ' . json_last_error_msg()], 'warnings' => []];
    }

    $items = isset($decoded['items']) && is_array($decoded['items']) ? $decoded['items'] : $decoded;
    $rows = [];
    $warnings = [];
    foreach ($items as $index => $item) {
        if (!is_array($item)) {
            $warnings[] = 'Запись JSON #' . ($index + 1) . ' пропущена: ожидался объект.';
            continue;
        }
        $phrase = trim((string) ($item['phrase'] ?? $item['query'] ?? $item['keyword'] ?? ''));
        if ($phrase === '') {
            $warnings[] = 'Запись JSON #' . ($index + 1) . ' пропущена: нет phrase.';
            continue;
        }
        $item['phrase'] = $phrase;
        $item['scope_id'] = demand_normalize_scope_id((string) ($item['scope_id'] ?? $item['scopeId'] ?? $defaultScopeId));
        $item['frequency'] = demand_parse_frequency($item['frequency'] ?? 0, $warnings, $index + 1);
        $rows[] = $item;
    }

    return ['rows' => $rows, 'errors' => [], 'warnings' => $warnings];
}

function demand_existing_keyword_map(): array
{
    $map = [];
    foreach (read_demand_keywords()['items'] as $keyword) {
        if (!is_array($keyword)) {
            continue;
        }
        $map[demand_keyword_duplicate_key($keyword)] = $keyword;
    }

    return $map;
}

function demand_import_preview_group_definitions(): array
{
    return [
        'usable' => [
            'label' => 'Можно использовать',
            'summaryLabel' => 'Можно использовать',
            'tone' => 'success',
            'description' => 'Эти фразы похожи на реальный спрос по аренде авто. По ним можно готовить страницы, FAQ, подсказки или черновики.',
            'empty' => 'В этой загрузке нет явно целевых фраз для аренды авто.',
        ],
        'review' => [
            'label' => 'Нужна проверка',
            'summaryLabel' => 'Нужна проверка',
            'tone' => 'warning',
            'description' => 'Эти фразы нельзя сразу превращать в страницы. Сначала нужно решить, реально ли Rent RK оказывает такую услугу.',
            'empty' => 'Фраз, требующих решения владельца, не найдено.',
        ],
        'no_page' => [
            'label' => 'Не создавать страницы',
            'summaryLabel' => 'Не создавать страницы',
            'tone' => 'attention',
            'description' => 'По этим фразам нельзя делать продающие страницы с прямым обещанием. Иногда их можно использовать для FAQ или объяснения условий.',
            'empty' => 'Опасных условий для блокировки посадочных страниц не найдено.',
        ],
        'irrelevant' => [
            'label' => 'Нецелевые запросы',
            'summaryLabel' => 'Нецелевые',
            'tone' => 'muted',
            'description' => 'Эти фразы не относятся к самостоятельной аренде авто. Они сохраняются как исключённые, чтобы система не предлагала по ним страницы.',
            'empty' => 'Нецелевых запросов не найдено.',
        ],
        'duplicates' => [
            'label' => 'Дубли и обновления',
            'summaryLabel' => 'Дубли / обновления',
            'tone' => 'neutral',
            'description' => 'Эти фразы уже есть в системе. При сохранении они будут обновлены или пропущены по правилам импорта.',
            'empty' => 'Дублей и обновлений в этой загрузке нет.',
        ],
        'errors' => [
            'label' => 'Ошибки файла',
            'summaryLabel' => 'Ошибки',
            'tone' => 'danger',
            'description' => 'Эти строки нужно исправить в файле или пропустить.',
            'empty' => 'Ошибок в файле не найдено.',
        ],
        'all' => [
            'label' => 'Все строки файла',
            'summaryLabel' => 'Все строки',
            'tone' => 'neutral',
            'description' => 'Полный список строк загрузки. Обычно он нужен только для проверки файла.',
            'empty' => 'Строк для отображения нет.',
        ],
    ];
}

function demand_import_preview_intent_label(string $intent, string $negativeIntent = ''): string
{
    $negativeIntent = trim($negativeIntent);
    if ($negativeIntent !== '') {
        return [
            'taxi_transfer' => 'Такси / трансфер',
            'car_sales' => 'Покупка или продажа авто',
            'repair_parts_service' => 'Ремонт / запчасти',
            'job_driver' => 'Работа / водитель',
            'commercial_use_not_supported' => 'Коммерческое использование',
            'carsharing' => 'Каршеринг',
            'driver_service_not_supported' => 'Авто с водителем',
            'unsupported_vehicle_type' => 'Неподдерживаемый транспорт',
            'unsafe_legal_request' => 'Небезопасный запрос',
            'irrelevant_rental_object' => 'Не аренда авто',
            'competitor_or_platform_query' => 'Площадка / конкурент',
            'generic_noise' => 'Нецелевой запрос',
        ][$negativeIntent] ?? $negativeIntent;
    }

    return [
        'city_rental' => 'Городская аренда',
        'region_rental' => 'Региональная аренда',
        'car_class_rental' => 'Класс автомобиля',
        'condition_rental' => 'Условие аренды',
        'airport_delivery' => 'Аэропорт / подача',
        'family_trip' => 'Семья / 7 мест',
        'route_trip' => 'Маршрут / поездка',
        'price_sensitive' => 'Цена / бюджет',
        'deposit_sensitive' => 'Залог',
        'driverless' => 'Без водителя',
        'informational' => 'Вопрос / FAQ',
        'comparison' => 'Сравнение',
        'unsafe_or_unsupported' => 'Небезопасный запрос',
        'taxi_transfer' => 'Такси / трансфер',
        'car_sales' => 'Покупка или продажа авто',
        'repair_parts_service' => 'Ремонт / запчасти',
        'job_driver' => 'Работа / водитель',
        'commercial_use_not_supported' => 'Коммерческое использование',
        'carsharing' => 'Каршеринг',
        'driver_service_not_supported' => 'Авто с водителем',
        'unsupported_vehicle_type' => 'Неподдерживаемый транспорт',
        'irrelevant_rental_object' => 'Не аренда авто',
        'competitor_or_platform_query' => 'Площадка / конкурент',
        'generic_noise' => 'Нецелевой запрос',
        'unknown' => 'Нужно определить',
    ][$intent] ?? ($intent !== '' ? $intent : 'Нужно определить');
}

function demand_import_preview_decision_label(string $decisionHint): string
{
    return [
        'create_landing_page' => 'Можно готовить страницу',
        'improve_existing_page' => 'Улучшить существующую страницу',
        'create_faq' => 'Добавить FAQ',
        'add_condition_block' => 'Добавить блок условий',
        'create_car_card_hint' => 'Доработать карточку авто',
        'create_content_brief' => 'Создать ТЗ для страницы',
        'needs_business_decision' => 'Нужно решение владельца',
        'needs_human_review' => 'Разобрать вручную',
        'do_not_create_page' => 'Не создавать страницу',
        'ignore_as_irrelevant' => 'Не использовать для аренды авто',
        'maybe_use_as_negative_ad_keyword' => 'Не использовать для страниц аренды',
    ][$decisionHint] ?? ($decisionHint !== '' ? $decisionHint : 'Разобрать вручную');
}

function demand_import_preview_action_label(string $action): string
{
    return [
        'add' => 'Будет сохранено',
        'update' => 'Обновит существующую',
        'skip' => 'Пропущено как дубль',
    ][$action] ?? ($action !== '' ? $action : 'Будет проверено');
}

function demand_import_preview_has_risk(array $keyword): bool
{
    return !empty($keyword['riskFlags'])
        || !empty($keyword['mustNotPromise'])
        || !empty($keyword['isExcluded'])
        || in_array((string) ($keyword['decisionHint'] ?? ''), ['do_not_create_page', 'needs_business_decision', 'needs_human_review'], true);
}

function demand_import_preview_group_for_row(array $row): string
{
    $keyword = is_array($row['keyword'] ?? null) ? $row['keyword'] : [];
    $action = (string) ($row['action'] ?? '');
    if ($action === 'update' || $action === 'skip' || !empty($row['duplicateInBatch']) || trim((string) ($row['existingKeywordId'] ?? '')) !== '') {
        return 'duplicates';
    }

    $negativeIntent = trim((string) ($keyword['negativeIntent'] ?? ''));
    $decisionHint = trim((string) ($keyword['decisionHint'] ?? ''));
    $intent = trim((string) ($keyword['intent'] ?? ''));
    $riskFlags = array_map('strval', (array) ($keyword['riskFlags'] ?? []));

    if ($negativeIntent !== '') {
        if (in_array($negativeIntent, ['unsafe_legal_request', 'driver_service_not_supported', 'unsupported_vehicle_type'], true) || $decisionHint === 'do_not_create_page') {
            return 'no_page';
        }
        if ($negativeIntent === 'commercial_use_not_supported' || $decisionHint === 'needs_business_decision') {
            return 'review';
        }

        return 'irrelevant';
    }

    if (
        $decisionHint === 'do_not_create_page'
        || $intent === 'unsafe_or_unsupported'
        || !empty($keyword['isExcluded'])
        || (bool) array_intersect($riskFlags, ['possible_false_promise', 'condition_not_supported', 'unsupported_legal_request'])
    ) {
        return 'no_page';
    }

    if ($decisionHint === 'ignore_as_irrelevant' || $decisionHint === 'maybe_use_as_negative_ad_keyword') {
        return 'irrelevant';
    }

    if (
        $decisionHint === 'needs_business_decision'
        || $decisionHint === 'needs_human_review'
        || (bool) array_intersect($riskFlags, ['region_not_confirmed', 'unknown_region', 'airport_delivery_not_confirmed', 'driver_service_not_confirmed', 'needs_business_decision', 'needs_human_review'])
    ) {
        return 'review';
    }

    if (in_array($decisionHint, ['create_landing_page', 'improve_existing_page', 'create_faq', 'add_condition_block', 'create_car_card_hint', 'create_content_brief'], true)) {
        return 'usable';
    }

    return 'review';
}

function demand_import_preview_enrich_row(array $row): array
{
    $keyword = is_array($row['keyword'] ?? null) ? $row['keyword'] : [];
    $groupKey = demand_import_preview_group_for_row($row);
    $negativeIntent = trim((string) ($keyword['negativeIntent'] ?? ''));
    $intent = trim((string) ($keyword['intent'] ?? ''));
    $decisionHint = trim((string) ($keyword['decisionHint'] ?? ''));
    $row['groupKey'] = $groupKey;
    $row['intentLabel'] = demand_import_preview_intent_label($intent, $negativeIntent);
    $row['decisionLabel'] = demand_import_preview_decision_label($decisionHint);
    $row['actionLabel'] = demand_import_preview_action_label((string) ($row['action'] ?? ''));
    $row['hasRisk'] = demand_import_preview_has_risk($keyword);
    $row['adminExplanation'] = trim((string) ($keyword['adminExplanation'] ?? ''));
    if ($row['adminExplanation'] === '') {
        $row['adminExplanation'] = 'Фраза распознана частично. Перед созданием страницы лучше проверить смысл запроса.';
    }

    return $row;
}

function demand_import_preview_summary(array $rows, int $errorCount = 0): array
{
    $summary = [
        'total' => count($rows) + $errorCount,
        'usable' => 0,
        'review' => 0,
        'no_page' => 0,
        'irrelevant' => 0,
        'duplicates' => 0,
        'errors' => $errorCount,
    ];
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $groupKey = (string) ($row['groupKey'] ?? demand_import_preview_group_for_row($row));
        if (array_key_exists($groupKey, $summary)) {
            $summary[$groupKey]++;
        }
    }

    return $summary;
}

function demand_import_preview_rows_by_group(array $rows): array
{
    $groups = [
        'usable' => [],
        'review' => [],
        'no_page' => [],
        'irrelevant' => [],
        'duplicates' => [],
        'all' => [],
    ];
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $groupKey = (string) ($row['groupKey'] ?? demand_import_preview_group_for_row($row));
        if (!array_key_exists($groupKey, $groups) || $groupKey === 'all') {
            $groupKey = 'review';
        }
        $groups[$groupKey][] = $row;
        $groups['all'][] = $row;
    }

    return $groups;
}

function demand_preview_import_rows(array $rows): array
{
    $existingMap = demand_existing_keyword_map();
    $batchMap = [];
    $previewRows = [];
    $errors = [];
    foreach ($rows as $index => $row) {
        if (!is_array($row)) {
            $errors[] = 'Запись #' . ($index + 1) . ' пропущена: ожидался объект.';
            continue;
        }
        $keyword = demand_normalize_keyword_record($row, null);
        if ($keyword['phrase'] === '' || $keyword['normalizedPhrase'] === '') {
            $errors[] = 'Запись #' . ($index + 1) . ' пропущена: пустая фраза.';
            continue;
        }
        $key = demand_keyword_duplicate_key($keyword);
        $existing = $existingMap[$key] ?? null;
        $duplicateInBatch = isset($batchMap[$key]);
        $batchMap[$key] = true;
        $previewRows[] = demand_import_preview_enrich_row([
            'rowNumber' => $index + 1,
            'keyword' => $existing ? demand_normalize_keyword_record($keyword, $existing) : $keyword,
            'duplicateKey' => $key,
            'existingKeywordId' => is_array($existing) ? (string) ($existing['id'] ?? '') : '',
            'duplicateInBatch' => $duplicateInBatch,
            'action' => $duplicateInBatch ? 'skip' : ($existing ? 'update' : 'add'),
        ]);
    }

    $stats = [
        'add' => count(array_filter($previewRows, static fn(array $row): bool => $row['action'] === 'add')),
        'update' => count(array_filter($previewRows, static fn(array $row): bool => $row['action'] === 'update')),
        'skip' => count(array_filter($previewRows, static fn(array $row): bool => $row['action'] === 'skip')),
    ];

    return [
        'rows' => $previewRows,
        'errors' => $errors,
        'stats' => $stats,
        'summary' => demand_import_preview_summary($previewRows, count($errors)),
    ];
}

function demand_store_import_preview(array $preview, array $warnings = []): string
{
    $token = bin2hex(random_bytes(16));
    $_SESSION['demand_import_previews'][$token] = [
        'createdAt' => time(),
        'preview' => $preview,
        'warnings' => $warnings,
    ];

    return $token;
}

function demand_load_import_preview(string $token): array
{
    $preview = $_SESSION['demand_import_previews'][$token] ?? null;
    if (!is_array($preview) || (int) ($preview['createdAt'] ?? 0) < time() - 3600) {
        throw new RuntimeException('Предпросмотр импорта устарел. Загрузите файл заново.');
    }

    return $preview;
}

function demand_apply_import_preview(string $token): array
{
    if (!has_permission('demand.import')) {
        deny_scope_access();
    }

    $stored = demand_load_import_preview($token);
    $preview = is_array($stored['preview'] ?? null) ? $stored['preview'] : [];
    $rows = isset($preview['rows']) && is_array($preview['rows']) ? $preview['rows'] : [];
    $data = read_demand_keywords();
    $items = isset($data['items']) && is_array($data['items']) ? $data['items'] : [];
    $byKey = [];
    foreach ($items as $index => $item) {
        if (is_array($item)) {
            $byKey[demand_keyword_duplicate_key($item)] = $index;
        }
    }

    $result = ['added' => 0, 'updated' => 0, 'skipped' => 0, 'keywordIds' => []];
    foreach ($rows as $row) {
        if (!is_array($row) || ($row['action'] ?? '') === 'skip') {
            $result['skipped']++;
            continue;
        }
        $keyword = is_array($row['keyword'] ?? null) ? $row['keyword'] : [];
        $key = demand_keyword_duplicate_key($keyword);
        if (isset($byKey[$key])) {
            $items[$byKey[$key]] = demand_normalize_keyword_record($keyword, is_array($items[$byKey[$key]]) ? $items[$byKey[$key]] : null);
            $result['updated']++;
            $result['keywordIds'][] = (string) ($items[$byKey[$key]]['id'] ?? '');
        } else {
            $items[] = demand_normalize_keyword_record($keyword, null);
            $byKey[$key] = count($items) - 1;
            $result['added']++;
            $result['keywordIds'][] = (string) ($items[$byKey[$key]]['id'] ?? '');
        }
    }

    $data['items'] = $items;
    save_demand_keywords($data);

    foreach (array_unique(array_filter($result['keywordIds'])) as $keywordId) {
        demand_recalculate_keyword_recommendations($keywordId);
        analytics_record_event('demand_keyword_imported', [
            'scopeId' => demand_keyword_scope_id($keywordId),
            'entityType' => 'demand_keyword',
            'entityId' => $keywordId,
            'meta' => ['source' => 'admin_import'],
        ]);
    }

    audit_log('demand.import.applied', 'demand', 'keywords', 'Импортированы поисковые фразы', $result);

    return $result;
}

function demand_keyword_scope_id(string $keywordId): string
{
    foreach (read_demand_keywords()['items'] as $keyword) {
        if (is_array($keyword) && (string) ($keyword['id'] ?? '') === $keywordId) {
            return demand_normalize_scope_id((string) ($keyword['scope_id'] ?? 'rent_rk'));
        }
    }

    return 'rent_rk';
}

function demand_find_keyword(string $keywordId): ?array
{
    foreach (read_demand_keywords()['items'] as $keyword) {
        if (is_array($keyword) && (string) ($keyword['id'] ?? '') === $keywordId) {
            return $keyword;
        }
    }

    return null;
}

function demand_find_recommendation(string $recommendationId): ?array
{
    foreach (read_demand_recommendations()['items'] as $recommendation) {
        if (is_array($recommendation) && (string) ($recommendation['id'] ?? '') === $recommendationId) {
            return $recommendation;
        }
    }

    return null;
}

function demand_find_draft(string $draftId): ?array
{
    foreach (read_landing_page_drafts()['items'] as $draft) {
        if (is_array($draft) && (string) ($draft['id'] ?? '') === $draftId) {
            return $draft;
        }
    }

    return null;
}

function demand_scope_guard(array $item, string $permission = 'demand.view'): void
{
    if (!has_permission($permission)) {
        deny_scope_access();
    }
    $scopeId = demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk'));
    if (!in_array($scopeId, demand_visible_scope_ids_for_current_user(), true)) {
        deny_scope_access();
    }
}

function demand_active_cars_for_scope(string $scopeId): array
{
    $scopeId = demand_normalize_scope_id($scopeId);
    $cars = array_values(array_filter(read_cars(), static function (array $car) use ($scopeId): bool {
        if (car_is_archived($car) || !car_is_active_for_partners($car)) {
            return false;
        }
        if ($scopeId !== 'rent_rk') {
            return car_owner_scope_id($car) === $scopeId;
        }

        return car_owner_scope_id($car) === 'rent_rk'
            || (!empty($car['available_for_rent_rk_partners']) && scope_feature_enabled(car_owner_scope_id($car), 'show_in_rent_rk_showcase'));
    }));

    return $cars;
}

function demand_car_matches_class(array $car, ?string $class): bool
{
    if ($class === null || $class === '') {
        return true;
    }
    $text = demand_normalize_phrase(implode(' ', [
        (string) ($car['class'] ?? ''),
        (string) ($car['name'] ?? ''),
        (string) ($car['slug'] ?? ''),
    ]));
    $seats = (int) ($car['seats'] ?? 0);

    return match ($class) {
        'минивэн' => $seats >= 7 || str_contains($text, 'минивен') || str_contains($text, 'минивэн') || str_contains($text, '7 мест') || str_contains($text, 'семимест'),
        'кабриолет' => str_contains($text, 'кабриолет'),
        'кроссовер' => str_contains($text, 'кроссовер') || str_contains($text, 'внедорожник') || str_contains($text, 'джип'),
        'седан' => str_contains($text, 'седан'),
        'компакт' => str_contains($text, 'компакт'),
        'бизнес' => str_contains($text, 'бизнес') || str_contains($text, 'bmw') || str_contains($text, 'mercedes'),
        'эконом' => normalize_rate_price($car['price'] ?? null) !== null && (int) normalize_rate_price($car['price'] ?? null) <= 4500,
        'микроавтобус' => $seats >= 8 || str_contains($text, 'микроавтобус'),
        default => true,
    };
}

function demand_match_cars_for_keyword(array $keyword): array
{
    $scopeId = demand_normalize_scope_id((string) ($keyword['scope_id'] ?? 'rent_rk'));
    $class = (string) ($keyword['detectedCarClass'] ?? '');
    $cars = demand_active_cars_for_scope($scopeId);
    $matched = array_values(array_filter($cars, static fn(array $car): bool => demand_car_matches_class($car, $class !== '' ? $class : null)));

    if (!$matched && $class === '') {
        $matched = $cars;
    }

    return $matched;
}

function demand_car_has_price(array $car): bool
{
    $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
    $rate = $slug !== '' ? rate_for_car($slug, $car) : [];
    return normalize_rate_price($rate['base'] ?? null) !== null || normalize_rate_price($car['price'] ?? null) !== null;
}

function demand_car_deposit_state(array $car): string
{
    $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
    $deposit = $slug !== '' ? car_deposit_amount($slug, $car) : null;
    if ($deposit === null) {
        return 'unknown';
    }

    return $deposit > 0 ? 'has_deposit' : 'no_deposit';
}

function demand_existing_pages(): array
{
    $pages = [];
    foreach (['pages', 'routes'] as $dirName) {
        foreach (glob(PROJECT_ROOT . $dirName . '/*.html') ?: [] as $path) {
            $html = (string) file_get_contents($path);
            $title = '';
            if (preg_match('/<h1[^>]*>(.*?)<\/h1>/is', $html, $match)) {
                $title = trim(strip_tags($match[1]));
            } elseif (preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $match)) {
                $title = trim(strip_tags($match[1]));
            }
            $slug = basename($path, '.html');
            $pages[] = [
                'path' => str_replace('\\', '/', $dirName . '/' . basename($path)),
                'slug' => $slug,
                'title' => $title,
                'normalized' => demand_normalize_phrase($slug . ' ' . $title),
            ];
        }
    }

    return $pages;
}

function demand_slug_words(string $value): array
{
    $value = str_replace('-', ' ', demand_normalize_phrase($value));
    return array_values(array_unique(array_filter(explode(' ', $value), static function (string $word): bool {
        return function_exists('mb_strlen') ? mb_strlen($word, 'UTF-8') > 2 : strlen($word) > 2;
    })));
}

function demand_find_similar_pages(array $keyword): array
{
    $phrase = (string) ($keyword['normalizedPhrase'] ?? $keyword['phrase'] ?? '');
    $slug = demand_landing_slug_for_keyword($keyword);
    $phraseWords = demand_slug_words($phrase . ' ' . str_replace('-', ' ', $slug));
    $matches = [];
    foreach (demand_existing_pages() as $page) {
        $pageWords = demand_slug_words((string) $page['normalized']);
        $intersection = array_intersect($phraseWords, $pageWords);
        $ratio = $phraseWords ? count($intersection) / max(1, count($phraseWords)) : 0;
        if ($ratio >= 0.62 || (string) $page['slug'] === $slug) {
            $page['similarity'] = round($ratio, 2);
            $matches[] = $page;
        }
    }

    usort($matches, static fn(array $a, array $b): int => ($b['similarity'] <=> $a['similarity']));
    return array_slice($matches, 0, 4);
}

function demand_stage_b_clamp_score(int|float $value, int $min = 0, int $max = 100): int
{
    return max($min, min($max, (int) round($value)));
}

function demand_stage_b_risk_profile(array $riskFlags): array
{
    $flags = demand_unique_strings(array_map('strval', $riskFlags));
    $blockedFlags = ['not_relevant_for_car_rental', 'unsupported_legal_request', 'commercial_use_not_supported'];
    $highFlags = ['possible_false_promise', 'condition_not_supported', 'no_matching_cars'];
    $businessFlags = ['region_not_confirmed', 'unknown_region', 'airport_delivery_not_confirmed', 'driver_service_not_confirmed', 'needs_business_decision'];
    $mediumFlags = ['price_claim_risk', 'no_price_data', 'no_deposit_data', 'duplicate_intent', 'too_similar_to_existing_page', 'too_generic', 'needs_human_review'];

    $level = 'low';
    if (array_intersect($flags, $blockedFlags)) {
        $level = 'blocked';
    } elseif (array_intersect($flags, $highFlags)) {
        $level = 'high';
    } elseif (array_intersect($flags, $businessFlags) || array_intersect($flags, $mediumFlags)) {
        $level = 'medium';
    }

    $score = 0;
    foreach ($flags as $flag) {
        $score += match ($flag) {
            'not_relevant_for_car_rental', 'unsupported_legal_request', 'commercial_use_not_supported' => 45,
            'possible_false_promise', 'condition_not_supported' => 28,
            'no_matching_cars' => 22,
            'region_not_confirmed', 'unknown_region', 'airport_delivery_not_confirmed', 'driver_service_not_confirmed' => 16,
            'price_claim_risk', 'duplicate_intent', 'too_similar_to_existing_page' => 12,
            'no_price_data', 'no_deposit_data', 'too_generic', 'needs_human_review' => 8,
            'low_frequency' => 5,
            default => 4,
        };
    }
    $score = min(50, $score);

    $mustNotPromise = [];
    if (array_intersect($flags, ['possible_false_promise', 'condition_not_supported'])) {
        $mustNotPromise[] = 'Не обещать аренду без залога или особое условие, пока оно не подтверждено бизнесом.';
    }
    if (in_array('price_claim_risk', $flags, true)) {
        $mustNotPromise[] = 'Не обещать самую низкую цену, фиксированную цену или скидку без проверки тарифов.';
    }
    if (array_intersect($flags, ['airport_delivery_not_confirmed', 'region_not_confirmed', 'unknown_region'])) {
        $mustNotPromise[] = 'Не обещать подачу или выдачу в регионе без подтверждения условий менеджером.';
    }
    if (in_array('no_matching_cars', $flags, true)) {
        $mustNotPromise[] = 'Не обещать наличие подходящих авто, если они не найдены в публично доступном предложении.';
    }
    if (in_array('unsupported_legal_request', $flags, true)) {
        $mustNotPromise[] = 'Не обещать аренду без прав, паспорта, договора или других обязательных документов.';
    }

    $summary = match ($level) {
        'blocked' => 'Запрос заблокирован для посадочной страницы: есть неподдерживаемое или нецелевое условие.',
        'high' => 'Высокий риск ложного обещания или отсутствия предложения. Нужен безопасный ответ вместо страницы.',
        'medium' => 'Есть риск или неполные данные. Перед страницей нужна проверка условий, региона или карточек авто.',
        default => 'Критичных рисков не найдено, но факты всё равно нужно проверить перед публикацией.',
    };

    return [
        'level' => $level,
        'score' => $score,
        'flags' => $flags,
        'summary' => $summary,
        'mustNotPromise' => demand_unique_strings($mustNotPromise),
    ];
}

function demand_stage_b_supply_fit(array $cars, array $keyword = []): array
{
    if (!$cars) {
        return [
            'score' => 0,
            'status' => 'no_matching_cars',
            'summary' => 'Подходящие активные авто не найдены. Страницу лучше отложить до появления предложения.',
            'missing' => ['matching_cars'],
            'matchingCarCount' => 0,
        ];
    }

    $matchingCarCount = count($cars);
    $withPrice = array_values(array_filter($cars, static fn(array $car): bool => demand_car_has_price($car)));
    $withDeposit = array_values(array_filter($cars, static fn(array $car): bool => demand_car_deposit_state($car) !== 'unknown'));
    $withPhoto = array_values(array_filter($cars, static fn(array $car): bool => trim((string) ($car['image'] ?? '')) !== ''));
    $withText = array_values(array_filter($cars, static function (array $car): bool {
        return trim((string) ($car['description'] ?? $car['publicDescription'] ?? $car['shortDescription'] ?? '')) !== '';
    }));
    $publicVisible = array_values(array_filter($cars, static function (array $car): bool {
        return function_exists('car_visible_in_public_rent_rk_showcase') ? car_visible_in_public_rent_rk_showcase($car) : car_is_active_for_partners($car);
    }));

    $score = 6 + min(8, $matchingCarCount * 2);
    $score += count($withPrice) === $matchingCarCount ? 4 : ($withPrice ? 2 : 0);
    $score += count($withDeposit) === $matchingCarCount ? 4 : ($withDeposit ? 2 : 0);
    $score += count($withPhoto) === $matchingCarCount ? 3 : ($withPhoto ? 1 : 0);
    $score += count($withText) === $matchingCarCount ? 2 : ($withText ? 1 : 0);
    $score += $publicVisible ? 2 : 0;
    $score = min(25, $score);

    $missing = [];
    if (!$withPrice) {
        $missing[] = 'price';
    }
    if (!$withDeposit) {
        $missing[] = 'deposit';
    }
    if (!$withPhoto) {
        $missing[] = 'photo';
    }
    if (!$withText) {
        $missing[] = 'description';
    }
    if (!$publicVisible) {
        $missing[] = 'public_visibility';
    }

    $status = $score >= 20 ? 'good_supply_fit' : ($score >= 12 ? 'partial_supply_fit' : 'weak_supply_fit');
    $summary = $status === 'good_supply_fit'
        ? 'В автопарке есть подходящее предложение, карточки достаточно готовы для безопасной подготовки страницы.'
        : 'Подходящие авто есть, но нужно проверить данные карточек: ' . implode(', ', $missing ?: ['условия']);

    return [
        'score' => $score,
        'status' => $status,
        'summary' => $summary,
        'missing' => $missing,
        'matchingCarCount' => $matchingCarCount,
    ];
}

function demand_stage_b_page_fit(array $keyword, array $similarPages = [], ?array $drafts = null, ?bool $hasExistingPage = null): array
{
    $drafts = $drafts ?? read_landing_page_drafts()['items'];
    $slug = demand_landing_slug_for_keyword($keyword);
    $draftMatch = null;
    foreach ($drafts as $draft) {
        if (!is_array($draft)) {
            continue;
        }
        if ((string) ($draft['slug'] ?? '') === $slug && !in_array((string) ($draft['publishStatus'] ?? ''), ['archived', 'merged', 'rolled_back'], true)) {
            $draftMatch = $draft;
            break;
        }
    }

    $bestPage = $similarPages[0] ?? null;
    $bestSimilarity = is_array($bestPage) ? (float) ($bestPage['similarity'] ?? 0) : 0.0;
    $intent = (string) ($keyword['intent'] ?? '');
    $decisionHint = (string) ($keyword['decisionHint'] ?? '');

    if ($hasExistingPage === true && !$bestPage && !$draftMatch) {
        return [
            'score' => 10,
            'status' => 'page_exists_weak_fit',
            'summary' => 'Похожая страница или черновик уже есть, но качество соответствия нужно проверить вручную.',
            'duplicatePenalty' => 10,
            'matches' => [],
        ];
    }
    if (is_array($draftMatch)) {
        return [
            'score' => 8,
            'status' => 'draft_exists',
            'summary' => 'Под запрос уже есть черновик. Лучше улучшить его, а не создавать новый дубль.',
            'duplicatePenalty' => 8,
            'matches' => [['type' => 'draft', 'id' => (string) ($draftMatch['id'] ?? ''), 'slug' => (string) ($draftMatch['slug'] ?? '')]],
        ];
    }
    if (is_array($bestPage)) {
        $status = $bestSimilarity >= 0.75 ? 'page_exists_good_fit' : 'page_exists_weak_fit';
        return [
            'score' => $status === 'page_exists_good_fit' ? 14 : 9,
            'status' => $status,
            'summary' => $status === 'page_exists_good_fit'
                ? 'Есть страница похожего смысла. Новую страницу создавать не нужно, лучше улучшить существующую.'
                : 'Есть похожая страница, но она может не полностью отвечать на запрос. Нужна доработка или объединение.',
            'duplicatePenalty' => $status === 'page_exists_good_fit' ? 18 : 10,
            'matches' => [$bestPage],
        ];
    }
    if ($intent === 'informational' || $decisionHint === 'create_faq') {
        return [
            'score' => 10,
            'status' => 'faq_better_than_page',
            'summary' => 'Запрос лучше закрыть FAQ или блоком ответа, отдельная страница может быть слабой.',
            'duplicatePenalty' => 4,
            'matches' => [],
        ];
    }

    return [
        'score' => 12,
        'status' => 'no_page_found',
        'summary' => 'Под запрос не найдено отдельной страницы или черновика.',
        'duplicatePenalty' => 0,
        'matches' => [],
    ];
}

function demand_stage_b_content_gap(array $keyword, array $cars, array $pageFit, array $riskFlags): array
{
    $gaps = [];
    $intent = (string) ($keyword['intent'] ?? '');
    $category = (string) ($keyword['category'] ?? '');
    $normalized = (string) ($keyword['normalizedPhrase'] ?? '');
    $pageFitStatus = (string) ($pageFit['status'] ?? 'no_page_found');

    if ($pageFitStatus === 'no_page_found') {
        $gaps[] = 'Нет отдельной страницы или черновика под этот смысл.';
    } elseif ($pageFitStatus === 'page_exists_weak_fit') {
        $gaps[] = 'Похожая страница есть, но её соответствие запросу слабое.';
    } elseif ($pageFitStatus === 'draft_exists') {
        $gaps[] = 'Есть черновик, который нужно доработать вместо создания дубля.';
    }
    if (in_array($intent, ['informational', 'condition_rental', 'deposit_sensitive'], true) || $category === 'condition') {
        $gaps[] = 'Нужен FAQ или блок условий с прямым ответом.';
    }
    if (array_intersect($riskFlags, ['no_deposit_data', 'possible_false_promise'])) {
        $gaps[] = 'Нужно проверить и честно описать залог.';
    }
    if (array_intersect($riskFlags, ['price_claim_risk', 'no_price_data'])) {
        $gaps[] = 'Нужно проверить тарифы и не обещать самую низкую цену.';
    }
    if (array_intersect($riskFlags, ['airport_delivery_not_confirmed', 'region_not_confirmed', 'unknown_region'])) {
        $gaps[] = 'Нужно подтвердить регион, подачу или выдачу.';
    }
    if (!$cars) {
        $gaps[] = 'Нет подходящих авто для публичного предложения.';
    }
    if (str_contains($normalized, '7 ') || str_contains($normalized, 'минив') || str_contains($normalized, 'семей')) {
        $gaps[] = 'В карточках и тексте нужно явно раскрыть места, багаж и семейный сценарий.';
    }
    if (!$gaps) {
        $gaps[] = 'Крупных пробелов не найдено; перед публикацией всё равно нужна ручная проверка фактов.';
    }

    $score = min(25, 6 + count($gaps) * 4);
    if ($pageFitStatus === 'no_page_found') {
        $score = min(25, $score + 4);
    }
    if ($pageFitStatus === 'page_exists_good_fit') {
        $score = max(4, $score - 8);
    }

    return [
        'score' => $score,
        'gaps' => demand_unique_strings($gaps),
        'summary' => implode(' ', array_slice(demand_unique_strings($gaps), 0, 3)),
    ];
}

function demand_stage_b_volume_score(array $keyword, array $context = []): int
{
    $frequency = max(0, (int) ($keyword['frequency30d'] ?? 0), (int) ($keyword['frequency'] ?? 0));
    $clusterKeywordCount = max(1, (int) ($context['clusterKeywordCount'] ?? 1));
    $hasRegion = trim((string) ($keyword['detectedCity'] ?? $keyword['detectedRegion'] ?? $keyword['regionName'] ?? '')) !== '';
    $score = $frequency > 0 ? min(22, log($frequency + 1, 1.65)) : 4;
    $score += min(5, $clusterKeywordCount);
    $score += $hasRegion ? 3 : 0;
    if ($frequency > 0 && $frequency < 10 && in_array((string) ($keyword['intent'] ?? ''), ['city_rental', 'car_class_rental', 'driverless'], true)) {
        $score += 4;
    }

    return demand_stage_b_clamp_score($score, 0, 30);
}

function demand_stage_b_commercial_score(array $keyword): int
{
    $intent = (string) ($keyword['intent'] ?? '');
    $features = is_array($keyword['features'] ?? null) ? $keyword['features'] : [];
    $score = 0;
    if (!empty($features['isCommercial'])) {
        $score += 5;
    }
    if (in_array($intent, ['city_rental', 'region_rental', 'car_class_rental', 'driverless'], true)) {
        $score += 8;
    } elseif (in_array($intent, ['price_sensitive', 'airport_delivery', 'family_trip'], true)) {
        $score += 7;
    } elseif (in_array($intent, ['condition_rental', 'comparison'], true)) {
        $score += 4;
    } elseif ($intent === 'informational') {
        $score += 2;
    }
    foreach (['detectedCity', 'detectedRegion', 'detectedCarClass', 'detectedDuration', 'detectedPriceModifier'] as $field) {
        if (trim((string) ($keyword[$field] ?? '')) !== '') {
            $score += 2;
        }
    }
    if (!empty($keyword['negativeIntent']) || !empty($keyword['isExcluded'])) {
        $score = 0;
    }
    if (in_array('too_generic', (array) ($keyword['riskFlags'] ?? []), true)) {
        $score -= 4;
    }

    return demand_stage_b_clamp_score($score, 0, 22);
}

function demand_stage_b_region_fit_score(array $keyword, array $riskFlags): int
{
    if (array_intersect($riskFlags, ['region_not_confirmed', 'unknown_region', 'needs_business_decision'])) {
        return 4;
    }
    $region = trim((string) ($keyword['detectedCity'] ?? $keyword['detectedRegion'] ?? $keyword['regionName'] ?? ''));
    if ($region === '') {
        return 8;
    }
    if (function_exists('demand_region_is_priority') && demand_region_is_priority($region)) {
        return 14;
    }

    return 6;
}

function demand_stage_b_priority_level(int $decisionScore, array $riskProfile, array $riskFlags): string
{
    if (($riskProfile['level'] ?? '') === 'blocked') {
        return 'blocked';
    }
    if (($riskProfile['level'] ?? '') === 'high' && array_intersect($riskFlags, ['possible_false_promise', 'condition_not_supported'])) {
        return 'blocked';
    }
    if (array_intersect($riskFlags, ['region_not_confirmed', 'unknown_region', 'needs_business_decision', 'airport_delivery_not_confirmed', 'driver_service_not_confirmed'])) {
        return 'needs_business_decision';
    }
    if ($decisionScore >= 68) {
        return 'high';
    }
    if ($decisionScore >= 42) {
        return 'medium';
    }

    return 'low';
}

function demand_stage_b_recommended_decision(array $keyword, array $riskProfile, array $supplyFit, array $pageFit, array $contentGap, string $priorityLevel): string
{
    $riskFlags = (array) ($riskProfile['flags'] ?? []);
    $intent = (string) ($keyword['intent'] ?? '');
    $decisionHint = (string) ($keyword['decisionHint'] ?? '');
    $pageFitStatus = (string) ($pageFit['status'] ?? '');
    $supplyStatus = (string) ($supplyFit['status'] ?? '');

    if (!empty($keyword['isExcluded']) || trim((string) ($keyword['negativeIntent'] ?? '')) !== '' || in_array('not_relevant_for_car_rental', $riskFlags, true)) {
        return in_array('unsupported_legal_request', $riskFlags, true) ? 'do_not_create_page' : 'ignore_as_irrelevant';
    }
    if (($riskProfile['level'] ?? '') === 'blocked' && in_array('unsupported_legal_request', $riskFlags, true)) {
        return 'do_not_create_page';
    }
    if (array_intersect($riskFlags, ['possible_false_promise', 'condition_not_supported'])) {
        return $intent === 'deposit_sensitive' ? 'create_faq' : 'add_condition_block';
    }
    if (array_intersect($riskFlags, ['region_not_confirmed', 'unknown_region', 'airport_delivery_not_confirmed', 'driver_service_not_confirmed', 'needs_business_decision'])) {
        return 'needs_business_decision';
    }
    if ($supplyStatus === 'no_matching_cars' || in_array('no_matching_cars', $riskFlags, true)) {
        return 'postpone_until_supply_exists';
    }
    if ($pageFitStatus === 'page_exists_good_fit') {
        return 'improve_existing_page';
    }
    if ($pageFitStatus === 'page_exists_weak_fit' || $pageFitStatus === 'draft_exists') {
        return 'merge_with_existing_page';
    }
    if ($pageFitStatus === 'faq_better_than_page' || $intent === 'informational' || $decisionHint === 'create_faq') {
        return 'create_faq';
    }
    if ($decisionHint === 'add_condition_block' || in_array('price_claim_risk', $riskFlags, true)) {
        return 'add_condition_block';
    }
    if ($pageFitStatus !== 'no_page_found' && $intent === 'car_class_rental' && (int) ($supplyFit['score'] ?? 0) >= 10 && in_array('description', (array) ($supplyFit['missing'] ?? []), true)) {
        return 'create_car_card_hint';
    }
    if ($priorityLevel === 'high' || $priorityLevel === 'medium') {
        return 'create_landing_page';
    }

    return $decisionHint === 'create_content_brief' ? 'create_content_brief' : 'needs_human_review';
}

function demand_stage_b_explanation(array $keyword, array $score): string
{
    $priority = (string) ($score['priorityLevel'] ?? 'low');
    $decision = (string) ($score['recommendedDecision'] ?? 'needs_human_review');
    $supply = (string) ($score['supplyFitSummary'] ?? '');
    $page = (string) ($score['pageFitSummary'] ?? '');
    $gap = (string) ($score['contentGapSummary'] ?? '');

    if ($priority === 'blocked') {
        return 'Не создавать страницу: запрос содержит неподдерживаемое условие или риск ложного обещания. Безопаснее дать FAQ/объяснение либо не использовать запрос.';
    }
    if ($priority === 'needs_business_decision') {
        return 'Нужно решение: спрос есть, но регион, подача, услуга или наличие предложения требуют ручного подтверждения.';
    }
    if ($decision === 'improve_existing_page' || $decision === 'merge_with_existing_page') {
        return 'Похожая страница уже есть. Лучше улучшить существующий материал, добавить ответы и внутренние ссылки, а не создавать дубль.';
    }
    if ($decision === 'create_faq' || $decision === 'add_condition_block') {
        return 'Запрос полезен, но безопаснее закрыть его FAQ или блоком условий: ' . $gap;
    }
    if ($priority === 'high') {
        return 'Высокий приоритет: есть спрос, предложение в автопарке и понятный следующий шаг. ' . trim($supply . ' ' . $page);
    }
    if ($priority === 'medium') {
        return 'Средний приоритет: запрос полезный, но сначала стоит закрыть пробелы в данных или контенте. ' . $gap;
    }

    return 'Низкий приоритет: запрос можно сохранить для анализа, но лучше не начинать отдельную страницу без дополнительных данных.';
}

function demand_stage_b_score_keyword(array $keyword, array $context = []): array
{
    $cars = is_array($context['cars'] ?? null) ? (array) $context['cars'] : demand_match_cars_for_keyword($keyword);
    $similarPages = is_array($context['similarPages'] ?? null) ? (array) $context['similarPages'] : demand_find_similar_pages($keyword);
    $riskFlags = demand_unique_strings(array_merge((array) ($keyword['riskFlags'] ?? []), (array) ($context['riskFlags'] ?? [])));
    $normalizedPhrase = (string) ($keyword['normalizedPhrase'] ?? demand_normalize_phrase((string) ($keyword['phrase'] ?? '')));
    $detectedCondition = (string) ($keyword['detectedCondition'] ?? '');
    $intent = (string) ($keyword['intent'] ?? '');
    $decisionHint = (string) ($keyword['decisionHint'] ?? '');
    if ($intent === 'deposit_sensitive' || $detectedCondition === 'без залога' || str_contains($normalizedPhrase, 'без залога')) {
        $riskFlags[] = 'possible_false_promise';
        $riskFlags[] = 'condition_not_supported';
        $riskFlags[] = 'needs_human_review';
    }
    if ($decisionHint === 'do_not_create_page' && trim((string) ($keyword['negativeIntent'] ?? '')) === '' && !in_array('unsupported_legal_request', $riskFlags, true)) {
        $riskFlags[] = 'possible_false_promise';
        $riskFlags[] = 'condition_not_supported';
    }
    if (str_contains($normalizedPhrase, 'дешев') || str_contains($normalizedPhrase, 'недорог')) {
        $riskFlags[] = 'price_claim_risk';
        $riskFlags[] = 'needs_human_review';
    }
    if (!$cars && empty($keyword['isExcluded']) && trim((string) ($keyword['negativeIntent'] ?? '')) === '') {
        $riskFlags[] = 'no_matching_cars';
    }
    if ($similarPages) {
        $riskFlags[] = 'duplicate_intent';
        $riskFlags[] = 'too_similar_to_existing_page';
    }
    $riskFlags = demand_unique_strings($riskFlags);

    $keywordForScoring = $keyword;
    $keywordForScoring['riskFlags'] = $riskFlags;
    $riskProfile = demand_stage_b_risk_profile($riskFlags);
    $supplyFit = demand_stage_b_supply_fit($cars, $keywordForScoring);
    $pageFit = demand_stage_b_page_fit(
        $keywordForScoring,
        $similarPages,
        is_array($context['drafts'] ?? null) ? (array) $context['drafts'] : null,
        isset($context['hasExistingPage']) ? (bool) $context['hasExistingPage'] : null
    );
    $contentGap = demand_stage_b_content_gap($keywordForScoring, $cars, $pageFit, $riskFlags);

    $demandVolumeScore = demand_stage_b_volume_score($keywordForScoring, $context);
    $commercialScore = demand_stage_b_commercial_score($keywordForScoring);
    $regionFitScore = demand_stage_b_region_fit_score($keywordForScoring, $riskFlags);
    $seasonalityScore = isset($context['seasonalityScore']) ? demand_stage_b_clamp_score((int) $context['seasonalityScore'], 0, 10) : 5;
    $duplicatePenalty = (int) ($pageFit['duplicatePenalty'] ?? 0);
    $thinContentPenalty = in_array('too_generic', $riskFlags, true) ? 10 : 0;
    if ((string) ($pageFit['status'] ?? '') === 'faq_better_than_page') {
        $thinContentPenalty += 6;
    }

    $decisionScore = demand_stage_b_clamp_score(
        $demandVolumeScore
        + $commercialScore
        + (int) $supplyFit['score']
        + (int) $pageFit['score']
        + (int) $contentGap['score']
        + $regionFitScore
        + $seasonalityScore
        - (int) $riskProfile['score']
        - $duplicatePenalty
        - $thinContentPenalty
    );
    $priorityLevel = demand_stage_b_priority_level($decisionScore, $riskProfile, $riskFlags);
    $recommendedDecision = demand_stage_b_recommended_decision($keywordForScoring, $riskProfile, $supplyFit, $pageFit, $contentGap, $priorityLevel);

    $score = [
        'demandVolumeScore' => $demandVolumeScore,
        'commercialScore' => $commercialScore,
        'supplyFitScore' => (int) $supplyFit['score'],
        'pageFitScore' => (int) $pageFit['score'],
        'contentGapScore' => (int) $contentGap['score'],
        'riskScore' => (int) $riskProfile['score'],
        'regionFitScore' => $regionFitScore,
        'seasonalityScore' => $seasonalityScore,
        'decisionScore' => $decisionScore,
        'priorityLevel' => $priorityLevel,
        'recommendedDecision' => $recommendedDecision,
        'pageFitStatus' => (string) ($pageFit['status'] ?? ''),
        'pageFitSummary' => (string) ($pageFit['summary'] ?? ''),
        'supplyFitStatus' => (string) ($supplyFit['status'] ?? ''),
        'supplyFitSummary' => (string) ($supplyFit['summary'] ?? ''),
        'contentGapSummary' => (string) ($contentGap['summary'] ?? ''),
        'contentGaps' => (array) ($contentGap['gaps'] ?? []),
        'pageRiskProfile' => $riskProfile,
        'riskFlags' => $riskFlags,
        'duplicatePenalty' => $duplicatePenalty,
        'thinContentPenalty' => $thinContentPenalty,
        'whatBlocks' => array_values(array_unique(array_merge((array) ($supplyFit['missing'] ?? []), (array) ($contentGap['gaps'] ?? [])))),
    ];
    $score['scoringExplanation'] = demand_stage_b_explanation($keywordForScoring, $score);

    return $score;
}

function demand_stage_c_is_excluded(array $keyword): bool
{
    return !empty($keyword['isExcluded'])
        || trim((string) ($keyword['negativeIntent'] ?? '')) !== ''
        || (string) ($keyword['status'] ?? 'active') === 'excluded'
        || in_array('not_relevant_for_car_rental', (array) ($keyword['riskFlags'] ?? []), true);
}

function demand_stage_c_detect_intents(array $keyword): array
{
    $normalized = (string) ($keyword['normalizedPhrase'] ?? demand_normalize_phrase((string) ($keyword['phrase'] ?? '')));
    $intents = array_values(array_filter(array_merge(
        [(string) ($keyword['intent'] ?? '')],
        (array) ($keyword['secondaryIntents'] ?? [])
    ), static fn(string $value): bool => $value !== ''));

    if ((string) ($keyword['detectedCarClass'] ?? '') === 'минивэн' || str_contains($normalized, '7 мест') || str_contains($normalized, 'семимест') || str_contains($normalized, 'семей')) {
        $intents[] = 'family_trip';
        $intents[] = 'luggage_and_seats';
    }
    if ((string) ($keyword['detectedCarClass'] ?? '') === 'кабриолет' || str_contains($normalized, 'кабриолет')) {
        $intents[] = 'cabriolet';
    }
    if (str_contains($normalized, 'аэропорт') || str_contains($normalized, 'подач')) {
        $intents[] = 'airport_delivery';
    }
    if (str_contains($normalized, 'без залога')) {
        $intents[] = 'deposit_sensitive';
    }
    if (str_contains($normalized, 'дешев') || str_contains($normalized, 'недорог') || str_contains($normalized, 'цена') || str_contains($normalized, 'стоимость')) {
        $intents[] = 'price_sensitive';
    }
    if (str_contains($normalized, 'без водителя')) {
        $intents[] = 'driverless';
    }
    if (str_contains($normalized, 'на неделю') || str_contains($normalized, 'недел')) {
        $intents[] = 'weekly_rental';
    }

    return demand_unique_strings($intents);
}

function demand_stage_c_add_question(array &$questions, string $question, string $intent, string $priority = 'medium'): void
{
    $question = demand_clean_string($question, 260);
    if ($question === '') {
        return;
    }
    $key = demand_lower($question);
    $questions[$key] = [
        'question' => $question,
        'sourceIntent' => $intent,
        'priority' => $priority,
    ];
}

function demand_stage_c_user_question_map(array $keyword): array
{
    if (demand_stage_c_is_excluded($keyword)) {
        return [];
    }

    $questions = [];
    $intents = demand_stage_c_detect_intents($keyword);
    foreach ($intents as $intent) {
        match ($intent) {
            'city_rental', 'region_rental' => (function () use (&$questions, $intent): void {
                demand_stage_c_add_question($questions, 'Где можно получить автомобиль?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Какие автомобили доступны под этот запрос?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Какие документы нужны для аренды?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Как считается цена?', $intent, 'medium');
                demand_stage_c_add_question($questions, 'Какой залог и когда он возвращается?', $intent, 'high');
            })(),
            'car_class_rental' => (function () use (&$questions, $intent): void {
                demand_stage_c_add_question($questions, 'Кому подходит этот класс автомобиля?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Какие авто доступны?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Сколько мест и хватит ли места для багажа?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Какая цена и какой залог?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Какие есть альтернативы, если нужного авто нет?', $intent, 'medium');
            })(),
            'family_trip', 'luggage_and_seats' => (function () use (&$questions, $intent): void {
                demand_stage_c_add_question($questions, 'Сколько мест в автомобиле?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Хватит ли места для багажа?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Можно ли добавить детское кресло?', $intent, 'medium');
                demand_stage_c_add_question($questions, 'Подойдёт ли машина для поездок по Крыму?', $intent, 'medium');
                demand_stage_c_add_question($questions, 'Какой залог?', $intent, 'high');
            })(),
            'airport_delivery' => (function () use (&$questions, $intent): void {
                demand_stage_c_add_question($questions, 'Можно ли получить авто в аэропорту?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Где происходит встреча?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Можно ли вернуть авто в аэропорту?', $intent, 'medium');
                demand_stage_c_add_question($questions, 'Нужно ли согласовывать подачу заранее?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Есть ли доплата за подачу?', $intent, 'medium');
            })(),
            'deposit_sensitive' => (function () use (&$questions, $intent): void {
                demand_stage_c_add_question($questions, 'От чего зависит размер залога?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Когда возвращается залог?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Можно ли уменьшить залог?', $intent, 'medium');
                demand_stage_c_add_question($questions, 'Почему у разных авто разный залог?', $intent, 'medium');
            })(),
            'price_sensitive' => (function () use (&$questions, $intent): void {
                demand_stage_c_add_question($questions, 'От чего зависит цена?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Есть ли экономичные варианты?', $intent, 'medium');
                demand_stage_c_add_question($questions, 'Как считается аренда на неделю?', $intent, 'medium');
                demand_stage_c_add_question($questions, 'Что входит в стоимость?', $intent, 'high');
            })(),
            'driverless' => (function () use (&$questions, $intent): void {
                demand_stage_c_add_question($questions, 'Какие документы нужны?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Требуется ли стаж?', $intent, 'medium');
                demand_stage_c_add_question($questions, 'Кто может управлять авто?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Можно ли ездить по Крыму самостоятельно?', $intent, 'medium');
            })(),
            'cabriolet' => (function () use (&$questions, $intent): void {
                demand_stage_c_add_question($questions, 'Когда лучше бронировать кабриолет?', $intent, 'medium');
                demand_stage_c_add_question($questions, 'Для каких поездок он подходит?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Что важно учитывать в сезон?', $intent, 'medium');
                demand_stage_c_add_question($questions, 'Есть ли ограничения по погоде или условиям?', $intent, 'medium');
            })(),
            'weekly_rental' => (function () use (&$questions, $intent): void {
                demand_stage_c_add_question($questions, 'Как считается аренда на неделю?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Что входит в недельную аренду?', $intent, 'medium');
                demand_stage_c_add_question($questions, 'Какой залог и когда он возвращается?', $intent, 'high');
            })(),
            'informational' => (function () use (&$questions, $intent): void {
                demand_stage_c_add_question($questions, 'Что нужно для аренды автомобиля?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Какие документы и условия нужно проверить?', $intent, 'high');
                demand_stage_c_add_question($questions, 'Что уточнить у менеджера перед бронированием?', $intent, 'medium');
            })(),
            default => null,
        };
    }

    if (!$questions) {
        demand_stage_c_add_question($questions, 'Какой автомобиль и условия подойдут под этот запрос?', 'general', 'medium');
        demand_stage_c_add_question($questions, 'Что нужно уточнить перед бронированием?', 'general', 'medium');
    }

    return array_values($questions);
}

function demand_stage_c_block(string $type, string $title, string $why, string $template, array $facts = [], array $forbidden = [], array $intents = [], string $priority = 'medium'): array
{
    return [
        'type' => $type,
        'visibility' => 'admin_only',
        'title' => $title,
        'whyNeeded' => $why,
        'suggestedTextTemplate' => $template,
        'requiredFacts' => demand_unique_strings($facts),
        'forbiddenPromises' => demand_unique_strings($forbidden),
        'linkedIntents' => demand_unique_strings($intents),
        'priority' => $priority,
    ];
}

function demand_stage_c_safe_content_blocks(array $keyword, array $stageB = []): array
{
    if (demand_stage_c_is_excluded($keyword)) {
        return [];
    }

    $intents = demand_stage_c_detect_intents($keyword);
    $riskFlags = demand_unique_strings(array_merge((array) ($keyword['riskFlags'] ?? []), (array) ($stageB['riskFlags'] ?? [])));
    $blocks = [];
    $add = static function (array $block) use (&$blocks): void {
        $type = (string) ($block['type'] ?? '');
        if ($type === '' || isset($blocks[$type])) {
            return;
        }
        $blocks[$type] = $block;
    };

    if (array_intersect($riskFlags, ['possible_false_promise', 'condition_not_supported', 'unsupported_legal_request'])) {
        $add(demand_stage_c_block(
            'not_supported_explanation',
            'Безопасное объяснение ограничения',
            'Запрос может создать ложное ожидание, поэтому нужен не продающий блок, а честное объяснение.',
            'Объяснить, что условие нельзя обещать без подтверждения. Если данных нет, написать, что условия уточняются менеджером.',
            ['подтверждённые условия аренды', 'правила по документам и залогу'],
            ['без залога', 'без прав', 'без паспорта', 'без договора'],
            ['deposit_sensitive', 'unsafe_or_unsupported'],
            'high'
        ));
    } else {
        $add(demand_stage_c_block(
            'intro_answer',
            'Короткий прямой ответ',
            'Пользователь должен сразу понять, подходит ли предложение под его сценарий.',
            'Коротко ответить на запрос, назвать сценарий и указать, что цена, залог, подача и наличие подтверждаются перед бронированием.',
            ['основной запрос', 'подтверждённые авто', 'город или регион'],
            ['наличие авто без проверки', 'фиксированная цена без тарифа'],
            ['city_rental', 'region_rental', 'car_class_rental'],
            'high'
        ));
    }

    if (!array_intersect($riskFlags, ['unsupported_legal_request', 'not_relevant_for_car_rental'])) {
        $add(demand_stage_c_block(
            'available_cars',
            'Подходящие авто',
            'Страница должна опираться на реальное предложение, а не только на ключевую фразу.',
            'Показать только связанные авто и объяснить, какие характеристики важны для запроса. Если авто не подтверждены, оставить задачу на ручную проверку.',
            ['публичные авто', 'класс/кузов', 'места', 'фото'],
            ['наличие конкретного авто без проверки'],
            ['car_class_rental', 'city_rental', 'family_trip'],
            'high'
        ));
        $add(demand_stage_c_block(
            'conditions',
            'Условия аренды',
            'Без условий страница не отвечает на главный страх пользователя.',
            'Перечислить документы, стаж, порядок оформления, ограничения и что менеджер подтверждает перед поездкой.',
            ['документы', 'стаж', 'условия оформления'],
            ['аренда без документов', 'аренда без договора'],
            ['driverless', 'condition_rental'],
            'high'
        ));
    }

    if (in_array('deposit_sensitive', $intents, true) || in_array('possible_false_promise', $riskFlags, true) || in_array('no_deposit_data', $riskFlags, true)) {
        $add(demand_stage_c_block(
            'deposit_explanation',
            'Как работает залог',
            'Запрос про залог опасен для ложных обещаний и должен закрываться фактами.',
            'Объяснить, от чего зависит залог, когда он возвращается и что отсутствие данных означает ручное уточнение.',
            ['залог по авто', 'правила возврата залога'],
            ['без залога без подтверждения'],
            ['deposit_sensitive'],
            'high'
        ));
    }
    if (in_array('price_sensitive', $intents, true) || in_array('price_claim_risk', $riskFlags, true) || in_array('no_price_data', $riskFlags, true)) {
        $add(demand_stage_c_block(
            'price_explanation',
            'Как считается цена',
            'Цена влияет на заявку, но нельзя обещать самую низкую стоимость.',
            'Объяснить, что итог зависит от дат, автомобиля, срока аренды и условий. Можно упомянуть экономичные варианты только как проверяемый выбор.',
            ['публичная цена', 'срок аренды', 'тарифные условия'],
            ['самая низкая цена', 'фиксированная цена без проверки'],
            ['price_sensitive', 'weekly_rental'],
            'high'
        ));
    }
    if (in_array('airport_delivery', $intents, true) || in_array('airport_delivery_not_confirmed', $riskFlags, true)) {
        $add(demand_stage_c_block(
            'airport_pickup',
            'Получение в аэропорту',
            'Пользователь ищет конкретное место получения, но подачу нельзя обещать без подтверждения.',
            'Описать аэропорт только как условие, которое согласуется заранее: время, место встречи, возврат и возможная доплата подтверждаются менеджером.',
            ['подтверждение подачи', 'место встречи', 'условия возврата'],
            ['подача в аэропорт без подтверждения', 'бесплатная подача без фактов'],
            ['airport_delivery'],
            'high'
        ));
    } elseif (array_intersect($intents, ['city_rental', 'region_rental'])) {
        $add(demand_stage_c_block(
            'pickup_delivery',
            'Получение и подача',
            'Для городской страницы важно объяснить, где реально можно получить авто.',
            'Описать подтверждённые варианты получения и указать, что подача согласуется заранее.',
            ['город/регион выдачи', 'условия подачи'],
            ['подача без подтверждения'],
            ['city_rental', 'region_rental'],
            'medium'
        ));
    }
    if (array_intersect($intents, ['family_trip', 'luggage_and_seats'])) {
        $add(demand_stage_c_block(
            'family_use',
            'Семья или компания',
            'Семейный сценарий требует не только класса авто, но и понятного объяснения удобства.',
            'Объяснить, кому подойдёт автомобиль, сколько людей едет, что нужно проверить по детскому креслу и багажу.',
            ['количество мест', 'багаж', 'детское кресло'],
            ['детское кресло без подтверждения'],
            ['family_trip'],
            'high'
        ));
        $add(demand_stage_c_block(
            'luggage_and_seats',
            'Места и багаж',
            'Запросы про 7 мест и минивэн требуют раскрыть вместимость.',
            'Показать количество мест и написать, что багаж/кресло нужно сверить по конкретному автомобилю.',
            ['места', 'багажник', 'фото салона'],
            ['точная вместимость без данных авто'],
            ['family_trip', 'car_class_rental'],
            'high'
        ));
    }
    if (in_array('weekly_rental', $intents, true)) {
        $add(demand_stage_c_block(
            'weekly_rental',
            'Аренда на неделю',
            'Срок аренды меняет ожидания по цене, залогу и условиям.',
            'Объяснить, как считается недельная аренда и какие условия нужно подтвердить.',
            ['срок аренды', 'тариф', 'залог'],
            ['скидка на неделю без подтверждения'],
            ['weekly_rental', 'price_sensitive'],
            'medium'
        ));
    }
    if (in_array('cabriolet', $intents, true)) {
        $add(demand_stage_c_block(
            'who_is_it_for',
            'Для каких поездок подходит',
            'Кабриолетный спрос зависит от сценария и сезона, поэтому нужен конкретный, а не общий рекламный текст.',
            'Объяснить, для каких поездок подходит кабриолет, что доступность зависит от сезона и что условия нужно проверить перед бронированием.',
            ['класс авто', 'сезон', 'доступность'],
            ['наличие кабриолета без проверки', 'идеальная погода или доступность всегда'],
            ['cabriolet'],
            'medium'
        ));
        $add(demand_stage_c_block(
            'safety_limitations',
            'Сезон и ограничения',
            'Для кабриолета важно заранее объяснить сезонность, погоду и ограничения без пустой рекламы.',
            'Указать, что сезон, погода, доступность и условия аренды проверяются перед поездкой.',
            ['сезон', 'погода', 'условия аренды'],
            ['безусловная доступность в любой день'],
            ['cabriolet'],
            'medium'
        ));
    }
    if (in_array('route_trip', $intents, true)) {
        $add(demand_stage_c_block(
            'route_use',
            'Поездки по маршруту',
            'Маршрутный сценарий требует объяснить ограничения и возврат.',
            'Описать, что маршрут, место возврата и ограничения согласуются заранее.',
            ['маршрут', 'возврат', 'ограничения'],
            ['любой маршрут без ограничений'],
            ['route_trip'],
            'medium'
        ));
    }
    if (in_array('comparison', $intents, true)) {
        $add(demand_stage_c_block(
            'comparison',
            'Как выбрать вариант',
            'Пользователь сравнивает, значит странице нужен критерий выбора.',
            'Сравнить классы или сценарии по вместимости, цене, залогу и условиям без обещания лучшего варианта для всех.',
            ['классы авто', 'цена', 'залог', 'сценарий'],
            ['лучший вариант без контекста'],
            ['comparison'],
            'medium'
        ));
    }

    $add(demand_stage_c_block(
        'faq',
        'FAQ',
        'FAQ закрывает рискованные и уточняющие вопросы без создания лишних страниц.',
        'Добавить вопросы по документам, залогу, цене, подаче, доступности и ограничениям.',
        ['условия', 'риски', 'частые вопросы'],
        ['неподтверждённые обещания'],
        $intents,
        'high'
    ));
    $add(demand_stage_c_block(
        'internal_links',
        'Внутренние связи',
        'Страница должна помогать перейти к классу авто, городу, условиям или карточкам.',
        'Добавить только рекомендации для ссылок; реальные URL создавать вручную, если целевая страница существует.',
        ['существующие страницы', 'карточки авто', 'категории'],
        ['создание несуществующих ссылок как факта'],
        $intents,
        'medium'
    ));
    $add(demand_stage_c_block(
        'what_to_confirm_before_booking',
        'Что уточнить перед бронированием',
        'Этот блок снижает риск ложных обещаний и помогает менеджеру.',
        'Списком указать, что нужно подтвердить: наличие авто, цену, залог, подачу, документы и дополнительные опции.',
        ['наличие', 'цена', 'залог', 'подача', 'документы'],
        ['гарантия без проверки'],
        $intents,
        'high'
    ));

    return array_values($blocks);
}

function demand_stage_c_must_answer(array $keyword): array
{
    if (demand_stage_c_is_excluded($keyword)) {
        return ['Почему запрос не подходит для посадочной страницы Rent RK.'];
    }

    $answers = [];
    foreach (demand_stage_c_detect_intents($keyword) as $intent) {
        $answers = array_merge($answers, match ($intent) {
            'city_rental', 'region_rental' => ['где можно получить авто', 'какие авто доступны', 'какие документы нужны', 'как считается цена', 'какой залог', 'можно ли подать авто по городу или региону'],
            'car_class_rental' => ['кому подходит класс', 'какие авто доступны', 'сколько мест и багажа', 'цена и залог', 'ограничения', 'альтернативы'],
            'airport_delivery' => ['подтверждена ли подача', 'где встреча', 'сроки и время', 'возврат', 'доплата, если есть', 'что согласовать заранее'],
            'deposit_sensitive' => ['от чего зависит залог', 'как возвращается залог', 'когда залог может удерживаться', 'можно ли уменьшить залог', 'почему нельзя обещать без залога без подтверждения'],
            'price_sensitive' => ['от чего зависит цена', 'какие есть экономичные варианты', 'как считается срок аренды', 'что входит в стоимость'],
            'driverless' => ['какие документы нужны', 'требуется ли стаж', 'кто может управлять авто', 'можно ли ездить самостоятельно'],
            'family_trip', 'luggage_and_seats' => ['сколько мест', 'хватит ли места для багажа', 'есть ли детское кресло', 'какие авто подходят семье', 'какой залог'],
            'cabriolet' => ['когда лучше бронировать', 'для каких поездок подходит', 'что учитывать в сезон', 'какие есть ограничения'],
            'weekly_rental' => ['как считается недельная аренда', 'что входит в стоимость', 'какой залог', 'что уточнить перед бронированием'],
            'informational' => ['какие документы нужны', 'какие условия проверить', 'что уточнить у менеджера'],
            default => [],
        });
    }
    if (!$answers) {
        $answers = ['какой сценарий закрывает страница', 'какие авто подходят', 'какие условия нужно проверить'];
    }

    return demand_unique_strings($answers);
}

function demand_stage_c_must_not_promise(array $keyword, array $stageB = []): array
{
    $riskFlags = demand_unique_strings(array_merge((array) ($keyword['riskFlags'] ?? []), (array) ($stageB['riskFlags'] ?? [])));
    $items = array_merge((array) ($keyword['mustNotPromise'] ?? []), (array) ($stageB['pageRiskProfile']['mustNotPromise'] ?? []));
    $items[] = 'Не обещать наличие авто без проверки.';
    $items[] = 'Не обещать самую низкую цену.';
    $items[] = 'Не менять цены, залог и условия.';
    if (array_intersect($riskFlags, ['possible_false_promise', 'condition_not_supported']) || str_contains((string) ($keyword['normalizedPhrase'] ?? ''), 'без залога')) {
        $items[] = 'Не обещать "без залога", если это не подтверждено.';
    }
    if (in_array('airport_delivery_not_confirmed', $riskFlags, true)) {
        $items[] = 'Не обещать подачу в аэропорт без подтверждения.';
    }
    if (in_array('availability_claim_risk', $riskFlags, true)) {
        $items[] = 'Не обещать 24/7 или срочную выдачу без подтверждения.';
    }
    if (in_array('driver_service_not_confirmed', $riskFlags, true)) {
        $items[] = 'Не обещать авто с водителем, если услуги нет.';
    }
    if (in_array('unsupported_legal_request', $riskFlags, true)) {
        $items[] = 'Не обещать аренду без прав, паспорта или договора.';
    }
    if (array_intersect(demand_stage_c_detect_intents($keyword), ['family_trip', 'luggage_and_seats'])) {
        $items[] = 'Не обещать детское кресло, если это не подтверждено.';
    }
    if (in_array('no_matching_cars', $riskFlags, true)) {
        $items[] = 'Не обещать конкретный класс авто, если нет активных машин.';
    }

    return demand_unique_strings(array_map('strval', $items));
}

function demand_stage_c_recommended_faq(array $keyword, array $stageB = []): array
{
    if (demand_stage_c_is_excluded($keyword)) {
        return [];
    }

    $faq = [];
    foreach (demand_stage_c_user_question_map($keyword) as $question) {
        $intent = (string) ($question['sourceIntent'] ?? 'general');
        $riskLevel = in_array($intent, ['airport_delivery', 'deposit_sensitive'], true) ? 'medium' : 'low';
        if (in_array('possible_false_promise', (array) ($stageB['riskFlags'] ?? []), true)) {
            $riskLevel = 'high';
        }
        $guidance = match ($intent) {
            'airport_delivery' => 'Ответить только если подача подтверждена. Если неизвестно — указать, что подача согласуется с менеджером.',
            'deposit_sensitive' => 'Не обещать отсутствие залога. Объяснить, от чего зависит залог и когда он возвращается.',
            'price_sensitive', 'weekly_rental' => 'Не обещать самую низкую цену. Объяснить зависимость цены от дат, авто и срока аренды.',
            'family_trip', 'luggage_and_seats' => 'Отвечать по данным конкретного авто: места, багаж и детское кресло требуют проверки.',
            'driverless' => 'Подтвердить документы, стаж и правила самостоятельного управления.',
            default => 'Ответить только на основе подтверждённых условий Rent RK; если данных нет, указать, что менеджер уточнит условия.',
        };
        $faq[] = [
            'question' => (string) ($question['question'] ?? ''),
            'answerGuidance' => $guidance,
            'sourceIntent' => $intent,
            'riskLevel' => $riskLevel,
        ];
        if (count($faq) >= 8) {
            break;
        }
    }

    return $faq;
}

function demand_stage_c_recommended_internal_links(array $keyword): array
{
    if (demand_stage_c_is_excluded($keyword)) {
        return [];
    }

    $intents = demand_stage_c_detect_intents($keyword);
    $links = [];
    $phrase = (string) ($keyword['phrase'] ?? $keyword['normalizedPhrase'] ?? '');
    $city = (string) ($keyword['detectedCity'] ?? $keyword['detectedRegion'] ?? '');
    $class = (string) ($keyword['detectedCarClass'] ?? '');
    if ($city !== '' && $class !== '') {
        $links[] = [
            'linkType' => 'city_to_class',
            'fromContext' => $phrase,
            'toTargetType' => 'landing_or_category',
            'targetHint' => 'Аренда ' . $class . ' ' . $city,
            'reason' => 'Пользователь ищет город и класс авто; связка помогает выбрать подходящий автомобиль.',
        ];
    } elseif ($city !== '') {
        $links[] = [
            'linkType' => 'city_to_class',
            'fromContext' => $phrase,
            'toTargetType' => 'landing_or_category',
            'targetHint' => 'Классы авто для аренды ' . $city,
            'reason' => 'Городскую страницу полезно связать с подходящими классами авто.',
        ];
    } elseif ($class !== '') {
        $links[] = [
            'linkType' => 'class_to_city',
            'fromContext' => $phrase,
            'toTargetType' => 'landing_or_category',
            'targetHint' => 'Городские страницы для класса ' . $class,
            'reason' => 'Класс авто полезно связать с городами выдачи.',
        ];
    }
    if (in_array('deposit_sensitive', $intents, true)) {
        $links[] = [
            'linkType' => 'condition_to_cars',
            'fromContext' => $phrase,
            'toTargetType' => 'condition_or_car_cards',
            'targetHint' => 'Условия залога и карточки авто',
            'reason' => 'Запрос про залог должен вести к подтверждённым условиям и авто.',
        ];
    }
    if (in_array('airport_delivery', $intents, true)) {
        $links[] = [
            'linkType' => 'airport_to_region',
            'fromContext' => $phrase,
            'toTargetType' => 'landing_or_region',
            'targetHint' => 'Аренда авто в Симферополе и Крыму',
            'reason' => 'Аэропорт связан с городом/регионом, но подача должна подтверждаться.',
        ];
    }
    if (array_intersect($intents, ['family_trip', 'luggage_and_seats'])) {
        $links[] = [
            'linkType' => 'family_to_class',
            'fromContext' => $phrase,
            'toTargetType' => 'landing_or_category',
            'targetHint' => 'Минивэны и 7-местные авто',
            'reason' => 'Семейный сценарий полезно связать с вместительными авто.',
        ];
    }
    if (in_array('cabriolet', $intents, true)) {
        $links[] = [
            'linkType' => 'seasonal_class_to_routes',
            'fromContext' => $phrase,
            'toTargetType' => 'route_or_seasonal_page',
            'targetHint' => 'Кабриолеты, маршруты и сезонные поездки',
            'reason' => 'Кабриолетный спрос зависит от сезона и сценария поездки.',
        ];
    }

    return array_slice($links, 0, 6);
}

function demand_stage_c_recommended_car_card_hints(array $keyword, array $cars): array
{
    if (demand_stage_c_is_excluded($keyword) || !$cars) {
        return [];
    }

    $intents = demand_stage_c_detect_intents($keyword);
    $hints = [];
    foreach ($cars as $car) {
        if (!is_array($car)) {
            continue;
        }
        $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
        if ($slug === '') {
            continue;
        }
        $items = [];
        if (array_intersect($intents, ['family_trip', 'luggage_and_seats']) || (int) ($car['seats'] ?? 0) >= 7) {
            $items[] = 'выделить количество мест и пользу для семьи или компании';
            $items[] = 'добавить текст про багаж, если это подтверждено данными авто';
            $items[] = 'добавить фото салона/багажника, если его нет';
        }
        if (in_array('airport_delivery', $intents, true)) {
            $items[] = 'добавить только подтверждённую информацию о подаче/получении';
        }
        if (in_array('deposit_sensitive', $intents, true) || demand_car_deposit_state($car) === 'unknown') {
            $items[] = 'проверить и явно описать залог';
        }
        if (in_array('price_sensitive', $intents, true) || !demand_car_has_price($car)) {
            $items[] = 'проверить цену и объяснить, что итог зависит от дат и условий';
        }
        if (in_array('driverless', $intents, true)) {
            $items[] = 'уточнить самостоятельное управление и документы без обещания неподтверждённых условий';
        }
        if ($items) {
            $hints[] = [
                'carSlug' => $slug,
                'carName' => (string) ($car['name'] ?? $slug),
                'hints' => demand_unique_strings($items),
            ];
        }
    }

    return array_slice($hints, 0, 8);
}

function demand_stage_c_detect_dangerous_claims(array $contentBlocks, string $intro = ''): array
{
    $text = demand_lower($intro);
    foreach ($contentBlocks as $block) {
        if (!is_array($block)) {
            continue;
        }
        $text .= ' ' . demand_lower((string) ($block['title'] ?? '')) . ' ' . demand_lower((string) ($block['body'] ?? ''));
        foreach ((array) ($block['items'] ?? []) as $item) {
            if (is_array($item)) {
                $text .= ' ' . demand_lower((string) ($item['question'] ?? '') . ' ' . (string) ($item['answer'] ?? ''));
            }
        }
    }

    $claims = [];
    foreach ([
        'без залога' => 'Обещание аренды без залога требует подтверждения.',
        'самая низкая' => 'Нельзя обещать самую низкую цену без подтверждения.',
        'гарантирован' => 'Нельзя гарантировать наличие или условия без проверки.',
        '24/7' => 'Круглосуточную выдачу нельзя обещать без подтверждения режима.',
        'без прав' => 'Аренда без прав невозможна для самостоятельной аренды.',
        'без паспорта' => 'Аренда без паспорта невозможна для самостоятельной аренды.',
    ] as $needle => $message) {
        if (str_contains($text, $needle)) {
            $claims[] = $message;
        }
    }

    return demand_unique_strings($claims);
}

function demand_stage_c_content_gap_report(array $keyword, array $safeBlocks, array $contentBlocks = [], string $intro = '', array $stageB = []): array
{
    $requiredTypes = array_values(array_filter(array_map(static fn(array $block): string => (string) ($block['type'] ?? ''), $safeBlocks)));
    $presentTypes = array_values(array_filter(array_map(static fn($block): string => is_array($block) ? (string) ($block['type'] ?? '') : '', $contentBlocks)));
    $missingBlocks = array_values(array_diff($requiredTypes, $presentTypes));
    $weakBlocks = [];
    $clarityWarnings = [];
    $recommendedFixes = [];

    if (trim($intro) === '') {
        $missingBlocks[] = 'intro_answer';
        $clarityWarnings[] = 'Нет короткого прямого ответа в начале.';
    }
    if (!in_array('faq', $presentTypes, true) && in_array('faq', $requiredTypes, true)) {
        $missingBlocks[] = 'faq';
        $recommendedFixes[] = 'Добавить FAQ по основным вопросам пользователя.';
    }
    if (!in_array('available_cars', $presentTypes, true) && in_array('available_cars', $requiredTypes, true)) {
        $missingBlocks[] = 'available_cars';
        $recommendedFixes[] = 'Показать подходящие авто или оставить задачу на ручное подтверждение.';
    }
    if (!in_array('conditions', $presentTypes, true) && in_array('conditions', $requiredTypes, true)) {
        $missingBlocks[] = 'conditions';
        $recommendedFixes[] = 'Добавить блок условий: документы, залог, цена, подача, ограничения.';
    }
    if (array_intersect(demand_stage_c_detect_intents($keyword), ['airport_delivery']) && !in_array('airport_pickup', $presentTypes, true)) {
        $missingBlocks[] = 'airport_pickup';
        $recommendedFixes[] = 'Добавить блок про подачу/получение в аэропорту только как подтверждаемое условие.';
    }
    if (array_intersect(demand_stage_c_detect_intents($keyword), ['family_trip', 'luggage_and_seats']) && !in_array('luggage_and_seats', $presentTypes, true)) {
        $missingBlocks[] = 'luggage_and_seats';
        $recommendedFixes[] = 'Раскрыть места, багаж и семейный сценарий.';
    }
    if (in_array('comparison', demand_stage_c_detect_intents($keyword), true) && !in_array('comparison', $presentTypes, true)) {
        $missingBlocks[] = 'comparison';
        $recommendedFixes[] = 'Добавить критерии сравнения без обещания лучшего варианта для всех.';
    }
    if (!in_array('what_to_confirm_before_booking', $presentTypes, true) && !demand_stage_c_is_excluded($keyword)) {
        $missingBlocks[] = 'what_to_confirm_before_booking';
        $recommendedFixes[] = 'Добавить список фактов, которые менеджер подтверждает перед бронированием.';
    }

    foreach ($contentBlocks as $block) {
        if (!is_array($block)) {
            continue;
        }
        if ((string) ($block['type'] ?? '') !== 'faq' && trim((string) ($block['body'] ?? '')) === '') {
            $weakBlocks[] = (string) ($block['type'] ?? 'text');
        }
    }

    $dangerousClaims = demand_stage_c_detect_dangerous_claims($contentBlocks, $intro);
    if ($dangerousClaims) {
        $recommendedFixes[] = 'Убрать или переписать опасные обещания через подтверждаемые условия.';
        $clarityWarnings[] = 'В тексте есть рискованные обещания.';
    }
    if (!empty($stageB['contentGapSummary'])) {
        $clarityWarnings[] = (string) $stageB['contentGapSummary'];
    }

    return [
        'missingBlocks' => demand_unique_strings($missingBlocks),
        'weakBlocks' => demand_unique_strings($weakBlocks),
        'dangerousClaims' => demand_unique_strings($dangerousClaims),
        'recommendedFixes' => demand_unique_strings($recommendedFixes),
        'clarityWarnings' => demand_unique_strings($clarityWarnings),
    ];
}

function demand_stage_c_first_screen_answer(array $keyword, array $stageB = []): string
{
    $normalized = (string) ($keyword['normalizedPhrase'] ?? '');
    $intents = demand_stage_c_detect_intents($keyword);
    if (demand_stage_c_is_excluded($keyword) || in_array('unsupported_legal_request', (array) ($stageB['riskFlags'] ?? []), true)) {
        return 'Запрос требует осторожности: если условие не поддерживается правилами самостоятельной аренды Rent RK, посадочную страницу создавать нельзя. Лучше объяснить ограничение и предложить безопасный вариант.';
    }
    if (in_array('deposit_sensitive', $intents, true) || str_contains($normalized, 'без залога')) {
        return 'Запрос про аренду без залога требует осторожности: если по автомобилям предусмотрен залог, страницу с обещанием "без залога" создавать нельзя. Лучше объяснить, от чего зависит залог и когда он возвращается.';
    }
    if (in_array('airport_delivery', $intents, true)) {
        return 'Автомобиль можно подготовить к получению в аэропорту только при подтверждённой подаче. Перед бронированием нужно согласовать время, место встречи, залог и условия возврата.';
    }
    if (array_intersect($intents, ['family_trip', 'luggage_and_seats']) || (string) ($keyword['detectedCarClass'] ?? '') === 'минивэн') {
        return 'Минивэн или 7-местный автомобиль подойдёт семье или компании, когда важно ехать вместе и оставить место для багажа. Перед бронированием нужно проверить доступность авто, залог и условия подачи.';
    }
    if (in_array('cabriolet', $intents, true)) {
        return 'Кабриолет подходит для сезонных поездок и прогулочных маршрутов, но доступность, условия аренды, погоду и ограничения нужно проверять перед бронированием.';
    }
    if (in_array('price_sensitive', $intents, true)) {
        return 'Стоимость аренды зависит от дат, автомобиля, срока и условий. Можно подобрать экономичный вариант, но цену, залог и доступность нужно проверить перед бронированием.';
    }
    if (in_array('driverless', $intents, true)) {
        return 'Аренда без водителя возможна только при соблюдении условий самостоятельной аренды: документы, стаж, залог и доступность автомобиля проверяются перед оформлением.';
    }
    if (in_array('weekly_rental', $intents, true)) {
        return 'Для аренды на неделю важно заранее проверить доступность автомобиля, итоговую стоимость, залог, лимит пробега и условия возврата.';
    }

    return 'Страница должна быстро ответить, какие автомобили подходят под запрос, какие условия нужно проверить и что менеджер подтверждает перед бронированием.';
}

function demand_stage_c_user_clarity_score(array $gapReport, array $safeBlocks, array $cars, array $stageB = []): array
{
    $score = 100;
    $score -= count((array) ($gapReport['missingBlocks'] ?? [])) * 8;
    $score -= count((array) ($gapReport['weakBlocks'] ?? [])) * 5;
    $score -= count((array) ($gapReport['dangerousClaims'] ?? [])) * 20;
    if (!$cars && !in_array('not_supported_explanation', array_map(static fn(array $block): string => (string) ($block['type'] ?? ''), $safeBlocks), true)) {
        $score -= 12;
    }
    if (in_array((string) ($stageB['priorityLevel'] ?? ''), ['blocked', 'needs_business_decision'], true)) {
        $score -= 10;
    }
    $score = demand_stage_b_clamp_score($score, 0, 100);
    $level = $score >= 78 ? 'clear' : ($score >= 55 ? 'needs_fixes' : 'confusing');
    if (!empty($gapReport['dangerousClaims']) || (string) ($stageB['priorityLevel'] ?? '') === 'blocked') {
        $level = 'risky';
    }
    $summary = match ($level) {
        'clear' => 'Страница выглядит понятной: есть основные блоки, условия, авто или объяснение и FAQ.',
        'needs_fixes' => 'Страница частично понятна, но нужно закрыть несколько важных вопросов пользователя.',
        'risky' => 'Страница рискованна: есть опасные обещания или запрос нельзя превращать в продающий лендинг.',
        default => 'Страница пока слабая: пользователю не хватает прямого ответа, фактов или безопасных условий.',
    };

    return ['level' => $level, 'score' => $score, 'summary' => $summary];
}

function demand_stage_c_ai_search_readiness(array $gapReport, array $safeBlocks, array $cars, array $stageB = []): array
{
    $types = array_map(static fn(array $block): string => (string) ($block['type'] ?? ''), $safeBlocks);
    $score = 70;
    if (!in_array('intro_answer', $types, true) && !in_array('not_supported_explanation', $types, true)) {
        $score -= 18;
    }
    if (!in_array('faq', $types, true)) {
        $score -= 12;
    }
    if (!in_array('conditions', $types, true) && !in_array('not_supported_explanation', $types, true)) {
        $score -= 10;
    }
    if (!$cars && !in_array('not_supported_explanation', $types, true)) {
        $score -= 14;
    }
    $score -= count((array) ($gapReport['missingBlocks'] ?? [])) * 5;
    $score -= count((array) ($gapReport['weakBlocks'] ?? [])) * 4;
    $score -= count((array) ($gapReport['dangerousClaims'] ?? [])) * 22;
    $score = demand_stage_b_clamp_score($score, 0, 100);

    $level = $score >= 76 ? 'ready' : ($score >= 58 ? 'needs_structure' : 'needs_facts');
    if (!empty($gapReport['dangerousClaims']) || (string) ($stageB['priorityLevel'] ?? '') === 'blocked') {
        $level = 'risky';
    }
    $summary = match ($level) {
        'ready' => 'Есть прямой ответ, структура, FAQ и ограничения; материал пригоден для поискового/AI-ответа после проверки фактов.',
        'needs_structure' => 'Нужна более явная структура: прямой ответ, FAQ, условия и блок подтверждения фактов.',
        'risky' => 'Для AI/поискового ответа рискованно: есть опасные обещания или неподдерживаемый запрос.',
        default => 'Не хватает фактов: авто, условий, цены/залога, подачи или ограничений.',
    };

    return ['level' => $level, 'score' => $score, 'summary' => $summary];
}

function demand_stage_c_analyze_keyword(array $keyword, array $context = []): array
{
    $stageB = is_array($context['stageB'] ?? null) ? (array) $context['stageB'] : [];
    if (!$stageB && function_exists('demand_stage_b_score_keyword')) {
        $stageB = demand_stage_b_score_keyword($keyword, $context);
    }
    $cars = is_array($context['cars'] ?? null) ? (array) $context['cars'] : demand_match_cars_for_keyword($keyword);
    $contentBlocks = is_array($context['contentBlocks'] ?? null) ? (array) $context['contentBlocks'] : [];
    $intro = (string) ($context['intro'] ?? '');

    $userQuestionMap = demand_stage_c_user_question_map($keyword);
    $safeContentBlocks = demand_stage_c_safe_content_blocks($keyword, $stageB);
    $contentGapReport = demand_stage_c_content_gap_report($keyword, $safeContentBlocks, $contentBlocks, $intro, $stageB);
    $mustAnswer = demand_stage_c_must_answer($keyword);
    $mustNotPromise = demand_stage_c_must_not_promise($keyword, $stageB);
    $recommendedFaq = demand_stage_c_recommended_faq($keyword, $stageB);
    $recommendedInternalLinks = demand_stage_c_recommended_internal_links($keyword);
    $recommendedCarCardHints = demand_stage_c_recommended_car_card_hints($keyword, $cars);
    $userClarityScore = demand_stage_c_user_clarity_score($contentGapReport, $safeContentBlocks, $cars, $stageB);
    $aiSearchReadiness = demand_stage_c_ai_search_readiness($contentGapReport, $safeContentBlocks, $cars, $stageB);

    return [
        'userQuestionMap' => $userQuestionMap,
        'safeContentBlocks' => $safeContentBlocks,
        'contentGapReport' => $contentGapReport,
        'firstScreenAnswer' => demand_stage_c_first_screen_answer($keyword, $stageB),
        'mustAnswer' => $mustAnswer,
        'mustNotPromise' => $mustNotPromise,
        'recommendedFaq' => $recommendedFaq,
        'recommendedInternalLinks' => $recommendedInternalLinks,
        'recommendedCarCardHints' => $recommendedCarCardHints,
        'userClarityScore' => $userClarityScore,
        'aiSearchReadiness' => $aiSearchReadiness,
    ];
}

function demand_stage_c_public_block_title(string $type, string $fallback = ''): string
{
    return match ($type) {
        'intro_answer' => '',
        'available_cars' => 'Авто по этому запросу',
        'conditions' => 'Условия аренды',
        'deposit_explanation' => 'Залог',
        'price_explanation' => 'Цена',
        'pickup_delivery' => 'Получение и возврат',
        'airport_pickup' => 'Получение в аэропорту',
        'family_use' => 'Когда подойдёт такой автомобиль',
        'luggage_and_seats' => 'Места и багаж',
        'weekly_rental' => 'Аренда на несколько дней',
        'route_use' => 'Поездки по маршруту',
        'comparison' => 'Как выбрать подходящий вариант',
        'what_to_confirm_before_booking' => 'Перед бронированием',
        'safety_limitations' => 'Что важно проверить',
        'not_supported_explanation' => 'Перед бронированием',
        'faq' => 'FAQ',
        default => $fallback !== '' ? $fallback : 'Полезно знать',
    };
}

function demand_stage_c_public_block_body(string $type, array $block, array $stageC, array $cars = []): string
{
    $carNames = array_values(array_filter(array_map(static fn(array $car): string => (string) ($car['name'] ?? ''), $cars)));
    $mustNot = array_values(array_filter(array_map('strval', (array) ($stageC['mustNotPromise'] ?? []))));
    $base = trim((string) ($block['publicText'] ?? $block['body'] ?? ''));
    if ($base !== '') {
        return $base;
    }

    return match ($type) {
        'intro_answer' => trim((string) ($stageC['firstScreenAnswer'] ?? '')),
        'available_cars' => $carNames
            ? 'Ниже показаны автомобили, которые подходят под этот запрос: ' . implode(', ', $carNames) . '. Перед бронированием менеджер проверит свободные даты, залог и условия подачи по конкретной машине.'
            : 'Подходящие автомобили нужно подтвердить вручную. Менеджер подберёт вариант по датам, маршруту и требованиям к багажу или количеству мест.',
        'conditions' => 'Для аренды обычно нужны паспорт и водительское удостоверение. Стаж, срок аренды, ограничения по пробегу и порядок оформления лучше проверить заранее по выбранному автомобилю.',
        'deposit_explanation' => 'Залог зависит от автомобиля и условий аренды. Точную сумму, порядок внесения и возврата менеджер подтверждает до бронирования.',
        'price_explanation' => 'Стоимость зависит от дат, срока аренды, класса автомобиля и дополнительных условий. Если цена не указана на странице, менеджер рассчитает её по выбранным датам и машине.',
        'pickup_delivery' => 'Получение и возврат согласуются заранее: город, адрес, время, возможная подача и возврат в другой точке. Если условие не подтверждено, его нужно уточнить перед бронированием.',
        'airport_pickup' => 'Подача к аэропорту или встреча в конкретной точке возможна только после подтверждения менеджером. Перед поездкой стоит согласовать время, место встречи, возврат и возможную доплату.',
        'family_use' => 'Такой формат удобен, когда важно ехать вместе: семья, друзья, дети, чемоданы и маршрут по Крыму на несколько дней. Перед бронированием проверьте количество мест, багажник и детское кресло, если оно нужно.',
        'luggage_and_seats' => 'Количество мест и багажное пространство лучше сверять по конкретному автомобилю. Если едете с детьми, чемоданами или спортивным снаряжением, укажите это в заявке.',
        'weekly_rental' => 'При аренде на несколько дней важны не только суточная цена, но и залог, лимит пробега, место возврата и условия продления. Эти детали лучше согласовать до поездки.',
        'route_use' => 'Если планируется маршрут по нескольким городам, заранее укажите примерный путь и место возврата. Менеджер подскажет, какие условия нужно проверить по выбранному автомобилю.',
        'comparison' => 'Сравнивайте не только класс и цену, но и количество мест, багажник, коробку, привод, залог и место получения. Так проще выбрать машину под реальный маршрут.',
        'what_to_confirm_before_booking' => 'Перед бронированием стоит уточнить свободные даты, точный залог, документы, место получения и возврата, ограничения по пробегу и дополнительные пожелания.',
        'safety_limitations' => 'Сезонность, погода, место подачи и доступность конкретной машины проверяются перед поездкой. Неподтверждённые условия лучше не считать гарантированными.',
        'not_supported_explanation' => $mustNot
            ? 'Некоторые условия требуют отдельного подтверждения: ' . implode('; ', array_slice($mustNot, 0, 3)) . '. Без подтверждения их нельзя обещать на странице.'
            : 'Если условие не подтверждено данными Rent RK, его нужно уточнить у менеджера до бронирования.',
        default => 'Перед бронированием менеджер проверит доступность автомобиля, залог, документы, место получения и условия поездки.',
    };
}

function demand_stage_c_content_blocks_for_draft(array $stageC, array $cars = []): array
{
    $blocks = [];
    $faqItems = [];
    foreach ((array) ($stageC['recommendedFaq'] ?? []) as $faq) {
        if (!is_array($faq)) {
            continue;
        }
        $question = demand_clean_string((string) ($faq['question'] ?? ''), 240);
        $answer = demand_clean_string((string) ($faq['answerGuidance'] ?? ''), 900);
        if ($question !== '' && $answer !== '') {
            $faqItems[] = ['question' => $question, 'answer' => $answer];
        }
    }

    foreach ((array) ($stageC['safeContentBlocks'] ?? []) as $block) {
        if (!is_array($block)) {
            continue;
        }
        $type = (string) ($block['type'] ?? 'text');
        if ($type === 'faq') {
            $blocks[] = [
                'type' => 'faq',
                'visibility' => 'public',
                'title' => (string) ($block['title'] ?? 'Частые вопросы'),
                'items' => array_slice($faqItems, 0, 8),
            ];
            continue;
        }
        if ($type === 'internal_links') {
            $links = [];
            foreach ((array) ($stageC['recommendedInternalLinks'] ?? []) as $link) {
                if (is_array($link)) {
                    $links[] = (string) ($link['targetHint'] ?? '') . ' — ' . (string) ($link['reason'] ?? '');
                }
            }
            $body = $links ? implode("\n", array_filter($links)) : (string) ($block['suggestedTextTemplate'] ?? '');
        } elseif ($type === 'available_cars') {
            $carNames = array_values(array_filter(array_map(static fn(array $car): string => (string) ($car['name'] ?? ''), $cars)));
            $body = $carNames
                ? 'Связанные авто: ' . implode(', ', $carNames) . ".\n" . (string) ($block['suggestedTextTemplate'] ?? '')
                : (string) ($block['suggestedTextTemplate'] ?? '');
        } else {
            $body = (string) ($block['suggestedTextTemplate'] ?? '');
        }
        if ($type !== 'internal_links') {
            $body = demand_stage_c_public_block_body($type, $block, $stageC, $cars);
        }
        $blocks[] = [
            'type' => in_array($type, demand_allowed_content_block_types(), true) ? $type : 'text',
            'visibility' => $type === 'internal_links' ? 'admin_only' : 'public',
            'title' => (string) ($block['title'] ?? demand_admin_safe_block_title($type)),
            'body' => $body,
        ];
        if (count($blocks) >= 8) {
            break;
        }
    }

    return $blocks;
}

function demand_admin_safe_block_title(string $type): string
{
    return match ($type) {
        'intro_answer' => 'Короткий ответ',
        'available_cars' => 'Подходящие авто',
        'conditions' => 'Условия аренды',
        'deposit_explanation' => 'Залог',
        'price_explanation' => 'Цена',
        'airport_pickup' => 'Получение в аэропорту',
        'family_use' => 'Для семьи',
        'luggage_and_seats' => 'Места и багаж',
        'what_to_confirm_before_booking' => 'Что уточнить перед бронированием',
        'not_supported_explanation' => 'Безопасное объяснение',
        default => 'Блок страницы',
    };
}

function demand_recommendation_type_labels(): array
{
    return [
        'update_title_description' => 'Улучшить title и description',
        'improve_landing_conversion' => 'Улучшить конверсию страницы',
        'improve_answer_blocks' => 'Улучшить блоки с ответами',
        'check_indexing_status' => 'Проверить видимость в поиске',
        'connect_external_source' => 'Подключить источник данных',
        'review_low_conversion_page' => 'Проверить страницу с низкой конверсией',
        'create_launch_plan_item' => 'Создать пункт плана страниц',
        'create_content_brief' => 'Создать ТЗ для страницы',
        'create_card_optimization_hint' => 'Создать подсказку для карточки авто',
        'create_city_landing_draft' => 'Создать черновик городской страницы',
        'create_class_landing_draft' => 'Создать черновик страницы класса авто',
        'create_condition_explanation' => 'Подготовить объяснение условия',
        'postpone_until_supply_exists' => 'Отложить до появления предложения',
        'needs_business_decision' => 'Нужно бизнес-решение',
        'block_false_promise_page' => 'Заблокировать страницу с ложным обещанием',
        'ignore_as_irrelevant' => 'Не использовать: нецелевой запрос',
        'do_not_create_page' => 'Не создавать страницу',
        'maybe_use_as_negative_ad_keyword' => 'Можно использовать как минус-фразу',
        'create_landing_page_draft' => 'Создать черновик страницы',
        'update_existing_page' => 'Улучшить существующую страницу',
        'update_car_cards' => 'Улучшить карточки автомобилей',
        'add_faq' => 'Добавить FAQ',
        'add_internal_links' => 'Добавить внутренние ссылки',
        'do_not_publish' => 'Не публиковать',
        'need_human_review' => 'Нужна ручная проверка',
    ];
}

function demand_make_recommendation(array $keyword, string $type, string $priority, float $confidence, string $reason, array $cars = [], array $pages = [], array $riskFlags = [], array $stageB = []): array
{
    $recommendation = [
        'id' => 'dr_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'scope_id' => demand_normalize_scope_id((string) ($keyword['scope_id'] ?? 'rent_rk')),
        'keywordId' => (string) ($keyword['id'] ?? ''),
        'recommendationType' => $type,
        'priority' => $priority,
        'confidence' => max(0, min(1, $confidence)),
        'reason' => $reason,
        'linkedCars' => array_values(array_unique(array_filter(array_map(static fn(array $car): string => normalize_car_slug((string) ($car['slug'] ?? '')), $cars)))),
        'linkedPages' => array_values(array_map(static fn(array $page): string => (string) ($page['path'] ?? ''), $pages)),
        'riskFlags' => demand_unique_strings($riskFlags),
        'actionStatus' => 'new',
        'createdAt' => now_iso(),
        'updatedAt' => now_iso(),
    ];

    foreach ([
        'demandVolumeScore',
        'commercialScore',
        'supplyFitScore',
        'pageFitScore',
        'contentGapScore',
        'riskScore',
        'regionFitScore',
        'seasonalityScore',
        'decisionScore',
        'priorityLevel',
        'recommendedDecision',
        'scoringExplanation',
        'contentGapSummary',
        'pageFitStatus',
        'supplyFitSummary',
        'pageRiskProfile',
        'whatBlocks',
        'userQuestionMap',
        'safeContentBlocks',
        'contentGapReport',
        'firstScreenAnswer',
        'mustAnswer',
        'mustNotPromise',
        'recommendedFaq',
        'recommendedInternalLinks',
        'recommendedCarCardHints',
        'userClarityScore',
        'aiSearchReadiness',
    ] as $field) {
        if (array_key_exists($field, $stageB)) {
            $recommendation[$field] = $stageB[$field];
        }
    }

    return $recommendation;
}

function demand_card_hint_flags(array $keyword, array $cars): array
{
    $hints = [];
    $class = (string) ($keyword['detectedCarClass'] ?? '');
    $condition = (string) ($keyword['detectedCondition'] ?? '');
    $normalized = (string) ($keyword['normalizedPhrase'] ?? '');
    foreach ($cars as $car) {
        $carHints = [];
        if (($class === 'минивэн' || str_contains($normalized, 'семей')) && (int) ($car['seats'] ?? 0) >= 7) {
            $carHints[] = 'добавить или явно проверить формулировку "7 мест" и пользу для семьи';
        }
        if ($condition === 'без водителя') {
            $carHints[] = 'уточнить в карточке, что аренда оформляется без водителя, если это соответствует правилам';
        }
        if ($condition === 'подача' || (string) ($keyword['detectedCity'] ?? '') !== '') {
            $carHints[] = 'добавить информацию о подаче и городе получения, если она подтверждена';
        }
        if (str_contains($normalized, 'детск') || str_contains($normalized, 'кресл')) {
            $carHints[] = 'уточнить наличие детского кресла, если такая опция действительно есть';
        }
        $depositState = demand_car_deposit_state($car);
        if ($depositState === 'unknown') {
            $carHints[] = 'добавить или проверить информацию о залоге';
        }
        if (trim((string) ($car['image'] ?? '')) === '') {
            $carHints[] = 'добавить фото, чтобы карточка была готова к посадочной странице';
        }
        if ($carHints) {
            $hints[(string) ($car['slug'] ?? '')] = demand_unique_strings($carHints);
        }
    }

    return $hints;
}

function demand_build_recommendations_for_keyword(array $keyword): array
{
    $settings = demand_settings()['rent_rk'];
    $cars = demand_match_cars_for_keyword($keyword);
    $similarPages = demand_find_similar_pages($keyword);
    $riskFlags = is_array($keyword['riskFlags'] ?? null) ? $keyword['riskFlags'] : [];
    $frequency = (int) ($keyword['frequency'] ?? 0);
    if ($frequency > 0 && $frequency < (int) $settings['minFrequencyForDraftSuggestion']) {
        $riskFlags[] = 'low_frequency';
    }
    if (!$cars) {
        $riskFlags[] = 'no_matching_cars';
    }
    $carsWithPrice = array_values(array_filter($cars, static fn(array $car): bool => demand_car_has_price($car)));
    if ($cars && count($carsWithPrice) < count($cars)) {
        $riskFlags[] = 'no_price_data';
    }
    $depositStates = array_map(static fn(array $car): string => demand_car_deposit_state($car), $cars);
    if ($cars && in_array('unknown', $depositStates, true)) {
        $riskFlags[] = 'no_deposit_data';
    }
    if ($similarPages) {
        $riskFlags[] = 'too_similar_to_existing_page';
    }
    $riskFlags = demand_unique_strings($riskFlags);
    $stageBKeyword = $keyword;
    $stageBKeyword['riskFlags'] = $riskFlags;
    $stageB = demand_stage_b_score_keyword($stageBKeyword, [
        'cars' => $cars,
        'similarPages' => $similarPages,
    ]);
    $stageC = demand_stage_c_analyze_keyword($stageBKeyword, [
        'cars' => $cars,
        'similarPages' => $similarPages,
        'stageB' => $stageB,
    ]);
    $riskFlags = demand_unique_strings((array) ($stageB['riskFlags'] ?? $riskFlags));
    $priorityLevel = (string) ($stageB['priorityLevel'] ?? 'medium');
    $finalizeRecommendations = static function (array $recommendations) use ($stageB, $stageC): array {
        foreach ($recommendations as &$recommendation) {
            foreach ([
                'demandVolumeScore',
                'commercialScore',
                'supplyFitScore',
                'pageFitScore',
                'contentGapScore',
                'riskScore',
                'regionFitScore',
                'seasonalityScore',
                'decisionScore',
                'priorityLevel',
                'recommendedDecision',
                'scoringExplanation',
                'contentGapSummary',
                'pageFitStatus',
                'supplyFitSummary',
                'pageRiskProfile',
                'whatBlocks',
            ] as $field) {
                if (array_key_exists($field, $stageB) && !array_key_exists($field, $recommendation)) {
                    $recommendation[$field] = $stageB[$field];
                }
            }
            foreach ([
                'userQuestionMap',
                'safeContentBlocks',
                'contentGapReport',
                'firstScreenAnswer',
                'mustAnswer',
                'mustNotPromise',
                'recommendedFaq',
                'recommendedInternalLinks',
                'recommendedCarCardHints',
                'userClarityScore',
                'aiSearchReadiness',
            ] as $field) {
                if (array_key_exists($field, $stageC) && !array_key_exists($field, $recommendation)) {
                    $recommendation[$field] = $stageC[$field];
                }
            }
        }
        unset($recommendation);

        return $recommendations;
    };

    $recommendations = [];
    $phrase = (string) ($keyword['phrase'] ?? '');
    $condition = (string) ($keyword['detectedCondition'] ?? '');
    $normalized = (string) ($keyword['normalizedPhrase'] ?? '');
    $decisionHint = (string) ($keyword['decisionHint'] ?? '');
    $adminExplanation = demand_clean_string($keyword['adminExplanation'] ?? '', 1000);
    $negativeIntent = demand_clean_string($keyword['negativeIntent'] ?? '', 120);

    if ($negativeIntent !== '' || !empty($keyword['isExcluded'])) {
        $type = match ($negativeIntent) {
            'commercial_use_not_supported' => 'needs_business_decision',
            'competitor_or_platform_query', 'generic_noise' => 'maybe_use_as_negative_ad_keyword',
            'unsafe_legal_request', 'driver_service_not_supported', 'unsupported_vehicle_type' => 'do_not_create_page',
            default => 'ignore_as_irrelevant',
        };
        $recommendations[] = demand_make_recommendation(
            $keyword,
            $type,
            $type === 'needs_business_decision' ? 'medium' : 'high',
            0.96,
            $adminExplanation !== '' ? $adminExplanation : 'Фраза не относится к целевой самостоятельной аренде авто. Страницу, черновик и ТЗ по ней не создаём.',
            [],
            [],
            array_merge($riskFlags, ['not_relevant_for_car_rental'])
        );
        return $finalizeRecommendations($recommendations);
    }

    if ($condition === 'без залога') {
        $recommendations[] = demand_make_recommendation(
            $keyword,
            'create_condition_explanation',
            'high',
            0.95,
            'Запрос содержит обещание "без залога", но условия автопарка не подтверждают такую возможность. Нельзя создавать страницу с ложным обещанием. Можно подготовить информационный блок про размер залога и условия возврата.',
            $cars,
            [],
            array_merge($riskFlags, ['possible_false_promise', 'condition_not_supported'])
        );
        return $finalizeRecommendations($recommendations);
    }

    if ($decisionHint === 'do_not_create_page') {
        $recommendations[] = demand_make_recommendation(
            $keyword,
            'do_not_create_page',
            'high',
            0.9,
            $adminExplanation !== '' ? $adminExplanation : 'По этой фразе не нужно создавать посадочную страницу: есть риск нецелевого или неподдерживаемого обещания.',
            [],
            $similarPages,
            $riskFlags
        );
        return $finalizeRecommendations($recommendations);
    }

    if ($decisionHint === 'create_faq') {
        $recommendations[] = demand_make_recommendation(
            $keyword,
            'add_faq',
            'medium',
            0.78,
            $adminExplanation !== '' ? $adminExplanation : 'Фраза похожа на вопрос пользователя. Лучше добавить FAQ или блок ответа, а не создавать отдельную страницу.',
            $cars,
            $similarPages,
            array_diff($riskFlags, ['no_matching_cars'])
        );
        return $finalizeRecommendations($recommendations);
    }

    if ($decisionHint === 'add_condition_block') {
        $recommendations[] = demand_make_recommendation(
            $keyword,
            'add_faq',
            'medium',
            0.76,
            $adminExplanation !== '' ? $adminExplanation : 'Фраза связана с условиями аренды. Безопаснее добавить объясняющий блок или FAQ с подтвержденными условиями.',
            $cars,
            $similarPages,
            array_diff($riskFlags, ['no_matching_cars'])
        );
        return $finalizeRecommendations($recommendations);
    }

    if ($decisionHint === 'needs_business_decision' && !$cars) {
        $recommendations[] = demand_make_recommendation(
            $keyword,
            'needs_business_decision',
            'medium',
            0.82,
            $adminExplanation !== '' ? $adminExplanation : 'Перед созданием страницы нужно вручную подтвердить, что Rent RK реально оказывает эту услугу в указанном регионе или формате.',
            [],
            $similarPages,
            $riskFlags
        );
        return $finalizeRecommendations($recommendations);
    }

    if (!$cars) {
        $recommendations[] = demand_make_recommendation(
            $keyword,
            'postpone_until_supply_exists',
            'high',
            0.9,
            'Не создавать страницу по запросу "' . $phrase . '", потому что в текущих данных не найдено подходящих активных автомобилей или условий. Сначала нужно проверить реальное предложение.',
            [],
            $similarPages,
            $riskFlags
        );
        return $finalizeRecommendations($recommendations);
    }

    if (str_contains($normalized, 'дешев') || str_contains($normalized, 'недорог')) {
        $economyCars = array_values(array_filter($cars, static fn(array $car): bool => normalize_rate_price($car['price'] ?? null) !== null && (int) normalize_rate_price($car['price']) <= 4500));
        if (!$economyCars) {
            $recommendations[] = demand_make_recommendation(
                $keyword,
                'need_human_review',
                'medium',
                0.72,
                'Запрос про низкую цену нельзя превращать в агрессивное обещание. В данных не найден явный набор экономичных авто; лучше проверить тарифы вручную.',
                $cars,
                $similarPages,
                array_merge($riskFlags, ['needs_human_review'])
            );
        } else {
            $cars = $economyCars;
        }
    }

    if ($similarPages) {
        $recommendations[] = demand_make_recommendation(
            $keyword,
            'update_existing_page',
            'high',
            0.84,
            'Похожая публичная страница уже есть. Безопаснее улучшить существующую страницу, добавить полезные уточнения и не создавать дубль только с другим заголовком.',
            $cars,
            $similarPages,
            $riskFlags
        );
        $recommendations[] = demand_make_recommendation(
            $keyword,
            'add_internal_links',
            'medium',
            0.68,
            'Есть спрос и похожая страница: стоит связать её с релевантными карточками автомобилей и условиями аренды, не открывая новый URL.',
            $cars,
            $similarPages,
            []
        );
    } elseif ($frequency === 0 || $frequency >= (int) $settings['minFrequencyForDraftSuggestion']) {
        $recommendations[] = demand_make_recommendation(
            $keyword,
            'create_landing_page_draft',
            in_array($priorityLevel, ['high', 'medium'], true) ? $priorityLevel : ($frequency >= 30 ? 'high' : 'medium'),
            0.82,
            'Есть спрос по фразе "' . $phrase . '", найдены подходящие автомобили, а отдельная похожая страница не найдена. Можно подготовить только черновик для ручной проверки.',
            $cars,
            [],
            array_diff($riskFlags, ['low_frequency'])
        );
    } else {
        $recommendations[] = demand_make_recommendation(
            $keyword,
            'need_human_review',
            'low',
            0.58,
            'Частотность ниже порога для черновика. Запрос лучше проверить вручную и использовать как подсказку для FAQ или карточек авто.',
            $cars,
            [],
            $riskFlags
        );
    }

    if (demand_card_hint_flags($keyword, $cars)) {
        $recommendations[] = demand_make_recommendation(
            $keyword,
            'update_car_cards',
            'medium',
            0.76,
            'Спрос подсказывает важные формулировки для карточек авто: места, семейное использование, подача, залог или фото. Нужно дополнять только подтвержденные свойства.',
            $cars,
            [],
            []
        );
    }

    if (in_array((string) ($keyword['category'] ?? ''), ['condition', 'airport', 'family', 'price'], true)) {
        $recommendations[] = demand_make_recommendation(
            $keyword,
            'add_faq',
            'medium',
            0.7,
            'Запрос связан с условиями аренды. Полезнее добавить короткий FAQ с честными ответами, чем создавать страницу с неподтвержденными обещаниями.',
            $cars,
            $similarPages,
            []
        );
    }

    return $finalizeRecommendations($recommendations);
}

function demand_recalculate_keyword_recommendations(string $keywordId): array
{
    $keyword = demand_find_keyword($keywordId);
    if (!$keyword) {
        throw new RuntimeException('Ключевой запрос не найден.');
    }

    $data = read_demand_recommendations();
    $existing = [];
    $kept = [];
    foreach ($data['items'] as $item) {
        if (!is_array($item)) {
            continue;
        }
        if ((string) ($item['keywordId'] ?? '') === $keywordId) {
            $existing[(string) ($item['recommendationType'] ?? '')] = $item;
        } else {
            $kept[] = $item;
        }
    }

    $new = [];
    foreach (demand_build_recommendations_for_keyword($keyword) as $recommendation) {
        $type = (string) ($recommendation['recommendationType'] ?? '');
        if (isset($existing[$type])) {
            $recommendation['id'] = (string) ($existing[$type]['id'] ?? $recommendation['id']);
            $recommendation['actionStatus'] = (string) ($existing[$type]['actionStatus'] ?? 'new');
            $recommendation['createdAt'] = (string) ($existing[$type]['createdAt'] ?? $recommendation['createdAt']);
            $recommendation['updatedAt'] = now_iso();
        }
        $new[] = $recommendation;
        analytics_record_event('demand_recommendation_created', [
            'scopeId' => (string) $recommendation['scope_id'],
            'entityType' => 'demand_recommendation',
            'entityId' => (string) $recommendation['id'],
            'meta' => ['type' => $type, 'keywordId' => $keywordId],
        ]);
    }

    $data['items'] = array_merge($new, $kept);
    save_demand_recommendations($data);

    return $new;
}

function demand_update_keyword_status(string $keywordId, string $status): void
{
    if (!has_permission('demand.manage')) {
        deny_scope_access();
    }
    $allowed = ['active', 'not_target', 'excluded', 'archived'];
    if (!in_array($status, $allowed, true)) {
        throw new RuntimeException('Некорректный статус запроса.');
    }

    $data = read_demand_keywords();
    foreach ($data['items'] as $index => $keyword) {
        if (is_array($keyword) && (string) ($keyword['id'] ?? '') === $keywordId) {
            $data['items'][$index]['status'] = $status;
            $data['items'][$index]['updatedAt'] = now_iso();
            save_demand_keywords($data);
            audit_log('demand.keyword.status_changed', 'demand_keyword', $keywordId, 'Изменен статус поисковой фразы', [
                'status' => $status,
            ]);
            return;
        }
    }
    throw new RuntimeException('Ключевой запрос не найден.');
}

function demand_update_recommendation_status(string $recommendationId, string $status): void
{
    $recommendation = demand_find_recommendation($recommendationId);
    if (!$recommendation) {
        throw new RuntimeException('Рекомендация не найдена.');
    }
    demand_scope_guard($recommendation, 'demand.recommendations.view');
    $allowed = ['new', 'in_review', 'draft_created', 'done', 'rejected', 'archived'];
    if (!in_array($status, $allowed, true)) {
        throw new RuntimeException('Некорректный статус рекомендации.');
    }

    $data = read_demand_recommendations();
    foreach ($data['items'] as $index => $item) {
        if (is_array($item) && (string) ($item['id'] ?? '') === $recommendationId) {
            $data['items'][$index]['actionStatus'] = $status;
            $data['items'][$index]['updatedAt'] = now_iso();
            save_demand_recommendations($data);
            analytics_record_event('demand_recommendation_status_changed', [
                'scopeId' => (string) ($item['scope_id'] ?? 'rent_rk'),
                'entityType' => 'demand_recommendation',
                'entityId' => $recommendationId,
                'meta' => ['status' => $status],
            ]);
            return;
        }
    }
}

function demand_transliterate(string $value): string
{
    $map = [
        'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd', 'е' => 'e', 'ё' => 'e', 'ж' => 'zh', 'з' => 'z', 'и' => 'i', 'й' => 'y',
        'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n', 'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't', 'у' => 'u',
        'ф' => 'f', 'х' => 'h', 'ц' => 'c', 'ч' => 'ch', 'ш' => 'sh', 'щ' => 'sch', 'ъ' => '', 'ы' => 'y', 'ь' => '', 'э' => 'e',
        'ю' => 'yu', 'я' => 'ya',
    ];
    $value = demand_lower($value);
    $value = strtr($value, $map);
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';

    return trim($value, '-');
}

function demand_landing_h1_for_keyword(array $keyword): string
{
    $class = (string) ($keyword['detectedCarClass'] ?? '');
    $city = (string) ($keyword['detectedCity'] ?? '');
    $region = (string) ($keyword['detectedRegion'] ?? '');
    $condition = (string) ($keyword['detectedCondition'] ?? '');
    $place = demand_landing_place_text($city, $region);

    if ($class === 'минивэн') {
        return 'Аренда минивэна' . $place;
    }
    if ($class === 'кабриолет') {
        return 'Прокат кабриолета' . $place;
    }
    if ($class !== '') {
        return 'Аренда авто класса ' . $class . $place;
    }
    if ($condition === 'без водителя') {
        return 'Аренда авто без водителя' . $place;
    }
    if (str_contains((string) ($keyword['normalizedPhrase'] ?? ''), 'недорог') || str_contains((string) ($keyword['normalizedPhrase'] ?? ''), 'дешев')) {
        return 'Экономичные автомобили в аренду' . $place;
    }

    return 'Аренда авто' . $place;
}

function demand_landing_place_text(string $city, string $region): string
{
    $forms = [
        'Ялта' => 'Ялте',
        'Симферополь' => 'Симферополе',
        'Алушта' => 'Алуште',
        'Севастополь' => 'Севастополе',
        'Евпатория' => 'Евпатории',
        'Феодосия' => 'Феодосии',
        'Керчь' => 'Керчи',
        'Судак' => 'Судаке',
        'Саки' => 'Саках',
        'Бахчисарай' => 'Бахчисарае',
    ];
    if ($city !== '') {
        return ' в ' . ($forms[$city] ?? $city);
    }
    if ($region === 'Крым') {
        return ' в Крыму';
    }

    return $region !== '' ? ' в ' . $region : '';
}

function demand_landing_slug_for_keyword(array $keyword): string
{
    $class = (string) ($keyword['detectedCarClass'] ?? '');
    $city = (string) ($keyword['detectedCity'] ?? '');
    $region = (string) ($keyword['detectedRegion'] ?? '');
    $condition = (string) ($keyword['detectedCondition'] ?? '');
    $placeSlug = $city !== '' ? demand_transliterate($city) : ($region !== '' ? demand_transliterate($region) : '');
    $base = match ($class) {
        'минивэн' => 'arenda-minivena',
        'кабриолет' => 'prokat-kabrioleta',
        'кроссовер' => 'arenda-krossovera',
        'седан' => 'arenda-sedana',
        default => $condition === 'без водителя' ? 'arenda-avto-bez-voditelya' : 'arenda-avto',
    };
    $slug = trim($base . ($placeSlug !== '' ? '-' . $placeSlug : ''), '-');
    if ($slug === 'arenda-avto' && (str_contains((string) ($keyword['normalizedPhrase'] ?? ''), 'недорог') || str_contains((string) ($keyword['normalizedPhrase'] ?? ''), 'дешев'))) {
        $slug = $placeSlug !== '' ? 'ekonomichnye-avto-' . $placeSlug : 'ekonomichnye-avto';
    }

    return $slug !== '' ? $slug : 'landing-page-draft';
}

function demand_draft_quality_status(array $draft, array $riskFlags = []): string
{
    if (empty($draft['linkedCars']) || !is_array($draft['linkedCars'])) {
        return 'needs_data';
    }
    foreach (['possible_false_promise', 'condition_not_supported', 'no_matching_cars', 'not_relevant_for_car_rental', 'unsupported_legal_request'] as $critical) {
        if (in_array($critical, $riskFlags, true)) {
            return 'risky';
        }
    }
    if (in_array('no_price_data', $riskFlags, true) || in_array('no_deposit_data', $riskFlags, true) || in_array('needs_human_review', $riskFlags, true)) {
        return 'needs_human_review';
    }

    return 'ready_for_review';
}

function demand_build_landing_page_draft(array $keyword, array $recommendation): array
{
    $linkedCars = is_array($recommendation['linkedCars'] ?? null) ? array_values($recommendation['linkedCars']) : [];
    $cars = array_values(array_filter(array_map(static fn(string $slug): ?array => find_car($slug), $linkedCars)));
    $h1 = demand_landing_h1_for_keyword($keyword);
    $slug = demand_landing_slug_for_keyword($keyword);
    $carNames = array_values(array_filter(array_map(static fn(array $car): string => (string) ($car['name'] ?? ''), $cars)));
    $placeText = demand_landing_place_text((string) ($keyword['detectedCity'] ?? ''), (string) ($keyword['detectedRegion'] ?? ''));
    $riskFlags = is_array($recommendation['riskFlags'] ?? null) ? $recommendation['riskFlags'] : [];
    $stageC = is_array($recommendation['safeContentBlocks'] ?? null)
        ? [
            'userQuestionMap' => (array) ($recommendation['userQuestionMap'] ?? []),
            'safeContentBlocks' => (array) ($recommendation['safeContentBlocks'] ?? []),
            'contentGapReport' => (array) ($recommendation['contentGapReport'] ?? []),
            'firstScreenAnswer' => (string) ($recommendation['firstScreenAnswer'] ?? ''),
            'mustAnswer' => (array) ($recommendation['mustAnswer'] ?? []),
            'mustNotPromise' => (array) ($recommendation['mustNotPromise'] ?? []),
            'recommendedFaq' => (array) ($recommendation['recommendedFaq'] ?? []),
            'recommendedInternalLinks' => (array) ($recommendation['recommendedInternalLinks'] ?? []),
            'recommendedCarCardHints' => (array) ($recommendation['recommendedCarCardHints'] ?? []),
            'userClarityScore' => (array) ($recommendation['userClarityScore'] ?? []),
            'aiSearchReadiness' => (array) ($recommendation['aiSearchReadiness'] ?? []),
        ]
        : demand_stage_c_analyze_keyword($keyword, [
            'cars' => $cars,
            'stageB' => is_array($recommendation['pageRiskProfile'] ?? null) ? [
                'riskFlags' => $riskFlags,
                'pageRiskProfile' => $recommendation['pageRiskProfile'],
                'priorityLevel' => (string) ($recommendation['priorityLevel'] ?? ''),
            ] : ['riskFlags' => $riskFlags],
        ]);
    $intro = trim((string) ($stageC['firstScreenAnswer'] ?? '')) !== ''
        ? (string) $stageC['firstScreenAnswer']
        : 'Черновик отвечает на запрос "' . (string) ($keyword['phrase'] ?? '') . '". В блоках используются только данные текущего автопарка; публикация возможна только после ручной проверки.';
    $contentBlocks = demand_stage_c_content_blocks_for_draft($stageC, $cars);
    if (!$contentBlocks) {
        $contentBlocks = [
            [
                'type' => 'who_is_it_for',
                'visibility' => 'public',
                'title' => 'Кому подойдёт',
                'body' => 'Подойдёт тем, кто ищет подтверждённый вариант аренды под конкретный сценарий поездки. Формулировки нужно сверить с реальными условиями перед публикацией.',
            ],
            [
                'type' => 'available_cars',
                'visibility' => 'public',
                'title' => 'Какие авто подходят',
                'body' => $carNames ? 'Связанные авто: ' . implode(', ', $carNames) . '.' : 'Подходящие автомобили не подтверждены, нужен ручной разбор.',
            ],
            [
                'type' => 'conditions',
                'visibility' => 'public',
                'title' => 'Что важно знать перед арендой',
                'body' => 'Документы, цена, залог, подача и срок аренды должны браться из карточек авто и действующих правил Rent RK. Если данных нет, менеджер уточняет условия вручную.',
            ],
        ];
    }
    $draft = [
        'id' => 'lpd_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'scope_id' => demand_normalize_scope_id((string) ($keyword['scope_id'] ?? 'rent_rk')),
        'sourceKeywordIds' => [(string) ($keyword['id'] ?? '')],
        'slug' => $slug,
        'title' => $h1 . ' - Rent RK',
        'h1' => $h1,
        'metaDescription' => 'Черновик: подбор автомобилей' . $placeText . '. Цены, залог и подача проверяются по карточкам и менеджером перед публикацией.',
        'intro' => $intro,
        'ctaText' => 'Оставьте даты и пожелания — менеджер проверит доступные авто и условия перед бронированием.',
        'contentBlocks' => $contentBlocks,
        'linkedCars' => $linkedCars,
        'internalLinks' => [],
        'linkedRecommendations' => [(string) ($recommendation['id'] ?? '')],
        'userQuestionMap' => (array) ($stageC['userQuestionMap'] ?? []),
        'safeContentBlocks' => (array) ($stageC['safeContentBlocks'] ?? []),
        'contentGapReport' => (array) ($stageC['contentGapReport'] ?? []),
        'mustAnswer' => (array) ($stageC['mustAnswer'] ?? []),
        'mustNotPromise' => (array) ($stageC['mustNotPromise'] ?? []),
        'recommendedFaq' => (array) ($stageC['recommendedFaq'] ?? []),
        'recommendedInternalLinks' => (array) ($stageC['recommendedInternalLinks'] ?? []),
        'recommendedCarCardHints' => (array) ($stageC['recommendedCarCardHints'] ?? []),
        'userClarityScore' => (array) ($stageC['userClarityScore'] ?? []),
        'aiSearchReadiness' => (array) ($stageC['aiSearchReadiness'] ?? []),
        'adminNote' => 'Stage C: перед публикацией проверить факты, наличие авто, цену, залог, подачу и запреты: ' . implode('; ', array_slice((array) ($stageC['mustNotPromise'] ?? []), 0, 4)),
        'publishStatus' => 'draft',
        'indexStatus' => 'blocked',
        'qualityStatus' => 'needs_review',
        'createdBy' => current_admin_user() ?: 'system',
        'reviewedBy' => null,
        'createdAt' => now_iso(),
        'updatedAt' => now_iso(),
    ];
    $draft['qualityStatus'] = demand_draft_quality_status($draft, $riskFlags);
    $draft['internalLinkSuggestions'] = demand_suggest_internal_links_for_draft($draft);

    return $draft;
}

function demand_create_landing_page_draft(string $recommendationId): array
{
    $recommendation = demand_find_recommendation($recommendationId);
    if (!$recommendation) {
        throw new RuntimeException('Рекомендация не найдена.');
    }
    demand_scope_guard($recommendation, 'demand.drafts.create');

    if ((string) ($recommendation['recommendationType'] ?? '') !== 'create_landing_page_draft') {
        throw new RuntimeException('Черновик можно создать только из рекомендации "создать черновик страницы".');
    }
    foreach (['possible_false_promise', 'condition_not_supported', 'no_matching_cars', 'not_relevant_for_car_rental', 'unsupported_legal_request'] as $blockedFlag) {
        if (in_array($blockedFlag, (array) ($recommendation['riskFlags'] ?? []), true)) {
            throw new RuntimeException('Черновик заблокирован риск-флагом: ' . $blockedFlag);
        }
    }
    $keyword = demand_find_keyword((string) ($recommendation['keywordId'] ?? ''));
    if (!$keyword) {
        throw new RuntimeException('Связанный ключевой запрос не найден.');
    }

    $draft = demand_build_landing_page_draft($keyword, $recommendation);
    $data = read_landing_page_drafts();
    foreach ($data['items'] as $existing) {
        if (!is_array($existing)) {
            continue;
        }
        if ((string) ($existing['slug'] ?? '') === $draft['slug'] && !in_array((string) ($existing['publishStatus'] ?? ''), ['archived', 'merged'], true)) {
            throw new RuntimeException('Черновик с таким slug уже существует.');
        }
    }
    $data['items'][] = $draft;
    save_landing_page_drafts($data);
    demand_update_recommendation_status($recommendationId, 'draft_created');
    demand_append_lifecycle_event((string) $draft['scope_id'], 'landing_page_draft', (string) $draft['id'], 'draft_created', 'Создан черновик посадочной страницы на основе спроса.');
    audit_log('landing_page_draft_created', 'landing_page_draft', (string) $draft['id'], 'Создан черновик посадочной страницы', [
        'scope_id' => (string) $draft['scope_id'],
        'keywordId' => (string) ($keyword['id'] ?? ''),
        'recommendationId' => $recommendationId,
        'indexStatus' => 'blocked',
    ]);
    analytics_record_event('landing_page_draft_created', [
        'scopeId' => (string) $draft['scope_id'],
        'entityType' => 'landing_page_draft',
        'entityId' => (string) $draft['id'],
        'meta' => ['keywordId' => (string) ($keyword['id'] ?? '')],
    ]);

    return $draft;
}

function demand_allowed_publish_statuses(): array
{
    return [
        'idea',
        'draft',
        'needs_review',
        'approved_for_public_preview',
        'approved_for_future_publication',
        'published_noindex',
        'ready_for_index_review',
        'published_indexed',
        'archived',
        'merged',
        'rolled_back',
    ];
}

function demand_allowed_index_statuses(): array
{
    return ['blocked', 'noindex', 'not_in_sitemap', 'index_allowed', 'in_sitemap', 'removed_from_sitemap'];
}

function demand_allowed_quality_statuses(): array
{
    return ['ready_for_review', 'needs_data', 'needs_human_review', 'risky', 'approved', 'rejected', 'archived'];
}

function demand_public_publish_statuses(): array
{
    return ['published_noindex', 'ready_for_index_review', 'published_indexed'];
}

function demand_refresh_draft_cars_allowed_statuses(): array
{
    return ['idea', 'draft', 'needs_review', 'approved_for_public_preview', 'approved_for_future_publication'];
}

function demand_indexed_publish_statuses(): array
{
    return ['published_indexed'];
}

function demand_landing_snapshot(array $draft): array
{
    $fields = [
        'slug',
        'title',
        'h1',
        'metaDescription',
        'intro',
        'ctaText',
        'contentBlocks',
        'linkedCars',
        'internalLinks',
        'internalLinkSuggestions',
        'linkedRecommendations',
        'sourceKeywordIds',
        'publishStatus',
        'indexStatus',
        'qualityStatus',
        'riskFlags',
        'userQuestionMap',
        'safeContentBlocks',
        'contentGapReport',
        'mustAnswer',
        'mustNotPromise',
        'recommendedFaq',
        'recommendedInternalLinks',
        'recommendedCarCardHints',
        'userClarityScore',
        'aiSearchReadiness',
        'reviewNotes',
        'targetPageId',
        'targetUrl',
    ];
    $snapshot = [];
    foreach ($fields as $field) {
        if (array_key_exists($field, $draft)) {
            $snapshot[$field] = $draft[$field];
        }
    }

    return $snapshot;
}

function demand_create_landing_page_version(array $draft, string $reason, string $createdBy = ''): array
{
    $data = read_landing_page_versions();
    $version = [
        'id' => 'lpv_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'scope_id' => demand_normalize_scope_id((string) ($draft['scope_id'] ?? 'rent_rk')),
        'landingPageDraftId' => (string) ($draft['id'] ?? ''),
        'snapshot' => demand_landing_snapshot($draft),
        'reason' => $reason,
        'createdBy' => $createdBy !== '' ? $createdBy : (current_admin_user() ?: 'system'),
        'createdAt' => now_iso(),
    ];
    array_unshift($data['items'], $version);
    $data['items'] = array_slice($data['items'], 0, 10000);
    save_landing_page_versions($data);

    demand_append_lifecycle_event(
        (string) $version['scope_id'],
        'landing_page_draft',
        (string) $version['landingPageDraftId'],
        'rollback_created',
        'Создан снимок версии посадочной страницы.',
        (string) $version['createdBy'],
        ['reason' => $reason, 'versionId' => (string) $version['id']]
    );

    return $version;
}

function demand_versions_for_draft(string $draftId): array
{
    return array_values(array_filter(
        read_landing_page_versions()['items'],
        static fn($item): bool => is_array($item) && (string) ($item['landingPageDraftId'] ?? '') === $draftId
    ));
}

function demand_lifecycle_for_draft(string $draftId): array
{
    return array_values(array_filter(
        read_seo_page_lifecycle()['items'],
        static fn($item): bool => is_array($item) && (string) ($item['entityId'] ?? '') === $draftId
    ));
}

function demand_update_draft_item(array $draft): array
{
    $draftId = (string) ($draft['id'] ?? '');
    if ($draftId === '') {
        throw new RuntimeException('Не указан id посадочной страницы.');
    }

    $data = read_landing_page_drafts();
    foreach ($data['items'] as $index => $item) {
        if (is_array($item) && (string) ($item['id'] ?? '') === $draftId) {
            $draft['updatedAt'] = now_iso();
            $data['items'][$index] = $draft;
            save_landing_page_drafts($data);
            return $draft;
        }
    }

    throw new RuntimeException('Черновик не найден.');
}

function demand_site_base_url(): string
{
    return 'https://rent-rk.ru';
}

function demand_public_landing_path(array $draft): string
{
    return '/landing.php?slug=' . rawurlencode((string) ($draft['slug'] ?? ''));
}

function demand_public_landing_url(array $draft): string
{
    return demand_site_base_url() . demand_public_landing_path($draft);
}

function demand_internal_link_statuses(): array
{
    return [
        'ready_public_link',
        'noindex_public_link',
        'draft_planned_link',
        'missing_target',
        'risky_or_irrelevant',
        'duplicate',
    ];
}

function demand_internal_link_relation_types(): array
{
    return [
        'city_page',
        'car_class',
        'car_card',
        'rental_conditions',
        'faq',
        'related_landing',
        'other',
    ];
}

function demand_internal_link_status_label(string $status): string
{
    return [
        'ready_public_link' => 'готовая публичная ссылка',
        'noindex_public_link' => 'публичная noindex-ссылка',
        'draft_planned_link' => 'планируемая связь',
        'missing_target' => 'цель не найдена',
        'risky_or_irrelevant' => 'сомнительная связь',
        'duplicate' => 'дубль',
    ][$status] ?? $status;
}

function demand_internal_link_relation_label(string $type): string
{
    return [
        'city_page' => 'Городская страница',
        'car_class' => 'Класс авто',
        'car_card' => 'Карточка автомобиля',
        'rental_conditions' => 'Условия аренды',
        'faq' => 'FAQ / справка',
        'related_landing' => 'Связанная посадочная',
        'other' => 'Другое',
    ][$type] ?? 'Другое';
}

function demand_internal_link_target_type_label(string $type): string
{
    return [
        'car' => 'Авто',
        'landing' => 'Посадочная',
        'static' => 'Страница',
        'planned' => 'План',
    ][$type] ?? 'Страница';
}

function demand_internal_link_safe_url($value): string
{
    $url = trim((string) $value);
    if ($url === '') {
        return '';
    }
    $url = str_replace(["\r", "\n", "\t"], '', $url);
    if (preg_match('~^(javascript|data|vbscript):~i', $url)) {
        return '';
    }
    if (preg_match('~^https?://~i', $url)) {
        $host = (string) (parse_url($url, PHP_URL_HOST) ?: '');
        if (!in_array(mb_strtolower($host, 'UTF-8'), ['rent-rk.ru', 'www.rent-rk.ru'], true)) {
            return '';
        }
        $path = (string) (parse_url($url, PHP_URL_PATH) ?: '/');
        $query = (string) (parse_url($url, PHP_URL_QUERY) ?: '');
        $url = $path . ($query !== '' ? '?' . $query : '');
    }
    if (!str_starts_with($url, '/') || str_starts_with($url, '//')) {
        return '';
    }
    if (preg_match('/[\s<>"\']/', $url)) {
        return '';
    }

    return demand_clean_string($url, 240);
}

function demand_internal_link_anchor_from_url(string $url): string
{
    $path = (string) (parse_url($url, PHP_URL_PATH) ?: $url);
    $base = basename($path, '.html');
    $base = trim(str_replace(['-', '_'], ' ', $base));

    return $base !== '' ? demand_clean_string($base, 120) : 'связанная страница';
}

function demand_internal_link_clean_anchor($value, string $fallback = ''): string
{
    $anchor = demand_clean_string($value, 120);
    $badAnchors = ['тут', 'здесь', 'подробнее', 'страница', 'ссылка'];
    if ($anchor === '' || in_array(demand_lower($anchor), $badAnchors, true)) {
        $anchor = demand_clean_string($fallback, 120);
    }

    return $anchor !== '' ? $anchor : 'связанная страница';
}

function demand_internal_link_normalize_status(string $status, string $url = ''): string
{
    $status = demand_clean_string($status, 80);
    if (!in_array($status, demand_internal_link_statuses(), true)) {
        $status = $url !== '' ? 'ready_public_link' : 'missing_target';
    }

    return $status;
}

function demand_internal_link_normalize_relation(string $type): string
{
    $type = demand_clean_string($type, 80);

    return in_array($type, demand_internal_link_relation_types(), true) ? $type : 'other';
}

function demand_internal_link_normalize_target_type(string $type): string
{
    $type = demand_clean_string($type, 40);

    return in_array($type, ['car', 'landing', 'static', 'planned'], true) ? $type : 'static';
}

function demand_normalize_internal_link($value, array $fallback = []): ?array
{
    if (is_string($value)) {
        $url = demand_internal_link_safe_url($value);
        if ($url === '') {
            return null;
        }
        $value = ['targetUrl' => $url];
    }
    if (!is_array($value)) {
        return null;
    }

    $url = demand_internal_link_safe_url($value['targetUrl'] ?? $value['url'] ?? $value['href'] ?? $fallback['targetUrl'] ?? '');
    $status = demand_internal_link_normalize_status((string) ($value['status'] ?? $fallback['status'] ?? ''), $url);
    if (in_array($status, ['draft_planned_link', 'missing_target', 'risky_or_irrelevant'], true) && $url === '') {
        $url = '';
    }
    $targetTitle = demand_clean_string($value['targetTitle'] ?? $value['title'] ?? $fallback['targetTitle'] ?? '', 160);
    $anchor = demand_internal_link_clean_anchor(
        $value['anchorText'] ?? $value['text'] ?? $value['linkText'] ?? '',
        $targetTitle !== '' ? $targetTitle : ($url !== '' ? demand_internal_link_anchor_from_url($url) : '')
    );
    if ($anchor === '' && $url === '' && !in_array($status, ['draft_planned_link', 'missing_target'], true)) {
        return null;
    }

    $targetType = demand_internal_link_normalize_target_type((string) ($value['targetType'] ?? $fallback['targetType'] ?? 'static'));
    $relationType = demand_internal_link_normalize_relation((string) ($value['relationType'] ?? $value['linkType'] ?? $fallback['relationType'] ?? 'other'));
    $safeToApply = array_key_exists('safeToApply', $value)
        ? !empty($value['safeToApply'])
        : in_array($status, ['ready_public_link', 'noindex_public_link'], true);

    return [
        'anchorText' => $anchor,
        'targetType' => $targetType,
        'targetId' => demand_clean_string($value['targetId'] ?? $fallback['targetId'] ?? '', 120),
        'targetUrl' => $url,
        'targetTitle' => $targetTitle !== '' ? $targetTitle : $anchor,
        'status' => $status,
        'relationType' => $relationType,
        'reason' => demand_clean_string($value['reason'] ?? $fallback['reason'] ?? '', 500),
        'placement' => demand_clean_string($value['placement'] ?? $fallback['placement'] ?? 'bottom_related', 80) ?: 'bottom_related',
        'safeToApply' => $safeToApply,
        'adminNote' => demand_clean_string($value['adminNote'] ?? $value['comment'] ?? $fallback['adminNote'] ?? '', 500),
        'source' => demand_clean_string($value['source'] ?? $fallback['source'] ?? 'manual', 80),
    ];
}

function demand_normalize_internal_links($values): array
{
    $links = [];
    $seen = [];
    foreach ((array) $values as $value) {
        $link = demand_normalize_internal_link($value);
        if (!$link) {
            continue;
        }
        $key = demand_internal_link_key($link);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $links[] = $link;
    }

    return $links;
}

function demand_internal_link_key(array $link): string
{
    $url = demand_internal_link_safe_url($link['targetUrl'] ?? '');
    if ($url !== '') {
        return 'url:' . demand_lower($url);
    }

    return 'planned:' . demand_lower((string) ($link['targetType'] ?? '') . '|' . (string) ($link['targetId'] ?? '') . '|' . (string) ($link['anchorText'] ?? ''));
}

function demand_internal_links_from_payload(array $payload, array $draft): array
{
    if (!empty($payload['internalLinksEditor'])) {
        $links = [];
        foreach ((array) ($payload['internalLinks'] ?? []) as $row) {
            if (!is_array($row) || !empty($row['remove'])) {
                continue;
            }
            $link = demand_normalize_internal_link($row);
            if ($link) {
                $links[] = $link;
            }
        }
        $new = [
            'anchorText' => $payload['newInternalLinkAnchor'] ?? '',
            'targetUrl' => $payload['newInternalLinkUrl'] ?? '',
            'relationType' => $payload['newInternalLinkRelationType'] ?? 'other',
            'adminNote' => $payload['newInternalLinkAdminNote'] ?? '',
            'targetType' => 'static',
            'status' => 'ready_public_link',
            'source' => 'manual',
            'reason' => 'Добавлено вручную в редакторе черновика.',
        ];
        if (trim((string) ($new['anchorText'] ?? '')) !== '' || trim((string) ($new['targetUrl'] ?? '')) !== '') {
            $link = demand_normalize_internal_link($new);
            if ($link) {
                $links[] = $link;
            }
        }

        return demand_normalize_internal_links($links);
    }
    if (array_key_exists('internalLinksInput', $payload)) {
        return demand_normalize_internal_links(demand_parse_string_list($payload['internalLinksInput'], 240));
    }

    return demand_normalize_internal_links($draft['internalLinks'] ?? []);
}

function demand_public_internal_links(array $draft): array
{
    $links = [];
    $seen = [];
    $draftIsIndexed = (string) ($draft['publishStatus'] ?? '') === 'published_indexed';
    foreach (demand_normalize_internal_links($draft['internalLinks'] ?? []) as $link) {
        $status = (string) ($link['status'] ?? '');
        if ($status !== 'ready_public_link' && !($status === 'noindex_public_link' && !$draftIsIndexed)) {
            continue;
        }
        $url = demand_internal_link_safe_url($link['targetUrl'] ?? '');
        if ($url === '') {
            continue;
        }
        $key = demand_lower($url);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $links[] = array_merge($link, ['targetUrl' => $url]);
        if (count($links) >= 5) {
            break;
        }
    }

    return $links;
}

function demand_internal_link_topic_text(array $draft): string
{
    $parts = [
        (string) ($draft['slug'] ?? ''),
        (string) ($draft['title'] ?? ''),
        (string) ($draft['h1'] ?? ''),
        (string) ($draft['intro'] ?? ''),
    ];
    foreach ((array) ($draft['recommendedInternalLinks'] ?? []) as $link) {
        if (is_array($link)) {
            $parts[] = (string) ($link['targetHint'] ?? '');
            $parts[] = (string) ($link['reason'] ?? '');
        }
    }

    return demand_normalize_phrase(implode(' ', $parts));
}

function demand_internal_link_relevance(array $candidate, array $draft): int
{
    $topicWords = demand_slug_words(demand_internal_link_topic_text($draft));
    $candidateWords = demand_slug_words((string) ($candidate['anchorText'] ?? '') . ' ' . (string) ($candidate['targetTitle'] ?? '') . ' ' . (string) ($candidate['targetUrl'] ?? ''));
    $score = count(array_intersect($topicWords, $candidateWords)) * 3;
    $url = demand_lower((string) ($candidate['targetUrl'] ?? ''));
    $title = demand_lower((string) ($candidate['targetTitle'] ?? '') . ' ' . (string) ($candidate['anchorText'] ?? ''));
    $topic = demand_internal_link_topic_text($draft);
    if ((string) ($candidate['targetType'] ?? '') === 'car' && in_array((string) ($candidate['targetId'] ?? ''), (array) ($draft['linkedCars'] ?? []), true)) {
        $score += 8;
    }
    if (str_contains($url, '/pages/conditions') || str_contains($title, 'услов')) {
        $score += str_contains($topic, 'залог') || str_contains($topic, 'документ') || str_contains($topic, 'услов') ? 7 : 3;
    }
    if (str_contains($url, '/pages/faq') || str_contains($title, 'faq') || str_contains($title, 'вопрос')) {
        $score += 4;
    }
    if (str_contains($url, '/cars/') || (string) ($candidate['targetType'] ?? '') === 'car') {
        $score += 4;
    }
    if ((string) ($candidate['status'] ?? '') === 'missing_target') {
        $score -= 4;
    }

    return $score;
}

function demand_internal_link_candidate(array $data, array $draft, array $existingKeys): array
{
    $link = demand_normalize_internal_link($data) ?: demand_normalize_internal_link([
        'anchorText' => $data['targetTitle'] ?? 'связанная страница',
        'targetType' => $data['targetType'] ?? 'static',
        'targetUrl' => $data['targetUrl'] ?? '',
        'status' => $data['status'] ?? 'missing_target',
    ]);
    $link = $link ?: [];
    $key = $link ? demand_internal_link_key($link) : '';
    if ($key !== '' && isset($existingKeys[$key])) {
        $link['status'] = 'duplicate';
        $link['safeToApply'] = false;
    }
    $link['score'] = demand_internal_link_relevance($link, $draft);

    return $link;
}

function demand_internal_link_static_candidates(array $draft, array $existingKeys): array
{
    $preferred = [
        '/pages/conditions.html' => ['anchor' => 'условия аренды автомобиля', 'relation' => 'rental_conditions'],
        '/pages/faq.html' => ['anchor' => 'вопросы по аренде автомобиля', 'relation' => 'faq'],
        '/cars/' => ['anchor' => 'каталог автомобилей Rent RK', 'relation' => 'car_class'],
        '/' => ['anchor' => 'аренда авто в Rent RK', 'relation' => 'other'],
    ];
    $candidates = [];
    foreach ($preferred as $url => $meta) {
        $path = PROJECT_ROOT . ltrim($url, '/');
        if ($url !== '/' && !is_file($path) && !is_dir(rtrim($path, '/'))) {
            continue;
        }
        $candidates[] = demand_internal_link_candidate([
            'anchorText' => $meta['anchor'],
            'targetType' => 'static',
            'targetUrl' => $url,
            'targetTitle' => $meta['anchor'],
            'status' => 'ready_public_link',
            'relationType' => $meta['relation'],
            'reason' => 'Помогает закрыть частый вопрос клиента без служебного текста на лендинге.',
            'placement' => 'bottom_related',
            'source' => 'ai_suggested_internal_link',
        ], $draft, $existingKeys);
    }
    foreach (demand_existing_pages() as $page) {
        $url = '/' . ltrim((string) ($page['path'] ?? ''), '/');
        if ($url === '/' || isset($preferred[$url])) {
            continue;
        }
        $title = demand_clean_string($page['title'] ?? demand_internal_link_anchor_from_url($url), 140);
        $candidates[] = demand_internal_link_candidate([
            'anchorText' => $title,
            'targetType' => 'static',
            'targetUrl' => $url,
            'targetTitle' => $title,
            'status' => 'ready_public_link',
            'relationType' => str_contains($url, 'faq') ? 'faq' : (str_contains($url, 'conditions') ? 'rental_conditions' : 'other'),
            'reason' => 'Статическая публичная страница может закрыть смежный вопрос клиента.',
            'placement' => 'bottom_related',
            'source' => 'ai_suggested_internal_link',
        ], $draft, $existingKeys);
    }

    return $candidates;
}

function demand_internal_link_car_candidates(array $draft, array $existingKeys): array
{
    $candidates = [];
    $linked = array_flip(array_map('strval', (array) ($draft['linkedCars'] ?? [])));
    foreach (read_cars() as $car) {
        if (!is_array($car) || !public_car_visible_for_api($car)) {
            continue;
        }
        $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
        if ($slug === '') {
            continue;
        }
        $name = demand_clean_string($car['name'] ?? car_name($slug), 140);
        $reason = isset($linked[$slug])
            ? 'Автомобиль уже связан с черновиком и подходит как готовая public-ссылка.'
            : 'Публичная карточка автомобиля может быть смежным вариантом для клиента.';
        $candidates[] = demand_internal_link_candidate([
            'anchorText' => $name,
            'targetType' => 'car',
            'targetId' => $slug,
            'targetUrl' => '/cars/' . rawurlencode($slug) . '.html',
            'targetTitle' => $name,
            'status' => 'ready_public_link',
            'relationType' => 'car_card',
            'reason' => $reason,
            'placement' => 'cars_section',
            'source' => 'ai_suggested_internal_link',
        ], $draft, $existingKeys);
        if (count($candidates) >= 14) {
            break;
        }
    }

    return $candidates;
}

function demand_internal_link_landing_candidates(array $draft, array $existingKeys): array
{
    $candidates = [];
    $currentId = (string) ($draft['id'] ?? '');
    foreach (read_landing_page_drafts()['items'] as $item) {
        if (!is_array($item) || (string) ($item['id'] ?? '') === $currentId) {
            continue;
        }
        $status = (string) ($item['publishStatus'] ?? 'draft');
        if (in_array($status, ['archived', 'merged', 'rolled_back'], true)) {
            continue;
        }
        $publicStatus = in_array($status, demand_public_publish_statuses(), true);
        $linkStatus = $publicStatus
            ? ($status === 'published_indexed' ? 'ready_public_link' : 'noindex_public_link')
            : 'draft_planned_link';
        $title = demand_clean_string($item['h1'] ?? $item['title'] ?? $item['slug'] ?? '', 160);
        $candidates[] = demand_internal_link_candidate([
            'anchorText' => $title,
            'targetType' => $publicStatus ? 'landing' : 'planned',
            'targetId' => (string) ($item['id'] ?? ''),
            'targetUrl' => $publicStatus ? demand_public_landing_path($item) : '',
            'targetTitle' => $title,
            'status' => $linkStatus,
            'relationType' => 'related_landing',
            'reason' => $publicStatus
                ? 'Связанная посадочная уже имеет публичный URL.'
                : 'Цель пока черновик: связь можно сохранить как план, но не выводить публично.',
            'placement' => 'bottom_related',
            'source' => 'ai_suggested_internal_link',
        ], $draft, $existingKeys);
    }

    return $candidates;
}

function demand_internal_link_recommended_candidates(array $draft, array $existingKeys): array
{
    $candidates = [];
    foreach ((array) ($draft['recommendedInternalLinks'] ?? []) as $item) {
        if (!is_array($item)) {
            continue;
        }
        $hint = demand_clean_string($item['targetHint'] ?? '', 160);
        if ($hint === '') {
            continue;
        }
        $candidates[] = demand_internal_link_candidate([
            'anchorText' => $hint,
            'targetType' => 'planned',
            'targetId' => '',
            'targetUrl' => '',
            'targetTitle' => $hint,
            'status' => 'missing_target',
            'relationType' => demand_internal_link_normalize_relation((string) ($item['linkType'] ?? 'other')),
            'reason' => demand_clean_string($item['reason'] ?? 'Stage C рекомендует связь, но реальная публичная цель не найдена.', 500),
            'placement' => 'bottom_related',
            'safeToApply' => false,
            'source' => 'stage_c_recommended_internal_link',
        ], $draft, $existingKeys);
    }

    return $candidates;
}

function demand_suggest_internal_links_for_draft(array $draft): array
{
    $existing = demand_normalize_internal_links($draft['internalLinks'] ?? []);
    $existingKeys = [];
    foreach ($existing as $link) {
        $existingKeys[demand_internal_link_key($link)] = true;
    }

    $candidates = array_merge(
        demand_internal_link_car_candidates($draft, $existingKeys),
        demand_internal_link_landing_candidates($draft, $existingKeys),
        demand_internal_link_static_candidates($draft, $existingKeys),
        demand_internal_link_recommended_candidates($draft, $existingKeys)
    );
    $seen = [];
    $suggestions = [];
    foreach ($candidates as $candidate) {
        if (!$candidate) {
            continue;
        }
        $key = demand_internal_link_key($candidate);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $suggestions[] = $candidate;
    }
    $statusOrder = [
        'ready_public_link' => 0,
        'noindex_public_link' => 1,
        'draft_planned_link' => 2,
        'missing_target' => 3,
        'risky_or_irrelevant' => 4,
        'duplicate' => 5,
    ];
    usort($suggestions, static function (array $a, array $b) use ($statusOrder): int {
        $statusCompare = ($statusOrder[(string) ($a['status'] ?? '')] ?? 9) <=> ($statusOrder[(string) ($b['status'] ?? '')] ?? 9);
        if ($statusCompare !== 0) {
            return $statusCompare;
        }

        return ((int) ($b['score'] ?? 0)) <=> ((int) ($a['score'] ?? 0));
    });
    $balanced = [];
    foreach ([
        'ready_public_link' => 6,
        'noindex_public_link' => 2,
        'draft_planned_link' => 2,
        'missing_target' => 2,
        'duplicate' => 2,
        'risky_or_irrelevant' => 2,
    ] as $status => $limit) {
        foreach ($suggestions as $suggestion) {
            if ((string) ($suggestion['status'] ?? '') !== $status) {
                continue;
            }
            $balanced[] = $suggestion;
            if (count(array_filter($balanced, static fn(array $item): bool => (string) ($item['status'] ?? '') === $status)) >= $limit) {
                break;
            }
        }
    }
    $suggestions = array_values(array_map(static function (array $item): array {
        unset($item['score']);

        return $item;
    }, array_slice($balanced, 0, 14)));
    $safe = array_values(array_filter($suggestions, static fn(array $item): bool => !empty($item['safeToApply']) && in_array((string) ($item['status'] ?? ''), ['ready_public_link', 'noindex_public_link'], true)));

    return [
        'summary' => $safe
            ? 'AI подобрал безопасные варианты внутренних ссылок. Добавление в существующий черновик выполняется только после подтверждения.'
            : 'Готовых public-ссылок не найдено. Есть планируемые связи или цели, которые сначала нужно создать.',
        'internalLinkSuggestions' => $suggestions,
        'publicBlockProposal' => [
            'title' => 'Также может подойти',
            'intro' => 'Если вы ещё выбираете формат поездки, посмотрите похожие варианты.',
            'links' => array_slice($safe, 0, 5),
        ],
        'adminNotes' => [
            'Draft/planned links не выводятся на публичной странице как href.',
            'Публикация, индексация, sitemap.xml и robots.txt не меняются.',
        ],
        'mustCheckBeforeApply' => [
            'Проверьте, что anchor text не обещает неподтверждённые условия.',
            'Для indexed-страницы noindex-ссылки лучше проверить вручную.',
        ],
        'notAllowed' => [
            'Нельзя добавлять ссылки на несуществующие публичные страницы как реальные href.',
            'Нельзя менять publishStatus, indexStatus, sitemap.xml или robots.txt.',
        ],
    ];
}

function demand_apply_internal_link_suggestions(string $draftId, array $suggestions, array $selectedIndexes = [], string $mode = 'selected', string $adminUser = ''): array
{
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.drafts.edit');

    $selected = [];
    if ($mode === 'all_safe') {
        foreach ($suggestions as $suggestion) {
            if (is_array($suggestion) && !empty($suggestion['safeToApply']) && in_array((string) ($suggestion['status'] ?? ''), ['ready_public_link', 'noindex_public_link'], true)) {
                $selected[] = $suggestion;
            }
        }
    } else {
        $indexMap = array_fill_keys(array_map('intval', $selectedIndexes), true);
        foreach ($suggestions as $index => $suggestion) {
            if (isset($indexMap[(int) $index]) && is_array($suggestion) && !empty($suggestion['safeToApply'])) {
                $selected[] = $suggestion;
            }
        }
    }
    $current = demand_normalize_internal_links($draft['internalLinks'] ?? []);
    $keys = [];
    foreach ($current as $link) {
        $keys[demand_internal_link_key($link)] = true;
    }
    $added = [];
    foreach ($selected as $suggestion) {
        $link = demand_normalize_internal_link($suggestion, ['source' => 'ai_suggested_internal_link']);
        if (!$link || !in_array((string) ($link['status'] ?? ''), ['ready_public_link', 'noindex_public_link'], true)) {
            continue;
        }
        $key = demand_internal_link_key($link);
        if (isset($keys[$key])) {
            continue;
        }
        $keys[$key] = true;
        $link['source'] = 'ai_suggested_internal_link';
        $link['createdAt'] = now_iso();
        $added[] = $link;
    }
    if (!$added) {
        throw new RuntimeException('Нет выбранных безопасных ссылок для добавления.');
    }

    if (in_array((string) ($draft['publishStatus'] ?? ''), demand_public_publish_statuses(), true)) {
        demand_create_landing_page_version($draft, 'before_internal_links_update');
    }
    $draft['internalLinks'] = array_values(array_merge($current, $added));
    $draft['readinessStatus'] = 'not_checked';
    $draft['readinessChecks'] = [];
    $draft['lastReadinessCheckAt'] = null;
    $draft['updatedAt'] = now_iso();
    $updated = demand_update_draft_item($draft);
    $actor = $adminUser !== '' ? $adminUser : (current_admin_user() ?: 'system');
    demand_append_lifecycle_event(
        (string) ($draft['scope_id'] ?? 'rent_rk'),
        'landing_page_draft',
        $draftId,
        'internal_links_applied',
        'Добавлены внутренние ссылки после подтверждения admin. Публикация, индексация, sitemap и robots не менялись.',
        $actor,
        ['addedCount' => count($added)]
    );
    analytics_record_event('landing_page_internal_links_applied', [
        'scopeId' => (string) ($draft['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
        'meta' => [
            'addedCount' => count($added),
            'publishStatus' => (string) ($draft['publishStatus'] ?? ''),
            'indexStatus' => (string) ($draft['indexStatus'] ?? ''),
        ],
    ]);

    return [
        'draft' => $updated,
        'added' => $added,
        'changed' => true,
    ];
}

function demand_scope_exists(string $scopeId): bool
{
    $scopeId = demand_normalize_scope_id($scopeId);
    if ($scopeId === 'rent_rk') {
        return true;
    }
    foreach (scope_list() as $scope) {
        if (demand_normalize_scope_id((string) ($scope['scope_id'] ?? '')) === $scopeId) {
            return true;
        }
    }

    return false;
}

function demand_landing_text(array $draft): string
{
    $parts = [
        (string) ($draft['slug'] ?? ''),
        (string) ($draft['title'] ?? ''),
        (string) ($draft['h1'] ?? ''),
        (string) ($draft['metaDescription'] ?? ''),
        (string) ($draft['intro'] ?? ''),
    ];
    foreach ((array) ($draft['contentBlocks'] ?? []) as $block) {
        if (!is_array($block)) {
            continue;
        }
        $parts[] = (string) ($block['title'] ?? '');
        $parts[] = (string) ($block['body'] ?? '');
        foreach ((array) ($block['items'] ?? []) as $item) {
            if (is_array($item)) {
                $parts[] = (string) ($item['question'] ?? '');
                $parts[] = (string) ($item['answer'] ?? '');
            }
        }
    }

    return demand_normalize_landing_text(implode(' ', $parts));
}

function demand_landing_source_keywords(array $draft): array
{
    $keywords = [];
    foreach ((array) ($draft['sourceKeywordIds'] ?? []) as $keywordId) {
        $keyword = demand_find_keyword((string) $keywordId);
        if ($keyword) {
            $keywords[] = $keyword;
        }
    }

    return $keywords;
}

function demand_landing_contains_no_deposit_promise(array $draft): bool
{
    if (str_contains(demand_landing_text($draft), 'без залога')) {
        return true;
    }
    foreach (demand_landing_source_keywords($draft) as $keyword) {
        if (str_contains(demand_normalize_phrase((string) ($keyword['phrase'] ?? '')), 'без залога')) {
            return true;
        }
    }

    return false;
}

function demand_landing_no_deposit_confirmed(array $draft): bool
{
    $linkedCars = array_values(array_filter(array_map('strval', (array) ($draft['linkedCars'] ?? []))));
    if (!$linkedCars) {
        return false;
    }
    foreach ($linkedCars as $slug) {
        $car = find_car($slug);
        if (!$car || demand_car_deposit_state($car) !== 'no_deposit') {
            return false;
        }
    }

    return true;
}

function demand_landing_existing_route_conflicts(string $slug): array
{
    $slug = trim($slug);
    if ($slug === '') {
        return [];
    }

    $paths = [
        PROJECT_ROOT . $slug . '.html',
        PROJECT_ROOT . 'pages/' . $slug . '.html',
        PROJECT_ROOT . 'routes/' . $slug . '.html',
        PROJECT_ROOT . 'cars/' . $slug . '.html',
        PROJECT_ROOT . $slug . '/index.html',
    ];
    $conflicts = [];
    foreach ($paths as $path) {
        if (is_file($path)) {
            $conflicts[] = str_replace('\\', '/', substr($path, strlen(PROJECT_ROOT)));
        }
    }

    foreach (demand_sitemap_locs() as $loc) {
        $path = (string) (parse_url($loc, PHP_URL_PATH) ?: '');
        $query = (string) (parse_url($loc, PHP_URL_QUERY) ?: '');
        if ($path === '/pages/' . $slug . '.html' || $path === '/routes/' . $slug . '.html' || ($path === '/landing.php' && $query === 'slug=' . rawurlencode($slug))) {
            $conflicts[] = $loc;
        }
    }

    return demand_unique_strings($conflicts);
}

function demand_landing_slug_is_unique(array $draft): bool
{
    $draftId = (string) ($draft['id'] ?? '');
    $slug = (string) ($draft['slug'] ?? '');
    foreach (read_landing_page_drafts()['items'] as $item) {
        if (!is_array($item) || (string) ($item['id'] ?? '') === $draftId) {
            continue;
        }
        if ((string) ($item['slug'] ?? '') === $slug && !in_array((string) ($item['publishStatus'] ?? ''), ['archived', 'merged', 'rolled_back'], true)) {
            return false;
        }
    }

    return demand_landing_existing_route_conflicts($slug) === [];
}

function demand_landing_is_duplicate(array $draft): bool
{
    $slug = (string) ($draft['slug'] ?? '');
    $h1 = demand_normalize_phrase((string) ($draft['h1'] ?? ''));
    $title = demand_normalize_phrase((string) ($draft['title'] ?? ''));
    foreach (demand_existing_pages() as $page) {
        $pageSlug = basename((string) ($page['path'] ?? ''), '.html');
        $pageTitle = demand_normalize_phrase((string) ($page['title'] ?? ''));
        if ($pageSlug === $slug || ($pageTitle !== '' && ($pageTitle === $h1 || $pageTitle === $title))) {
            return true;
        }
    }

    return false;
}

function demand_landing_risk_flags(array $draft): array
{
    $flags = (array) ($draft['riskFlags'] ?? []);
    foreach ((array) ($draft['linkedRecommendations'] ?? []) as $recommendationId) {
        $recommendation = demand_find_recommendation((string) $recommendationId);
        if ($recommendation) {
            $flags = array_merge($flags, (array) ($recommendation['riskFlags'] ?? []));
        }
    }

    return demand_unique_strings(array_map('strval', $flags));
}

function demand_landing_critical_risk_flags(array $draft): array
{
    $critical = ['possible_false_promise', 'condition_not_supported', 'no_matching_cars', 'too_similar_to_existing_page', 'not_relevant_for_car_rental', 'unsupported_legal_request'];
    return array_values(array_intersect(demand_landing_risk_flags($draft), $critical));
}

function demand_landing_has_content(array $draft): bool
{
    foreach ((array) ($draft['contentBlocks'] ?? []) as $block) {
        if (!is_array($block)) {
            continue;
        }
        if (trim((string) ($block['body'] ?? '')) !== '' || (is_array($block['items'] ?? null) && $block['items'])) {
            return true;
        }
    }

    return false;
}

function demand_transition_checks(array $draft, string $target): array
{
    $errors = [];
    $warnings = [];
    $publishStatus = (string) ($draft['publishStatus'] ?? 'draft');
    $indexStatus = (string) ($draft['indexStatus'] ?? 'blocked');
    $qualityStatus = (string) ($draft['qualityStatus'] ?? 'needs_human_review');
    $linkedCars = array_values(array_filter(array_map('strval', (array) ($draft['linkedCars'] ?? []))));

    if (trim((string) ($draft['slug'] ?? '')) === '') {
        $errors[] = 'Slug заполнен не был.';
    }
    if (!demand_landing_slug_is_unique($draft)) {
        $errors[] = 'Slug или публичный URL конфликтует с существующей страницей.';
    }
    if (trim((string) ($draft['h1'] ?? '')) === '') {
        $errors[] = 'H1 не заполнен.';
    }
    if (trim((string) ($draft['title'] ?? '')) === '') {
        $errors[] = 'Title не заполнен.';
    }
    if (trim((string) ($draft['intro'] ?? '')) === '') {
        $errors[] = 'Intro не заполнен.';
    }
    if (!demand_landing_has_content($draft)) {
        $errors[] = 'Нет полезных contentBlocks.';
    }
    if (!$linkedCars && trim((string) ($draft['informationReason'] ?? '')) === '') {
        $errors[] = 'Нет связанных авто и нет обоснования информационной страницы.';
    }
    if (!demand_scope_exists((string) ($draft['scope_id'] ?? 'rent_rk'))) {
        $errors[] = 'Контур страницы не найден.';
    }
    foreach (demand_landing_critical_risk_flags($draft) as $flag) {
        $errors[] = 'Критический riskFlag: ' . $flag . '.';
    }
    if (demand_landing_contains_no_deposit_promise($draft) && !demand_landing_no_deposit_confirmed($draft)) {
        $errors[] = 'Фраза содержит обещание "без залога", но связанные авто не подтверждают аренду без залога.';
    }
    $text = demand_landing_text($draft);
    if ((str_contains($text, 'дешево') || str_contains($text, 'недорого')) && preg_match('~(сам(ая|ые|ый)?\\s+низк|лучша(я|ие)?\\s+цен)~u', $text)) {
        $errors[] = 'Текст обещает самую низкую цену без подтверждения.';
    }
    if (demand_landing_is_duplicate($draft)) {
        $errors[] = 'Страница похожа на существующую страницу или использует занятый slug.';
    }

    if ($target === 'published_noindex') {
        if (!in_array($publishStatus, ['approved_for_public_preview', 'approved_for_future_publication'], true)) {
            $errors[] = 'Перед публикацией для просмотра страница должна быть одобрена.';
        }
        if ($qualityStatus !== 'approved') {
            $warnings[] = 'Качество будет переведено в approved только после ручного одобрения.';
        }
        if (demand_sitemap_contains(demand_public_landing_url($draft))) {
            $errors[] = 'Карта сайта для поисковиков уже содержит этот URL, хотя публикация для просмотра не должна её менять.';
        }
    }

    if ($target === 'published_indexed') {
        if (!in_array($publishStatus, ['published_noindex', 'ready_for_index_review'], true)) {
            $errors[] = 'Сначала страница должна быть опубликована для просмотра и закрыта от поиска.';
        }
        if ($qualityStatus !== 'approved') {
            $errors[] = 'Для открытия страницы в поиск нужен статус качества “одобрено”.';
        }
        if ($indexStatus !== 'noindex' && $indexStatus !== 'not_in_sitemap') {
            $warnings[] = 'Перед открытием для поиска страница должна быть закрыта от поиска или отсутствовать в карте сайта для поисковиков.';
        }
        if (!demand_public_landing_is_available($draft)) {
            $errors[] = 'Публичный URL недоступен по текущим статусам.';
        }
    }

    return ['ok' => !$errors, 'errors' => $errors, 'warnings' => $warnings];
}

function demand_readiness_has_faq(array $draft): bool
{
    foreach ((array) ($draft['contentBlocks'] ?? []) as $block) {
        if (!is_array($block)) {
            continue;
        }
        if ((string) ($block['type'] ?? '') === 'faq' && is_array($block['items'] ?? null) && count($block['items']) > 0) {
            return true;
        }
    }

    return false;
}

function demand_readiness_has_internal_links(array $draft): bool
{
    $text = (string) ($draft['intro'] ?? '') . ' ';
    foreach ((array) ($draft['contentBlocks'] ?? []) as $block) {
        if (!is_array($block)) {
            continue;
        }
        $text .= (string) ($block['body'] ?? '') . ' ';
        foreach ((array) ($block['items'] ?? []) as $item) {
            if (is_array($item)) {
                $text .= (string) ($item['question'] ?? '') . ' ' . (string) ($item['answer'] ?? '') . ' ';
            }
        }
    }

    return str_contains($text, '<a ') || str_contains($text, 'href=') || !empty(demand_public_internal_links($draft));
}

function demand_readiness_add_check(array &$checks, string $code, string $status, string $message): void
{
    $checks[] = [
        'code' => $code,
        'status' => $status,
        'message' => $message,
    ];
}

function demand_readiness_checks_for_draft(array $draft): array
{
    $checks = [];
    $linkedCars = array_values(array_filter(array_map('strval', (array) ($draft['linkedCars'] ?? []))));
    $text = demand_landing_text($draft);

    $h1Ok = trim((string) ($draft['h1'] ?? '')) !== '';
    demand_readiness_add_check($checks, 'has_h1', $h1Ok ? 'pass' : 'block', $h1Ok ? 'H1 заполнен.' : 'H1 не заполнен.');

    $titleOk = trim((string) ($draft['title'] ?? '')) !== '';
    demand_readiness_add_check($checks, 'has_title', $titleOk ? 'pass' : 'block', $titleOk ? 'SEO title заполнен.' : 'SEO title не заполнен.');

    $description = trim((string) ($draft['metaDescription'] ?? ''));
    demand_readiness_add_check($checks, 'has_description', $description !== '' ? 'pass' : 'block', $description !== '' ? 'Meta description заполнен.' : 'Meta description не заполнен.');
    if ($description !== '' && (function_exists('mb_strlen') ? mb_strlen($description, 'UTF-8') : strlen($description)) < 70) {
        demand_readiness_add_check($checks, 'weak_description', 'warn', 'Описание короткое: лучше добавить конкретику про авто, условия и город.');
    }

    $intro = trim((string) ($draft['intro'] ?? ''));
    demand_readiness_add_check($checks, 'has_intro', $intro !== '' ? 'pass' : 'block', $intro !== '' ? 'Intro заполнен.' : 'Intro не заполнен.');

    $hasContent = demand_landing_has_content($draft);
    demand_readiness_add_check($checks, 'has_content_blocks', $hasContent ? 'pass' : 'block', $hasContent ? 'Есть полезные контентные блоки.' : 'Нет полезных контентных блоков.');

    $hasCars = count($linkedCars) > 0;
    $informationOnly = trim((string) ($draft['informationReason'] ?? '')) !== '';
    demand_readiness_add_check($checks, 'has_linked_cars', ($hasCars || $informationOnly) ? 'pass' : 'block', $hasCars ? 'Связанные авто указаны.' : ($informationOnly ? 'Есть обоснование информационной страницы.' : 'Нет связанных авто для коммерческой страницы.'));

    $slugUnique = trim((string) ($draft['slug'] ?? '')) !== '' && demand_landing_slug_is_unique($draft);
    demand_readiness_add_check($checks, 'slug_unique', $slugUnique ? 'pass' : 'block', $slugUnique ? 'Slug уникален.' : 'Slug пустой или конфликтует с существующей страницей.');

    if (!demand_readiness_has_faq($draft)) {
        demand_readiness_add_check($checks, 'missing_faq', 'warn', 'FAQ не найден: добавьте короткие ответы на частые вопросы.');
    } else {
        demand_readiness_add_check($checks, 'has_faq', 'pass', 'FAQ есть.');
    }
    if (!str_contains($text, 'залог')) {
        demand_readiness_add_check($checks, 'missing_deposit_text', 'warn', 'Нет текста про залог: лучше объяснить, от чего он зависит.');
    }
    if (!str_contains($text, 'подач') && !str_contains($text, 'получ')) {
        demand_readiness_add_check($checks, 'missing_delivery_text', 'warn', 'Нет текста про подачу или получение авто.');
    }
    if (!demand_readiness_has_internal_links($draft)) {
        demand_readiness_add_check($checks, 'missing_internal_links', 'warn', 'Не найдены внутренние ссылки: стоит связать страницу с авто или близкими разделами.');
    }

    foreach (demand_landing_critical_risk_flags($draft) as $flag) {
        $message = match ($flag) {
            'possible_false_promise' => 'Есть риск ложного обещания: текст или запрос обещает условие, не подтвержденное данными.',
            'condition_not_supported' => 'Условие не подтверждено реальными данными автопарка.',
            'no_matching_cars' => 'Нет подходящих активных авто для этой страницы.',
            'too_similar_to_existing_page' => 'Страница похожа на существующую и может стать дублем.',
            default => 'Критический риск: ' . $flag . '.',
        };
        demand_readiness_add_check($checks, 'risk_' . $flag, 'block', $message);
    }
    if (demand_landing_contains_no_deposit_promise($draft) && !demand_landing_no_deposit_confirmed($draft)) {
        demand_readiness_add_check($checks, 'false_no_deposit_promise', 'block', 'Нельзя обещать аренду без залога, если залог указан или не подтвержден в условиях авто.');
    }
    if ((str_contains($text, 'дешево') || str_contains($text, 'недорого')) && preg_match('~(сам(ая|ые|ый)?\s+низк|лучша(я|ие)?\s+цен)~u', $text)) {
        demand_readiness_add_check($checks, 'false_lowest_price_promise', 'block', 'Нельзя обещать самую низкую цену без подтверждения.');
    }
    if (demand_landing_is_duplicate($draft)) {
        demand_readiness_add_check($checks, 'duplicate_page', 'block', 'Страница дублирует существующий маршрут или слишком похожую страницу.');
    }
    if (in_array('region_not_supported', demand_landing_risk_flags($draft), true)) {
        demand_readiness_add_check($checks, 'region_not_confirmed', 'block', 'Регион оказания услуги не подтвержден.');
    }

    return $checks;
}

function demand_readiness_status_from_checks(array $checks): string
{
    foreach ($checks as $check) {
        if (is_array($check) && (string) ($check['status'] ?? '') === 'block') {
            return 'blocked';
        }
    }
    foreach ($checks as $check) {
        if (is_array($check) && (string) ($check['status'] ?? '') === 'warn') {
            return 'needs_fixes';
        }
    }

    return 'ready';
}

function demand_group_readiness_checks(array $checks): array
{
    $groups = [
        'ready' => [],
        'needs_fixes' => [],
        'blocked' => [],
    ];
    foreach ($checks as $check) {
        if (!is_array($check)) {
            continue;
        }
        $status = (string) ($check['status'] ?? '');
        if ($status === 'block') {
            $groups['blocked'][] = $check;
        } elseif ($status === 'warn') {
            $groups['needs_fixes'][] = $check;
        } else {
            $groups['ready'][] = $check;
        }
    }

    return $groups;
}

function demand_update_draft_readiness(string $draftId, bool $requirePermission = true): array
{
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    if ($requirePermission) {
        demand_scope_guard($draft, 'demand.publish_wizard.manage');
    }

    $checks = demand_readiness_checks_for_draft($draft);
    $status = demand_readiness_status_from_checks($checks);
    $draft['readinessStatus'] = $status;
    $draft['readinessChecks'] = $checks;
    $draft['lastReadinessCheckAt'] = now_iso();
    $updated = demand_update_draft_item($draft);

    demand_append_lifecycle_event(
        (string) ($updated['scope_id'] ?? 'rent_rk'),
        'landing_page_draft',
        $draftId,
        'readiness_checked',
        'Проверена готовность посадочной страницы: ' . $status . '.',
        current_admin_user() ?: 'system',
        [
            'previousStatus' => (string) ($draft['publishStatus'] ?? ''),
            'newStatus' => (string) ($updated['publishStatus'] ?? ''),
        ]
    );
    analytics_record_event('readiness_checked', [
        'scopeId' => (string) ($updated['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
        'meta' => ['readinessStatus' => $status],
    ]);

    return $updated;
}

function demand_update_draft_admin_note(string $draftId, string $note): array
{
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.publish_wizard.manage');
    $draft['adminNote'] = demand_clean_string($note, 1000);
    $updated = demand_update_draft_item($draft);
    demand_append_lifecycle_event(
        (string) ($updated['scope_id'] ?? 'rent_rk'),
        'landing_page_draft',
        $draftId,
        'admin_note_updated',
        'Обновлена заметка admin по посадочной странице.',
        current_admin_user() ?: 'system',
        [
            'previousStatus' => (string) ($draft['publishStatus'] ?? ''),
            'newStatus' => (string) ($updated['publishStatus'] ?? ''),
        ]
    );
    analytics_record_event('admin_note_updated', [
        'scopeId' => (string) ($updated['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
    ]);

    return $updated;
}

function demand_simple_publish_stage(array $draft): array
{
    $publishStatus = (string) ($draft['publishStatus'] ?? 'draft');
    $readinessStatus = (string) ($draft['readinessStatus'] ?? 'not_checked');
    if (
        $readinessStatus === 'blocked'
        || (string) ($draft['qualityStatus'] ?? '') === 'rejected'
        || ($readinessStatus === 'needs_fixes' && in_array($publishStatus, ['idea', 'draft', 'needs_review', 'approved_for_public_preview', 'approved_for_future_publication'], true))
    ) {
        return [
            'key' => 'needs_fixes',
            'label' => 'Нужно исправить',
            'description' => 'Есть пункты готовности, которые нужно проверить перед публикацией.',
        ];
    }

    return match ($publishStatus) {
        'approved_for_public_preview', 'approved_for_future_publication' => [
            'key' => 'ready_preview',
            'label' => 'Готов к просмотру',
            'description' => 'Можно опубликовать страницу для просмотра: ссылка будет доступна, но карта сайта для поисковиков не изменится.',
        ],
        'published_noindex' => [
            'key' => 'noindex_preview',
            'label' => 'Опубликован для просмотра, поиску закрыт',
            'description' => 'Страница доступна по публичной ссылке, но закрыта от поиска и не добавлена в карту сайта для поисковиков.',
        ],
        'ready_for_index_review' => [
            'key' => 'ready_search',
            'label' => 'Готов к открытию для поиска',
            'description' => 'Admin Rent RK может вручную открыть страницу для поиска и добавить ее в карту сайта для поисковиков.',
        ],
        'published_indexed' => [
            'key' => 'search_open',
            'label' => 'Открыт для поиска',
            'description' => 'Страница открыта для поиска и добавлена в карту сайта для поисковиков.',
        ],
        'archived', 'rolled_back', 'merged' => [
            'key' => 'closed',
            'label' => 'Закрыт / архив',
            'description' => 'Страница не находится в активном запуске.',
        ],
        default => [
            'key' => 'draft',
            'label' => 'Черновик',
            'description' => 'Страница готовится в админке. Начните с проверки готовности.',
        ],
    };
}

function demand_readiness_label(string $status): string
{
    return match ($status) {
        'ready' => 'Готово',
        'needs_fixes' => 'Нужно дополнить',
        'blocked' => 'Блокирует публикацию',
        default => 'Не проверено',
    };
}

function demand_parse_string_list($value, int $maxLength = 160): array
{
    $raw = is_array($value) ? implode("\n", array_map('strval', $value)) : (string) $value;
    $parts = preg_split('/[\r\n,]+/u', $raw) ?: [];
    $result = [];
    foreach ($parts as $part) {
        $item = demand_clean_string($part, $maxLength);
        if ($item !== '') {
            $result[$item] = true;
        }
    }

    return array_values(array_keys($result));
}

function demand_parse_slug_list($value): array
{
    $result = [];
    foreach (demand_parse_string_list($value, 160) as $item) {
        $slug = normalize_car_slug($item);
        if ($slug !== '') {
            $result[$slug] = true;
        }
    }

    return array_values(array_keys($result));
}

function demand_parse_faq_items(string $lines): array
{
    $items = [];
    foreach (preg_split('/\r\n|\r|\n/u', $lines) ?: [] as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $parts = preg_split('/\s*\|\s*/u', $line, 2) ?: [];
        $question = demand_clean_string($parts[0] ?? '', 240);
        $answer = demand_clean_string($parts[1] ?? '', 1000);
        if ($question === '') {
            continue;
        }
        if ($answer === '') {
            $answer = 'Уточняется менеджером Rent RK.';
        }
        $items[] = [
            'question' => $question,
            'answer' => $answer,
        ];
    }

    return $items;
}

function demand_faq_items_to_lines(array $items): string
{
    $lines = [];
    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }
        $question = demand_clean_string((string) ($item['question'] ?? ''), 240);
        $answer = demand_clean_string((string) ($item['answer'] ?? ''), 1000);
        if ($question !== '') {
            $lines[] = $question . ' | ' . $answer;
        }
    }

    return implode("\n", $lines);
}

function demand_allowed_content_block_types(): array
{
    return [
        'intro_answer',
        'who_is_it_for',
        'available_cars',
        'conditions',
        'deposit_explanation',
        'price_explanation',
        'pickup_delivery',
        'airport_pickup',
        'family_use',
        'luggage_and_seats',
        'weekly_rental',
        'route_use',
        'comparison',
        'faq',
        'internal_links',
        'what_to_confirm_before_booking',
        'safety_limitations',
        'not_supported_explanation',
        'text',
    ];
}

function demand_allowed_content_block_visibility(): array
{
    return ['public', 'admin_only', 'technical'];
}

function demand_normalize_content_block_visibility(string $visibility, string $type = '', string $title = ''): string
{
    $visibility = demand_clean_string($visibility, 40);
    if (in_array($visibility, demand_allowed_content_block_visibility(), true)) {
        return $visibility;
    }

    $type = demand_clean_string($type, 80);
    $titleLower = function_exists('demand_lower') ? demand_lower($title) : mb_strtolower($title, 'UTF-8');
    if (in_array($type, ['internal_links', 'internal_linking'], true)) {
        return 'admin_only';
    }
    foreach ([
        'внутренние связи',
        'что должна объяснить страница',
        'чего не хватает',
        'рекомендуемые блоки',
        'готовность',
        'ai/search readiness',
        'content gap',
        'safe content blocks',
        'must answer',
        'must not promise',
        'recommended internal links',
    ] as $marker) {
        if ($marker !== '' && str_contains($titleLower, $marker)) {
            return 'admin_only';
        }
    }

    return 'public';
}

function demand_content_blocks_from_payload(array $payload, array $draft): array
{
    if (!isset($payload['contentBlocksEditor'])) {
        return (array) ($draft['contentBlocks'] ?? []);
    }

    $allowedTypes = demand_allowed_content_block_types();
    $blocks = [];
    foreach ((array) ($payload['contentBlocks'] ?? []) as $blockPayload) {
        if (!is_array($blockPayload) || !empty($blockPayload['remove'])) {
            continue;
        }
        $type = demand_clean_string((string) ($blockPayload['type'] ?? 'text'), 80);
        if (!in_array($type, $allowedTypes, true)) {
            $type = 'text';
        }
        $title = demand_clean_string((string) ($blockPayload['title'] ?? ''), 180);
        $visibility = demand_normalize_content_block_visibility((string) ($blockPayload['visibility'] ?? ''), $type, $title);
        if ($type === 'faq') {
            $items = demand_parse_faq_items((string) ($blockPayload['faqItems'] ?? ''));
            if ($title !== '' || $items) {
                $blocks[] = [
                    'type' => 'faq',
                    'visibility' => $visibility,
                    'title' => $title !== '' ? $title : 'Частые вопросы',
                    'items' => $items,
                ];
            }
            continue;
        }
        $body = demand_clean_string((string) ($blockPayload['body'] ?? ''), 4000);
        if ($title !== '' || $body !== '') {
            $blocks[] = [
                'type' => $type,
                'visibility' => $visibility,
                'title' => $title,
                'body' => $body,
            ];
        }
    }

    $newType = demand_clean_string((string) ($payload['newBlockType'] ?? ''), 80);
    $newTitle = demand_clean_string((string) ($payload['newBlockTitle'] ?? ''), 180);
    $newBody = demand_clean_string((string) ($payload['newBlockBody'] ?? ''), 4000);
    $newFaqItems = demand_parse_faq_items((string) ($payload['newBlockFaqItems'] ?? ''));
    if ($newTitle !== '' || $newBody !== '' || $newFaqItems) {
        if (!in_array($newType, $allowedTypes, true)) {
            $newType = 'text';
        }
        $newVisibility = demand_normalize_content_block_visibility((string) ($payload['newBlockVisibility'] ?? 'public'), $newType, $newTitle);
        $blocks[] = $newType === 'faq'
            ? [
                'type' => 'faq',
                'visibility' => $newVisibility,
                'title' => $newTitle !== '' ? $newTitle : 'Частые вопросы',
                'items' => $newFaqItems,
            ]
            : [
                'type' => $newType,
                'visibility' => $newVisibility,
                'title' => $newTitle,
                'body' => $newBody,
            ];
    }

    return $blocks;
}

function demand_wizard_publish_noindex(string $draftId): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_wizard_publish_noindex($draftId));
    $checked = demand_update_draft_readiness($draftId);
    if ((string) ($checked['readinessStatus'] ?? '') === 'blocked') {
        throw new RuntimeException('Публикация для просмотра заблокирована readiness-проверкой.');
    }

    $status = (string) ($checked['publishStatus'] ?? 'draft');
    if (in_array($status, ['idea', 'draft'], true)) {
        demand_workflow_submit_for_review($draftId);
        $checked = demand_find_draft($draftId) ?: $checked;
        $status = (string) ($checked['publishStatus'] ?? 'draft');
    }
    if ($status === 'needs_review') {
        demand_workflow_approve($draftId, 'Одобрено через простой мастер публикации.');
        $checked = demand_find_draft($draftId) ?: $checked;
        $status = (string) ($checked['publishStatus'] ?? 'draft');
    }
    if (!in_array($status, ['approved_for_public_preview', 'approved_for_future_publication'], true)) {
        throw new RuntimeException('Страница не готова к публикации для просмотра из текущего статуса.');
    }

    $published = demand_workflow_publish_noindex($draftId);
    demand_append_lifecycle_event(
        (string) ($published['scope_id'] ?? 'rent_rk'),
        'landing_page_draft',
        $draftId,
        'published_to_noindex_preview',
        'Страница опубликована для просмотра: публичная ссылка доступна, поиск закрыт, карта сайта для поисковиков не изменена.',
        current_admin_user() ?: 'system',
        [
            'previousStatus' => $status,
            'newStatus' => (string) ($published['publishStatus'] ?? ''),
        ]
    );
    analytics_record_event('published_to_noindex_preview', [
        'scopeId' => (string) ($published['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
    ]);

    return $published;
}

function demand_wizard_open_for_search(string $draftId): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_wizard_open_for_search($draftId));
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.publish.index');
    $checked = demand_update_draft_readiness($draftId, false);
    if ((string) ($checked['readinessStatus'] ?? '') === 'blocked') {
        throw new RuntimeException('Открытие для поиска заблокировано readiness-проверкой.');
    }
    $status = (string) ($checked['publishStatus'] ?? 'draft');
    if ($status === 'published_noindex') {
        demand_workflow_request_index_review($draftId);
        $status = 'ready_for_index_review';
    }
    if ($status !== 'ready_for_index_review') {
        throw new RuntimeException('Сначала страница должна быть опубликована для просмотра и закрыта от поиска.');
    }
    $indexed = demand_workflow_publish_indexed($draftId);
    demand_append_lifecycle_event(
        (string) ($indexed['scope_id'] ?? 'rent_rk'),
        'landing_page_draft',
        $draftId,
        'opened_for_search',
        'Страница вручную открыта для поиска и добавлена в карту сайта для поисковиков.',
        current_admin_user() ?: 'system',
        [
            'previousStatus' => $status,
            'newStatus' => (string) ($indexed['publishStatus'] ?? ''),
        ]
    );
    analytics_record_event('opened_for_search', [
        'scopeId' => (string) ($indexed['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
    ]);

    return $indexed;
}

function demand_wizard_close_from_search(string $draftId): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_wizard_close_from_search($draftId));
    $closed = demand_workflow_close_from_index($draftId);
    demand_append_lifecycle_event(
        (string) ($closed['scope_id'] ?? 'rent_rk'),
        'landing_page_draft',
        $draftId,
        'closed_from_search',
        'Страница закрыта от поиска через простой мастер публикации.',
        current_admin_user() ?: 'system',
        [
            'newStatus' => (string) ($closed['publishStatus'] ?? ''),
        ]
    );
    analytics_record_event('closed_from_search', [
        'scopeId' => (string) ($closed['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
    ]);

    return $closed;
}

function demand_assert_transition_ok(array $draft, string $target): void
{
    $checks = demand_transition_checks($draft, $target);
    if (empty($checks['ok'])) {
        throw new RuntimeException('Переход запрещен: ' . implode(' ', $checks['errors']));
    }
}

function demand_sitemap_path(): string
{
    return PROJECT_ROOT . 'sitemap.xml';
}

function demand_sitemap_locs(): array
{
    $raw = RentalReturnStore::publicationOutputBytes('sitemap.xml');
    if ($raw === null) return [];
    if (!preg_match_all('~<loc>(.*?)</loc>~is', $raw, $matches)) {
        return [];
    }

    return array_values(array_map(
        static fn(string $value): string => html_entity_decode(trim($value), ENT_QUOTES | ENT_XML1, 'UTF-8'),
        $matches[1]
    ));
}

function demand_sitemap_contains(string $url): bool
{
    return in_array($url, demand_sitemap_locs(), true);
}

function demand_backup_sitemap(string $reason): string
{
    if (!RentalReturnStore::active()) throw new LogicException('Sitemap backup requires a bounded transaction.');
    $name = 'demand-sitemap-' . date('Ymd-His') . '-' . bin2hex(random_bytes(2));
    foreach (['sitemap.xml', 'robots.txt'] as $file) {
        $bytes = RentalReturnStore::publicationOutputBytes($file);
        if ($bytes !== null && $bytes !== '') RentalReturnStore::stagePublicationOutput('@data/backups/' . $name . '/' . $file, $bytes);
    }
    $manifest = [
        'app' => 'Rent RK',
        'backupVersion' => 1,
        'exportType' => 'demand_sitemap_transition',
        'reason' => $reason,
        'createdAt' => now_iso(),
        'createdBy' => current_admin_user() ?: 'system',
    ];
    RentalReturnStore::stagePublicationOutput('@data/backups/' . $name . '/manifest.json', json_encode($manifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR) . "\n");

    return DATA_DIR . 'backups/' . $name;
}

function demand_write_sitemap_locs(array $locs): void
{
    $locs = demand_unique_strings(array_values(array_filter(array_map('strval', $locs))));
    $xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    $xml .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
    foreach ($locs as $loc) {
        $xml .= '  <url><loc>' . htmlspecialchars($loc, ENT_XML1 | ENT_COMPAT, 'UTF-8') . "</loc></url>\n";
    }
    $xml .= "</urlset>\n";
    if (!RentalReturnStore::active()) throw new LogicException('Sitemap update requires a bounded transaction.');
    $before = RentalReturnStore::publicationOutputBytes('sitemap.xml');
    RentalReturnStore::stagePublicationOutput('sitemap.xml', $xml, $before === null ? null : hash('sha256', $before));
}

function demand_sitemap_add_landing(array $draft): void
{
    require_permission('demand.sitemap.manage');
    $url = demand_public_landing_url($draft);
    if (demand_sitemap_contains($url)) {
        return;
    }
    demand_backup_sitemap('before_sitemap_add');
    $locs = demand_sitemap_locs();
    $locs[] = $url;
    demand_write_sitemap_locs($locs);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', (string) ($draft['id'] ?? ''), 'sitemap_added', 'Страница добавлена в карту сайта для поисковиков.', '', [
        'previousStatus' => (string) ($draft['publishStatus'] ?? ''),
        'newStatus' => (string) ($draft['publishStatus'] ?? ''),
    ]);
    analytics_record_event('landing_page_sitemap_added', [
        'scopeId' => (string) ($draft['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => (string) ($draft['id'] ?? ''),
        'meta' => ['url' => $url],
    ]);
}

function demand_sitemap_remove_landing(array $draft): void
{
    require_permission('demand.sitemap.manage');
    $url = demand_public_landing_url($draft);
    $locs = demand_sitemap_locs();
    if (!in_array($url, $locs, true)) {
        return;
    }
    demand_backup_sitemap('before_sitemap_remove');
    $locs = array_values(array_filter($locs, static fn(string $loc): bool => $loc !== $url));
    demand_write_sitemap_locs($locs);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', (string) ($draft['id'] ?? ''), 'sitemap_removed', 'Страница удалена из карты сайта для поисковиков.', '', [
        'previousStatus' => (string) ($draft['publishStatus'] ?? ''),
        'newStatus' => (string) ($draft['publishStatus'] ?? ''),
    ]);
    analytics_record_event('landing_page_sitemap_removed', [
        'scopeId' => (string) ($draft['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => (string) ($draft['id'] ?? ''),
        'meta' => ['url' => $url],
    ]);
}

function demand_public_landing_is_available(array $draft): bool
{
    return in_array((string) ($draft['publishStatus'] ?? ''), demand_public_publish_statuses(), true)
        && trim((string) ($draft['slug'] ?? '')) !== '';
}

function demand_find_public_landing_by_slug(string $slug): ?array
{
    $slug = demand_transliterate($slug);
    foreach (read_landing_page_drafts()['items'] as $draft) {
        if (!is_array($draft) || (string) ($draft['slug'] ?? '') !== $slug) {
            continue;
        }
        if (demand_public_landing_is_available($draft)) {
            return $draft;
        }
    }

    return null;
}

function demand_find_landing_by_slug_any_status(string $slug): ?array
{
    $slug = demand_transliterate($slug);
    foreach (read_landing_page_drafts()['items'] as $draft) {
        if (is_array($draft) && (string) ($draft['slug'] ?? '') === $slug) {
            return $draft;
        }
    }

    return null;
}

function demand_public_landing_service_titles(): array
{
    return [
        'короткий прямой ответ',
        'внутренние связи',
        'что уточнить перед бронированием',
        'рекомендуемые блоки',
        'что должна объяснить страница',
        'чего не хватает',
        'готовность',
        'ai/search readiness',
        'content gap',
        'safe content blocks',
        'must answer',
        'must not promise',
        'recommended internal links',
    ];
}

function demand_public_landing_is_service_title(string $title): bool
{
    $title = demand_lower(trim($title));
    if ($title === '') {
        return false;
    }
    foreach (demand_public_landing_service_titles() as $marker) {
        if ($marker !== '' && str_contains($title, $marker)) {
            return true;
        }
    }

    return false;
}

function demand_public_landing_text_looks_like_instruction(string $text): bool
{
    $text = demand_lower(trim($text));
    if ($text === '') {
        return true;
    }
    foreach ([
        'страница должна',
        'блок должен',
        'нужно добавить',
        'рекомендуется добавить',
        'рекомендуемые блоки',
        'перечислить',
        'показать только',
        'оставить задачу',
        'ответить только',
        'коротко ответить',
        'назвать сценарий',
        'указать, что',
        'описать подтверждённые',
        'объяснить, что',
        'если данных нет',
        'ручную проверку',
        'черновик',
        'перед публикацией',
        'администратор',
        'admin',
        'content gap',
        'stage c',
        'safecontentblocks',
        'mustnotpromise',
    ] as $marker) {
        if ($marker !== '' && str_contains($text, $marker)) {
            return true;
        }
    }

    return false;
}

function demand_public_landing_clean_text(string $text, int $maxLength = 1800): string
{
    $text = demand_clean_string($text, $maxLength);
    $text = preg_replace('/\s+/u', ' ', $text) ?? $text;

    return trim($text);
}

function demand_public_landing_public_title(string $type, string $title): string
{
    $public = demand_stage_c_public_block_title($type, $title);
    if ($public === '' || demand_public_landing_is_service_title($public)) {
        return '';
    }

    return $public;
}

function demand_public_landing_block_body(array $draft, array $block, array $linkedCars): string
{
    $type = (string) ($block['type'] ?? 'text');
    $body = demand_public_landing_clean_text((string) ($block['body'] ?? $block['text'] ?? ''), 1800);
    if ($body !== '' && !demand_public_landing_text_looks_like_instruction($body)) {
        return $body;
    }

    return demand_public_landing_clean_text(demand_stage_c_public_block_body($type, array_merge($block, ['body' => '']), $draft, $linkedCars), 1800);
}

function demand_prepare_public_landing_content(array $draft): array
{
    $linkedCars = array_values(array_filter(array_map(static fn($slug): ?array => find_car((string) $slug), (array) ($draft['linkedCars'] ?? []))));
    $linkedCars = array_values(array_filter($linkedCars, static fn(array $car): bool => public_car_visible_for_api($car)));
    $blocks = array_values(array_filter((array) ($draft['contentBlocks'] ?? []), 'is_array'));
    $publicInternalLinks = demand_public_internal_links($draft);

    $introCandidates = [
        demand_public_landing_clean_text((string) ($draft['heroSubtitle'] ?? ''), 700),
        demand_public_landing_clean_text((string) ($draft['publicIntro'] ?? ''), 900),
        demand_public_landing_clean_text((string) ($draft['intro'] ?? ''), 900),
    ];
    foreach ($blocks as $block) {
        if ((string) ($block['type'] ?? '') !== 'intro_answer') {
            continue;
        }
        $body = demand_public_landing_block_body($draft, $block, $linkedCars);
        if ($body !== '') {
            $introCandidates[] = $body;
        }
    }
    $heroIntro = '';
    foreach ($introCandidates as $candidate) {
        if ($candidate !== '' && !demand_public_landing_text_looks_like_instruction($candidate)) {
            $heroIntro = $candidate;
            break;
        }
    }
    if ($heroIntro === '') {
        $heroIntro = 'Подберите автомобиль под маршрут, даты и количество пассажиров. Менеджер проверит свободные машины, залог, документы и условия подачи перед бронированием.';
    }

    $conditionCards = [
        'documents' => [
            'title' => 'Документы',
            'text' => 'Обычно нужны паспорт и водительское удостоверение. Стаж и дополнительные условия менеджер проверит по выбранному автомобилю.',
        ],
        'deposit' => [
            'title' => 'Залог',
            'text' => 'Залог зависит от автомобиля и условий аренды. Точную сумму и порядок возврата лучше подтвердить до бронирования.',
        ],
        'pickup' => [
            'title' => 'Получение и возврат',
            'text' => 'Город, адрес, время получения и возврата согласуются заранее. Подача в отдельные точки требует подтверждения.',
        ],
        'duration' => [
            'title' => 'Срок аренды',
            'text' => 'Срок, продление и возможные ограничения по пробегу зависят от автомобиля и дат поездки.',
        ],
        'before_booking' => [
            'title' => 'Перед бронированием',
            'text' => 'Укажите даты, маршрут, багаж, количество пассажиров и особые пожелания, чтобы менеджер проверил подходящие варианты.',
        ],
    ];
    $publicSections = [];
    $faqItems = [];

    foreach ($blocks as $block) {
        $type = demand_clean_string((string) ($block['type'] ?? 'text'), 80);
        $title = demand_clean_string((string) ($block['title'] ?? ''), 180);
        $visibility = demand_normalize_content_block_visibility((string) ($block['visibility'] ?? ''), $type, $title);
        if ($visibility !== 'public') {
            continue;
        }
        if (in_array($type, ['internal_links', 'internal_linking', 'available_cars'], true)) {
            continue;
        }
        if ($type === 'faq') {
            foreach ((array) ($block['items'] ?? []) as $item) {
                if (!is_array($item)) {
                    continue;
                }
                $question = demand_public_landing_clean_text((string) ($item['question'] ?? ''), 220);
                $answer = demand_public_landing_clean_text((string) ($item['answer'] ?? ''), 800);
                if ($question !== '' && $answer !== '' && !demand_public_landing_text_looks_like_instruction($answer)) {
                    $faqItems[] = ['question' => $question, 'answer' => $answer];
                }
            }
            continue;
        }

        $body = demand_public_landing_block_body($draft, $block, $linkedCars);
        if ($body === '') {
            continue;
        }
        $publicTitle = demand_public_landing_public_title($type, $title);
        if (in_array($type, ['conditions'], true)) {
            $conditionCards['documents']['text'] = $body;
            continue;
        }
        if (in_array($type, ['deposit_explanation'], true)) {
            $conditionCards['deposit']['text'] = $body;
            continue;
        }
        if (in_array($type, ['pickup_delivery', 'airport_pickup'], true)) {
            $conditionCards['pickup']['text'] = $body;
            continue;
        }
        if (in_array($type, ['weekly_rental'], true)) {
            $conditionCards['duration']['text'] = $body;
            continue;
        }
        if (in_array($type, ['what_to_confirm_before_booking', 'not_supported_explanation', 'safety_limitations'], true)) {
            $conditionCards['before_booking']['text'] = $body;
            continue;
        }
        if ($type === 'intro_answer') {
            continue;
        }
        $publicSections[] = [
            'title' => $publicTitle !== '' ? $publicTitle : 'Когда подойдёт такой автомобиль',
            'body' => $body,
        ];
        if (count($publicSections) >= 4) {
            break;
        }
    }

    if (!$publicSections) {
        $publicSections[] = [
            'title' => 'Когда подойдёт такой автомобиль',
            'body' => 'Такой автомобиль удобно выбирать под конкретный маршрут: городские поездки, дорога между курортами, багаж, семья или несколько пассажиров. Перед бронированием лучше проверить свободные даты, залог, документы и место получения.',
        ];
    }
    if (!$faqItems) {
        $faqItems = [
            [
                'question' => 'Как понять, какие автомобили доступны?',
                'answer' => 'Оставьте даты и пожелания. Менеджер проверит свободные автомобили и предложит варианты под поездку.',
            ],
            [
                'question' => 'Как узнать точный залог?',
                'answer' => 'Залог зависит от автомобиля и условий аренды. Его нужно подтвердить по выбранной машине перед бронированием.',
            ],
            [
                'question' => 'Можно ли согласовать подачу?',
                'answer' => 'Подача зависит от места, времени и доступности автомобиля. Укажите нужную точку в заявке, менеджер подтвердит условия.',
            ],
        ];
    }

    $ctaText = demand_public_landing_clean_text((string) ($draft['ctaText'] ?? ''), 500);
    if ($ctaText === '' || demand_public_landing_text_looks_like_instruction($ctaText)) {
        $ctaText = 'Оставьте даты и пожелания — менеджер проверит доступные авто и условия.';
    }

    return [
        'heroIntro' => $heroIntro,
        'linkedCars' => $linkedCars,
        'publicTextSections' => array_values($publicSections),
        'conditionCards' => array_values($conditionCards),
        'faqItems' => array_slice($faqItems, 0, 8),
        'internalLinks' => $publicInternalLinks,
        'cta' => $ctaText,
    ];
}

function demand_update_landing_page_draft(string $draftId, array $payload): array
{
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.drafts.edit');

    $publishStatus = demand_clean_string($payload['publishStatus'] ?? ($draft['publishStatus'] ?? 'draft'), 80);
    $indexStatus = demand_clean_string($payload['indexStatus'] ?? ($draft['indexStatus'] ?? 'blocked'), 80);
    $qualityStatus = demand_clean_string($payload['qualityStatus'] ?? ($draft['qualityStatus'] ?? 'needs_human_review'), 80);
    if (!in_array($publishStatus, demand_allowed_publish_statuses(), true)) {
        throw new RuntimeException('На этапе 1 нельзя использовать такой статус публикации.');
    }
    if (!in_array($indexStatus, demand_allowed_index_statuses(), true)) {
        throw new RuntimeException('Для черновика можно выбрать только безопасный статус поиска: закрыто от поиска или не добавлено в карту сайта для поисковиков.');
    }
    if (!in_array($qualityStatus, demand_allowed_quality_statuses(), true)) {
        throw new RuntimeException('Некорректный статус качества.');
    }
    if (
        ($publishStatus !== (string) ($draft['publishStatus'] ?? 'draft') || $indexStatus !== (string) ($draft['indexStatus'] ?? 'blocked'))
        && in_array($publishStatus, ['published_noindex', 'ready_for_index_review', 'published_indexed'], true)
        && !has_permission('demand.publish.noindex')
    ) {
        throw new RuntimeException('Публикационные статусы меняются только через workflow.');
    }

    $contentBlocks = demand_content_blocks_from_payload($payload, $draft);
    $linkedCars = array_key_exists('linkedCarsInput', $payload)
        ? demand_parse_slug_list($payload['linkedCarsInput'])
        : array_values(array_filter(array_map('strval', (array) ($draft['linkedCars'] ?? []))));
    $internalLinks = demand_internal_links_from_payload($payload, $draft);

    $updates = [
        'slug' => demand_transliterate((string) ($payload['slug'] ?? $draft['slug'] ?? '')),
        'title' => demand_clean_string($payload['title'] ?? $draft['title'] ?? '', 160),
        'h1' => demand_clean_string($payload['h1'] ?? $draft['h1'] ?? '', 160),
        'metaDescription' => demand_clean_string($payload['metaDescription'] ?? $draft['metaDescription'] ?? '', 260),
        'intro' => demand_clean_string($payload['intro'] ?? $draft['intro'] ?? '', 1000),
        'ctaText' => demand_clean_string($payload['ctaText'] ?? $draft['ctaText'] ?? '', 500),
        'contentBlocks' => $contentBlocks,
        'linkedCars' => $linkedCars,
        'internalLinks' => $internalLinks,
        'informationReason' => demand_clean_string($payload['informationReason'] ?? $draft['informationReason'] ?? '', 500),
        'adminNote' => demand_clean_string($payload['adminNote'] ?? $draft['adminNote'] ?? '', 1000),
        'publishStatus' => $publishStatus,
        'indexStatus' => $indexStatus,
        'qualityStatus' => $publishStatus === 'archived' ? 'archived' : $qualityStatus,
        'updatedAt' => now_iso(),
    ];
    $stageCKeyword = null;
    foreach ((array) ($draft['sourceKeywordIds'] ?? []) as $sourceKeywordId) {
        $stageCKeyword = demand_find_keyword((string) $sourceKeywordId);
        if ($stageCKeyword) {
            break;
        }
    }
    if ($stageCKeyword) {
        $stageCCars = array_values(array_filter(array_map(static fn(string $slug): ?array => find_car($slug), $linkedCars)));
        $stageC = demand_stage_c_analyze_keyword($stageCKeyword, [
            'cars' => $stageCCars,
            'contentBlocks' => $contentBlocks,
            'intro' => (string) $updates['intro'],
        ]);
        foreach ([
            'userQuestionMap',
            'safeContentBlocks',
            'contentGapReport',
            'mustAnswer',
            'mustNotPromise',
            'recommendedFaq',
            'recommendedInternalLinks',
            'recommendedCarCardHints',
            'userClarityScore',
            'aiSearchReadiness',
        ] as $field) {
            $updates[$field] = $stageC[$field] ?? [];
        }
    }
    if ($updates['slug'] === '') {
        throw new RuntimeException('Slug не может быть пустым.');
    }

    $data = read_landing_page_drafts();
    foreach ($data['items'] as $index => $item) {
        if (!is_array($item)) {
            continue;
        }
        if ((string) ($item['id'] ?? '') !== $draftId && (string) ($item['slug'] ?? '') === $updates['slug'] && !in_array((string) ($item['publishStatus'] ?? ''), ['archived', 'merged'], true)) {
            throw new RuntimeException('Другой активный черновик уже использует этот slug.');
        }
        if ((string) ($item['id'] ?? '') === $draftId) {
            $contentChanged = false;
            foreach (['slug', 'title', 'h1', 'metaDescription', 'intro', 'ctaText', 'informationReason'] as $field) {
                if ((string) ($item[$field] ?? '') !== (string) ($updates[$field] ?? '')) {
                    $contentChanged = true;
                    break;
                }
            }
            if (!$contentChanged) {
                foreach (['contentBlocks', 'linkedCars', 'internalLinks'] as $field) {
                    if (json_encode($item[$field] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !== json_encode($updates[$field] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) {
                        $contentChanged = true;
                        break;
                    }
                }
            }
            if ($contentChanged && in_array((string) ($item['publishStatus'] ?? ''), demand_public_publish_statuses(), true)) {
                demand_create_landing_page_version($item, 'before_published_content_update');
            }
            if ($contentChanged) {
                $updates['readinessStatus'] = 'not_checked';
                $updates['readinessChecks'] = [];
                $updates['lastReadinessCheckAt'] = null;
            }
            $data['items'][$index] = array_merge($item, $updates);
            save_landing_page_drafts($data);
            demand_append_lifecycle_event((string) ($item['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'draft_updated', 'Обновлен черновик посадочной страницы.');
            analytics_record_event('landing_page_draft_updated', [
                'scopeId' => (string) ($item['scope_id'] ?? 'rent_rk'),
                'entityType' => 'landing_page_draft',
                'entityId' => $draftId,
                'meta' => ['publishStatus' => $publishStatus, 'indexStatus' => $indexStatus],
            ]);
            return $data['items'][$index];
        }
    }

    throw new RuntimeException('Черновик не найден.');
}

function demand_preview_text_clean($value, int $maxLength = 1800): string
{
    $text = html_entity_decode(strip_tags((string) $value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text) ?? '';
    $text = preg_replace("/[ \t]+/u", ' ', $text) ?? $text;
    $text = preg_replace("/\R{3,}/u", "\n\n", $text) ?? $text;
    $text = trim($text);

    if (function_exists('mb_substr')) {
        return mb_substr($text, 0, $maxLength, 'UTF-8');
    }

    return substr($text, 0, $maxLength);
}

function demand_preview_text_edit_is_allowed(array $draft): bool
{
    $publishStatus = (string) ($draft['publishStatus'] ?? 'draft');
    $indexStatus = (string) ($draft['indexStatus'] ?? 'blocked');

    if (in_array($publishStatus, ['published_indexed', 'archived', 'merged', 'rolled_back'], true)) {
        return false;
    }

    return !in_array($indexStatus, ['index_allowed', 'in_sitemap'], true);
}

function demand_update_landing_preview_text(string $draftId, array $payload, string $adminUser = ''): array
{
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.drafts.edit');
    if (!demand_preview_text_edit_is_allowed($draft)) {
        throw new RuntimeException('Этот preview нельзя редактировать inline: indexed/archived/merged страницы защищены от прямой правки.');
    }

    $target = demand_clean_string($payload['preview_edit_target'] ?? '', 40);
    $updated = $draft;
    $eventType = 'preview_text_block_updated';
    $changedFields = [];

    if ($target === 'field') {
        $field = demand_clean_string($payload['preview_field'] ?? '', 60);
        $allowed = [
            'title' => 160,
            'h1' => 160,
            'metaDescription' => 260,
            'intro' => 1000,
            'ctaText' => 500,
        ];
        if (!isset($allowed[$field])) {
            throw new RuntimeException('Поле не входит в безопасный список preview-редактора.');
        }
        $updated[$field] = demand_preview_text_clean($payload['preview_value'] ?? '', $allowed[$field]);
        $changedFields[] = $field;
    } elseif ($target === 'block') {
        $blockIndex = (int) ($payload['block_index'] ?? -1);
        $blocks = array_values(array_filter((array) ($draft['contentBlocks'] ?? []), 'is_array'));
        if (!isset($blocks[$blockIndex])) {
            throw new RuntimeException('Текстовый блок не найден.');
        }
        $block = $blocks[$blockIndex];
        $type = demand_clean_string($payload['block_type'] ?? ($block['type'] ?? 'text'), 80);
        if (!in_array($type, demand_allowed_content_block_types(), true)) {
            $type = demand_clean_string($block['type'] ?? 'text', 80);
        }
        if (in_array($type, ['faq', 'internal_links', 'internal_linking', 'available_cars'], true)) {
            throw new RuntimeException('Этот тип блока нельзя менять как обычный текст на preview.');
        }
        $visibility = demand_normalize_content_block_visibility((string) ($block['visibility'] ?? ''), $type, (string) ($block['title'] ?? ''));
        if ($visibility !== 'public') {
            throw new RuntimeException('Служебные и технические блоки не редактируются в публичном preview.');
        }
        $block['type'] = $type !== '' ? $type : 'text';
        $block['visibility'] = 'public';
        $block['title'] = demand_preview_text_clean($payload['block_title'] ?? ($block['title'] ?? ''), 180);
        $block['body'] = demand_preview_text_clean($payload['block_body'] ?? ($block['body'] ?? $block['text'] ?? ''), 1800);
        if (array_key_exists('block_admin_note', $payload)) {
            $block['adminNote'] = demand_preview_text_clean($payload['block_admin_note'] ?? '', 500);
        }
        unset($block['text']);
        $blocks[$blockIndex] = $block;
        $updated['contentBlocks'] = $blocks;
        $changedFields[] = 'contentBlocks[' . $blockIndex . ']';
    } elseif ($target === 'faq') {
        $blockIndex = (int) ($payload['block_index'] ?? -1);
        $itemIndex = (int) ($payload['faq_index'] ?? -1);
        $blocks = array_values(array_filter((array) ($draft['contentBlocks'] ?? []), 'is_array'));
        if (!isset($blocks[$blockIndex]) || (string) ($blocks[$blockIndex]['type'] ?? '') !== 'faq') {
            throw new RuntimeException('FAQ-блок не найден.');
        }
        $items = array_values(array_filter((array) ($blocks[$blockIndex]['items'] ?? []), 'is_array'));
        if (!isset($items[$itemIndex])) {
            throw new RuntimeException('FAQ-вопрос не найден.');
        }
        $items[$itemIndex]['question'] = demand_preview_text_clean($payload['faq_question'] ?? '', 220);
        $items[$itemIndex]['answer'] = demand_preview_text_clean($payload['faq_answer'] ?? '', 900);
        $blocks[$blockIndex]['items'] = $items;
        $updated['contentBlocks'] = $blocks;
        $eventType = 'preview_faq_updated';
        $changedFields[] = 'faq[' . $blockIndex . ':' . $itemIndex . ']';
    } else {
        throw new RuntimeException('Неизвестная зона preview-редактора.');
    }

    $beforeContent = json_encode(demand_landing_snapshot($draft), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $afterContent = json_encode(demand_landing_snapshot($updated), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($beforeContent === $afterContent) {
        return ['draft' => $draft, 'changed' => false, 'changedFields' => []];
    }

    if (in_array((string) ($draft['publishStatus'] ?? ''), demand_public_publish_statuses(), true)) {
        demand_create_landing_page_version($draft, 'before_preview_text_update', $adminUser);
    }

    $updated['publishStatus'] = (string) ($draft['publishStatus'] ?? 'draft');
    $updated['indexStatus'] = (string) ($draft['indexStatus'] ?? 'blocked');
    $updated['readinessStatus'] = 'not_checked';
    $updated['readinessChecks'] = [];
    $updated['lastReadinessCheckAt'] = null;
    $updated['updatedBy'] = $adminUser !== '' ? $adminUser : (current_admin_user() ?: 'system');
    $updated = demand_update_draft_item($updated);

    demand_append_lifecycle_event(
        (string) ($updated['scope_id'] ?? 'rent_rk'),
        'landing_page_draft',
        $draftId,
        $eventType,
        'Текст публичного preview обновлён через управляемый редактор. Публикация, индексация, sitemap.xml и robots.txt не менялись.',
        (string) ($updated['updatedBy'] ?? 'system'),
        [
            'changedFields' => $changedFields,
            'publishStatus' => (string) ($updated['publishStatus'] ?? ''),
            'indexStatus' => (string) ($updated['indexStatus'] ?? ''),
        ]
    );
    analytics_record_event($eventType, [
        'scopeId' => (string) ($updated['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
        'meta' => ['changedFields' => $changedFields],
    ]);

    return ['draft' => $updated, 'changed' => true, 'changedFields' => $changedFields];
}

function demand_draft_editorial_present_block_types(array $draft): array
{
    $types = [];
    foreach ((array) ($draft['contentBlocks'] ?? []) as $block) {
        if (!is_array($block)) {
            continue;
        }
        $type = trim((string) ($block['type'] ?? ''));
        if ($type !== '') {
            $types[] = $type;
        }
    }

    return demand_unique_strings($types);
}

function demand_draft_editorial_has_faq(array $draft): bool
{
    foreach ((array) ($draft['contentBlocks'] ?? []) as $block) {
        if (!is_array($block) || (string) ($block['type'] ?? '') !== 'faq') {
            continue;
        }
        if (!empty($block['items']) && is_array($block['items'])) {
            return true;
        }
    }

    return false;
}

function demand_draft_editorial_block_status(array $draft, array $safeBlock): array
{
    $type = trim((string) ($safeBlock['type'] ?? ''));
    if ($type === '' || !in_array($type, demand_allowed_content_block_types(), true)) {
        return [
            'key' => 'forbidden',
            'label' => 'Нельзя использовать',
            'explanation' => 'Тип блока не входит в безопасный список для черновиков.',
        ];
    }

    if (in_array($type, demand_draft_editorial_present_block_types($draft), true)) {
        return [
            'key' => 'present',
            'label' => 'Есть на странице',
            'explanation' => 'В черновике уже есть блок такого типа.',
        ];
    }

    if (in_array($type, ['airport_pickup', 'pickup_delivery', 'not_supported_explanation'], true)) {
        return [
            'key' => 'needs_confirmation',
            'label' => 'Требует проверки',
            'explanation' => 'Добавлять можно только как осторожное объяснение без обещания неподтверждённого условия.',
        ];
    }

    if ($type === 'deposit_explanation' && array_filter((array) ($safeBlock['forbiddenPromises'] ?? []), static fn(string $item): bool => str_contains(demand_lower($item), 'без залог'))) {
        return [
            'key' => 'needs_confirmation',
            'label' => 'Требует проверки',
            'explanation' => 'Нужно объяснить залог без обещания аренды без залога.',
        ];
    }

    return [
        'key' => 'missing',
        'label' => 'Не хватает',
        'explanation' => trim((string) ($safeBlock['whyNeeded'] ?? 'Этот блок нужен, чтобы закрыть важный вопрос пользователя.')),
    ];
}

function demand_draft_editorial_block_group(array $draft, array $safeBlock): string
{
    $status = demand_draft_editorial_block_status($draft, $safeBlock);
    if ((string) ($status['key'] ?? '') === 'forbidden') {
        return 'forbidden';
    }
    if ((string) ($status['key'] ?? '') === 'needs_confirmation') {
        return 'confirmed';
    }

    return (string) ($safeBlock['priority'] ?? '') === 'high' ? 'required' : 'recommended';
}

function demand_draft_editorial_find_safe_block(array $draft, string $blockType): ?array
{
    $blockType = trim($blockType);
    foreach ((array) ($draft['safeContentBlocks'] ?? []) as $block) {
        if (is_array($block) && (string) ($block['type'] ?? '') === $blockType) {
            return $block;
        }
    }

    return null;
}

function demand_draft_editorial_block_to_content(array $safeBlock, array $draft): array
{
    $type = (string) ($safeBlock['type'] ?? 'text');
    if (!in_array($type, demand_allowed_content_block_types(), true)) {
        $type = 'text';
    }
    $title = demand_clean_string((string) ($safeBlock['title'] ?? demand_admin_safe_block_title($type)), 180);
    if ($title === '') {
        $title = demand_admin_safe_block_title($type);
    }

    if ($type === 'faq') {
        $items = [];
        foreach ((array) ($draft['recommendedFaq'] ?? []) as $faq) {
            if (!is_array($faq)) {
                continue;
            }
            $question = demand_clean_string((string) ($faq['question'] ?? ''), 240);
            $answer = demand_clean_string((string) ($faq['answerGuidance'] ?? ''), 900);
            if ($question !== '' && $answer !== '') {
                $items[] = ['question' => $question, 'answer' => $answer];
            }
            if (count($items) >= 4) {
                break;
            }
        }

        return [
            'type' => 'faq',
            'title' => $title !== '' ? $title : 'Частые вопросы',
            'items' => $items,
        ];
    }

    $body = demand_clean_string((string) ($safeBlock['suggestedTextTemplate'] ?? ''), 4000);
    if ($body === '') {
        $body = 'Заготовка безопасного блока: опишите только подтверждённые факты, а неподтверждённые условия оставьте для проверки менеджером.';
    }

    return [
        'type' => $type,
        'title' => $title,
        'body' => $body,
    ];
}

function demand_draft_editorial_stage_c_updates(array $draft, array $contentBlocks): array
{
    $stageCKeyword = null;
    foreach ((array) ($draft['sourceKeywordIds'] ?? []) as $sourceKeywordId) {
        $stageCKeyword = demand_find_keyword((string) $sourceKeywordId);
        if ($stageCKeyword) {
            break;
        }
    }
    if (!$stageCKeyword) {
        return [];
    }

    $linkedCars = array_values(array_filter(array_map('strval', (array) ($draft['linkedCars'] ?? []))));
    $stageCCars = array_values(array_filter(array_map(static fn(string $slug): ?array => find_car($slug), $linkedCars)));
    $stageC = demand_stage_c_analyze_keyword($stageCKeyword, [
        'cars' => $stageCCars,
        'contentBlocks' => $contentBlocks,
        'intro' => (string) ($draft['intro'] ?? ''),
    ]);
    $updates = [];
    foreach ([
        'userQuestionMap',
        'safeContentBlocks',
        'contentGapReport',
        'mustAnswer',
        'mustNotPromise',
        'recommendedFaq',
        'recommendedInternalLinks',
        'recommendedCarCardHints',
        'userClarityScore',
        'aiSearchReadiness',
    ] as $field) {
        $updates[$field] = $stageC[$field] ?? [];
    }

    return $updates;
}

function demand_draft_editorial_save_content_blocks(string $draftId, array $contentBlocks, string $eventName, string $eventMessage): array
{
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.drafts.edit');

    $oldHash = json_encode((array) ($draft['contentBlocks'] ?? []), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $newHash = json_encode($contentBlocks, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($oldHash === $newHash) {
        return $draft;
    }

    $data = read_landing_page_drafts();
    foreach ($data['items'] as $index => $item) {
        if (!is_array($item) || (string) ($item['id'] ?? '') !== $draftId) {
            continue;
        }
        if (in_array((string) ($item['publishStatus'] ?? ''), demand_public_publish_statuses(), true)) {
            demand_create_landing_page_version($item, 'before_editorial_helper_update');
        }

        $updates = [
            'contentBlocks' => $contentBlocks,
            'readinessStatus' => 'not_checked',
            'readinessChecks' => [],
            'lastReadinessCheckAt' => null,
            'updatedAt' => now_iso(),
        ];
        $updates = array_merge($updates, demand_draft_editorial_stage_c_updates(array_merge($item, $updates), $contentBlocks));
        $data['items'][$index] = array_merge($item, $updates);
        save_landing_page_drafts($data);

        demand_append_lifecycle_event(
            (string) ($item['scope_id'] ?? 'rent_rk'),
            'landing_page_draft',
            $draftId,
            $eventName,
            $eventMessage,
            current_admin_user() ?: 'system'
        );
        analytics_record_event($eventName, [
            'scopeId' => (string) ($item['scope_id'] ?? 'rent_rk'),
            'entityType' => 'landing_page_draft',
            'entityId' => $draftId,
            'meta' => [
                'publishStatus' => (string) ($item['publishStatus'] ?? ''),
                'indexStatus' => (string) ($item['indexStatus'] ?? ''),
            ],
        ]);

        return $data['items'][$index];
    }

    throw new RuntimeException('Черновик не найден.');
}

function demand_draft_editorial_append_safe_block(string $draftId, string $blockType): array
{
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.drafts.edit');

    $safeBlock = demand_draft_editorial_find_safe_block($draft, $blockType);
    if (!$safeBlock) {
        throw new RuntimeException('Безопасная заготовка блока не найдена для этого черновика.');
    }
    $status = demand_draft_editorial_block_status($draft, $safeBlock);
    if ((string) ($status['key'] ?? '') === 'forbidden') {
        throw new RuntimeException('Этот блок нельзя добавить в черновик автоматически.');
    }
    if ((string) ($status['key'] ?? '') === 'present') {
        return $draft;
    }

    $contentBlock = demand_draft_editorial_block_to_content($safeBlock, $draft);
    $contentBlocks = (array) ($draft['contentBlocks'] ?? []);
    $contentBlocks[] = $contentBlock;

    return demand_draft_editorial_save_content_blocks(
        $draftId,
        $contentBlocks,
        'draft_editorial_block_added',
        'Редакторский помощник добавил безопасную заготовку блока. Публикация и индексация не выполнялись.'
    );
}

function demand_draft_editorial_append_faq(string $draftId, int $faqIndex): array
{
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.drafts.edit');

    $faqs = array_values(array_filter((array) ($draft['recommendedFaq'] ?? []), 'is_array'));
    if (!isset($faqs[$faqIndex])) {
        throw new RuntimeException('FAQ-подсказка не найдена.');
    }
    $question = demand_clean_string((string) ($faqs[$faqIndex]['question'] ?? ''), 240);
    $answer = demand_clean_string((string) ($faqs[$faqIndex]['answerGuidance'] ?? ''), 900);
    if ($question === '') {
        throw new RuntimeException('FAQ-подсказка пустая.');
    }
    if ($answer === '') {
        $answer = 'Ответить только по подтверждённым условиям. Если данных нет, указать, что условие уточняется менеджером.';
    }

    $contentBlocks = (array) ($draft['contentBlocks'] ?? []);
    $faqBlockIndex = null;
    foreach ($contentBlocks as $index => $block) {
        if (is_array($block) && (string) ($block['type'] ?? '') === 'faq') {
            $faqBlockIndex = $index;
            break;
        }
    }
    if ($faqBlockIndex === null) {
        $contentBlocks[] = [
            'type' => 'faq',
            'title' => 'Частые вопросы',
            'items' => [],
        ];
        $faqBlockIndex = array_key_last($contentBlocks);
    }

    $items = (array) ($contentBlocks[$faqBlockIndex]['items'] ?? []);
    foreach ($items as $item) {
        if (is_array($item) && demand_lower(trim((string) ($item['question'] ?? ''))) === demand_lower($question)) {
            return $draft;
        }
    }
    $items[] = ['question' => $question, 'answer' => $answer];
    $contentBlocks[$faqBlockIndex]['items'] = $items;

    return demand_draft_editorial_save_content_blocks(
        $draftId,
        $contentBlocks,
        'draft_editorial_faq_added',
        'Редакторский помощник добавил FAQ в черновик. Публикация и индексация не выполнялись.'
    );
}

function demand_draft_editorial_next_action(array $draft): array
{
    $gap = is_array($draft['contentGapReport'] ?? null) ? $draft['contentGapReport'] : [];
    $dangerous = (array) ($gap['dangerousClaims'] ?? []);
    if ($dangerous) {
        return [
            'level' => 'risky',
            'title' => 'Исправьте рискованное обещание перед публикацией.',
            'body' => 'В тексте есть формулировка, которую нельзя оставлять без подтверждённых условий.',
        ];
    }
    if (in_array('intro_answer', (array) ($gap['missingBlocks'] ?? []), true) || trim((string) ($draft['intro'] ?? '')) === '') {
        return [
            'level' => 'needs_fixes',
            'title' => 'Добавьте короткий ответ в начало страницы.',
            'body' => 'Первый экран должен сразу объяснять, кому подходит предложение и что нужно проверить перед бронированием.',
        ];
    }
    if (!demand_draft_editorial_has_faq($draft)) {
        return [
            'level' => 'needs_fixes',
            'title' => 'Добавьте 2-3 FAQ из подсказок.',
            'body' => 'FAQ закрывает вопросы про документы, залог, цену, подачу и ограничения без лишних обещаний.',
        ];
    }
    $missing = array_values(array_filter(array_map('strval', (array) ($gap['missingBlocks'] ?? []))));
    if ($missing) {
        return [
            'level' => 'needs_fixes',
            'title' => 'Добавьте недостающий блок: ' . demand_admin_safe_block_title((string) $missing[0]) . '.',
            'body' => 'После добавления сохраните черновик и проверьте готовность заново.',
        ];
    }
    $clarity = is_array($draft['userClarityScore'] ?? null) ? (array) $draft['userClarityScore'] : [];
    if ((string) ($clarity['level'] ?? '') === 'risky') {
        return [
            'level' => 'risky',
            'title' => 'Сначала снимите риск в тексте.',
            'body' => (string) ($clarity['summary'] ?? 'Страница пока рискованна для публикации.'),
        ];
    }

    return [
        'level' => 'ready',
        'title' => 'Проверьте готовность и опубликуйте для просмотра.',
        'body' => 'Редакторских препятствий не видно, но публикация и открытие индексации всё равно остаются ручными.',
    ];
}

function demand_workflow_submit_for_review(string $draftId): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_workflow_submit_for_review($draftId));
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.drafts.edit');
    $previous = (string) ($draft['publishStatus'] ?? 'draft');
    if (!in_array($previous, ['idea', 'draft'], true)) {
        throw new RuntimeException('На проверку можно отправить только idea/draft.');
    }
    $draft['publishStatus'] = 'needs_review';
    $draft['indexStatus'] = 'blocked';
    if ((string) ($draft['qualityStatus'] ?? '') === 'rejected') {
        $draft['qualityStatus'] = 'needs_human_review';
    }
    $draft['submittedForReviewAt'] = now_iso();
    $draft['submittedForReviewBy'] = current_admin_user() ?: 'system';
    $draft = demand_update_draft_item($draft);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'draft_submitted_for_review', 'Черновик отправлен на проверку.', '', [
        'previousStatus' => $previous,
        'newStatus' => 'needs_review',
    ]);

    return $draft;
}

function demand_workflow_approve(string $draftId, string $note = ''): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_workflow_approve($draftId, $note));
    require_permission('demand.publish.noindex');
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.publish.noindex');
    $previous = (string) ($draft['publishStatus'] ?? 'draft');
    if (!in_array($previous, ['needs_review', 'draft'], true)) {
        throw new RuntimeException('Одобрить можно только черновик на проверке.');
    }
    $draft['publishStatus'] = 'approved_for_public_preview';
    $draft['indexStatus'] = 'blocked';
    $draft['qualityStatus'] = 'approved';
    $draft['reviewedBy'] = current_admin_user() ?: 'system';
    $draft['reviewedAt'] = now_iso();
    $draft['reviewNotes'] = demand_clean_string($note, 1000);
    $draft = demand_update_draft_item($draft);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'draft_approved', 'Черновик одобрен для безопасной noindex-публикации.', '', [
        'previousStatus' => $previous,
        'newStatus' => 'approved_for_public_preview',
        'reason' => $note,
    ]);

    return $draft;
}

function demand_workflow_reject(string $draftId, string $reason): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_workflow_reject($draftId, $reason));
    require_permission('demand.publish.noindex');
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.publish.noindex');
    $previous = (string) ($draft['publishStatus'] ?? 'draft');
    if (!in_array($previous, ['needs_review', 'approved_for_public_preview', 'approved_for_future_publication'], true)) {
        throw new RuntimeException('Отклонить можно только страницу, находящуюся на проверке или ожидающую публикации.');
    }
    $draft['publishStatus'] = 'draft';
    $draft['indexStatus'] = 'blocked';
    $draft['qualityStatus'] = 'rejected';
    $draft['reviewedBy'] = current_admin_user() ?: 'system';
    $draft['reviewedAt'] = now_iso();
    $draft['reviewNotes'] = demand_clean_string($reason, 1000);
    $draft = demand_update_draft_item($draft);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'draft_rejected', 'Черновик отклонен: ' . demand_clean_string($reason, 500), '', [
        'previousStatus' => $previous,
        'newStatus' => 'draft',
        'reason' => $reason,
    ]);

    return $draft;
}

function demand_workflow_publish_noindex(string $draftId): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_workflow_publish_noindex($draftId));
    require_permission('demand.publish.noindex');
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.publish.noindex');
    demand_assert_transition_ok($draft, 'published_noindex');
    demand_create_landing_page_version($draft, 'before_publish_noindex');
    $previous = (string) ($draft['publishStatus'] ?? 'draft');
    $draft['publishStatus'] = 'published_noindex';
    $draft['indexStatus'] = 'noindex';
    $draft['qualityStatus'] = 'approved';
    $draft['publishedNoindexAt'] = now_iso();
    $draft['publishedNoindexBy'] = current_admin_user() ?: 'system';
    $draft = demand_update_draft_item($draft);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'published_noindex', 'Страница опубликована для просмотра: публичная ссылка доступна, поиск закрыт, карта сайта для поисковиков не изменена.', '', [
        'previousStatus' => $previous,
        'newStatus' => 'published_noindex',
        'previousIndexStatus' => 'blocked',
        'newIndexStatus' => 'noindex',
    ]);
    analytics_record_event('landing_page_published_noindex', [
        'scopeId' => (string) ($draft['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
        'meta' => ['url' => demand_public_landing_url($draft)],
    ]);

    return $draft;
}

function demand_workflow_request_index_review(string $draftId): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_workflow_request_index_review($draftId));
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.drafts.edit');
    $previous = (string) ($draft['publishStatus'] ?? 'draft');
    if ($previous !== 'published_noindex') {
        throw new RuntimeException('Запросить индексацию можно только для published_noindex.');
    }
    $draft['publishStatus'] = 'ready_for_index_review';
    $draft['indexStatus'] = 'noindex';
    $draft['indexReviewRequestedAt'] = now_iso();
    $draft['indexReviewRequestedBy'] = current_admin_user() ?: 'system';
    $draft = demand_update_draft_item($draft);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'index_review_requested', 'Запрошено ручное открытие индексации.', '', [
        'previousStatus' => $previous,
        'newStatus' => 'ready_for_index_review',
    ]);
    analytics_record_event('landing_page_index_requested', [
        'scopeId' => (string) ($draft['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
    ]);

    return $draft;
}

function demand_workflow_publish_indexed(string $draftId): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_workflow_publish_indexed($draftId));
    require_permission('demand.publish.index');
    require_permission('demand.sitemap.manage');
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.publish.index');
    demand_assert_transition_ok($draft, 'published_indexed');
    demand_create_landing_page_version($draft, 'before_publish_indexed');
    $previous = (string) ($draft['publishStatus'] ?? 'published_noindex');
    $draft['publishStatus'] = 'published_indexed';
    $draft['indexStatus'] = 'in_sitemap';
    $draft['qualityStatus'] = 'approved';
    $draft['indexedAt'] = now_iso();
    $draft['indexedBy'] = current_admin_user() ?: 'system';
    $draft = demand_update_draft_item($draft);
    demand_sitemap_add_landing($draft);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'published_indexed', 'Страница вручную открыта для поиска и добавлена в карту сайта для поисковиков.', '', [
        'previousStatus' => $previous,
        'newStatus' => 'published_indexed',
        'previousIndexStatus' => 'noindex',
        'newIndexStatus' => 'in_sitemap',
    ]);
    analytics_record_event('landing_page_published_indexed', [
        'scopeId' => (string) ($draft['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
        'meta' => ['url' => demand_public_landing_url($draft)],
    ]);

    return $draft;
}

function demand_workflow_return_noindex(string $draftId, string $reason = ''): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_workflow_return_noindex($draftId, $reason));
    require_permission('demand.publish.index');
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.publish.index');
    $previous = (string) ($draft['publishStatus'] ?? 'ready_for_index_review');
    if ($previous !== 'ready_for_index_review') {
        throw new RuntimeException('Вернуть в noindex можно только страницу ready_for_index_review.');
    }
    $draft['publishStatus'] = 'published_noindex';
    $draft['indexStatus'] = 'noindex';
    $draft['indexReviewRejectedAt'] = now_iso();
    $draft['indexReviewRejectedBy'] = current_admin_user() ?: 'system';
    $draft['indexReviewRejectReason'] = demand_clean_string($reason, 1000);
    $draft = demand_update_draft_item($draft);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'draft_rejected', 'Открытие индексации отклонено, страница возвращена в noindex.', '', [
        'previousStatus' => $previous,
        'newStatus' => 'published_noindex',
        'reason' => $reason,
    ]);

    return $draft;
}

function demand_workflow_close_from_index(string $draftId): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_workflow_close_from_index($draftId));
    require_permission('demand.publish.index');
    require_permission('demand.sitemap.manage');
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.publish.index');
    if ((string) ($draft['publishStatus'] ?? '') !== 'published_indexed') {
        throw new RuntimeException('Закрыть от поиска можно только индексируемую страницу.');
    }
    demand_create_landing_page_version($draft, 'before_close_from_index');
    demand_sitemap_remove_landing($draft);
    $previous = (string) ($draft['publishStatus'] ?? 'published_indexed');
    $draft['publishStatus'] = 'published_noindex';
    $draft['indexStatus'] = 'noindex';
    $draft['closedFromIndexAt'] = now_iso();
    $draft['closedFromIndexBy'] = current_admin_user() ?: 'system';
    $draft = demand_update_draft_item($draft);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'page_closed_from_index', 'Страница закрыта от поиска и удалена из карты сайта для поисковиков.', '', [
        'previousStatus' => $previous,
        'newStatus' => 'published_noindex',
        'previousIndexStatus' => 'in_sitemap',
        'newIndexStatus' => 'noindex',
    ]);
    analytics_record_event('landing_page_closed_from_index', [
        'scopeId' => (string) ($draft['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
    ]);

    return $draft;
}

function demand_workflow_archive(string $draftId, string $reason = ''): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_workflow_archive($draftId, $reason));
    require_permission('demand.rollback');
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.rollback');
    if (in_array((string) ($draft['publishStatus'] ?? ''), ['archived', 'merged'], true)) {
        throw new RuntimeException('Страница уже выведена из рабочего процесса.');
    }
    demand_create_landing_page_version($draft, 'before_archive');
    if (demand_sitemap_contains(demand_public_landing_url($draft))) {
        demand_sitemap_remove_landing($draft);
    }
    $previous = (string) ($draft['publishStatus'] ?? 'draft');
    $draft['publishStatus'] = 'archived';
    $draft['indexStatus'] = 'removed_from_sitemap';
    $draft['qualityStatus'] = 'archived';
    $draft['archivedAt'] = now_iso();
    $draft['archivedBy'] = current_admin_user() ?: 'system';
    $draft['archiveReason'] = demand_clean_string($reason, 1000);
    $draft = demand_update_draft_item($draft);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'page_archived', 'Посадочная страница архивирована.', '', [
        'previousStatus' => $previous,
        'newStatus' => 'archived',
        'reason' => $reason,
    ]);
    analytics_record_event('landing_page_archived', [
        'scopeId' => (string) ($draft['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
    ]);

    return $draft;
}

function demand_workflow_merge(string $draftId, string $targetPageId = '', string $targetUrl = '', string $reason = ''): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_workflow_merge($draftId, $targetPageId, $targetUrl, $reason));
    require_permission('demand.rollback');
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.rollback');
    $targetPageId = demand_clean_string($targetPageId, 120);
    $targetUrl = demand_clean_string($targetUrl, 500);
    $reason = demand_clean_string($reason, 1000);
    if (in_array((string) ($draft['publishStatus'] ?? ''), ['archived', 'merged'], true)) {
        throw new RuntimeException('Архивную или уже объединённую страницу нельзя объединить повторно.');
    }
    if (($targetPageId === '') === ($targetUrl === '')) {
        throw new RuntimeException('Выберите только одну цель: внутреннюю страницу или URL.');
    }
    if ($reason === '') {
        throw new RuntimeException('Укажите причину объединения страницы.');
    }
    if ($targetPageId === $draftId) {
        throw new RuntimeException('Страницу нельзя объединить с самой собой.');
    }
    if ($targetUrl !== '' && !str_starts_with($targetUrl, '/') && filter_var($targetUrl, FILTER_VALIDATE_URL) === false) {
        throw new RuntimeException('Некорректный целевой URL для объединения.');
    }
    if ($targetPageId !== '') {
        $targetDraft = demand_find_draft($targetPageId);
        if (!$targetDraft) {
            throw new RuntimeException('Целевая внутренняя страница для объединения не найдена.');
        }
        if (demand_normalize_scope_id((string) ($targetDraft['scope_id'] ?? 'rent_rk')) !== demand_normalize_scope_id((string) ($draft['scope_id'] ?? 'rent_rk'))) {
            throw new RuntimeException('Нельзя объединять страницы разных контуров.');
        }
    }
    demand_create_landing_page_version($draft, 'before_merge');
    if (demand_sitemap_contains(demand_public_landing_url($draft))) {
        demand_sitemap_remove_landing($draft);
    }
    $previous = (string) ($draft['publishStatus'] ?? 'draft');
    $draft['publishStatus'] = 'merged';
    $draft['indexStatus'] = 'removed_from_sitemap';
    $draft['targetPageId'] = $targetPageId;
    $draft['targetUrl'] = $targetUrl;
    $draft['mergeReason'] = $reason;
    $draft['mergedAt'] = now_iso();
    $draft['mergedBy'] = current_admin_user() ?: 'system';
    $draft = demand_update_draft_item($draft);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'page_merged', 'Страница помечена как объединенная. Автоматический редирект не включен.', '', [
        'previousStatus' => $previous,
        'newStatus' => 'merged',
        'targetPageId' => $targetPageId,
        'targetUrl' => $targetUrl,
        'reason' => $reason,
    ]);

    return $draft;
}

function demand_workflow_restore_draft(string $draftId): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_workflow_restore_draft($draftId));
    require_permission('demand.rollback');
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.rollback');
    if (!in_array((string) ($draft['publishStatus'] ?? ''), ['archived', 'merged'], true)) {
        throw new RuntimeException('Восстановить как черновик можно только архивную или объединённую страницу.');
    }
    demand_create_landing_page_version($draft, 'before_restore_draft');
    $previous = (string) ($draft['publishStatus'] ?? 'archived');
    $draft['publishStatus'] = 'draft';
    $draft['indexStatus'] = 'blocked';
    $draft['qualityStatus'] = 'needs_human_review';
    $draft = demand_update_draft_item($draft);
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'rollback_applied', 'Архивная страница восстановлена как draft.', '', [
        'previousStatus' => $previous,
        'newStatus' => 'draft',
    ]);

    return $draft;
}

function demand_workflow_apply_rollback(string $draftId, string $versionId = ''): array
{
    if (!RentalReturnStore::active()) return RentalReturnStore::transaction(static fn(): array => demand_workflow_apply_rollback($draftId, $versionId));
    require_permission('demand.rollback');
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.rollback');
    demand_create_landing_page_version($draft, 'before_rollback_apply');
    $versions = demand_versions_for_draft($draftId);
    $version = null;
    foreach ($versions as $candidate) {
        if ($versionId === '' || (string) ($candidate['id'] ?? '') === $versionId) {
            $version = $candidate;
            break;
        }
    }
    if (!$version || !is_array($version['snapshot'] ?? null)) {
        throw new RuntimeException('Версия для отката не найдена.');
    }
    if (demand_normalize_scope_id((string) ($version['scope_id'] ?? 'rent_rk')) !== demand_normalize_scope_id((string) ($draft['scope_id'] ?? 'rent_rk'))
        || (string) ($version['landingPageDraftId'] ?? '') !== $draftId) {
        throw new RuntimeException('Версия отката не относится к выбранной странице и контуру.');
    }
    if (demand_sitemap_contains(demand_public_landing_url($draft))) {
        demand_sitemap_remove_landing($draft);
    }
    $previous = (string) ($draft['publishStatus'] ?? '');
    $snapshot = $version['snapshot'];
    foreach (demand_landing_snapshot($snapshot) as $key => $value) {
        $draft[$key] = $value;
    }
    $draft['rolledBackFromStatus'] = $previous;
    $draft['rolledBackAt'] = now_iso();
    $draft['rolledBackBy'] = current_admin_user() ?: 'system';
    $draft = demand_update_draft_item($draft);
    if ((string) ($draft['publishStatus'] ?? '') === 'published_indexed') {
        demand_sitemap_add_landing($draft);
    }
    demand_append_lifecycle_event((string) ($draft['scope_id'] ?? 'rent_rk'), 'landing_page_draft', $draftId, 'rollback_applied', 'Применен откат к предыдущей версии.', '', [
        'previousStatus' => $previous,
        'newStatus' => (string) ($draft['publishStatus'] ?? ''),
        'versionId' => (string) ($version['id'] ?? ''),
    ]);
    analytics_record_event('landing_page_rollback_applied', [
        'scopeId' => (string) ($draft['scope_id'] ?? 'rent_rk'),
        'entityType' => 'landing_page_draft',
        'entityId' => $draftId,
        'meta' => ['versionId' => (string) ($version['id'] ?? '')],
    ]);

    return $draft;
}

function demand_refresh_draft_linked_cars_preview(string $draftId): array
{
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.drafts.edit');

    $publishStatus = (string) ($draft['publishStatus'] ?? 'draft');
    if (!in_array($publishStatus, demand_refresh_draft_cars_allowed_statuses(), true)) {
        $message = in_array($publishStatus, demand_public_publish_statuses(), true)
            ? 'REFRESH_DRAFT_CARS_PUBLIC_STATE_FORBIDDEN: публичную страницу нельзя пересчитывать этим инструментом.'
            : 'REFRESH_DRAFT_CARS_STATE_FORBIDDEN: пересчёт доступен только для рабочих черновиков и состояний проверки.';
        throw new RuntimeException($message, 409);
    }

    $draftScopeId = demand_normalize_scope_id((string) ($draft['scope_id'] ?? 'rent_rk'));
    $keywordIds = is_array($draft['sourceKeywordIds'] ?? null) ? $draft['sourceKeywordIds'] : [];
    $cars = [];
    foreach ($keywordIds as $keywordId) {
        $keyword = demand_find_keyword((string) $keywordId);
        if (!$keyword) {
            throw new RuntimeException('REFRESH_DRAFT_CARS_SOURCE_KEYWORD_MISSING: исходный запрос черновика не найден.', 409);
        }
        $keywordScopeId = demand_normalize_scope_id((string) ($keyword['scope_id'] ?? 'rent_rk'));
        if ($keywordScopeId !== $draftScopeId) {
            throw new RuntimeException('REFRESH_DRAFT_CARS_KEYWORD_SCOPE_MISMATCH: контур исходного запроса не совпадает с контуром черновика.', 409);
        }
        foreach (demand_match_cars_for_keyword($keyword) as $car) {
            $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
            if ($slug !== '') {
                $cars[$slug] = true;
            }
        }
    }

    $currentCars = [];
    foreach ((array) ($draft['linkedCars'] ?? []) as $slug) {
        $normalized = normalize_car_slug((string) $slug);
        if ($normalized !== '') {
            $currentCars[$normalized] = true;
        }
    }
    $currentCars = array_values(array_keys($currentCars));
    $recalculatedCars = array_values(array_keys($cars));

    return [
        'draftId' => $draftId,
        'publishStatus' => $publishStatus,
        'currentCars' => $currentCars,
        'recalculatedCars' => $recalculatedCars,
        'addedCars' => array_values(array_diff($recalculatedCars, $currentCars)),
        'removedCars' => array_values(array_diff($currentCars, $recalculatedCars)),
        'unchangedCars' => array_values(array_intersect($currentCars, $recalculatedCars)),
        'changed' => $currentCars !== $recalculatedCars,
    ];
}

function demand_refresh_draft_linked_cars(string $draftId, bool $confirmed = false): array
{
    if (!$confirmed) {
        throw new RuntimeException('REFRESH_DRAFT_CARS_CONFIRMATION_REQUIRED: сначала проверьте и отдельно подтвердите пересчёт.', 409);
    }

    $preview = demand_refresh_draft_linked_cars_preview($draftId);
    if (empty($preview['changed'])) {
        $preview['draft'] = demand_find_draft($draftId);
        return $preview;
    }

    $data = read_landing_page_drafts();
    foreach ($data['items'] as $index => $item) {
        if (is_array($item) && (string) ($item['id'] ?? '') === $draftId) {
            $updated = $item;
            $updated['linkedCars'] = (array) $preview['recalculatedCars'];
            $updated['updatedAt'] = now_iso();
            $updated['qualityStatus'] = demand_draft_quality_status($updated, (array) ($updated['riskFlags'] ?? []));
            $updated['readinessStatus'] = 'not_checked';
            $updated['readinessChecks'] = [];
            $updated['lastReadinessCheckAt'] = null;
            $data['items'][$index] = $updated;
            save_landing_page_drafts($data);
            demand_append_lifecycle_event(
                (string) ($updated['scope_id'] ?? 'rent_rk'),
                'landing_page_draft',
                $draftId,
                'draft_updated',
                'Связанные авто черновика пересчитаны по исходным запросам.'
            );
            analytics_record_event('landing_page_draft_updated', [
                'scopeId' => (string) ($updated['scope_id'] ?? 'rent_rk'),
                'entityType' => 'landing_page_draft',
                'entityId' => $draftId,
                'meta' => [
                    'publishStatus' => (string) ($updated['publishStatus'] ?? 'draft'),
                    'indexStatus' => (string) ($updated['indexStatus'] ?? 'blocked'),
                    'source' => 'refresh_draft_cars',
                    'addedCars' => (array) $preview['addedCars'],
                    'removedCars' => (array) $preview['removedCars'],
                ],
            ]);
            $preview['draft'] = $updated;
            return $preview;
        }
    }

    throw new RuntimeException('Черновик не найден.');
}

function demand_visible_keywords(string $scopeFilter = ''): array
{
    $scopes = demand_current_scope_filter($scopeFilter);
    return array_values(array_filter(read_demand_keywords()['items'], static fn($item): bool => is_array($item) && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopes, true)));
}

function demand_visible_recommendations(string $scopeFilter = ''): array
{
    $scopes = demand_current_scope_filter($scopeFilter);
    return array_values(array_filter(read_demand_recommendations()['items'], static fn($item): bool => is_array($item) && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopes, true)));
}

function demand_visible_drafts(string $scopeFilter = ''): array
{
    $scopes = demand_current_scope_filter($scopeFilter);
    return array_values(array_filter(read_landing_page_drafts()['items'], static fn($item): bool => is_array($item) && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopes, true)));
}

function demand_overview_stats(string $scopeFilter = ''): array
{
    $keywords = demand_visible_keywords($scopeFilter);
    $recommendations = demand_visible_recommendations($scopeFilter);
    $drafts = demand_visible_drafts($scopeFilter);
    $lastImport = '';
    foreach ($keywords as $keyword) {
        $created = (string) ($keyword['updatedAt'] ?? $keyword['createdAt'] ?? '');
        if ($created > $lastImport) {
            $lastImport = $created;
        }
    }

    return [
        'keywords' => count($keywords),
        'activeRecommendations' => count(array_filter($recommendations, static fn(array $item): bool => !in_array((string) ($item['actionStatus'] ?? ''), ['done', 'rejected', 'archived'], true))),
        'drafts' => count($drafts),
        'doNotPublish' => count(array_filter($recommendations, static fn(array $item): bool => (string) ($item['recommendationType'] ?? '') === 'do_not_publish')),
        'carCardHints' => count(array_filter($recommendations, static fn(array $item): bool => (string) ($item['recommendationType'] ?? '') === 'update_car_cards')),
        'lastImport' => $lastImport,
    ];
}

function demand_car_card_hints(string $scopeFilter = ''): array
{
    $keywordsById = [];
    foreach (demand_visible_keywords($scopeFilter) as $keyword) {
        $keywordsById[(string) ($keyword['id'] ?? '')] = $keyword;
    }
    $rows = [];
    foreach (demand_visible_recommendations($scopeFilter) as $recommendation) {
        if ((string) ($recommendation['recommendationType'] ?? '') !== 'update_car_cards') {
            continue;
        }
        $keyword = $keywordsById[(string) ($recommendation['keywordId'] ?? '')] ?? null;
        if (!$keyword) {
            continue;
        }
        $cars = array_values(array_filter(array_map(static fn(string $slug): ?array => find_car($slug), (array) ($recommendation['linkedCars'] ?? []))));
        foreach (demand_card_hint_flags($keyword, $cars) as $carSlug => $hints) {
            $rows[$carSlug] = $rows[$carSlug] ?? [
                'carSlug' => $carSlug,
                'carName' => car_name($carSlug),
                'scope_id' => car_owner_scope_id(find_car($carSlug) ?? []),
                'keywords' => [],
                'hints' => [],
            ];
            $rows[$carSlug]['keywords'][] = (string) ($keyword['phrase'] ?? '');
            $rows[$carSlug]['hints'] = demand_unique_strings(array_merge($rows[$carSlug]['hints'], $hints));
        }
    }

    return array_values($rows);
}

function demand_ai_budget_modes(): array
{
    return [
        'economy' => [
            'key' => 'economy',
            'label' => 'economy',
            'description' => 'Минимальный расход: подготовить основу по одному направлению и остановиться перед подтверждениями.',
            'maxAiCalls' => 3,
            'maxSeedPhrases' => 20,
            'maxClusters' => 3,
            'maxDrafts' => 0,
            'draftCreationAllowed' => false,
            'draftCreationPolicy' => 'not_allowed',
            'wordstatDryRunAllowed' => false,
            'wordstatLiveAllowed' => false,
            'maxCopyVariants' => 1,
            'maxInternalLinks' => 3,
            'maxNeighboringDirections' => 3,
            'requiresExpensiveModeWarning' => false,
        ],
        'trusted_economy' => [
            'key' => 'trusted_economy',
            'label' => 'trusted_economy',
            'description' => 'Экономный доверенный режим: один безопасный draft/blocked черновик только внутри выбранного направления, если это явно показано перед стартом.',
            'maxAiCalls' => 3,
            'maxSeedPhrases' => 20,
            'maxClusters' => 3,
            'maxDrafts' => 1,
            'draftCreationAllowed' => true,
            'draftCreationPolicy' => 'draft_blocked_only_selected_direction',
            'wordstatDryRunAllowed' => false,
            'wordstatLiveAllowed' => false,
            'maxCopyVariants' => 1,
            'maxInternalLinks' => 3,
            'maxNeighboringDirections' => 3,
            'requiresExpensiveModeWarning' => false,
        ],
        'standard' => [
            'key' => 'standard',
            'label' => 'standard',
            'description' => 'Полный пакет по направлению: больше фраз, кластеров и материалов, dry-run только с групповым подтверждением.',
            'maxAiCalls' => 7,
            'maxSeedPhrases' => 60,
            'maxClusters' => 8,
            'maxDrafts' => 3,
            'draftCreationAllowed' => true,
            'draftCreationPolicy' => 'draft_blocked_only_group_confirmation',
            'wordstatDryRunAllowed' => true,
            'wordstatDryRunRequiresConfirmation' => true,
            'wordstatLiveAllowed' => false,
            'maxCopyVariants' => 3,
            'maxInternalLinks' => 5,
            'maxNeighboringDirections' => 8,
            'requiresExpensiveModeWarning' => false,
        ],
        'deep' => [
            'key' => 'deep',
            'label' => 'deep',
            'description' => 'Глубокая проработка дорогого направления. Перед запуском нужен явный warning о расходе и объёме проверки.',
            'maxAiCalls' => 14,
            'maxSeedPhrases' => 120,
            'maxClusters' => 15,
            'maxDrafts' => 5,
            'draftCreationAllowed' => true,
            'draftCreationPolicy' => 'draft_blocked_only_group_confirmation',
            'wordstatDryRunAllowed' => true,
            'wordstatDryRunRequiresConfirmation' => true,
            'wordstatLiveAllowed' => false,
            'maxCopyVariants' => 5,
            'maxInternalLinks' => 8,
            'maxNeighboringDirections' => 15,
            'requiresExpensiveModeWarning' => true,
        ],
    ];
}

function demand_ai_budget_mode(string $mode = ''): array
{
    $modes = demand_ai_budget_modes();
    $mode = demand_clean_string($mode, 80);

    return $modes[$mode] ?? $modes['economy'];
}

function demand_ai_budget_mode_label(string $mode = ''): string
{
    return (string) (demand_ai_budget_mode($mode)['label'] ?? 'economy');
}

function demand_ai_protected_non_change_guarantees(): array
{
    return [
        'Публикация не меняется',
        'Индексация не открывается',
        'sitemap.xml не меняется',
        'robots.txt не меняется',
        'canonical/public routes не меняются',
        'Цены не меняются',
        'Залоги не меняются',
        'Автомобили не меняются',
        'Заявки не меняются',
        'Аренды не меняются',
        'Клиенты не меняются',
        'Штрафы не меняются',
        'Финансы не меняются',
        'Документы не меняются',
        'Пользователи, роли и права не меняются',
        'Wordstat live не запускается без отдельного special confirmation',
    ];
}

function demand_ai_read_run_history(): array
{
    $path = defined('DEMAND_AI_RUN_HISTORY_FILE') ? DEMAND_AI_RUN_HISTORY_FILE : (DATA_DIR . 'demand-ai-run-history.json');

    return demand_read_container($path);
}

function demand_ai_save_run_history(array $data): void
{
    $path = defined('DEMAND_AI_RUN_HISTORY_FILE') ? DEMAND_AI_RUN_HISTORY_FILE : (DATA_DIR . 'demand-ai-run-history.json');
    $items = [];
    foreach ((array) ($data['items'] ?? []) as $item) {
        if (is_array($item)) {
            $items[] = demand_ai_normalize_run_history_record($item);
        }
    }
    demand_write_container($path, [
        'updatedAt' => (string) ($data['updatedAt'] ?? now_iso()),
        'items' => $items,
    ]);
}

function demand_ai_run_history_list(array $values, int $limit = 20, int $maxLength = 240): array
{
    $items = [];
    foreach ($values as $value) {
        $text = demand_clean_string($value, $maxLength);
        if ($text !== '') {
            $items[] = $text;
        }
        if (count($items) >= $limit) {
            break;
        }
    }

    return array_values(array_unique($items));
}

function demand_ai_normalize_run_history_record(array $record): array
{
    $directionId = demand_clean_string($record['directionId'] ?? '', 160);
    $directionTitle = demand_clean_string($record['directionTitle'] ?? '', 240);
    $budgetMode = (string) (demand_ai_budget_mode((string) ($record['budgetMode'] ?? 'economy'))['key'] ?? 'economy');
    $stopReason = demand_clean_string($record['stopReason'] ?? 'completed', 80);
    if (!in_array($stopReason, ['completed', 'budget_limit_reached', 'needs_confirmation', 'needs_human_decision', 'stale_fingerprint_reused', 'error', 'cancelled'], true)) {
        $stopReason = 'completed';
    }

    return [
        'runId' => demand_clean_string($record['runId'] ?? ('airh_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4))), 120),
        'sessionId' => demand_clean_string($record['sessionId'] ?? '', 120),
        'directionId' => $directionId,
        'directionTitle' => $directionTitle,
        'startedAt' => demand_clean_string($record['startedAt'] ?? now_iso(), 80),
        'finishedAt' => demand_clean_string($record['finishedAt'] ?? now_iso(), 80),
        'startedBy' => is_array($record['startedBy'] ?? null) ? [
            'userId' => demand_clean_string($record['startedBy']['userId'] ?? '', 120),
            'source' => demand_clean_string($record['startedBy']['source'] ?? '', 120),
        ] : [],
        'budgetMode' => $budgetMode,
        'summaryForOwner' => demand_clean_string($record['summaryForOwner'] ?? '', 1200),
        'completedActionLabels' => demand_ai_run_history_list((array) ($record['completedActionLabels'] ?? []), 30, 240),
        'createdObjectLabels' => demand_ai_run_history_list((array) ($record['createdObjectLabels'] ?? []), 30, 240),
        'changedFiles' => demand_ai_run_history_list((array) ($record['changedFiles'] ?? []), 20, 260),
        'stopReason' => $stopReason,
        'stopReasonLabel' => demand_ai_stop_reason_label($stopReason),
        'estimatedCostLabel' => demand_clean_string($record['estimatedCostLabel'] ?? '', 240),
        'tokenEstimate' => is_array($record['tokenEstimate'] ?? null) ? [
            'input' => isset($record['tokenEstimate']['input']) ? (int) $record['tokenEstimate']['input'] : null,
            'output' => isset($record['tokenEstimate']['output']) ? (int) $record['tokenEstimate']['output'] : null,
            'total' => isset($record['tokenEstimate']['total']) ? (int) $record['tokenEstimate']['total'] : null,
        ] : [],
        'wordstatCostEstimate' => is_array($record['wordstatCostEstimate'] ?? null) ? [
            'requests' => isset($record['wordstatCostEstimate']['requests']) ? (int) $record['wordstatCostEstimate']['requests'] : 0,
            'estimatedRub' => isset($record['wordstatCostEstimate']['estimatedRub']) ? (float) $record['wordstatCostEstimate']['estimatedRub'] : 0.0,
        ] : [],
        'wordstatStatus' => demand_clean_string($record['wordstatStatus'] ?? '', 120),
        'wordstatRunId' => demand_clean_string($record['wordstatRunId'] ?? '', 120),
        'wordstatPacketId' => demand_clean_string($record['wordstatPacketId'] ?? '', 120),
        'seedPhrasesCount' => isset($record['seedPhrasesCount']) ? max(0, (int) $record['seedPhrasesCount']) : 0,
        'regionIds' => demand_ai_run_history_list((array) ($record['regionIds'] ?? []), 40, 80),
        'methods' => demand_ai_run_history_list((array) ($record['methods'] ?? []), 20, 80),
        'estimatedRequests' => isset($record['estimatedRequests']) ? max(0, (int) $record['estimatedRequests']) : 0,
        'estimatedCostRub' => isset($record['estimatedCostRub']) ? max(0.0, (float) $record['estimatedCostRub']) : 0.0,
        'nextSafeAction' => demand_clean_string($record['nextSafeAction'] ?? '', 260),
        'notChangedLabel' => demand_ai_run_history_list((array) ($record['notChangedLabel'] ?? demand_ai_protected_non_change_guarantees()), 30, 260),
        'processingFingerprint' => demand_clean_string($record['processingFingerprint'] ?? '', 160),
    ];
}

function demand_ai_stop_reason_labels(): array
{
    return [
        'completed' => 'AI закончил подготовку направления',
        'budget_limit_reached' => 'AI остановился по лимиту',
        'needs_confirmation' => 'Нужно подтверждение',
        'needs_human_decision' => 'Нужно решение человека',
        'stale_fingerprint_reused' => 'AI не повторял работу: данные не изменились',
        'error' => 'AI остановился из-за ошибки',
        'cancelled' => 'Сессия остановлена пользователем',
    ];
}

function demand_ai_stop_reason_label(string $reason): string
{
    $reason = demand_clean_string($reason, 80);
    return demand_ai_stop_reason_labels()[$reason] ?? ($reason !== '' ? $reason : 'Статус сессии не указан');
}

function demand_ai_append_run_history(array $record): array
{
    $normalized = demand_ai_normalize_run_history_record($record);
    $data = demand_ai_read_run_history();
    $items = array_values(array_filter((array) ($data['items'] ?? []), static function ($item) use ($normalized): bool {
        return is_array($item) && (string) ($item['runId'] ?? '') !== (string) ($normalized['runId'] ?? '');
    }));
    $items[] = $normalized;
    usort($items, static fn(array $a, array $b): int => strcmp((string) ($b['finishedAt'] ?? ''), (string) ($a['finishedAt'] ?? '')));
    demand_ai_save_run_history([
        'updatedAt' => now_iso(),
        'items' => array_slice($items, 0, 500),
    ]);

    return $normalized;
}

function demand_ai_latest_run_for_direction(string $directionId): ?array
{
    $directionId = demand_clean_string($directionId, 160);
    if ($directionId === '') {
        return null;
    }
    $matches = array_values(array_filter(demand_ai_read_run_history()['items'], static function ($item) use ($directionId): bool {
        return is_array($item) && (string) ($item['directionId'] ?? '') === $directionId;
    }));
    usort($matches, static fn(array $a, array $b): int => strcmp((string) ($b['finishedAt'] ?? ''), (string) ($a['finishedAt'] ?? '')));

    return $matches[0] ?? null;
}

function demand_ai_items_by_id(array $items): array
{
    $map = [];
    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }
        $id = (string) ($item['id'] ?? '');
        if ($id !== '') {
            $map[$id] = $item;
        }
    }

    return $map;
}

function demand_ai_stable_subset(array $item, array $keys): array
{
    $result = [];
    foreach ($keys as $key) {
        if (array_key_exists($key, $item)) {
            $result[$key] = $item[$key];
        }
    }

    return $result;
}

function demand_ai_build_direction_id(string $title, string $region = '', string $topic = '', string $intentType = ''): string
{
    $parts = [
        demand_normalize_phrase($title),
        demand_normalize_phrase($region),
        demand_normalize_phrase($topic),
        demand_normalize_phrase($intentType),
    ];
    $base = implode('|', array_filter($parts, static fn(string $value): bool => $value !== ''));
    if ($base === '') {
        $base = 'demand-direction';
    }

    return 'dir_' . substr(hash('sha256', $base), 0, 18);
}

function demand_ai_direction_region_from_source(array $source): array
{
    $regionName = demand_clean_string($source['regionName'] ?? $source['detectedCity'] ?? $source['detectedRegion'] ?? $source['region'] ?? '', 160);
    $clusterType = (string) ($source['clusterType'] ?? $source['planType'] ?? '');
    $type = 'none';
    if ($regionName !== '') {
        $type = in_array($clusterType, ['city'], true) || preg_match('/ялта|симферополь|севастополь|алушта|евпатория|феодосия|керчь|саки/iu', $regionName) ? 'city' : 'region';
    }
    $confidence = 'needs_confirmation';
    if ($regionName === '') {
        $confidence = 'not_applicable';
    } elseif (preg_match('/крым|ялта|симферополь|севастополь|алушта|евпатория|феодосия|керчь|саки/iu', $regionName)) {
        $confidence = 'confirmed';
    }

    return [
        'type' => $type,
        'name' => $regionName,
        'regionId' => demand_clean_string($source['regionId'] ?? '', 80),
        'confidence' => $confidence,
    ];
}

function demand_ai_direction_intent_type(array $source): string
{
    $clusterType = (string) ($source['clusterType'] ?? $source['planType'] ?? '');
    $intent = demand_normalize_phrase((string) ($source['intent'] ?? $source['targetIntent'] ?? ''));
    $title = demand_normalize_phrase((string) ($source['title'] ?? $source['name'] ?? $source['phrase'] ?? ''));

    if (in_array($clusterType, ['excluded'], true) || str_contains($intent, 'unsupported')) {
        return 'mixed';
    }
    if (in_array($clusterType, ['car_class'], true) || preg_match('/минивен|минивэн|7 мест|семимест|кабриолет|кроссовер|седан/u', $title)) {
        return 'car_class';
    }
    if (in_array($clusterType, ['condition', 'price', 'duration', 'family'], true) || preg_match('/залог|документ|услов|срок|без водителя/u', $title)) {
        return 'condition';
    }
    if (in_array($clusterType, ['airport'], true) || preg_match('/аэропорт|подача|доставка|прилет|прилёт/u', $title)) {
        return 'service_condition';
    }
    if (preg_match('/сезон|лето|кабриолет/u', $title)) {
        return 'seasonal';
    }
    if (preg_match('/faq|вопрос|залог/u', $title)) {
        return 'faq';
    }

    return 'commercial';
}

function demand_ai_direction_topic_from_source(array $source, string $intentType): string
{
    $title = demand_clean_string($source['title'] ?? $source['name'] ?? $source['phrase'] ?? '', 240);
    $normalized = demand_normalize_phrase($title);
    if (str_contains($normalized, 'залог')) {
        return 'условия залога';
    }
    if (preg_match('/минивен|минивэн|7 мест|семимест/u', $normalized)) {
        return 'минивэны / 7 мест';
    }
    if (str_contains($normalized, 'кабриолет')) {
        return 'кабриолеты';
    }
    if (str_contains($normalized, 'аэропорт')) {
        return 'аэропорт / получение авто';
    }
    if ($intentType === 'condition') {
        return 'условия аренды';
    }
    if ($intentType === 'car_class') {
        return 'класс авто';
    }

    return 'аренда авто';
}

function demand_ai_direction_priority(array $source): string
{
    $priority = (string) ($source['priority'] ?? $source['priorityLevel'] ?? $source['recommendedDecision'] ?? '');
    $decision = (string) ($source['recommendedDecision'] ?? '');
    $riskFlags = (array) ($source['riskFlags'] ?? ($source['pageRiskProfile']['flags'] ?? []));
    $score = (int) ($source['priorityScore'] ?? $source['decisionScore'] ?? 0);
    $normalizedTitle = demand_normalize_phrase((string) ($source['title'] ?? $source['name'] ?? $source['phrase'] ?? ''));

    if (in_array($priority, ['blocked', 'do_not_publish', 'not_relevant', 'excluded'], true)
        || in_array($decision, ['do_not_publish', 'ignore_as_irrelevant'], true)
        || array_intersect($riskFlags, ['not_relevant_for_car_rental', 'unsupported_legal_request'])
        || preg_match('/такси|трансфер|ремонт|запчаст|купить|каршеринг|без прав|без паспорта/u', $normalizedTitle)
    ) {
        return 'no_go';
    }
    if (in_array($priority, ['high', 'ready', 'ready_for_draft', 'needs_business_decision'], true) || $score >= 60) {
        return 'high';
    }
    if (in_array($priority, ['medium', 'manual_review', 'needs_review'], true) || $score >= 25) {
        return 'medium';
    }

    return 'low';
}

function demand_ai_workspace_context(string $scopeFilter = ''): array
{
    $scopes = demand_current_scope_filter($scopeFilter);
    $syncRuns = [];
    if (defined('DEMAND_SYNC_RUNS_FILE')) {
        foreach (demand_read_container(DEMAND_SYNC_RUNS_FILE)['items'] as $item) {
            if (is_array($item) && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopes, true)) {
                $syncRuns[] = $item;
            }
        }
    }
    $aiRuns = [];
    if (defined('AI_API_RUNS_FILE')) {
        foreach (demand_read_container(AI_API_RUNS_FILE)['items'] as $item) {
            if (is_array($item) && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopes, true)) {
                $aiRuns[] = $item;
            }
        }
    }

    return [
        'scopeFilter' => $scopeFilter,
        'scopeIds' => $scopes,
        'keywords' => demand_visible_keywords($scopeFilter),
        'recommendations' => demand_visible_recommendations($scopeFilter),
        'drafts' => demand_visible_drafts($scopeFilter),
        'clusters' => function_exists('demand_map_visible_clusters') ? demand_map_visible_clusters($scopeFilter) : [],
        'plans' => function_exists('demand_map_visible_launch_plan') ? demand_map_visible_launch_plan($scopeFilter) : [],
        'briefs' => function_exists('demand_map_visible_content_briefs') ? demand_map_visible_content_briefs($scopeFilter) : [],
        'hints' => function_exists('demand_map_visible_card_hints') ? demand_map_visible_card_hints($scopeFilter) : [],
        'syncRuns' => $syncRuns,
        'aiRuns' => $aiRuns,
        'runHistory' => demand_ai_read_run_history()['items'],
        'wordstatCostLedger' => function_exists('wordstat_read_cost_ledger') ? wordstat_read_cost_ledger() : [],
        'wordstatSettings' => function_exists('wordstat_current_settings') ? wordstat_current_settings() : [],
        'aiSettings' => function_exists('openai_ai_settings') ? openai_ai_settings() : [],
        'copySettings' => function_exists('demand_ai_copy_settings') ? demand_ai_copy_settings() : [],
        'regionsCache' => defined('WORDSTAT_REGIONS_CACHE_FILE') && is_file(WORDSTAT_REGIONS_CACHE_FILE)
            ? read_json_file(WORDSTAT_REGIONS_CACHE_FILE, demand_default_container())
            : demand_default_container(),
    ];
}

function demand_ai_direction_from_source(array $source, string $scopeId = 'rent_rk'): array
{
    $title = demand_clean_string($source['title'] ?? $source['name'] ?? $source['phrase'] ?? 'Направление спроса', 240);
    $intentType = demand_ai_direction_intent_type($source);
    $topic = demand_ai_direction_topic_from_source($source, $intentType);
    $region = demand_ai_direction_region_from_source($source);
    $directionId = demand_ai_build_direction_id($title, (string) ($region['name'] ?? ''), $topic, $intentType);

    return [
        'directionId' => $directionId,
        'scope_id' => demand_normalize_scope_id($scopeId),
        'title' => $title,
        'region' => $region,
        'topic' => $topic,
        'intentType' => $intentType,
        'priority' => demand_ai_direction_priority($source),
        'status' => 'not_started',
        'lastProcessedAt' => null,
        'lastWordstatDryRunAt' => null,
        'lastWordstatLiveAt' => null,
        'nextRefreshRecommendedAt' => null,
        'linkedKeywordIds' => array_values(array_unique(array_filter(array_map('strval', (array) ($source['keywordIds'] ?? []))))),
        'linkedDraftIds' => [],
        'linkedContentBriefIds' => [],
        'linkedDecisionIds' => [],
        'linkedAiRunIds' => [],
        'linkedClusterIds' => array_values(array_filter([(string) ($source['clusterId'] ?? $source['id'] ?? '')])),
        'linkedLaunchPlanIds' => array_values(array_filter([(string) ($source['launchPlanId'] ?? '')])),
        'linkedCarHintIds' => [],
        'budgetMode' => 'economy',
        'processingFingerprint' => null,
        'riskFlags' => demand_unique_strings((array) ($source['riskFlags'] ?? ($source['pageRiskProfile']['flags'] ?? []))),
        'nextAction' => [],
    ];
}

function demand_ai_merge_direction(array $base, array $extra): array
{
    foreach (['linkedKeywordIds', 'linkedDraftIds', 'linkedContentBriefIds', 'linkedDecisionIds', 'linkedAiRunIds', 'linkedClusterIds', 'linkedLaunchPlanIds', 'linkedCarHintIds', 'riskFlags'] as $key) {
        $base[$key] = array_values(array_unique(array_filter(array_merge((array) ($base[$key] ?? []), (array) ($extra[$key] ?? [])))));
    }
    foreach (['lastProcessedAt', 'lastWordstatDryRunAt', 'lastWordstatLiveAt'] as $key) {
        $candidate = (string) ($extra[$key] ?? '');
        if ($candidate !== '' && $candidate > (string) ($base[$key] ?? '')) {
            $base[$key] = $candidate;
        }
    }
    if (demand_ai_priority_rank((string) ($extra['priority'] ?? 'low')) > demand_ai_priority_rank((string) ($base['priority'] ?? 'low'))) {
        $base['priority'] = (string) ($extra['priority'] ?? $base['priority']);
    }

    return $base;
}

function demand_ai_priority_rank(string $priority): int
{
    return match ($priority) {
        'high' => 4,
        'medium' => 3,
        'low' => 2,
        'no_go' => 1,
        default => 0,
    };
}

function demand_ai_direction_matches_keywords(array $direction, array $keywordIds): bool
{
    return (bool) array_intersect((array) ($direction['linkedKeywordIds'] ?? []), $keywordIds);
}

function demand_ai_direction_run_matches(array $direction, array $run): bool
{
    $haystack = demand_normalize_phrase(implode(' ', array_merge(
        (array) ($run['seedPhrases'] ?? []),
        [(string) ($run['task'] ?? ''), (string) ($run['entityId'] ?? '')]
    )));
    if ($haystack === '') {
        return false;
    }
    $title = demand_normalize_phrase((string) ($direction['title'] ?? ''));
    $topic = demand_normalize_phrase((string) ($direction['topic'] ?? ''));
    $region = demand_normalize_phrase((string) ($direction['region']['name'] ?? ''));

    return ($region !== '' && str_contains($haystack, $region))
        || ($topic !== '' && str_contains($haystack, $topic))
        || ($title !== '' && str_contains($haystack, $title));
}

function demand_ai_direction_refresh_at(array $direction): ?string
{
    $base = (string) ($direction['lastWordstatLiveAt'] ?? $direction['lastWordstatDryRunAt'] ?? $direction['lastProcessedAt'] ?? '');
    if ($base === '') {
        return null;
    }
    $interval = in_array((string) ($direction['intentType'] ?? ''), ['seasonal', 'service_condition'], true) ? '+45 days' : '+90 days';
    $timestamp = strtotime($base . ' ' . $interval);
    if (!$timestamp) {
        return null;
    }

    return date('c', $timestamp);
}

function demand_ai_direction_processing_fingerprint(array $direction, array $context): string
{
    $keywordMap = demand_ai_items_by_id((array) ($context['keywords'] ?? []));
    $draftMap = demand_ai_items_by_id((array) ($context['drafts'] ?? []));
    $briefMap = demand_ai_items_by_id((array) ($context['briefs'] ?? []));
    $hintMap = demand_ai_items_by_id((array) ($context['hints'] ?? []));
    $syncMap = demand_ai_items_by_id((array) ($context['syncRuns'] ?? []));
    $aiRunMap = demand_ai_items_by_id((array) ($context['aiRuns'] ?? []));
    $payload = [
        'direction' => [
            'title' => demand_normalize_phrase((string) ($direction['title'] ?? '')),
            'region' => demand_normalize_phrase((string) ($direction['region']['name'] ?? '')),
            'topic' => demand_normalize_phrase((string) ($direction['topic'] ?? '')),
            'intentType' => (string) ($direction['intentType'] ?? ''),
            'budgetMode' => (string) ($direction['budgetMode'] ?? 'economy'),
        ],
        'keywords' => [],
        'drafts' => [],
        'briefs' => [],
        'hints' => [],
        'syncRuns' => [],
        'aiRuns' => [],
        'versions' => [
            'wordstatRegionsCache' => (string) (($context['regionsCache']['updatedAt'] ?? '') ?: (defined('WORDSTAT_REGIONS_CACHE_FILE') && is_file(WORDSTAT_REGIONS_CACHE_FILE) ? date('c', (int) filemtime(WORDSTAT_REGIONS_CACHE_FILE)) : '')),
            'aiSettings' => (string) ($context['aiSettings']['updatedAt'] ?? ''),
            'copySettings' => (string) ($context['copySettings']['updatedAt'] ?? ''),
            'safetyRuleVersion' => 'demand-direction-safety-v1',
            'actionRegistryVersion' => function_exists('demand_ai_dialog_action_registry') ? hash('sha256', json_encode(array_keys(demand_ai_dialog_action_registry()), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '') : '',
        ],
    ];
    foreach ((array) ($direction['linkedKeywordIds'] ?? []) as $id) {
        if (isset($keywordMap[$id])) {
            $payload['keywords'][] = demand_ai_stable_subset($keywordMap[$id], ['id', 'phrase', 'normalizedPhrase', 'source', 'status', 'intent', 'frequency', 'negativeIntent', 'updatedAt', 'createdAt']);
        }
    }
    foreach ((array) ($direction['linkedDraftIds'] ?? []) as $id) {
        if (isset($draftMap[$id])) {
            $payload['drafts'][] = demand_ai_stable_subset($draftMap[$id], ['id', 'slug', 'title', 'h1', 'metaDescription', 'intro', 'contentBlocks', 'faq', 'internalLinks', 'internalLinkSuggestions', 'readinessStatus', 'publishStatus', 'indexStatus', 'updatedAt']);
        }
    }
    foreach ((array) ($direction['linkedContentBriefIds'] ?? []) as $id) {
        if (isset($briefMap[$id])) {
            $payload['briefs'][] = demand_ai_stable_subset($briefMap[$id], ['id', 'title', 'targetIntent', 'mustAnswer', 'mustNotPromise', 'recommendedBlocks', 'faqQuestions', 'updatedAt', 'createdAt']);
        }
    }
    foreach ((array) ($direction['linkedCarHintIds'] ?? []) as $id) {
        if (isset($hintMap[$id])) {
            $payload['hints'][] = demand_ai_stable_subset($hintMap[$id], ['id', 'carId', 'clusterId', 'launchPlanId', 'hintType', 'priority', 'message', 'suggestedText', 'status', 'updatedAt', 'createdAt']);
        }
    }
    foreach ((array) ($direction['linkedWordstatRunIds'] ?? []) as $id) {
        if (isset($syncMap[$id])) {
            $payload['syncRuns'][] = demand_ai_stable_subset($syncMap[$id], ['id', 'mode', 'status', 'dryRun', 'startedAt', 'finishedAt', 'seedPhrases', 'regionIds', 'methods']);
        }
    }
    foreach ((array) ($direction['linkedAiRunIds'] ?? []) as $id) {
        if (isset($aiRunMap[$id])) {
            $payload['aiRuns'][] = demand_ai_stable_subset($aiRunMap[$id], ['id', 'createdAt', 'task', 'entityType', 'entityId', 'status', 'promptHash', 'responseHash']);
        }
    }

    return 'sha256:' . hash('sha256', json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION) ?: '');
}

function demand_ai_direction_status(array $direction, array $context = []): string
{
    if ((string) ($direction['priority'] ?? '') === 'no_go') {
        return 'not_relevant';
    }
    $latestRun = is_array($direction['latestRun'] ?? null) ? $direction['latestRun'] : null;
    if ($latestRun && (string) ($latestRun['stopReason'] ?? '') === 'stale_fingerprint_reused') {
        return 'prepared';
    }
    if (!empty($direction['linkedDecisionIds']) || array_intersect((array) ($direction['riskFlags'] ?? []), ['possible_false_promise', 'condition_not_supported', 'region_not_confirmed', 'airport_delivery_not_confirmed', 'availability_claim_risk', 'needs_human_review'])) {
        return 'needs_decision';
    }
    $now = now_iso();
    if (!empty($direction['nextRefreshRecommendedAt']) && (string) $direction['nextRefreshRecommendedAt'] < $now && (!empty($direction['lastProcessedAt']) || !empty($direction['lastWordstatDryRunAt']) || !empty($direction['lastWordstatLiveAt']))) {
        return 'stale';
    }
    $draftMap = demand_ai_items_by_id((array) ($context['drafts'] ?? []));
    foreach ((array) ($direction['linkedDraftIds'] ?? []) as $draftId) {
        $draft = $draftMap[(string) $draftId] ?? null;
        if (!$draft) {
            continue;
        }
        $readiness = (string) ($draft['readinessStatus'] ?? 'not_checked');
        $publish = (string) ($draft['publishStatus'] ?? 'draft');
        if (in_array($readiness, ['ready'], true) || in_array($publish, ['published_noindex', 'ready_for_index_review'], true)) {
            return 'ready_for_manual_publish_review';
        }
        if (in_array($readiness, ['needs_fixes', 'blocked'], true)) {
            return 'needs_decision';
        }
    }
    if (!empty($direction['linkedDraftIds'])
        || !empty($direction['linkedContentBriefIds'])
        || !empty($direction['linkedCarHintIds'])
        || !empty($direction['lastProcessedAt'])
        || !empty($direction['lastWordstatDryRunAt'])
        || !empty($direction['lastWordstatLiveAt'])
    ) {
        return 'prepared';
    }

    return 'not_started';
}

function demand_ai_direction_next_action(array $direction): array
{
    $status = (string) ($direction['status'] ?? 'not_started');
    $directionId = (string) ($direction['directionId'] ?? '');
    return match ($status) {
        'not_started' => [
            'label' => 'Запустить AI-сессию',
            'actionKey' => 'direction_start_confirm',
            'confirmationLevel' => 'start_session',
            'directionId' => $directionId,
        ],
        'needs_decision' => [
            'label' => 'Принять решение',
            'actionKey' => 'direction_business_risk_review',
            'confirmationLevel' => 'human_decision',
            'directionId' => $directionId,
        ],
        'stale' => [
            'label' => 'Обновить dry-run',
            'actionKey' => 'direction_refresh_due',
            'confirmationLevel' => 'grouped',
            'directionId' => $directionId,
        ],
        'ready_for_manual_publish_review' => [
            'label' => 'Проверить перед публикацией',
            'actionKey' => 'manual_publish_review',
            'confirmationLevel' => 'manual',
            'directionId' => $directionId,
        ],
        'prepared' => [
            'label' => 'Открыть материалы',
            'actionKey' => 'open_materials',
            'confirmationLevel' => 'none',
            'directionId' => $directionId,
        ],
        'postponed' => [
            'label' => 'Вернуть в очередь',
            'actionKey' => 'direction_resume',
            'confirmationLevel' => 'none',
            'directionId' => $directionId,
        ],
        'not_relevant' => [
            'label' => 'Не делать',
            'actionKey' => 'keep_not_relevant',
            'confirmationLevel' => 'none',
            'directionId' => $directionId,
        ],
        default => [
            'label' => 'Посмотреть направление',
            'actionKey' => 'open_direction',
            'confirmationLevel' => 'none',
            'directionId' => $directionId,
        ],
    };
}

function demand_direction_wordstat_not_changed_guarantees(): array
{
    return [
        'Demand keywords',
        'recommendations',
        'demand map',
        'sitemap.xml',
        'robots.txt',
        'publication',
        'indexing',
        'business data',
    ];
}

function demand_direction_wordstat_normalize_methods($value): array
{
    $methods = is_array($value) ? $value : preg_split('/[\s,;]+/u', (string) $value);
    $methods = is_array($methods) ? $methods : [];
    $allowed = function_exists('wordstat_supported_methods') ? wordstat_supported_methods() : ['getTop', 'getDynamics', 'getRegionsDistribution'];
    $normalized = [];
    foreach ($methods as $method) {
        $method = demand_clean_string((string) $method, 80);
        if ($method !== '' && in_array($method, $allowed, true)) {
            $normalized[] = $method;
        }
    }

    return array_values(array_unique($normalized));
}

function demand_direction_wordstat_region_label(array $region): string
{
    $id = demand_clean_string($region['id'] ?? '', 80);
    $name = demand_clean_string($region['name'] ?? '', 160);
    $path = $region['path'] ?? [];
    if (!is_array($path)) {
        $path = $path !== '' ? [(string) $path] : [];
    }
    $path = array_values(array_filter(array_map(static fn($value): string => demand_clean_string($value, 160), $path)));
    $label = $name !== '' ? $name : ($id !== '' ? 'Region #' . $id : 'Region');
    if ($id !== '') {
        $label .= ' #' . $id;
    }
    if ($path) {
        $label .= ' (' . implode(' / ', $path) . ')';
    }

    return $label;
}

function demand_direction_wordstat_regions_by_id(array $regions): array
{
    $map = [];
    foreach ($regions as $region) {
        if (!is_array($region)) {
            continue;
        }
        $id = demand_clean_string($region['id'] ?? '', 80);
        if ($id !== '') {
            $map[$id] = $region;
        }
    }

    return $map;
}

function demand_direction_wordstat_region_norm(array $region, string $key): string
{
    if ($key === 'path') {
        $path = $region['path'] ?? [];
        if (!is_array($path)) {
            $path = $path !== '' ? [(string) $path] : [];
        }

        return demand_normalize_phrase(implode(' ', array_map(static fn($value): string => (string) $value, $path)));
    }
    $value = (string) ($region['normalizedName'] ?? '');
    if ($value === '') {
        $value = demand_normalize_phrase((string) ($region['name'] ?? ''));
    }

    return $value;
}

function demand_direction_wordstat_region_candidates(array $direction): array
{
    $haystack = demand_normalize_phrase(implode(' ', [
        (string) ($direction['title'] ?? ''),
        (string) ($direction['topic'] ?? ''),
        (string) ($direction['region']['name'] ?? ''),
    ]));
    $candidates = [];
    $explicit = demand_clean_string($direction['region']['name'] ?? '', 160);
    if ($explicit !== '') {
        $candidates[] = $explicit;
    }
    $known = ['Ялта', 'Крым', 'Республика Крым', 'Симферополь', 'Севастополь', 'Алушта', 'Евпатория', 'Феодосия', 'Керчь', 'Саки'];
    foreach ($known as $name) {
        $normalized = demand_normalize_phrase($name);
        if ($normalized !== '' && str_contains($haystack, $normalized)) {
            $candidates[] = $name;
        }
    }

    return array_values(array_unique(array_filter($candidates)));
}

function demand_direction_wordstat_match_region(array $regions, string $candidate): ?array
{
    $candidate = demand_clean_string($candidate, 160);
    $normalized = demand_normalize_phrase($candidate);
    if ($normalized === '') {
        return null;
    }
    $aliases = [
        'крым' => ['крым', 'республика крым'],
        'республика крым' => ['крым', 'республика крым'],
        'ялта' => ['ялта'],
        'симферополь' => ['симферополь'],
        'севастополь' => ['севастополь'],
        'алушта' => ['алушта'],
        'евпатория' => ['евпатория'],
        'феодосия' => ['феодосия'],
        'керчь' => ['керчь'],
        'саки' => ['саки'],
    ];
    $targetNames = $aliases[$normalized] ?? [$normalized];
    $matches = [];
    foreach ($regions as $region) {
        if (!is_array($region)) {
            continue;
        }
        $name = demand_direction_wordstat_region_norm($region, 'name');
        if ($name !== '' && in_array($name, $targetNames, true)) {
            $matches[] = $region;
        }
    }
    if (!$matches) {
        return null;
    }
    if (count($matches) === 1) {
        return $matches[0];
    }

    $crimeaMatches = array_values(array_filter($matches, static function (array $region): bool {
        $path = demand_direction_wordstat_region_norm($region, 'path');
        $name = demand_direction_wordstat_region_norm($region, 'name');
        return str_contains($path, 'крым') || str_contains($name, 'крым');
    }));
    if (count($crimeaMatches) === 1) {
        return $crimeaMatches[0];
    }

    return null;
}

function demand_direction_wordstat_region_details(array $direction, array $context = []): array
{
    $regions = array_values(array_filter((array) ($context['regionsCache']['regions'] ?? []), 'is_array'));
    if (!$regions && function_exists('wordstat_read_regions_cache')) {
        $regions = array_values(array_filter((array) (wordstat_read_regions_cache()['regions'] ?? []), 'is_array'));
    }
    $byId = demand_direction_wordstat_regions_by_id($regions);
    $warnings = [];
    $ids = [];
    $labels = [];
    $unmatched = [];

    $explicitId = demand_clean_string($direction['region']['regionId'] ?? '', 80);
    $confidence = (string) ($direction['region']['confidence'] ?? '');
    if ($explicitId !== '' && ($confidence === 'confirmed' || isset($byId[$explicitId]))) {
        $ids[] = $explicitId;
    }

    foreach (demand_direction_wordstat_region_candidates($direction) as $candidate) {
        $match = demand_direction_wordstat_match_region($regions, $candidate);
        if ($match) {
            $id = demand_clean_string($match['id'] ?? '', 80);
            if ($id !== '') {
                $ids[] = $id;
            }
        } else {
            $unmatched[] = $candidate;
        }
    }

    $ids = array_values(array_unique(array_filter($ids)));
    foreach ($ids as $id) {
        $labels[] = isset($byId[$id]) ? demand_direction_wordstat_region_label($byId[$id]) : ('Region #' . $id);
    }

    $needsConfirmation = false;
    if (!$ids) {
        $needsConfirmation = true;
        $warnings[] = 'needs_region_confirmation';
    }
    if ($unmatched) {
        $needsConfirmation = true;
        $warnings[] = 'needs_region_confirmation';
        $warnings[] = 'region_not_matched_reliably:' . implode(', ', array_values(array_unique($unmatched)));
    }
    if (!$regions) {
        $needsConfirmation = true;
        $warnings[] = 'wordstat_regions_cache_empty';
    }

    return [
        'regionIds' => $ids,
        'regionLabels' => array_values(array_unique($labels)),
        'needsRegionConfirmation' => $needsConfirmation,
        'warnings' => array_values(array_unique($warnings)),
    ];
}

function demand_direction_wordstat_region_ids(array $direction, array $context = []): array
{
    return demand_direction_wordstat_region_details($direction, $context)['regionIds'];
}

function demand_direction_wordstat_seed_phrases(array $direction, array $context = []): array
{
    $keywordIds = array_values(array_unique(array_filter(array_map('strval', (array) ($direction['linkedKeywordIds'] ?? [])))));
    $phrases = [];
    foreach ((array) ($context['keywords'] ?? []) as $keyword) {
        if (!is_array($keyword)) {
            continue;
        }
        $keywordId = (string) ($keyword['id'] ?? '');
        if ($keywordIds && !in_array($keywordId, $keywordIds, true)) {
            continue;
        }
        $status = (string) ($keyword['status'] ?? '');
        $category = (string) ($keyword['category'] ?? '');
        $intent = (string) ($keyword['intent'] ?? '');
        if (!empty($keyword['isExcluded'])
            || !empty($keyword['negativeIntent'])
            || in_array($status, ['excluded', 'not_target', 'archived'], true)
            || in_array($category, ['excluded', 'no_go'], true)
            || in_array($intent, ['unsafe_or_unsupported'], true)
        ) {
            continue;
        }
        $phrase = demand_clean_string($keyword['phrase'] ?? $keyword['normalizedPhrase'] ?? '', 240);
        if ($phrase !== '') {
            $phrases[demand_normalize_phrase($phrase)] = $phrase;
        }
    }

    foreach ((array) ($direction['seedPhrases'] ?? []) as $phrase) {
        $phrase = demand_clean_string($phrase, 240);
        if ($phrase !== '') {
            $phrases[demand_normalize_phrase($phrase)] = $phrase;
        }
    }

    $mode = demand_ai_budget_mode((string) ($direction['budgetMode'] ?? 'standard'));
    $limit = max(0, (int) ($mode['maxSeedPhrases'] ?? 0));
    $result = array_values($phrases);
    if ($limit > 0) {
        $result = array_slice($result, 0, $limit);
    }

    return $result;
}

function demand_direction_wordstat_methods(array $direction = [], string $budgetMode = ''): array
{
    $budgetMode = $budgetMode !== '' ? $budgetMode : (string) ($direction['budgetMode'] ?? 'standard');
    $allowed = function_exists('wordstat_supported_methods') ? wordstat_supported_methods() : ['getTop', 'getDynamics', 'getRegionsDistribution'];
    $methods = match ((string) (demand_ai_budget_mode($budgetMode)['key'] ?? 'standard')) {
        'deep' => $allowed,
        'standard' => ['getTop', 'getDynamics'],
        default => ['getTop'],
    };

    return array_values(array_intersect($methods, $allowed)) ?: array_values($allowed);
}

function demand_direction_wordstat_cost_preview(array $seedPhrases, array $regionIds, array $methods): array
{
    $phrases = function_exists('wordstat_parse_seed_phrases') ? wordstat_parse_seed_phrases($seedPhrases) : array_values(array_filter($seedPhrases));
    $regions = function_exists('wordstat_parse_region_ids') ? wordstat_parse_region_ids($regionIds) : array_values(array_filter($regionIds));
    $methods = demand_direction_wordstat_normalize_methods($methods);
    $estimatedRequests = count($phrases) * count($methods);
    $estimatedCostRub = 0.0;
    foreach ($methods as $method) {
        $estimatedCostRub += function_exists('wordstat_estimate_cost') ? wordstat_estimate_cost($method, count($phrases)) : 0.0;
    }
    $warnings = [];
    if (!$phrases) {
        $warnings[] = 'seed_phrases_empty';
    }
    if (!$regions) {
        $warnings[] = 'regions_empty';
    }
    if (!$methods) {
        $warnings[] = 'methods_empty';
    }

    return [
        'estimatedRequests' => $estimatedRequests,
        'estimatedCostRub' => round($estimatedCostRub, 4),
        'warnings' => $warnings,
    ];
}

function demand_direction_wordstat_packet_fingerprint(array $seedPhrases, array $regionIds, array $methods): string
{
    $phrases = array_values(array_unique(array_filter(array_map(static fn($phrase): string => demand_normalize_phrase((string) $phrase), $seedPhrases))));
    $regions = array_values(array_unique(array_filter(array_map('strval', $regionIds))));
    $methods = array_values(array_unique(array_filter(array_map('strval', $methods))));
    sort($phrases);
    sort($regions);
    sort($methods);

    return substr(hash('sha256', json_encode([
        'seedPhrases' => $phrases,
        'regionIds' => $regions,
        'methods' => $methods,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)), 0, 32);
}

function demand_direction_wordstat_run_direction_id(array $run): string
{
    $metadata = is_array($run['metadata'] ?? null) ? $run['metadata'] : [];

    return demand_clean_string($run['directionId'] ?? $metadata['directionId'] ?? '', 160);
}

function demand_direction_wordstat_existing_dry_run(array $packet, array $context = []): ?array
{
    $directionId = (string) ($packet['directionId'] ?? '');
    $fingerprint = (string) ($packet['packetFingerprint'] ?? demand_direction_wordstat_packet_fingerprint((array) ($packet['seedPhrases'] ?? []), (array) ($packet['regionIds'] ?? []), (array) ($packet['methods'] ?? [])));
    foreach ((array) ($context['syncRuns'] ?? []) as $run) {
        if (!is_array($run)
            || (string) ($run['source'] ?? '') !== 'wordstat'
            || empty($run['dryRun'])
            || in_array((string) ($run['status'] ?? ''), ['failed', 'cancelled'], true)
        ) {
            continue;
        }
        $runDirectionId = demand_direction_wordstat_run_direction_id($run);
        if ($directionId !== '' && $runDirectionId !== '' && $runDirectionId !== $directionId) {
            continue;
        }
        $metadata = is_array($run['metadata'] ?? null) ? $run['metadata'] : [];
        $runFingerprint = (string) ($run['packetFingerprint'] ?? $metadata['packetFingerprint'] ?? '');
        if ($runFingerprint === '') {
            $runFingerprint = demand_direction_wordstat_packet_fingerprint(
                (array) ($run['seedPhrases'] ?? []),
                (array) ($run['regionIds'] ?? []),
                (array) ($run['methods'] ?? [])
            );
        }
        if ($runFingerprint === $fingerprint) {
            return $run;
        }
    }

    return null;
}

function demand_find_direction_by_id(string $directionId, string $scopeFilter = '', array $context = []): ?array
{
    $directionId = demand_clean_string($directionId, 160);
    if ($directionId === '') {
        return null;
    }
    $directions = (array) ($context['directions'] ?? []);
    if (!$directions) {
        $context = $context ?: demand_ai_workspace_context($scopeFilter);
        $directions = demand_ai_build_directions($scopeFilter, $context);
    }
    foreach ($directions as $direction) {
        if (is_array($direction) && (string) ($direction['directionId'] ?? '') === $directionId) {
            return $direction;
        }
    }

    return null;
}

function demand_build_direction_wordstat_packet($direction, string $scopeFilter = '', string $budgetMode = '', array $context = []): array
{
    $context = $context ?: demand_ai_workspace_context($scopeFilter);
    if (!is_array($direction)) {
        $direction = demand_find_direction_by_id((string) $direction, $scopeFilter, $context) ?? [];
    }
    $directionId = demand_clean_string($direction['directionId'] ?? '', 160);
    $directionTitle = demand_clean_string($direction['title'] ?? 'Направление спроса', 240);
    $budgetMode = $budgetMode !== '' ? $budgetMode : (string) ($direction['budgetMode'] ?? 'standard');
    $mode = demand_ai_budget_mode($budgetMode);
    $budgetMode = (string) ($mode['key'] ?? 'standard');
    $direction['budgetMode'] = $budgetMode;

    $seedPhrases = demand_direction_wordstat_seed_phrases($direction, $context);
    $regionDetails = demand_direction_wordstat_region_details($direction, $context);
    $methods = demand_direction_wordstat_methods($direction, $budgetMode);
    $cost = demand_direction_wordstat_cost_preview($seedPhrases, (array) ($regionDetails['regionIds'] ?? []), $methods);
    $fingerprint = demand_direction_wordstat_packet_fingerprint($seedPhrases, (array) ($regionDetails['regionIds'] ?? []), $methods);
    $packetId = 'dwp_' . substr(hash('sha256', implode('|', [$directionId, $budgetMode, $fingerprint])), 0, 18);
    $warnings = array_values(array_unique(array_merge(
        (array) ($regionDetails['warnings'] ?? []),
        (array) ($cost['warnings'] ?? [])
    )));
    if (!$seedPhrases) {
        $warnings[] = 'needs_seed_phrases';
    }
    if (!empty($mode['requiresExpensiveModeWarning'])) {
        $warnings[] = 'deep_expensive_mode_warning';
    }
    if (empty($mode['wordstatDryRunAllowed'])) {
        $warnings[] = 'budget_mode_requires_separate_wordstat_step';
    }

    $packet = [
        'packetId' => $packetId,
        'directionId' => $directionId,
        'directionTitle' => $directionTitle,
        'seedPhrases' => $seedPhrases,
        'regionIds' => (array) ($regionDetails['regionIds'] ?? []),
        'regionLabels' => (array) ($regionDetails['regionLabels'] ?? []),
        'methods' => $methods,
        'estimatedRequests' => (int) ($cost['estimatedRequests'] ?? 0),
        'estimatedCostRub' => (float) ($cost['estimatedCostRub'] ?? 0.0),
        'dryRunOnly' => true,
        'liveRequiresSpecialConfirmation' => true,
        'notChangedGuarantees' => demand_direction_wordstat_not_changed_guarantees(),
        'warnings' => array_values(array_unique($warnings)),
        'budgetMode' => $budgetMode,
        'needsSeedPhrases' => !$seedPhrases,
        'needsRegionConfirmation' => !empty($regionDetails['needsRegionConfirmation']),
        'packetFingerprint' => $fingerprint,
    ];

    $existing = demand_direction_wordstat_existing_dry_run($packet, $context);
    if ($existing) {
        $packet['existingDryRunId'] = (string) ($existing['id'] ?? '');
        $packet['duplicateMessage'] = 'Wordstat dry-run по этому направлению уже подготовлен. Данные не изменились.';
        $packet['warnings'][] = 'identical_dry_run_already_exists';
        $packet['warnings'] = array_values(array_unique($packet['warnings']));
    }

    return $packet;
}

function demand_direction_wordstat_append_dry_run_follow_up(array $direction, array $packet, array $run): array
{
    $estimatedRequests = (int) ($packet['estimatedRequests'] ?? $run['plannedRequests'] ?? $run['itemsRead'] ?? 0);
    $estimatedCostRub = (float) ($packet['estimatedCostRub'] ?? $run['estimatedCostRub'] ?? 0.0);
    $summary = 'Wordstat dry-run готов для направления "' . (string) ($packet['directionTitle'] ?? $direction['title'] ?? 'Направление спроса') . '". '
        . 'Проверены только план, методы, регионы и стоимость; live не запускался, Demand keywords, recommendations и demand map не менялись.';

    return demand_ai_append_run_history([
        'runId' => 'airh_wordstat_dry_' . (string) ($run['id'] ?? ('manual_' . date('Ymd_His'))),
        'directionId' => (string) ($packet['directionId'] ?? $direction['directionId'] ?? ''),
        'directionTitle' => (string) ($packet['directionTitle'] ?? $direction['title'] ?? ''),
        'startedAt' => (string) ($run['startedAt'] ?? now_iso()),
        'finishedAt' => (string) ($run['finishedAt'] ?? now_iso()),
        'startedBy' => ['source' => 'ai_direction_wordstat_packet'],
        'budgetMode' => (string) ($packet['budgetMode'] ?? $direction['budgetMode'] ?? 'standard'),
        'summaryForOwner' => $summary,
        'completedActionLabels' => [
            'Wordstat dry-run выполнен',
            'Live Wordstat не запускался',
            'Demand keywords/recommendations/map не менялись',
        ],
        'createdObjectLabels' => [
            'Sync-run: ' . (string) ($run['id'] ?? ''),
            'Decision: Wordstat dry-run готов',
        ],
        'changedFiles' => [
            'private/rent-rk-data/demand-sync-runs.json',
            'private/rent-rk-data/demand-ai-run-history.json',
        ],
        'stopReason' => 'completed',
        'estimatedCostLabel' => $estimatedRequests . ' Wordstat dry-run requests, ' . round($estimatedCostRub, 4) . ' RUB estimate',
        'wordstatCostEstimate' => [
            'requests' => $estimatedRequests,
            'estimatedRub' => $estimatedCostRub,
        ],
        'wordstatStatus' => 'wordstat_dry_run_ready',
        'wordstatRunId' => (string) ($run['id'] ?? ''),
        'wordstatPacketId' => (string) ($packet['packetId'] ?? ''),
        'seedPhrasesCount' => count((array) ($packet['seedPhrases'] ?? [])),
        'regionIds' => (array) ($packet['regionIds'] ?? []),
        'methods' => (array) ($packet['methods'] ?? []),
        'estimatedRequests' => $estimatedRequests,
        'estimatedCostRub' => $estimatedCostRub,
        'nextSafeAction' => 'Открыть результат, продолжить без live или запустить live только через special confirmation.',
        'notChangedLabel' => array_merge(demand_direction_wordstat_not_changed_guarantees(), demand_ai_protected_non_change_guarantees()),
        'processingFingerprint' => (string) ($packet['packetFingerprint'] ?? $direction['processingFingerprint'] ?? ''),
    ]);
}

function demand_direction_wordstat_append_live_follow_up(array $direction, array $result, array $metadata = []): array
{
    $run = is_array($result['run'] ?? null) ? $result['run'] : [];
    $plan = is_array($result['plan'] ?? null) ? $result['plan'] : [];
    $directionId = (string) ($metadata['directionId'] ?? $direction['directionId'] ?? '');
    if ($directionId === '') {
        return [];
    }
    $title = (string) ($metadata['directionTitle'] ?? $direction['title'] ?? 'Направление спроса');
    $summary = 'Данные Wordstat получены. Вот что теперь важно: live мог обновить Wordstat-derived Demand keyword metrics и recommendations; публикация, индексация, sitemap.xml и robots.txt не менялись.';

    return demand_ai_append_run_history([
        'runId' => 'airh_wordstat_live_' . (string) ($run['id'] ?? ('manual_' . date('Ymd_His'))),
        'directionId' => $directionId,
        'directionTitle' => $title,
        'startedAt' => (string) ($run['startedAt'] ?? now_iso()),
        'finishedAt' => (string) ($run['finishedAt'] ?? now_iso()),
        'startedBy' => ['source' => 'wordstat_live_special_confirmation'],
        'budgetMode' => (string) ($metadata['budgetMode'] ?? $direction['budgetMode'] ?? 'standard'),
        'summaryForOwner' => $summary,
        'completedActionLabels' => [
            'Данные Wordstat получены',
            'Продолжить подготовку материалов',
            'Открыть обновлённые рекомендации',
            'Открыть черновики',
        ],
        'createdObjectLabels' => [
            'Sync-run: ' . (string) ($run['id'] ?? ''),
            'Next action: Пересчитать карту спроса по новым данным',
        ],
        'changedFiles' => [
            'private/rent-rk-data/demand-sync-runs.json',
            'private/rent-rk-data/demand-keywords.json',
            'private/rent-rk-data/demand-external-metrics.json',
            'private/rent-rk-data/demand-recommendations.json',
            'private/rent-rk-data/demand-ai-run-history.json',
        ],
        'stopReason' => 'completed',
        'estimatedCostLabel' => (int) ($plan['plannedRequests'] ?? 0) . ' Wordstat live requests, ' . round((float) ($plan['estimatedCostRub'] ?? 0), 4) . ' RUB estimate',
        'wordstatCostEstimate' => [
            'requests' => (int) ($plan['plannedRequests'] ?? 0),
            'estimatedRub' => (float) ($plan['estimatedCostRub'] ?? 0.0),
        ],
        'wordstatStatus' => 'wordstat_live_ready',
        'wordstatRunId' => (string) ($run['id'] ?? ''),
        'wordstatPacketId' => (string) ($metadata['packetId'] ?? ''),
        'seedPhrasesCount' => count((array) ($plan['seedPhrases'] ?? [])),
        'regionIds' => (array) ($plan['regionIds'] ?? []),
        'methods' => (array) ($plan['methods'] ?? []),
        'estimatedRequests' => (int) ($plan['plannedRequests'] ?? 0),
        'estimatedCostRub' => (float) ($plan['estimatedCostRub'] ?? 0.0),
        'nextSafeAction' => 'Пересчитать карту спроса по новым данным или открыть обновлённые рекомендации.',
        'notChangedLabel' => demand_ai_protected_non_change_guarantees(),
        'processingFingerprint' => (string) ($metadata['packetFingerprint'] ?? $direction['processingFingerprint'] ?? ''),
    ]);
}

function demand_ai_direction_session_overrides(): array
{
    $raw = is_array($_SESSION['demand_direction_decisions'] ?? null) ? $_SESSION['demand_direction_decisions'] : [];
    $normalize = static function ($items): array {
        return array_values(array_unique(array_filter(array_map(
            static fn($item): string => demand_clean_string($item, 160),
            is_array($items) ? $items : []
        ))));
    };

    return [
        'queued' => $normalize($raw['queued'] ?? []),
        'postponed' => $normalize($raw['postponed'] ?? []),
        'ignored' => $normalize($raw['ignored'] ?? []),
    ];
}

function demand_ai_save_direction_session_overrides(array $overrides): void
{
    $normalized = [
        'queued' => array_values(array_unique(array_filter(array_map(static fn($item): string => demand_clean_string($item, 160), (array) ($overrides['queued'] ?? []))))),
        'postponed' => array_values(array_unique(array_filter(array_map(static fn($item): string => demand_clean_string($item, 160), (array) ($overrides['postponed'] ?? []))))),
        'ignored' => array_values(array_unique(array_filter(array_map(static fn($item): string => demand_clean_string($item, 160), (array) ($overrides['ignored'] ?? []))))),
    ];
    $_SESSION['demand_direction_decisions'] = $normalized;
}

function demand_ai_apply_direction_session_override(string $directionId, string $action): array
{
    $directionId = demand_clean_string($directionId, 160);
    $action = demand_clean_string($action, 40);
    if ($directionId === '') {
        throw new RuntimeException('Direction id is required.');
    }
    if (!in_array($action, ['add_to_queue', 'process_now', 'ignore', 'postpone'], true)) {
        throw new RuntimeException('Unknown direction decision action.');
    }

    $overrides = demand_ai_direction_session_overrides();
    foreach (['queued', 'postponed', 'ignored'] as $bucket) {
        $overrides[$bucket] = array_values(array_filter((array) ($overrides[$bucket] ?? []), static fn(string $id): bool => $id !== $directionId));
    }
    if ($action === 'add_to_queue' || $action === 'process_now') {
        $overrides['queued'][] = $directionId;
    } elseif ($action === 'ignore') {
        $overrides['ignored'][] = $directionId;
    } elseif ($action === 'postpone') {
        $overrides['postponed'][] = $directionId;
    }

    demand_ai_save_direction_session_overrides($overrides);

    return $overrides;
}

function demand_ai_build_directions(string $scopeFilter = '', array $context = []): array
{
    $context = $context ?: demand_ai_workspace_context($scopeFilter);
    $directions = [];
    $clusterToDirection = [];
    $planToDirection = [];
    $keywordToDirection = [];

    foreach ((array) ($context['clusters'] ?? []) as $cluster) {
        if (!is_array($cluster)) {
            continue;
        }
        $direction = demand_ai_direction_from_source($cluster, (string) ($cluster['scope_id'] ?? 'rent_rk'));
        $id = (string) ($direction['directionId'] ?? '');
        $directions[$id] = isset($directions[$id]) ? demand_ai_merge_direction($directions[$id], $direction) : $direction;
        $clusterId = (string) ($cluster['id'] ?? '');
        if ($clusterId !== '') {
            $clusterToDirection[$clusterId] = $id;
        }
        foreach ((array) ($cluster['keywordIds'] ?? []) as $keywordId) {
            $keywordToDirection[(string) $keywordId] = $id;
        }
    }

    foreach ((array) ($context['plans'] ?? []) as $plan) {
        if (!is_array($plan)) {
            continue;
        }
        $clusterId = (string) ($plan['clusterId'] ?? '');
        $directionId = $clusterToDirection[$clusterId] ?? '';
        $direction = demand_ai_direction_from_source(array_merge($plan, ['clusterId' => $clusterId]), (string) ($plan['scope_id'] ?? 'rent_rk'));
        $direction['linkedLaunchPlanIds'] = array_values(array_filter([(string) ($plan['id'] ?? '')]));
        if ($directionId !== '' && isset($directions[$directionId])) {
            $directions[$directionId] = demand_ai_merge_direction($directions[$directionId], $direction);
        } else {
            $directionId = (string) ($direction['directionId'] ?? '');
            $directions[$directionId] = isset($directions[$directionId]) ? demand_ai_merge_direction($directions[$directionId], $direction) : $direction;
        }
        if ((string) ($plan['id'] ?? '') !== '') {
            $planToDirection[(string) ($plan['id'] ?? '')] = $directionId;
        }
    }

    foreach ((array) ($context['keywords'] ?? []) as $keyword) {
        if (!is_array($keyword)) {
            continue;
        }
        $keywordId = (string) ($keyword['id'] ?? '');
        if ($keywordId !== '' && isset($keywordToDirection[$keywordId])) {
            continue;
        }
        if ((string) ($keyword['source'] ?? '') !== 'ai_suggested_seed' && empty($keyword['isExcluded'])) {
            continue;
        }
        $direction = demand_ai_direction_from_source($keyword, (string) ($keyword['scope_id'] ?? 'rent_rk'));
        $direction['linkedKeywordIds'] = array_values(array_filter([$keywordId]));
        $id = (string) ($direction['directionId'] ?? '');
        $directions[$id] = isset($directions[$id]) ? demand_ai_merge_direction($directions[$id], $direction) : $direction;
        if ($keywordId !== '') {
            $keywordToDirection[$keywordId] = $id;
        }
    }

    foreach ((array) ($context['briefs'] ?? []) as $brief) {
        if (!is_array($brief)) {
            continue;
        }
        $directionId = $clusterToDirection[(string) ($brief['clusterId'] ?? '')] ?? $planToDirection[(string) ($brief['launchPlanId'] ?? '')] ?? '';
        if ($directionId === '') {
            $direction = demand_ai_direction_from_source($brief, (string) ($brief['scope_id'] ?? 'rent_rk'));
            $directionId = (string) ($direction['directionId'] ?? '');
            $directions[$directionId] = isset($directions[$directionId]) ? demand_ai_merge_direction($directions[$directionId], $direction) : $direction;
        }
        $directions[$directionId]['linkedContentBriefIds'][] = (string) ($brief['id'] ?? '');
        $directions[$directionId]['linkedContentBriefIds'] = array_values(array_unique(array_filter($directions[$directionId]['linkedContentBriefIds'])));
    }

    foreach ((array) ($context['hints'] ?? []) as $hint) {
        if (!is_array($hint)) {
            continue;
        }
        $directionId = $clusterToDirection[(string) ($hint['clusterId'] ?? '')] ?? $planToDirection[(string) ($hint['launchPlanId'] ?? '')] ?? '';
        if ($directionId === '') {
            foreach ((array) ($hint['keywordIds'] ?? []) as $keywordId) {
                if (isset($keywordToDirection[(string) $keywordId])) {
                    $directionId = $keywordToDirection[(string) $keywordId];
                    break;
                }
            }
        }
        if ($directionId !== '' && isset($directions[$directionId])) {
            $directions[$directionId]['linkedCarHintIds'][] = (string) ($hint['id'] ?? '');
            $directions[$directionId]['linkedCarHintIds'] = array_values(array_unique(array_filter($directions[$directionId]['linkedCarHintIds'])));
        }
    }

    foreach ((array) ($context['drafts'] ?? []) as $draft) {
        if (!is_array($draft)) {
            continue;
        }
        $directionId = $clusterToDirection[(string) ($draft['linkedClusterId'] ?? '')] ?? $planToDirection[(string) ($draft['linkedLaunchPlanId'] ?? '')] ?? '';
        if ($directionId === '') {
            foreach ((array) ($draft['sourceKeywordIds'] ?? []) as $keywordId) {
                if (isset($keywordToDirection[(string) $keywordId])) {
                    $directionId = $keywordToDirection[(string) $keywordId];
                    break;
                }
            }
        }
        if ($directionId === '') {
            $direction = demand_ai_direction_from_source($draft, (string) ($draft['scope_id'] ?? 'rent_rk'));
            $directionId = (string) ($direction['directionId'] ?? '');
            $directions[$directionId] = isset($directions[$directionId]) ? demand_ai_merge_direction($directions[$directionId], $direction) : $direction;
        }
        $directions[$directionId]['linkedDraftIds'][] = (string) ($draft['id'] ?? '');
        $directions[$directionId]['linkedKeywordIds'] = array_values(array_unique(array_filter(array_merge(
            (array) ($directions[$directionId]['linkedKeywordIds'] ?? []),
            (array) ($draft['sourceKeywordIds'] ?? [])
        ))));
        $directions[$directionId]['linkedDraftIds'] = array_values(array_unique(array_filter($directions[$directionId]['linkedDraftIds'])));
    }

    foreach ($directions as $directionId => $direction) {
        foreach ((array) ($context['syncRuns'] ?? []) as $run) {
            if (!is_array($run)) {
                continue;
            }
            $runDirectionId = function_exists('demand_direction_wordstat_run_direction_id')
                ? demand_direction_wordstat_run_direction_id($run)
                : (string) ($run['directionId'] ?? '');
            if (($runDirectionId !== '' && $runDirectionId === (string) $directionId) || demand_ai_direction_run_matches($direction, $run)) {
                $runId = (string) ($run['id'] ?? '');
                if ($runId !== '') {
                    $directions[$directionId]['linkedWordstatRunIds'][] = $runId;
                }
                $finished = (string) ($run['finishedAt'] ?? $run['startedAt'] ?? '');
                if (!empty($run['dryRun'])) {
                    if ($finished > (string) ($directions[$directionId]['lastWordstatDryRunAt'] ?? '')) {
                        $directions[$directionId]['lastWordstatDryRunAt'] = $finished;
                    }
                } elseif ((string) ($run['source'] ?? '') === 'wordstat') {
                    if ($finished > (string) ($directions[$directionId]['lastWordstatLiveAt'] ?? '')) {
                        $directions[$directionId]['lastWordstatLiveAt'] = $finished;
                    }
                }
            }
        }
        foreach ((array) ($context['aiRuns'] ?? []) as $run) {
            if (!is_array($run)) {
                continue;
            }
            $runId = (string) ($run['id'] ?? '');
            if ($runId === '') {
                continue;
            }
            if (in_array((string) ($run['entityId'] ?? ''), (array) ($direction['linkedDraftIds'] ?? []), true)
                || demand_ai_direction_run_matches($direction, $run)
            ) {
                $directions[$directionId]['linkedAiRunIds'][] = $runId;
            }
        }
        foreach ((array) ($context['runHistory'] ?? []) as $history) {
            if (is_array($history) && (string) ($history['directionId'] ?? '') === $directionId) {
                $runId = (string) ($history['runId'] ?? '');
                if ($runId !== '') {
                    $directions[$directionId]['linkedAiRunIds'][] = $runId;
                }
                $finished = (string) ($history['finishedAt'] ?? '');
                if ($finished > (string) ($directions[$directionId]['lastProcessedAt'] ?? '')) {
                    $directions[$directionId]['lastProcessedAt'] = $finished;
                    $directions[$directionId]['latestRun'] = $history;
                }
            }
        }
        $directions[$directionId]['linkedAiRunIds'] = array_values(array_unique(array_filter((array) ($directions[$directionId]['linkedAiRunIds'] ?? []))));
        $directions[$directionId]['linkedWordstatRunIds'] = array_values(array_unique(array_filter((array) ($directions[$directionId]['linkedWordstatRunIds'] ?? []))));
        $directions[$directionId]['nextRefreshRecommendedAt'] = demand_ai_direction_refresh_at($directions[$directionId]);
        $directions[$directionId]['processingFingerprint'] = demand_ai_direction_processing_fingerprint($directions[$directionId], $context);
        $latest = demand_ai_latest_run_for_direction($directionId);
        if ($latest) {
            $directions[$directionId]['latestRun'] = $latest;
            $directions[$directionId]['lastProcessedAt'] = (string) ($latest['finishedAt'] ?? $directions[$directionId]['lastProcessedAt'] ?? '');
            if ((string) ($latest['processingFingerprint'] ?? '') === (string) ($directions[$directionId]['processingFingerprint'] ?? '')
                && in_array((string) ($latest['stopReason'] ?? ''), ['completed', 'needs_confirmation', 'needs_human_decision'], true)
            ) {
                $directions[$directionId]['fingerprintReuseAvailable'] = true;
                $directions[$directionId]['reuseMessage'] = 'Это направление уже обработано, данные не изменились. Можно открыть готовые материалы без повторного расхода лимитов.';
            }
        }
        $lastDryRunAt = (string) ($directions[$directionId]['lastWordstatDryRunAt'] ?? '');
        $lastLiveAt = (string) ($directions[$directionId]['lastWordstatLiveAt'] ?? '');
        if ($lastLiveAt !== '') {
            $directions[$directionId]['wordstatStatus'] = 'live_result_ready';
            $directions[$directionId]['wordstatNextAction'] = [
                'label' => 'Открыть обновлённые рекомендации',
                'actionKey' => 'open_wordstat_recommendations',
                'confirmationLevel' => 'none',
                'directionId' => (string) $directionId,
            ];
        } elseif ($lastDryRunAt !== '') {
            $directions[$directionId]['wordstatStatus'] = 'dry_run_ready';
            $directions[$directionId]['wordstatNextAction'] = [
                'label' => 'Открыть dry-run',
                'actionKey' => 'open_wordstat_dry_run_result',
                'confirmationLevel' => 'none',
                'directionId' => (string) $directionId,
            ];
        } else {
            $directions[$directionId]['wordstatStatus'] = 'not_checked';
            $directions[$directionId]['wordstatNextAction'] = [
                'label' => 'Подготовить Wordstat-проверку',
                'actionKey' => 'prepare_direction_wordstat_packet',
                'confirmationLevel' => 'dry_run_modal',
                'directionId' => (string) $directionId,
            ];
        }
        $directions[$directionId]['status'] = demand_ai_direction_status($directions[$directionId], $context);
        $directions[$directionId]['nextAction'] = demand_ai_direction_next_action($directions[$directionId]);
    }

    $overrides = demand_ai_direction_session_overrides();
    foreach ($directions as $directionId => $direction) {
        if (in_array((string) $directionId, (array) ($overrides['ignored'] ?? []), true)) {
            unset($directions[$directionId]);
            continue;
        }
        if (in_array((string) $directionId, (array) ($overrides['postponed'] ?? []), true)) {
            $directions[$directionId]['status'] = 'postponed';
            $directions[$directionId]['sessionDecision'] = 'postponed';
            $directions[$directionId]['nextAction'] = demand_ai_direction_next_action($directions[$directionId]);
        } elseif (in_array((string) $directionId, (array) ($overrides['queued'] ?? []), true)) {
            $directions[$directionId]['sessionDecision'] = 'queued';
        }
    }

    $result = array_values($directions);
    usort($result, static function (array $a, array $b): int {
        $statusRank = [
            'in_progress' => 8,
            'needs_decision' => 7,
            'stale' => 6,
            'prepared' => 5,
            'ready_for_manual_publish_review' => 4,
            'not_started' => 3,
            'postponed' => 2,
            'not_relevant' => 1,
        ];
        $cmp = (($statusRank[(string) ($b['status'] ?? '')] ?? 0) <=> ($statusRank[(string) ($a['status'] ?? '')] ?? 0));
        if ($cmp !== 0) {
            return $cmp;
        }
        $cmp = demand_ai_priority_rank((string) ($b['priority'] ?? 'low')) <=> demand_ai_priority_rank((string) ($a['priority'] ?? 'low'));
        if ($cmp !== 0) {
            return $cmp;
        }

        return strcmp((string) ($a['title'] ?? ''), (string) ($b['title'] ?? ''));
    });

    return $result;
}

function demand_build_decision_queue(string $scopeFilter = '', array $context = []): array
{
    $context = $context ?: demand_ai_workspace_context($scopeFilter);
    $directions = (array) ($context['directions'] ?? demand_ai_build_directions($scopeFilter, $context));
    $decisions = [];
    $protected = demand_ai_protected_non_change_guarantees();
    foreach ($directions as $direction) {
        if (!is_array($direction)) {
            continue;
        }
        $directionId = (string) ($direction['directionId'] ?? '');
        $status = (string) ($direction['status'] ?? '');
        $base = [
            'directionId' => $directionId,
            'relatedObjectIds' => [
                'keywords' => (array) ($direction['linkedKeywordIds'] ?? []),
                'drafts' => (array) ($direction['linkedDraftIds'] ?? []),
                'briefs' => (array) ($direction['linkedContentBriefIds'] ?? []),
            ],
            'forbiddenActions' => [
                'publish_page',
                'publish_noindex',
                'open_indexing',
                'add_to_sitemap',
                'edit_sitemap',
                'edit_robots',
                'edit_prices',
                'edit_deposits',
                'edit_car_records',
                'edit_requests',
                'edit_rentals',
                'edit_clients',
                'edit_finance',
                'edit_users',
                'edit_roles',
                'call_arbitrary_endpoint',
            ],
            'protectedNonChangeGuarantees' => $protected,
        ];
        if ((string) ($direction['wordstatStatus'] ?? '') === 'dry_run_ready'
            || ((string) ($direction['lastWordstatDryRunAt'] ?? '') !== '' && (string) ($direction['lastWordstatLiveAt'] ?? '') === '')
        ) {
            $decisions[] = array_merge($base, [
                'id' => 'dec_' . substr(hash('sha1', $directionId . '|wordstat_dry_run_ready|' . (string) ($direction['lastWordstatDryRunAt'] ?? '')), 0, 14),
                'type' => 'wordstat_dry_run_ready',
                'source' => 'direction',
                'title' => 'Wordstat dry-run готов',
                'body' => 'Dry-run по выбранному направлению готов. Можно открыть результат, продолжить без live или запускать live только через отдельное special confirmation.',
                'blockingLevel' => 'recommended',
                'confirmationLevel' => 'none',
                'allowedAction' => 'open_wordstat_dry_run_result',
                'safeToApply' => false,
                'actions' => [
                    ['key' => 'open_result', 'label' => 'Открыть результат'],
                    ['key' => 'run_live_special_confirmation', 'label' => 'Запустить live через special confirmation', 'requiresSpecialConfirmation' => true],
                    ['key' => 'continue_without_live', 'label' => 'Продолжить без live'],
                    ['key' => 'edit_phrases', 'label' => 'Изменить фразы'],
                ],
            ]);
        }
        if ($status === 'needs_decision') {
            $decisions[] = array_merge($base, [
                'id' => 'dec_' . substr(hash('sha1', $directionId . '|risk'), 0, 14),
                'type' => 'direction_business_risk_review',
                'source' => 'direction',
                'title' => 'Нужно решение: ' . (string) ($direction['title'] ?? 'направление'),
                'body' => 'Есть риск или неполные условия. AI может подготовить материалы, но бизнес-обещания должен подтвердить человек.',
                'blockingLevel' => 'required',
                'confirmationLevel' => 'human_decision',
                'allowedAction' => 'open_direction_risk_review',
                'safeToApply' => false,
            ]);
        } elseif ($status === 'stale') {
            $decisions[] = array_merge($base, [
                'id' => 'dec_' . substr(hash('sha1', $directionId . '|refresh'), 0, 14),
                'type' => 'direction_refresh_due',
                'source' => 'direction',
                'title' => 'Обновить спрос: ' . (string) ($direction['title'] ?? 'направление'),
                'body' => 'Данные направления устарели. Можно начать с dry-run без изменения фраз, страниц, sitemap и robots.',
                'blockingLevel' => 'recommended',
                'confirmationLevel' => 'grouped',
                'allowedAction' => 'wordstat_dry_run',
                'safeToApply' => false,
            ]);
        } elseif ($status === 'not_started') {
            $decisions[] = array_merge($base, [
                'id' => 'dec_' . substr(hash('sha1', $directionId . '|start'), 0, 14),
                'type' => 'direction_start_confirm',
                'source' => 'direction',
                'title' => 'Запустить AI-сессию: ' . (string) ($direction['title'] ?? 'направление'),
                'body' => 'AI обработает одно направление в выбранном бюджете и остановится перед подтверждениями.',
                'blockingLevel' => 'optional',
                'confirmationLevel' => 'start_session',
                'allowedAction' => 'start_direction_session',
                'safeToApply' => true,
            ]);
        }
    }
    if (count($directions) > 1) {
        $current = is_array($directions[0] ?? null) ? $directions[0] : [];
        $neighbors = array_values(array_filter(array_slice($directions, 1, 6), 'is_array'));
        $neighborIds = array_values(array_filter(array_map(static fn(array $item): string => (string) ($item['directionId'] ?? ''), $neighbors)));
        if ($current && $neighborIds) {
            $directionId = (string) ($current['directionId'] ?? '');
            $decisions[] = [
                'id' => 'dec_' . substr(hash('sha1', $directionId . '|neighbors|' . implode('|', $neighborIds)), 0, 14),
                'type' => 'direction_neighbor_found',
                'source' => 'direction',
                'directionId' => $directionId,
                'relatedObjectIds' => [
                    'neighborDirections' => array_slice($neighborIds, 0, 3),
                ],
                'title' => 'Найдены соседние направления',
                'body' => 'AI видит темы рядом с текущим направлением. Они не обрабатываются автоматически, чтобы не тратить лимиты без вашего решения.',
                'blockingLevel' => 'optional',
                'confirmationLevel' => 'start_session',
                'allowedAction' => 'review_neighboring_directions',
                'actions' => [
                    ['key' => 'add_to_queue', 'label' => 'Добавить в очередь', 'writesSessionOnly' => true],
                    ['key' => 'process_now', 'label' => 'Обработать сейчас', 'opensStartSessionModal' => true],
                    ['key' => 'ignore', 'label' => 'Игнорировать', 'writesSessionOnly' => true],
                    ['key' => 'postpone', 'label' => 'Отложить', 'writesSessionOnly' => true],
                ],
                'forbiddenActions' => [
                    'publish_page',
                    'publish_noindex',
                    'open_indexing',
                    'add_to_sitemap',
                    'edit_sitemap',
                    'edit_robots',
                    'edit_prices',
                    'edit_deposits',
                    'edit_car_records',
                    'edit_requests',
                    'edit_rentals',
                    'edit_clients',
                    'edit_finance',
                    'edit_users',
                    'edit_roles',
                    'call_arbitrary_endpoint',
                ],
                'protectedNonChangeGuarantees' => $protected,
                'safeToApply' => false,
            ];
        }
    }
    if (function_exists('demand_ai_dialog_state')) {
        $state = demand_ai_dialog_state();
        $workflow = is_array($state['workflow'] ?? null) ? $state['workflow'] : [];
        foreach (['requiresConfirmation' => 'grouped', 'specialConfirmation' => 'special'] as $bucket => $level) {
            foreach ((array) ($workflow[$bucket] ?? []) as $action) {
                if (!is_array($action) || !in_array((string) ($action['status'] ?? 'pending'), ['pending', 'waiting'], true)) {
                    continue;
                }
                $actionId = (string) ($action['action'] ?? $action['id'] ?? '');
                $type = match ($actionId) {
                    'wordstat_dry_run' => 'direction_wordstat_dry_run_confirm',
                    'wordstat_controlled_live_sync' => 'direction_wordstat_live_special_confirm',
                    'create_safe_landing_drafts_batch' => 'direction_draft_batch_confirm',
                    'apply_internal_link_suggestions' => 'direction_internal_links_apply',
                    default => 'direction_budget_warning',
                };
                $decisions[] = [
                    'id' => 'dec_' . substr(hash('sha1', (string) ($workflow['id'] ?? '') . '|' . $actionId), 0, 14),
                    'type' => $type,
                    'source' => 'ai_dialog',
                    'directionId' => (string) ($workflow['directionSession']['directionId'] ?? ''),
                    'relatedObjectIds' => [],
                    'title' => demand_clean_string($action['label'] ?? $actionId, 240),
                    'body' => demand_clean_string($action['explanation'] ?? $action['safeNote'] ?? '', 700),
                    'blockingLevel' => $level === 'special' ? 'required' : 'recommended',
                    'confirmationLevel' => $level,
                    'allowedAction' => $actionId,
                    'forbiddenActions' => $base['forbiddenActions'] ?? [],
                    'protectedNonChangeGuarantees' => $protected,
                    'safeToApply' => $level !== 'special',
                ];
            }
        }
    }

    $rank = ['required' => 3, 'recommended' => 2, 'optional' => 1];
    usort($decisions, static fn(array $a, array $b): int => ($rank[(string) ($b['blockingLevel'] ?? 'optional')] ?? 0) <=> ($rank[(string) ($a['blockingLevel'] ?? 'optional')] ?? 0));

    return array_values($decisions);
}

function demand_build_materials_summary(string $scopeFilter = '', array $context = []): array
{
    $context = $context ?: demand_ai_workspace_context($scopeFilter);
    $drafts = (array) ($context['drafts'] ?? []);
    $keywords = (array) ($context['keywords'] ?? []);
    $briefs = (array) ($context['briefs'] ?? []);
    $hints = (array) ($context['hints'] ?? []);
    $plans = (array) ($context['plans'] ?? []);

    return [
        'drafts' => [
            'total' => count($drafts),
            'needEdits' => count(array_filter($drafts, static fn(array $draft): bool => in_array((string) ($draft['readinessStatus'] ?? ''), ['not_checked', 'needs_fixes', 'blocked'], true))),
            'readyForPreview' => count(array_filter($drafts, static fn(array $draft): bool => in_array((string) ($draft['readinessStatus'] ?? ''), ['ready'], true))),
            'publishedForPreview' => count(array_filter($drafts, static fn(array $draft): bool => (string) ($draft['publishStatus'] ?? '') === 'published_noindex')),
            'readyForSearch' => count(array_filter($drafts, static fn(array $draft): bool => (string) ($draft['publishStatus'] ?? '') === 'ready_for_index_review')),
        ],
        'briefs' => ['total' => count($briefs)],
        'faq' => ['total' => count(array_filter($briefs, static fn(array $brief): bool => !empty($brief['faqQuestions']) || !empty($brief['recommendedFaq'])))],
        'carHints' => ['total' => count($hints)],
        'pagePlan' => ['total' => count($plans)],
        'aiSeedPhrases' => ['total' => count(array_filter($keywords, static fn(array $keyword): bool => (string) ($keyword['source'] ?? '') === 'ai_suggested_seed'))],
        'postponedOrNoGo' => ['total' => count(array_filter($keywords, static fn(array $keyword): bool => (string) ($keyword['status'] ?? '') === 'excluded' || !empty($keyword['negativeIntent'])))],
    ];
}

function demand_build_primary_next_action(string $scopeFilter = '', array $context = []): array
{
    $context = $context ?: demand_ai_workspace_context($scopeFilter);
    $directions = (array) ($context['directions'] ?? demand_ai_build_directions($scopeFilter, $context));
    $decisionQueue = (array) ($context['decisionQueue'] ?? demand_build_decision_queue($scopeFilter, array_merge($context, ['directions' => $directions])));
    if ($decisionQueue) {
        $decision = $decisionQueue[0];
        return [
            'id' => (string) ($decision['id'] ?? ''),
            'title' => (string) ($decision['title'] ?? 'Нужно решение'),
            'text' => (string) ($decision['body'] ?? ''),
            'button' => (string) ($decision['type'] ?? '') === 'wordstat_dry_run_ready'
                ? 'Открыть dry-run'
                : ((string) ($decision['confirmationLevel'] ?? '') === 'start_session' ? 'Запустить сессию' : 'Открыть решение'),
            'actionKey' => (string) ($decision['type'] ?? ''),
            'directionId' => (string) ($decision['directionId'] ?? ''),
            'tone' => (string) ($decision['blockingLevel'] ?? '') === 'required' ? 'warning' : 'safe',
            'confirmationLevel' => (string) ($decision['confirmationLevel'] ?? 'none'),
        ];
    }
    $direction = $directions[0] ?? null;
    if (is_array($direction)) {
        $next = (array) ($direction['nextAction'] ?? demand_ai_direction_next_action($direction));
        return [
            'id' => 'next_' . (string) ($direction['directionId'] ?? ''),
            'title' => (string) ($direction['title'] ?? 'Направление спроса'),
            'text' => !empty($direction['reuseMessage'])
                ? (string) $direction['reuseMessage']
                : 'Следующий безопасный шаг по направлению: ' . (string) ($next['label'] ?? 'посмотреть материалы') . '.',
            'button' => (string) ($next['label'] ?? 'Открыть'),
            'actionKey' => (string) ($next['actionKey'] ?? ''),
            'directionId' => (string) ($direction['directionId'] ?? ''),
            'tone' => 'safe',
            'confirmationLevel' => (string) ($next['confirmationLevel'] ?? 'none'),
        ];
    }

    return [
        'id' => 'demand_start',
        'title' => 'Начните с направления спроса',
        'text' => 'Добавьте фразы или попросите AI предложить первое направление. AI не публикует страницы и не открывает индексацию.',
        'button' => 'Собрать спрос',
        'actionKey' => 'direction_start_confirm',
        'directionId' => '',
        'tone' => 'safe',
        'confirmationLevel' => 'start_session',
    ];
}

function demand_ai_direction_queue_projection(array $directions): array
{
    $queue = [
        'backlog' => [],
        'next' => [],
        'in_progress' => [],
        'prepared' => [],
        'needs_decision' => [],
        'stale' => [],
        'postponed' => [],
        'ignored' => [],
    ];
    $counts = [
        'prepared' => 0,
        'needsDecision' => 0,
        'stale' => 0,
        'notStarted' => 0,
        'postponed' => 0,
        'notRelevant' => 0,
    ];
    foreach ($directions as $direction) {
        if (!is_array($direction)) {
            continue;
        }
        $status = (string) ($direction['status'] ?? 'not_started');
        if ($status === 'needs_decision') {
            $queue['needs_decision'][] = $direction;
            $counts['needsDecision']++;
        } elseif ($status === 'stale') {
            $queue['stale'][] = $direction;
            $counts['stale']++;
        } elseif ($status === 'prepared' || $status === 'ready_for_manual_publish_review') {
            $queue['prepared'][] = $direction;
            $counts['prepared']++;
        } elseif ($status === 'postponed') {
            $queue['postponed'][] = $direction;
            $counts['postponed']++;
        } elseif ($status === 'not_relevant') {
            $queue['ignored'][] = $direction;
            $counts['notRelevant']++;
        } elseif ($status === 'in_progress') {
            $queue['in_progress'][] = $direction;
        } else {
            $queue['backlog'][] = $direction;
            $counts['notStarted']++;
        }
    }
    $queue['next'] = array_slice(array_merge($queue['needs_decision'], $queue['stale'], $queue['prepared'], $queue['backlog']), 0, 5);

    return [
        'current' => $queue['in_progress'][0] ?? $queue['needs_decision'][0] ?? $queue['prepared'][0] ?? $queue['backlog'][0] ?? [],
        'next' => $queue['next'][0] ?? [],
        'counts' => $counts,
        'queue' => $queue,
    ];
}

function demand_build_workspace_state(string $scopeFilter = ''): array
{
    $context = demand_ai_workspace_context($scopeFilter);
    $directions = demand_ai_build_directions($scopeFilter, $context);
    $context['directions'] = $directions;
    $decisionQueue = demand_build_decision_queue($scopeFilter, $context);
    $context['decisionQueue'] = $decisionQueue;
    $materialsSummary = demand_build_materials_summary($scopeFilter, $context);
    $primaryNextAction = demand_build_primary_next_action($scopeFilter, $context);
    $stats = demand_overview_stats($scopeFilter);
    $wordstatSettings = (array) ($context['wordstatSettings'] ?? []);
    $aiSettings = (array) ($context['aiSettings'] ?? []);
    $runHistory = demand_ai_read_run_history()['items'];
    $today = substr(now_iso(), 0, 10);
    $todayRuns = array_values(array_filter($runHistory, static fn($run): bool => is_array($run) && str_starts_with((string) ($run['startedAt'] ?? ''), $today)));

    return [
        'scopeId' => implode(',', (array) ($context['scopeIds'] ?? [])),
        'generatedAt' => now_iso(),
        'primaryNextAction' => $primaryNextAction,
        'decisionQueue' => $decisionQueue,
        'materialsSummary' => $materialsSummary,
        'draftSummary' => $materialsSummary['drafts'] ?? [],
        'demandMapSummary' => [
            'clusters' => count((array) ($context['clusters'] ?? [])),
            'plans' => count((array) ($context['plans'] ?? [])),
            'highPriority' => count(array_filter((array) ($context['clusters'] ?? []), static fn(array $cluster): bool => in_array((string) ($cluster['priority'] ?? $cluster['priorityLevel'] ?? ''), ['high', 'ready'], true) || (int) ($cluster['priorityScore'] ?? 0) >= 60)),
            'needsDecision' => count(array_filter((array) ($context['clusters'] ?? []), static fn(array $cluster): bool => in_array((string) ($cluster['recommendedDecision'] ?? $cluster['priority'] ?? ''), ['needs_business_decision', 'manual_review'], true))),
        ],
        'aiDialogStatus' => function_exists('demand_ai_dialog_state') ? [
            'available' => function_exists('demand_ai_dialog_can_access') ? demand_ai_dialog_can_access() : false,
            'hasWorkflow' => !empty(demand_ai_dialog_state()['workflow']),
            'hasPendingConfirmation' => !empty(demand_ai_dialog_state()['workflow']) && function_exists('demand_ai_dialog_workflow_has_pending_confirmation')
                ? demand_ai_dialog_workflow_has_pending_confirmation((array) demand_ai_dialog_state()['workflow'])
                : false,
        ] : ['available' => false, 'hasWorkflow' => false, 'hasPendingConfirmation' => false],
        'wordstatStatus' => [
            'enabled' => !empty($wordstatSettings['enabled']),
            'mode' => (string) ($wordstatSettings['mode'] ?? ''),
            'authStatus' => (string) ($wordstatSettings['authStatus'] ?? ''),
            'liveEnabled' => !empty($wordstatSettings['liveEnabled']),
            'dryRunRuns' => count(array_filter((array) ($context['syncRuns'] ?? []), static fn(array $run): bool => !empty($run['dryRun']))),
            'liveRuns' => count(array_filter((array) ($context['syncRuns'] ?? []), static fn(array $run): bool => (string) ($run['source'] ?? '') === 'wordstat' && empty($run['dryRun']))),
        ],
        'technicalHealth' => [
            'aiProviderEnabled' => !empty($aiSettings['enabled']),
            'aiProvider' => (string) ($aiSettings['provider'] ?? ''),
            'wordstatConfigured' => !empty($wordstatSettings['apiKeyConfigured']) && !empty($wordstatSettings['folderIdConfigured']) && !empty($wordstatSettings['baseUrlConfigured']),
            'recentAiErrors' => count(array_filter((array) ($context['aiRuns'] ?? []), static fn(array $run): bool => (string) ($run['status'] ?? '') === 'error')),
        ],
        'directions' => demand_ai_direction_queue_projection($directions),
        'budgetStatus' => [
            'defaultMode' => 'economy',
            'modes' => demand_ai_budget_modes(),
            'todayAiDirectionSessions' => count($todayRuns),
            'dailyAiCallLimit' => 25,
        ],
        'recentAiSessions' => array_slice(array_values(array_filter($runHistory, 'is_array')), 0, 8),
        'stats' => $stats,
    ];
}
