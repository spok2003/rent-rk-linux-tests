<?php
declare(strict_types=1);

/** A laboratory cutover latch; losing the opt-in does not unlock the old writer. */
final class PhpPublicationCutover
{
    private static function path(): string { return DATA_DIR . 'php-publication-mode.json'; }

    public static function selected(): bool
    {
        $path = self::path();
        clearstatcache(true, $path);
        return defined('RENT_RK_PHP_PUBLICATION_CUTOVER') || is_link($path) || file_exists($path);
    }

    private static function assertConfigured(): void
    {
        if (!defined('RENT_RK_PHP_PUBLICATION_CUTOVER') || RENT_RK_PHP_PUBLICATION_CUTOVER !== true
            || !PhpPublicationAutomation::enabled()) throw new RuntimeException('BLOCKED_PHP_CUTOVER_CONFIGURATION', 409);
        if (!function_exists('sodium_crypto_sign_detached') || !function_exists('sodium_crypto_sign_verify_detached')
            || !class_exists(DOMDocument::class)) throw new RuntimeException('BLOCKED_PHP_CUTOVER_CAPABILITY', 503);
    }

    private static function state(): array
    {
        if (is_link(self::path()) || (file_exists(self::path()) && !is_file(self::path()))) {
            throw new RuntimeException('BLOCKED_PHP_CUTOVER_STATE', 409);
        }
        $state = RentalReturnStore::read(self::path(), ['generation' => 0, 'state' => 'paused']);
        if (!is_int($state['generation'] ?? null) || $state['generation'] < 0
            || !in_array($state['state'] ?? '', ['running', 'paused'], true)) throw new RuntimeException('BLOCKED_PHP_CUTOVER_STATE', 409);
        return $state;
    }

    public static function change(string $next, int $expected): array
    {
        self::assertConfigured();
        if (PHP_SAPI !== 'cli' || !in_array($next, ['running', 'paused'], true)) throw new RuntimeException('BLOCKED_PHP_CUTOVER_CONTROL', 403);
        return RentalReturnStore::transaction(static function () use ($next, $expected): array {
            $state = self::state();
            if ($state['generation'] !== $expected) throw new RuntimeException('BLOCKED_PHP_CUTOVER_GENERATION', 409);
            if ($state['generation'] > 0 && $state['state'] === $next) return $state;
            $state = ['generation' => $expected + 1, 'state' => $next];
            if (!RentalReturnStore::stage(self::path(), $state)) throw new LogicException('Cutover transaction required');
            return $state;
        });
    }

    public static function generation(bool $requireRunning = true): int
    {
        self::assertConfigured();
        $state = self::state();
        if ($requireRunning && $state['state'] !== 'running') throw new RuntimeException('BLOCKED_PHP_CUTOVER_PAUSED', 409);
        return $state['generation'];
    }

    public static function inspect(): array
    {
        self::assertConfigured();
        if (PHP_SAPI !== 'cli') throw new RuntimeException('BLOCKED_PHP_CUTOVER_CONTROL', 403);
        RentalReturnStore::enter(true);
        return self::state();
    }

    public static function assertApply(?int $generation = null): void
    {
        if (!self::selected() && $generation === null) return;
        $active = self::generation();
        if ($generation !== null && $generation !== $active) throw new RuntimeException('BLOCKED_PHP_CUTOVER_GENERATION', 409);
    }

    public static function assertNoPendingActions(): void
    {
        if (!self::selected()) return;
        foreach (PhpPublicationAutomation::store()['jobs'] as $job) {
            if (in_array($job['status'] ?? '', ['pending', 'retry', 'blocked'], true)) {
                throw new RuntimeException('BLOCKED_PHP_CUTOVER_PENDING_ACTIONS', 409);
            }
        }
    }

    public static function legacyResult(): array
    {
        return ['success' => false, 'skipped' => true, 'unavailable' => true, 'reason' => 'php_confirmation_required', 'output' => [],
            'error' => 'Старый генератор заблокирован. Для записи подтвердите точный PHP-план в разделе публичных версий.'];
    }

    public static function status(): array
    {
        try {
            self::assertConfigured();
            $state = self::state();
            return ['available' => true, 'reason' => 'php_preview', 'execution' => $state['state'],
                'message' => 'Предварительная проверка PHP без публикации.'];
        } catch (Throwable $e) {
            return ['available' => false, 'reason' => 'php_configuration', 'message' => $e->getMessage()];
        }
    }

    public static function preview(string $slug, ?callable $access): array
    {
        $failure = ['success' => false, 'unavailable' => false, 'output' => [], 'parsed' => ['items' => []]];
        try {
            if (RentalReturnStore::active()) throw new RuntimeException('BLOCKED_PHP_PREVIEW_TRANSACTION_ACTIVE', 409);
            RentalReturnStore::enter(true);
            if ($access !== null && !$access()) return $failure + ['reason' => 'access_changed'];
            self::generation(false);
            require_once __DIR__ . '/approved-public-car-snapshot.php';
            $preview = ApprovedPublicCarSnapshots::fromServer()->carDryRun($slug);
            if ($access !== null && !$access()) return $failure + ['reason' => 'access_changed'];
            return ['success' => true, 'unavailable' => false, 'reason' => 'php_preview', 'status' => 'PLAN_ONLY',
                'canApply' => false, 'presentationLimits' => $preview['presentationLimits'],
                'parsed' => ['items' => $preview['items'], 'conflicts' => [], 'unknownOwnership' => [], 'publicData' => []]];
        } catch (Throwable $e) {
            if ($e instanceof RuntimeException && $e->getMessage() === 'BLOCKED_PHP_CAR_PREVIEW_ACCESS') {
                return $failure + ['reason' => 'access_changed'];
            }
            return $failure + ['reason' => 'php_preview_blocked', 'error' => $e->getMessage()];
        }
    }
}
