<?php
declare(strict_types=1);

require_once __DIR__ . '/php-public-renderer-templates.php';
require_once __DIR__ . '/php-public-renderer-static.php';
require_once __DIR__ . '/apriori-editorial-v2.php';

/** This is an offline renderer, not an approval issuer or publication endpoint. */
final class RentRkPublicRenderer
{
    public const VERSION = 'php-public-plan-v1.5';
    private const DOMAIN = "RentRK approved public snapshot v1\0";

    public static function canonical(mixed $value): string
    {
        $sort = static function (mixed $v) use (&$sort): mixed {
            if (!is_array($v)) { return $v; }
            if (!array_is_list($v)) { ksort($v, SORT_STRING); }
            foreach ($v as $k => $item) { $v[$k] = $sort($item); }
            return $v;
        };
        return json_encode($sort($value), JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public static function signingBytes(array $snapshot): string
    {
        return self::DOMAIN . self::canonical($snapshot);
    }

    /** $trust must originate in trusted code/configuration, NEVER request/envelope data. */
    public static function plan(?array $envelope, array $trust, string $root, string $mode = 'Full', ?string $slug = null): array
    {
        try {
            $snapshot = self::verify($envelope, $trust);
        } catch (Throwable $e) {
            return ['status' => 'BLOCKED_APPROVED_SOURCE_UNAVAILABLE', 'reason' => $e->getMessage(), 'outputs' => [], 'canApply' => false];
        }
        try {
            if (!in_array($mode, ['Full', 'Car'], true)) { throw new RuntimeException('Unsupported plan mode.'); }
            $cars = $snapshot['cars'];
            $selected = $cars;
            if ($mode === 'Car') {
                $selected = array_values(array_filter($cars, static fn(array $c): bool => $c['slug'] === $slug));
                if (count($selected) !== 1) { throw new RuntimeException('Requested approved car unavailable.'); }
            }
            $base = realpath($root);
            if ($base === false || is_link($root)) { throw new RuntimeException('Invalid observation root.'); }
            $payloads = [
                'index.html' => rent_rk_public_render_listing($snapshot, false),
                'cars/index.html' => rent_rk_public_render_listing($snapshot, true),
                'sitemap.xml' => rent_rk_public_render_sitemap($snapshot),
            ];
            foreach ($selected as $car) { $payloads['cars/' . $car['slug'] . '.html'] = rent_rk_public_render_detail($snapshot, $car); }
            $static = isset($snapshot['staticPublication']);
            $assetHashes = [];
            if ($static) {
                $payloads += RentRkPublicStaticPlan::render($snapshot, $mode, $mode === 'Car' ? $selected[0] : null);
            }
            foreach (['assets/css/main.css', 'assets/js/main.js', 'assets/js/analytics-tracker.js'] as $asset) {
                $hash = self::observeFile($base, $asset);
                if ($hash !== null) $assetHashes[$asset] = $hash;
                elseif ($static) throw new RuntimeException('Required public asset unavailable.');
            }
            $outputs = [];
            foreach ($payloads as $path => $bytes) {
                $before = self::observeFile($base, $path);
                $outputs[$path] = ['path' => $path, 'payloadBase64' => base64_encode($bytes), 'sha256' => hash('sha256', $bytes),
                    'beforeSha256' => $before, 'operation' => $before === null ? 'create' : 'replace',
                    'ownership' => $before === null ? 'unclaimed-new-target' : 'unverified-existing-target',
                    'conflicts' => $before === null ? [] : ['OWNERSHIP_REQUIRES_APPLY_VALIDATION']];
            }
            foreach ($outputs as $path => $output) {
                $current = self::observeFile($base, $path);
                if ($current !== $output['beforeSha256']) { throw new RuntimeException('Output changed during planning.'); }
            }
            foreach ($assetHashes as $path => $hash) {
                if (self::observeFile($base, $path) !== $hash) throw new RuntimeException('Public asset changed during planning.');
            }
            $limits = [];
            if (!isset($snapshot['staticPublication']['contactMedia']) && !isset($snapshot['staticPublication']['editorial']) && $mode === 'Full') $limits[] = 'CONTACT_MEDIA_NOT_APPROVED';
            if (count($cars) > 1 && array_filter($cars, static fn(array $c): bool => !isset($c['related']))) $limits[] = 'RELATED_RANKING_FACTS_NOT_APPROVED';
            foreach ($selected as $c) if (($c['parkCallback']['enabled'] ?? false) && ($c['parkCallback']['repeatPolicy'] ?? '') === 'days') {
                $limits[] = 'PARK_REPEAT_INTERVAL_UNDEFINED:' . $c['slug'];
            }
            return ['status' => 'PLAN_ONLY', 'canApply' => false, 'rendererVersion' => self::VERSION, 'mode' => $mode,
                'presentationLimits' => $limits,
                'coverage' => $static ? 'approved-static-and-core' : 'core-only',
                'snapshotSha256' => hash('sha256', self::canonical($snapshot)), 'approval' => $snapshot['approval'],
                'dependencies' => ['coreSha256' => hash_file('sha256', __FILE__),
                    'templatesSha256' => hash_file('sha256', __DIR__ . '/php-public-renderer-templates.php'),
                    'staticTemplatesSha256' => hash_file('sha256', __DIR__ . '/php-public-renderer-static.php'),
                    'editorial' => isset($snapshot['staticPublication']['editorial']) ? [
                        'edition' => RentRkApprovedEditorialV2::EDITION, 'sourceSha256' => RentRkApprovedEditorialV2::SOURCE_SHA256,
                        'projectionSha256' => RentRkApprovedEditorialV2::PROJECTION_SHA256,
                        'adapterSha256' => hash_file('sha256', __DIR__ . '/apriori-editorial-v2.php'),
                    ] : null,
                    'assets' => $assetHashes,
                    'sourceVersions' => $snapshot['sourceVersions']],
                'observationContract' => 'Optimistic per-target observations, not an atomic store snapshot; future apply must revalidate.',
                'outputs' => array_values($outputs), 'deletePaths' => [], 'publicDataPaths' => []];
        } catch (Throwable $e) {
            return ['status' => 'BLOCKED_RENDER_PLAN', 'reason' => $e->getMessage(), 'outputs' => [], 'canApply' => false];
        }
    }

    private static function observeFile(string $root, string $path): ?string
    {
        $target = $root;
        foreach (explode('/', $path) as $segment) {
            if ($segment === '' || $segment === '.' || $segment === '..') throw new RuntimeException('Invalid output path.');
            $target .= '/' . $segment;
            clearstatcache(true, $target);
            $resolved = realpath($target);
            if (is_link($target) || ($resolved !== false && str_replace('\\', '/', $resolved) !== str_replace('\\', '/', $target))) {
                throw new RuntimeException('Linked output refused.');
            }
            if ($target !== $root . '/' . $path && file_exists($target) && !is_dir($target)) throw new RuntimeException('Invalid output parent.');
        }
        if (!file_exists($target)) return null;
        if (!is_file($target) || !is_readable($target) || ($hash = hash_file('sha256', $target)) === false) throw new RuntimeException('Unreadable output refused.');
        return $hash;
    }

    private static function keys(array $value, array $allowed, array $required): void
    {
        if (array_diff(array_keys($value), $allowed) || array_diff($required, array_keys($value))) {
            throw new RuntimeException('Unexpected or missing approved projection fields.');
        }
    }

    private static function verify(?array $envelope, array $trust): array
    {
        if ($envelope === null || !extension_loaded('sodium')) { throw new RuntimeException('Signed source unavailable.'); }
        self::keys($envelope, ['snapshot', 'signature'], ['snapshot', 'signature']);
        $s = $envelope['snapshot'];
        if (!is_array($s)) { throw new RuntimeException('Invalid snapshot.'); }
        $required = ['schemaVersion', 'approval', 'sourceVersions', 'site', 'cars'];
        self::keys($s, [...$required, 'dynamicSitemapUrls', 'staticPublication'], $required);
        if ($s['schemaVersion'] !== 1) { throw new RuntimeException('Unsupported snapshot version.'); }
        $a = $s['approval'];
        self::keys($a, ['issuer', 'keyId', 'audience', 'approvalId', 'revision', 'issuedAt', 'expiresAt', 'scopeIds'], ['issuer', 'keyId', 'audience', 'approvalId', 'revision', 'issuedAt', 'expiresAt', 'scopeIds']);
        foreach (['issuer', 'keyId', 'audience', 'approvalId', 'revision'] as $key) {
            if (!isset($trust[$key]) || $trust[$key] !== $a[$key]) { throw new RuntimeException('Approval identity/version mismatch.'); }
        }
        $digest = hash('sha256', self::canonical($s));
        if (!isset($trust['snapshotSha256']) || !hash_equals($trust['snapshotSha256'], $digest)) { throw new RuntimeException('Unpinned approved source.'); }
        $signature = base64_decode((string) $envelope['signature'], true);
        $publicKey = base64_decode((string) ($trust['publicKeyBase64'] ?? ''), true);
        if ($signature === false || strlen($signature) !== SODIUM_CRYPTO_SIGN_BYTES || $publicKey === false
            || strlen($publicKey) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES
            || !sodium_crypto_sign_verify_detached($signature, self::signingBytes($s), $publicKey)) { throw new RuntimeException('Invalid approval signature.'); }
        $now = time();
        if (!is_int($a['issuedAt']) || !is_int($a['expiresAt']) || $a['issuedAt'] > $now || $a['expiresAt'] <= $now) { throw new RuntimeException('Approval outside validity period.'); }
        if (!is_array($a['scopeIds']) || !isset($trust['scopeIds']) || array_diff($a['scopeIds'], $trust['scopeIds'])) { throw new RuntimeException('Approval scope mismatch.'); }
        self::keys($s['site'], ['baseUrl', 'name', 'phone', 'telegram', 'address', 'extraSitemapPaths', 'callback'], ['baseUrl', 'name', 'phone', 'telegram', 'address', 'extraSitemapPaths', 'callback']);
        $url = parse_url($s['site']['baseUrl']);
        if (!$url || ($url['scheme'] ?? '') !== 'https' || empty($url['host']) || isset($url['user']) || isset($url['query']) || isset($url['fragment']) || !in_array($url['path'] ?? '', ['', '/'], true)) { throw new RuntimeException('Invalid approved site origin.'); }
        if (!preg_match('~\Ahttps://t\.me/[a-zA-Z0-9_]+\z~D', $s['site']['telegram']) || !preg_match('/\A\+[0-9]{7,15}\z/D', $s['site']['phone'])) { throw new RuntimeException('Invalid public contact.'); }
        self::keys($s['site']['callback'], ['enabled', 'delaySeconds', 'repeatPolicy', 'texts'], ['enabled', 'delaySeconds', 'repeatPolicy', 'texts']);
        if (!is_bool($s['site']['callback']['enabled']) || !is_int($s['site']['callback']['delaySeconds']) || $s['site']['callback']['delaySeconds'] < 0 || !in_array($s['site']['callback']['repeatPolicy'], ['daily', 'session', 'always'], true)) { throw new RuntimeException('Invalid approved callback configuration.'); }
        self::keys($s['site']['callback']['texts'], ['title', 'text', 'button_text', 'success_text'], ['title', 'text', 'button_text', 'success_text']);
        if (!is_array($s['sourceVersions']) || !$s['sourceVersions']) { throw new RuntimeException('Missing source versions.'); }
        if (array_key_exists('dynamicSitemapUrls', $s)) {
            $urls = $s['dynamicSitemapUrls'];
            if (!is_array($urls) || !array_is_list($urls) || !is_string($s['sourceVersions']['dynamicInventory'] ?? null)
                || !preg_match('/\A[a-f0-9]{64}\z/D', $s['sourceVersions']['dynamicInventory'])) {
                throw new RuntimeException('Invalid dynamic sitemap inventory.');
            }
            $seenUrls = [];
            foreach ($urls as $url) {
                if (!is_string($url) || isset($seenUrls[$url]) ||
                    !preg_match('~\Ahttps://(?:base-rent\.ru/partner/[a-z0-9-]+/|rent-rk\.ru/landing\.php\?slug=[a-z0-9]+(?:-[a-z0-9]+)*)\z~D', $url)) {
                    throw new RuntimeException('Invalid dynamic sitemap URL.');
                }
                $seenUrls[$url] = true;
            }
        }
        if (!is_array($s['cars']) || !array_is_list($s['cars'])) { throw new RuntimeException('Invalid approved cars.'); }
        $slugs = [];
        foreach ($s['cars'] as $car) {
            $fields = ['slug', 'scopeId', 'name', 'description', 'price', 'deposit', 'image', 'gallery', 'specs', 'seo', 'type', 'seats', 'drive', 'year', 'bodyType', 'fuelType', 'equipment', 'features', 'conditions', 'faq', 'content', 'brand', 'model', 'hero'];
            $foreign = ($car['scopeId'] ?? null) !== 'rent_rk';
            if ($foreign) $fields[] = 'parkCallback';
            self::keys($car, [...$fields, 'related'], $fields);
            if (array_key_exists('related', $car)) {
                $r = $car['related'];
                self::keys($r, ['price', 'badges'], ['price', 'badges']);
                if (($r['price'] !== null && (!is_int($r['price']) || $r['price'] < 0))
                    || !is_array($r['badges']) || !array_is_list($r['badges']) || count($r['badges']) > 3) throw new RuntimeException('Invalid approved related-car facts.');
                foreach ($r['badges'] as $badge) if (!is_string($badge) || $badge === '') throw new RuntimeException('Invalid approved related-car badge.');
            }
            if (!preg_match('/\A[a-z0-9]+(?:-[a-z0-9]+)*\z/D', $car['slug']) || isset($slugs[$car['slug']])) { throw new RuntimeException('Invalid or duplicate car slug.'); }
            $slugs[$car['slug']] = true;
            if (!is_string($car['scopeId']) || $car['scopeId'] === '' || !in_array($car['scopeId'], $a['scopeIds'], true)) { throw new RuntimeException('Foreign-scope car.'); }
            if ($foreign) {
                $callback = $car['parkCallback'];
                $fields = ['scopeId', 'mode', 'enabled', 'delaySeconds', 'repeatPolicy', 'texts'];
                self::keys($callback, $fields, $fields);
                if ($callback['scopeId'] !== $car['scopeId'] || !in_array($callback['mode'], ['park_own', 'disabled'], true)
                    || !is_bool($callback['enabled']) || ($callback['mode'] === 'disabled' && $callback['enabled'])
                    || !is_int($callback['delaySeconds']) || $callback['delaySeconds'] < 0
                    || !in_array($callback['repeatPolicy'], ['daily', 'session', 'days'], true)) throw new RuntimeException('Invalid approved park callback.');
                $fields = ['title', 'text', 'button_text', 'success_text'];
                self::keys($callback['texts'], $fields, $fields);
                foreach ($callback['texts'] as $text) if (!is_string($text)) throw new RuntimeException('Invalid approved park callback text.');
            }
            foreach (['price', 'deposit'] as $field) {
                if (!is_int($car[$field]) || $car[$field] < 0) { throw new RuntimeException('Invalid approved price.'); }
            }
            self::keys($car['seo'], ['title', 'description'], ['title', 'description']);
            self::keys($car['hero'], ['eyebrow', 'title', 'subtitle', 'priceText', 'primaryCta', 'secondaryCta'], ['eyebrow', 'title', 'subtitle', 'priceText', 'primaryCta', 'secondaryCta']);
            foreach (array_merge(array_values($car['hero']), array_values($car['seo'])) as $text) { if (!is_string($text)) { throw new RuntimeException('Invalid presentation text.'); } }
            foreach (['gallery', 'equipment', 'features', 'conditions'] as $list) {
                if (!is_array($car[$list]) || !array_is_list($car[$list])) { throw new RuntimeException('Invalid public list.'); }
                foreach ($car[$list] as $text) { if (!is_string($text)) { throw new RuntimeException('Non-text public list item.'); } }
            }
            foreach (['name', 'description', 'type', 'drive', 'bodyType', 'fuelType', 'brand', 'model'] as $text) {
                if (!is_string($car[$text])) { throw new RuntimeException('Non-text public field.'); }
            }
            if (!is_int($car['seats']) || $car['seats'] < 1 || !is_int($car['year']) || $car['year'] < 1900) { throw new RuntimeException('Invalid public numeric specification.'); }
            foreach ($car['faq'] as $faq) {
                self::keys($faq, ['question', 'answer'], ['question', 'answer']);
                if (!is_string($faq['question']) || !is_string($faq['answer'])) { throw new RuntimeException('Invalid public FAQ.'); }
            }
            foreach ($car['content'] as $section) {
                self::keys($section, ['heading', 'text'], ['heading', 'text']);
                if (!is_string($section['heading']) || !is_string($section['text'])) { throw new RuntimeException('Invalid public content section.'); }
            }
            foreach (array_merge([$car['image']], $car['gallery']) as $asset) {
                if (!is_string($asset) || !preg_match('~\Aassets/[a-zA-Z0-9/_-]+\.(?:webp|png|jpg|jpeg)\z~D', $asset) || str_contains($asset, '..')) { throw new RuntimeException('Invalid approved asset.'); }
            }
            foreach ($car['specs'] as $label => $value) {
                if (!is_string($label) || !is_string($value)) { throw new RuntimeException('Invalid approved specifications.'); }
            }
        }
        foreach ($s['site']['extraSitemapPaths'] as $path) {
            if (!is_string($path) || !preg_match('~\A/(?:[a-zA-Z0-9/_-]+(?:\.html)?)?\z~D', $path) || str_contains($path, '..')) { throw new RuntimeException('Invalid approved sitemap path.'); }
        }
        if (array_key_exists('staticPublication', $s)) {
            if (!is_array($s['staticPublication']) || ($s['sourceVersions']['staticPublication'] ?? null) !== hash('sha256', self::canonical($s['staticPublication']))
                || array_diff(RentRkPublicStaticPlan::paths($s['staticPublication']), $s['site']['extraSitemapPaths'])) {
                throw new RuntimeException('Static publication source or URL scope mismatch.');
            }
            if (isset($s['staticPublication']['editorial'])) RentRkApprovedEditorialV2::assertProjection(
                $s['staticPublication']['editorial'], $s['site'], $s['staticPublication']['routes']);
        }
        return $s;
    }
}
