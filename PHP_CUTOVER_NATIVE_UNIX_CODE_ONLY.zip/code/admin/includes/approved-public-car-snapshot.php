<?php
declare(strict_types=1);
require_once __DIR__ . '/php-public-renderer-core.php';
require_once __DIR__ . '/approved-public-dynamic-inventory.php';
require_once __DIR__ . '/approved-dynamic-inventory-automation.php';
require_once __DIR__ . '/approved-sitemap-continuity.php';
require_once __DIR__ . '/approved-php-plan-apply.php';

/** Trusted server configuration is never accepted from an HTTP form. */
final class ApprovedPublicCarSnapshots
{
    private array $context;
    public function __construct(array $trustedServerContext)
    {
        $this->context = $trustedServerContext;
        foreach (['issuer', 'keyId', 'publicKeyBase64', 'secretKeyBase64', 'site', 'siteDecisionId', 'inventory'] as $key) {
            if (!array_key_exists($key, $this->context)) throw new RuntimeException('BLOCKED_TRUST_CONFIGURATION_UNAVAILABLE', 503);
        }
        foreach (['issuer', 'keyId', 'siteDecisionId'] as $key) if (!is_string($this->context[$key]) || $this->context[$key] === '') throw new RuntimeException('BLOCKED_TRUST_CONFIGURATION_UNAVAILABLE', 503);
        $site = $this->context['site'];
        $siteFields = ['baseUrl', 'name', 'phone', 'telegram', 'address', 'extraSitemapPaths', 'callback'];
        if (!is_array($site) || array_diff(array_keys($site), $siteFields) || array_diff($siteFields, array_keys($site))) throw new RuntimeException('BLOCKED_PUBLIC_SITE_PROJECTION_INVALID', 503);
        foreach (['baseUrl', 'name', 'phone', 'telegram', 'address'] as $key) if (!is_string($site[$key])) throw new RuntimeException('BLOCKED_PUBLIC_SITE_PROJECTION_INVALID', 503);
        $callbackFields = ['enabled', 'delaySeconds', 'repeatPolicy', 'texts']; $texts = ['title', 'text', 'button_text', 'success_text'];
        if (!is_array($site['callback']) || array_diff(array_keys($site['callback']), $callbackFields) || array_diff($callbackFields, array_keys($site['callback']))
            || !is_array($site['callback']['texts']) || array_diff(array_keys($site['callback']['texts']), $texts) || array_diff($texts, array_keys($site['callback']['texts']))) throw new RuntimeException('BLOCKED_PUBLIC_SITE_PROJECTION_INVALID', 503);
        foreach ($site['callback']['texts'] as $value) if (!is_string($value)) throw new RuntimeException('BLOCKED_PUBLIC_SITE_PROJECTION_INVALID', 503);
        $secret = base64_decode((string) $this->context['secretKeyBase64'], true);
        $public = base64_decode((string) $this->context['publicKeyBase64'], true);
        if (!extension_loaded('sodium') || !is_string($secret) || strlen($secret) !== SODIUM_CRYPTO_SIGN_SECRETKEYBYTES
            || !is_string($public) || !hash_equals(sodium_crypto_sign_publickey_from_secretkey($secret), $public)) {
            throw new RuntimeException('BLOCKED_TRUST_CONFIGURATION_UNAVAILABLE', 503);
        }
        $revoked = $this->context['revokedKeyIds'] ?? [];
        $retired = $this->context['retiredKeys'] ?? [];
        if (!is_array($revoked) || !array_is_list($revoked) || !is_array($retired)) throw new RuntimeException('BLOCKED_SIGNING_KEY_REGISTRY_INVALID', 503);
        foreach ($revoked as $id) if (!is_string($id) || $id === '') throw new RuntimeException('BLOCKED_SIGNING_KEY_REGISTRY_INVALID', 503);
        if (in_array($this->context['keyId'], $revoked, true)) throw new RuntimeException('BLOCKED_SIGNING_KEY_REVOKED', 503);
        $seen = [base64_encode($public) => true];
        foreach ($retired as $id => $key) {
            $decoded = is_string($key['publicKeyBase64'] ?? null) ? base64_decode($key['publicKeyBase64'], true) : false;
            if ((string) $id === '' || (string) $id === $this->context['keyId'] || in_array((string) $id, $revoked, true)
                || !is_array($key) || count($key) !== 2 || !is_string($decoded) || strlen($decoded) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES
                || isset($seen[base64_encode($decoded)]) || !is_int($key['retiredAt'] ?? null) || $key['retiredAt'] <= 0 || $key['retiredAt'] > time()) {
                throw new RuntimeException('BLOCKED_SIGNING_KEY_REGISTRY_INVALID', 503);
            }
            $seen[base64_encode($decoded)] = true;
        }
    }

    public static function fromServer(): self
    {
        $configured = defined('RENT_RK_APPROVED_PUBLIC_SERVER_CONFIG') ? (string) RENT_RK_APPROVED_PUBLIC_SERVER_CONFIG : '';
        $path = $configured !== '' ? realpath($configured) : false;
        $root = rtrim(str_replace('\\', '/', (string) realpath(PROJECT_ROOT)), '/') . '/';
        if (!$path || is_link($configured) || !is_file($path) || str_starts_with(str_replace('\\', '/', $path), $root)) {
            throw new RuntimeException('BLOCKED_TRUST_CONFIGURATION_UNAVAILABLE', 503);
        }
        $config = require $path;
        if (!is_array($config)) throw new RuntimeException('BLOCKED_TRUST_CONFIGURATION_UNAVAILABLE', 503);
        return new self($config);
    }

    private static function digest(array $value): string { return hash('sha256', RentRkPublicRenderer::canonical($value)); }
    private static function actor(): array { return car_publication_actor_binding(); }
    public static function path(): string { return DATA_DIR . 'approved-public-car-snapshots.json'; }

    private static function recordNativeSitemap(?string $before, string $after, callable $operation): void
    {
        if ($before === $after) return;
        $store = self::store();
        if (!array_key_exists('dynamicInventory', $store) && !array_key_exists('sitemapContinuity', $store)) {
            // Existing publishers are not gated on provisioning unless a baseline was already tracked.
            foreach (read_audit_log()['items'] ?? [] as $row) {
                if (in_array($row['action'] ?? '', ['public_inventory.technical_attestation', 'public_inventory.sitemap_transition'], true)) {
                    throw new RuntimeException('BLOCKED_SITEMAP_CONTINUITY_ORIGIN_MISSING', 409);
                }
            }
            return;
        }
        $service = self::fromServer();
        $origin = ApprovedDynamicInventoryAutomation::trustedOrigin($store, $service->context);
        ApprovedSitemapContinuity::record($store, $origin, $service->context, $before, $after, $operation());
    }

    public static function recordDemandSitemap(string $action, string $commandId, array $old, array $current, ?string $before, string $after): void
    {
        self::recordNativeSitemap($before, $after, static function () use ($action, $commandId, $old, $current): array {
            $id = $old['id'] ?? null;
            $scope = $old['scope_id'] ?? null;
            if (!is_string($id) || $id === '' || ($current['id'] ?? null) !== $id || !is_string($scope) || !demand_scope_exists($scope)
                || ($current['scope_id'] ?? null) !== $scope || !demand_publication_changes_sitemap($action)) {
                throw new RuntimeException('BLOCKED_SITEMAP_CONTINUITY_SCOPE', 409);
            }
            $oldUrl = demand_public_landing_url($old);
            $finalUrl = demand_public_landing_url($current);
            $indexed = ($current['publishStatus'] ?? null) === 'published_indexed' && ($current['indexStatus'] ?? null) === 'in_sitemap';
            return ['writer' => 'demand', 'action' => $action, 'reference' => $commandId,
                'entity' => $id, 'scope' => $scope, 'targets' => array_values(array_unique([$oldUrl, $finalUrl])),
                'oldUrl' => $oldUrl, 'finalUrl' => $finalUrl, 'indexed' => $indexed];
        });
    }

    public static function recordOptionCSitemap(string $slug, string $planDigest, string $before, string $after): void
    {
        self::recordNativeSitemap($before, $after, static fn(): array => ['writer' => 'option_c', 'action' => 'apply', 'reference' => $planDigest,
            'slug' => $slug, 'targets' => [rtrim(RENT_RK_PUBLIC_BASE_URL, '/') . '/cars/' . $slug . '.html']]);
    }

    private static function rawCar(string $slug): array
    {
        foreach (RentalReturnStore::read(CARS_FILE, []) as $car) if (is_array($car) && ($car['slug'] ?? '') === $slug) return $car;
        throw new RuntimeException('BLOCKED_CAR_SOURCE_UNAVAILABLE', 409);
    }

    private static function eligible(array $car): bool
    {
        $raw = self::rawCar((string) $car['slug']);
        return car_visible_in_public_rent_rk_showcase($car) && ($raw['adminStatus'] ?? '') === 'active'
            && ($raw['publicStatus'] ?? '') === 'published' && ($raw['isPublished'] ?? null) === true
            && in_array('rent_rk_public', (array) ($raw['publishChannels'] ?? []), true);
    }

    public static function store(): array
    {
        $path = self::path();
        if (is_link($path) || (file_exists($path) && !is_file($path))) throw new RuntimeException('BLOCKED_APPROVAL_STORE_INVALID', 503);
        $s = RentalReturnStore::read($path, ['schemaVersion' => 1, 'version' => 0, 'objects' => [], 'active' => []]);
        if (($s['schemaVersion'] ?? null) !== 1 || !is_int($s['version'] ?? null) || !is_array($s['objects'] ?? null) || !is_array($s['active'] ?? null)) {
            throw new RuntimeException('BLOCKED_APPROVAL_STORE_INVALID', 503);
        }
        if ($s['version'] < 0) throw new RuntimeException('BLOCKED_APPROVAL_STORE_INVALID', 503);
        foreach ($s['objects'] as $id => $object) {
            if (!preg_match('/\Aapc_[a-f0-9]{64}\z/D', (string) $id) || !is_array($object['immutable'] ?? null)
                || ($object['immutable']['id'] ?? null) !== $id || !is_string($object['digest'] ?? null)
                || !hash_equals($object['digest'], self::digest($object['immutable']))) throw new RuntimeException('BLOCKED_APPROVAL_STORE_INVALID', 503);
        }
        foreach ($s['active'] as $slug => $head) {
            if (!is_array($head) || !isset($s['objects'][$head['id'] ?? '']) || !is_int($head['revision'] ?? null) || $head['revision'] < 1
                || !in_array($head['state'] ?? '', ['approved', 'revoked'], true)
                || ($s['objects'][$head['id']]['immutable']['slug'] ?? null) !== $slug
                || ($s['objects'][$head['id']]['immutable']['revision'] ?? null) !== $head['revision'] - ($head['state'] === 'revoked' ? 1 : 0)) throw new RuntimeException('BLOCKED_APPROVAL_STORE_INVALID', 503);
        }
        return $s;
    }

    private static function car(string $slug, bool $approve = false): array
    {
        if (!has_permission('cars.view')) throw new RuntimeException('Недостаточно прав просмотра.', 403);
        $car = null;
        foreach (scope_cars_for_current_user(read_cars()) as $row) { if (($row['slug'] ?? '') === $slug) { $car = $row; break; } }
        if (!$car) throw new RuntimeException('Автомобиль недоступен в этом контуре.', 403);
        $scope = car_owner_scope_id($car);
        if (!can_view_car_page_content_editor($car) || !current_user_can_view_tariffs($scope)) throw new RuntimeException('Составной кандидат недоступен.', 403);
        if ($approve && (!has_permission('cars.publish') || !has_permission('cars.edit') || !has_permission('settings.manage')
            || !current_user_is_platform_admin() || !page_content_current_user_can_moderate() || !current_user_can_edit_tariffs($scope))) {
            throw new RuntimeException('Недостаточно существующих полномочий для всех групп полей.', 403);
        }
        if ($approve && car_owner_type($car) === 'lessor' && (!current_user_can_manage_lessor_publication_review() || !admin_can_review_lessor_car($car))) {
            throw new RuntimeException('Нет полномочий модерации публикации внешнего парка.', 403);
        }
        return $car;
    }

    private static function asset(string $path): array
    {
        $path = ltrim(str_replace('\\', '/', $path), '/');
        if (!preg_match('~\Aassets/[a-zA-Z0-9/_-]+\.(?:png|webp|jpg|jpeg)\z~D', $path) || str_contains($path, '..')) throw new RuntimeException('BLOCKED_PHOTO_SOURCE_INVALID', 409);
        $root = rtrim(str_replace('\\', '/', (string) realpath(PROJECT_ROOT)), '/') . '/';
        $full = realpath(PROJECT_ROOT . $path);
        if (!$full || !is_file($full) || is_link(PROJECT_ROOT . $path) || !str_starts_with(str_replace('\\', '/', $full), $root . 'assets/')) throw new RuntimeException('BLOCKED_PHOTO_SOURCE_UNAVAILABLE', 409);
        $hash = hash_file('sha256', $full);
        if (!is_string($hash)) throw new RuntimeException('BLOCKED_PHOTO_SOURCE_UNAVAILABLE', 503);
        return ['path' => $path, 'sha256' => $hash];
    }

    private function publicContext(): array
    {
        return ['issuer' => $this->context['issuer'], 'keyId' => $this->context['keyId'], 'site' => $this->context['site'],
            'siteDecisionId' => $this->context['siteDecisionId'], 'inventory' => $this->context['inventory']];
    }

    public static function canApprove(string $slug): bool
    {
        try { self::car($slug, true); return true; } catch (Throwable $e) { return false; }
    }

    private static function parkCallback(array $car): array
    {
        $scopeId = car_owner_scope_id($car);
        $scope = scope_control_item($scopeId);
        if (!$scope || ($scope['owner_type'] ?? '') !== 'lessor') throw new RuntimeException('BLOCKED_PARK_CALLBACK_SCOPE_UNAVAILABLE', 409);
        $settings = RentalReturnStore::read(CALLBACK_SETTINGS_FILE, []);
        $parks = $settings['parks'] ?? null;
        $row = is_array($parks) ? ($parks[$scopeId] ?? null) : null;
        if (!is_array($row) || (array_key_exists('scope_id', $row) && $row['scope_id'] !== $scopeId)) {
            throw new RuntimeException('BLOCKED_PARK_CALLBACK_CONFIGURATION_UNAVAILABLE', 409);
        }
        foreach (array_keys($parks) as $key) {
            if ((string) $key !== $scopeId && trim((string) $key) === $scopeId) throw new RuntimeException('BLOCKED_PARK_CALLBACK_SCOPE_AMBIGUOUS', 409);
        }
        $mode = $row['callback_mode'] ?? null;
        if (!in_array($mode, ['park_own', 'disabled'], true)) throw new RuntimeException('BLOCKED_PARK_CALLBACK_MODE_UNSUPPORTED', 409);
        $settings = normalize_callback_park_settings($scopeId, $row);
        $enabled = $mode === 'park_own' && $settings['park_callback_enabled'] && !empty($scope['active'])
            && scope_feature_enabled($scopeId, 'park_active') && public_car_visible_for_api($car);
        return ['scopeId' => $scopeId, 'mode' => $mode, 'enabled' => $enabled, 'delaySeconds' => $settings['delay_seconds'],
            'repeatPolicy' => $settings['repeat_policy'], 'texts' => [
                'title' => $mode === 'park_own' ? $settings['park_title'] : '',
                'text' => $mode === 'park_own' ? $settings['park_text'] : '',
                'button_text' => $mode === 'park_own' ? $settings['park_button_text'] : '',
                'success_text' => $mode === 'park_own' ? 'Заявка принята.' : '',
            ]];
    }

    private static function assertCurrentParkCallback(array $approved, array $car): void
    {
        if ($approved['scopeId'] !== car_owner_scope_id($car)) throw new RuntimeException('BLOCKED_APPROVED_SCOPE_CHANGED', 409);
        if ($approved['scopeId'] !== 'rent_rk'
            && (!is_array($approved['parkCallback'] ?? null) || self::digest($approved['parkCallback']) !== self::digest(self::parkCallback($car)))) {
            throw new RuntimeException('BLOCKED_APPROVED_PARK_CALLBACK_STALE', 409);
        }
    }

    public function candidate(string $slug): array
    {
        $car = self::car($slug);
        $parkCallback = car_owner_scope_id($car) === 'rent_rk' ? null : self::parkCallback($car);
        $rate = rate_for_car($slug, $car);
        $content = normalize_car_page_content_payload(car_page_content_saved($slug) ?? [], $car, $slug);
        $price = car_publication_display_price($car, $rate);
        $deposit = normalize_rate_price($rate['depositAmount'] ?? $car['depositAmount'] ?? null);
        if ($price === null || $deposit === null) throw new RuntimeException('BLOCKED_RENDERER_MONEY_CONTRACT_UNAVAILABLE', 409);
        $main = self::asset((string) ($car['image'] ?? ''));
        $photos = [$main['path']]; $assets = [$main['path'] => $main['sha256']];
        foreach (car_photos($car) as $photo) {
            $asset = self::asset((string) ($photo['path'] ?? ''));
            $photos[] = $asset['path']; $assets[$asset['path']] = $asset['sha256'];
        }
        $specs = [];
        foreach (array_merge($content['specs']['items'], $content['rentalTerms']['items']) as $pair) {
            $label = (string) ($pair['label'] ?? '');
            if (isset($specs[$label])) throw new RuntimeException('BLOCKED_AMBIGUOUS_SPEC_LABEL', 409);
            $specs[$label] = (string) ($pair['value'] ?? '');
        }
        $sections = [];
        foreach ($content['content'] as $heading => $lines) $sections[] = ['heading' => (string) $heading, 'text' => implode("\n", $lines)];
        $projection = ['slug' => $slug, 'scopeId' => car_owner_scope_id($car), 'name' => (string) ($car['name'] ?? ''),
            'description' => (string) ($car['detailDescription'] ?? $car['cardDescription'] ?? ''), 'price' => $price, 'deposit' => $deposit,
            'image' => $main['path'], 'gallery' => array_values(array_unique($photos)), 'specs' => $specs, 'seo' => $content['seo'],
            'type' => (string) ($car['class'] ?? ''), 'seats' => (int) ($car['seats'] ?? 0), 'drive' => (string) ($car['drive'] ?? ''),
            'year' => (int) ($car['year'] ?? 0), 'bodyType' => (string) ($car['bodyType'] ?? ''), 'fuelType' => (string) ($car['fuelType'] ?? ''),
            'equipment' => array_values(array_map('strval', (array) ($car['equipment'] ?? []))), 'features' => array_values($content['content']['fitFor']),
            'conditions' => array_values(array_map(static fn(array $p): string => $p['label'] . ': ' . $p['value'], $content['rentalTerms']['items'])),
            'faq' => $content['faq']['items'], 'content' => $sections, 'brand' => (string) ($car['brand'] ?? ''), 'model' => (string) ($car['model'] ?? ''), 'hero' => $content['hero']];
        $projection['related'] = rent_rk_public_related_facts($car,
            normalize_rate_price($rate['manual'] ?? null) ?? normalize_rate_price($rate['base'] ?? null) ?? normalize_rate_price($car['price'] ?? null));
        if ($projection['year'] < 1900 || $projection['seats'] < 1) throw new RuntimeException('BLOCKED_RENDERER_SPEC_CONTRACT_UNAVAILABLE', 409);
        $sources = ['car' => self::digest($car), 'rawCar' => self::digest(self::rawCar($slug)), 'rates' => self::digest($rate), 'pageContent' => self::digest($content),
            'photos' => self::digest($assets), 'trustedSite' => self::digest($this->publicContext()),
            'projector' => hash_file('sha256', __FILE__), 'renderer' => hash_file('sha256', __DIR__ . '/php-public-renderer-core.php')];
        if ($parkCallback !== null) {
            $projection['parkCallback'] = $parkCallback;
            $sources['parkCallback'] = self::digest($parkCallback);
        }
        $fieldSources = [];
        foreach (array_keys($projection) as $field) {
            $groups = $field === 'related' ? ['car', 'rates', 'projector'] : (in_array($field, ['price', 'deposit'], true) ? ['car', 'rates'] : (in_array($field, ['image', 'gallery'], true) ? ['car', 'photos']
                : (in_array($field, ['hero', 'seo', 'faq', 'content', 'conditions', 'features', 'specs'], true) ? ['car', 'rates', 'pageContent', 'projector'] : ['car'])));
            $fieldSources['car.' . $field] = array_intersect_key($sources, array_flip(array_merge($groups, ['rawCar'])));
        }
        if ($parkCallback !== null) $fieldSources['car.parkCallback']['parkCallback'] = $sources['parkCallback'];
        foreach (array_keys($this->context['site']) as $field) $fieldSources['site.' . $field] = ['decisionId' => $this->context['siteDecisionId'], 'digest' => $sources['trustedSite']];
        $material = ['car' => $projection, 'site' => $this->context['site'], 'sources' => $sources, 'fieldSources' => $fieldSources, 'assets' => $assets];
        $store = self::store(); $head = $store['active'][$slug] ?? null; $matchesApproved = false; $recoveryHistory = null;
        if (($head['state'] ?? '') === 'approved') {
            try {
                $matchesApproved = hash_equals($this->verifiedObject($store, $slug, false)['materialDigest'], self::digest($material));
            } catch (Throwable $e) {
                if ($e instanceof RuntimeException && $e->getMessage() === 'BLOCKED_ATTESTATION_KEY_REVOKED') {
                    // This fingerprint identifies archived evidence; it is not a trust anchor.
                    $recoveryHistory = ['id' => $head['id'], 'revision' => $head['revision'],
                        'storedRowSha256' => self::digest($store['objects'][$head['id']])];
                }
            }
        }
        $reviewVersion = self::digest(['material' => $material, 'head' => $head, 'actor' => self::actor()]);
        return ['status' => 'UNAPPROVED_CANDIDATE', 'material' => $material, 'materialDigest' => self::digest($material),
            'reviewVersion' => $reviewVersion, 'recoveryHistory' => $recoveryHistory,
            'recoveryVersion' => $recoveryHistory === null ? null : self::digest(['action' => 'recover_revoked_key',
                'candidateVersion' => $reviewVersion, 'untrustedHistory' => $recoveryHistory,
                'signingPublicKey' => $this->context['publicKeyBase64']]),
            'currentApproval' => $head, 'matchesApproved' => $matchesApproved, 'eligible' => self::eligible($car)];
    }

    private function envelope(array $snapshot): array
    {
        $secret = base64_decode($this->context['secretKeyBase64'], true);
        $signature = sodium_crypto_sign_detached(RentRkPublicRenderer::signingBytes($snapshot), $secret);
        sodium_memzero($secret);
        return ['snapshot' => $snapshot, 'signature' => base64_encode($signature)];
    }

    public function approve(string $slug, string $reviewVersion, bool $confirmed): array
    {
        return $this->approveVersion($slug, $reviewVersion, $confirmed, false);
    }

    public function recoverRevokedKey(string $slug, string $reviewVersion, bool $confirmed): array
    {
        return $this->approveVersion($slug, $reviewVersion, $confirmed, true);
    }

    private function approveVersion(string $slug, string $reviewVersion, bool $confirmed, bool $recoverRevoked): array
    {
        if (!RentalReturnStore::active()) return RentalReturnStore::transaction(fn(): array => $this->approveVersion($slug, $reviewVersion, $confirmed, $recoverRevoked));
        self::car($slug, true);
        if (!$confirmed) throw new RuntimeException('Требуется индивидуальное подтверждение публикации версии.', 422);
        $candidate = $this->candidate($slug);
        if (!$candidate['eligible']) throw new RuntimeException('BLOCKED_PUBLIC_CHANNEL_NOT_ENABLED', 409);
        $s = self::store(); $head = $s['active'][$slug] ?? null;
        if ($recoverRevoked && $candidate['recoveryVersion'] === null) throw new RuntimeException('BLOCKED_KEY_RECOVERY_NOT_REQUIRED', 409);
        if (!$recoverRevoked && $head && $head['state'] === 'approved') {
            $object = $this->verifiedObject($s, $slug, false);
            if (hash_equals($object['materialDigest'], $candidate['materialDigest'])
                && (hash_equals($object['reviewVersion'], $reviewVersion) || hash_equals($candidate['reviewVersion'], $reviewVersion))) {
                return ['status' => 'ALREADY_APPROVED_NOT_PUBLISHED', 'id' => $head['id'], 'revision' => $head['revision']];
            }
        }
        $expectedVersion = $recoverRevoked ? $candidate['recoveryVersion'] : $candidate['reviewVersion'];
        if (!hash_equals($expectedVersion, $reviewVersion)) throw new RuntimeException('Кандидат, контур или активная версия изменились.', 409);
        $revision = (int) ($head['revision'] ?? 0) + 1;
        $id = 'apc_' . self::digest(['slug' => $slug, 'revision' => $revision, 'material' => $candidate['materialDigest']]);
        $material = $candidate['material']; $now = time();
        $ttl = (int) ($this->context['signatureLifetimeSeconds'] ?? 3600);
        if ($ttl < 1 || $ttl > 86400) throw new RuntimeException('BLOCKED_SIGNING_CONFIGURATION_INVALID', 503);
        $approvedAt = now_iso(); $approvedBy = self::actor();
        $decision = ['action' => 'approve_public_car_snapshot', 'permissions' => ['cars.publish', 'cars.edit', 'settings.manage', 'central_page_content_moderation', 'scoped_tariff_edit'], 'siteDecisionId' => $this->context['siteDecisionId']];
        if ($recoverRevoked) {
            $decision['action'] = 'reapprove_after_key_revocation';
            $decision['untrustedHistory'] = $candidate['recoveryHistory'];
        }
        $signedSources = $material['sources'] + ['approvalMaterial' => $candidate['materialDigest'], 'reviewVersion' => $reviewVersion,
            'decisionDigest' => self::digest(['by' => $approvedBy, 'at' => $approvedAt, 'decision' => $decision])];
        $snapshot = ['schemaVersion' => 1, 'approval' => ['issuer' => $this->context['issuer'], 'keyId' => $this->context['keyId'], 'audience' => 'rent-rk-core',
            'approvalId' => $id, 'revision' => $revision, 'issuedAt' => $now, 'expiresAt' => $now + $ttl, 'scopeIds' => [$material['car']['scopeId']]],
            'sourceVersions' => $signedSources, 'site' => $material['site'], 'cars' => [$material['car']]];
        $immutable = ['id' => $id, 'slug' => $slug, 'revision' => $revision, 'channel' => 'rent_rk_public', 'publishAuthorized' => true,
            'approvedAt' => $approvedAt, 'approvedBy' => $approvedBy, 'reviewVersion' => $reviewVersion, 'materialDigest' => $candidate['materialDigest'],
            'material' => $material, 'envelope' => $this->envelope($snapshot),
            'decision' => $decision];
        if (isset($s['objects'][$id])) throw new RuntimeException('Конфликт неизменяемой версии.', 409);
        $s['objects'][$id] = ['immutable' => $immutable, 'digest' => self::digest($immutable)];
        $s['active'][$slug] = ['id' => $id, 'revision' => $revision, 'state' => 'approved']; $s['version']++;
        if (!RentalReturnStore::stage(self::path(), $s)) throw new LogicException('Snapshot requires transaction.');
        $meta = ['id' => $id, 'revision' => $revision, 'digest' => $s['objects'][$id]['digest'], 'published' => false];
        if ($recoverRevoked) $meta['untrustedHistory'] = $candidate['recoveryHistory'];
        audit_log($recoverRevoked ? 'public_car_snapshot.reapproved_after_key_revocation' : 'public_car_snapshot.approved',
            'car', $slug, 'Разрешена конкретная публичная версия; витрина не обновлена', $meta);
        PhpPublicationAutomation::publish($slug);
        return ['status' => $recoverRevoked ? 'REAPPROVED_NOT_PUBLISHED' : 'APPROVED_NOT_PUBLISHED', 'id' => $id, 'revision' => $revision];
    }

    public static function revokeVersion(string $slug): string
    {
        self::car($slug);
        return self::digest(['slug' => $slug, 'head' => self::store()['active'][$slug] ?? null, 'actor' => self::actor()]);
    }

    public function revoke(string $slug, string $version, string $reason): array
    {
        if (!RentalReturnStore::active()) return RentalReturnStore::transaction(fn(): array => $this->revoke($slug, $version, $reason));
        self::car($slug, true);
        if ($reason === '' || !hash_equals(self::revokeVersion($slug), $version)) throw new RuntimeException('Причина отсутствует или версия отзыва устарела.', 409);
        $s = self::store(); $head = $s['active'][$slug] ?? null;
        if (!$head || $head['state'] !== 'approved') throw new RuntimeException('Активное одобрение отсутствует.', 409);
        $s['active'][$slug] = ['id' => $head['id'], 'revision' => $head['revision'] + 1, 'state' => 'revoked', 'reason' => mb_substr($reason, 0, 600), 'at' => now_iso(), 'by' => self::actor()];
        $s['version']++; RentalReturnStore::stage(self::path(), $s);
        audit_log('public_car_snapshot.revoked', 'car', $slug, 'Отозвано одобрение; публичные файлы не изменены', ['id' => $head['id'], 'reason' => mb_substr($reason, 0, 600)]);
        PhpPublicationAutomation::withdraw('revoke', $slug, $s['objects'][$head['id']]['immutable']['material']['car']['scopeId']);
        return ['status' => 'REVOKED_NOT_UNPUBLISHED'];
    }

    private function verifiedObject(array $s, string $slug, bool $requireCurrentAssets = true, ?array &$effective = null): array
    {
        $head = $s['active'][$slug] ?? null;
        if (!$head || $head['state'] !== 'approved') throw new RuntimeException('BLOCKED_APPROVED_SOURCE_UNAVAILABLE', 409);
        $row = $s['objects'][$head['id']] ?? null; $o = $row['immutable'] ?? null;
        if (!is_array($o) || !hash_equals((string) ($row['digest'] ?? ''), self::digest($o)) || $o['id'] !== $head['id'] || $o['slug'] !== $slug || $o['revision'] !== $head['revision']
            || $o['channel'] !== 'rent_rk_public' || $o['publishAuthorized'] !== true || !hash_equals($o['materialDigest'], self::digest($o['material']))) throw new RuntimeException('BLOCKED_APPROVAL_INTEGRITY', 409);
        $e = $o['envelope']; $a = $e['snapshot']['approval'];
        $expectedSources = $o['material']['sources'] + ['approvalMaterial' => $o['materialDigest'], 'reviewVersion' => $o['reviewVersion'],
            'decisionDigest' => self::digest(['by' => $o['approvedBy'], 'at' => $o['approvedAt'], 'decision' => $o['decision']])];
        if ($a['issuer'] !== $this->context['issuer'] || $a['approvalId'] !== $o['id'] || $a['revision'] !== $o['revision']
            || $e['snapshot']['sourceVersions'] !== $expectedSources
            || $e['snapshot']['cars'] !== [$o['material']['car']] || $e['snapshot']['site'] !== $o['material']['site']
            || !$this->validAttestation($e)) throw new RuntimeException('BLOCKED_APPROVAL_SIGNATURE', 409);
        $history = array_key_exists('attestations', $row) ? $row['attestations'] : [];
        if (!is_array($history) || !array_is_list($history)) throw new RuntimeException('BLOCKED_ATTESTATION_HISTORY', 409);
        $effective = $e;
        $usedKeys = [$a['keyId'] => true];
        foreach ($history as $renewal) {
            if (!is_array($renewal) || !$this->validAttestation($renewal)) throw new RuntimeException('BLOCKED_ATTESTATION_HISTORY', 409);
            $period = $renewal['snapshot']['approval'];
            $expected = $e['snapshot'];
            $expected['approval']['issuedAt'] = $period['issuedAt'];
            $expected['approval']['expiresAt'] = $period['expiresAt'];
            $expected['approval']['keyId'] = $period['keyId'];
            $previous = $effective['snapshot']['approval'];
            $changingKey = $previous['keyId'] !== $period['keyId'];
            $cutover = $this->context['retiredKeys'][$previous['keyId']]['retiredAt'] ?? null;
            if ($changingKey) $expected['approval']['previousAttestationSha256'] = self::digest($effective);
            if ($renewal['snapshot'] !== $expected || ($changingKey
                ? ($cutover === null || $period['issuedAt'] < $cutover || isset($usedKeys[$period['keyId']]))
                : $period['issuedAt'] < $previous['expiresAt'])) throw new RuntimeException('BLOCKED_ATTESTATION_HISTORY', 409);
            $usedKeys[$period['keyId']] = true;
            $effective = $renewal;
        }
        if ($requireCurrentAssets) foreach ($o['material']['assets'] as $path => $hash) { if (!hash_equals($hash, self::asset($path)['sha256'])) throw new RuntimeException('BLOCKED_APPROVED_ASSET_CHANGED', 409); }
        return $o;
    }

    private function validAttestation(array $envelope): bool
    {
        $snapshot = $envelope['snapshot'] ?? null;
        $period = $snapshot['approval'] ?? null;
        $signature = is_string($envelope['signature'] ?? null) ? base64_decode($envelope['signature'], true) : false;
        $keyId = $period['keyId'] ?? null;
        if (!is_string($keyId) || ($period['issuer'] ?? null) !== $this->context['issuer']) return false;
        if (in_array($keyId, $this->context['revokedKeyIds'] ?? [], true)) throw new RuntimeException('BLOCKED_ATTESTATION_KEY_REVOKED', 409);
        $retired = $this->context['retiredKeys'][$keyId] ?? null;
        $key = $keyId === $this->context['keyId'] ? $this->context['publicKeyBase64'] : ($retired['publicKeyBase64'] ?? null);
        return is_string($key) && count($envelope) === 2 && is_int($period['issuedAt'] ?? null) && is_int($period['expiresAt'] ?? null)
            && $period['issuedAt'] > 0 && $period['issuedAt'] <= time() && $period['expiresAt'] > $period['issuedAt']
            && ($retired === null || $period['issuedAt'] <= $retired['retiredAt'])
            && $period['expiresAt'] - $period['issuedAt'] <= 86400
            && is_string($signature) && strlen($signature) === SODIUM_CRYPTO_SIGN_BYTES
            && sodium_crypto_sign_verify_detached($signature, RentRkPublicRenderer::signingBytes($snapshot), base64_decode($key, true));
    }

    private function renewalState(string $slug, array $store, ?array &$effective): array
    {
        $car = self::car($slug, true);
        if (!self::eligible($car)) throw new RuntimeException('BLOCKED_PUBLIC_CHANNEL_NOT_ENABLED', 409);
        $object = $this->verifiedObject($store, $slug, true, $effective);
        self::assertCurrentParkCallback($object['material']['car'], $car);
        if ($object['material']['site'] !== $this->context['site'] || $object['decision']['siteDecisionId'] !== $this->context['siteDecisionId']) {
            throw new RuntimeException('BLOCKED_APPROVED_SITE_VERSION_MISMATCH', 409);
        }
        return ['id' => $object['id'], 'revision' => $object['revision'],
            'version' => self::digest(['object' => $store['objects'][$object['id']]['digest'], 'attestation' => $effective, 'actor' => self::actor(),
                'signingKeyId' => $this->context['keyId'], 'signingPublicKey' => $this->context['publicKeyBase64']]),
            'rotating' => $effective['snapshot']['approval']['keyId'] !== $this->context['keyId'],
            'expiresAt' => $effective['snapshot']['approval']['expiresAt']];
    }

    public function renewalVersion(string $slug): ?array
    {
        $effective = null;
        $state = $this->renewalState($slug, self::store(), $effective);
        return $state['rotating'] || $state['expiresAt'] <= time() ? $state : null;
    }

    public function reattest(string $slug, string $version): array
    {
        if (!RentalReturnStore::active()) return RentalReturnStore::transaction(fn(): array => $this->reattest($slug, $version));
        $store = self::store(); $effective = null;
        $state = $this->renewalState($slug, $store, $effective);
        if (!hash_equals($state['version'], $version)) throw new RuntimeException('BLOCKED_ATTESTATION_VERSION_STALE', 409);
        $now = time();
        if (!$state['rotating'] && $state['expiresAt'] > $now) return ['status' => 'ATTESTATION_STILL_VALID', 'id' => $state['id'], 'revision' => $state['revision']];
        [$envelope, $audit] = $this->nextAttestation($effective, $now);
        $store['objects'][$state['id']]['attestations'][] = $envelope;
        self::saveAttestations($store, [$slug => $audit]);
        return ['status' => 'REATTESTED_NOT_PUBLISHED', 'id' => $state['id'], 'revision' => $state['revision']];
    }

    private function nextAttestation(array $effective, int $now): array
    {
        $ttl = (int) ($this->context['signatureLifetimeSeconds'] ?? 3600);
        if ($ttl < 1 || $ttl > 86400) throw new RuntimeException('BLOCKED_SIGNING_CONFIGURATION_INVALID', 503);
        $snapshot = $effective['snapshot'];
        $previous = $snapshot['approval'];
        $rotating = $previous['keyId'] !== $this->context['keyId'];
        $snapshot['approval']['keyId'] = $this->context['keyId'];
        unset($snapshot['approval']['previousAttestationSha256']);
        $snapshot['approval']['issuedAt'] = $now;
        $snapshot['approval']['expiresAt'] = $now + $ttl;
        if ($rotating) $snapshot['approval']['previousAttestationSha256'] = self::digest($effective);
        $envelope = $this->envelope($snapshot);
        return [$envelope, ['id' => $previous['approvalId'], 'revision' => $previous['revision'], 'previousAttestationSha256' => self::digest($effective),
            'attestationSha256' => self::digest($envelope), 'expiresAt' => $snapshot['approval']['expiresAt'], 'published' => false]
            + ($rotating ? ['previousKeyId' => $previous['keyId'], 'keyId' => $snapshot['approval']['keyId']] : [])];
    }

    private static function saveAttestations(array $store, array $audits): void
    {
        if (!RentalReturnStore::stage(self::path(), $store)) throw new LogicException('Re-attestation requires transaction.');
        foreach ($audits as $slug => $audit) {
            audit_log('public_car_snapshot.reattested', 'car', (string) $slug, 'Обновлена техническая подпись; одобрение и витрина не изменены', $audit);
        }
    }

    private function staticPublication(array $inventory): ?array
    {
        if (!array_key_exists('staticPublication', $this->context)) return null;
        $approved = $this->context['staticPublication'];
        if (!is_array($approved) || ($approved['siteDecisionId'] ?? null) !== $this->context['siteDecisionId']
            || ($inventory['staticPagesSha256'] ?? null) !== self::digest($approved)) {
            throw new RuntimeException('BLOCKED_STATIC_PUBLIC_SOURCE_UNVERIFIED', 409);
        }
        $editorial = array_key_exists('editorialEdition', $approved) || array_key_exists('editorialSourceSha256', $approved);
        if ($editorial) {
            if (count($approved) !== 3 || ($approved['editorialEdition'] ?? null) !== RentRkApprovedEditorialV2::EDITION
                || ($approved['editorialSourceSha256'] ?? null) !== RentRkApprovedEditorialV2::SOURCE_SHA256) {
                throw new RuntimeException('BLOCKED_APPROVED_EDITORIAL_SOURCE_MISMATCH', 409);
            }
        } elseif (array_diff(array_keys($approved), ['siteDecisionId', 'pages', 'contactMedia']) || !is_array($approved['pages'] ?? null)) {
            throw new RuntimeException('BLOCKED_STATIC_PUBLIC_SOURCE_UNVERIFIED', 409);
        }
        $file = PROJECT_ROOT . 'data/routes.json';
        $bytes = is_link($file) || is_link(dirname($file)) || !is_file($file) ? false : file_get_contents($file);
        if ($bytes === false || ($inventory['dependencies']['routes'] ?? null) !== hash('sha256', $bytes)) {
            throw new RuntimeException('BLOCKED_STATIC_PUBLIC_ROUTES_UNVERIFIED', 409);
        }
        $routes = json_decode($bytes, true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($routes) || !array_is_list($routes)) throw new RuntimeException('BLOCKED_STATIC_PUBLIC_ROUTE_INVALID', 409);
        $fields = array_fill_keys(['slug', 'title', 'summary', 'description', 'type', 'duration', 'car', 'audience'], true);
        $projection = ['routes' => array_map(static function ($route) use ($fields): array {
            if (!is_array($route)) throw new RuntimeException('BLOCKED_STATIC_PUBLIC_ROUTE_INVALID', 409);
            return array_intersect_key($route, $fields);
        }, $routes)];
        if ($editorial) $projection['editorial'] = RentRkApprovedEditorialV2::load();
        else {
            $projection['pages'] = $approved['pages'];
            if (array_key_exists('contactMedia', $approved)) $projection['contactMedia'] = $approved['contactMedia'];
        }
        return $projection;
    }

    public function plan(string $slug, string $mode = 'Car'): array
    {
        self::car($slug);
        try {
            if (RentalReturnStore::active()) throw new LogicException('BLOCKED_PLAN_REQUIRES_OWN_COMMIT_BOUNDARY');
            RentalReturnStore::enter();
            return $this->renderLocked($slug, $mode, true);
        } catch (Throwable $e) { return ['status' => $e->getMessage(), 'outputs' => [], 'canApply' => false]; }
    }

    private function renderLocked(string $slug, string $mode, bool $refresh, ?array &$expectedUrls = null, ?array $job = null, bool $carDryRun = false): array
    {
            $withdraw = $job !== null && in_array($job['kind'], ['hide', 'archive', 'delete', 'revoke'], true);
            $queue = PhpPublicationAutomation::enabled() ? PhpPublicationAutomation::store() : ['cars' => []];
            $targetCar = $carDryRun ? self::carDryRunTarget($slug) : ($job === null ? self::car($slug, !$refresh) : find_car($slug));
            if (!$withdraw && (!$targetCar || !self::eligible($targetCar)
                || ($job === null && !empty($queue['cars'][$slug]['withdrawn']))
                || ($job !== null && car_owner_scope_id($targetCar) !== $job['scope']))) {
                throw new RuntimeException('BLOCKED_PUBLIC_CHANNEL_NOT_ENABLED', 409);
            }
            if ($withdraw && $targetCar && car_owner_scope_id($targetCar) !== $job['scope']) {
                throw new RuntimeException('BLOCKED_PHP_AUTOMATION_SCOPE', 409);
            }
            $s = self::store(); $targetEnvelope = null;
            $target = $withdraw ? ['material' => ['site' => $this->context['site']], 'decision' => ['siteDecisionId' => $this->context['siteDecisionId']]]
                : $this->verifiedObject($s, $slug, true, $targetEnvelope);
            if ($job !== null && !$withdraw && $target['id'] !== $job['approvalId']) {
                throw new RuntimeException('BLOCKED_PHP_AUTOMATION_APPROVAL_REQUIRED', 409);
            }
            $cars = []; $ids = []; $scopes = []; $verified = [];
            $pendingNeighbors = []; $heldUrls = [];
            if ($job !== null) {
                foreach ($queue['cars'] as $key => $head) {
                    if ($key === $slug) continue;
                    $queued = $queue['jobs'][$head['job']] ?? [];
                    if (in_array($queued['status'] ?? '', ['pending', 'retry', 'blocked'], true)) $pendingNeighbors[$key] = $queued['kind'];
                }
                if ($pendingNeighbors) {
                    $currentUrls = isset($s['dynamicInventory']) ? ApprovedSitemapContinuity::currentUrls($s,
                        ApprovedDynamicInventoryAutomation::trustedOrigin($s, $this->context), $this->context) : [];
                    foreach ($pendingNeighbors as $key => $kind) {
                        $url = rtrim($this->context['site']['baseUrl'], '/') . '/cars/' . $key . '.html';
                        if (in_array($kind, ['hide', 'archive', 'delete', 'revoke'], true) && in_array($url, $currentUrls, true)) {
                            // Drop the unavailable car from lists now, but only its own job can remove its sitemap URL.
                            $heldUrls[] = $url;
                        } elseif ($kind === 'publish' && !in_array($url, $currentUrls, true)) {
                            $pendingNeighbors[$key] = 'not_yet_published';
                        }
                    }
                }
            }
            foreach (read_cars() as $car) {
                $key = (string) $car['slug'];
                if (($pendingNeighbors[$key] ?? null) === 'not_yet_published') continue;
                if (($withdraw && $key === $slug) || (!empty($queue['cars'][$key]['withdrawn'])
                    && !($job !== null && $job['kind'] === 'publish' && $key === $slug))) continue;
                if (!car_visible_in_public_rent_rk_showcase($car)) continue;
                if (!self::eligible($car)) throw new RuntimeException('BLOCKED_PUBLIC_CHANNEL_EVIDENCE_UNAVAILABLE', 409);
                if (!$refresh || $job !== null) {
                    if ($key === 'index') throw new RuntimeException('BLOCKED_PHP_APPLY_TARGET', 409);
                    // The shared output calculation uses verified public material, not the viewer's approval authority.
                    if ($job === null && !$carDryRun) self::car($key, true);
                }
                $effective = null;
                try {
                    $o = $key === $slug ? $target : $this->verifiedObject($s, $key, true, $effective);
                    if ($key === $slug) $effective = $targetEnvelope;
                } catch (Throwable $e) { throw new RuntimeException('BLOCKED_APPROVED_SET_INCOMPLETE', 409, $e); }
                self::assertCurrentParkCallback($o['material']['car'], $car);
                if ($o['material']['site'] !== $target['material']['site']) throw new RuntimeException('BLOCKED_APPROVED_SITE_VERSION_MISMATCH', 409);
                $published = $queue['cars'][$key]['published'] ?? [];
                $desired = $job !== null && $key === $slug ? $job['desired']
                    : (($published['approvalId'] ?? null) === $o['id'] ? $published['desired'] : []);
                $projection = $o['material']['car'];
                if (isset($desired['rates'])) {
                    $rates = $desired['rates']['patch'];
                    $preserved = ($published['approvalId'] ?? null) === $o['id']
                        && ($published['desired']['rates'] ?? null) === $desired['rates'];
                    if ($job !== null && $key === $slug && !$preserved && PhpPublicationAutomation::tariff($slug) !== $rates) {
                        throw new RuntimeException('BLOCKED_PHP_AUTOMATION_RATES_STALE', 409);
                    }
                    $oldPriceText = 'от ' . number_format($projection['price'], 0, '.', ' ') . ' р./сутки';
                    $newPriceText = 'от ' . number_format($rates['price'], 0, '.', ' ') . ' р./сутки';
                    if ($projection['hero']['priceText'] === $oldPriceText) $projection['hero']['priceText'] = $newPriceText;
                    if (($projection['specs']['Цена от'] ?? null) === $oldPriceText) $projection['specs']['Цена от'] = $newPriceText;
                    $projection['price'] = $rates['price']; $projection['deposit'] = $rates['deposit'];
                    if (isset($projection['related'])) $projection['related']['price'] = $rates['relatedPrice'];
                }
                if (isset($desired['photos'])) {
                    $gallery = $desired['photos']['patch']['gallery'];
                    if (count($gallery) !== count($projection['gallery']) || array_diff($gallery, $projection['gallery'])
                        || ($gallery[0] ?? '') !== $projection['image']) throw new RuntimeException('BLOCKED_PHP_AUTOMATION_GALLERY', 409);
                    $projection['gallery'] = $gallery;
                }
                $cars[] = $projection; $ids[] = $o['id']; $scopes[] = car_owner_scope_id($car);
                $verified[$key] = [$o, $effective];
            }
            if (!$withdraw && !in_array($target['id'], $ids, true)) throw new RuntimeException('BLOCKED_PUBLIC_CHANNEL_NOT_ENABLED', 409);
            $inventory = $this->context['inventory'];
            if (!is_string($inventory['decisionId'] ?? null) || $inventory['decisionId'] === '' || !is_array($inventory['dependencies'] ?? null)) throw new RuntimeException('BLOCKED_PUBLIC_INVENTORY_UNVERIFIED', 409);
            $site = $target['material']['site'];
            if (($inventory['siteDigest'] ?? '') !== self::digest($site)) throw new RuntimeException('BLOCKED_PUBLIC_INVENTORY_SITE_MISMATCH', 409);
            if (!in_array($mode, ['Full', 'Car'], true)) throw new RuntimeException('BLOCKED_PUBLIC_PLAN_MODE_INVALID', 409);
            $static = $this->staticPublication($inventory);
            if ($static === null && $mode === 'Full') throw new RuntimeException('BLOCKED_STATIC_PUBLIC_SOURCE_UNAVAILABLE', 409);
            $managed = $static === null ? [] : RentRkPublicStaticPlan::paths($static);
            if (isset($static['editorial'])) {
                RentRkApprovedEditorialV2::assertProjection($static['editorial'], $site, $static['routes']);
                foreach ($verified as [$o]) if ($o['decision']['siteDecisionId'] !== $this->context['siteDecisionId']) {
                    throw new RuntimeException('BLOCKED_APPROVED_SITE_VERSION_MISMATCH', 409);
                }
            }
            if ($static !== null && ($target['decision']['siteDecisionId'] !== $this->context['siteDecisionId']
                || array_diff($managed, $site['extraSitemapPaths']))) throw new RuntimeException('BLOCKED_STATIC_PUBLIC_URL_SCOPE', 409);
            foreach ($site['extraSitemapPaths'] as $urlPath) {
                $relative = ltrim($urlPath, '/');
                if (str_ends_with($relative, '/')) $relative .= 'index.html';
                if (!preg_match('~\A(?:pages|routes)/[a-z0-9-]+\.html\z~D', $relative)) throw new RuntimeException('BLOCKED_PUBLIC_INVENTORY_ADAPTER_REQUIRED', 409);
                if (in_array($urlPath, $managed, true) && !file_exists(PROJECT_ROOT . $relative) && !is_link(PROJECT_ROOT . $relative)) continue;
                $full = realpath(PROJECT_ROOT . $relative);
                $hash = $full && !is_link(PROJECT_ROOT . $relative) && is_file($full) ? hash_file('sha256', $full) : false;
                if (!is_string($hash) || (($inventory['publicFiles'][$relative] ?? null) !== $hash
                    && (!in_array($urlPath, $managed, true) || !ApprovedPhpPlanApply::ownsGenerated($relative, $hash)))) {
                    throw new RuntimeException('BLOCKED_PUBLIC_INVENTORY_OUTPUT_UNVERIFIED', 409);
                }
            }
            $now = time(); $audits = []; $expiries = [];
            $staticUrls = array_map(static fn(string $p): string => rtrim($site['baseUrl'], '/') . $p,
                array_merge(['/', '/cars/'], array_map(static fn(array $c): string => '/cars/' . $c['slug'] . '.html', $cars), $site['extraSitemapPaths']));
            $staticUrls = array_merge($staticUrls, $heldUrls);
            $carChange = $job !== null && ($withdraw || $job['kind'] === 'publish')
                ? ['action' => $withdraw ? 'withdraw' : 'publish', 'url' => rtrim($site['baseUrl'], '/') . '/cars/' . $slug . '.html']
                : null;
            $dynamic = ApprovedDynamicInventoryAutomation::prepare($s, $this->context, $staticUrls, $now, $carChange);
            if (!$refresh && $dynamic['audit'] !== null) throw new RuntimeException('BLOCKED_PHP_APPLY_INVENTORY_STALE', 409);
            $expectedUrls = array_merge($staticUrls, $dynamic['urls']);
            sort($expectedUrls, SORT_STRING);
            foreach ($verified as $key => [$object, $effective]) {
                $period = $effective['snapshot']['approval'];
                if ($period['keyId'] !== $this->context['keyId'] || $period['expiresAt'] <= $now) {
                    if (!$refresh) throw new RuntimeException('BLOCKED_PHP_APPLY_ATTESTATION_STALE', 409);
                    if ($object['material']['site'] !== $this->context['site'] || $object['decision']['siteDecisionId'] !== $this->context['siteDecisionId']) {
                        throw new RuntimeException('BLOCKED_APPROVED_SITE_VERSION_MISMATCH', 409);
                    }
                    [$effective, $audit] = $this->nextAttestation($effective, $now);
                    $s['objects'][$object['id']]['attestations'][] = $effective;
                    $audits[$key] = $audit + ['trigger' => 'approved_public_plan'];
                }
                $expiries[] = $effective['snapshot']['approval']['expiresAt'];
            }
            $expiries[] = $dynamic['expiresAt'];
            $snapshot = ['schemaVersion' => 1, 'approval' => ['issuer' => $this->context['issuer'], 'keyId' => $this->context['keyId'], 'audience' => 'rent-rk-core',
                'approvalId' => 'approved_set_' . self::digest($ids), 'revision' => $s['version'], 'issuedAt' => $now, 'expiresAt' => min($expiries),
                'scopeIds' => array_values(array_unique($scopes))], 'sourceVersions' => ['approvalSet' => self::digest($ids), 'inventory' => self::digest($inventory)], 'site' => $site, 'cars' => $cars];
            $snapshot['dynamicSitemapUrls'] = $dynamic['urls'];
            $snapshot['sourceVersions']['dynamicInventory'] = $dynamic['sha256'];
            if ($static !== null) {
                $snapshot['staticPublication'] = $static;
                $snapshot['sourceVersions']['staticPublication'] = self::digest($static);
                $snapshot['sourceVersions']['siteDecision'] = $this->context['siteDecisionId'];
            }
            $trust = array_intersect_key($snapshot['approval'], array_flip(['issuer', 'keyId', 'audience', 'approvalId', 'revision', 'scopeIds']));
            $trust['snapshotSha256'] = self::digest($snapshot); $trust['publicKeyBase64'] = $this->context['publicKeyBase64'];
            $plan = RentRkPublicRenderer::plan($this->envelope($snapshot), $trust, PROJECT_ROOT, $mode, $slug);
            if ($plan['status'] !== 'PLAN_ONLY') return $plan;
            foreach ($plan['outputs'] as &$output) {
                if ($output['path'] === 'sitemap.xml' && $output['beforeSha256'] !== $dynamic['beforeSha256']) {
                    throw new RuntimeException('BLOCKED_DYNAMIC_INVENTORY_SITEMAP_CHANGED_DURING_PLAN', 409);
                }
                if ($output['path'] === 'sitemap.xml' && $heldUrls) {
                    $bytes = rent_rk_public_render_sitemap_urls($expectedUrls);
                    $output['payloadBase64'] = base64_encode($bytes);
                    $output['sha256'] = hash('sha256', $bytes);
                }
            }
            unset($output);
            if (min($expiries) <= time()) throw new RuntimeException('BLOCKED_ATTESTATION_EXPIRED_DURING_PLAN', 409);
            if ($dynamic['audit'] !== null || $audits !== []) {
                $s['dynamicInventory'] = $dynamic['history'];
                $save = static function () use ($s, $audits, $dynamic): void {
                    self::saveAttestations($s, $audits);
                    if ($dynamic['audit'] !== null) audit_log('public_inventory.technical_attestation', 'sitemap', 'global',
                        'Обновлён технический инвентарь; витрина не изменена', $dynamic['audit']);
                };
                if ($job !== null) $save();
                else RentalReturnStore::transaction($save);
            }
            $plan['approvedObjectIds'] = $ids; $plan['inventoryDecisionId'] = $inventory['decisionId'];
            $plan['dynamicInventoryRevision'] = $dynamic['revision'];
            return $plan;
    }

    public function applyAutomationJob(array $job): array
    {
        $queue = PhpPublicationAutomation::store();
        PhpPublicationAutomation::assertJob($job, $queue);
        $slug = $job['slug'];
        $withdraw = in_array($job['kind'], ['hide', 'archive', 'delete', 'revoke'], true);
        $urls = [];
        $plan = $this->renderLocked($slug, $withdraw ? 'Full' : 'Car', true, $urls, $job);
        if (($plan['status'] ?? '') !== 'PLAN_ONLY') throw new RuntimeException('BLOCKED_PHP_AUTOMATION_PLAN', 409);
        $action = $withdraw ? 'withdraw' : ($job['kind'] === 'publish' ? 'publish' : 'apply');
        $state = ApprovedPhpPlanApply::state();
        if ($withdraw) {
            $path = 'cars/' . $slug . '.html';
            $before = RentalReturnStore::publicationOutputBytes($path);
            if ($before === null) throw new RuntimeException('BLOCKED_PHP_AUTOMATION_NO_PREVIOUS_PAGE', 409);
            $title = $job['kind'] === 'delete' ? 'Автомобиль больше не представлен в прокате' : 'Автомобиль сейчас недоступен';
            $bytes = '<!doctype html><html lang="ru"><meta charset="utf-8"><title>' . $title
                . '</title><main><h1>' . $title . '</h1><a href="/cars/">Каталог автомобилей</a></main></html>';
            $plan['outputs'] = array_values(array_filter($plan['outputs'], static fn(array $row): bool =>
                in_array($row['path'], ['index.html', 'cars/index.html', 'sitemap.xml'], true) || RentRkPublicStaticPlan::isFleetPage($row['path'])));
            $plan['outputs'][] = ['path' => $path, 'payloadBase64' => base64_encode($bytes), 'sha256' => hash('sha256', $bytes),
                'beforeSha256' => hash('sha256', $before)];
            $plan['mode'] = 'Car';
        }
        $actor = ['job' => $job['id'], 'generation' => $job['generation'], 'actor' => $job['actor'], 'scope' => $job['scope']];
        $ticket = ApprovedPhpPlanApply::issue($plan, $plan['approval']['expiresAt'], $state, $actor, $slug, 'Car', $this->context);
        $p = ApprovedPhpPlanApply::verify($plan, $ticket, $actor, $slug, 'Car', $this->context);
        $outputs = ApprovedPhpPlanApply::checkOutputs($plan, $state, $slug, 'Car');
        $store = self::store();
        $origin = ApprovedDynamicInventoryAutomation::trustedOrigin($store, $this->context);
        return ApprovedPhpPlanApply::stage($p, $state, $outputs, $store, $origin, $this->context, $urls, $action,
            rtrim($this->context['site']['baseUrl'], '/') . '/cars/' . $slug . '.html');
    }

    private static function carDryRunTarget(string $slug): array
    {
        if (!has_permission('cars.edit') || (!has_permission('cars.publish') && !has_permission('content.publish.single_page'))) {
            throw new RuntimeException('BLOCKED_PHP_CAR_PREVIEW_ACCESS', 403);
        }
        $car = find_car($slug);
        if (!$car || !car_belongs_to_current_scope($car)) throw new RuntimeException('BLOCKED_PHP_CAR_PREVIEW_ACCESS', 403);
        return $car;
    }

    public function carDryRun(string $slug): array
    {
        if (RentalReturnStore::active()) throw new LogicException('BLOCKED_PHP_PREVIEW_TRANSACTION_ACTIVE');
        RentalReturnStore::enter(true);
        self::carDryRunTarget($slug);
        PhpPublicationCutover::generation(false);
        PhpPublicationCutover::assertNoPendingActions();
        $plan = $this->renderLocked($slug, 'Car', false, carDryRun: true);
        if (($plan['status'] ?? '') !== 'PLAN_ONLY') throw new RuntimeException('BLOCKED_PHP_APPLY_PLAN', 409);
        ApprovedPhpPlanApply::checkOutputs($plan, ApprovedPhpPlanApply::state(), $slug, 'Car');
        self::carDryRunTarget($slug);
        return ['presentationLimits' => $plan['presentationLimits'], 'items' => array_map(static function (array $o): array {
            [$type, $id] = ApprovedPhpPlanApply::entity($o['path']);
            return ['path' => $o['path'], 'status' => $o['beforeSha256'] === $o['sha256'] ? 'unchanged' : 'would-write',
                'beforeSha256' => $o['beforeSha256'], 'afterSha256' => $o['sha256'], 'entityType' => $type, 'entityId' => $id];
        }, $plan['outputs'])];
    }

    public function cutoverPreview(string $slug, string $mode, bool $prepareApply): array
    {
        if (RentalReturnStore::active()) throw new LogicException('BLOCKED_PHP_APPLY_REQUIRES_OWN_TRANSACTION');
        RentalReturnStore::enter(true);
        PhpPublicationCutover::generation($prepareApply);
        PhpPublicationCutover::assertNoPendingActions();
        ApprovedPhpPlanApply::assertGlobalAccess();
        self::car($slug, true);
        $plan = $this->renderLocked($slug, $mode, false);
        if (($plan['status'] ?? '') !== 'PLAN_ONLY') throw new RuntimeException('BLOCKED_PHP_APPLY_PLAN', 409);
        ApprovedPhpPlanApply::checkOutputs($plan, ApprovedPhpPlanApply::state(), $slug, $mode);
        return $plan;
    }

    private static function applyActor(): array
    {
        return self::actor() + (PhpPublicationCutover::selected() ? ['cutoverGeneration' => PhpPublicationCutover::generation()] : []);
    }

    /** Separate trusted-server entry; not called by the existing plan POST. */
    public function preparePhpApply(string $slug, string $mode, array $plan): array
    {
        if (RentalReturnStore::active()) throw new LogicException('BLOCKED_PHP_APPLY_REQUIRES_OWN_TRANSACTION');
        RentalReturnStore::enter();
        PhpPublicationCutover::assertApply();
        PhpPublicationCutover::assertNoPendingActions();
        ApprovedPhpPlanApply::assertGlobalAccess();
        self::car($slug, true);
        $fresh = $this->renderLocked($slug, $mode, false);
        if (($fresh['status'] ?? '') !== 'PLAN_ONLY' || ApprovedPhpPlanApply::binding($plan) !== ApprovedPhpPlanApply::binding($fresh)) {
            throw new RuntimeException('BLOCKED_PHP_APPLY_STALE', 409);
        }
        $state = ApprovedPhpPlanApply::state();
        ApprovedPhpPlanApply::checkOutputs($fresh, $state, $slug, $mode);
        return ['plan' => $fresh, 'ticket' => ApprovedPhpPlanApply::issue(
            $fresh, $fresh['approval']['expiresAt'], $state, self::applyActor(), $slug, $mode, $this->context)];
    }

    /** The host must authenticate the actor and collect explicit confirmation. */
    public function applyPhpPlan(string $slug, string $mode, array $plan, array $ticket, bool $confirmed): array
    {
        if (!$confirmed) throw new RuntimeException('BLOCKED_PHP_APPLY_CONFIRMATION_REQUIRED', 403);
        if (RentalReturnStore::active()) throw new LogicException('BLOCKED_PHP_APPLY_REQUIRES_OWN_TRANSACTION');
        return RentalReturnStore::transaction(function () use ($slug, $mode, $plan, $ticket): array {
            PhpPublicationCutover::assertApply();
            if (PhpPublicationCutover::selected() && ($ticket['payload']['actor']['cutoverGeneration'] ?? null) !== PhpPublicationCutover::generation()) {
                throw new RuntimeException('BLOCKED_PHP_CUTOVER_GENERATION', 409);
            }
            ApprovedPhpPlanApply::assertGlobalAccess();
            self::car($slug, true);
            $p = ApprovedPhpPlanApply::verify($plan, $ticket, self::applyActor(), $slug, $mode, $this->context);
            $state = ApprovedPhpPlanApply::state();
            foreach ($state['runs'] as $run) {
                if (($run['id'] ?? null) !== $p['id']) continue;
                if (($run['generator'] ?? null) !== ApprovedPhpPlanApply::GENERATOR
                    || ($run['planDigest'] ?? null) !== $p['planDigest'] || ($run['status'] ?? null) !== 'completed') {
                    throw new RuntimeException('BLOCKED_PHP_APPLY_RUN_CONFLICT', 409);
                }
                return ['status' => 'ALREADY_APPLIED', 'id' => $p['id'], 'wrote' => false];
            }
            PhpPublicationCutover::assertNoPendingActions();
            if ($p['buildStateSha256'] !== self::digest($state)) throw new RuntimeException('BLOCKED_PHP_APPLY_STALE_BUILD_STATE', 409);
            $urls = [];
            $fresh = $this->renderLocked($slug, $mode, false, $urls);
            if (($fresh['status'] ?? '') !== 'PLAN_ONLY' || ApprovedPhpPlanApply::binding($plan) !== ApprovedPhpPlanApply::binding($fresh)) {
                throw new RuntimeException('BLOCKED_PHP_APPLY_STALE', 409);
            }
            $outputs = ApprovedPhpPlanApply::checkOutputs($plan, $state, $slug, $mode);
            $store = self::store();
            $origin = ApprovedDynamicInventoryAutomation::trustedOrigin($store, $this->context);
            return ApprovedPhpPlanApply::stage($p, $state, $outputs, $store, $origin, $this->context, $urls);
        });
    }
}
