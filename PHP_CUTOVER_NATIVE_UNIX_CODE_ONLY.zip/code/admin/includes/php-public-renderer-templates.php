<?php
declare(strict_types=1);

function rent_rk_public_escape(string $text): string
{
    return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function rent_rk_public_layout(array $snapshot, string $title, string $description, string $path, string $body, ?array $car = null): string
{
    $e = 'rent_rk_public_escape';
    $site = $snapshot['site'];
    $displayPhone = $snapshot['staticPublication']['editorial']['contacts']['phone'] ?? $site['phone'];
    $prefix = $path === '/' ? '' : '../';
    $canonical = rtrim($site['baseUrl'], '/') . $path;
    $links = '';
    foreach (['cars/' => 'Автомобили', 'pages/conditions.html' => 'Условия', 'pages/faq.html' => 'FAQ', 'routes/' => 'Маршруты', 'pages/contacts.html' => 'Контакты'] as $url => $label) {
        $links .= '<a href="' . $e($prefix . $url) . '">' . $e($label) . '</a>';
    }
    $schema = json_encode(['@context' => 'https://schema.org', '@type' => 'AutoRental', 'name' => $site['name'],
        'url' => $site['baseUrl'], 'telephone' => $site['phone'], 'address' => $site['address']], JSON_THROW_ON_ERROR | JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
    $callback = ['can_show' => $site['callback']['enabled'], 'source_page_type' => str_starts_with($path, '/cars/') && $path !== '/cars/' ? 'car_page' : 'main_showcase',
        'callback_mode' => $site['callback']['enabled'] ? 'rent_rk_own' : 'disabled', 'delay_seconds' => $site['callback']['delaySeconds'],
        'repeat_policy' => $site['callback']['repeatPolicy'], 'api_url' => $prefix . 'api/callback.php', 'texts' => $site['callback']['texts']];
    if ($car !== null) {
        if ($car['scopeId'] !== 'rent_rk') {
            $park = $car['parkCallback'];
            $callback['can_show'] = $park['enabled'];
            $callback['callback_mode'] = $park['mode'];
            $callback['delay_seconds'] = $park['delaySeconds'];
            $callback['repeat_policy'] = $park['repeatPolicy'];
            $callback['texts'] = $park['texts'];
        }
        $callback['car_id'] = $car['slug']; $callback['car_title'] = $car['name'];
        if ($car['scopeId'] !== 'rent_rk') $callback['use_approved_park_timing'] = true;
    }
    $callbackJson = json_encode($callback, JSON_THROW_ON_ERROR | JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
    $ogImage = $snapshot['cars'][0]['image'] ?? null;
    foreach ($snapshot['cars'] as $car) { if ($path === '/cars/' . $car['slug'] . '.html') { $ogImage = $car['image']; } }
    $og = $ogImage === null ? '' : '<meta property="og:image" content="' . $e(rtrim($site['baseUrl'], '/') . '/' . $ogImage) . '">';
    $breadcrumbs = '';
    if ($path !== '/') {
        $base = rtrim($site['baseUrl'], '/');
        $parents = ['/'=> 'Главная'];
        foreach (['/cars/' => 'Автомобили', '/routes/' => 'Маршруты'] as $parent => $label) {
            if ($parent !== $path && str_starts_with($path, $parent)) $parents[$parent] = $label;
        }
        $crumbLinks = '';
        foreach ($parents as $parent => $label) $crumbLinks .= '<a href="' . $e($prefix . ltrim($parent, '/') . 'index.html') . '">' . $e($label) . '</a> ';
        $items = [];
        foreach ($parents + [$path => $title] as $url => $label) $items[] = ['@type' => 'ListItem', 'position' => count($items) + 1, 'name' => $label, 'item' => $base . $url];
        $breadcrumbs = '<nav aria-label="Хлебные крошки">' . $crumbLinks . '<span aria-current="page">' . $e($title) . '</span></nav><script type="application/ld+json">'
            . json_encode(['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $items], JSON_THROW_ON_ERROR | JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) . '</script>';
    }
    return '<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>' . $e($title) . '</title><meta name="description" content="' . $e($description) . '"><link rel="canonical" href="' . $e($canonical) . '">'
        . '<meta property="og:type" content="website"><meta property="og:site_name" content="' . $e($site['name']) . '"><meta property="og:title" content="' . $e($title) . '"><meta property="og:description" content="' . $e($description) . '"><meta property="og:url" content="' . $e($canonical) . '"><meta name="twitter:card" content="summary_large_image">'
        . $og . '<link rel="stylesheet" href="' . $prefix . 'assets/css/main.css"><style>[data-car-card][hidden],[data-open-availability][hidden],[data-editorial-empty-state],[data-editorial-empty-state][hidden]+[data-approved-editorial-tail]{display:none}.catalog-filters fieldset{min-inline-size:0;margin:0}.catalog-filters label{display:block}</style><script type="application/ld+json">' . $schema . '</script></head>'
        . '<body><header class="site-header"><a class="brand" href="' . $prefix . 'index.html">' . $e($site['name']) . '</a><nav>' . $links . '</nav><a href="tel:' . $e($site['phone']) . '">' . $e($displayPhone) . '</a></header>' . $breadcrumbs . '<main><div class="container">' . $body . '</div></main>'
        . '<footer class="site-footer"><nav>' . $links . '</nav><p>' . $e($site['address']) . '</p><a href="tel:' . $e($site['phone']) . '">' . $e($displayPhone) . '</a><a href="' . $e($site['telegram']) . '">Telegram</a></footer><script type="application/json" id="rent-rk-callback-context">' . $callbackJson . '</script>'
        . '<script src="' . $prefix . 'assets/js/analytics-tracker.js" defer></script><script src="' . $prefix . 'assets/js/main.js" defer></script></body></html>';
}

function rent_rk_public_card(array $car, bool $catalog, ?string $approvedDetail = null): string
{
    $e = 'rent_rk_public_escape';
    $href = ($catalog ? '' : 'cars/') . $car['slug'] . '.html';
    $image = ($catalog ? '../' : '') . $car['image'];
    $specs = '';
    foreach ($car['specs'] as $label => $value) { $specs .= '<li>' . $e($label) . ': ' . $e($value) . '</li>'; }
    foreach (array_merge($car['features'], $car['conditions']) as $text) { $specs .= '<li>' . $e($text) . '</li>'; }
    $attrs = '';
    foreach (['type' => 'type', 'seats' => 'seats', 'drive' => 'drive', 'year' => 'year', 'body-type' => 'bodyType', 'fuel-type' => 'fuelType'] as $attribute => $field) { $attrs .= ' data-' . $attribute . '="' . $e((string) $car[$field]) . '"'; }
    $attrs .= ' data-equipment="' . $e(implode(',', $car['equipment'])) . '"';
    return '<article class="card car-card" data-car-card data-slug="' . $e($car['slug']) . '" data-car-slug="' . $e($car['slug']) . '" data-contour-slug="' . $e($car['scopeId']) . '" data-price="' . $car['price'] . '"' . $attrs . '>'
        . '<a class="car-card__image" href="' . $e($href) . '"><img src="' . $e($image) . '" alt="' . $e($car['name']) . '" loading="lazy"></a><h3><a href="' . $e($href) . '">' . $e($car['name']) . '</a></h3>'
        . '<p class="price">' . $car['price'] . ' ₽ / сутки</p><p>Залог: ' . $car['deposit'] . ' ₽</p><ul>' . $specs . '</ul><p>' . $e($car['description']) . '</p>'
        . '<p data-car-availability-status hidden></p><a data-car-detail-link' . ($approvedDetail === null ? '' : ' data-approved-editorial-button')
        . ' href="' . $e($href) . '">' . $e($approvedDetail ?? 'Подробнее') . '</a><a data-car-primary-action href="' . $e($href) . '#booking">Забронировать</a></article>';
}

function rent_rk_public_render_listing(array $snapshot, bool $catalog): string
{
    $item = RentRkApprovedEditorialV2::item($snapshot, $catalog ? 'cars/index.html' : 'index.html');
    $labels = $catalog && $item !== null ? explode("\n", $item['buttons']) : null;
    if ($labels !== null && count($labels) !== 3) throw new RuntimeException('BLOCKED_APPROVED_EDITORIAL_BUTTON_MISMATCH');
    $cards = '';
    foreach ($snapshot['cars'] as $car) { $cards .= rent_rk_public_card($car, $catalog, $labels[1] ?? null); }
    $title = $item['title'] ?? ($catalog ? 'Автомобили в аренду' : $snapshot['site']['name']);
    $filters = '';
    if ($catalog) {
        foreach (['type' => 'Класс', 'seats' => 'Места', 'drive' => 'Привод', 'price' => 'Цена за сутки'] as $name => $label) {
            $options = $name === 'price' ? ['under-5000' => 'До 5 000 ₽', '5000-8000' => '5 000–8 000 ₽', 'over-8000' => 'От 8 000 ₽'] : [];
            if ($name !== 'price') foreach ($snapshot['cars'] as $car) {
                $value = trim((string) $car[$name]);
                if ($value !== '') $options[mb_strtolower($value)] = $value;
            }
            if (!$options) continue;
            $filters .= '<fieldset><legend>' . rent_rk_public_escape($label) . '</legend>';
            foreach ($options as $value => $text) { $filters .= '<label><input type="' . ($name === 'price' ? 'radio' : 'checkbox') . '" name="' . $name . '" value="' . rent_rk_public_escape((string) $value) . '">' . rent_rk_public_escape($text) . '</label>'; }
            $filters .= '</fieldset>';
        }
        $filters = '<form class="catalog-filters" data-catalog-filters>' . $filters . '<button type="reset"'
            . ($labels === null ? '' : ' data-approved-editorial-button') . '>' . rent_rk_public_escape($labels[0] ?? 'Сбросить') . '</button></form>';
    }
    $empty = '<p data-catalog-empty hidden>Автомобили не найдены</p>';
    $actions = '';
    if ($item === null) {
        $body = '<section class="hero compact"><h1>' . rent_rk_public_escape($title) . '</h1></section>';
    } elseif ($catalog) {
        $split = strrpos($item['text'], "\n## ");
        if ($split === false) throw new RuntimeException('BLOCKED_APPROVED_EDITORIAL_CATALOG_STRUCTURE');
        $body = RentRkApprovedEditorialV2::article($item, rtrim(substr($item['text'], 0, $split)));
        $empty = '<span data-catalog-empty data-editorial-empty-state aria-hidden="true" hidden></span><div data-approved-editorial-tail role="status">'
            . RentRkApprovedEditorialV2::markdown(substr($item['text'], $split + 1)) . '</div>';
        $actions = '<p><a class="btn secondary" data-approved-editorial-button href="../pages/contacts.html">' . rent_rk_public_escape($labels[2]) . '</a></p>';
    } else {
        $body = RentRkApprovedEditorialV2::article($item);
        $body .= RentRkApprovedEditorialV2::links($item, ['cars/index.html', 'tel:' . $snapshot['site']['phone'], $snapshot['site']['telegram']]);
    }
    $body .= '<form data-availability-search ' . ($catalog ? 'data-catalog-availability data-api="../api/available-cars.php"' : 'data-home-availability-search') . ' action="' . ($catalog ? 'index.html' : 'cars/index.html') . '" method="get">'
        . '<label>Получение <input type="date" name="date_from" required></label><label>Возврат <input type="date" name="date_to" required></label><label>Место подачи <input name="pickup"></label><button type="submit">Проверить</button>' . ($catalog ? '<button type="button" data-availability-reset>Сбросить</button>' : '') . '<p data-availability-search-message aria-live="polite"></p></form>'
        . $filters . '<section data-catalog-grid class="grid cards">' . $cards . '</section>' . $empty . $actions;
    return rent_rk_public_layout($snapshot, $title, $item['description'] ?? 'Аренда автомобилей', $catalog ? '/cars/' : '/', $body);
}

function rent_rk_public_related_facts(array $car, ?int $price): array
{
    $clean = static function ($value): string {
        if (!is_scalar($value)) return '';
        $text = trim(preg_replace('/\s+/u', ' ', (string) $value) ?? '');
        return in_array(mb_strtolower(trim($text, '.,;:')), ['уточняется', '-', '—', 'null'], true) ? '' : $text;
    };
    $custom = $car['cardBadgesCustom'] ?? [];
    if (is_string($custom)) $custom = preg_split('/\r?\n|,/', $custom);
    $badges = [$clean($car['cardBadge'] ?? '')];
    if (is_array($custom)) $badges = array_merge($badges, array_slice(array_values(array_unique(array_filter(array_map($clean, $custom)))), 0, 3));
    $class = mb_strtolower((string) ($car['class'] ?? ''));
    if (!empty($car['hourlyAvailable'])) $badges[] = 'Почасовая аренда';
    if (str_contains($class, 'кабриолет')) $badges[] = 'Кабриолет';
    if ((int) ($car['seats'] ?? 0) >= 7 || str_contains($class, '7')) $badges[] = '7 мест';
    if (str_contains(mb_strtolower((string) ($car['drive'] ?? '')), 'полн')) $badges[] = 'Полный привод';
    return ['price' => $price, 'badges' => array_slice(array_values(array_unique(array_filter($badges))), 0, 3)];
}

function rent_rk_public_render_related(array $fleet, array $car): string
{
    // A pre-existing approval without the ranking projection cannot attest a complete ranking.
    foreach ($fleet as $entry) if (!isset($entry['related'])) return '';
    $class = static function (array $entry): string {
        $type = mb_strtolower(trim(preg_replace('/\s+/u', ' ', $entry['type']) ?? ''));
        foreach (['кабриолет' => 'кабриолет', 'кроссовер|suv' => 'кроссовер', 'бизнес' => 'бизнес-седан',
            'седан' => 'седан', 'компакт|хэтч' => 'компакт'] as $pattern => $key) {
            if (preg_match('/' . $pattern . '/u', $type)) return $key;
        }
        return in_array(trim($type, '.,;:'), ['уточняется', '-', '—', 'null'], true) ? '' : $type;
    };
    $category = $class($car); $price = $car['related']['price'];
    $badges = array_map('mb_strtolower', $car['related']['badges']);
    $ranking = [];
    foreach ($fleet as $entry) {
        if ($entry['slug'] === $car['slug']) continue;
        $rankPrice = $entry['related']['price'];
        $ranking[] = ['car' => $entry, 'rank' => [$class($entry) === $category ? 0 : 1,
            $price === null || $rankPrice === null ? 999999999 : abs($price - $rankPrice),
            abs($car['seats'] - $entry['seats']), -count(array_intersect(array_map('mb_strtolower', $entry['related']['badges']), $badges))]];
    }
    if (!$ranking) return '';
    $collator = class_exists('Collator') ? new Collator('ru_RU') : null;
    usort($ranking, static function (array $a, array $b) use ($collator): int {
        $rank = $a['rank'] <=> $b['rank'];
        if ($rank !== 0) return $rank;
        $left = mb_strtolower($a['car']['name']); $right = mb_strtolower($b['car']['name']);
        return $collator ? ((int) $collator->compare($left, $right)) : strcmp($left, $right);
    });
    $e = 'rent_rk_public_escape';
    $title = $ranking[0]['rank'][0] === 0 ? 'Похожие автомобили' : 'Другие автомобили в парке';
    $html = '<section id="related-cars" class="section soft"><h2>' . $title . '</h2><div class="carousel-actions">'
        . '<button class="icon-btn" type="button" data-carousel-prev aria-label="Предыдущие автомобили">‹</button>'
        . '<button class="icon-btn" type="button" data-carousel-next aria-label="Следующие автомобили">›</button>'
        . '<a href="../cars/index.html">Все автомобили</a></div><div class="related-carousel" data-carousel tabindex="0" aria-label="' . $title . '">';
    foreach (array_slice($ranking, 0, 6) as $entry) {
        $c = $entry['car']; $href = $e($c['slug']) . '.html';
        $html .= '<article class="card car-card related-car-card"><a class="related-car-card__media" href="' . $href . '"><img class="related-car-card__image" loading="lazy" src="../'
            . $e($c['image']) . '" alt="' . $e($c['name']) . '"></a><div class="card-body"><h3><a href="' . $href . '">' . $e($c['name'])
            . '</a></h3><p class="price">' . $c['price'] . ' ₽ / сутки</p><p>' . $e($c['type']) . ' · ' . $c['seats'] . '</p></div></article>';
    }
    return $html . '</div></section>';
}

function rent_rk_public_render_availability(string $slug): string
{
    $id = 'availability-calendar-' . $slug;
    return '<section class="car-detail-availability" data-availability data-api="../api/availability.php?car=' . $slug . '">'
        . '<h2>Календарь занятости</h2><p data-availability-empty role="status">Проверяем занятость.</p><div data-availability-list></div>'
        . '<button class="btn secondary" type="button" data-open-availability aria-controls="' . $id . '" hidden>Открыть календарь</button></section>'
        . '<section class="availability-calendar-section" id="' . $id . '" data-availability-panel hidden><div class="availability-dialog">'
        . '<div class="availability-dialog-head"><p>Доступность подтвердит менеджер.</p><button class="btn secondary" type="button" data-close-availability>Свернуть календарь</button></div>'
        . '<div class="availability-modal-controls"><button class="icon-btn" type="button" data-availability-prev aria-label="Предыдущий месяц">‹</button>'
        . '<strong data-availability-month></strong><button class="icon-btn" type="button" data-availability-next aria-label="Следующий месяц">›</button></div>'
        . '<div class="availability-calendar-grid" data-availability-calendar></div></div></section>';
}

function rent_rk_public_render_detail(array $snapshot, array $car): string
{
    $e = 'rent_rk_public_escape';
    $specs = '';
    foreach ($car['specs'] as $label => $value) { $specs .= '<dt>' . $e($label) . '</dt><dd>' . $e($value) . '</dd>'; }
    $gallery = '';
    foreach (array_unique(array_merge([$car['image']], $car['gallery'])) as $image) {
        $gallery .= '<img data-gallery="car-gallery" data-full="../' . $e($image) . '" src="../' . $e($image) . '" alt="' . $e($car['name']) . '" tabindex="0" role="button" loading="lazy">';
    }
    $hero = $car['hero'];
    $body = '<section class="hero compact car-hero" data-car-detail data-car-slug="' . $e($car['slug']) . '" data-contour-slug="' . $e($car['scopeId']) . '"><p class="eyebrow">' . $e($hero['eyebrow']) . '</p><h1>' . $e($hero['title']) . '</h1><p class="lead">' . $e($hero['subtitle']) . '</p><p class="car-hero-price">' . $e($hero['priceText']) . '</p><p>Залог: ' . $car['deposit'] . ' ₽</p><div data-promo-hero-slot hidden></div><button data-open-booking aria-controls="booking">' . $e($hero['primaryCta']) . '</button><a href="' . $e($snapshot['site']['telegram']) . '">' . $e($hero['secondaryCta']) . '</a><p>' . $e($car['description']) . '</p></section>'
        . '<div data-quick-booking data-api="../api/available-cars.php" data-slug="' . $e($car['slug']) . '" data-booking-target="booking"><form data-quick-booking-form><input type="hidden" name="start_date"><input type="hidden" name="end_date"><div class="date-range-picker" data-date-range-picker data-date-range-start-label="Получение"><div class="date-range-picker__head"><button class="date-range-picker__nav" type="button" data-date-range-prev aria-label="Предыдущий месяц">&lt;</button><strong data-date-range-month></strong><button class="date-range-picker__nav" type="button" data-date-range-next aria-label="Следующий месяц">&gt;</button></div><p class="date-range-picker__summary" data-date-range-summary></p><div class="date-range-picker__grid" data-date-range-grid></div></div><label>Получение <input type="time" name="start_time"></label><label>Возврат <input type="time" name="end_time"></label><button type="submit">Продолжить бронирование</button><p data-quick-booking-message aria-live="polite"></p></form></div>'
        . '<section class="car-gallery">' . $gallery . '</section><dl>' . $specs . '</dl>' . rent_rk_public_render_availability($e($car['slug']))
        . '<section class="booking-section" id="booking" data-booking-section hidden><form data-booking-form action="../api/request.php" method="post">'
        . '<input type="hidden" name="car_slug" value="' . $e($car['slug']) . '"><input type="hidden" name="car_name" value="' . $e($car['name']) . '">'
        . '<input type="hidden" name="partner_slug" data-partner-field><input type="hidden" name="partner_agent_slug" data-partner-agent-field><input name="website" tabindex="-1" autocomplete="off" hidden>'
        . '<label>Имя<input name="name" autocomplete="name"></label><label>Телефон<input name="phone" autocomplete="tel" required></label>'
        . '<label>Начало<input name="start_date" type="date"><input name="start_time" type="time"></label><label>Возврат<input name="end_date" type="date"><input name="end_time" type="time"></label>'
        . '<div data-price-calculator data-api="../api/rates.php?car=' . $e($car['slug']) . '"><span data-price-total></span><span data-price-details></span></div><input name="pickup_place"><input name="return_place"><textarea name="message"></textarea>'
        . '<label><input type="checkbox" name="consent" value="1" required>Согласие на обработку данных</label><button type="submit">Отправить</button><p data-form-message aria-live="polite"></p></form><div data-booking-success hidden></div></section>';
    foreach ($car['content'] as $section) { $body .= '<section><h2>' . $e($section['heading']) . '</h2><p>' . $e($section['text']) . '</p></section>'; }
    foreach ($car['faq'] as $faq) { $body .= '<details><summary>' . $e($faq['question']) . '</summary><p>' . $e($faq['answer']) . '</p></details>'; }
    foreach (['features', 'conditions'] as $list) { $body .= '<ul>'; foreach ($car[$list] as $text) { $body .= '<li>' . $e($text) . '</li>'; } $body .= '</ul>'; }
    $schema = ['@context' => 'https://schema.org', '@type' => 'Product', 'name' => $car['name'], 'image' => rtrim($snapshot['site']['baseUrl'], '/') . '/' . $car['image'], 'description' => $car['description'],
        'brand' => ['@type' => 'Brand', 'name' => $car['brand']], 'model' => $car['model'], 'category' => $car['type'],
        'additionalProperty' => array_map(static fn(string $label, string $value): array => ['@type' => 'PropertyValue', 'name' => $label, 'value' => $value], array_keys($car['specs']), array_values($car['specs'])),
        'offers' => ['@type' => 'Offer', 'priceCurrency' => 'RUB', 'price' => $car['price'], 'url' => rtrim($snapshot['site']['baseUrl'], '/') . '/cars/' . $car['slug'] . '.html']];
    $body .= '<script type="application/ld+json">' . json_encode($schema, JSON_THROW_ON_ERROR | JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) . '</script>';
    if ($car['faq']) { $body .= '<script type="application/ld+json">' . json_encode(['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map(static fn(array $f): array => ['@type' => 'Question', 'name' => $f['question'], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f['answer']]], $car['faq'])], JSON_THROW_ON_ERROR | JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) . '</script>'; }
    $body .= rent_rk_public_render_related($snapshot['cars'], $car)
        . '<div class="mobile-sticky-cta" aria-label="Быстрые действия по аренде"><div class="mobile-sticky-cta__price"><span>Цена</span><strong>'
        . $car['price'] . ' ₽ / сутки</strong></div><button class="btn" type="button" data-open-booking aria-controls="booking">Забронировать</button>'
        . '<a class="btn secondary" href="' . $e($snapshot['site']['telegram']) . '">Telegram</a><a class="btn secondary" href="tel:'
        . $e($snapshot['site']['phone']) . '">Позвонить</a></div>';
    return rent_rk_public_layout($snapshot, $car['seo']['title'], $car['seo']['description'], '/cars/' . $car['slug'] . '.html', $body, $car);
}

function rent_rk_public_render_sitemap(array $snapshot): string
{
    $paths = ['/', '/cars/'];
    foreach ($snapshot['cars'] as $car) { $paths[] = '/cars/' . $car['slug'] . '.html'; }
    $urls = array_map(static fn(string $path): string => rtrim($snapshot['site']['baseUrl'], '/') . $path,
        array_unique(array_merge($paths, $snapshot['site']['extraSitemapPaths'])));
    return rent_rk_public_render_sitemap_urls(array_merge($urls, $snapshot['dynamicSitemapUrls'] ?? []));
}

function rent_rk_public_render_sitemap_urls(array $urls): string
{
    sort($urls, SORT_STRING);
    $xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    foreach ($urls as $url) { $xml .= '<url><loc>' . htmlspecialchars($url, ENT_XML1 | ENT_QUOTES, 'UTF-8') . '</loc></url>'; }
    return $xml . '</urlset>';
}
