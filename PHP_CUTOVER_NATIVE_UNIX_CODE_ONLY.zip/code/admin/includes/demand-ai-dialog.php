<?php

declare(strict_types=1);

function demand_ai_dialog_allowed_intents(): array
{
    return [
        'explain_current_screen',
        'suggest_next_step',
        'collect_keyword_ideas',
        'build_keyword_plan',
        'summarize_import_preview',
        'clean_irrelevant_queries',
        'prioritize_launch_plan',
        'build_city_keyword_map',
        'build_region_keyword_map',
        'create_seo_action_plan',
        'create_content_briefs',
        'create_safe_landing_drafts',
        'create_faq_plan',
        'create_car_card_hints',
        'improve_landing_draft',
        'suggest_internal_links',
        'regenerate_human_copy',
        'check_false_promises',
        'prepare_publication_checklist',
    ];
}

function demand_ai_dialog_intent_label(string $intent): string
{
    return [
        'explain_current_screen' => 'Объяснить текущий экран',
        'suggest_next_step' => 'Предложить следующий шаг',
        'collect_keyword_ideas' => 'Собрать идеи запросов',
        'build_keyword_plan' => 'Собрать план запросов',
        'summarize_import_preview' => 'Разобрать импорт',
        'clean_irrelevant_queries' => 'Отделить мусорные запросы',
        'prioritize_launch_plan' => 'Приоритизировать план страниц',
        'build_city_keyword_map' => 'Собрать запросы по городам',
        'build_region_keyword_map' => 'Собрать региональную карту запросов',
        'create_seo_action_plan' => 'Сделать SEO-план действий',
        'create_content_briefs' => 'Подготовить ТЗ',
        'create_safe_landing_drafts' => 'Подготовить безопасные черновики',
        'create_faq_plan' => 'Подготовить FAQ',
        'create_car_card_hints' => 'Подготовить подсказки для авто',
        'improve_landing_draft' => 'Улучшить черновик',
        'suggest_internal_links' => 'Подобрать внутренние ссылки',
        'regenerate_human_copy' => 'Оживить текст черновика',
        'check_false_promises' => 'Проверить рискованные обещания',
        'prepare_publication_checklist' => 'Проверить перед публикацией',
    ][$intent] ?? $intent;
}

function demand_ai_dialog_quick_prompts(): array
{
    return [
        ['label' => 'Объясни этот экран', 'message' => 'Объясни этот экран простым языком: что здесь важно и что можно нажимать безопасно.'],
        ['label' => 'Что делать дальше?', 'message' => 'Посмотри текущий раздел спроса и предложи один следующий безопасный шаг.'],
        ['label' => 'Собрать запросы по теме', 'message' => 'Собери запросы по теме аренды авто по городам Крыма, предложи действия и расставь их по приоритету.'],
        ['label' => 'Собрать запросы по городам Крыма', 'message' => 'Собери запросы по теме аренды авто по городам Крыма, после этого предложи какие действия можно сделать и расположи их в порядке приоритета.'],
        ['label' => 'Разобрать импорт', 'message' => 'Объясни результат загрузки фраз: что полезно, что рискованно и что нельзя использовать.'],
        ['label' => 'Приоритизировать страницы', 'message' => 'Какие страницы готовить первыми и почему? Что лучше отложить?'],
        ['label' => 'Подготовить ТЗ', 'message' => 'Подготовь безопасные ТЗ по самым приоритетным пунктам плана спроса. Не публикуй страницы и не открывай индексацию.'],
        ['label' => 'Создать безопасные черновики', 'message' => 'Подготовь безопасные черновики только для пунктов без критических рисков. Черновики должны остаться draft и blocked.'],
        ['label' => 'Создать подсказки для карточек', 'message' => 'Подготовь подсказки для карточек авто по спросу, не меняя сами автомобили.'],
        ['label' => 'Найти риски', 'message' => 'Найди рискованные запросы и обещания, которые нельзя превращать в продающие страницы.'],
        ['label' => 'Сделать FAQ', 'message' => 'Подготовь безопасный план FAQ по условиям аренды, залогу, цене и документам.'],
        ['label' => 'Проверить риски', 'message' => 'Проверь риски по текущему плану спроса: залог, аэропорт, неподтвержденные города, цены, наличие авто и юридические ограничения.'],
        ['label' => 'Проверить черновик', 'message' => 'Проверь выбранный черновик: что исправить, какие FAQ и блоки добавить, что нельзя обещать.'],
        ['label' => 'Улучшить черновик', 'message' => 'Проверь выбранный черновик: что исправить, какие FAQ и блоки добавить, что нельзя обещать.'],
        ['label' => 'Оживить текст', 'message' => 'Перепиши выбранный черновик живее: сделай текст для обычного человека, без SEO-простыни и без новых неподтвержденных обещаний.'],
        ['label' => 'Проверить перед публикацией', 'message' => 'Проверь выбранный черновик перед публикацией для просмотра: риски, факты, FAQ, залог, подача и наличие авто.'],
    ];
}

function demand_ai_dialog_action_registry(): array
{
    $readOnly = [
        'explain_current_screen' => 'Объяснить текущий экран',
        'analyze_current_tab' => 'Проанализировать текущую вкладку',
        'analyze_existing_keywords' => 'Проанализировать существующие фразы',
        'analyze_import_preview' => 'Разобрать предпросмотр импорта',
        'analyze_demand_map' => 'Разобрать карту спроса',
        'analyze_launch_plan' => 'Разобрать план страниц',
        'analyze_draft' => 'Проверить черновик',
        'generate_seed_phrases' => 'Собрать seed-фразы',
        'clean_irrelevant_queries' => 'Отделить нецелевые запросы',
        'build_action_plan' => 'Собрать план действий',
        'build_priority_summary' => 'Собрать приоритеты',
        'prepare_human_landing_copy' => 'Подготовить живой вариант текста',
        'suggest_internal_links' => 'Подобрать внутренние ссылки',
        'save_workflow_result_summary' => 'Подготовить итог workflow',
    ];
    $writeAfterConfirmation = [
        'save_ai_seed_keywords' => 'Сохранить AI-фразы как идеи для проверки',
        'classify_saved_ai_keywords' => 'Классифицировать AI-фразы',
        'classify_ai_seed_phrases' => 'Классифицировать AI seed-фразы',
        'mark_irrelevant_ai_keywords' => 'Пометить нецелевые AI-фразы',
        'recalculate_recommendations' => 'Пересчитать рекомендации',
        'recalculate_demand_map' => 'Пересчитать карту спроса',
        'create_ai_content_brief' => 'Создать ТЗ из AI-плана',
        'create_content_brief_from_ai_plan' => 'Создать ТЗ из плана',
        'create_safe_landing_draft' => 'Создать безопасный черновик',
        'create_safe_landing_draft_from_ai_plan' => 'Создать безопасные черновики',
        'create_safe_landing_drafts_batch' => 'Создать безопасные черновики пакетом',
        'add_faq_to_draft' => 'Добавить FAQ в черновик',
        'add_safe_block_to_draft' => 'Добавить безопасный блок в черновик',
        'create_car_card_hint' => 'Создать подсказки для карточек авто',
        'save_admin_note' => 'Сохранить заметку admin',
        'save_ai_workflow_summary' => 'Сохранить итог AI workflow',
        'apply_safe_draft_proposal' => 'Применить безопасное предложение к черновику',
        'apply_internal_link_suggestions' => 'Добавить выбранные внутренние ссылки',
        'apply_safe_brief_proposal' => 'Применить безопасное предложение к ТЗ',
    ];
    $special = [
        'wordstat_dry_run' => 'Проверить план Wordstat dry-run',
        'wordstat_controlled_live_sync' => 'Загрузить реальные данные Wordstat',
    ];
    $forbidden = [
        'publish_page',
        'publish_noindex',
        'open_indexing',
        'request_indexing',
        'add_to_sitemap',
        'remove_from_sitemap',
        'edit_sitemap',
        'edit_robots',
        'edit_canonical',
        'edit_public_route',
        'edit_price',
        'edit_prices',
        'edit_deposit',
        'edit_deposits',
        'edit_tariff',
        'edit_car_record',
        'edit_car_records',
        'edit_request',
        'edit_requests',
        'edit_rental',
        'edit_rentals',
        'edit_client',
        'edit_clients',
        'edit_fine',
        'edit_fines',
        'edit_finance',
        'edit_document',
        'edit_documents',
        'edit_user',
        'edit_users',
        'edit_role',
        'edit_roles',
        'edit_permission',
        'send_notification',
        'send_notifications',
        'call_arbitrary_endpoint',
    ];

    $registry = [];
    foreach ($readOnly as $action => $label) {
        $registry[$action] = [
            'action' => $action,
            'label' => $label,
            'kind' => 'read',
            'writesData' => false,
            'requiresConfirmation' => false,
            'requiresExplicitConfirmation' => false,
            'mayCostMoney' => false,
            'permission' => 'demand.ai_workflow.run',
            'safeNote' => 'Без изменений в данных.',
        ];
    }
    foreach ($writeAfterConfirmation as $action => $label) {
        $registry[$action] = [
            'action' => $action,
            'label' => $label,
            'kind' => 'write',
            'writesData' => true,
            'requiresConfirmation' => true,
            'requiresExplicitConfirmation' => false,
            'mayCostMoney' => false,
            'permission' => 'demand.ai_workflow.apply',
            'safeNote' => 'Без публикации страниц и без изменений в поиске.',
        ];
    }
    foreach ($special as $action => $label) {
        $registry[$action] = [
            'action' => $action,
            'label' => $label,
            'kind' => 'special',
            'writesData' => $action === 'wordstat_dry_run',
            'requiresConfirmation' => true,
            'requiresExplicitConfirmation' => true,
            'mayCostMoney' => $action === 'wordstat_controlled_live_sync',
            'permission' => $action === 'wordstat_controlled_live_sync' ? 'demand.wordstat.live' : 'demand.wordstat.test',
            'safeNote' => $action === 'wordstat_controlled_live_sync'
                ? 'Может выполнить запросы к Wordstat. Нужна отдельная проверка лимитов.'
                : 'Dry-run не публикует страницы и не меняет sitemap/robots.',
        ];
    }
    foreach ($forbidden as $action) {
        $registry[$action] = [
            'action' => $action,
            'label' => $action,
            'kind' => 'forbidden',
            'writesData' => true,
            'requiresConfirmation' => false,
            'requiresExplicitConfirmation' => false,
            'mayCostMoney' => false,
            'permission' => '',
            'safeNote' => 'Запрещено для диалогового AI workflow.',
        ];
    }

    $autoSafe = [
        'explain_current_screen',
        'analyze_current_tab',
        'analyze_existing_keywords',
        'analyze_import_preview',
        'analyze_demand_map',
        'analyze_launch_plan',
        'analyze_draft',
        'generate_seed_phrases',
        'clean_irrelevant_queries',
        'build_action_plan',
        'build_priority_summary',
        'classify_ai_seed_phrases',
        'prepare_human_landing_copy',
        'suggest_internal_links',
        'save_workflow_result_summary',
    ];
    $safeWrite = [
        'save_ai_seed_keywords',
        'classify_saved_ai_keywords',
        'classify_ai_seed_phrases',
        'mark_irrelevant_ai_keywords',
        'recalculate_recommendations',
        'recalculate_demand_map',
        'create_ai_content_brief',
        'create_content_brief_from_ai_plan',
        'create_car_card_hint',
        'save_admin_note',
        'save_ai_workflow_summary',
    ];
    $confirmationRequired = [
        'create_safe_landing_draft',
        'create_safe_landing_draft_from_ai_plan',
        'create_safe_landing_drafts_batch',
        'add_faq_to_draft',
        'add_safe_block_to_draft',
        'apply_safe_draft_proposal',
        'apply_internal_link_suggestions',
        'apply_safe_brief_proposal',
        'wordstat_dry_run',
    ];
    $specialConfirmation = ['wordstat_controlled_live_sync'];

    foreach ($registry as $action => &$item) {
        $item['actionId'] = $action;
        $item['requiresPermission'] = (string) ($item['permission'] ?? '');
        $item['allowedScope'] = 'rent_rk';
        $item['executor'] = 'demand_ai_dialog_execute_action';
        $item['rollbackNote'] = ((string) ($item['kind'] ?? '') === 'forbidden')
            ? 'Действие не выполняется.'
            : 'Подготовительные JSON-записи можно восстановить из .bak/backup; публикация и индекс не затрагиваются.';
        if (in_array($action, $autoSafe, true)) {
            $item['riskLevel'] = 'auto_safe';
            $item['requiresConfirmation'] = false;
            $item['requiresExplicitConfirmation'] = false;
        } elseif (in_array($action, $safeWrite, true)) {
            $item['riskLevel'] = 'safe_write';
            $item['requiresConfirmation'] = false;
            $item['requiresExplicitConfirmation'] = false;
        } elseif (in_array($action, $confirmationRequired, true)) {
            $item['riskLevel'] = 'confirmation_required';
            $item['requiresConfirmation'] = true;
        } elseif (in_array($action, $specialConfirmation, true)) {
            $item['riskLevel'] = 'special_confirmation_required';
            $item['requiresConfirmation'] = true;
            $item['requiresExplicitConfirmation'] = true;
        } else {
            $item['riskLevel'] = ((string) ($item['kind'] ?? '') === 'forbidden') ? 'forbidden' : 'confirmation_required';
        }
    }
    unset($item);

    return $registry;
}

function demand_ai_dialog_forbidden_actions(): array
{
    return array_values(array_filter(demand_ai_dialog_action_registry(), static fn(array $item): bool => (string) ($item['kind'] ?? '') === 'forbidden'));
}

function demand_ai_dialog_can_access(): bool
{
    if (current_user_is_platform_admin()) {
        return true;
    }
    $scopeId = current_user_data_scope_id();
    if ($scopeId !== '' && $scopeId !== 'rent_rk') {
        return false;
    }

    return has_permission('demand.ai_dialog.view') || has_permission('demand.ai_dialog.use') || has_permission('demand.ai_api.use');
}

function demand_ai_dialog_permission_allowed(string $permission): bool
{
    if (!demand_ai_dialog_can_access()) {
        return false;
    }
    if ($permission === 'demand.ai_dialog.view'
        && (has_permission('demand.ai_dialog.view') || has_permission('demand.ai_dialog.use') || has_permission('demand.ai_api.view') || has_permission('demand.ai_api.use'))
    ) {
        return true;
    }
    if ($permission === 'demand.ai_dialog.use'
        && (has_permission('demand.ai_dialog.use') || has_permission('demand.ai_api.use'))
    ) {
        return true;
    }
    if ($permission === 'demand.ai_workflow.run'
        && (has_permission('demand.ai_workflow.run') || has_permission('demand.ai_dialog.use') || has_permission('demand.ai_api.use'))
    ) {
        return true;
    }
    if ($permission === 'demand.ai_workflow.apply'
        && (has_permission('demand.ai_workflow.apply') || has_permission('demand.ai_api.apply'))
    ) {
        return true;
    }

    return has_permission($permission);
}

function demand_ai_dialog_require(string $permission): void
{
    if (demand_ai_dialog_permission_allowed($permission)) {
        return;
    }
    deny_scope_access();
}

function demand_ai_dialog_action_allowed(array $actionCard): bool
{
    $definition = demand_ai_dialog_action_registry()[(string) ($actionCard['action'] ?? '')] ?? null;
    if (!is_array($definition) || (string) ($definition['kind'] ?? '') === 'forbidden') {
        return false;
    }
    $permission = (string) ($definition['permission'] ?? '');
    return $permission === '' || demand_ai_dialog_permission_allowed($permission);
}

function demand_ai_dialog_scope_id(string $scopeFilter): string
{
    $scopeIds = demand_current_scope_filter($scopeFilter);
    if (!$scopeIds) {
        deny_scope_access();
    }
    if (!current_user_is_platform_admin()) {
        $scopeId = demand_normalize_scope_id(current_user_data_scope_id());
        if ($scopeId !== 'rent_rk') {
            deny_scope_access();
        }

        return 'rent_rk';
    }

    $requested = demand_normalize_scope_id($scopeFilter);
    return ($requested !== '' && $requested !== 'all') ? $requested : 'rent_rk';
}

function demand_ai_dialog_state(): array
{
    $state = is_array($_SESSION['demand_ai_dialog'] ?? null) ? $_SESSION['demand_ai_dialog'] : [];

    return [
        'messages' => array_values(array_slice((array) ($state['messages'] ?? []), -8)),
        'workflow' => is_array($state['workflow'] ?? null) ? $state['workflow'] : null,
        'lastResult' => is_array($state['lastResult'] ?? null) ? $state['lastResult'] : null,
    ];
}

function demand_ai_dialog_save_state(array $state): void
{
    $state['messages'] = array_values(array_slice((array) ($state['messages'] ?? []), -8));
    $_SESSION['demand_ai_dialog'] = $state;
}

function demand_ai_dialog_clear_state(): void
{
    unset($_SESSION['demand_ai_dialog']);
}

function demand_ai_dialog_workflow_has_pending_confirmation(array $workflow): bool
{
    foreach (['requiresConfirmation', 'specialConfirmation'] as $bucket) {
        foreach ((array) ($workflow[$bucket] ?? []) as $action) {
            if (!is_array($action)) {
                continue;
            }
            if (in_array((string) ($action['status'] ?? 'pending'), ['pending', 'waiting'], true)) {
                return true;
            }
        }
    }

    return false;
}

function demand_ai_dialog_derive_workflow_status(array $workflow): string
{
    $current = (string) ($workflow['status'] ?? 'planned');
    if (in_array($current, ['cancelled', 'failed'], true)) {
        return $current;
    }
    $statuses = (array) ($workflow['actionStatuses'] ?? []);
    if (demand_ai_dialog_workflow_has_pending_confirmation($workflow)) {
        return $statuses ? 'waiting_confirmation' : 'planned';
    }

    return $statuses ? 'completed' : 'planned';
}

function demand_ai_dialog_initial_auto_actions(array $workflow): array
{
    if (empty($workflow['seedAnalyses'])) {
        return [];
    }
    $actions = [
        'generate_seed_phrases',
        'save_ai_seed_keywords',
        'classify_saved_ai_keywords',
        'mark_irrelevant_ai_keywords',
        'recalculate_recommendations',
        'recalculate_demand_map',
        'build_priority_summary',
        'create_ai_content_brief',
        'create_car_card_hint',
        'save_ai_workflow_summary',
    ];

    $budgetLimits = is_array($workflow['directionSession']['budgetLimits'] ?? null) ? $workflow['directionSession']['budgetLimits'] : [];
    $maxActions = (int) ($budgetLimits['maxAiCalls'] ?? 0);
    if ($maxActions > 0 && count($actions) > $maxActions) {
        $actions = array_slice($actions, 0, $maxActions);
    }

    return array_values(array_unique($actions));
}

function demand_ai_dialog_direction_session_from_options(array $options): array
{
    $nested = is_array($options['directionSession'] ?? null) ? $options['directionSession'] : [];
    $payload = $nested;
    foreach ([
        'directionId' => ['directionId', 'direction_id'],
        'directionTitle' => ['directionTitle', 'direction_title'],
        'budgetMode' => ['budgetMode', 'budget_mode', 'direction_budget_mode'],
        'processingFingerprint' => ['processingFingerprint', 'processing_fingerprint'],
        'source' => ['source', 'direction_session_source'],
    ] as $target => $keys) {
        foreach ($keys as $key) {
            if (array_key_exists($key, $options) && (string) $options[$key] !== '') {
                $payload[$target] = $options[$key];
                break;
            }
        }
    }

    $directionId = demand_ai_safe_string($payload['directionId'] ?? '', 160);
    if ($directionId === '') {
        return [];
    }
    $mode = (string) (function_exists('demand_ai_budget_mode') ? (demand_ai_budget_mode((string) ($payload['budgetMode'] ?? 'economy'))['key'] ?? 'economy') : 'economy');
    $limits = function_exists('demand_ai_budget_mode') ? demand_ai_budget_mode($mode) : [
        'key' => $mode,
        'maxAiCalls' => 3,
        'maxSeedPhrases' => 20,
        'maxClusters' => 3,
        'maxDrafts' => 0,
        'wordstatDryRunAllowed' => false,
        'wordstatLiveAllowed' => false,
        'maxCopyVariants' => 1,
        'maxInternalLinks' => 3,
        'maxNeighboringDirections' => 3,
    ];

    return [
        'sessionId' => 'ais_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'directionId' => $directionId,
        'directionTitle' => demand_ai_safe_string($payload['directionTitle'] ?? '', 240),
        'budgetMode' => $mode,
        'budgetLimits' => $limits,
        'processingFingerprint' => demand_ai_safe_string($payload['processingFingerprint'] ?? '', 180),
        'startedAt' => now_iso(),
        'startedBy' => [
            'userId' => current_admin_user() ?: 'system',
            'source' => demand_ai_safe_string($payload['source'] ?? 'demand_master', 120),
        ],
    ];
}

function demand_ai_dialog_has_direction_option_payload(array $options): bool
{
    if (is_array($options['directionSession'] ?? null)) {
        return true;
    }
    foreach (['directionId', 'direction_id', 'directionTitle', 'direction_title', 'processingFingerprint', 'processing_fingerprint'] as $key) {
        if (array_key_exists($key, $options) && (string) $options[$key] !== '') {
            return true;
        }
    }

    return false;
}

function demand_ai_dialog_is_broad_direction_request(string $message, string $intent = ''): bool
{
    $normalized = demand_normalize_phrase($message);
    $hasBroad = demand_map_contains_any($normalized, [
        'весь спрос',
        'все лендинги',
        'seo полностью',
        'сео полностью',
        'всем городам',
        'все города',
        'по всем городам',
        'города крыма',
        'по городам крыма',
        'по крыму',
        'весь крым',
        'собери запросы по всем',
        'подготовь спрос по крыму',
        'подготовь все лендинги',
    ]);
    if ($hasBroad) {
        return true;
    }

    return in_array($intent, ['build_city_keyword_map', 'build_region_keyword_map', 'create_seo_action_plan'], true)
        && demand_map_contains_any($normalized, ['крым', 'город'])
        && demand_map_contains_any($normalized, ['весь', 'все', 'всем', 'по городам']);
}

function demand_ai_dialog_fallback_direction_queue(string $scopeId): array
{
    $rows = [
        ['title' => 'Ялта / аренда авто', 'region' => 'Ялта', 'topic' => 'аренда авто', 'intentType' => 'commercial', 'priority' => 'high'],
        ['title' => 'Симферополь / аренда авто', 'region' => 'Симферополь', 'topic' => 'аренда авто', 'intentType' => 'commercial', 'priority' => 'high'],
        ['title' => 'Севастополь / аренда авто', 'region' => 'Севастополь', 'topic' => 'аренда авто', 'intentType' => 'commercial', 'priority' => 'medium'],
        ['title' => 'Минивэны / 7 мест', 'region' => 'Крым', 'topic' => 'минивэны 7 мест', 'intentType' => 'car_class', 'priority' => 'high'],
        ['title' => 'Аэропорт Симферополь / подача авто', 'region' => 'Симферополь', 'topic' => 'подача авто аэропорт', 'intentType' => 'service_condition', 'priority' => 'medium'],
        ['title' => 'Залог / FAQ', 'region' => 'Крым', 'topic' => 'условия залога', 'intentType' => 'faq', 'priority' => 'medium'],
    ];
    $directions = [];
    foreach ($rows as $row) {
        $id = function_exists('demand_ai_build_direction_id')
            ? demand_ai_build_direction_id($row['title'], $row['region'], $row['topic'], $row['intentType'])
            : 'dir_' . substr(hash('sha256', implode('|', $row)), 0, 18);
        $direction = [
            'directionId' => $id,
            'title' => $row['title'],
            'region' => ['name' => $row['region'], 'type' => $row['region'] === 'Крым' ? 'region' : 'city', 'confidence' => 'needs_confirmation'],
            'topic' => $row['topic'],
            'intentType' => $row['intentType'],
            'priority' => $row['priority'],
            'status' => 'not_started',
            'lastProcessedAt' => null,
            'lastWordstatDryRunAt' => null,
            'lastWordstatLiveAt' => null,
            'nextRefreshRecommendedAt' => null,
            'linkedKeywordIds' => [],
            'linkedDraftIds' => [],
            'linkedContentBriefIds' => [],
            'linkedDecisionIds' => [],
            'linkedAiRunIds' => [],
            'budgetMode' => 'economy',
            'processingFingerprint' => '',
        ];
        if (function_exists('demand_ai_direction_processing_fingerprint')) {
            $direction['processingFingerprint'] = demand_ai_direction_processing_fingerprint($direction, [
                'scopeIds' => [$scopeId],
                'keywords' => [],
                'briefs' => [],
                'drafts' => [],
                'hints' => [],
                'syncRuns' => [],
                'aiSettings' => [],
                'copySettings' => [],
            ]);
        }
        $direction['nextAction'] = function_exists('demand_ai_direction_next_action') ? demand_ai_direction_next_action($direction) : [
            'label' => 'Запустить AI-сессию',
            'actionKey' => 'direction_start_confirm',
            'confirmationLevel' => 'start_session',
            'directionId' => $id,
        ];
        $directions[] = $direction;
    }

    return $directions;
}

function demand_ai_dialog_build_direction_queue_plan(string $message, string $scopeFilter, string $currentTab, string $entityType, string $entityId, string $intent, string $reason = 'broad_command'): array
{
    $scopeId = demand_ai_dialog_scope_id($scopeFilter);
    $context = function_exists('demand_ai_workspace_context') ? demand_ai_workspace_context($scopeFilter) : ['scopeIds' => [$scopeId]];
    $directions = function_exists('demand_ai_build_directions') ? demand_ai_build_directions($scopeFilter, $context) : [];
    if (!$directions) {
        $directions = demand_ai_dialog_fallback_direction_queue($scopeId);
    }
    $directions = array_values(array_filter($directions, static fn($item): bool => is_array($item) && (string) ($item['directionId'] ?? '') !== ''));
    $recommended = $directions[0] ?? [];
    $recommendedTitle = (string) ($recommended['title'] ?? 'первое направление');

    return [
        'id' => 'aidlg_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'createdAt' => now_iso(),
        'updatedAt' => now_iso(),
        'actor' => current_admin_user() ?: 'system',
        'scope_id' => $scopeId,
        'status' => 'waiting_direction_start',
        'currentTab' => demand_ai_safe_string($currentTab, 80),
        'entityType' => demand_ai_safe_string($entityType, 80),
        'entityId' => demand_ai_safe_string($entityId, 120),
        'userGoalSummary' => $message,
        'dialogIntent' => $intent,
        'summary' => 'Это широкая задача. Чтобы не тратить лимиты впустую, AI разобьёт её на направления и начнёт только после подтверждения конкретного направления и бюджета.',
        'whatIUnderstood' => [
            'Задача широкая: ' . $message,
            'AI не запускает общий workflow и не создаёт seed-фразы до выбора direction-session.',
            'Рекомендуемое начало: ' . $recommendedTitle . ' в режиме economy.',
        ],
        'safeToRunNow' => [],
        'requiresConfirmation' => [],
        'specialConfirmation' => [],
        'forbiddenActions' => array_values(array_map(static fn(array $item): string => (string) $item['action'], demand_ai_dialog_forbidden_actions())),
        'expectedResult' => [
            'keywordGroups' => [],
            'priorityActions' => array_map(static fn(array $direction): array => [
                'title' => (string) ($direction['title'] ?? ''),
                'priority' => (string) ($direction['priority'] ?? 'medium'),
                'action' => 'start_direction_session',
                'directionId' => (string) ($direction['directionId'] ?? ''),
            ], array_slice($directions, 0, 8)),
            'draftProposals' => [],
            'briefProposals' => [],
            'faqProposals' => [],
        ],
        'seedKeywords' => [],
        'seedAnalyses' => [],
        'risks' => [],
        'nextStep' => [
            'label' => 'Запустить AI-сессию по направлению',
            'reason' => 'Сначала выберите одно направление и бюджет. До подтверждения AI не тратит API-вызовы и не пишет Demand JSON.',
            'safe' => true,
        ],
        'actionStatuses' => [],
        'createdKeywordIds' => [],
        'createdBriefIds' => [],
        'createdDraftIds' => [],
        'createdHintIds' => [],
        'apiUsed' => false,
        'apiError' => '',
        'promptHash' => '',
        'responseHash' => '',
        'directionSession' => [],
        'requiresDirectionSelection' => true,
        'directionRoutingReason' => $reason,
        'broadDirectionQueue' => [
            'recommendedDirectionId' => (string) ($recommended['directionId'] ?? ''),
            'recommendedDirectionTitle' => $recommendedTitle,
            'budgetMode' => 'economy',
            'directions' => array_slice($directions, 0, 8),
        ],
        'stopReason' => 'needs_confirmation',
    ];
}

function demand_ai_dialog_stop_state(): array
{
    $state = demand_ai_dialog_state();
    $workflow = is_array($state['workflow'] ?? null) ? $state['workflow'] : [];
    if (!$workflow) {
        return ['changed' => false, 'message' => 'Активного AI workflow нет.'];
    }
    $workflow['status'] = 'cancelled';
    $workflow['updatedAt'] = now_iso();
    foreach (['safeToRunNow', 'requiresConfirmation', 'specialConfirmation'] as $bucket) {
        foreach ((array) ($workflow[$bucket] ?? []) as $index => $action) {
            if (!is_array($action)) {
                continue;
            }
            if ((string) ($action['status'] ?? 'pending') === 'pending') {
                $workflow[$bucket][$index]['status'] = 'cancelled';
            }
        }
    }
    $state['workflow'] = $workflow;
    $state['lastResult'] = [
        'action' => 'stop_workflow',
        'changed' => false,
        'message' => 'AI workflow остановлен. Уже созданные безопасные подготовительные записи остаются; публикация и индекс не менялись.',
    ];
    $state['messages'][] = [
        'role' => 'assistant',
        'text' => (string) $state['lastResult']['message'],
        'createdAt' => now_iso(),
    ];
    demand_ai_dialog_save_state($state);

    return $state['lastResult'];
}

function demand_ai_dialog_redact_text(string $text, int $limit = 3000): string
{
    $text = demand_clean_string($text, $limit);
    $text = preg_replace('/sk-[A-Za-z0-9_\-]{8,}/', 'sk-***', $text) ?? $text;
    $text = preg_replace('/Bearer\s+[A-Za-z0-9._\-]+/i', 'Bearer ***', $text) ?? $text;
    $text = preg_replace('/api[_-]?key\s*[:=]\s*["\']?[^"\'\s,}]+/i', 'apiKey=***', $text) ?? $text;
    $text = preg_replace('/\+?\d[\d\s().-]{8,}\d/u', '[phone hidden]', $text) ?? $text;

    return trim($text);
}

function demand_ai_dialog_detect_intent(string $message, string $currentTab = '', string $entityType = ''): string
{
    $normalized = demand_normalize_phrase($message);
    $has = static fn(array $needles): bool => demand_map_contains_any($normalized, $needles);

    if (($entityType === 'draft' || $has(['черновик', 'страниц', 'текст', 'блок', 'intro', 'faq']))
        && $has(['живее', 'обычного человека', 'seo-простын', 'сео-простын', 'перегенер', 'перепиши', 'оживи', 'менее шаблон', 'еще один вариант', 'ещё один вариант', 'убери seo', 'убери сео', 'сделай текст проще'])
    ) {
        return 'regenerate_human_copy';
    }

    if (($entityType === 'draft' || $has(['черновик', 'страниц', 'лендинг']))
        && $has(['внутренн', 'ссылк', 'связи', 'связать', 'перелинков'])
    ) {
        return 'suggest_internal_links';
    }

    if ($has(['без залога', 'без прав', 'без паспорта', 'без договора', 'ложн', 'обещан', 'риск'])) {
        return 'check_false_promises';
    }
    if ($entityType === 'draft' || $has(['черновик', 'публикац', 'перед публикац', 'страниц'])) {
        if ($has(['перед публикац', 'провер', 'готовност'])) {
            return 'prepare_publication_checklist';
        }
        if ($has(['сделай черновик', 'создай черновик', 'подготовь черновик'])) {
            return 'create_safe_landing_drafts';
        }
        if ($has(['faq', 'вопрос', 'ответ'])) {
            return 'create_faq_plan';
        }
        if ($entityType === 'draft' || $has(['улучш', 'исправ', 'понятн'])) {
            return 'improve_landing_draft';
        }
    }
    if ($has(['собери запрос', 'собрать запрос', 'города крыма', 'городам крыма', 'ялта', 'симферополь', 'севастополь'])) {
        return 'build_city_keyword_map';
    }
    if ($has(['крым', 'регион', 'южнобереж', 'юбк'])) {
        return 'build_region_keyword_map';
    }
    if ($has(['минивен', 'минивэн', '7 мест', 'семь мест', 'семьи', 'кабриолет'])) {
        return 'build_keyword_plan';
    }
    if ($has(['мусор', 'убери', 'очист', 'игнорировать', 'нецелев'])) {
        return 'clean_irrelevant_queries';
    }
    if ($has(['план страниц', 'приоритет', 'первыми', 'что отложить'])) {
        return 'prioritize_launch_plan';
    }
    if ($has(['тз', 'бриф'])) {
        return 'create_content_briefs';
    }
    if ($has(['faq', 'вопрос', 'залог', 'документ'])) {
        return 'create_faq_plan';
    }
    if ($has(['подсказк', 'карточк', 'авто'])) {
        return 'create_car_card_hints';
    }
    if ($currentTab === 'import') {
        return 'summarize_import_preview';
    }
    if ($has(['что делать', 'следующ', 'сегодня'])) {
        return 'suggest_next_step';
    }

    return 'explain_current_screen';
}

function demand_ai_dialog_seed_phrase_rows(string $message, string $intent, string $scopeId): array
{
    $normalized = demand_normalize_phrase($message);
    $rows = [];
    $add = static function (string $phrase, string $region = '') use (&$rows, $scopeId): void {
        $key = demand_normalize_phrase($phrase) . '|' . demand_normalize_phrase($region);
        $rows[$key] = [
            'scope_id' => $scopeId,
            'phrase' => $phrase,
            'regionName' => $region,
            'frequency' => 0,
            'source' => 'ai_suggested_seed',
            'status' => 'active',
            'comment' => 'AI seed: проверить через Wordstat перед решением о странице.',
        ];
    };

    $cities = ['Ялта', 'Симферополь', 'Севастополь', 'Алушта', 'Евпатория', 'Феодосия', 'Керчь', 'Саки'];
    $isKeywordCollection = in_array($intent, ['build_city_keyword_map', 'build_region_keyword_map', 'collect_keyword_ideas', 'build_keyword_plan', 'create_seo_action_plan'], true)
        || demand_map_contains_any($normalized, ['город', 'крым', 'аренда авто']);
    if ($isKeywordCollection) {
        foreach ($cities as $city) {
            $add('аренда авто ' . $city, $city);
            $add('прокат авто ' . $city, $city);
        }
        $add('аренда машины Ялта', 'Ялта');
        $add('машина напрокат в Ялте', 'Ялта');
        $add('аренда авто Крым', 'Крым');
        $add('прокат авто Крым', 'Крым');
        $add('аренда авто без водителя Крым', 'Крым');
        $add('аренда авто аэропорт Симферополь', 'Симферополь');
    }

    if ($isKeywordCollection
        || in_array($intent, ['build_keyword_plan', 'create_car_card_hints', 'create_seo_action_plan'], true)
        || demand_map_contains_any($normalized, ['минивен', 'минивэн', '7 мест', 'семь мест', 'кабриолет', 'семь'])
    ) {
        $add('аренда минивэна Ялта', 'Ялта');
        $add('аренда минивэна Крым', 'Крым');
        $add('7 мест авто Ялта', 'Ялта');
        $add('7 мест авто Крым', 'Крым');
        $add('машина для семьи Ялта', 'Ялта');
        $add('прокат кабриолета Крым', 'Крым');
    }

    if ($isKeywordCollection
        || in_array($intent, ['create_faq_plan', 'check_false_promises', 'clean_irrelevant_queries'], true)
        || demand_map_contains_any($normalized, ['залог', 'дешево', 'документ', 'прав', 'паспорт'])
    ) {
        $add('аренда авто без залога', 'Крым');
        $add('аренда авто дешево', 'Крым');
        $add('что нужно для аренды авто', '');
        $add('аренда авто без прав', '');
        $add('аренда авто без паспорта', '');
    }

    $add('такси Ялта', 'Ялта');
    $add('трансфер Симферополь Ялта', 'Симферополь');
    $add('аренда авто под такси', 'Крым');
    $add('купить авто Ялта', 'Ялта');
    $add('ремонт авто Ялта', 'Ялта');
    $add('каршеринг Крым', 'Крым');

    return array_values($rows);
}

function demand_ai_dialog_analyze_seed_row(array $row): array
{
    $keyword = demand_normalize_keyword_record($row);
    $keyword['id'] = 'seed_' . substr(hash('sha1', (string) ($keyword['scope_id'] ?? '') . '|' . (string) ($keyword['phrase'] ?? '') . '|' . (string) ($keyword['regionName'] ?? '')), 0, 14);
    $stageB = demand_stage_b_score_keyword($keyword);
    $stageC = demand_stage_c_analyze_keyword($keyword, ['stageB' => $stageB]);

    return [
        'keyword' => $keyword,
        'stageB' => $stageB,
        'stageC' => $stageC,
        'safe' => demand_ai_safe_keyword($keyword),
    ];
}

function demand_ai_dialog_seed_groups(array $seedAnalyses): array
{
    $groups = [
        'priority' => [],
        'review' => [],
        'faq_or_condition' => [],
        'excluded' => [],
    ];
    foreach ($seedAnalyses as $analysis) {
        $keyword = is_array($analysis['keyword'] ?? null) ? $analysis['keyword'] : [];
        $stageB = is_array($analysis['stageB'] ?? null) ? $analysis['stageB'] : [];
        $safe = is_array($analysis['safe'] ?? null) ? $analysis['safe'] : demand_ai_safe_keyword($keyword);
        if (!$safe) {
            continue;
        }
        $riskFlags = (array) ($keyword['riskFlags'] ?? []);
        if ((string) ($keyword['status'] ?? '') === 'excluded' || (string) ($keyword['negativeIntent'] ?? '') !== '') {
            $groups['excluded'][] = $safe;
            continue;
        }
        if (array_intersect($riskFlags, ['unsupported_legal_request', 'not_relevant_for_car_rental', 'driver_service_not_confirmed', 'commercial_use_not_supported'])) {
            $groups['excluded'][] = $safe;
            continue;
        }
        if (array_intersect($riskFlags, ['possible_false_promise', 'price_claim_risk', 'condition_not_supported'])) {
            $groups['faq_or_condition'][] = $safe;
            continue;
        }
        if (array_intersect($riskFlags, ['region_not_confirmed', 'unknown_region', 'airport_delivery_not_confirmed', 'needs_business_decision'])) {
            $groups['review'][] = $safe;
            continue;
        }
        if (in_array((string) ($stageB['priorityLevel'] ?? ''), ['high', 'medium', 'low'], true)) {
            $groups['priority'][] = $safe;
        } else {
            $groups['review'][] = $safe;
        }
    }

    return $groups;
}

function demand_ai_dialog_priority_actions(array $seedAnalyses, array $screenContext): array
{
    $actions = [];
    foreach (array_slice($seedAnalyses, 0, 24) as $analysis) {
        $keyword = is_array($analysis['keyword'] ?? null) ? $analysis['keyword'] : [];
        $stageB = is_array($analysis['stageB'] ?? null) ? $analysis['stageB'] : [];
        $phrase = (string) ($keyword['phrase'] ?? '');
        if ($phrase === '') {
            continue;
        }
        $riskFlags = (array) ($keyword['riskFlags'] ?? []);
        $priority = (string) ($stageB['priorityLevel'] ?? 'medium');
        $decision = (string) ($stageB['recommendedDecision'] ?? '');
        $actionLabel = 'Создать ТЗ после проверки спроса';
        if ((string) ($keyword['status'] ?? '') === 'excluded' || (string) ($keyword['negativeIntent'] ?? '') !== '') {
            $priority = 'excluded';
            $actionLabel = 'Не использовать для страниц';
            $decision = 'ignore_as_irrelevant';
        } elseif (array_intersect($riskFlags, ['unsupported_legal_request', 'not_relevant_for_car_rental'])) {
            $priority = 'blocked';
            $actionLabel = 'Не создавать страницу';
            $decision = 'do_not_create_page';
        } elseif (array_intersect($riskFlags, ['possible_false_promise', 'price_claim_risk', 'condition_not_supported'])) {
            $priority = 'blocked';
            $actionLabel = 'Сделать FAQ или осторожное объяснение';
            $decision = 'create_faq';
        } elseif (array_intersect($riskFlags, ['airport_delivery_not_confirmed', 'region_not_confirmed', 'unknown_region', 'needs_business_decision'])) {
            $priority = 'needs_business_decision';
            $actionLabel = 'Сначала подтвердить условие';
            $decision = 'needs_business_decision';
        } elseif (in_array($decision, ['create_landing_page', 'create_content_brief'], true)) {
            $actionLabel = 'Создать ТЗ и безопасный черновик после проверки';
        } elseif ($decision === 'improve_existing_page') {
            $actionLabel = 'Улучшить существующую страницу';
        } elseif ($decision === 'create_car_card_hint') {
            $actionLabel = 'Доработать подсказки для авто';
        }

        $actions[] = [
            'title' => $phrase,
            'priority' => $priority,
            'recommendedDecision' => $decision,
            'action' => $actionLabel,
            'reason' => demand_ai_safe_string($stageB['scoringExplanation'] ?? $keyword['adminExplanation'] ?? '', 700),
            'riskFlags' => demand_ai_safe_list($riskFlags, 12, 80),
        ];
    }

    usort($actions, static function (array $a, array $b): int {
        $order = ['high' => 0, 'medium' => 1, 'low' => 2, 'needs_business_decision' => 3, 'blocked' => 4, 'excluded' => 5];
        return ($order[(string) ($a['priority'] ?? '')] ?? 9) <=> ($order[(string) ($b['priority'] ?? '')] ?? 9);
    });

    return array_slice($actions, 0, 12);
}

function demand_ai_dialog_action_card(string $action, string $explanation = '', array $overrides = []): array
{
    $registry = demand_ai_dialog_action_registry();
    $base = $registry[$action] ?? [
        'action' => $action,
        'label' => $action,
        'kind' => 'forbidden',
        'writesData' => true,
        'requiresConfirmation' => false,
        'requiresExplicitConfirmation' => false,
        'mayCostMoney' => false,
        'permission' => '',
        'safeNote' => 'Действие не зарегистрировано.',
    ];
    $base['id'] = (string) ($overrides['id'] ?? ('act_' . substr(hash('sha1', $action . '|' . $explanation . '|' . json_encode($overrides)), 0, 10)));
    $base['explanation'] = $explanation !== '' ? demand_ai_safe_string($explanation, 700) : (string) ($base['safeNote'] ?? '');
    $base['status'] = (string) ($overrides['status'] ?? 'pending');
    foreach ($overrides as $key => $value) {
        if ($key !== 'id') {
            $base[$key] = $value;
        }
    }

    return $base;
}

function demand_ai_dialog_build_local_plan(string $message, string $scopeFilter, string $currentTab = '', string $entityType = '', string $entityId = '', array $options = []): array
{
    demand_ai_dialog_require('demand.ai_dialog.use');
    $scopeId = demand_ai_dialog_scope_id($scopeFilter);
    $message = demand_ai_dialog_redact_text($message);
    if ($message === '') {
        throw new RuntimeException('Напишите задачу для AI-помощника.');
    }

    $intent = demand_ai_dialog_detect_intent($message, $currentTab, $entityType);
    $directionSession = demand_ai_dialog_direction_session_from_options($options);
    if (!$directionSession && demand_ai_dialog_has_direction_option_payload($options)) {
        return demand_ai_dialog_build_direction_queue_plan($message, $scopeFilter, $currentTab, $entityType, $entityId, $intent, 'malformed_direction_session');
    }
    if (!$directionSession && demand_ai_dialog_is_broad_direction_request($message, $intent)) {
        return demand_ai_dialog_build_direction_queue_plan($message, $scopeFilter, $currentTab, $entityType, $entityId, $intent, 'broad_command');
    }
    $screenContext = demand_ai_api_screen_context($currentTab, $scopeFilter);
    $seedRows = in_array($intent, ['regenerate_human_copy', 'suggest_internal_links'], true) ? [] : demand_ai_dialog_seed_phrase_rows($message, $intent, $scopeId);
    $seedLimit = (int) ($directionSession['budgetLimits']['maxSeedPhrases'] ?? 0);
    if ($seedLimit > 0 && count($seedRows) > $seedLimit) {
        $seedRows = array_slice($seedRows, 0, $seedLimit);
    }
    $seedAnalyses = array_map('demand_ai_dialog_analyze_seed_row', $seedRows);
    $seedGroups = demand_ai_dialog_seed_groups($seedAnalyses);
    $priorityActions = demand_ai_dialog_priority_actions($seedAnalyses, $screenContext);
    $seedCount = count($seedAnalyses);

    $safeToRun = [
        demand_ai_dialog_action_card('analyze_current_tab', 'Посмотреть только текущую вкладку и безопасные Stage A/B/C поля.', ['id' => 'analyze_current_tab']),
        demand_ai_dialog_action_card('build_action_plan', 'Собрать список следующих шагов без записи данных.', ['id' => 'build_action_plan']),
    ];
    if ($intent === 'regenerate_human_copy' && $entityType === 'draft' && $entityId !== '') {
        $safeToRun[] = demand_ai_dialog_action_card('prepare_human_landing_copy', 'Подготовить живой вариант текста для выбранного черновика и показать preview/diff. Черновик не меняется без кнопки применения.', ['id' => 'prepare_human_landing_copy']);
    }
    if ($intent === 'suggest_internal_links' && $entityType === 'draft' && $entityId !== '') {
        $safeToRun[] = demand_ai_dialog_action_card('suggest_internal_links', 'Подобрать готовые внутренние ссылки из безопасных public-источников и показать варианты. Черновик не меняется без подтверждения.', ['id' => 'suggest_internal_links']);
    }
    if ($seedCount > 0) {
        array_unshift($safeToRun, demand_ai_dialog_action_card('generate_seed_phrases', 'Сформировать seed-фразы. Это только идеи, не подтвержденный спрос.', ['id' => 'generate_seed_phrases']));
        $safeToRun[] = demand_ai_dialog_action_card('save_ai_seed_keywords', 'Сохранить AI-фразы как подготовительные идеи `source=ai_suggested_seed`. Это не Wordstat-подтверждение.', ['id' => 'save_ai_seed_keywords']);
        $safeToRun[] = demand_ai_dialog_action_card('classify_saved_ai_keywords', 'Проверить Stage A/B/C классификацию сохраненных AI-фраз без публикации.', ['id' => 'classify_saved_ai_keywords']);
        $safeToRun[] = demand_ai_dialog_action_card('mark_irrelevant_ai_keywords', 'Нецелевые фразы остаются в данных как excluded и не идут в страницы/ТЗ/черновики.', ['id' => 'mark_irrelevant_ai_keywords']);
        $safeToRun[] = demand_ai_dialog_action_card('recalculate_recommendations', 'Пересчитать советы системы по сохраненным seed-фразам.', ['id' => 'recalculate_recommendations']);
        $safeToRun[] = demand_ai_dialog_action_card('recalculate_demand_map', 'Пересчитать карту спроса и SEO-план без публикации и индексации.', ['id' => 'recalculate_demand_map']);
        $safeToRun[] = demand_ai_dialog_action_card('build_priority_summary', 'Собрать приоритеты и безопасные следующие действия.', ['id' => 'build_priority_summary']);
        $safeToRun[] = demand_ai_dialog_action_card('create_ai_content_brief', 'Создать подготовительные ТЗ по приоритетным безопасным пунктам. Публикация не меняется.', ['id' => 'create_ai_content_brief']);
        $safeToRun[] = demand_ai_dialog_action_card('create_car_card_hint', 'Создать подсказки к карточкам авто, если в плане есть связанные авто.', ['id' => 'create_car_card_hint']);
        $safeToRun[] = demand_ai_dialog_action_card('save_ai_workflow_summary', 'Сохранить краткий итог в текущей session-памяти workflow без полного prompt/response.', ['id' => 'save_ai_workflow_summary']);
    }

    $requires = [];
    if ($seedCount > 0) {
        $requires[] = demand_ai_dialog_action_card('save_ai_seed_keywords', 'Сохранить AI-фразы как идеи `source=ai_suggested_seed`. Они не считаются подтвержденным спросом.', ['id' => 'save_ai_seed_keywords']);
        $requires[] = demand_ai_dialog_action_card('recalculate_recommendations', 'После сохранения seed-фраз пересчитать советы системы без создания страниц.', ['id' => 'recalculate_recommendations']);
        $requires[] = demand_ai_dialog_action_card('recalculate_demand_map', 'Пересчитать карту спроса и план страниц по сохраненным фразам.', ['id' => 'recalculate_demand_map']);
        $requires[] = demand_ai_dialog_action_card('create_safe_landing_drafts_batch', 'AI подготовил безопасные черновики. Создать их пакетом как draft/blocked?', ['id' => 'create_safe_landing_drafts_batch']);
    }
    $requires = array_values(array_filter($requires, static fn(array $item): bool => !in_array((string) ($item['action'] ?? ''), [
        'save_ai_seed_keywords',
        'recalculate_recommendations',
        'recalculate_demand_map',
    ], true)));
    if ($entityType === 'draft' && $entityId !== '') {
        $requires[] = demand_ai_dialog_action_card('add_faq_to_draft', 'Добавить первый безопасный FAQ из Stage C в выбранный черновик.', ['id' => 'add_faq_to_draft']);
        $requires[] = demand_ai_dialog_action_card('add_safe_block_to_draft', 'Добавить первый безопасный недостающий блок из Stage C.', ['id' => 'add_safe_block_to_draft']);
        if ($intent === 'suggest_internal_links') {
            $requires[] = demand_ai_dialog_action_card('apply_internal_link_suggestions', 'Добавить выбранные безопасные внутренние ссылки в черновик одной групповой кнопкой. Публикация и индексация не меняются.', ['id' => 'apply_internal_link_suggestions']);
        }
        $requires[] = demand_ai_dialog_action_card('save_admin_note', 'Сохранить краткую заметку admin по результату проверки.', ['id' => 'save_admin_note']);
    }

    $special = [];
    if ($seedCount > 0) {
        $special[] = demand_ai_dialog_action_card('wordstat_dry_run', 'Dry-run можно запускать только отдельным подтверждением. Он не публикует страницы.', ['id' => 'wordstat_dry_run']);
        $special[] = demand_ai_dialog_action_card('wordstat_controlled_live_sync', 'Live sync требует отдельного решения, лимитов и прав Wordstat live.', ['id' => 'wordstat_controlled_live_sync']);
    }

    $riskItems = [];
    foreach ($priorityActions as $item) {
        if (in_array((string) ($item['priority'] ?? ''), ['blocked', 'needs_business_decision', 'excluded'], true)) {
            $riskItems[] = [
                'level' => (string) ($item['priority'] ?? '') === 'excluded' ? 'medium' : ((string) ($item['priority'] ?? '') === 'blocked' ? 'blocked' : 'high'),
                'message' => (string) ($item['title'] ?? '') . ': ' . (string) ($item['action'] ?? ''),
            ];
        }
    }

    return [
        'id' => 'aidlg_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
        'createdAt' => now_iso(),
        'updatedAt' => now_iso(),
        'actor' => current_admin_user() ?: 'system',
        'scope_id' => $scopeId,
        'status' => 'planned',
        'currentTab' => demand_ai_safe_string($currentTab, 80),
        'entityType' => demand_ai_safe_string($entityType, 80),
        'entityId' => demand_ai_safe_string($entityId, 120),
        'userGoalSummary' => $message,
        'dialogIntent' => $intent,
        'summary' => demand_ai_dialog_intent_label($intent) . ': подготовлен безопасный workflow. AI предлагает план, сервер выполнит только зарегистрированные действия после подтверждения.',
        'whatIUnderstood' => [
            'Задача: ' . $message,
            'Контекст: вкладка ' . ($currentTab !== '' ? $currentTab : 'start') . ', scope ' . $scopeId . '.',
            $seedCount > 0 ? 'Seed-фразы являются идеями AI и требуют проверки через Wordstat.' : 'Используются текущие данные раздела "Спрос".',
        ],
        'safeToRunNow' => $safeToRun,
        'requiresConfirmation' => $requires,
        'specialConfirmation' => $special,
        'forbiddenActions' => array_values(array_map(static fn(array $item): string => (string) $item['action'], demand_ai_dialog_forbidden_actions())),
        'expectedResult' => [
            'keywordGroups' => $seedGroups,
            'priorityActions' => $priorityActions,
            'draftProposals' => [],
            'briefProposals' => [],
            'faqProposals' => demand_ai_dialog_faq_proposals($seedAnalyses),
        ],
        'seedKeywords' => array_values(array_map(static fn(array $item): array => (array) ($item['safe'] ?? []), $seedAnalyses)),
        'seedAnalyses' => $seedAnalyses,
        'risks' => array_slice($riskItems, 0, 8),
        'nextStep' => [
            'label' => $seedCount > 0 ? 'Сохранить seed-фразы или сначала запустить Wordstat dry-run' : 'Посмотреть план и выбрать безопасное действие',
            'reason' => $seedCount > 0
                ? 'AI-фразы не являются подтвержденным спросом. Их нужно сохранить как идеи и проверить.'
                : 'Диалоговый помощник не меняет данные без кнопки подтверждения.',
            'safe' => true,
        ],
        'actionStatuses' => [],
        'createdKeywordIds' => [],
        'createdBriefIds' => [],
        'createdDraftIds' => [],
        'createdHintIds' => [],
        'apiUsed' => false,
        'apiError' => '',
        'promptHash' => '',
        'responseHash' => '',
        'directionSession' => $directionSession,
        'stopReason' => '',
    ];
}

function demand_ai_dialog_faq_proposals(array $seedAnalyses): array
{
    $faq = [];
    foreach ($seedAnalyses as $analysis) {
        $stageC = is_array($analysis['stageC'] ?? null) ? $analysis['stageC'] : [];
        foreach ((array) ($stageC['recommendedFaq'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }
            $question = demand_ai_safe_string($item['question'] ?? '', 260);
            if ($question !== '') {
                $faq[$question] = [
                    'question' => $question,
                    'answerGuidance' => demand_ai_safe_string($item['answerGuidance'] ?? '', 700),
                    'sourceIntent' => demand_ai_safe_string($item['sourceIntent'] ?? '', 80),
                    'riskLevel' => demand_ai_safe_string($item['riskLevel'] ?? '', 40),
                ];
            }
            if (count($faq) >= 8) {
                break 2;
            }
        }
    }

    return array_values($faq);
}

function demand_ai_dialog_response_schema(): array
{
    return [
        'type' => 'object',
        'additionalProperties' => false,
        'required' => ['dialogIntent', 'summary', 'whatIUnderstood', 'importantFindings', 'risks', 'nextStep'],
        'properties' => [
            'dialogIntent' => ['type' => 'string', 'enum' => demand_ai_dialog_allowed_intents()],
            'summary' => ['type' => 'string'],
            'whatIUnderstood' => ['type' => 'array', 'items' => ['type' => 'string']],
            'importantFindings' => ['type' => 'array', 'items' => ['type' => 'string']],
            'risks' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'additionalProperties' => false,
                    'required' => ['level', 'message'],
                    'properties' => [
                        'level' => ['type' => 'string', 'enum' => ['low', 'medium', 'high', 'blocked']],
                        'message' => ['type' => 'string'],
                    ],
                ],
            ],
            'nextStep' => [
                'type' => 'object',
                'additionalProperties' => false,
                'required' => ['label', 'reason', 'safe'],
                'properties' => [
                    'label' => ['type' => 'string'],
                    'reason' => ['type' => 'string'],
                    'safe' => ['type' => 'boolean'],
                ],
            ],
        ],
    ];
}

function demand_ai_dialog_system_instructions(): string
{
    return implode("\n", [
        'Ты — диалоговый AI-помощник админки Rent RK для раздела "Маркетинг → Спрос".',
        'Помогаешь одному admin формулировать безопасный план подготовки SEO-материалов.',
        'Сервер сам выполнит только зарегистрированные allow-list действия; ты не управляешь публикацией и бизнес-данными.',
        'Не предлагай автопубликацию, открытие индексации, sitemap, robots, canonical, цены, залоги, автомобили, заявки, аренды, клиентов, штрафы, финансы, документы, пользователей, роли и уведомления.',
        'AI seed-фразы не являются подтвержденным спросом: указывай, что их нужно проверить через Wordstat.',
        'Для "без залога", "дешево", "аэропорт", "с водителем", "без прав", "без паспорта" и "без договора" обязательно говори о рисках.',
        'Отвечай простым русским языком и возвращай только JSON по схеме.',
    ]);
}

function demand_ai_dialog_stable_prompt_contract(): array
{
    return [
        'schemaVersion' => 'rent-rk-ai-dialog-context-v2',
        'contractVersion' => 'direction-session-hardening-v1',
        'task' => 'Return only JSON matching the response schema. Do not execute actions directly.',
        'safetyRules' => [
            'Do not publish pages.',
            'Do not open indexing.',
            'Do not change sitemap.xml, robots.txt, canonical routes, prices, deposits, cars, requests, rentals, clients, finance, documents, users, roles or permissions.',
            'Wordstat live requires separate special confirmation.',
            'Direction sessions must stay inside the selected direction and budget.',
        ],
        'responseSchema' => demand_ai_dialog_response_schema(),
    ];
}

function demand_ai_dialog_variable_prompt_payload(array $localPlan, string $scopeFilter): array
{
    $directionSession = is_array($localPlan['directionSession'] ?? null) ? $localPlan['directionSession'] : [];
    $payload = [
        'dialogIntent' => (string) ($localPlan['dialogIntent'] ?? ''),
        'userGoalSummary' => demand_ai_dialog_redact_text((string) ($localPlan['userGoalSummary'] ?? ''), 1000),
        'directionSession' => $directionSession ? [
            'directionId' => (string) ($directionSession['directionId'] ?? ''),
            'directionTitle' => (string) ($directionSession['directionTitle'] ?? ''),
            'budgetMode' => (string) ($directionSession['budgetMode'] ?? 'economy'),
            'budgetLimits' => (array) ($directionSession['budgetLimits'] ?? []),
            'processingFingerprint' => (string) ($directionSession['processingFingerprint'] ?? ''),
        ] : null,
        'workflowDraft' => [
            'safeToRunNow' => array_map(static fn(array $item): array => [
                'action' => (string) ($item['action'] ?? ''),
                'label' => (string) ($item['label'] ?? ''),
                'writesData' => !empty($item['writesData']),
            ], (array) ($localPlan['safeToRunNow'] ?? [])),
            'requiresConfirmation' => array_map(static fn(array $item): array => [
                'action' => (string) ($item['action'] ?? ''),
                'label' => (string) ($item['label'] ?? ''),
                'writesData' => !empty($item['writesData']),
            ], (array) ($localPlan['requiresConfirmation'] ?? [])),
            'forbiddenActions' => (array) ($localPlan['forbiddenActions'] ?? []),
        ],
        'expectedResult' => [
            'priorityActions' => array_slice((array) ($localPlan['expectedResult']['priorityActions'] ?? []), 0, 8),
            'faqProposals' => array_slice((array) ($localPlan['expectedResult']['faqProposals'] ?? []), 0, 6),
        ],
    ];

    if ($directionSession) {
        $payload['screen'] = [
            'currentTab' => demand_ai_safe_string((string) ($localPlan['currentTab'] ?? ''), 80),
            'scopeId' => demand_ai_safe_string((string) ($localPlan['scope_id'] ?? ''), 80),
        ];
    } else {
        $payload['screen'] = demand_ai_api_screen_context((string) ($localPlan['currentTab'] ?? ''), $scopeFilter);
    }

    return $payload;
}

function demand_ai_dialog_build_api_context(array $localPlan, string $scopeFilter): array
{
    // Keep volatile UI metadata out of the provider prompt. Stable contract stays
    // first for cache reuse; direction/user data is isolated below.
    return [
        'stablePromptContract' => demand_ai_dialog_stable_prompt_contract(),
        'variableDirectionPayload' => demand_ai_dialog_variable_prompt_payload($localPlan, $scopeFilter),
    ];
}

function demand_ai_dialog_try_api_enrich(array $localPlan, string $scopeFilter): array
{
    $settings = function_exists('openai_ai_settings') ? openai_ai_settings() : [];
    if (empty($settings['enabled']) || empty($settings['apiKeyConfigured'])) {
        return $localPlan;
    }

    $actor = current_admin_user() ?: 'system';
    $limit = openai_ai_limit_status($actor, $settings);
    if (!empty($limit['blocked'])) {
        $localPlan['apiError'] = (string) ($limit['message'] ?? '');
        return $localPlan;
    }

    $context = demand_ai_dialog_build_api_context($localPlan, $scopeFilter);
    $prompt = json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($prompt === false) {
        return $localPlan;
    }
    $runBase = [
        'id' => 'aidlgapi_' . bin2hex(random_bytes(8)),
        'createdAt' => now_iso(),
        'actor' => $actor,
        'scope_id' => (string) ($localPlan['scope_id'] ?? 'rent_rk'),
        'task' => 'dialog:' . (string) ($localPlan['dialogIntent'] ?? ''),
        'entityType' => (string) ($localPlan['entityType'] ?? ''),
        'entityId' => (string) ($localPlan['entityId'] ?? ''),
        'model' => (string) ($settings['model'] ?? 'deepseek-v4-flash'),
        'promptHash' => openai_ai_hash_value($context),
    ];

    try {
        $raw = openai_ai_send_request(
            demand_ai_dialog_system_instructions(),
            $prompt,
            demand_ai_dialog_response_schema(),
            [
                'model' => (string) ($settings['model'] ?? 'deepseek-v4-flash'),
                'timeoutSeconds' => (int) ($settings['perRequestTimeoutSeconds'] ?? 45),
                'retryCount' => (int) ($settings['retryCount'] ?? 0),
            ]
        );
        $response = is_array($raw['response'] ?? null) ? $raw['response'] : [];
        $intent = demand_ai_safe_string($response['dialogIntent'] ?? '', 80);
        if (in_array($intent, demand_ai_dialog_allowed_intents(), true)) {
            $localPlan['dialogIntent'] = $intent;
        }
        $summary = demand_ai_safe_string($response['summary'] ?? '', 1000);
        if ($summary !== '') {
            $localPlan['summary'] = $summary;
        }
        $understood = demand_ai_safe_list($response['whatIUnderstood'] ?? [], 8, 300);
        if ($understood) {
            $localPlan['whatIUnderstood'] = $understood;
        }
        $important = demand_ai_safe_list($response['importantFindings'] ?? [], 8, 400);
        if ($important) {
            $localPlan['importantFindings'] = $important;
        }
        $risks = [];
        foreach ((array) ($response['risks'] ?? []) as $risk) {
            if (!is_array($risk)) {
                continue;
            }
            $message = demand_ai_safe_string($risk['message'] ?? '', 500);
            if ($message !== '') {
                $level = demand_ai_safe_string($risk['level'] ?? 'medium', 40);
                $risks[] = [
                    'level' => in_array($level, ['low', 'medium', 'high', 'blocked'], true) ? $level : 'medium',
                    'message' => $message,
                ];
            }
        }
        if ($risks) {
            $localPlan['risks'] = array_values(array_merge($risks, (array) ($localPlan['risks'] ?? [])));
        }
        if (is_array($response['nextStep'] ?? null)) {
            $localPlan['nextStep'] = [
                'label' => demand_ai_safe_string($response['nextStep']['label'] ?? '', 240),
                'reason' => demand_ai_safe_string($response['nextStep']['reason'] ?? '', 700),
                'safe' => !empty($response['nextStep']['safe']),
            ];
        }
        $run = openai_ai_log_run(array_merge($runBase, [
            'model' => (string) ($raw['model'] ?? $runBase['model']),
            'status' => 'success',
            'responseHash' => (string) ($raw['responseHash'] ?? openai_ai_hash_value($response)),
            'inputTokens' => (int) ($raw['inputTokens'] ?? 0),
            'outputTokens' => (int) ($raw['outputTokens'] ?? 0),
        ]));
        $localPlan['apiUsed'] = true;
        $localPlan['promptHash'] = (string) ($run['promptHash'] ?? '');
        $localPlan['responseHash'] = (string) ($run['responseHash'] ?? '');
    } catch (Throwable $exception) {
        $error = openai_ai_sanitize_error($exception->getMessage());
        openai_ai_log_run(array_merge($runBase, [
            'status' => 'error',
            'errorCode' => 'dialog_request_failed',
            'sanitizedError' => $error,
        ]));
        $localPlan['apiError'] = $error;
    }

    return $localPlan;
}

function demand_ai_dialog_ask(string $message, string $scopeFilter, string $currentTab = '', string $entityType = '', string $entityId = '', array $options = []): array
{
    $plan = demand_ai_dialog_build_local_plan($message, $scopeFilter, $currentTab, $entityType, $entityId, $options);
    $directionSession = is_array($plan['directionSession'] ?? null) ? $plan['directionSession'] : [];
    if ($directionSession && function_exists('demand_ai_latest_run_for_direction')) {
        $latestRun = demand_ai_latest_run_for_direction((string) ($directionSession['directionId'] ?? ''));
        $fingerprint = (string) ($directionSession['processingFingerprint'] ?? '');
        if ($latestRun
            && $fingerprint !== ''
            && (string) ($latestRun['processingFingerprint'] ?? '') === $fingerprint
            && in_array((string) ($latestRun['stopReason'] ?? ''), ['completed', 'needs_confirmation', 'needs_human_decision'], true)
        ) {
            $plan['status'] = 'completed';
            $plan['stopReason'] = 'stale_fingerprint_reused';
            $plan['reusedRunId'] = (string) ($latestRun['runId'] ?? '');
            $plan['summary'] = 'Это направление уже обработано, данные не изменились. Можно открыть готовые материалы без повторного расхода лимитов.';
            $state = demand_ai_dialog_state();
            $state['messages'][] = [
                'role' => 'user',
                'text' => demand_ai_dialog_redact_text($message, 1000),
                'createdAt' => now_iso(),
            ];
            $state['messages'][] = [
                'role' => 'assistant',
                'text' => (string) $plan['summary'],
                'createdAt' => now_iso(),
            ];
            $state['workflow'] = $plan;
            $state['lastResult'] = [
                'action' => 'reuse_direction_session',
                'changed' => false,
                'message' => (string) $plan['summary'],
            ];
            demand_ai_dialog_save_state($state);

            return $plan;
        }
    }
    if (!empty($plan['requiresDirectionSelection'])) {
        $state = demand_ai_dialog_state();
        $state['messages'][] = [
            'role' => 'user',
            'text' => demand_ai_dialog_redact_text($message, 1000),
            'createdAt' => now_iso(),
        ];
        $state['messages'][] = [
            'role' => 'assistant',
            'text' => (string) ($plan['summary'] ?? ''),
            'createdAt' => now_iso(),
        ];
        $state['workflow'] = $plan;
        $state['lastResult'] = [
            'action' => 'route_broad_prompt_to_direction_queue',
            'changed' => false,
            'message' => (string) ($plan['summary'] ?? ''),
        ];
        demand_ai_dialog_save_state($state);

        return $plan;
    }
    $plan = demand_ai_dialog_try_api_enrich($plan, $scopeFilter);
    $plan['status'] = 'running';
    $state = demand_ai_dialog_state();
    $state['messages'][] = [
        'role' => 'user',
        'text' => demand_ai_dialog_redact_text($message, 1000),
        'createdAt' => now_iso(),
    ];
    $state['messages'][] = [
        'role' => 'assistant',
        'text' => (string) ($plan['summary'] ?? ''),
        'createdAt' => now_iso(),
    ];
    $state['workflow'] = $plan;
    $state['lastResult'] = null;
    demand_ai_dialog_save_state($state);

    $autoResults = [];
    $initialAutoActions = demand_ai_dialog_initial_auto_actions($plan);
    foreach ($initialAutoActions as $autoActionId) {
        try {
            $autoResults[] = demand_ai_dialog_execute_action((string) ($plan['id'] ?? ''), $autoActionId, $scopeFilter);
        } catch (Throwable $exception) {
            $latest = demand_ai_dialog_state();
            $workflow = is_array($latest['workflow'] ?? null) ? $latest['workflow'] : $plan;
            $workflow['status'] = 'failed';
            $workflow['errorCode'] = 'auto_action_failed';
            $workflow['sanitizedError'] = demand_ai_dialog_redact_text($exception->getMessage(), 700);
            $latest['workflow'] = $workflow;
            $latest['lastResult'] = [
                'action' => $autoActionId,
                'changed' => false,
                'message' => 'AI workflow остановился на безопасном шаге: ' . (string) $workflow['sanitizedError'],
            ];
            demand_ai_dialog_save_state($latest);
            throw $exception;
        }
    }

    $state = demand_ai_dialog_state();
    $workflow = is_array($state['workflow'] ?? null) ? $state['workflow'] : $plan;
    $workflow['status'] = demand_ai_dialog_derive_workflow_status($workflow);
    $workflow['autoExecutedActions'] = array_values(array_filter(array_map(static fn(array $item): string => (string) ($item['action'] ?? ''), $autoResults)));
    $directionSession = is_array($workflow['directionSession'] ?? null) ? $workflow['directionSession'] : [];
    if ($directionSession) {
        $budgetLimit = (int) ($directionSession['budgetLimits']['maxAiCalls'] ?? 0);
        if ($budgetLimit > 0 && count($initialAutoActions) >= $budgetLimit && count((array) ($workflow['safeToRunNow'] ?? [])) > $budgetLimit) {
            $workflow['stopReason'] = 'budget_limit_reached';
            $workflow['status'] = 'waiting_confirmation';
        } elseif (demand_ai_dialog_workflow_has_pending_confirmation($workflow)) {
            $workflow['stopReason'] = 'needs_confirmation';
        } else {
            $workflow['stopReason'] = 'completed';
        }
        if (function_exists('demand_ai_append_run_history')) {
            $changedFiles = [];
            foreach ($autoResults as $result) {
                if (empty($result['changed'])) {
                    continue;
                }
                $action = (string) ($result['action'] ?? '');
                if ($action === 'save_ai_seed_keywords') {
                    $changedFiles[] = 'private/rent-rk-data/demand-keywords.json';
                } elseif ($action === 'recalculate_recommendations') {
                    $changedFiles[] = 'private/rent-rk-data/demand-recommendations.json';
                } elseif ($action === 'recalculate_demand_map') {
                    $changedFiles[] = 'private/rent-rk-data/demand-clusters.json';
                    $changedFiles[] = 'private/rent-rk-data/seo-launch-plan.json';
                } elseif ($action === 'create_ai_content_brief') {
                    $changedFiles[] = 'private/rent-rk-data/demand-content-briefs.json';
                } elseif ($action === 'create_car_card_hint') {
                    $changedFiles[] = 'private/rent-rk-data/demand-card-optimization-hints.json';
                }
            }
            $history = demand_ai_append_run_history([
                'sessionId' => (string) ($directionSession['sessionId'] ?? $workflow['id'] ?? ''),
                'directionId' => (string) ($directionSession['directionId'] ?? ''),
                'directionTitle' => (string) ($directionSession['directionTitle'] ?? ''),
                'startedAt' => (string) ($directionSession['startedAt'] ?? $workflow['createdAt'] ?? now_iso()),
                'finishedAt' => now_iso(),
                'startedBy' => is_array($directionSession['startedBy'] ?? null) ? $directionSession['startedBy'] : [],
                'budgetMode' => (string) ($directionSession['budgetMode'] ?? 'economy'),
                'summaryForOwner' => 'AI обработал направление в режиме ' . (string) ($directionSession['budgetMode'] ?? 'economy') . '. Выполнены безопасные подготовительные шаги; публикация, индексация, sitemap, robots и бизнес-данные не менялись.',
                'completedActionLabels' => array_values(array_filter(array_map(static fn(array $item): string => (string) ($item['message'] ?? $item['action'] ?? ''), $autoResults))),
                'createdObjectLabels' => [
                    'AI seed-фразы: ' . count((array) ($workflow['createdKeywordIds'] ?? [])),
                    'ТЗ: ' . count((array) ($workflow['createdBriefIds'] ?? [])),
                    'Черновики: ' . count((array) ($workflow['createdDraftIds'] ?? [])),
                    'Подсказки авто: ' . count((array) ($workflow['createdHintIds'] ?? [])),
                ],
                'changedFiles' => array_values(array_unique($changedFiles)),
                'stopReason' => (string) ($workflow['stopReason'] ?? 'completed'),
                'estimatedCostLabel' => 'AI: в пределах режима; Wordstat live не запускался.',
                'tokenEstimate' => [
                    'input' => null,
                    'output' => null,
                    'total' => null,
                ],
                'wordstatCostEstimate' => [
                    'requests' => 0,
                    'estimatedRub' => 0.0,
                ],
                'notChangedLabel' => function_exists('demand_ai_protected_non_change_guarantees') ? demand_ai_protected_non_change_guarantees() : [],
                'processingFingerprint' => (string) ($directionSession['processingFingerprint'] ?? ''),
            ]);
            $workflow['directionSession']['historyRunId'] = (string) ($history['runId'] ?? '');
        }
    }
    $state['workflow'] = $workflow;
    if ($autoResults) {
        $createdKeywords = count((array) ($workflow['createdKeywordIds'] ?? []));
        $state['messages'][] = [
            'role' => 'assistant',
            'text' => 'Готово: безопасные подготовительные шаги выполнены. AI seed-фраз создано: ' . $createdKeywords . '. Публикация, индекс, sitemap и robots не менялись.',
            'createdAt' => now_iso(),
        ];
    }
    demand_ai_dialog_save_state($state);

    return $workflow;
}

function demand_ai_dialog_find_action(array $workflow, string $actionId): ?array
{
    foreach (['safeToRunNow', 'requiresConfirmation', 'specialConfirmation'] as $bucket) {
        foreach ((array) ($workflow[$bucket] ?? []) as $action) {
            if (is_array($action) && (string) ($action['id'] ?? '') === $actionId) {
                $action['bucket'] = $bucket;
                return $action;
            }
        }
    }

    return null;
}

function demand_ai_dialog_update_action_status(array &$workflow, string $actionId, string $status, string $message = ''): void
{
    foreach (['safeToRunNow', 'requiresConfirmation', 'specialConfirmation'] as $bucket) {
        foreach ((array) ($workflow[$bucket] ?? []) as $index => $action) {
            if (is_array($action) && (string) ($action['id'] ?? '') === $actionId) {
                $workflow[$bucket][$index]['status'] = $status;
                if ($message !== '') {
                    $workflow[$bucket][$index]['resultMessage'] = demand_ai_safe_string($message, 500);
                }
            }
        }
    }
    $workflow['actionStatuses'][$actionId] = [
        'status' => $status,
        'message' => demand_ai_safe_string($message, 500),
        'updatedAt' => now_iso(),
    ];
    $workflow['updatedAt'] = now_iso();
}

function demand_ai_dialog_save_seed_keywords(array &$workflow): array
{
    $seedAnalyses = (array) ($workflow['seedAnalyses'] ?? []);
    if (!$seedAnalyses) {
        return ['created' => [], 'skipped' => 0];
    }
    $data = read_demand_keywords();
    $existing = demand_existing_keyword_map();
    $created = [];
    $skipped = 0;
    foreach ($seedAnalyses as $analysis) {
        $keyword = is_array($analysis['keyword'] ?? null) ? $analysis['keyword'] : [];
        if (!$keyword) {
            continue;
        }
        $keyword['source'] = 'ai_suggested_seed';
        $keyword['frequency'] = 0;
        $keyword['comment'] = 'AI seed: проверить через Wordstat перед решением о странице.';
        $key = demand_keyword_duplicate_key($keyword);
        if (isset($existing[$key])) {
            $skipped++;
            continue;
        }
        $normalized = demand_normalize_keyword_record($keyword);
        $normalized['id'] = 'dk_ai_seed_' . substr(hash('sha1', (string) ($normalized['scope_id'] ?? '') . '|' . (string) ($normalized['phrase'] ?? '') . '|' . now_iso()), 0, 16);
        $normalized['source'] = 'ai_suggested_seed';
        $normalized['frequency'] = 0;
        $normalized['comment'] = 'AI seed: проверить через Wordstat перед решением о странице.';
        $data['items'][] = $normalized;
        $existing[demand_keyword_duplicate_key($normalized)] = $normalized;
        $created[] = $normalized;
    }
    save_demand_keywords($data);
    $workflow['createdKeywordIds'] = array_values(array_unique(array_merge((array) ($workflow['createdKeywordIds'] ?? []), array_map(static fn(array $item): string => (string) ($item['id'] ?? ''), $created))));
    analytics_record_event('demand_ai_dialog_seed_keywords_saved', [
        'scopeId' => (string) ($workflow['scope_id'] ?? 'rent_rk'),
        'entityType' => 'demand_ai_dialog',
        'entityId' => (string) ($workflow['id'] ?? ''),
        'meta' => ['created' => count($created), 'skipped' => $skipped],
    ]);

    return ['created' => $created, 'skipped' => $skipped];
}

function demand_ai_dialog_plans_for_workflow(array $workflow, string $scopeFilter): array
{
    $keywordIds = array_values(array_filter(array_map('strval', (array) ($workflow['createdKeywordIds'] ?? []))));
    if (!$keywordIds) {
        return array_slice(demand_map_visible_launch_plan($scopeFilter), 0, 6);
    }
    $plans = [];
    foreach (demand_map_visible_launch_plan($scopeFilter) as $plan) {
        if (array_intersect($keywordIds, (array) ($plan['linkedKeywordIds'] ?? []))) {
            $plans[] = $plan;
        }
    }

    return $plans;
}

function demand_ai_dialog_execute_action(string $workflowId, string $actionId, string $scopeFilter, array $payload = []): array
{
    $state = demand_ai_dialog_state();
    $workflow = is_array($state['workflow'] ?? null) ? $state['workflow'] : [];
    if (!$workflow || (string) ($workflow['id'] ?? '') !== $workflowId) {
        throw new RuntimeException('Диалоговый workflow устарел. Задайте вопрос заново.');
    }
    if ((string) ($workflow['status'] ?? '') === 'cancelled') {
        throw new RuntimeException('Диалоговый workflow остановлен. Создайте новый план, если нужно продолжить.');
    }
    $actionCard = demand_ai_dialog_find_action($workflow, $actionId);
    if (!$actionCard) {
        throw new RuntimeException('Действие не найдено в текущем workflow.');
    }
    $action = (string) ($actionCard['action'] ?? '');
    $executorAction = [
        'create_ai_content_brief' => 'create_content_brief_from_ai_plan',
        'create_safe_landing_draft' => 'create_safe_landing_draft_from_ai_plan',
        'create_safe_landing_drafts_batch' => 'create_safe_landing_draft_from_ai_plan',
        'classify_ai_seed_phrases' => 'classify_saved_ai_keywords',
        'save_workflow_result_summary' => 'save_ai_workflow_summary',
    ][$action] ?? $action;
    $registry = demand_ai_dialog_action_registry();
    $definition = $registry[$action] ?? null;
    if (!$definition || (string) ($definition['kind'] ?? '') === 'forbidden') {
        throw new RuntimeException('Это действие запрещено для диалогового AI workflow.');
    }
    $permission = (string) ($definition['permission'] ?? '');
    if ($permission !== '') {
        demand_ai_dialog_require($permission);
    }
    if (!empty($definition['requiresExplicitConfirmation']) && empty($payload['explicit_confirm'])) {
        throw new RuntimeException('Для этого действия нужно отдельное подтверждение.');
    }

    $result = ['action' => $action, 'changed' => false, 'message' => 'Действие выполнено без записи данных.'];
    if (in_array($executorAction, ['generate_seed_phrases', 'analyze_current_tab', 'build_action_plan', 'clean_irrelevant_queries'], true)) {
        $result['message'] = 'План уже показан. Данные не изменялись.';
    } elseif ($executorAction === 'build_priority_summary') {
        $result['priorityActions'] = array_slice((array) ($workflow['expectedResult']['priorityActions'] ?? []), 0, 12);
        $result['message'] = 'Приоритеты собраны в карточке результата. Данные не изменялись.';
    } elseif ($executorAction === 'prepare_human_landing_copy') {
        $draftId = demand_ai_safe_string($payload['draft_id'] ?? $workflow['entityId'] ?? '', 120);
        if ($draftId === '') {
            throw new RuntimeException('Выберите черновик для подготовки живого текста.');
        }
        $draft = demand_find_draft($draftId);
        $copySettings = $draft ? demand_ai_draft_copy_settings($draft) : demand_ai_copy_settings();
        $generated = demand_ai_copy_generate_preview($draftId, 'make_copy_more_human', $scopeFilter, [
            'style' => (string) ($copySettings['defaultStyle'] ?? 'calm_human'),
            'baseInstruction' => (string) ($copySettings['defaultBaseInstruction'] ?? demand_ai_copy_default_base_instruction()),
            'avoid' => (array) ($copySettings['avoidList'] ?? []),
            'emphasis' => (array) ($copySettings['defaultEmphasisList'] ?? []),
            'preserveSeoMeaning' => true,
            'reduceKeywordRepeats' => true,
            'preserveFacts' => true,
            'noUnconfirmedPromises' => true,
        ]);
        $_SESSION['demand_ai_copy_latest'] = [
            'token' => 'aicopy_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
            'entityType' => 'draft',
            'entityId' => $draftId,
            'task' => 'make_copy_more_human',
            'source' => (string) ($generated['source'] ?? 'local_safe_fallback'),
            'run' => (array) ($generated['run'] ?? []),
            'response' => (array) ($generated['response'] ?? []),
            'proposal' => (array) ($generated['proposal'] ?? []),
            'diff' => is_array($generated['diff'] ?? null) ? $generated['diff'] : null,
            'request' => (array) ($generated['request'] ?? []),
            'createdAt' => now_iso(),
        ];
        $result['message'] = 'Живой вариант текста подготовлен в preview/diff выбранного черновика. Публикация, индексация, sitemap и robots.txt не менялись.';
        $result['draftId'] = $draftId;
    } elseif ($executorAction === 'suggest_internal_links') {
        $draftId = demand_ai_safe_string($payload['draft_id'] ?? $workflow['entityId'] ?? '', 120);
        if ($draftId === '') {
            throw new RuntimeException('Выберите черновик для подбора внутренних ссылок.');
        }
        $draft = demand_find_draft($draftId);
        if (!$draft) {
            throw new RuntimeException('Черновик не найден.');
        }
        demand_scope_guard($draft, 'demand.drafts.edit');
        $suggestions = demand_suggest_internal_links_for_draft($draft);
        $_SESSION['demand_internal_links_latest'] = [
            'token' => 'dil_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
            'draftId' => $draftId,
            'suggestions' => $suggestions,
            'createdAt' => now_iso(),
        ];
        $workflow['internalLinkSuggestions'] = $suggestions;
        $result['suggestions'] = $suggestions;
        $result['draftId'] = $draftId;
        $result['message'] = 'Варианты внутренних ссылок подготовлены. Добавление в черновик выполняется только после группового подтверждения; публикация, индексация, sitemap и robots.txt не менялись.';
    } elseif ($executorAction === 'save_ai_workflow_summary') {
        $workflow['resultSummary'] = [
            'createdKeywordCount' => count((array) ($workflow['createdKeywordIds'] ?? [])),
            'createdBriefCount' => count((array) ($workflow['createdBriefIds'] ?? [])),
            'createdDraftCount' => count((array) ($workflow['createdDraftIds'] ?? [])),
            'createdHintCount' => count((array) ($workflow['createdHintIds'] ?? [])),
            'safeNote' => 'Публикация, индексация, sitemap, robots и бизнес-данные не менялись.',
            'updatedAt' => now_iso(),
        ];
        $result['message'] = 'Краткий итог workflow сохранен в текущей session-памяти без полного prompt/response.';
    } elseif ($executorAction === 'save_ai_seed_keywords') {
        $saved = demand_ai_dialog_save_seed_keywords($workflow);
        $result['changed'] = count((array) ($saved['created'] ?? [])) > 0;
        $result['createdKeywordIds'] = array_map(static fn(array $item): string => (string) ($item['id'] ?? ''), (array) ($saved['created'] ?? []));
        $result['message'] = 'AI seed-фразы сохранены как идеи: ' . count((array) ($saved['created'] ?? [])) . ', пропущено дублей: ' . (int) ($saved['skipped'] ?? 0) . '.';
    } elseif ($executorAction === 'classify_saved_ai_keywords') {
        $active = 0;
        $excluded = 0;
        foreach ((array) ($workflow['createdKeywordIds'] ?? []) as $keywordId) {
            $keyword = demand_find_keyword((string) $keywordId);
            if (!$keyword) {
                continue;
            }
            if ((string) ($keyword['status'] ?? '') === 'excluded' || (string) ($keyword['negativeIntent'] ?? '') !== '') {
                $excluded++;
            } else {
                $active++;
            }
        }
        $result['message'] = 'Stage A/B/C классификация готова: активных AI-фраз ' . $active . ', исключенных ' . $excluded . '.';
    } elseif ($executorAction === 'mark_irrelevant_ai_keywords') {
        $excluded = [];
        foreach ((array) ($workflow['createdKeywordIds'] ?? []) as $keywordId) {
            $keyword = demand_find_keyword((string) $keywordId);
            if ($keyword && ((string) ($keyword['status'] ?? '') === 'excluded' || (string) ($keyword['negativeIntent'] ?? '') !== '')) {
                $excluded[] = (string) ($keyword['phrase'] ?? $keywordId);
            }
        }
        $workflow['excludedKeywordPhrases'] = array_slice($excluded, 0, 20);
        $result['message'] = 'Нецелевые AI-фразы отделены и не пойдут в страницы/ТЗ/черновики: ' . count($excluded) . '.';
    } elseif ($executorAction === 'recalculate_recommendations') {
        $count = 0;
        foreach ((array) ($workflow['createdKeywordIds'] ?? []) as $keywordId) {
            $keyword = demand_find_keyword((string) $keywordId);
            if ($keyword && (string) ($keyword['status'] ?? '') === 'active' && (string) ($keyword['negativeIntent'] ?? '') === '') {
                demand_recalculate_keyword_recommendations((string) $keywordId);
                $count++;
            }
        }
        $result['changed'] = $count > 0;
        $result['message'] = 'Рекомендации пересчитаны для seed-фраз: ' . $count . '.';
    } elseif ($executorAction === 'recalculate_demand_map') {
        $map = demand_map_recalculate($scopeFilter);
        $result['changed'] = true;
        $result['message'] = 'Карта спроса пересчитана: групп ' . (int) ($map['clusters'] ?? 0) . ', пунктов плана ' . (int) ($map['plans'] ?? 0) . '.';
    } elseif ($executorAction === 'create_content_brief_from_ai_plan') {
        if (empty($workflow['createdKeywordIds'])) {
            demand_ai_dialog_save_seed_keywords($workflow);
        }
        demand_map_recalculate($scopeFilter);
        $created = [];
        foreach (demand_ai_dialog_plans_for_workflow($workflow, $scopeFilter) as $plan) {
            if (in_array((string) ($plan['priority'] ?? ''), ['blocked', 'needs_business_decision'], true)) {
                continue;
            }
            try {
                $brief = demand_map_create_content_brief((string) ($plan['id'] ?? ''));
                $created[(string) ($brief['id'] ?? '')] = $brief;
                if (count($created) >= 3) {
                    break;
                }
            } catch (Throwable $_exception) {
                continue;
            }
        }
        $workflow['createdBriefIds'] = array_values(array_unique(array_merge((array) ($workflow['createdBriefIds'] ?? []), array_keys($created))));
        $result['changed'] = count($created) > 0;
        $result['createdBriefIds'] = array_keys($created);
        $result['message'] = 'Создано/найдено ТЗ: ' . count($created) . '.';
    } elseif ($executorAction === 'create_safe_landing_draft_from_ai_plan') {
        if (empty($workflow['createdKeywordIds'])) {
            demand_ai_dialog_save_seed_keywords($workflow);
        }
        $directionSession = is_array($workflow['directionSession'] ?? null) ? $workflow['directionSession'] : [];
        $draftLimit = $directionSession ? (int) ($directionSession['budgetLimits']['maxDrafts'] ?? 0) : 2;
        if ($directionSession && $draftLimit <= 0) {
            throw new RuntimeException('Текущий бюджет направления не разрешает создавать черновики. Выберите trusted_economy, standard или deep и подтвердите действие.');
        }
        demand_map_recalculate($scopeFilter);
        $created = [];
        $blocked = 0;
        foreach (demand_ai_dialog_plans_for_workflow($workflow, $scopeFilter) as $plan) {
            if (!in_array((string) ($plan['recommendedAction'] ?? ''), ['create_landing_draft', 'create_city_landing_draft'], true)) {
                continue;
            }
            if (array_intersect((array) ($plan['riskFlags'] ?? []), ['possible_false_promise', 'condition_not_supported', 'no_matching_cars', 'region_not_confirmed', 'unknown_region', 'not_relevant_for_car_rental', 'unsupported_legal_request'])) {
                $blocked++;
                continue;
            }
            try {
                $draft = demand_map_create_landing_draft_from_plan((string) ($plan['id'] ?? ''));
                $created[(string) ($draft['id'] ?? '')] = $draft;
                if (count($created) >= $draftLimit) {
                    break;
                }
            } catch (Throwable $_exception) {
                $blocked++;
            }
        }
        $workflow['createdDraftIds'] = array_values(array_unique(array_merge((array) ($workflow['createdDraftIds'] ?? []), array_keys($created))));
        $result['changed'] = count($created) > 0;
        $result['createdDraftIds'] = array_keys($created);
        $result['message'] = 'Безопасных черновиков создано/найдено: ' . count($created) . '. Заблокировано рисками или дублями: ' . $blocked . '.';
    } elseif ($executorAction === 'create_car_card_hint') {
        if (empty($workflow['createdKeywordIds'])) {
            demand_ai_dialog_save_seed_keywords($workflow);
        }
        demand_map_recalculate($scopeFilter);
        $created = [];
        foreach (demand_ai_dialog_plans_for_workflow($workflow, $scopeFilter) as $plan) {
            try {
                foreach (demand_map_create_card_hints((string) ($plan['id'] ?? '')) as $hint) {
                    $created[(string) ($hint['id'] ?? '')] = $hint;
                }
            } catch (Throwable $_exception) {
                continue;
            }
            if (count($created) >= 5) {
                break;
            }
        }
        $workflow['createdHintIds'] = array_values(array_unique(array_merge((array) ($workflow['createdHintIds'] ?? []), array_keys($created))));
        $result['changed'] = count($created) > 0;
        $result['createdHintIds'] = array_keys($created);
        $result['message'] = 'Создано подсказок для карточек авто: ' . count($created) . '.';
    } elseif ($executorAction === 'add_faq_to_draft') {
        $draftId = demand_ai_safe_string($payload['draft_id'] ?? $workflow['entityId'] ?? '', 120);
        if ($draftId === '') {
            throw new RuntimeException('Выберите черновик для добавления FAQ.');
        }
        $draft = demand_draft_editorial_append_faq($draftId, 0);
        $result['changed'] = true;
        $result['message'] = 'FAQ добавлен в черновик. Готовность нужно проверить заново.';
        $result['draftId'] = (string) ($draft['id'] ?? $draftId);
    } elseif ($executorAction === 'add_safe_block_to_draft') {
        $draftId = demand_ai_safe_string($payload['draft_id'] ?? $workflow['entityId'] ?? '', 120);
        if ($draftId === '') {
            throw new RuntimeException('Выберите черновик для добавления блока.');
        }
        $draft = demand_find_draft($draftId);
        $safeBlocks = (array) ($draft['safeContentBlocks'] ?? []);
        $type = '';
        foreach ($safeBlocks as $block) {
            if (is_array($block)) {
                $candidate = demand_ai_safe_string($block['type'] ?? '', 80);
                if ($candidate !== '') {
                    $type = $candidate;
                    break;
                }
            }
        }
        if ($type === '') {
            throw new RuntimeException('В черновике нет безопасных Stage C блоков для добавления.');
        }
        $draft = demand_draft_editorial_append_safe_block($draftId, $type);
        $result['changed'] = true;
        $result['message'] = 'Безопасный блок добавлен в черновик. Готовность нужно проверить заново.';
        $result['draftId'] = (string) ($draft['id'] ?? $draftId);
    } elseif ($executorAction === 'save_admin_note') {
        $draftId = demand_ai_safe_string($payload['draft_id'] ?? $workflow['entityId'] ?? '', 120);
        if ($draftId === '') {
            throw new RuntimeException('Выберите черновик для заметки.');
        }
        $draft = demand_find_draft($draftId);
        $note = trim((string) ($draft['adminNote'] ?? ''));
        $addition = 'AI dialog: ' . demand_ai_safe_string($workflow['summary'] ?? '', 700);
        $draft = demand_update_draft_admin_note($draftId, trim($note . "\n" . $addition));
        $result['changed'] = true;
        $result['message'] = 'Заметка admin сохранена. Публикация и индексация не менялись.';
        $result['draftId'] = (string) ($draft['id'] ?? $draftId);
    } elseif ($executorAction === 'apply_safe_draft_proposal') {
        if (empty($payload['preview_confirmed'])) {
            throw new RuntimeException('Сначала покажите preview/diff и подтвердите применение вручную.');
        }
        $draftId = demand_ai_safe_string($payload['draft_id'] ?? $workflow['entityId'] ?? '', 120);
        if ($draftId === '') {
            throw new RuntimeException('Выберите черновик для применения предложения.');
        }
        $proposal = $payload['proposal'] ?? [];
        if (is_string($proposal)) {
            $decoded = json_decode($proposal, true);
            $proposal = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($proposal) || $proposal === []) {
            throw new RuntimeException('Нет безопасного предложения для применения.');
        }
        $diff = demand_ai_build_preview_diff('draft', $draftId, $proposal);
        if (empty($diff['applySupported'])) {
            throw new RuntimeException('Предложение нельзя применить без безопасного preview.');
        }
        $applied = demand_ai_apply_manual_proposal('draft', $draftId, $proposal, current_admin_user() ?: 'system');
        $result['changed'] = !empty($applied['changed']);
        $result['message'] = $result['changed']
            ? 'Безопасное предложение применено к черновику. Публикация и индексация не менялись; готовность нужно проверить заново.'
            : 'Предложение не изменило черновик. Публикация и индексация не менялись.';
        $result['draftId'] = $draftId;
    } elseif ($executorAction === 'apply_internal_link_suggestions') {
        $draftId = demand_ai_safe_string($payload['draft_id'] ?? $workflow['entityId'] ?? '', 120);
        if ($draftId === '') {
            throw new RuntimeException('Выберите черновик для добавления внутренних ссылок.');
        }
        $suggestions = [];
        if (isset($payload['suggestions']) && is_array($payload['suggestions'])) {
            $suggestions = (array) $payload['suggestions'];
        } elseif ((string) (($_SESSION['demand_internal_links_latest']['draftId'] ?? '') ?: '') === $draftId) {
            $suggestions = (array) ($_SESSION['demand_internal_links_latest']['suggestions']['internalLinkSuggestions'] ?? []);
        } else {
            $suggestions = (array) ($workflow['internalLinkSuggestions']['internalLinkSuggestions'] ?? []);
        }
        if (!$suggestions) {
            $prepared = demand_suggest_internal_links_for_draft(demand_find_draft($draftId) ?: []);
            $suggestions = (array) ($prepared['internalLinkSuggestions'] ?? []);
        }
        $selected = array_map('intval', (array) ($payload['selectedIndexes'] ?? []));
        $mode = (string) ($payload['mode'] ?? 'all_safe');
        $applied = demand_apply_internal_link_suggestions($draftId, $suggestions, $selected, $mode === 'selected' ? 'selected' : 'all_safe', current_admin_user() ?: 'system');
        unset($_SESSION['demand_internal_links_latest']);
        $result['changed'] = !empty($applied['changed']);
        $result['draftId'] = $draftId;
        $result['message'] = 'Внутренние ссылки добавлены: ' . count((array) ($applied['added'] ?? [])) . '. Черновик остался в прежнем статусе; готовность нужно проверить заново.';
    } elseif ($executorAction === 'apply_safe_brief_proposal') {
        throw new RuntimeException('Предложение к ТЗ можно применять только через preview/diff существующего AI-помощника.');
    } elseif ($executorAction === 'wordstat_dry_run') {
        $directionSession = is_array($workflow['directionSession'] ?? null) ? $workflow['directionSession'] : [];
        $result['changed'] = false;
        $result['directionId'] = (string) ($directionSession['directionId'] ?? '');
        $result['returnAnchor'] = 'simple-ai-workspace';
        $result['message'] = 'Я подготовил карточку Wordstat в AI-помощнике. Добавьте стартовые фразы и регион, если их не хватает, затем запустите проверку без изменения данных.';
        $_SESSION['demand_simple_ai_workspace'] = array_merge(
            function_exists('demand_admin_simple_ai_workspace_defaults') ? demand_admin_simple_ai_workspace_defaults() : [
                'workspaceMode' => 'simple',
                'returnAnchor' => 'simple-ai-workspace',
            ],
            is_array($_SESSION['demand_simple_ai_workspace'] ?? null) ? $_SESSION['demand_simple_ai_workspace'] : [],
            [
                'workspaceMode' => 'simple',
                'activeAiTask' => 'wordstat_dry_run',
                'activeDirectionId' => (string) ($directionSession['directionId'] ?? ''),
                'lastResult' => [
                    'type' => 'wordstat_dry_run_prepare',
                    'title' => 'Проверка Wordstat готовится в этом окне',
                    'summary' => 'Нужно добавить стартовые фразы или выбрать регион, если карточка показывает предупреждение. Мастер Wordstat не является основным шагом.',
                ],
                'returnAnchor' => 'simple-ai-workspace',
            ]
        );
    } elseif ($executorAction === 'wordstat_controlled_live_sync') {
        $result['message'] = 'Live sync не запускается из диалога. Используйте существующий controlled live Wordstat workflow с отдельным подтверждением и правами.';
    } else {
        throw new RuntimeException('Для действия пока нет безопасного executor.');
    }

    demand_ai_dialog_update_action_status($workflow, $actionId, !empty($result['changed']) ? 'done' : 'shown', (string) ($result['message'] ?? ''));
    $workflow['status'] = demand_ai_dialog_derive_workflow_status($workflow);
    $state['workflow'] = $workflow;
    $state['lastResult'] = $result;
    $state['messages'][] = [
        'role' => 'assistant',
        'text' => (string) ($result['message'] ?? ''),
        'createdAt' => now_iso(),
    ];
    demand_ai_dialog_save_state($state);

    return $result;
}
