<?php

declare(strict_types=1);

// Embedded authentication has its own cookie names. Browsers partition these
// cookies by the top-level site; normal first-party login remains unchanged.
const RENT_RK_ADMIN_IFRAME_SESSION = '__Host-rent_rk_admin_iframe';
const RENT_RK_ADMIN_IFRAME_REMEMBER = '__Host-rent_rk_admin_iframe_remember';

function admin_iframe_session_active(): bool
{
    return !empty($GLOBALS['rent_rk_admin_iframe_session']);
}

function admin_iframe_cookie_header(string $header): string
{
    if (!preg_match('/^Set-Cookie:\s*([^=;\s]+)=/i', $header, $match)
        || !in_array($match[1], [RENT_RK_ADMIN_IFRAME_SESSION, RENT_RK_ADMIN_IFRAME_REMEMBER], true)) {
        return $header;
    }

    $parts = explode(';', $header);
    $result = array_shift($parts);
    foreach ($parts as $part) {
        $attribute = strtolower(trim(explode('=', trim($part), 2)[0]));
        if (!in_array($attribute, ['path', 'domain', 'secure', 'httponly', 'samesite', 'partitioned'], true)) {
            $result .= ';' . $part;
        }
    }

    // PHP 8.3/8.4 do not expose Partitioned through session/setcookie options.
    // Rewrite only our two embedded cookies, including rotation and deletion.
    return $result . '; Path=/; Secure; HttpOnly; SameSite=None; Partitioned';
}

function admin_iframe_prepare_session(): void
{
    $GLOBALS['rent_rk_admin_iframe_session'] = false;
    if (PHP_SAPI === 'cli' || session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    $script = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? ''));
    $adminRoute = str_starts_with($script, '/admin/');
    $explicit = $adminRoute && ($_GET['embed'] ?? null) === '1';
    $iframeNavigation = $adminRoute && strtolower((string) ($_SERVER['HTTP_SEC_FETCH_DEST'] ?? '')) === 'iframe';
    $hasEmbeddedCookie = isset($_COOKIE[RENT_RK_ADMIN_IFRAME_SESSION])
        || isset($_COOKIE[RENT_RK_ADMIN_IFRAME_REMEMBER]);
    if (!$explicit && !$iframeNavigation && !$hasEmbeddedCookie) {
        return;
    }

    if (!admin_request_is_https()) {
        http_response_code(400);
        header('Content-Type: text/plain; charset=utf-8');
        exit('Для входа во встроенную админку требуется HTTPS.');
    }

    $GLOBALS['rent_rk_admin_iframe_session'] = true;
    session_name(RENT_RK_ADMIN_IFRAME_SESSION);
    ini_set('session.use_only_cookies', '1');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => true,
        'httponly' => true,
        'samesite' => 'None',
    ]);

    header_register_callback(static function (): void {
        $cookies = array_values(array_filter(headers_list(), static fn(string $header): bool => stripos($header, 'Set-Cookie:') === 0));
        if (!$cookies) {
            return;
        }
        header_remove('Set-Cookie');
        foreach ($cookies as $cookie) {
            header(admin_iframe_cookie_header($cookie), false);
        }
    });
}
