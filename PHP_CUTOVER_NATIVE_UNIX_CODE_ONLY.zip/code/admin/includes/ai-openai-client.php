<?php

declare(strict_types=1);

function openai_ai_default_settings(): array
{
    return [
        'updatedAt' => null,
        'updatedBy' => 'system',
        'enabled' => false,
        'provider' => 'deepseek',
        'mode' => 'manual_assistant',
        'credentialSource' => 'private_file',
        'apiKeyConfigured' => false,
        'baseUrlConfigured' => false,
        'model' => 'deepseek-v4-flash',
        'lastTestAt' => null,
        'lastSuccessAt' => null,
        'lastErrorAt' => null,
        'lastError' => null,
        'lastErrorCode' => null,
        'lastErrorTechnical' => null,
        'dailyRequestLimit' => 100,
        'globalDailyLimit' => 100,
        'perUserDailyLimit' => 30,
        'monthlyRequestLimit' => 1000,
        'maxContextSize' => 35000,
        'perRequestTimeoutSeconds' => 45,
        'retryCount' => 0,
    ];
}

function openai_ai_credentials_path(): string
{
    return defined('DEEPSEEK_CREDENTIALS_FILE')
        ? DEEPSEEK_CREDENTIALS_FILE
        : DATA_DIR . 'secrets/deepseek-credentials.local.json';
}

function openai_ai_read_private_credentials(): array
{
    $path = openai_ai_credentials_path();
    if (!is_file($path)) {
        return [];
    }

    try {
        $data = read_json_file($path, []);
    } catch (Throwable) {
        return [];
    }

    return is_array($data) ? $data : [];
}

function openai_ai_prepare_credentials_dir(string $dir): void
{
    if (!is_dir($dir) && !mkdir($dir, 0775, true)) {
        throw new RuntimeException('Не удалось создать private secrets директорию для DeepSeek.');
    }

    $gitignore = $dir . DIRECTORY_SEPARATOR . '.gitignore';
    if (!is_file($gitignore)) {
        file_put_contents($gitignore, "*\n!.gitignore\n!.htaccess\n", LOCK_EX);
    }

    $htaccess = $dir . DIRECTORY_SEPARATOR . '.htaccess';
    if (!is_file($htaccess)) {
        file_put_contents($htaccess, "Require all denied\nDeny from all\n", LOCK_EX);
    }
}

function openai_ai_write_private_credentials(array $payload): array
{
    require_permission('demand.ai_api.settings.manage');

    $path = openai_ai_credentials_path();
    $existing = openai_ai_read_private_credentials();
    $apiKeyInput = openai_ai_normalize_api_key((string) ($payload['deepseek_api_key'] ?? $payload['apiKey'] ?? ''));
    $baseUrlInput = trim((string) ($payload['deepseek_base_url'] ?? $payload['baseUrl'] ?? ''));
    $modelInput = trim((string) ($payload['deepseek_model'] ?? $payload['model'] ?? ''));

    $apiKey = $apiKeyInput !== '' ? $apiKeyInput : openai_ai_normalize_api_key((string) ($existing['apiKey'] ?? ''));
    if ($apiKey === '') {
        throw new RuntimeException('Введите DeepSeek API key. Пустое поле сохраняет прежний ключ только если private file уже был настроен.');
    }

    $baseUrl = openai_ai_normalize_base_url($baseUrlInput !== '' ? $baseUrlInput : (string) ($existing['baseUrl'] ?? 'https://api.deepseek.com'));
    if (!preg_match('#^https?://#i', $baseUrl)) {
        throw new RuntimeException('DeepSeek base URL должен начинаться с http:// или https://.');
    }

    $model = demand_clean_string($modelInput !== '' ? $modelInput : (string) ($existing['model'] ?? 'deepseek-v4-flash'), 80) ?: 'deepseek-v4-flash';
    $timeout = openai_ai_clamp_int($payload['deepseek_timeout_seconds'] ?? ($existing['timeoutSeconds'] ?? null), 5, 120, 45);

    $data = [
        'apiKey' => substr($apiKey, 0, 4000),
        'baseUrl' => substr($baseUrl, 0, 1000),
        'model' => $model,
        'timeoutSeconds' => $timeout,
        'credentialSource' => 'private_file',
        'updatedAt' => now_iso(),
        'updatedBy' => current_admin_user() ?: 'admin',
    ];
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if (!is_string($json)) {
        throw new RuntimeException('Не удалось подготовить DeepSeek credentials JSON.');
    }
    $json .= PHP_EOL;

    openai_ai_prepare_credentials_dir(dirname($path));
    $tempPath = $path . '.tmp.' . bin2hex(random_bytes(6));
    if (file_put_contents($tempPath, $json, LOCK_EX) === false) {
        @unlink($tempPath);
        throw new RuntimeException('Не удалось записать временный DeepSeek credentials файл.');
    }

    $verifyRaw = file_get_contents($tempPath);
    $verify = is_string($verifyRaw) ? json_decode($verifyRaw, true) : null;
    if (!is_array($verify) || openai_ai_normalize_api_key((string) ($verify['apiKey'] ?? '')) === '') {
        @unlink($tempPath);
        throw new RuntimeException('DeepSeek credentials JSON не прошёл проверку перед сохранением.');
    }

    if (!rename($tempPath, $path)) {
        @unlink($tempPath);
        throw new RuntimeException('Не удалось сохранить DeepSeek credentials файл.');
    }
    @chmod($path, 0600);

    openai_ai_update_settings_meta([
        'lastErrorAt' => null,
        'lastError' => null,
        'lastErrorCode' => null,
        'lastErrorTechnical' => null,
    ]);

    audit_log('demand.ai_api.credentials.saved', 'demand_ai_api', 'credentials', 'DeepSeek private credentials saved from Demand admin.', [
        'apiKeyConfigured' => true,
        'baseUrlConfigured' => true,
        'model' => $model,
        'credentialSource' => (string) (openai_ai_credentials_metadata()['credentialSource'] ?? 'private_file'),
    ]);

    return openai_ai_settings();
}

function openai_ai_clear_private_credentials(): array
{
    require_permission('demand.ai_api.settings.manage');

    $path = openai_ai_credentials_path();
    if (is_file($path) && !unlink($path)) {
        throw new RuntimeException('Не удалось удалить private DeepSeek credentials file.');
    }

    openai_ai_update_settings_meta([
        'lastErrorAt' => null,
        'lastError' => null,
        'lastErrorCode' => null,
        'lastErrorTechnical' => null,
    ]);

    audit_log('demand.ai_api.credentials.cleared', 'demand_ai_api', 'credentials', 'DeepSeek private credentials removed from Demand admin.', [
        'envStillConfigured' => !empty(openai_ai_credentials_metadata()['apiKeyConfigured']),
        'credentialSource' => (string) (openai_ai_credentials_metadata()['credentialSource'] ?? 'not_configured'),
    ]);

    return openai_ai_settings();
}

function openai_ai_settings_path(): string
{
    return defined('DEMAND_AI_SETTINGS_FILE')
        ? DEMAND_AI_SETTINGS_FILE
        : DATA_DIR . 'ai-settings.json';
}

function openai_ai_runs_path(): string
{
    return defined('AI_API_RUNS_FILE')
        ? AI_API_RUNS_FILE
        : DATA_DIR . 'ai-api-runs.json';
}

function openai_ai_normalize_base_url(string $baseUrl): string
{
    $baseUrl = trim($baseUrl);
    if ($baseUrl === '') {
        return 'https://api.deepseek.com';
    }

    return rtrim($baseUrl, '/');
}

function openai_ai_normalize_api_key(string $apiKey): string
{
    $apiKey = trim($apiKey);
    if ($apiKey === '' || stripos($apiKey, 'PASTE_') !== false || stripos($apiKey, 'YOUR_') !== false) {
        return '';
    }

    return $apiKey;
}

function openai_ai_private_credentials(): array
{
    $credentials = openai_ai_read_private_credentials();

    $envApiKey = trim((string) getenv('DEEPSEEK_API_KEY'));
    $envBaseUrl = trim((string) getenv('DEEPSEEK_BASE_URL'));
    $envModel = trim((string) getenv('DEEPSEEK_MODEL'));
    $envTimeout = trim((string) getenv('DEEPSEEK_TIMEOUT_SECONDS'));

    if ($envApiKey !== '') {
        $credentials['apiKey'] = $envApiKey;
        $credentials['credentialSource'] = 'env';
    }
    if ($envBaseUrl !== '') {
        $credentials['baseUrl'] = $envBaseUrl;
    }
    if ($envModel !== '') {
        $credentials['model'] = $envModel;
    }
    if ($envTimeout !== '') {
        $credentials['timeoutSeconds'] = (int) $envTimeout;
    }

    return [
        'apiKey' => openai_ai_normalize_api_key((string) ($credentials['apiKey'] ?? '')),
        'baseUrl' => openai_ai_normalize_base_url((string) ($credentials['baseUrl'] ?? 'https://api.deepseek.com')),
        'model' => trim((string) ($credentials['model'] ?? '')),
        'timeoutSeconds' => max(1, min(120, (int) ($credentials['timeoutSeconds'] ?? 0))),
        'credentialSource' => (string) ($credentials['credentialSource'] ?? 'private_file'),
    ];
}

function openai_ai_credentials_metadata(): array
{
    $credentials = openai_ai_private_credentials();

    return [
        'credentialSource' => (string) ($credentials['credentialSource'] ?? 'private_file'),
        'apiKeyConfigured' => (string) ($credentials['apiKey'] ?? '') !== '',
        'baseUrlConfigured' => (string) ($credentials['baseUrl'] ?? '') !== '',
        'configuredModel' => (string) ($credentials['model'] ?? ''),
    ];
}

function openai_ai_clamp_int($value, int $min, int $max, int $fallback): int
{
    $number = is_numeric($value) ? (int) $value : $fallback;

    return max($min, min($max, $number));
}

function openai_ai_settings(): array
{
    $default = openai_ai_default_settings();
    $path = openai_ai_settings_path();
    $data = is_file($path) ? read_json_file($path, $default) : $default;
    $settings = array_merge($default, is_array($data) ? $data : []);
    $storedProvider = is_array($data) ? (string) ($data['provider'] ?? '') : '';
    $credentials = openai_ai_credentials_metadata();

    $settings['enabled'] = !empty($settings['enabled']);
    $settings['provider'] = 'deepseek';
    $settings['mode'] = 'manual_assistant';
    $settings['credentialSource'] = (string) ($credentials['credentialSource'] ?: 'private_file');
    $settings['apiKeyConfigured'] = !empty($credentials['apiKeyConfigured']);
    $settings['baseUrlConfigured'] = !empty($credentials['baseUrlConfigured']);
    if ((string) ($settings['model'] ?? '') === '' && (string) ($credentials['configuredModel'] ?? '') !== '') {
        $settings['model'] = (string) $credentials['configuredModel'];
    }
    if ($storedProvider !== '' && $storedProvider !== 'deepseek' && str_starts_with((string) ($settings['model'] ?? ''), 'gpt-')) {
        $settings['model'] = 'deepseek-v4-flash';
    }
    $settings['model'] = trim((string) ($settings['model'] ?? 'deepseek-v4-flash')) ?: 'deepseek-v4-flash';
    $settings['dailyRequestLimit'] = openai_ai_clamp_int($settings['dailyRequestLimit'] ?? null, 0, 100000, 100);
    $settings['globalDailyLimit'] = openai_ai_clamp_int($settings['globalDailyLimit'] ?? null, 0, 100000, (int) $settings['dailyRequestLimit']);
    $settings['perUserDailyLimit'] = openai_ai_clamp_int($settings['perUserDailyLimit'] ?? null, 0, 100000, 30);
    $settings['monthlyRequestLimit'] = openai_ai_clamp_int($settings['monthlyRequestLimit'] ?? null, 0, 1000000, 1000);
    $settings['maxContextSize'] = openai_ai_clamp_int($settings['maxContextSize'] ?? null, 2000, 200000, 35000);
    $settings['perRequestTimeoutSeconds'] = openai_ai_clamp_int($settings['perRequestTimeoutSeconds'] ?? null, 5, 120, 45);
    $settings['retryCount'] = openai_ai_clamp_int($settings['retryCount'] ?? null, 0, 1, 0);

    unset($settings['apiKey'], $settings['secret'], $settings['credentials']);

    return $settings;
}

function openai_ai_save_settings(array $payload): array
{
    require_permission('demand.ai_api.settings.manage');

    $before = openai_ai_settings();
    $next = $before;
    $next['enabled'] = !empty($payload['enabled']);
    $next['model'] = demand_clean_string((string) ($payload['model'] ?? $before['model']), 80) ?: 'deepseek-v4-flash';
    $next['dailyRequestLimit'] = openai_ai_clamp_int($payload['dailyRequestLimit'] ?? ($payload['globalDailyLimit'] ?? null), 0, 100000, 100);
    $next['globalDailyLimit'] = openai_ai_clamp_int($payload['globalDailyLimit'] ?? ($payload['dailyRequestLimit'] ?? null), 0, 100000, $next['dailyRequestLimit']);
    $next['perUserDailyLimit'] = openai_ai_clamp_int($payload['perUserDailyLimit'] ?? null, 0, 100000, 30);
    $next['monthlyRequestLimit'] = openai_ai_clamp_int($payload['monthlyRequestLimit'] ?? null, 0, 1000000, 1000);
    $next['maxContextSize'] = openai_ai_clamp_int($payload['maxContextSize'] ?? null, 2000, 200000, 35000);
    $next['perRequestTimeoutSeconds'] = openai_ai_clamp_int($payload['perRequestTimeoutSeconds'] ?? null, 5, 120, 45);
    $next['retryCount'] = openai_ai_clamp_int($payload['retryCount'] ?? null, 0, 1, 0);
    $next['updatedAt'] = now_iso();
    $next['updatedBy'] = current_admin_user() ?: 'system';

    unset($next['apiKey'], $next['secret'], $next['credentials'], $next['configuredModel']);
    write_json_file(openai_ai_settings_path(), $next);

    audit_log('demand.ai_api.settings.updated', 'demand_ai_api', 'settings', 'DeepSeek API assistant settings updated without storing secrets.', [
        'changes' => changed_fields($before, $next, [
            'enabled',
            'model',
            'dailyRequestLimit',
            'globalDailyLimit',
            'perUserDailyLimit',
            'monthlyRequestLimit',
            'maxContextSize',
            'perRequestTimeoutSeconds',
            'retryCount',
        ]),
    ]);

    return openai_ai_settings();
}

function openai_ai_update_settings_meta(array $meta): array
{
    $settings = openai_ai_settings();
    foreach ($meta as $key => $value) {
        if (in_array((string) $key, ['apiKey', 'secret', 'credentials'], true)) {
            continue;
        }
        $settings[(string) $key] = $value;
    }
    $settings['updatedAt'] = now_iso();
    $settings['updatedBy'] = current_admin_user() ?: 'system';
    unset($settings['apiKey'], $settings['secret'], $settings['credentials'], $settings['configuredModel']);
    write_json_file(openai_ai_settings_path(), $settings);

    return openai_ai_settings();
}

function openai_ai_sanitize_error(string $error): string
{
    $error = preg_replace('/sk-[A-Za-z0-9_\-]{8,}/', 'sk-***', $error) ?? $error;
    $error = preg_replace('/Bearer\s+[A-Za-z0-9._\-]+/i', 'Bearer ***', $error) ?? $error;
    $error = preg_replace('/api[_-]?key["\']?\s*[:=]\s*["\']?[^"\'\s,}]+/i', 'apiKey=***', $error) ?? $error;
    $error = preg_replace('/[A-Za-z0-9_\-]{32,}/', '***', $error) ?? $error;

    return demand_clean_string($error, 1200);
}

function openai_ai_runs_default(): array
{
    return [
        'updatedAt' => null,
        'items' => [],
    ];
}

function openai_ai_read_runs(): array
{
    $path = openai_ai_runs_path();
    $data = is_file($path) ? read_json_file($path, openai_ai_runs_default()) : openai_ai_runs_default();
    $data['items'] = isset($data['items']) && is_array($data['items']) ? array_values($data['items']) : [];

    return $data;
}

function openai_ai_write_runs(array $data): void
{
    $items = isset($data['items']) && is_array($data['items']) ? array_values($data['items']) : [];
    if (count($items) > 2000) {
        $items = array_slice($items, -2000);
    }
    write_json_file(openai_ai_runs_path(), [
        'updatedAt' => now_iso(),
        'items' => $items,
    ]);
}

function openai_ai_hash_value($value): string
{
    $json = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    return hash('sha256', $json === false ? serialize($value) : $json);
}

function openai_ai_log_run(array $entry): array
{
    $data = openai_ai_read_runs();
    $safe = [
        'id' => demand_clean_string((string) ($entry['id'] ?? ('aiapi_' . bin2hex(random_bytes(8)))), 80),
        'createdAt' => demand_clean_string((string) ($entry['createdAt'] ?? now_iso()), 40),
        'actor' => demand_clean_string((string) ($entry['actor'] ?? (current_admin_user() ?: 'system')), 120),
        'scope_id' => demand_normalize_scope_id((string) ($entry['scope_id'] ?? 'rent_rk')),
        'task' => demand_clean_string((string) ($entry['task'] ?? ''), 120),
        'entityType' => demand_clean_string((string) ($entry['entityType'] ?? ''), 80),
        'entityId' => demand_clean_string((string) ($entry['entityId'] ?? ''), 120),
        'model' => demand_clean_string((string) ($entry['model'] ?? ''), 80),
        'status' => demand_clean_string((string) ($entry['status'] ?? 'unknown'), 40),
        'promptHash' => demand_clean_string((string) ($entry['promptHash'] ?? ''), 128),
        'responseHash' => demand_clean_string((string) ($entry['responseHash'] ?? ''), 128),
        'inputTokens' => max(0, (int) ($entry['inputTokens'] ?? 0)),
        'outputTokens' => max(0, (int) ($entry['outputTokens'] ?? 0)),
        'estimatedCost' => max(0, (float) ($entry['estimatedCost'] ?? 0)),
        'errorCode' => demand_clean_string((string) ($entry['errorCode'] ?? ''), 80),
        'sanitizedError' => openai_ai_sanitize_error((string) ($entry['sanitizedError'] ?? '')),
    ];
    $data['items'][] = $safe;
    openai_ai_write_runs($data);

    return $safe;
}

function openai_ai_run_count_since(array $runs, string $since, ?string $actor = null): int
{
    $count = 0;
    foreach ($runs as $run) {
        if (!is_array($run)) {
            continue;
        }
        if ($actor !== null && (string) ($run['actor'] ?? '') !== $actor) {
            continue;
        }
        if ((string) ($run['status'] ?? '') !== 'success') {
            continue;
        }
        if ((string) ($run['createdAt'] ?? '') >= $since) {
            $count++;
        }
    }

    return $count;
}

function openai_ai_limit_status(string $actor, array $settings): array
{
    $runs = openai_ai_read_runs()['items'];
    $today = (new DateTimeImmutable('today'))->format(DATE_ATOM);
    $month = (new DateTimeImmutable('first day of this month 00:00:00'))->format(DATE_ATOM);
    $perUser = openai_ai_run_count_since($runs, $today, $actor);
    $daily = openai_ai_run_count_since($runs, $today, null);
    $monthly = openai_ai_run_count_since($runs, $month, null);
    $perUserLimit = (int) ($settings['perUserDailyLimit'] ?? 0);
    $dailyLimit = (int) ($settings['globalDailyLimit'] ?? $settings['dailyRequestLimit'] ?? 0);
    $monthlyLimit = (int) ($settings['monthlyRequestLimit'] ?? 0);

    $blocked = false;
    $message = '';
    if ($perUserLimit > 0 && $perUser >= $perUserLimit) {
        $blocked = true;
        $message = 'Лимит AI-помощника для пользователя на сегодня исчерпан. Можно продолжить вручную или увеличить лимит в настройках.';
    } elseif ($dailyLimit > 0 && $daily >= $dailyLimit) {
        $blocked = true;
        $message = 'Лимит AI-помощника на сегодня исчерпан. Можно продолжить вручную или увеличить лимит в настройках.';
    } elseif ($monthlyLimit > 0 && $monthly >= $monthlyLimit) {
        $blocked = true;
        $message = 'Месячный лимит AI-помощника исчерпан. Можно продолжить вручную или увеличить лимит в настройках.';
    }

    return [
        'blocked' => $blocked,
        'message' => $message,
        'perUserUsedToday' => $perUser,
        'globalUsedToday' => $daily,
        'monthlyUsed' => $monthly,
        'perUserDailyLimit' => $perUserLimit,
        'globalDailyLimit' => $dailyLimit,
        'monthlyRequestLimit' => $monthlyLimit,
    ];
}

function openai_ai_response_schema(): array
{
    return [
        'type' => 'object',
        'additionalProperties' => false,
        'required' => [
            'summary',
            'whatIsHappening',
            'importantFindings',
            'risks',
            'nextStep',
            'suggestedActions',
            'draftProposal',
            'briefProposal',
            'mustCheckBeforeApply',
            'notAllowed',
        ],
        'properties' => [
            'summary' => ['type' => 'string'],
            'whatIsHappening' => ['type' => 'array', 'items' => ['type' => 'string']],
            'importantFindings' => ['type' => 'array', 'items' => ['type' => 'string']],
            'risks' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'additionalProperties' => false,
                    'required' => ['level', 'message'],
                    'properties' => [
                        'level' => ['type' => 'string', 'enum' => ['low', 'medium', 'high', 'blocked']],
                        'message' => ['type' => 'string'],
                    ],
                ],
            ],
            'nextStep' => [
                'type' => 'object',
                'additionalProperties' => false,
                'required' => ['label', 'reason', 'safe'],
                'properties' => [
                    'label' => ['type' => 'string'],
                    'reason' => ['type' => 'string'],
                    'safe' => ['type' => 'boolean'],
                ],
            ],
            'suggestedActions' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'additionalProperties' => false,
                    'required' => ['type', 'label', 'explanation', 'requiresConfirmation'],
                    'properties' => [
                        'type' => ['type' => 'string', 'enum' => ['open_tab', 'create_brief', 'create_draft', 'edit_draft', 'add_faq', 'add_block', 'review_risk', 'do_nothing']],
                        'label' => ['type' => 'string'],
                        'explanation' => ['type' => 'string'],
                        'requiresConfirmation' => ['type' => 'boolean'],
                    ],
                ],
            ],
            'draftProposal' => [
                'type' => 'object',
                'additionalProperties' => false,
                'required' => ['title', 'h1', 'metaDescription', 'intro', 'contentBlocks', 'faq', 'adminNote'],
                'properties' => [
                    'title' => ['type' => ['string', 'null']],
                    'h1' => ['type' => ['string', 'null']],
                    'metaDescription' => ['type' => ['string', 'null']],
                    'intro' => ['type' => ['string', 'null']],
                    'contentBlocks' => [
                        'type' => 'array',
                        'items' => [
                            'type' => 'object',
                            'additionalProperties' => false,
                            'required' => ['type', 'title', 'body', 'items'],
                            'properties' => [
                                'type' => ['type' => 'string'],
                                'title' => ['type' => 'string'],
                                'body' => ['type' => 'string'],
                                'items' => [
                                    'type' => 'array',
                                    'items' => [
                                        'type' => 'object',
                                        'additionalProperties' => false,
                                        'required' => ['question', 'answer'],
                                        'properties' => [
                                            'question' => ['type' => 'string'],
                                            'answer' => ['type' => 'string'],
                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ],
                    'faq' => [
                        'type' => 'array',
                        'items' => [
                            'type' => 'object',
                            'additionalProperties' => false,
                            'required' => ['question', 'answer'],
                            'properties' => [
                                'question' => ['type' => 'string'],
                                'answer' => ['type' => 'string'],
                            ],
                        ],
                    ],
                    'adminNote' => ['type' => ['string', 'null']],
                ],
            ],
            'briefProposal' => [
                'type' => 'object',
                'additionalProperties' => false,
                'required' => ['targetIntent', 'mustAnswer', 'mustNotPromise', 'recommendedBlocks', 'faqQuestions'],
                'properties' => [
                    'targetIntent' => ['type' => ['string', 'null']],
                    'mustAnswer' => ['type' => 'array', 'items' => ['type' => 'string']],
                    'mustNotPromise' => ['type' => 'array', 'items' => ['type' => 'string']],
                    'recommendedBlocks' => ['type' => 'array', 'items' => ['type' => 'string']],
                    'faqQuestions' => ['type' => 'array', 'items' => ['type' => 'string']],
                ],
            ],
            'mustCheckBeforeApply' => ['type' => 'array', 'items' => ['type' => 'string']],
            'notAllowed' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
    ];
}

function openai_ai_build_chat_payload(string $model, string $systemInstructions, string $userInput, array $schema): array
{
    $schemaJson = json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($schemaJson === false) {
        $schemaJson = '{}';
    }

    return [
        'model' => $model,
        'messages' => [
            [
                'role' => 'system',
                'content' => $systemInstructions . "\n\nВерни только JSON object без markdown. JSON должен соответствовать этой схеме: " . $schemaJson,
            ],
            [
                'role' => 'user',
                'content' => $userInput,
            ],
        ],
        'response_format' => ['type' => 'json_object'],
        'thinking' => ['type' => 'disabled'],
        'stream' => false,
        'temperature' => 0.2,
    ];
}

function openai_ai_provider_configuration_version(?array $settings = null, ?array $credentials = null): string
{
    $settings = $settings ?? openai_ai_settings();
    $credentials = $credentials ?? openai_ai_private_credentials();
    $material = [
        'settings' => [
            'enabled' => !empty($settings['enabled']),
            'provider' => (string) ($settings['provider'] ?? 'deepseek'),
            'model' => (string) ($settings['model'] ?? ''),
            'dailyRequestLimit' => (int) ($settings['dailyRequestLimit'] ?? 0),
            'globalDailyLimit' => (int) ($settings['globalDailyLimit'] ?? 0),
            'perUserDailyLimit' => (int) ($settings['perUserDailyLimit'] ?? 0),
            'monthlyRequestLimit' => (int) ($settings['monthlyRequestLimit'] ?? 0),
            'maxContextSize' => (int) ($settings['maxContextSize'] ?? 0),
            'perRequestTimeoutSeconds' => (int) ($settings['perRequestTimeoutSeconds'] ?? 0),
            'retryCount' => (int) ($settings['retryCount'] ?? 0),
        ],
        'credentials' => [
            'apiKeyHash' => hash('sha256', (string) ($credentials['apiKey'] ?? '')),
            'baseUrl' => openai_ai_normalize_base_url((string) ($credentials['baseUrl'] ?? '')),
            'model' => (string) ($credentials['model'] ?? ''),
            'timeoutSeconds' => (int) ($credentials['timeoutSeconds'] ?? 0),
            'credentialSource' => (string) ($credentials['credentialSource'] ?? ''),
        ],
    ];

    return hash('sha256', json_encode($material, JSON_THROW_ON_ERROR | JSON_PRESERVE_ZERO_FRACTION));
}

function openai_ai_extract_response_text(array $response): string
{
    if (isset($response['output_text']) && is_string($response['output_text'])) {
        return trim($response['output_text']);
    }

    if (isset($response['choices'][0]['message']['content']) && is_string($response['choices'][0]['message']['content'])) {
        return trim($response['choices'][0]['message']['content']);
    }

    $parts = [];
    foreach ((array) ($response['output'] ?? []) as $output) {
        if (!is_array($output)) {
            continue;
        }
        foreach ((array) ($output['content'] ?? []) as $content) {
            if (!is_array($content)) {
                continue;
            }
            foreach (['text', 'output_text'] as $field) {
                if (isset($content[$field]) && is_string($content[$field])) {
                    $parts[] = $content[$field];
                }
            }
        }
    }

    return trim(implode("\n", $parts));
}

function openai_ai_usage_from_response(array $response): array
{
    $usage = is_array($response['usage'] ?? null) ? $response['usage'] : [];

    return [
        'inputTokens' => max(0, (int) ($usage['input_tokens'] ?? $usage['prompt_tokens'] ?? 0)),
        'outputTokens' => max(0, (int) ($usage['output_tokens'] ?? $usage['completion_tokens'] ?? 0)),
    ];
}

function openai_ai_send_request(string $systemInstructions, string $userInput, array $schema, array $options = []): array
{
    $credentials = openai_ai_private_credentials();
    $settings = openai_ai_settings();
    $configurationVersion = openai_ai_provider_configuration_version($settings, $credentials);
    $apiKey = (string) ($credentials['apiKey'] ?? '');
    if ($apiKey === '') {
        throw new RuntimeException('DeepSeek API key is not configured.');
    }
    $model = demand_clean_string((string) ($options['model'] ?? $credentials['model'] ?: $settings['model'] ?? 'deepseek-v4-flash'), 80) ?: 'deepseek-v4-flash';
    $timeout = openai_ai_clamp_int($options['timeoutSeconds'] ?? ($credentials['timeoutSeconds'] ?: $settings['perRequestTimeoutSeconds']), 5, 120, 45);
    $baseUrl = openai_ai_normalize_base_url((string) ($credentials['baseUrl'] ?? 'https://api.deepseek.com'));
    $payload = openai_ai_build_chat_payload($model, $systemInstructions, $userInput, $schema);
    $body = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($body === false) {
        throw new RuntimeException('DeepSeek request payload could not be encoded.');
    }

    $attempts = 1 + openai_ai_clamp_int($options['retryCount'] ?? $settings['retryCount'] ?? 0, 0, 1, 0);
    $send = static function () use ($attempts, $baseUrl, $body, $timeout, $apiKey, $model, $payload): array {
        $lastError = '';
        $httpCode = 0;
        for ($attempt = 1; $attempt <= $attempts; $attempt++) {
            $url = $baseUrl . '/chat/completions';
            $controlled = demand_integrations_controlled_transport('deepseek', [
                'method' => 'POST',
                'operation' => 'chat.completions',
                'url' => $url,
                'body' => $body,
                'headerNames' => ['Authorization', 'Content-Type'],
                'timeoutSeconds' => $timeout,
                'attempt' => $attempt,
            ]);
            if ($controlled !== null) {
                $raw = $controlled['body'] ?? false;
                $httpCode = (int) ($controlled['status'] ?? 0);
                $curlError = (string) ($controlled['error'] ?? '');
            } else {
                if (!function_exists('curl_init')) {
                    throw new RuntimeException('PHP cURL extension is not available.');
                }
                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_POST => true,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HTTPHEADER => [
                        'Authorization: Bearer ' . $apiKey,
                        'Content-Type: application/json',
                    ],
                    CURLOPT_POSTFIELDS => $body,
                    CURLOPT_TIMEOUT => $timeout,
                ]);
                $raw = curl_exec($ch);
                $httpCode = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                $curlError = curl_error($ch);
                curl_close($ch);
            }

            if ($raw !== false && $httpCode >= 200 && $httpCode < 300) {
                $decoded = json_decode((string) $raw, true);
                if (!is_array($decoded)) {
                    throw new RuntimeException('DeepSeek response was not valid JSON.');
                }
                $text = openai_ai_extract_response_text($decoded);
                if ($text === '') {
                    throw new RuntimeException('DeepSeek response did not contain output text.');
                }
                $output = json_decode($text, true);
                if (!is_array($output)) {
                    throw new RuntimeException('DeepSeek structured output was not valid JSON.');
                }
                $usage = openai_ai_usage_from_response($decoded);

                return [
                    'model' => $model,
                    'response' => $output,
                    'rawResponseHash' => openai_ai_hash_value($decoded),
                    'promptHash' => openai_ai_hash_value($payload),
                    'responseHash' => openai_ai_hash_value($output),
                    'inputTokens' => (int) $usage['inputTokens'],
                    'outputTokens' => (int) $usage['outputTokens'],
                ];
            }

            $lastError = $raw === false ? $curlError : (string) $raw;
        }

        throw new RuntimeException('DeepSeek request failed: HTTP ' . $httpCode . ' ' . openai_ai_sanitize_error($lastError));
    };
    $result = RentalReturnStore::waitOutsideLock($send);
    if (!hash_equals($configurationVersion, openai_ai_provider_configuration_version())) {
        throw new RuntimeException('Настройки AI-провайдера изменились во время запроса. Повторите операцию.', 409);
    }

    return $result;
}

function openai_ai_test_connection(): array
{
    require_permission('demand.ai_api.settings.manage');

    $configurationVersion = business_form_version([DEMAND_AI_SETTINGS_FILE, openai_ai_credentials_path()]);
    $settings = openai_ai_settings();
    if (empty($settings['apiKeyConfigured'])) {
        $error = 'DeepSeek API key is not configured. Add it to private secrets file or environment.';
        openai_ai_update_settings_meta([
            'lastTestAt' => now_iso(),
            'lastErrorAt' => now_iso(),
            'lastError' => $error,
            'lastErrorCode' => 'missing_api_key',
            'lastErrorTechnical' => '',
        ]);

        return ['ok' => false, 'message' => $error];
    }

    try {
        $result = openai_ai_send_request(
            'Return a minimal valid JSON object for the provided schema.',
            'Connection test. Return summary "ok" and empty arrays.',
            openai_ai_response_schema(),
            [
                'model' => (string) ($settings['model'] ?? 'deepseek-v4-flash'),
                'timeoutSeconds' => (int) ($settings['perRequestTimeoutSeconds'] ?? 45),
                'retryCount' => 0,
            ]
        );
        if (!hash_equals($configurationVersion, business_form_version([DEMAND_AI_SETTINGS_FILE, openai_ai_credentials_path()]))) {
            return ['ok' => false, 'stale' => true, 'message' => 'DeepSeek settings changed while the connection test was running.'];
        }
        openai_ai_update_settings_meta([
            'lastTestAt' => now_iso(),
            'lastSuccessAt' => now_iso(),
            'lastErrorAt' => null,
            'lastError' => null,
            'lastErrorCode' => null,
            'lastErrorTechnical' => null,
        ]);

        return [
            'ok' => true,
            'message' => 'DeepSeek API connection works.',
            'model' => (string) ($result['model'] ?? $settings['model']),
        ];
    } catch (Throwable $exception) {
        if (!hash_equals($configurationVersion, business_form_version([DEMAND_AI_SETTINGS_FILE, openai_ai_credentials_path()]))) {
            return ['ok' => false, 'stale' => true, 'message' => 'DeepSeek settings changed while the connection test was running.'];
        }
        $error = openai_ai_sanitize_error($exception->getMessage());
        openai_ai_update_settings_meta([
            'lastTestAt' => now_iso(),
            'lastErrorAt' => now_iso(),
            'lastError' => 'DeepSeek API check failed.',
            'lastErrorCode' => 'test_failed',
            'lastErrorTechnical' => $error,
        ]);

        return ['ok' => false, 'message' => 'DeepSeek API check failed.', 'technical' => $error];
    }
}
