<?php

declare(strict_types=1);

function rental_return_document_parties(array $rental): array
{
    $car = find_car($rental['carSlug']);
    $customer = customer_for_rental_scope($rental);
    $scope = rental_owner_scope_id($rental);
    if (!$car || !$customer || car_owner_scope_id($car) !== $scope) {
        throw new RuntimeException('Проверьте автомобиль, клиента и контур для акта.', 409);
    }
    if ($scope === 'rent_rk') {
        $settings = read_json_file(SETTINGS_FILE, []);
        $lessor = $settings['lessor'] ?? [];
    } else {
        $lessorRecord = find_lessor_by_slug(lessor_slug_from_scope_id($scope));
        $lessor = ['fullName' => $lessorRecord['name'] ?? ''];
    }
    if (trim((string) ($lessor['fullName'] ?? $lessor['name'] ?? '')) === '' || trim((string) ($customer['fullName'] ?? '')) === '') {
        throw new RuntimeException('Заполните наименования арендодателя и клиента. Чужие реквизиты не подставляются.', 409);
    }
    $lessor['fullName'] = $lessor['fullName'] ?? $lessor['name'];
    return ['scopeId' => $scope, 'lessor' => $lessor,
        'customer' => array_intersect_key($customer, array_flip(['id', 'fullName', 'phone', 'birthDate', 'passport', 'passportIssuedBy', 'passportIssuedAt', 'passportDepartmentCode', 'registrationAddress', 'address', 'driverLicense'])),
        'car' => ['slug' => $car['slug'], 'name' => $car['name'], 'car_owner_scope_id' => $scope, 'owner_scope_id' => $scope] + normalize_car_document_fields($car)];
}

function rental_return_docx_append(string $bytes, string $html): string
{
    $tmp = tempnam(sys_get_temp_dir(), 'rent_rk_return_');
    if ($tmp === false) { throw new RuntimeException('Не удалось подготовить документ.'); }
    $zip = new ZipArchive();
    $opened = false;
    try {
        if (file_put_contents($tmp, $bytes) !== strlen($bytes) || $zip->open($tmp) !== true) { throw new RuntimeException('Не удалось открыть документ.'); }
        $opened = true;
        $xml = $zip->getFromName('word/document.xml');
        $dom = new DOMDocument();
        if ($xml === false || !$dom->loadXML($xml, LIBXML_NONET)) { throw new RuntimeException('Некорректная структура документа.'); }
        $ns = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
        $body = $dom->getElementsByTagNameNS($ns, 'body')->item(0);
        if (!$body) { throw new RuntimeException('Отсутствует тело документа.'); }
        $htmlDom = new DOMDocument();
        $previous = libxml_use_internal_errors(true);
        try { $htmlDom->loadHTML('<html><head><meta charset="utf-8"></head><body>' . $html . '</body></html>', LIBXML_NONET); }
        finally { libxml_clear_errors(); libxml_use_internal_errors($previous); }
        $xpath = new DOMXPath($htmlDom);
        $section = $dom->getElementsByTagNameNS($ns, 'sectPr')->item(0);
        if ($section && $section->parentNode !== $body) { $section = null; }
        foreach ($xpath->query('//h1|//h2|//p|//tr') as $node) {
            $paragraph = $dom->createElementNS($ns, 'w:p');
            $run = $dom->createElementNS($ns, 'w:r');
            $text = $dom->createElementNS($ns, 'w:t');
            $value = $node->textContent;
            if ($node->nodeName === 'tr') {
                $cells = [];
                foreach ($node->childNodes as $cell) { if ($cell instanceof DOMElement) { $cells[] = $cell->textContent; } }
                $value = implode(': ', $cells);
            }
            $text->appendChild($dom->createTextNode($value));
            $run->appendChild($text);
            $paragraph->appendChild($run);
            $body->insertBefore($paragraph, $section);
        }
        if (!$zip->addFromString('word/document.xml', $dom->saveXML()) || !$zip->close()) { throw new RuntimeException('Не удалось собрать документ.'); }
        $opened = false;
        $result = file_get_contents($tmp);
        if ($result === false) { throw new RuntimeException('Не удалось прочитать документ.'); }
        return $result;
    } finally {
        if ($opened) { $zip->close(); }
        if (is_file($tmp)) { unlink($tmp); }
    }
}

function rental_return_document_rows(array $rental): array
{
    $summary = rental_return_finance($rental);
    if (!$summary) { throw new RuntimeException('Подтвердите финансовые остатки перед подготовкой акта.', 409); }
    $rows = [
        'Основная аренда' => $summary['base'], 'Дополнительные начисления' => $summary['extras'],
        'Всего начислено' => $summary['due'], 'Получено за вычетом возвратов' => $summary['paid'],
        'Долг' => $summary['debt'], 'Переплата' => $summary['excess'], 'Деньги без распределения' => $summary['unallocated'],
        'Фактически полученный залог' => $summary['deposit']['received'], 'Возвращено из залога' => $summary['deposit']['returned'],
        'Удержано из залога' => $summary['deposit']['retained'], 'Остаток залога к решению' => $summary['deposit']['remaining'],
    ];
    return array_map(static fn(int $amount): string => format_money_with_words($amount), $rows)
        + ['Статус залога' => rental_deposit_status_label($rental)];
}

function rental_return_document_body(array $rental, array $customer, array $car, array $lessor, string $contractNumber, string $contractDate): string
{
    $state = rental_return_v2($rental);
    $mileage = rental_mileage_summary($rental);
    $html = '<article class="doc-act legal-document"><h1>Акт возврата автомобиля</h1>';
    $html .= '<p>К договору № ' . e($contractNumber) . ' от ' . e($contractDate) . '.</p>';
    $html .= '<p>Арендодатель: ' . e(doc_lessor_line($lessor)) . '.</p><p>Арендатор: ' . e(doc_client_line($rental, $customer)) . '.</p>';
    $html .= '<p>Автомобиль: ' . e(doc_car_line($car, $rental)) . '.</p><table class="doc-table"><tbody>';
    $rows = [
        'Плановый возврат' => $rental['endDate'] . ' ' . $rental['endTime'],
        'Фактическая приёмка' => $rental['actualReturnDate'] . ' ' . $rental['actualReturnTime'],
        'Одометр при выдаче' => number_format($rental['startMileage'] ?? 0, 0, '', ' ') . ' км',
        'Одометр при возврате' => number_format($rental['endMileage'] ?? 0, 0, '', ' ') . ' км',
        'Пройдено' => $mileage['actual'] === null ? 'Не определено' : number_format($mileage['actual'], 0, '', ' ') . ' км',
        'Лимит пробега' => $mileage['allowed'] === null ? 'Не указан' : number_format($mileage['allowed'], 0, '', ' ') . ' км',
        'Топливо при возврате' => rental_fuel_level_label($state['condition']['fuel'] ?? ''),
        'Авто чистый' => !empty($state['condition']['clean']) ? 'Да' : 'Нет',
        'Замечания по видеофиксации' => $state['condition']['reason'] ?? '',
    ] + rental_return_document_rows($rental);
    foreach ($rows as $label => $value) { $html .= '<tr><th>' . e($label) . '</th><td>' . e($value) . '</td></tr>'; }
    $html .= '</tbody></table><h2>Начисления и решения по залогу</h2>';
    foreach ($state['finance']['charges'] as $charge) {
        $html .= '<p>' . e(rental_return_categories()[$charge['category']] . ': ' . format_money_with_words($charge['amount']) . '. ' . $charge['reason'] . ($charge['status'] === 'reversed' ? ' (отменено)' : '')) . '</p>';
    }
    foreach ($state['finance']['depositEvents'] as $event) {
        if (!in_array($event['kind'], ['retain', 'reverse'], true)) { continue; }
        $html .= '<p>' . e(($event['kind'] === 'retain' ? 'Удержание: ' : 'Отмена удержания: ') . format_money_with_words($event['amount']) . '. ' . $event['reason']) . '</p>';
    }
    return $html . '<p>Арендодатель ____________________ / ' . e($lessor['fullName']) . '</p><p>Арендатор ____________________ / ' . e($customer['fullName']) . '</p></article>';
}
