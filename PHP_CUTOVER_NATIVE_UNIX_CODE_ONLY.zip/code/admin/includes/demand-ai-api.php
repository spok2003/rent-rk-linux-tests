<?php

declare(strict_types=1);

function demand_ai_api_allowed_tasks(): array
{
    return [
        'explain_current_screen',
        'suggest_next_step',
        'summarize_import_preview',
        'explain_demand_map',
        'prioritize_launch_plan',
        'explain_recommendation',
        'improve_landing_draft',
        'create_faq',
        'create_title_description',
        'check_false_promises',
        'compare_page_with_demand',
        'simplify_for_client',
        'prepare_publication_checklist',
        'suggest_internal_links',
        'regenerate_internal_links',
        'apply_internal_link_suggestions',
        'regenerate_landing_draft_human',
        'regenerate_landing_intro',
        'regenerate_content_blocks',
        'regenerate_single_content_block',
        'regenerate_faq',
        'rewrite_block_human',
        'reduce_seo_overoptimization',
        'make_copy_more_human',
        'generate_alternative_variant',
        'evaluate_copy_human_quality',
        'regenerate_preview_block_human',
        'rewrite_preview_block_shorter',
        'reduce_preview_block_seo_overuse',
        'regenerate_preview_faq',
        'suggest_preview_internal_links',
        'generate_car_hint_text',
        'generate_car_description_suggestion',
        'improve_car_hint',
    ];
}

function demand_ai_api_task_label(string $task): string
{
    return [
        'explain_current_screen' => 'Объясни, что делать дальше',
        'suggest_next_step' => 'Составь простой план на сегодня',
        'summarize_import_preview' => 'Объясни результат загрузки',
        'explain_demand_map' => 'Объясни карту спроса',
        'prioritize_launch_plan' => 'Какие страницы готовить первыми',
        'explain_recommendation' => 'Почему эта рекомендация важна',
        'improve_landing_draft' => 'Что исправить в черновике',
        'create_faq' => 'Собери FAQ',
        'create_title_description' => 'Сделай title/description',
        'check_false_promises' => 'Проверь обещания и риски',
        'compare_page_with_demand' => 'Сравни страницу со спросом',
        'simplify_for_client' => 'Сделай текст понятнее',
        'prepare_publication_checklist' => 'Проверь страницу перед публикацией',
        'suggest_internal_links' => 'Подобрать внутренние ссылки',
        'regenerate_internal_links' => 'Подобрать другие внутренние ссылки',
        'apply_internal_link_suggestions' => 'Подготовить применение внутренних ссылок',
        'regenerate_landing_draft_human' => 'Сгенерировать живой вариант страницы',
        'regenerate_landing_intro' => 'Сгенерировать заново intro',
        'regenerate_content_blocks' => 'Сгенерировать заново все блоки',
        'regenerate_single_content_block' => 'Сгенерировать этот блок',
        'regenerate_faq' => 'Сгенерировать заново FAQ',
        'rewrite_block_human' => 'Переписать живее, факты не менять',
        'reduce_seo_overoptimization' => 'Убрать SEO-переспам',
        'make_copy_more_human' => 'Проверить и оживить текст',
        'generate_alternative_variant' => 'Сгенерировать еще раз',
        'evaluate_copy_human_quality' => 'Оценить живость текста',
        'regenerate_preview_block_human' => 'Оживить блок на preview',
        'rewrite_preview_block_shorter' => 'Сделать preview-блок короче',
        'reduce_preview_block_seo_overuse' => 'Убрать SEO-повторы в preview-блоке',
        'regenerate_preview_faq' => 'Перегенерировать FAQ на preview',
        'suggest_preview_internal_links' => 'Подобрать внутренние ссылки на preview',
        'generate_car_hint_text' => 'Сформировать текст подсказки',
        'generate_car_description_suggestion' => 'Сформировать текст описания',
        'improve_car_hint' => 'Улучшить подсказку для авто',
    ][$task] ?? $task;
}

function demand_ai_api_task_allowed(string $task): bool
{
    return in_array($task, demand_ai_api_allowed_tasks(), true);
}

function demand_ai_api_is_car_hint_task(string $task): bool
{
    return in_array($task, ['generate_car_hint_text', 'generate_car_description_suggestion', 'improve_car_hint'], true);
}

function demand_ai_api_system_instructions(): string
{
    return implode("\n", [
        'Ты — AI-помощник админки Rent RK для раздела "Маркетинг → Спрос".',
        'Помогай одному admin разобраться в текущем экране простым русским языком.',
        'Используй только переданный safe context. Не выдумывай цены, залог, наличие авто, подачу и условия.',
        'Любые изменения предлагай только как предложение для ручного preview/diff и подтверждения admin.',
        'Не предлагай автопубликацию, открытие индексации, изменение sitemap.xml, robots.txt, canonical, publishStatus или indexStatus.',
        'Не меняй и не проси менять цены, залоги, тарифы, автомобили, заявки, аренды, клиентов, штрафы, финансы, документы, пользователей, роли и права.',
        'Не запускай Wordstat live sync и не отправляй уведомления.',
        'Если данных недостаточно, прямо напиши, что нужно проверить у менеджера.',
        'Для "без залога", "дешево", "аэропорт", "с водителем", "без прав", "без паспорта" и "без договора" обязательно укажи риски.',
        'Если task относится к human_landing_copy_generation, пиши не SEO-простыню, а спокойный живой текст для человека, который выбирает машину для поездки.',
        'В human_landing_copy_generation учитывай copyGenerationSettings: style, baseInstruction, avoid, emphasis и oneTimeInstruction. Разовая инструкция важна только для текущего варианта.',
        'В human_landing_copy_generation не используй канцелярит, рекламные штампы, механические повторы ключей и давление. Каждый блок должен отвечать на реальный вопрос пользователя и реальный сценарий поездки.',
        'В human_landing_copy_generation возвращай финальный public copy для посетителя, а не редакторское ТЗ. Не пиши "эта страница должна", "блок должен", "рекомендуется добавить", "перечислить", "показать", "внутренние связи", Stage A/B/C, contentGap, mustAnswer или mustNotPromise как публичные заголовки.',
        'Для regenerate_preview_block_human, rewrite_preview_block_shorter, reduce_preview_block_seo_overuse и regenerate_preview_faq переписывай только выбранный блок/FAQ из safe context. Возвращай вариант для preview/diff, без автоприменения и без HTML.',
        'Для contentBlocks явно указывай visibility: public для текста посетителя, admin_only для редакторских подсказок и technical для служебных данных. Публичные блоки не должны содержать internal_links, contentGap, readiness, safe content blocks или инструкции администратору.',
        'Верни heroSubtitle/public intro смысл через intro или public content block. FAQ должен быть готовым ответом клиента, не guidance вида "ответить только на основе".',
        'Сохраняй поисковый смысл, но не повторяй ключевую фразу в каждом абзаце. Если факта нет, пиши честно: "условия уточняются перед бронированием", "точный залог зависит от автомобиля" или "наличие проверяется перед поездкой".',
        'Нельзя обещать "без залога", "самая низкая цена", "машина всегда доступна", "подача в любое время", скидки, детское кресло, 24/7 или наличие авто, если это не подтверждено safe context.',
        'Не меняй цены, залог, наличие авто, подачу и условия. Не выдумывай факты, которых нет в safe context.',
        'Избегай штампов: идеальный вариант, лучшее решение, широкий выбор, доступные цены, высокий уровень сервиса, индивидуальный подход, быстро и качественно, максимальный комфорт, самые выгодные условия, без лишних хлопот, самые низкие цены.',
        'Для generate_car_hint_text, generate_car_description_suggestion и improve_car_hint верни только carHintProposal. Это proposal для подсказки, а не изменение карточки автомобиля.',
        'В carHintProposal можно предлагать message, suggestedText и descriptionSuggestion. Нельзя менять автомобиль, цену, залог, характеристики, доступность, публикацию или индексацию.',
        'Текст подсказки должен быть коротким, человеческим и пригодным для ручного применения после preview/diff. Если фактов не хватает, добавь это в mustCheckBeforeApply.',
        'Для suggest_internal_links/regenerate_internal_links подбирай только safe context источники: публичные карточки авто, опубликованные landing pages, статические страницы и draft/planned targets как планируемые связи без href.',
        'Внутренние ссылки возвращай структурно: summary, internalLinkSuggestions, publicBlockProposal, adminNotes, mustCheckBeforeApply, notAllowed. Статусы: ready_public_link, noindex_public_link, draft_planned_link, missing_target, risky_or_irrelevant, duplicate.',
        'Не пиши публичный заголовок "Внутренние связи". Для блока посетителя используй "Также может подойти", "Похожие варианты" или похожий человеческий текст. Planned/draft/missing targets нельзя выводить как public href.',
        'Добавление внутренних ссылок в существующий черновик требует preview/подтверждения. Не меняй publishStatus, indexStatus, sitemap.xml, robots.txt или canonical.',
        'Верни только JSON по заданной схеме. Все поля схемы обязательны. Unknown fields не добавляй.',
    ]);
}

function demand_ai_api_forbidden_field_markers(): array
{
    return [
        'customer', 'customers', 'client', 'clients', 'phone', 'phones', 'request', 'requests',
        'rental', 'rentals', 'fine', 'fines', 'finance', 'payment', 'payments', 'balance',
        'document', 'documents', 'passport', 'vin', 'gosnumber', 'licensePlate',
        'owner', 'settlement', 'admin_users', 'adminUsers', 'roles', 'permissions',
        'password', 'apiKey', 'api_key', 'secret', 'credentials', 'wordstat',
        'openai', 'deepseek', 'telegram', 'rawLog', 'stackTrace',
    ];
}

function demand_ai_api_forbidden_context_hits($value, string $path = ''): array
{
    $hits = [];
    if (!is_array($value)) {
        return [];
    }
    foreach ($value as $key => $child) {
        $keyText = (string) $key;
        foreach (demand_ai_api_forbidden_field_markers() as $marker) {
            if (stripos($keyText, $marker) !== false) {
                $hits[] = trim($path . '.' . $keyText, '.');
                break;
            }
        }
        $hits = array_merge($hits, demand_ai_api_forbidden_context_hits($child, trim($path . '.' . $keyText, '.')));
    }

    return array_values(array_unique($hits));
}

function demand_ai_api_safe_screen_item(array $item): array
{
    return array_filter([
        'id' => demand_ai_safe_string($item['id'] ?? '', 100),
        'scope_id' => demand_ai_safe_string($item['scope_id'] ?? 'rent_rk', 80),
        'title' => demand_ai_safe_string($item['title'] ?? $item['h1'] ?? $item['primaryPhrase'] ?? '', 220),
        'phrase' => demand_ai_safe_string($item['phrase'] ?? $item['primaryPhrase'] ?? '', 220),
        'intent' => demand_ai_safe_string($item['intent'] ?? $item['targetIntent'] ?? '', 100),
        'priorityLevel' => demand_ai_safe_string($item['priorityLevel'] ?? '', 80),
        'recommendedDecision' => demand_ai_safe_string($item['recommendedDecision'] ?? $item['recommendedAction'] ?? $item['recommendationType'] ?? '', 120),
        'scoringExplanation' => demand_ai_safe_string($item['scoringExplanation'] ?? $item['adminExplanation'] ?? $item['explanation'] ?? '', 800),
        'contentGapSummary' => demand_ai_safe_string($item['contentGapSummary'] ?? '', 800),
        'pageFitStatus' => demand_ai_safe_string($item['pageFitStatus'] ?? '', 100),
        'supplyFitSummary' => demand_ai_safe_string($item['supplyFitSummary'] ?? '', 800),
        'riskFlags' => demand_ai_safe_list($item['riskFlags'] ?? [], 20, 80),
        'mustNotPromise' => demand_ai_safe_list($item['mustNotPromise'] ?? [], 20, 200),
        'userClarityScore' => is_array($item['userClarityScore'] ?? null) ? [
            'level' => demand_ai_safe_string($item['userClarityScore']['level'] ?? '', 40),
            'summary' => demand_ai_safe_string($item['userClarityScore']['summary'] ?? '', 500),
        ] : null,
        'aiSearchReadiness' => is_array($item['aiSearchReadiness'] ?? null) ? [
            'level' => demand_ai_safe_string($item['aiSearchReadiness']['level'] ?? '', 40),
            'summary' => demand_ai_safe_string($item['aiSearchReadiness']['summary'] ?? '', 500),
        ] : null,
    ], static fn($value): bool => $value !== '' && $value !== [] && $value !== null);
}

function demand_ai_api_screen_context(string $currentTab, string $scopeFilter): array
{
    $keywords = function_exists('demand_visible_keywords') && has_permission('demand.view')
        ? array_slice(demand_visible_keywords($scopeFilter), 0, 12)
        : [];
    $recommendations = function_exists('demand_visible_recommendations') && has_permission('demand.recommendations.view')
        ? array_slice(demand_visible_recommendations($scopeFilter), 0, 10)
        : [];
    $drafts = function_exists('demand_visible_drafts') && has_permission('demand.view')
        ? array_slice(demand_visible_drafts($scopeFilter), 0, 8)
        : [];
    $clusters = function_exists('demand_map_visible_clusters') && has_permission('demand.map.view')
        ? array_slice(demand_map_visible_clusters($scopeFilter), 0, 8)
        : [];
    $plans = function_exists('demand_map_visible_launch_plan') && has_permission('demand.launch_plan.view')
        ? array_slice(demand_map_visible_launch_plan($scopeFilter), 0, 10)
        : [];
    $briefs = function_exists('demand_map_visible_content_briefs') && has_permission('demand.content_briefs.view')
        ? array_slice(demand_map_visible_content_briefs($scopeFilter), 0, 8)
        : [];
    $hints = function_exists('demand_map_visible_card_hints') && has_permission('demand.card_hints.view')
        ? array_slice(demand_map_visible_card_hints($scopeFilter), 0, 8)
        : [];

    $keywords = array_values(array_filter($keywords, 'is_array'));
    $recommendations = array_values(array_filter($recommendations, 'is_array'));
    $drafts = array_values(array_filter($drafts, 'is_array'));
    $clusters = array_values(array_filter($clusters, 'is_array'));
    $plans = array_values(array_filter($plans, 'is_array'));
    $briefs = array_values(array_filter($briefs, 'is_array'));
    $hints = array_values(array_filter($hints, 'is_array'));

    return [
        'currentTab' => demand_ai_safe_string($currentTab, 80),
        'scopeFilter' => demand_ai_safe_string($scopeFilter, 80),
        'stats' => function_exists('demand_overview_stats') ? demand_overview_stats($scopeFilter) : [
            'keywords' => count($keywords),
            'recommendations' => count($recommendations),
            'drafts' => count($drafts),
        ],
        'keywords' => array_map(static fn(array $item): array => demand_ai_api_safe_screen_item($item), $keywords),
        'recommendations' => array_map(static fn(array $item): array => demand_ai_api_safe_screen_item($item), $recommendations),
        'clusters' => array_map(static fn(array $item): array => demand_ai_api_safe_screen_item($item), $clusters),
        'launchPlan' => array_map(static fn(array $item): array => demand_ai_api_safe_screen_item($item), $plans),
        'contentBriefs' => array_map(static fn(array $item): array => demand_ai_api_safe_screen_item($item), $briefs),
        'drafts' => array_map(static fn(array $item): array => demand_ai_api_safe_screen_item($item), $drafts),
        'carHints' => array_map(static fn(array $item): array => demand_ai_api_safe_screen_item($item), $hints),
    ];
}

function demand_ai_api_trim_context(array $context, int $maxBytes): array
{
    $json = json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json !== false && strlen($json) <= $maxBytes) {
        return $context;
    }

    foreach (['keywords', 'recommendations', 'clusters', 'launchPlan', 'contentBriefs', 'drafts', 'carHints'] as $field) {
        if (isset($context['screen'][$field]) && is_array($context['screen'][$field])) {
            $context['screen'][$field] = array_slice($context['screen'][$field], 0, 4);
        }
    }
    if (isset($context['facts']['demand']['keywords']) && is_array($context['facts']['demand']['keywords'])) {
        $context['facts']['demand']['keywords'] = array_slice($context['facts']['demand']['keywords'], 0, 6);
    }

    return $context;
}

function demand_ai_api_response_schema_for_task(string $task): array
{
    $schema = openai_ai_response_schema();
    if (demand_ai_api_is_car_hint_task($task)) {
        $schema['required'] = array_values(array_unique(array_merge((array) ($schema['required'] ?? []), ['carHintProposal'])));
        $schema['properties']['carHintProposal'] = [
            'type' => 'object',
            'additionalProperties' => false,
            'required' => ['message', 'suggestedText', 'descriptionSuggestion', 'risks', 'notesForAdmin'],
            'properties' => [
                'message' => ['type' => 'string'],
                'suggestedText' => ['type' => 'string'],
                'descriptionSuggestion' => ['type' => 'string'],
                'risks' => ['type' => 'array', 'items' => ['type' => 'string']],
                'notesForAdmin' => ['type' => 'array', 'items' => ['type' => 'string']],
            ],
        ];

        return $schema;
    }
    if (in_array($task, ['suggest_internal_links', 'regenerate_internal_links', 'apply_internal_link_suggestions'], true)) {
        $schema['required'] = array_values(array_unique(array_merge((array) ($schema['required'] ?? []), ['internalLinkSuggestions', 'publicBlockProposal', 'adminNotes'])));
        $linkItem = [
            'type' => 'object',
            'additionalProperties' => false,
            'required' => ['anchorText', 'targetType', 'targetId', 'targetUrl', 'targetTitle', 'status', 'reason', 'placement', 'safeToApply'],
            'properties' => [
                'anchorText' => ['type' => 'string'],
                'targetType' => ['type' => 'string', 'enum' => ['car', 'landing', 'static', 'planned']],
                'targetId' => ['type' => 'string'],
                'targetUrl' => ['type' => 'string'],
                'targetTitle' => ['type' => 'string'],
                'status' => ['type' => 'string', 'enum' => demand_internal_link_statuses()],
                'reason' => ['type' => 'string'],
                'placement' => ['type' => 'string', 'enum' => ['hero', 'cars_section', 'conditions', 'faq', 'bottom_related']],
                'safeToApply' => ['type' => 'boolean'],
            ],
        ];
        $schema['properties']['internalLinkSuggestions'] = [
            'type' => 'array',
            'items' => $linkItem,
        ];
        $schema['properties']['publicBlockProposal'] = [
            'type' => 'object',
            'additionalProperties' => false,
            'required' => ['title', 'intro', 'links'],
            'properties' => [
                'title' => ['type' => 'string'],
                'intro' => ['type' => 'string'],
                'links' => ['type' => 'array', 'items' => $linkItem],
            ],
        ];
        $schema['properties']['adminNotes'] = ['type' => 'array', 'items' => ['type' => 'string']];

        return $schema;
    }
    if (!demand_ai_is_human_copy_task($task)) {
        return $schema;
    }

    $schema['required'] = array_values(array_unique(array_merge((array) ($schema['required'] ?? []), ['styleUsed', 'copyQuality'])));
    $schema['properties']['styleUsed'] = ['type' => 'string'];
    $schema['properties']['copyQuality'] = [
        'type' => 'object',
        'additionalProperties' => false,
        'required' => ['clarity', 'humanTone', 'seoOveruse', 'promiseRisk', 'specificity'],
        'properties' => [
            'clarity' => ['type' => 'string', 'enum' => ['good', 'needs_simpler']],
            'humanTone' => ['type' => 'string', 'enum' => ['good', 'too_dry', 'too_salesy']],
            'seoOveruse' => ['type' => 'string', 'enum' => ['none', 'possible', 'high']],
            'promiseRisk' => ['type' => 'string', 'enum' => ['none', 'needs_check', 'high']],
            'specificity' => ['type' => 'string', 'enum' => ['good', 'needs_more_facts']],
        ],
    ];
    $schema['properties']['draftProposal']['properties']['contentBlocks'] = [
        'type' => 'array',
        'items' => [
            'type' => 'object',
            'additionalProperties' => false,
            'required' => ['type', 'title', 'text'],
            'properties' => [
                'type' => ['type' => 'string'],
                'visibility' => ['type' => 'string', 'enum' => ['public', 'admin_only', 'technical']],
                'title' => ['type' => 'string'],
                'text' => ['type' => 'string'],
            ],
        ],
    ];

    return $schema;
}

function demand_ai_api_build_context(string $task, string $entityType = '', string $entityId = '', string $scopeFilter = '', string $currentTab = '', array $copyOptions = []): array
{
    require_permission('demand.ai_api.use');

    $task = demand_ai_safe_string($task, 120);
    if (!demand_ai_api_task_allowed($task)) {
        throw new RuntimeException('Эта задача AI API недоступна.');
    }

    $settings = openai_ai_settings();
    $instructions = demand_ai_base_instructions();
    $context = [
        'schemaVersion' => 'rent-rk-ai-api-context-v1',
        'createdAt' => now_iso(),
        'task' => $task,
        'taskLabel' => demand_ai_api_task_label($task),
        'language' => 'ru',
        'screen' => demand_ai_api_screen_context($currentTab, $scopeFilter),
        'source' => [
            'entityType' => '',
            'entityId' => '',
            'scopeId' => demand_normalize_scope_id($scopeFilter ?: 'rent_rk'),
        ],
        'facts' => [],
        'mustPreserve' => $instructions['mustPreserve'],
        'mustNotPromise' => $instructions['mustNotPromise'],
        'forbiddenActions' => $instructions['forbiddenActions'],
        'expectedResponse' => [
            'format' => 'json',
            'schema' => demand_ai_api_response_schema_for_task($task),
        ],
    ];
    $normalizedCopyOptions = demand_ai_is_human_copy_task($task) ? demand_ai_normalize_copy_options($copyOptions) : [];
    if (demand_ai_is_human_copy_task($task)) {
        $context['copyGeneration'] = [
            'mode' => 'human_landing_copy_generation',
            'style' => demand_ai_copy_style_label((string) ($normalizedCopyOptions['style'] ?? 'calm_human')),
            'options' => $normalizedCopyOptions,
            'rules' => demand_ai_copy_generation_rules(),
            'instruction' => !empty($copyOptions['regenerateAgain'])
                ? 'Сделай вариант другим, не повторяй структуру и формулировки прошлого варианта.'
                : 'Подготовь новый живой вариант текста. Ничего не применяй к черновику.',
        ];
    }

    $entityType = demand_ai_safe_string($entityType, 80);
    $entityId = demand_ai_safe_string($entityId, 120);
    if ($entityType !== '' && $entityId !== '') {
        $entity = demand_ai_find_entity($entityType, $entityId);
        if (!$entity) {
            throw new RuntimeException('Контекст для AI API не найден.');
        }
        demand_scope_guard($entity, demand_ai_entity_view_permission($entityType));
        $entityScope = demand_ai_entity_scope($entity);
        $scope = demand_normalize_scope_id($scopeFilter);
        if ($scope !== '' && $scope !== 'all' && $scope !== $entityScope) {
            deny_scope_access();
        }
        $context['source'] = [
            'entityType' => $entityType,
            'entityId' => $entityId,
            'scopeId' => $entityScope,
        ];
        $context['facts'] = demand_ai_build_facts($entityType, $entity);
    }
    if (demand_ai_is_human_copy_task($task)) {
        $factsToPreserve = is_array($context['facts']['factsToPreserve'] ?? null) ? (array) $context['facts']['factsToPreserve'] : [];
        $context['copyGenerationSettings'] = [
            'style' => demand_ai_copy_style_label((string) ($normalizedCopyOptions['style'] ?? 'calm_human')),
            'styleKey' => (string) ($normalizedCopyOptions['style'] ?? 'calm_human'),
            'baseInstruction' => (string) ($normalizedCopyOptions['baseInstruction'] ?? demand_ai_copy_default_base_instruction()),
            'avoid' => array_values(array_intersect_key(demand_ai_copy_avoid_options(), array_fill_keys((array) ($normalizedCopyOptions['avoid'] ?? []), true))),
            'avoidKeys' => (array) ($normalizedCopyOptions['avoid'] ?? []),
            'emphasis' => array_values(array_intersect_key(demand_ai_copy_emphasis_options(), array_fill_keys((array) ($normalizedCopyOptions['emphasis'] ?? []), true))),
            'emphasisKeys' => (array) ($normalizedCopyOptions['emphasis'] ?? []),
            'oneTimeInstruction' => (string) ($normalizedCopyOptions['oneTimeInstruction'] ?? ''),
            'factsToPreserve' => $factsToPreserve,
            'mustNotPromise' => demand_ai_safe_list($factsToPreserve['mustNotPromise'] ?? ($context['mustNotPromise'] ?? []), 30, 260),
            'riskFlags' => demand_ai_safe_list($factsToPreserve['riskFlags'] ?? ($context['facts']['demand']['riskFlags'] ?? []), 30, 100),
        ];
    }
    if (demand_ai_api_is_car_hint_task($task)) {
        $context['carHintGeneration'] = [
            'mode' => 'proposal_only',
            'task' => $task,
            'allowedApplyFields' => ['message', 'suggestedText', 'descriptionSuggestion'],
            'rules' => [
                'Return text for the car-card hint proposal only.',
                'Do not change the car itself, prices, deposits, availability, publication, indexing, sitemap or robots.',
                'Write human text for a customer choosing a car, without SEO stuffing or editor-only instructions.',
                'If a fact is not confirmed in safe context, put it into mustCheckBeforeApply instead of promising it.',
            ],
        ];
    }

    $context = demand_ai_api_trim_context($context, (int) ($settings['maxContextSize'] ?? 35000));
    $hits = demand_ai_api_forbidden_context_hits($context);
    if ($hits) {
        throw new RuntimeException('AI API context contains forbidden fields: ' . implode(', ', array_slice($hits, 0, 8)));
    }

    return $context;
}

function demand_ai_api_context_version(array $context): string
{
    unset($context['createdAt']);
    return openai_ai_hash_value($context);
}

function demand_ai_api_default_response(): array
{
    return [
        'summary' => '',
        'styleUsed' => '',
        'copyQuality' => demand_ai_copy_quality_default(),
        'whatIsHappening' => [],
        'importantFindings' => [],
        'risks' => [],
        'nextStep' => ['label' => '', 'reason' => '', 'safe' => true],
        'suggestedActions' => [],
        'draftProposal' => [
            'title' => null,
            'h1' => null,
            'metaDescription' => null,
            'intro' => null,
            'contentBlocks' => [],
            'faq' => [],
            'adminNote' => null,
        ],
        'internalLinkSuggestions' => [],
        'publicBlockProposal' => [
            'title' => '',
            'intro' => '',
            'links' => [],
        ],
        'carHintProposal' => [
            'message' => '',
            'suggestedText' => '',
            'descriptionSuggestion' => '',
            'risks' => [],
            'notesForAdmin' => [],
        ],
        'adminNotes' => [],
        'briefProposal' => [
            'targetIntent' => null,
            'mustAnswer' => [],
            'mustNotPromise' => [],
            'recommendedBlocks' => [],
            'faqQuestions' => [],
        ],
        'mustCheckBeforeApply' => [],
        'notAllowed' => [],
        'ignoredFields' => [],
    ];
}

function demand_ai_api_normalize_response(array $payload): array
{
    $default = demand_ai_api_default_response();
    $ignored = [];
    foreach ($payload as $field => $_value) {
        if (!array_key_exists((string) $field, $default)) {
            $ignored[] = (string) $field;
        }
    }

    $response = $default;
    $response['summary'] = demand_ai_safe_string($payload['summary'] ?? '', 1200);
    $response['styleUsed'] = demand_ai_safe_string($payload['styleUsed'] ?? '', 120);
    $response['copyQuality'] = demand_ai_normalize_copy_quality($payload['copyQuality'] ?? []);
    $response['whatIsHappening'] = demand_ai_safe_list($payload['whatIsHappening'] ?? [], 12, 400);
    $response['importantFindings'] = demand_ai_safe_list($payload['importantFindings'] ?? [], 12, 500);
    $response['mustCheckBeforeApply'] = demand_ai_safe_list($payload['mustCheckBeforeApply'] ?? [], 16, 400);
    $response['notAllowed'] = demand_ai_safe_list($payload['notAllowed'] ?? [], 16, 400);

    foreach ((array) ($payload['risks'] ?? []) as $risk) {
        if (!is_array($risk)) {
            continue;
        }
        $level = demand_ai_safe_string($risk['level'] ?? 'medium', 40);
        if (!in_array($level, ['low', 'medium', 'high', 'blocked'], true)) {
            $level = 'medium';
        }
        $message = demand_ai_safe_string($risk['message'] ?? '', 500);
        if ($message !== '') {
            $response['risks'][] = ['level' => $level, 'message' => $message];
        }
    }

    $next = is_array($payload['nextStep'] ?? null) ? $payload['nextStep'] : [];
    $response['nextStep'] = [
        'label' => demand_ai_safe_string($next['label'] ?? '', 240),
        'reason' => demand_ai_safe_string($next['reason'] ?? '', 700),
        'safe' => !array_key_exists('safe', $next) || !empty($next['safe']),
    ];

    $actionTypes = ['open_tab', 'create_brief', 'create_draft', 'edit_draft', 'add_faq', 'add_block', 'review_risk', 'do_nothing'];
    foreach ((array) ($payload['suggestedActions'] ?? []) as $action) {
        if (!is_array($action)) {
            continue;
        }
        $type = demand_ai_safe_string($action['type'] ?? 'do_nothing', 80);
        if (!in_array($type, $actionTypes, true)) {
            $type = 'do_nothing';
        }
        $label = demand_ai_safe_string($action['label'] ?? '', 240);
        if ($label === '') {
            continue;
        }
        $response['suggestedActions'][] = [
            'type' => $type,
            'label' => $label,
            'explanation' => demand_ai_safe_string($action['explanation'] ?? '', 700),
            'requiresConfirmation' => true,
        ];
    }

    $draft = is_array($payload['draftProposal'] ?? null) ? $payload['draftProposal'] : [];
    foreach (['title' => 160, 'h1' => 160, 'metaDescription' => 260, 'intro' => 1400, 'adminNote' => 1200] as $field => $limit) {
        $value = array_key_exists($field, $draft) && $draft[$field] !== null ? demand_ai_safe_string($draft[$field], $limit) : null;
        $response['draftProposal'][$field] = $value !== '' ? $value : null;
    }
    $response['draftProposal']['contentBlocks'] = demand_ai_safe_content_blocks($draft['contentBlocks'] ?? []);
    $response['draftProposal']['faq'] = demand_ai_safe_faq($draft['faq'] ?? []);

    foreach ((array) ($payload['internalLinkSuggestions'] ?? []) as $suggestion) {
        $link = demand_normalize_internal_link($suggestion, ['source' => 'ai_api']);
        if ($link) {
            $response['internalLinkSuggestions'][] = $link;
        }
    }
    $response['internalLinkSuggestions'] = array_slice($response['internalLinkSuggestions'], 0, 20);
    $publicBlock = is_array($payload['publicBlockProposal'] ?? null) ? $payload['publicBlockProposal'] : [];
    $response['publicBlockProposal'] = [
        'title' => demand_ai_safe_string($publicBlock['title'] ?? '', 120),
        'intro' => demand_ai_safe_string($publicBlock['intro'] ?? '', 400),
        'links' => demand_normalize_internal_links($publicBlock['links'] ?? []),
    ];
    $carHint = is_array($payload['carHintProposal'] ?? null) ? $payload['carHintProposal'] : [];
    $response['carHintProposal'] = [
        'message' => demand_ai_safe_string($carHint['message'] ?? '', 1200),
        'suggestedText' => demand_ai_safe_string($carHint['suggestedText'] ?? '', 1800),
        'descriptionSuggestion' => demand_ai_safe_string($carHint['descriptionSuggestion'] ?? '', 2200),
        'risks' => demand_ai_safe_list($carHint['risks'] ?? [], 16, 300),
        'notesForAdmin' => demand_ai_safe_list($carHint['notesForAdmin'] ?? [], 16, 400),
    ];
    $response['adminNotes'] = demand_ai_safe_list($payload['adminNotes'] ?? [], 20, 400);

    $brief = is_array($payload['briefProposal'] ?? null) ? $payload['briefProposal'] : [];
    $targetIntent = array_key_exists('targetIntent', $brief) && $brief['targetIntent'] !== null ? demand_ai_safe_string($brief['targetIntent'], 500) : null;
    $response['briefProposal'] = [
        'targetIntent' => $targetIntent !== '' ? $targetIntent : null,
        'mustAnswer' => demand_ai_safe_list($brief['mustAnswer'] ?? [], 30, 260),
        'mustNotPromise' => demand_ai_safe_list($brief['mustNotPromise'] ?? [], 30, 260),
        'recommendedBlocks' => demand_ai_safe_list($brief['recommendedBlocks'] ?? [], 30, 180),
        'faqQuestions' => demand_ai_safe_list($brief['faqQuestions'] ?? [], 30, 260),
    ];
    $response['ignoredFields'] = $ignored;

    return $response;
}

function demand_ai_api_proposal_for_entity(string $entityType, array $response): array
{
    $proposal = [];
    if ($entityType === 'draft') {
        foreach ((array) ($response['draftProposal'] ?? []) as $field => $value) {
            if (in_array((string) $field, ['title', 'h1', 'metaDescription', 'intro', 'contentBlocks', 'faq', 'adminNote'], true)
                && $value !== null && $value !== '' && $value !== []
            ) {
                $proposal[(string) $field] = $value;
            }
        }
        if (!empty($response['internalLinkSuggestions'])) {
            $proposal['internalLinkSuggestions'] = (array) $response['internalLinkSuggestions'];
            $proposal['publicBlockProposal'] = (array) ($response['publicBlockProposal'] ?? []);
            $proposal['adminNotes'] = (array) ($response['adminNotes'] ?? []);
        }
        return $proposal;
    }

    if ($entityType === 'content_brief') {
        foreach ((array) ($response['briefProposal'] ?? []) as $field => $value) {
            if (in_array((string) $field, ['targetIntent', 'mustAnswer', 'mustNotPromise', 'recommendedBlocks', 'faqQuestions'], true)
                && $value !== null && $value !== '' && $value !== []
            ) {
                $proposal[(string) $field] = $value;
            }
        }
        return $proposal;
    }

    if ($entityType === 'car_hint') {
        foreach ((array) ($response['carHintProposal'] ?? []) as $field => $value) {
            if (in_array((string) $field, ['message', 'suggestedText', 'descriptionSuggestion', 'risks', 'notesForAdmin'], true)
                && $value !== null && $value !== '' && $value !== []
            ) {
                $proposal[(string) $field] = $value;
            }
        }

        return $proposal;
    }

    return [];
}

function demand_ai_api_ask(string $task, string $entityType = '', string $entityId = '', string $scopeFilter = '', string $currentTab = '', array $copyOptions = []): array
{
    require_permission('demand.ai_api.use');

    $settings = openai_ai_settings();
    if (empty($settings['enabled'])) {
        throw new RuntimeException('AI API отключён. Можно сформировать пакет для AI вручную.');
    }
    if (empty($settings['apiKeyConfigured'])) {
        throw new RuntimeException('DeepSeek API key не настроен. Можно сформировать пакет для AI вручную.');
    }
    $actor = current_admin_user() ?: 'system';
    $limit = openai_ai_limit_status($actor, $settings);
    if (!empty($limit['blocked'])) {
        throw new RuntimeException((string) $limit['message']);
    }

    $context = demand_ai_api_build_context($task, $entityType, $entityId, $scopeFilter, $currentTab, $copyOptions);
    $contextVersion = demand_ai_api_context_version($context);
    $prompt = json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($prompt === false) {
        throw new RuntimeException('AI API context could not be encoded.');
    }

    $runBase = [
        'id' => 'aiapi_' . bin2hex(random_bytes(8)),
        'createdAt' => now_iso(),
        'actor' => $actor,
        'scope_id' => (string) ($context['source']['scopeId'] ?? 'rent_rk'),
        'task' => $task,
        'entityType' => $entityType,
        'entityId' => $entityId,
        'model' => (string) ($settings['model'] ?? 'deepseek-v4-flash'),
        'promptHash' => openai_ai_hash_value($context),
    ];

    try {
        $raw = openai_ai_send_request(
            demand_ai_api_system_instructions(),
            $prompt,
            demand_ai_api_response_schema_for_task($task),
            [
                'model' => (string) ($settings['model'] ?? 'deepseek-v4-flash'),
                'timeoutSeconds' => (int) ($settings['perRequestTimeoutSeconds'] ?? 45),
                'retryCount' => (int) ($settings['retryCount'] ?? 0),
            ]
        );
        $currentContext = demand_ai_api_build_context($task, $entityType, $entityId, $scopeFilter, $currentTab, $copyOptions);
        if (!hash_equals($contextVersion, demand_ai_api_context_version($currentContext))) {
            throw new RuntimeException('Данные для AI изменились во время запроса. Сформируйте предложение заново.', 409);
        }
        $response = demand_ai_api_normalize_response((array) ($raw['response'] ?? []));
        $proposal = demand_ai_api_proposal_for_entity($entityType, $response);
        $diff = ($proposal && $entityType !== '' && $entityId !== '')
            ? demand_ai_build_preview_diff($entityType, $entityId, $proposal)
            : null;
        $run = openai_ai_log_run(array_merge($runBase, [
            'model' => (string) ($raw['model'] ?? $runBase['model']),
            'status' => 'success',
            'responseHash' => (string) ($raw['responseHash'] ?? openai_ai_hash_value($response)),
            'inputTokens' => (int) ($raw['inputTokens'] ?? 0),
            'outputTokens' => (int) ($raw['outputTokens'] ?? 0),
        ]));
        openai_ai_update_settings_meta([
            'lastSuccessAt' => now_iso(),
            'lastErrorAt' => null,
            'lastError' => null,
            'lastErrorCode' => null,
            'lastErrorTechnical' => null,
        ]);
        if ($entityType !== '' && $entityId !== '') {
            demand_ai_record_event($entityType, $entityId, 'ai_api_response_previewed', 'DeepSeek API response previewed. No changes were applied.', [
                'task' => $task,
                'runId' => (string) ($run['id'] ?? ''),
                'proposalHash' => $proposal ? demand_ai_hash($proposal) : '',
            ]);
        }

        return [
            'run' => $run,
            'contextHash' => openai_ai_hash_value($context),
            'response' => $response,
            'proposal' => $proposal,
            'diff' => $diff,
        ];
    } catch (Throwable $exception) {
        $error = openai_ai_sanitize_error($exception->getMessage());
        $stale = (int) $exception->getCode() === 409;
        openai_ai_log_run(array_merge($runBase, [
            'status' => $stale ? 'stale_rejected' : 'error',
            'errorCode' => $stale ? 'stale_context' : 'request_failed',
            'sanitizedError' => $error,
        ]));
        if (!$stale) {
            openai_ai_update_settings_meta([
                'lastErrorAt' => now_iso(),
                'lastError' => 'DeepSeek API request failed.',
                'lastErrorCode' => 'request_failed',
                'lastErrorTechnical' => $error,
            ]);
        }
        throw new RuntimeException($error, $stale ? 409 : 0, $exception);
    }
}

function demand_ai_copy_text_blob(array $proposal): string
{
    $parts = [
        (string) ($proposal['title'] ?? ''),
        (string) ($proposal['h1'] ?? ''),
        (string) ($proposal['metaDescription'] ?? ''),
        (string) ($proposal['intro'] ?? ''),
    ];
    foreach ((array) ($proposal['contentBlocks'] ?? []) as $block) {
        if (!is_array($block)) {
            continue;
        }
        $parts[] = (string) ($block['title'] ?? '');
        $parts[] = (string) ($block['body'] ?? $block['text'] ?? '');
        foreach ((array) ($block['items'] ?? []) as $item) {
            if (is_array($item)) {
                $parts[] = (string) ($item['question'] ?? '');
                $parts[] = (string) ($item['answer'] ?? '');
            }
        }
    }
    foreach ((array) ($proposal['faq'] ?? []) as $item) {
        if (is_array($item)) {
            $parts[] = (string) ($item['question'] ?? '');
            $parts[] = (string) ($item['answer'] ?? '');
        }
    }

    return trim(implode("\n", array_filter($parts, static fn($value): bool => trim((string) $value) !== '')));
}

function demand_ai_copy_quality_for_proposal(array $proposal, array $facts): array
{
    $text = mb_strtolower(demand_ai_copy_text_blob($proposal), 'UTF-8');
    $quality = demand_ai_copy_quality_default();
    $clicheHits = 0;
    foreach (demand_ai_copy_forbidden_cliches() as $cliche) {
        if ($cliche !== '' && str_contains($text, mb_strtolower($cliche, 'UTF-8'))) {
            $clicheHits++;
        }
    }
    if ($clicheHits > 0) {
        $quality['humanTone'] = 'too_salesy';
    }

    $primary = mb_strtolower((string) ($facts['demand']['primaryPhrase'] ?? ''), 'UTF-8');
    if ($primary !== '' && mb_strlen($primary, 'UTF-8') > 6) {
        $count = substr_count($text, $primary);
        $quality['seoOveruse'] = $count >= 4 ? 'high' : ($count >= 2 ? 'possible' : 'none');
    }

    if (preg_match('/сам(ая|ые|ый)\s+низк|машин[аы]\s+всегда\s+доступн|подач[ауы]\s+в\s+любое\s+время/u', $text)) {
        $quality['promiseRisk'] = 'high';
    } elseif (str_contains($text, 'без залога') && !str_contains($text, 'не стоит обещать') && !str_contains($text, 'зависит')) {
        $quality['promiseRisk'] = 'needs_check';
    }

    if (!preg_match('/залог|подач|даты|налич|автомобил|багаж/u', $text)) {
        $quality['specificity'] = 'needs_more_facts';
    }
    if (preg_match('/осуществляется|является|предоставляется|данная услуга/u', $text)) {
        $quality['humanTone'] = $quality['humanTone'] === 'good' ? 'too_dry' : $quality['humanTone'];
    }

    return $quality;
}

function demand_ai_copy_subject(array $draft, array $facts): array
{
    $haystack = mb_strtolower(
        (string) ($draft['h1'] ?? '') . ' ' .
        (string) ($draft['title'] ?? '') . ' ' .
        (string) ($facts['demand']['primaryPhrase'] ?? ''),
        'UTF-8'
    );
    $isMinivan = str_contains($haystack, 'минивэн') || str_contains($haystack, 'минивен') || str_contains($haystack, '7 мест') || str_contains($haystack, 'семимест');
    $region = demand_ai_safe_string($facts['factsToPreserve']['region'] ?? '', 120);
    if ($region === '') {
        $region = str_contains($haystack, 'крым') ? 'Крыму' : 'регионе';
    }

    return [
        'isMinivan' => $isMinivan,
        'region' => $region,
        'titleSubject' => $isMinivan ? 'минивэна' : 'автомобиля',
        'pageTitle' => $isMinivan ? 'Аренда минивэна в Крыму' : ((string) ($draft['h1'] ?? '') ?: 'Аренда авто'),
    ];
}

function demand_ai_copy_safe_intro(array $draft, array $facts, array $options): string
{
    $subject = demand_ai_copy_subject($draft, $facts);
    if (!empty($subject['isMinivan'])) {
        return !empty($options['regenerateAgain'])
            ? 'Минивэн берут не ради лишних мест в описании, а ради нормальной поездки: всем хватает пространства, вещи лежат в одной машине, маршрут не приходится делить между двумя водителями. Такой формат особенно удобен для семьи, компании друзей или дороги на несколько дней по Крыму. Перед бронированием лучше спокойно сверить свободные даты, количество мест, багажное пространство, залог и условия подачи по конкретному автомобилю.'
            : 'Минивэн обычно выбирают, когда поездка должна быть общей: семья, друзья, дети, чемоданы, дорога по Крыму и желание не делиться на две машины. В такой машине проще распределить вещи, ехать одним маршрутом и не подстраивать поездку под два экипажа. Перед бронированием важно проверить свободные даты, количество мест, багажное пространство, залог и условия подачи по конкретному автомобилю.';
    }

    return !empty($options['regenerateAgain'])
        ? 'Автомобиль в аренду нужен, когда хочется самому управлять маршрутом: выехать раньше, остановиться по дороге и не зависеть от расписания. Перед бронированием стоит сверить свободные даты, подходящий класс машины, залог, документы и условия подачи. Если часть условий не подтверждена заранее, их лучше уточнить до поездки.'
        : 'Арендованная машина помогает ехать по своему маршруту: без привязки к расписанию, с остановками по дороге и с понятным багажом рядом. Чтобы поездка прошла спокойно, перед бронированием нужно сверить свободные даты, автомобиль, залог, документы и условия подачи. Неподтвержденные условия лучше уточнять заранее, а не обещать их на странице.';
}

function demand_ai_copy_safe_blocks(array $draft, array $facts, array $options): array
{
    $subject = demand_ai_copy_subject($draft, $facts);
    $blocks = [];
    if (!empty($subject['isMinivan'])) {
        $blocks[] = [
            'type' => 'text',
            'title' => 'Когда минивэн действительно удобнее',
            'body' => 'Минивэн имеет смысл, когда нужно ехать вместе: семья с детьми, компания друзей, поездка с багажом или маршрут на несколько дней. В такой машине проще распределить вещи, не делить людей по разным авто и не подстраивать поездку под два водителя. Перед бронированием стоит проверить количество мест, багажное пространство и залог по конкретному автомобилю.',
        ];
        $blocks[] = [
            'type' => 'text',
            'title' => 'Что уточнить до бронирования',
            'body' => 'Главные факты лучше сверить заранее: свободные даты, комплектацию, документы, залог и условия подачи. Если нужна встреча в аэропорту, конкретный город или детское кресло, это не стоит считать автоматическим условием. Менеджер должен подтвердить такие детали до оплаты и передачи машины.',
        ];
        $blocks[] = [
            'type' => 'text',
            'title' => 'Залог и реальные условия',
            'body' => 'Точный залог зависит от автомобиля и условий аренды. Если запрос связан с поездкой без залога или особыми условиями, это нужно отдельно проверить перед бронированием. На странице безопаснее честно объяснить, что условия уточняются заранее, чем обещать то, что зависит от машины и даты.',
        ];
    } else {
        $blocks[] = [
            'type' => 'text',
            'title' => 'Для каких поездок подходит аренда',
            'body' => 'Машину обычно берут, когда маршрут важнее расписания: дорога между городами, поездка с багажом, семейные дела или несколько остановок за день. Перед выбором лучше понять, сколько людей едет, какой нужен багажник и где удобнее получить автомобиль. Доступность машины и условия подачи проверяются перед бронированием.',
        ];
        $blocks[] = [
            'type' => 'text',
            'title' => 'Что проверить заранее',
            'body' => 'До поездки стоит сверить документы, залог, свободные даты, класс автомобиля и место передачи. Цена и залог не должны угадываться по тексту страницы: они зависят от конкретной машины и условий аренды. Если услуга требует подтверждения, это лучше прямо указать в тексте.',
        ];
    }

    $existing = demand_ai_safe_content_blocks((array) ($draft['contentBlocks'] ?? []));
    if (count($existing) > count($blocks)) {
        foreach ($existing as $block) {
            if ((string) ($block['type'] ?? '') === 'faq') {
                continue;
            }
            if (count($blocks) >= min(6, count($existing))) {
                break;
            }
            $blocks[] = [
                'type' => (string) ($block['type'] ?? 'text'),
                'title' => (string) ($block['title'] ?? 'Важная деталь поездки'),
                'body' => demand_ai_safe_string((string) ($block['body'] ?? '') !== '' ? (string) $block['body'] : 'Эту часть стоит описать простым языком и оставить только подтвержденные факты.', 1200),
            ];
        }
    }

    return demand_ai_safe_content_blocks($blocks);
}

function demand_ai_copy_safe_faq(array $draft, array $facts, array $options): array
{
    $subject = demand_ai_copy_subject($draft, $facts);
    $faq = [
        [
            'question' => !empty($subject['isMinivan']) ? 'Кому подойдет минивэн?' : 'Когда стоит брать авто в аренду?',
            'answer' => !empty($subject['isMinivan'])
                ? 'Минивэн удобен для семьи, компании друзей, поездки с детьми или маршрута с багажом. Перед бронированием нужно проверить количество мест, багажное пространство и свободные даты по конкретному автомобилю.'
                : 'Аренда подходит, когда нужен свой маршрут, багаж рядом и возможность останавливаться по дороге. Перед бронированием нужно проверить свободные даты, автомобиль, документы и условия подачи.',
        ],
        [
            'question' => 'Как понять точный залог?',
            'answer' => 'Точный залог зависит от автомобиля и условий аренды. Если важно особое условие, например запрос без залога, его нужно отдельно подтвердить перед бронированием; без проверки это не стоит обещать на странице.',
        ],
        [
            'question' => 'Можно ли получить машину в нужном городе или аэропорту?',
            'answer' => 'Подача зависит от даты, места и доступности автомобиля. Если нужен аэропорт, конкретный город или позднее время, это лучше уточнить заранее перед бронированием.',
        ],
        [
            'question' => 'Какие автомобили доступны?',
            'answer' => 'Доступность проверяется по датам и конкретным машинам. На странице можно показывать только подтвержденные автомобили, а финальный выбор лучше сверить перед поездкой.',
        ],
    ];

    return demand_ai_safe_faq($faq);
}

function demand_ai_copy_replace_single_block(array $draft, array $facts, array $options): array
{
    $blocks = demand_ai_safe_content_blocks((array) ($draft['contentBlocks'] ?? []));
    $index = $options['targetBlockIndex'];
    if ($index === null || !isset($blocks[$index])) {
        return $blocks;
    }
    $block = $blocks[$index];
    if ((string) ($block['type'] ?? '') === 'faq') {
        $block['items'] = demand_ai_copy_safe_faq($draft, $facts, $options);
    } else {
        $title = demand_ai_safe_string($block['title'] ?? 'Важная деталь поездки', 160);
        $block['body'] = 'Этот блок лучше читать как ответ на практический вопрос клиента. Сохраните подтвержденные факты, объясните пользу простыми словами и отдельно отметьте, что цена, залог, наличие автомобиля и подача проверяются перед бронированием. Так текст остается полезным и не превращается в набор ключевых фраз.';
        if (stripos($title, 'залог') !== false) {
            $block['body'] = 'Залог нужно описывать честно: точная сумма зависит от автомобиля и условий аренды. Если клиент спрашивает про поездку без залога, это не обещание, а повод отдельно проверить условия перед бронированием. Без подтверждения безопаснее написать, что залог уточняется по конкретной машине.';
        }
    }
    $blocks[$index] = $block;

    return demand_ai_safe_content_blocks($blocks);
}

function demand_ai_copy_local_proposal(array $draft, string $task, array $options): array
{
    $facts = demand_ai_build_facts('draft', $draft);
    $subject = demand_ai_copy_subject($draft, $facts);
    $proposal = [
        'title' => demand_ai_safe_string((string) ($draft['title'] ?? '') !== '' ? (string) $draft['title'] : (string) $subject['pageTitle'], 160),
        'h1' => demand_ai_safe_string((string) ($draft['h1'] ?? '') !== '' ? (string) $draft['h1'] : (string) $subject['pageTitle'], 160),
        'metaDescription' => !empty($subject['isMinivan'])
            ? 'Когда минивэн удобен для поездки по Крыму, что проверить по местам, багажу, залогу и подаче перед бронированием.'
            : 'Как спокойно выбрать авто в аренду: маршрут, документы, залог, подача и условия, которые нужно уточнить перед бронированием.',
    ];

    if (in_array($task, ['regenerate_landing_draft_human', 'make_copy_more_human', 'reduce_seo_overoptimization', 'generate_alternative_variant', 'evaluate_copy_human_quality'], true)) {
        $proposal['intro'] = demand_ai_copy_safe_intro($draft, $facts, $options);
        $proposal['contentBlocks'] = demand_ai_copy_safe_blocks($draft, $facts, $options);
        $proposal['faq'] = demand_ai_copy_safe_faq($draft, $facts, $options);
    } elseif ($task === 'regenerate_landing_intro') {
        $proposal = ['intro' => demand_ai_copy_safe_intro($draft, $facts, $options)];
    } elseif ($task === 'regenerate_content_blocks') {
        $proposal = ['contentBlocks' => demand_ai_copy_safe_blocks($draft, $facts, $options)];
    } elseif (in_array($task, ['regenerate_single_content_block', 'rewrite_block_human', 'regenerate_preview_block_human', 'rewrite_preview_block_shorter', 'reduce_preview_block_seo_overuse'], true)) {
        $proposal = ['contentBlocks' => demand_ai_copy_replace_single_block($draft, $facts, $options)];
    } elseif (in_array($task, ['regenerate_faq', 'regenerate_preview_faq'], true)) {
        $proposal = ['faq' => demand_ai_copy_safe_faq($draft, $facts, $options)];
    } elseif ($task === 'suggest_preview_internal_links') {
        $links = function_exists('demand_suggest_internal_links_for_draft') ? demand_suggest_internal_links_for_draft($draft) : [];
        return [
            'summary' => 'Подобраны варианты внутренних ссылок для preview. Они не применены к черновику автоматически.',
            'styleUsed' => demand_ai_copy_style_label((string) ($options['style'] ?? 'calm_human')),
            'copyQuality' => demand_ai_copy_quality_default(),
            'draftProposal' => [],
            'internalLinkSuggestions' => (array) ($links['internalLinkSuggestions'] ?? []),
            'publicBlockProposal' => (array) ($links['publicBlockProposal'] ?? ['title' => '', 'intro' => '', 'links' => []]),
            'mustCheckBeforeApply' => ['Добавление ссылок в существующий черновик требует подтверждения admin.'],
            'notAllowed' => ['Не публиковать страницу, не открывать индексацию, не менять sitemap.xml или robots.txt.'],
        ];
    } else {
        $proposal['intro'] = demand_ai_copy_safe_intro($draft, $facts, $options);
    }

    $quality = demand_ai_copy_quality_for_proposal($proposal, $facts);

    return [
        'summary' => 'Подготовлен живой вариант текста без автоприменения. Факты, цена, залог, подача и наличие авто оставлены в зоне ручной проверки.',
        'styleUsed' => demand_ai_copy_style_label((string) ($options['style'] ?? 'calm_human')),
        'copyQuality' => $quality,
        'draftProposal' => $proposal,
        'mustCheckBeforeApply' => [
            'Проверить цену, залог и наличие автомобиля по реальным данным.',
            'Проверить условия подачи, если в тексте есть город, аэропорт или конкретное место.',
            'Убедиться, что в тексте нет обещаний без подтверждения.',
        ],
        'notAllowed' => [
            'Не публиковать автоматически.',
            'Не открывать индексацию.',
            'Не менять sitemap.xml, robots.txt, цены, залоги, тарифы или автомобили.',
        ],
    ];
}

function demand_ai_copy_subset_proposal(array $proposal, string $mode): array
{
    return match ($mode) {
        'intro' => array_key_exists('intro', $proposal) ? ['intro' => $proposal['intro']] : [],
        'blocks' => array_key_exists('contentBlocks', $proposal) ? ['contentBlocks' => $proposal['contentBlocks']] : [],
        'faq' => array_key_exists('faq', $proposal) ? ['faq' => $proposal['faq']] : [],
        default => $proposal,
    };
}

function demand_ai_copy_generate_preview(string $draftId, string $task, string $scopeFilter = '', array $options = []): array
{
    if (!has_permission('demand.ai_api.use') && !has_permission('demand.ai.package')) {
        require_permission('demand.ai_api.use');
    }
    $task = demand_ai_safe_string($task, 120);
    if (!demand_ai_is_human_copy_task($task)) {
        throw new RuntimeException('Эта AI-задача не относится к перегенерации текста черновика.');
    }
    $draft = demand_find_draft($draftId);
    if (!$draft) {
        throw new RuntimeException('Черновик не найден.');
    }
    demand_scope_guard($draft, 'demand.drafts.edit');
    $scope = demand_normalize_scope_id($scopeFilter);
    $draftScope = demand_normalize_scope_id((string) ($draft['scope_id'] ?? 'rent_rk'));
    if ($scope !== '' && $scope !== 'all' && $scope !== $draftScope) {
        deny_scope_access();
    }

    $options = demand_ai_normalize_copy_options($options);
    $settings = function_exists('openai_ai_settings') ? openai_ai_settings() : [];
    $apiReady = !empty($settings['enabled']) && !empty($settings['apiKeyConfigured']) && has_permission('demand.ai_api.use');
    $source = 'local_safe_fallback';
    $run = [];

    if ($apiReady) {
        try {
            $api = demand_ai_api_ask($task, 'draft', $draftId, $scopeFilter, 'drafts', $options);
            $response = (array) ($api['response'] ?? []);
            $proposal = (array) ($api['proposal'] ?? []);
            $diff = is_array($api['diff'] ?? null) ? $api['diff'] : demand_ai_build_preview_diff('draft', $draftId, $proposal);
            $source = 'deepseek_api';
            $run = (array) ($api['run'] ?? []);
        } catch (Throwable $exception) {
            $response = demand_ai_copy_local_proposal($draft, $task, $options);
            $proposal = (array) ($response['draftProposal'] ?? []);
            $diff = demand_ai_build_preview_diff('draft', $draftId, $proposal);
            $run = openai_ai_log_run([
                'id' => 'aiapi_' . bin2hex(random_bytes(8)),
                'createdAt' => now_iso(),
                'actor' => current_admin_user() ?: 'system',
                'scope_id' => $draftScope,
                'task' => $task,
                'entityType' => 'draft',
                'entityId' => $draftId,
                'model' => 'local_safe_fallback',
                'status' => 'fallback_after_error',
                'promptHash' => openai_ai_hash_value(['draftId' => $draftId, 'task' => $task, 'options' => $options]),
                'responseHash' => openai_ai_hash_value($response),
                'errorCode' => 'api_fallback',
                'sanitizedError' => openai_ai_sanitize_error($exception->getMessage()),
            ]);
        }
    } else {
        $response = demand_ai_copy_local_proposal($draft, $task, $options);
        $proposal = (array) ($response['draftProposal'] ?? []);
        $diff = demand_ai_build_preview_diff('draft', $draftId, $proposal);
        if (function_exists('openai_ai_log_run')) {
            $run = openai_ai_log_run([
                'id' => 'aiapi_' . bin2hex(random_bytes(8)),
                'createdAt' => now_iso(),
                'actor' => current_admin_user() ?: 'system',
                'scope_id' => $draftScope,
                'task' => $task,
                'entityType' => 'draft',
                'entityId' => $draftId,
                'model' => 'local_safe_fallback',
                'status' => 'local_preview',
                'promptHash' => openai_ai_hash_value(['draftId' => $draftId, 'task' => $task, 'options' => $options]),
                'responseHash' => openai_ai_hash_value($response),
            ]);
        }
    }

    $response = demand_ai_api_normalize_response($response);
    if (!$proposal) {
        $proposal = demand_ai_api_proposal_for_entity('draft', $response);
    }
    $quality = demand_ai_copy_quality_for_proposal($proposal, demand_ai_build_facts('draft', $draft));
    if (empty($response['copyQuality']) || $response['copyQuality'] === demand_ai_copy_quality_default()) {
        $response['copyQuality'] = $quality;
    }
    if ((string) ($response['styleUsed'] ?? '') === '') {
        $response['styleUsed'] = demand_ai_copy_style_label((string) ($options['style'] ?? 'calm_human'));
    }

    demand_ai_record_event('draft', $draftId, 'ai_copy_regeneration_previewed', 'AI prepared a human copy variant for preview. No changes were applied.', [
        'task' => $task,
        'source' => $source,
        'runId' => (string) ($run['id'] ?? ''),
        'proposalHash' => demand_ai_hash($proposal),
        'style' => (string) ($options['style'] ?? 'calm_human'),
    ]);

    return [
        'source' => $source,
        'run' => $run,
        'response' => $response,
        'proposal' => $proposal,
        'diff' => $diff,
        'request' => [
            'draftId' => $draftId,
            'task' => $task,
            'options' => $options,
            'proposalHash' => demand_ai_hash($proposal),
        ],
    ];
}

function demand_ai_api_apply_proposal(string $entityType, string $entityId, array $proposal, string $adminUser, string $runId = ''): array
{
    require_permission('demand.ai_api.apply');

    $result = demand_ai_apply_manual_proposal($entityType, $entityId, $proposal, $adminUser);
    demand_ai_record_event($entityType, $entityId, 'ai_api_proposal_applied', 'DeepSeek API proposal applied manually after preview. Publication and indexing were not changed.', [
        'runId' => demand_ai_safe_string($runId, 80),
        'proposalHash' => demand_ai_hash($proposal),
    ], $adminUser);

    return $result;
}
