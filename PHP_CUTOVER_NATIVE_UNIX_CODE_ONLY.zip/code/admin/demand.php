<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
require_permission('demand.view');

function demand_admin_status_class(string $status): string
{
    return match ($status) {
        'active', 'ready_for_review', 'done', 'approved', 'approved_for_public_preview', 'approved_for_future_publication', 'published_indexed', 'index_allowed', 'in_sitemap', 'high', 'ready_noindex', 'ready_for_future_index' => 'status-free',
        'draft', 'new', 'needs_review', 'in_review', 'needs_human_review', 'published_noindex', 'ready_for_index_review', 'planned', 'medium' => 'status-reserved',
        'blocked', 'noindex', 'not_in_sitemap', 'do_not_publish', 'risky', 'rejected', 'removed_from_sitemap', 'rolled_back', 'needs_business_decision' => 'status-busy',
        'archived', 'merged', 'not_target', 'excluded', 'postponed', 'low' => 'status-canceled',
        default => 'status-service',
    };
}

function demand_admin_recommendation_label(string $type): string
{
    return demand_recommendation_type_labels()[$type] ?? $type;
}

function demand_admin_priority_label(string $priority): string
{
    $stageBLabels = [
        'merge_with_existing_page' => 'Объединить с существующей страницей',
        'page_exists_good_fit' => 'Страница уже подходит',
        'page_exists_weak_fit' => 'Есть похожая страница',
        'draft_exists' => 'Есть черновик',
        'no_page_found' => 'Страницы нет',
        'faq_better_than_page' => 'Лучше FAQ',
        'good_supply_fit' => 'Предложение есть',
        'partial_supply_fit' => 'Предложение нужно дополнить',
        'weak_supply_fit' => 'Предложение слабое',
    ];
    if (isset($stageBLabels[$priority])) {
        return $stageBLabels[$priority];
    }

    return [
        'high' => 'Высокий',
        'medium' => 'Средний',
        'low' => 'Низкий',
        'blocked' => 'Заблокирован',
        'needs_business_decision' => 'Нужно решение',
    ][$priority] ?? ($priority !== '' ? $priority : '—');
}

function demand_admin_recommendation_status_label(string $status): string
{
    return [
        'new' => 'Новая',
        'in_review' => 'На проверке',
        'done' => 'Выполнено',
        'rejected' => 'Отклонено',
        'archived' => 'В архиве',
    ][$status] ?? ($status !== '' ? $status : 'Новая');
}

function demand_admin_ui_label(string $value): string
{
    $value = trim($value);
    if (function_exists('demand_ai_stop_reason_labels') && isset(demand_ai_stop_reason_labels()[$value])) {
        return demand_ai_stop_reason_label($value);
    }
    $stageBLabels = [
        'merge_with_existing_page' => 'Объединить с существующей страницей',
        'page_exists_good_fit' => 'Страница уже подходит',
        'page_exists_weak_fit' => 'Есть похожая страница',
        'draft_exists' => 'Есть черновик',
        'no_page_found' => 'Страницы нет',
        'faq_better_than_page' => 'Лучше FAQ',
        'good_supply_fit' => 'Предложение есть',
        'partial_supply_fit' => 'Предложение нужно дополнить',
        'weak_supply_fit' => 'Предложение слабое',
    ];
    if (isset($stageBLabels[$value])) {
        return $stageBLabels[$value];
    }
    if ($value === '') {
        return '—';
    }

    return [
        'dry-run' => 'Пробная проверка без изменений',
        'dry_run' => 'Пробная проверка без изменений',
        'live' => 'Ручная загрузка',
        'live_controlled' => 'Ручная загрузка данных',
        'sync' => 'Загрузка данных',
        'mock' => 'Тестовые данные',
        'manual_import' => 'Ручная загрузка файла',
        'api_ready_placeholder' => 'Подготовлено к API',
        'disabled' => 'Выключено',
        'draft' => 'Черновик',
        'idea' => 'Идея',
        'needs_review' => 'Нужно проверить',
        'needs_fixes' => 'Нужны правки',
        'confusing' => 'Непонятно',
        'clear' => 'Понятно',
        'ready' => 'Готово',
        'needs_structure' => 'Нужна структура',
        'needs_facts' => 'Нужны факты',
        'approved' => 'Одобрено',
        'approved_for_public_preview' => 'Готово к просмотру',
        'approved_for_future_publication' => 'Одобрено на будущее',
        'published_noindex' => 'Опубликовано для просмотра, поиску закрыто',
        'ready_for_index_review' => 'Готово к открытию для поиска',
        'published_indexed' => 'Открыто для поиска',
        'archived' => 'В архиве',
        'merged' => 'Объединено',
        'rolled_back' => 'Возвращена предыдущая версия',
        'blocked' => 'Заблокировано',
        'noindex' => 'Закрыто от поиска',
        'not_in_sitemap' => 'Не в карте сайта для поисковиков',
        'index_allowed' => 'Открыто для поиска',
        'in_sitemap' => 'Добавлено в карту сайта для поисковиков',
        'removed_from_sitemap' => 'Убрано из карты сайта для поисковиков',
        'ready_for_review' => 'Готово к проверке',
        'needs_data' => 'Не хватает данных',
        'needs_human_review' => 'Нужна ручная проверка',
        'risky' => 'Есть риск',
        'rejected' => 'Отклонено',
        'new' => 'Новое',
        'in_review' => 'На проверке',
        'done' => 'Выполнено',
        'not_target' => 'Нецелевое',
        'excluded' => 'Исключено',
        'postponed' => 'Отложено',
        'planned' => 'В плане',
        'ready_noindex' => 'Готово к просмотру',
        'ready_for_future_index' => 'Готово к будущему открытию поиска',
        'active' => 'Активно',
        'low' => 'Низкий',
        'medium' => 'Средний',
        'high' => 'Высокий',
        'queued' => 'В очереди',
        'running' => 'Выполняется',
        'success' => 'Успешно',
        'partial_success' => 'Частично успешно',
        'failed' => 'Ошибка',
        'cancelled' => 'Отменено',
        'rate_limited' => 'Лимит запросов',
        'add' => 'Добавить',
        'update' => 'Обновить',
        'skip' => 'Пропустить',
        'not_configured' => 'Не настроено',
        'configured' => 'Настроено',
        'test_success' => 'Проверка прошла',
        'test_failed' => 'Проверка не прошла',
        'error' => 'Ошибка',
        'not_required' => 'Не требуется',
        'true' => 'да',
        'false' => 'нет',
        'yes' => 'да',
        'no' => 'нет',
        'keyword' => 'Фраза',
        'landing_page' => 'Страница',
        'city' => 'Город',
        'region' => 'Регион',
        'car_class' => 'Класс авто',
        'condition' => 'Условия',
        'route' => 'Маршрут',
        'airport' => 'Аэропорт',
        'family' => 'Семья',
        'season' => 'Сезон',
        'price' => 'Цена',
        'duration' => 'Срок аренды',
        'service' => 'Услуга',
        'faq' => 'Вопросы и ответы',
        'unknown' => 'Не определено',
        'commercial' => 'Коммерческий спрос',
        'informational' => 'Вопрос/FAQ',
        'unsafe' => 'Опасный запрос',
        'city_rental' => 'Городская аренда',
        'region_rental' => 'Региональная аренда',
        'car_class_rental' => 'Класс авто',
        'condition_rental' => 'Условие аренды',
        'airport_delivery' => 'Аэропорт / подача',
        'family_trip' => 'Семейная поездка',
        'route_trip' => 'Маршрут / поездка',
        'price_sensitive' => 'Цена важна',
        'deposit_sensitive' => 'Вопрос залога',
        'driverless' => 'Без водителя',
        'comparison' => 'Сравнение вариантов',
        'unsafe_or_unsupported' => 'Опасный запрос',
        'excluded' => 'Исключено из SEO',
        'not_relevant_for_car_rental' => 'нецелевой запрос',
        'taxi_transfer' => 'Такси / трансфер',
        'car_sales' => 'Покупка или продажа авто',
        'repair_parts_service' => 'Ремонт или запчасти',
        'job_driver' => 'Работа водителем',
        'commercial_use_not_supported' => 'Коммерческое использование',
        'carsharing' => 'Каршеринг',
        'driver_service_not_supported' => 'Аренда с водителем',
        'unsupported_vehicle_type' => 'Неподдерживаемый транспорт',
        'unsafe_legal_request' => 'Небезопасное условие',
        'irrelevant_rental_object' => 'Не автомобиль',
        'competitor_or_platform_query' => 'Площадка или конкурент',
        'generic_noise' => 'Шумный запрос',
        'unrelated_service' => 'Нецелевая услуга',
        'create_landing_page' => 'Готовить страницу',
        'improve_existing_page' => 'Улучшить страницу',
        'create_faq' => 'Добавить FAQ',
        'add_condition_block' => 'Добавить блок условий',
        'create_car_card_hint' => 'Доработать карточки авто',
        'create_content_brief' => 'Создать ТЗ для страницы',
        'ignore_as_irrelevant' => 'Не использовать',
        'maybe_use_as_negative_ad_keyword' => 'Можно в минус-фразы',
        'unknown_region' => 'регион не подтверждён',
        'landing_page' => 'Посадочная страница',
        'car_card_update' => 'Доработка карточки авто',
        'faq_block' => 'FAQ-блок',
        'intro_answer' => 'Короткий ответ',
        'who_is_it_for' => 'Кому подойдёт',
        'available_cars' => 'Какие авто подходят',
        'conditions' => 'Что важно знать',
        'deposit_explanation' => 'Залог',
        'price_explanation' => 'Цена',
        'pickup_delivery' => 'Получение и подача',
        'airport_pickup' => 'Аэропорт',
        'family_use' => 'Для семьи',
        'luggage_and_seats' => 'Места и багаж',
        'weekly_rental' => 'Аренда на неделю',
        'route_use' => 'Маршрут',
        'comparison' => 'Сравнение',
        'internal_links' => 'Внутренние ссылки',
        'what_to_confirm_before_booking' => 'Что уточнить',
        'safety_limitations' => 'Ограничения',
        'not_supported_explanation' => 'Безопасное объяснение',
        'text' => 'Текстовый блок',
        'internal_linking' => 'Внутренние ссылки',
        'category_page' => 'Категорийная страница',
        'city_page' => 'Городская страница',
        'condition_explanation' => 'Объяснение условий',
        'do_not_create_page' => 'Не делать страницу',
        'needs_business_decision' => 'Нужно решение',
        'create_landing_draft' => 'Создать черновик страницы',
        'create_city_landing_draft' => 'Создать городской черновик',
        'create_class_landing_draft' => 'Создать черновик по классу авто',
        'create_condition_explanation' => 'Подготовить объяснение условий',
        'add_faq' => 'Добавить FAQ',
        'add_internal_links' => 'Добавить внутренние ссылки',
        'improve_car_cards' => 'Доработать карточки авто',
        'postpone_until_supply_exists' => 'Отложить до появления предложения',
        'block_false_promise_page' => 'Не делать страницу с ложным обещанием',
    ][$value] ?? $value;
}

function demand_admin_risk_label(string $flag): string
{
    return [
        'no_matching_cars' => 'нет подходящих авто',
        'no_price_data' => 'нет данных о цене',
        'no_deposit_data' => 'нет данных о залоге',
        'possible_false_promise' => 'риск ложного обещания',
        'too_generic' => 'слишком общий запрос',
        'too_similar_to_existing_page' => 'похоже на существующую страницу',
        'low_frequency' => 'низкая частотность',
        'needs_human_review' => 'нужна ручная проверка',
        'condition_not_supported' => 'условие не подтверждено',
        'region_not_supported' => 'регион не подтверждён',
        'external_api_imported' => 'получено из внешнего источника',
        'missing_data' => 'не хватает данных',
        'not_relevant_for_car_rental' => 'нецелевой запрос',
        'unknown_region' => 'регион не подтверждён',
        'region_not_confirmed' => 'регион не подтверждён',
        'unsupported_legal_request' => 'опасное условие',
        'price_claim_risk' => 'риск обещания цены',
        'availability_claim_risk' => 'риск обещания доступности',
        'airport_delivery_not_confirmed' => 'подача не подтверждена',
        'driver_service_not_confirmed' => 'водитель не подтверждён',
        'needs_business_decision' => 'нужно решение владельца',
    ][$flag] ?? demand_admin_ui_label($flag);
}

function demand_admin_stage_b_blocks_text(array $item): string
{
    $blocks = array_values(array_filter(array_map('strval', (array) ($item['whatBlocks'] ?? [])), static fn(string $value): bool => trim($value) !== ''));
    $labels = [
        'matching_cars' => 'нет подходящих авто',
        'price' => 'нет цены',
        'deposit' => 'нет залога',
        'photo' => 'нет фото',
        'description' => 'нужно описание',
        'public_visibility' => 'проверить публичный статус авто',
    ];
    $parts = [];
    foreach ($blocks as $block) {
        $parts[] = $labels[$block] ?? $block;
        if (count($parts) >= 3) {
            break;
        }
    }
    if (!$parts && trim((string) ($item['contentGapSummary'] ?? '')) !== '') {
        return (string) $item['contentGapSummary'];
    }

    return $parts ? implode('; ', $parts) : 'Критичных препятствий не видно';
}

function demand_admin_stage_c_questions_text(array $item, int $limit = 4): string
{
    $questions = [];
    foreach ((array) ($item['userQuestionMap'] ?? []) as $question) {
        if (!is_array($question)) {
            continue;
        }
        $text = trim((string) ($question['question'] ?? ''));
        if ($text !== '') {
            $questions[] = $text;
        }
        if (count($questions) >= $limit) {
            break;
        }
    }

    return $questions ? implode('; ', $questions) : 'Вопросы ещё не рассчитаны';
}

function demand_admin_stage_c_blocks_text(array $item, int $limit = 4): string
{
    $blocks = [];
    foreach ((array) ($item['safeContentBlocks'] ?? []) as $block) {
        if (!is_array($block)) {
            continue;
        }
        $type = trim((string) ($block['type'] ?? ''));
        if ($type !== '') {
            $blocks[] = demand_admin_ui_label($type);
        }
        if (count($blocks) >= $limit) {
            break;
        }
    }

    return $blocks ? implode('; ', $blocks) : 'Блоки не нужны или запрос исключён';
}

function demand_admin_stage_c_gap_text(array $item, int $limit = 4): string
{
    $report = is_array($item['contentGapReport'] ?? null) ? $item['contentGapReport'] : [];
    $parts = [];
    foreach (['missingBlocks', 'weakBlocks', 'dangerousClaims', 'recommendedFixes', 'clarityWarnings'] as $field) {
        foreach ((array) ($report[$field] ?? []) as $value) {
            $value = trim((string) $value);
            if ($value !== '') {
                $parts[] = in_array($field, ['missingBlocks', 'weakBlocks'], true) ? demand_admin_ui_label($value) : $value;
            }
            if (count($parts) >= $limit) {
                break 2;
            }
        }
    }

    return $parts ? implode('; ', $parts) : 'Крупных пробелов не видно';
}

function demand_admin_stage_c_score_text(array $item, string $field): string
{
    $score = is_array($item[$field] ?? null) ? $item[$field] : [];
    $level = trim((string) ($score['level'] ?? ''));
    $summary = trim((string) ($score['summary'] ?? ''));
    if ($level === '' && $summary === '') {
        return 'Не рассчитано';
    }

    return trim(demand_admin_ui_label($level) . ($summary !== '' ? ': ' . $summary : ''));
}

function demand_admin_editorial_values(array $values, int $limit = 7, ?callable $labeler = null): array
{
    $labeler ??= static fn(string $value): string => $value;
    $items = [];
    foreach ($values as $value) {
        if (is_array($value)) {
            $value = (string) ($value['question'] ?? $value['title'] ?? $value['summary'] ?? '');
        }
        $value = trim((string) $value);
        if ($value === '') {
            continue;
        }
        $items[] = $labeler($value);
        if (count($items) >= $limit) {
            break;
        }
    }

    return $items;
}

function demand_admin_editorial_questions(array $draft, int $limit = 7): array
{
    $items = [];
    foreach ((array) ($draft['mustAnswer'] ?? []) as $value) {
        $value = trim((string) $value);
        if ($value !== '') {
            $items[] = $value;
        }
        if (count($items) >= $limit) {
            return $items;
        }
    }
    foreach ((array) ($draft['userQuestionMap'] ?? []) as $question) {
        if (!is_array($question)) {
            continue;
        }
        $value = trim((string) ($question['question'] ?? ''));
        if ($value !== '') {
            $items[] = $value;
        }
        if (count($items) >= $limit) {
            break;
        }
    }

    return array_values(array_unique($items));
}

function demand_admin_editorial_gap_items(array $draft, int $limit = 7): array
{
    $report = is_array($draft['contentGapReport'] ?? null) ? (array) $draft['contentGapReport'] : [];
    $items = [];
    foreach (['missingBlocks', 'weakBlocks', 'dangerousClaims', 'recommendedFixes', 'clarityWarnings'] as $field) {
        foreach ((array) ($report[$field] ?? []) as $value) {
            $value = trim((string) $value);
            if ($value === '') {
                continue;
            }
            $items[] = in_array($field, ['missingBlocks', 'weakBlocks'], true) ? demand_admin_ui_label($value) : $value;
            if (count($items) >= $limit) {
                break 2;
            }
        }
    }

    return array_values(array_unique($items));
}

function demand_admin_editorial_block_groups(array $draft): array
{
    $groups = [
        'required' => [],
        'recommended' => [],
        'confirmed' => [],
        'forbidden' => [],
    ];
    foreach ((array) ($draft['safeContentBlocks'] ?? []) as $block) {
        if (!is_array($block)) {
            continue;
        }
        $group = demand_draft_editorial_block_group($draft, $block);
        $groups[$group][] = $block;
    }

    return $groups;
}

function demand_admin_editorial_group_label(string $group): string
{
    return [
        'required' => 'Обязательные',
        'recommended' => 'Желательные',
        'confirmed' => 'Только если подтверждено',
        'forbidden' => 'Не использовать для этой страницы',
    ][$group] ?? $group;
}

function demand_admin_editorial_add_block_label(array $status): string
{
    return (string) ($status['key'] ?? '') === 'needs_confirmation'
        ? 'Добавить как осторожное объяснение'
        : 'Добавить заготовку блока';
}

function demand_admin_list_labels(array $values, ?callable $labeler = null): string
{
    $labeler ??= static fn(string $value): string => demand_admin_ui_label($value);
    $labels = [];
    foreach ($values as $value) {
        $value = trim((string) $value);
        if ($value !== '') {
            $labels[] = $labeler($value);
        }
    }

    return $labels ? implode(', ', $labels) : '—';
}

function demand_admin_wordstat_method_label(string $method): string
{
    return [
        'getTop' => 'Похожие запросы',
        'getDynamics' => 'Динамика спроса',
        'getRegionsDistribution' => 'Спрос по регионам',
        'getRegionsTree' => 'Справочник регионов',
    ][$method] ?? demand_admin_ui_label($method);
}

function demand_admin_scope_filter_url(string $tab, string $scopeFilter, array $extra = []): string
{
    $base = ['tab' => $tab, 'scope' => $scopeFilter];
    if (demand_admin_ui_mode() === 'detail') {
        $base['view'] = 'detail';
    }

    return 'demand.php?' . http_build_query(array_merge($base, $extra));
}

function demand_admin_ui_mode(): string
{
    $mode = strtolower(trim((string) ($_GET['view'] ?? $_POST['view'] ?? 'simple')));

    return $mode === 'detail' ? 'detail' : 'simple';
}

function demand_admin_simple_tabs(): array
{
    return [
        'start' => true,
        'materials' => true,
        'keywords' => true,
        'demand_map' => true,
        'drafts' => true,
        'technical' => true,
    ];
}

function demand_admin_draft_filter_options(): array
{
    return [
        'all' => 'Все черновики',
        'needs_fixes' => 'Нужно исправить',
        'ready_preview' => 'Готовы к просмотру',
        'noindex_preview' => 'Опубликованы для просмотра',
        'ready_search' => 'Готовы к поиску',
        'archived' => 'Архив',
    ];
}

function demand_admin_draft_counts(array $drafts): array
{
    $counts = [
        'all' => 0,
        'needs_fixes' => 0,
        'ready_preview' => 0,
        'noindex_preview' => 0,
        'ready_search' => 0,
        'search_open' => 0,
        'archived' => 0,
    ];
    foreach ($drafts as $draft) {
        if (!is_array($draft)) {
            continue;
        }
        $counts['all']++;
        $stage = demand_simple_publish_stage($draft);
        $stageKey = (string) ($stage['key'] ?? 'draft');
        if (isset($counts[$stageKey])) {
            $counts[$stageKey]++;
        }
        if ($stageKey === 'closed') {
            $counts['archived']++;
        }
    }

    return $counts;
}

function demand_admin_draft_matches_filter(array $draft, string $filter): bool
{
    if ($filter === 'all') {
        return true;
    }
    $stage = demand_simple_publish_stage($draft);
    $stageKey = (string) ($stage['key'] ?? 'draft');
    if ($filter === 'archived') {
        return $stageKey === 'closed';
    }

    return $stageKey === $filter;
}

function demand_admin_draft_blockers_text(array $draft): string
{
    $checks = (array) ($draft['readinessChecks'] ?? []);
    $groups = demand_group_readiness_checks($checks);
    $items = [];
    foreach (['blocked', 'needs_fixes'] as $groupKey) {
        foreach ((array) ($groups[$groupKey] ?? []) as $check) {
            if (!is_array($check)) {
                continue;
            }
            $message = trim((string) ($check['message'] ?? ''));
            if ($message !== '') {
                $items[] = $message;
            }
            if (count($items) >= 3) {
                break 2;
            }
        }
    }
    if ($items) {
        return implode(' ', $items);
    }
    $riskFlags = demand_landing_risk_flags($draft);
    if ($riskFlags) {
        return 'Проверьте риски: ' . demand_admin_list_labels($riskFlags, 'demand_admin_risk_label') . '.';
    }
    $stage = demand_simple_publish_stage($draft);

    return match ((string) ($stage['key'] ?? 'draft')) {
        'ready_preview' => 'Критичных препятствий не видно. Осталось опубликовать для просмотра.',
        'noindex_preview' => 'Страница уже доступна по ссылке и закрыта от поиска.',
        'ready_search' => 'Перед открытием для поиска проверьте страницу глазами.',
        'search_open' => 'Страница открыта для поиска.',
        'closed' => 'Черновик в архиве или закрыт.',
        default => 'Готовность ещё не проверена.',
    };
}

function demand_admin_draft_next_action_text(array $draft): string
{
    $stage = demand_simple_publish_stage($draft);
    $stageKey = (string) ($stage['key'] ?? 'draft');
    $readiness = (string) ($draft['readinessStatus'] ?? 'not_checked');

    if ($stageKey === 'needs_fixes') {
        return 'Откройте черновик и исправьте подсвеченные пункты.';
    }
    if ($readiness === 'not_checked' || $stageKey === 'draft') {
        return 'Проверьте готовность черновика.';
    }

    return match ($stageKey) {
        'ready_preview' => 'Опубликуйте страницу для просмотра.',
        'noindex_preview' => 'Проверьте публичную страницу и решите, открывать ли поиск.',
        'ready_search' => 'Можно вручную открыть страницу для поиска.',
        'search_open' => 'Периодически проверяйте качество страницы.',
        'closed' => 'Активных действий нет.',
        default => 'Откройте черновик и продолжите работу.',
    };
}

function demand_admin_stage_nav_items(array $stats, array $plans, array $drafts, string $scopeFilter): array
{
    $keywordCount = (int) ($stats['keywords'] ?? 0);
    $planCount = count($plans);
    $draftCounts = demand_admin_draft_counts($drafts);
    $hasProblemDrafts = $draftCounts['needs_fixes'] > 0;
    $hasCheckedDrafts = false;
    foreach ($drafts as $draft) {
        if (is_array($draft) && in_array((string) ($draft['readinessStatus'] ?? ''), ['ready', 'needs_fixes', 'blocked'], true)) {
            $hasCheckedDrafts = true;
            break;
        }
    }

    return [
        [
            'label' => 'Спрос',
            'href' => demand_admin_scope_filter_url('keywords', $scopeFilter),
            'state' => $keywordCount > 0 ? 'done' : 'current',
            'hint' => $keywordCount > 0 ? 'Фразы есть' : 'Нужно добавить фразы',
        ],
        [
            'label' => 'План',
            'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter) . '#seo-launch-plan',
            'state' => $planCount > 0 ? 'done' : ($keywordCount > 0 ? 'current' : 'pending'),
            'hint' => $planCount > 0 ? 'План готов' : 'Нужно построить план',
        ],
        [
            'label' => 'Черновики',
            'href' => demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => 'all']) . '#demand-drafts-worklist',
            'state' => $draftCounts['all'] > 0 ? 'done' : ($planCount > 0 ? 'current' : 'pending'),
            'hint' => $draftCounts['all'] > 0 ? 'Есть черновики' : 'Пока пусто',
        ],
        [
            'label' => 'Проверка',
            'href' => demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => $hasProblemDrafts ? 'needs_fixes' : 'all']) . '#demand-drafts-worklist',
            'state' => $hasProblemDrafts ? 'problem' : ($hasCheckedDrafts ? 'done' : ($draftCounts['all'] > 0 ? 'current' : 'pending')),
            'hint' => $hasProblemDrafts ? 'Есть правки' : ($hasCheckedDrafts ? 'Проверено' : 'Ждёт проверки'),
        ],
        [
            'label' => 'Публикация',
            'href' => demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => $draftCounts['ready_preview'] > 0 ? 'ready_preview' : 'noindex_preview']) . '#demand-drafts-worklist',
            'state' => $draftCounts['search_open'] > 0 ? 'done' : (($draftCounts['ready_preview'] + $draftCounts['noindex_preview'] + $draftCounts['ready_search']) > 0 ? 'current' : 'pending'),
            'hint' => $draftCounts['search_open'] > 0 ? 'Есть открытые страницы' : 'Только вручную',
        ],
    ];
}

function demand_admin_ai_return_url(string $entityType, string $entityId, string $tab, string $scopeFilter): string
{
    if ($entityType === 'draft') {
        return demand_admin_scope_filter_url('drafts', $scopeFilter, ['preview_draft' => $entityId, 'view' => 'detail']);
    }
    if ($entityType === 'content_brief') {
        $brief = demand_ai_find_content_brief($entityId);
        return demand_admin_scope_filter_url('demand_map', $scopeFilter, [
            'cluster_id' => (string) ($brief['clusterId'] ?? ''),
            'brief_id' => $entityId,
            'view' => 'detail',
        ]);
    }
    if ($entityType === 'launch_plan_item') {
        $plan = demand_map_find_plan($entityId);
        return demand_admin_scope_filter_url('demand_map', $scopeFilter, [
            'cluster_id' => (string) ($plan['clusterId'] ?? ''),
            'view' => 'detail',
        ]);
    }
    if ($entityType === 'demand_cluster') {
        return demand_admin_scope_filter_url('demand_map', $scopeFilter, ['cluster_id' => $entityId, 'view' => 'detail']);
    }
    if ($entityType === 'car_hint') {
        return demand_admin_scope_filter_url('car_hints', $scopeFilter, ['hint_id' => $entityId, 'view' => 'detail']);
    }

    return demand_admin_scope_filter_url($tab, $scopeFilter, ['view' => 'detail']);
}

function demand_admin_ai_context_matches($state, string $entityType, string $entityId): bool
{
    return is_array($state)
        && (string) ($state['entityType'] ?? '') === $entityType
        && (string) ($state['entityId'] ?? '') === $entityId;
}

function demand_admin_ai_api_context_matches($state, string $contextTab, string $entityType = '', string $entityId = ''): bool
{
    if (!is_array($state)) {
        return false;
    }
    if ($entityType !== '' || $entityId !== '') {
        return (string) ($state['entityType'] ?? '') === $entityType
            && (string) ($state['entityId'] ?? '') === $entityId;
    }

    return (string) ($state['contextTab'] ?? '') === $contextTab
        && (string) ($state['entityType'] ?? '') === ''
        && (string) ($state['entityId'] ?? '') === '';
}

function demand_admin_ai_api_return_url(string $contextTab, string $scopeFilter, string $entityType = '', string $entityId = ''): string
{
    if ($entityType !== '' && $entityId !== '') {
        return demand_admin_ai_return_url($entityType, $entityId, $contextTab, $scopeFilter);
    }

    return demand_admin_scope_filter_url($contextTab !== '' ? $contextTab : 'start', $scopeFilter);
}

function demand_admin_ai_dialog_return_url(string $contextTab, string $scopeFilter, string $entityType = '', string $entityId = ''): string
{
    if ($entityType === 'draft' && $entityId !== '') {
        return demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $entityId]);
    }
    if ($entityType === 'content_brief' && $entityId !== '') {
        return demand_admin_scope_filter_url('demand_map', $scopeFilter, ['brief_id' => $entityId]) . '#demand-content-briefs';
    }
    if ($entityType === 'demand_cluster' && $entityId !== '') {
        return demand_admin_scope_filter_url('demand_map', $scopeFilter, ['cluster_id' => $entityId]);
    }
    if ($entityType === 'launch_plan_item' && $entityId !== '') {
        return demand_admin_scope_filter_url('demand_map', $scopeFilter, ['plan_id' => $entityId]);
    }

    return demand_admin_scope_filter_url($contextTab !== '' ? $contextTab : 'start', $scopeFilter);
}

function demand_admin_ai_api_fallback_task(string $entityType, string $task): string
{
    if ($entityType === 'content_brief') {
        return in_array($task, ['create_faq', 'create_page_outline'], true) ? $task : 'improve_content_brief';
    }
    if ($entityType === 'launch_plan_item' || $entityType === 'demand_cluster') {
        return $task === 'create_faq' ? 'create_page_outline' : 'compare_with_demand';
    }
    if ($entityType === 'car_hint') {
        return 'improve_car_hint';
    }

    return in_array($task, ['create_faq', 'create_title_description', 'check_false_promises', 'compare_with_demand'], true)
        ? $task
        : 'improve_landing_draft';
}

function demand_admin_car_hint_ai_api_task(string $task): string
{
    return in_array($task, ['generate_car_hint_text', 'generate_car_description_suggestion', 'improve_car_hint'], true)
        ? $task
        : 'generate_car_hint_text';
}

function demand_admin_car_hint_manual_task(string $task): string
{
    return $task === 'generate_car_description_suggestion' ? 'check_false_promises' : 'improve_car_hint';
}

function demand_admin_car_hint_ai_status_label(array $hint): string
{
    return match ((string) ($hint['aiProposalStatus'] ?? '')) {
        'prepared' => 'AI подготовил вариант',
        'pending_apply' => 'Ожидает применения',
        'rejected' => 'Отклонено',
        'applied_to_hint' => 'Применено к подсказке',
        'applied_with_manual_edit' => 'Применено с ручной правкой',
        default => '',
    };
}

function demand_admin_car_hint_ai_fields_for_task(string $task): array
{
    if ($task === 'generate_car_description_suggestion') {
        return ['descriptionSuggestion' => 'Текст описания'];
    }

    return [
        'message' => 'Сообщение подсказки',
        'suggestedText' => 'Текст подсказки',
    ];
}

function demand_admin_car_hint_ai_actions(array $hint, string $scopeFilter): void
{
    $hintId = (string) ($hint['id'] ?? '');
    if ($hintId === '' || (!has_permission('demand.ai_api.use') && !has_permission('demand.ai.package'))) {
        return;
    }
    ?>
    <div class="demand-car-hint-actions">
      <?php foreach ([
          'generate_car_hint_text' => 'Сформировать текст подсказки',
          'generate_car_description_suggestion' => 'Сформировать текст описания',
      ] as $task => $label): ?>
        <form method="post" class="demand-ai-inline-form">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="tab" value="car_hints">
          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
          <input type="hidden" name="action" value="demand_car_hint_ai_generate">
          <?= demand_ai_content_command_fields('demand_car_hint_ai_generate', 'car_hint', $hintId) ?>
          <input type="hidden" name="hint_id" value="<?= e($hintId) ?>">
          <input type="hidden" name="ai_api_task" value="<?= e((string) $task) ?>">
          <button class="btn small" type="submit"><?= e((string) $label) ?></button>
        </form>
      <?php endforeach; ?>
      <?php if (has_permission('demand.ai.package')): ?>
        <details class="demand-car-hint-manual">
          <summary>Ручной режим</summary>
          <p class="muted">Используйте, если AI API выключен или нужен пакет для внешнего AI вручную.</p>
          <?php foreach ([
              'improve_car_hint' => 'Сформировать пакет вручную',
              'check_false_promises' => 'Пакет для проверки описания',
          ] as $task => $label): ?>
            <form method="post" class="demand-ai-inline-form">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="car_hints">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="demand_ai_generate_package">
              <?= demand_ai_content_command_fields('demand_ai_generate_package', 'car_hint', $hintId) ?>
              <input type="hidden" name="entity_type" value="car_hint">
              <input type="hidden" name="entity_id" value="<?= e($hintId) ?>">
              <input type="hidden" name="ai_task" value="<?= e((string) $task) ?>">
              <button class="btn secondary small" type="submit"><?= e((string) $label) ?></button>
            </form>
          <?php endforeach; ?>
        </details>
      <?php endif; ?>
    </div>
    <?php
}

function demand_admin_car_hint_ai_fallback_panel($state, string $scopeFilter): void
{
    if (!is_array($state) || (string) ($state['entityType'] ?? '') !== 'car_hint') {
        return;
    }
    $hintId = (string) ($state['entityId'] ?? '');
    $task = demand_admin_car_hint_manual_task((string) ($state['task'] ?? ''));
    $contextTab = (string) ($state['contextTab'] ?? 'car_hints');
    $returnAnchor = $contextTab === 'start' ? 'simple-ai-workspace' : '';
    ?>
    <article class="panel demand-car-hint-ai-fallback" id="demand-car-hint-ai-fallback">
      <div class="panel-head">
        <div>
          <h2>AI API недоступен</h2>
          <p class="muted">Автоматический текст не был сгенерирован. Можно перейти в ручной режим и подготовить безопасный пакет для внешнего AI.</p>
        </div>
        <span class="status status-service">без API</span>
      </div>
      <div class="notice warning"><?= e((string) ($state['reason'] ?? 'AI API выключен или ключ не настроен.')) ?></div>
      <?php if (has_permission('demand.ai.package')): ?>
        <form method="post" class="inline-form">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="tab" value="<?= e($contextTab === 'start' ? 'start' : 'car_hints') ?>">
          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
          <input type="hidden" name="action" value="demand_ai_generate_package">
          <?= demand_ai_content_command_fields('demand_ai_generate_package', 'car_hint', $hintId) ?>
          <input type="hidden" name="entity_type" value="car_hint">
          <input type="hidden" name="entity_id" value="<?= e($hintId) ?>">
          <input type="hidden" name="ai_task" value="<?= e($task) ?>">
          <?php if ($returnAnchor !== ''): ?><input type="hidden" name="return_anchor" value="<?= e($returnAnchor) ?>"><?php endif; ?>
          <button class="btn secondary" type="submit">Сформировать пакет вручную</button>
        </form>
      <?php endif; ?>
    </article>
    <?php
}

function demand_admin_car_hint_ai_proposal_modal($state, string $scopeFilter): void
{
    if (!is_array($state)
        || (string) ($state['entityType'] ?? '') !== 'car_hint'
        || !is_array($state['proposal'] ?? null)
    ) {
        return;
    }
    $hintId = (string) ($state['entityId'] ?? '');
    $hint = $hintId !== '' ? demand_ai_find_car_hint($hintId) : null;
    if (!$hint) {
        return;
    }
    demand_scope_guard($hint, 'demand.card_hints.view');
    $task = demand_admin_car_hint_ai_api_task((string) ($state['task'] ?? 'generate_car_hint_text'));
    $proposal = (array) ($state['proposal'] ?? []);
    $fields = demand_admin_car_hint_ai_fields_for_task($task);
    $token = (string) ($state['token'] ?? '');
    $runId = (string) ($state['run']['id'] ?? '');
    $contextTab = (string) ($state['contextTab'] ?? 'car_hints');
    $returnAnchor = $contextTab === 'start' ? 'simple-ai-workspace' : '';
    $risks = array_values(array_filter(array_merge(
        array_map('strval', (array) ($proposal['risks'] ?? [])),
        array_map(static fn($risk): string => is_array($risk) ? (string) ($risk['message'] ?? '') : (string) $risk, (array) ($state['response']['risks'] ?? []))
    )));
    $notes = array_values(array_filter(array_map('strval', (array) ($proposal['notesForAdmin'] ?? $state['response']['adminNotes'] ?? []))));
    $mustCheck = array_values(array_filter(array_map('strval', (array) ($state['response']['mustCheckBeforeApply'] ?? []))));
    $notAllowed = array_values(array_filter(array_map('strval', (array) ($state['response']['notAllowed'] ?? []))));
    ?>
    <div class="demand-car-hint-ai-backdrop" id="demand-car-hint-ai-proposal" data-car-hint-ai-proposal>
      <section class="demand-car-hint-ai-modal" role="dialog" aria-modal="true" aria-labelledby="demand-car-hint-ai-title">
        <button class="demand-car-hint-ai-close" type="button" data-car-hint-ai-close aria-label="Закрыть">×</button>
        <div class="panel-head">
          <div>
            <h2 id="demand-car-hint-ai-title">AI подготовил текст. Можно поправить перед применением.</h2>
            <p class="muted">Изменения не будут сохранены, пока вы не нажмёте “Применить отредактированный вариант”.</p>
          </div>
          <span class="status status-service">вариант AI</span>
        </div>
        <div class="notice">
          Будет обновлена только подсказка для карточки авто. Сама карточка автомобиля, цены, залоги, характеристики, публикация и индексация не изменятся.
        </div>
        <form method="post" class="form-stack demand-car-hint-ai-form">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="tab" value="<?= e($contextTab === 'start' ? 'start' : 'car_hints') ?>">
          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
          <input type="hidden" name="action" value="demand_car_hint_ai_apply_edited">
          <?= demand_ai_content_command_fields('demand_car_hint_ai_apply_edited', 'car_hint', $hintId) ?>
          <input type="hidden" name="ai_api_token" value="<?= e($token) ?>">
          <input type="hidden" name="hint_id" value="<?= e($hintId) ?>">
          <?php if ($returnAnchor !== ''): ?><input type="hidden" name="return_anchor" value="<?= e($returnAnchor) ?>"><?php endif; ?>
          <div class="demand-car-hint-ai-grid">
            <?php foreach ($fields as $field => $label): ?>
              <?php
                $current = (string) ($hint[$field] ?? '');
                $aiValue = (string) ($proposal[$field] ?? '');
              ?>
              <section class="demand-car-hint-ai-field">
                <h3><?= e((string) $label) ?></h3>
                <label>Текущий сохранённый текст
                  <textarea rows="4" readonly><?= e($current) ?></textarea>
                </label>
                <label>Итоговый текст для сохранения
                  <textarea name="car_hint_proposal[<?= e((string) $field) ?>]" rows="6" data-car-hint-ai-edit data-ai-original="<?= e($aiValue) ?>"><?= e($aiValue) ?></textarea>
                </label>
                <details>
                  <summary>AI-вариант до ручных правок</summary>
                  <pre><?= e($aiValue) ?></pre>
                </details>
              </section>
            <?php endforeach; ?>
          </div>
          <span class="demand-car-hint-ai-dirty" data-car-hint-ai-dirty hidden>Есть ручные правки</span>
          <?php if ($risks || $mustCheck || $notes || $notAllowed): ?>
            <div class="demand-car-hint-ai-meta">
              <?php if ($risks): ?><div><h3>Риски</h3><ul><?php foreach ($risks as $item): ?><li><?= e($item) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
              <?php if ($mustCheck): ?><div><h3>Что проверить</h3><ul><?php foreach ($mustCheck as $item): ?><li><?= e($item) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
              <?php if ($notes): ?><div><h3>Заметки администратора</h3><ul><?php foreach ($notes as $item): ?><li><?= e($item) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
              <?php if ($notAllowed): ?><div><h3>AI не имел права менять</h3><ul><?php foreach ($notAllowed as $item): ?><li><?= e($item) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
            </div>
          <?php endif; ?>
          <div class="demand-ai-actions">
            <?php if (has_permission('demand.ai.apply') || has_permission('demand.ai_api.apply')): ?>
              <button class="btn" type="submit">Применить отредактированный вариант</button>
            <?php endif; ?>
            <button class="btn secondary" type="button" data-car-hint-ai-reset>Вернуть вариант AI</button>
            <button class="btn secondary" type="button" data-car-hint-ai-copy>Скопировать</button>
          </div>
        </form>
        <div class="demand-ai-actions demand-car-hint-ai-secondary">
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="<?= e($contextTab === 'start' ? 'start' : 'car_hints') ?>">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_car_hint_ai_generate">
            <?= demand_ai_content_command_fields('demand_car_hint_ai_generate', 'car_hint', $hintId) ?>
            <input type="hidden" name="hint_id" value="<?= e($hintId) ?>">
            <input type="hidden" name="ai_api_task" value="<?= e($task) ?>">
            <?php if ($returnAnchor !== ''): ?><input type="hidden" name="return_anchor" value="<?= e($returnAnchor) ?>"><?php endif; ?>
            <button class="btn secondary" type="submit">Сгенерировать ещё раз</button>
          </form>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="<?= e($contextTab === 'start' ? 'start' : 'car_hints') ?>">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_ai_api_reject">
            <?= demand_ai_content_command_fields('demand_ai_api_reject', 'car_hint', $hintId) ?>
            <input type="hidden" name="entity_type" value="car_hint">
            <input type="hidden" name="entity_id" value="<?= e($hintId) ?>">
            <input type="hidden" name="ai_api_token" value="<?= e($token) ?>">
            <?php if ($returnAnchor !== ''): ?><input type="hidden" name="return_anchor" value="<?= e($returnAnchor) ?>"><?php endif; ?>
            <button class="btn secondary" type="submit">Отклонить</button>
          </form>
          <?php if (has_permission('demand.ai.package')): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="<?= e($contextTab === 'start' ? 'start' : 'car_hints') ?>">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="demand_ai_generate_package">
              <?= demand_ai_content_command_fields('demand_ai_generate_package', 'car_hint', $hintId) ?>
              <input type="hidden" name="entity_type" value="car_hint">
              <input type="hidden" name="entity_id" value="<?= e($hintId) ?>">
              <input type="hidden" name="ai_task" value="<?= e(demand_admin_car_hint_manual_task($task)) ?>">
              <?php if ($returnAnchor !== ''): ?><input type="hidden" name="return_anchor" value="<?= e($returnAnchor) ?>"><?php endif; ?>
              <button class="btn secondary" type="submit">Ручной режим</button>
            </form>
          <?php endif; ?>
        </div>
      </section>
    </div>
    <?php
}

function demand_admin_ai_dialog_status_meta(?array $workflow, ?array $result): array
{
    if (is_array($result) && !empty($result['error'])) {
        return ['key' => 'error', 'label' => 'Есть ошибка'];
    }
    if (!$workflow) {
        return ['key' => 'ready', 'label' => 'AI готов'];
    }
    $status = (string) ($workflow['status'] ?? 'planned');
    if ($status === 'failed' || (string) ($workflow['sanitizedError'] ?? '') !== '') {
        return ['key' => 'error', 'label' => 'Есть ошибка'];
    }
    if ($status === 'running' || $status === 'in_progress') {
        return ['key' => 'running', 'label' => 'Выполняю задачу'];
    }
    if ($status === 'waiting_confirmation' || (function_exists('demand_ai_dialog_workflow_has_pending_confirmation') && demand_ai_dialog_workflow_has_pending_confirmation($workflow))) {
        return ['key' => 'waiting', 'label' => 'Нужно подтверждение'];
    }
    if ($status === 'cancelled') {
        return ['key' => 'done', 'label' => 'Остановлено'];
    }
    if ($status === 'completed') {
        return ['key' => 'done', 'label' => 'Готово'];
    }

    return ['key' => 'ready', 'label' => 'AI готов'];
}

function demand_admin_ai_dialog_progress_steps(?array $workflow): array
{
    $statuses = is_array($workflow['actionStatuses'] ?? null) ? (array) $workflow['actionStatuses'] : [];
    $has = static fn(string $action): bool => isset($statuses[$action]) && in_array((string) ($statuses[$action]['status'] ?? ''), ['done', 'shown'], true);
    $waiting = is_array($workflow) && function_exists('demand_ai_dialog_workflow_has_pending_confirmation') && demand_ai_dialog_workflow_has_pending_confirmation($workflow);
    $failed = is_array($workflow) && ((string) ($workflow['status'] ?? '') === 'failed' || (string) ($workflow['sanitizedError'] ?? '') !== '');
    $cancelled = is_array($workflow) && (string) ($workflow['status'] ?? '') === 'cancelled';

    $steps = [
        ['key' => 'plan', 'label' => 'Планирую', 'done' => is_array($workflow)],
        ['key' => 'seed', 'label' => 'Собираю фразы', 'done' => $has('generate_seed_phrases') || !empty($workflow['seedKeywords'])],
        ['key' => 'clean', 'label' => 'Очищаю мусор', 'done' => $has('mark_irrelevant_ai_keywords')],
        ['key' => 'score', 'label' => 'Считаю приоритеты', 'done' => $has('recalculate_recommendations') || $has('recalculate_demand_map')],
        ['key' => 'briefs', 'label' => 'Готовлю ТЗ', 'done' => !empty($workflow['createdBriefIds'])],
        ['key' => 'drafts', 'label' => 'Готовлю черновики', 'done' => !empty($workflow['createdDraftIds'])],
    ];
    $steps[] = [
        'key' => 'finish',
        'label' => $failed ? 'Есть ошибка' : ($cancelled ? 'Остановлено' : ($waiting ? 'Жду подтверждения' : 'Готово')),
        'done' => $failed || $cancelled || $waiting || (is_array($workflow) && (string) ($workflow['status'] ?? '') === 'completed'),
    ];

    $seenCurrent = false;
    foreach ($steps as $index => $step) {
        if (empty($step['done']) && !$seenCurrent) {
            $steps[$index]['current'] = true;
            $seenCurrent = true;
        } else {
            $steps[$index]['current'] = false;
        }
    }

    return $steps;
}

function demand_admin_plain_ai_text(string $text): string
{
    return strtr($text, [
        'Seed-фразы' => 'Стартовые фразы',
        'seed-фразы' => 'стартовые фразы',
        'AI-фразы' => 'AI-предложения',
        'workflow' => 'план',
        'Workflow' => 'План',
    ]);
}

function demand_admin_ai_dialog_render_action(array $action, string $workflowId, string $tab, string $scopeFilter, string $entityType, string $entityId): void
{
    $kind = (string) ($action['kind'] ?? 'read');
    $status = (string) ($action['status'] ?? 'pending');
    $riskLevel = (string) ($action['riskLevel'] ?? '');
    $actionLabel = demand_admin_plain_ai_text((string) ($action['label'] ?? $action['action'] ?? ''));
    $actionExplanation = demand_admin_plain_ai_text((string) ($action['explanation'] ?? $action['safeNote'] ?? ''));
    $actionSafeNote = demand_admin_plain_ai_text((string) ($action['safeNote'] ?? 'Без публикации страниц и без изменений в поиске.'));
    $actionResultMessage = demand_admin_plain_ai_text((string) ($action['resultMessage'] ?? ''));
    $button = $kind === 'read' || $riskLevel === 'auto_safe'
        ? 'Показать'
        : ($riskLevel === 'safe_write' ? 'Выполнить' : ($kind === 'special' ? 'Подтвердить отдельно' : 'Выполнить после подтверждения'));
    ?>
    <article class="demand-ai-dialog-action-card is-<?= e($kind) ?>">
      <div>
        <strong><?= e($actionLabel) ?></strong>
        <p><?= e($actionExplanation) ?></p>
        <small><?= e($actionSafeNote) ?></small>
        <?php if ($status !== 'pending'): ?><span class="status <?= e(demand_admin_status_class($status)) ?>"><?= e(demand_admin_ui_label($status)) ?></span><?php endif; ?>
        <?php if ($actionResultMessage !== ''): ?><p class="field-hint"><?= e($actionResultMessage) ?></p><?php endif; ?>
      </div>
      <?php if ($kind !== 'forbidden' && demand_ai_dialog_action_allowed($action)): ?>
        <form method="post" class="demand-ai-dialog-action-form">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="tab" value="<?= e($tab) ?>">
          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
          <input type="hidden" name="action" value="demand_ai_dialog_run_action">
          <?= demand_ai_content_command_fields('demand_ai_dialog_run_action', $entityType, $entityId) ?>
          <input type="hidden" name="workflow_id" value="<?= e($workflowId) ?>">
          <input type="hidden" name="workflow_action_id" value="<?= e((string) ($action['id'] ?? '')) ?>">
          <input type="hidden" name="context_tab" value="<?= e($tab) ?>">
          <input type="hidden" name="entity_type" value="<?= e($entityType) ?>">
          <input type="hidden" name="entity_id" value="<?= e($entityId) ?>">
          <?php if (!empty($action['requiresExplicitConfirmation'])): ?>
            <label class="check-row small"><input type="checkbox" name="explicit_confirm" value="1" required><span>Подтверждаю отдельный запуск</span></label>
          <?php endif; ?>
          <button class="btn secondary small" type="submit"><?= e($button) ?></button>
        </form>
      <?php endif; ?>
    </article>
    <?php
}

function demand_admin_ai_dialog_render_drawer(string $tab, string $scopeFilter, array $state, string $entityType = '', string $entityId = '', array $settings = []): void
{
    if (!function_exists('demand_ai_dialog_can_access') || !demand_ai_dialog_can_access()) {
        return;
    }
    $settings = $settings ?: (function_exists('openai_ai_settings') ? openai_ai_settings() : []);
    $workflow = is_array($state['workflow'] ?? null) ? $state['workflow'] : null;
    $messages = array_values((array) ($state['messages'] ?? []));
    $result = is_array($state['lastResult'] ?? null) ? $state['lastResult'] : null;
    $apiReady = !empty($settings['enabled']) && !empty($settings['apiKeyConfigured']);
    $screen = demand_ai_api_screen_context($tab, $scopeFilter);
    $statusMeta = demand_admin_ai_dialog_status_meta($workflow, $result);
    $contextLine = 'Вкладка: ' . $tab . '; scope: ' . ($scopeFilter !== '' ? $scopeFilter : 'all');
    if ($entityType !== '' && $entityId !== '') {
        $contextLine .= '; выбран контекст: ' . $entityType . ' ' . $entityId;
    }
    ?>
    <button class="demand-ai-dialog-rail is-<?= e((string) $statusMeta['key']) ?>" type="button" data-demand-ai-dialog-open aria-controls="demand-ai-dialog" aria-expanded="false">
      <span><?= e((string) $statusMeta['label']) ?></span>
    </button>
    <div class="demand-ai-dialog-backdrop" data-demand-ai-dialog-close></div>
    <aside class="demand-ai-dialog-drawer is-<?= e((string) $statusMeta['key']) ?>" id="demand-ai-dialog" data-demand-ai-dialog aria-hidden="true">
      <header class="demand-ai-dialog-head">
        <div>
          <p class="eyebrow">Маркетинг → Спрос</p>
          <h2>AI-помощник</h2>
          <span class="status <?= e(demand_admin_status_class((string) $statusMeta['key'])) ?>"><?= e((string) $statusMeta['label']) ?></span>
          <p class="muted">AI ничего не меняет без подтверждения. Сервер выполнит только зарегистрированные безопасные действия.</p>
        </div>
        <div class="demand-ai-dialog-head-actions">
          <?php if ($workflow && demand_ai_dialog_permission_allowed('demand.ai_dialog.use') && !in_array((string) ($workflow['status'] ?? ''), ['completed', 'cancelled', 'failed'], true)): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="<?= e($tab) ?>">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="demand_ai_dialog_stop">
              <?= demand_ai_content_command_fields('demand_ai_dialog_stop') ?>
              <button class="btn secondary small" type="submit">Остановить</button>
            </form>
          <?php endif; ?>
          <button class="btn secondary small" type="button" data-demand-ai-dialog-close>Свернуть</button>
        </div>
      </header>
      <details class="demand-ai-dialog-details">
        <summary>Что важно проверить</summary>
        <div class="notice warning demand-ai-warning">AI может ошибаться. Проверьте цены, залог, наличие авто, подачу и любые обещания перед применением.</div>
      </details>
      <?php if (!$apiReady): ?>
        <div class="notice info">Внешний AI выключен или ключ не настроен. Диалоговый помощник всё равно соберёт безопасный локальный план; для внешнего AI можно использовать ручной пакет в карточках сущностей.</div>
      <?php endif; ?>
      <details class="demand-ai-dialog-section demand-ai-dialog-details">
        <summary>Что AI видит сейчас</summary>
        <p class="muted"><?= e($contextLine) ?></p>
        <div class="demand-ai-dialog-context-grid">
          <span>Фразы <strong><?= e((string) count((array) ($screen['keywords'] ?? []))) ?></strong></span>
          <span>Кластеры <strong><?= e((string) count((array) ($screen['clusters'] ?? []))) ?></strong></span>
          <span>План <strong><?= e((string) count((array) ($screen['launchPlan'] ?? []))) ?></strong></span>
          <span>Черновики <strong><?= e((string) count((array) ($screen['drafts'] ?? []))) ?></strong></span>
        </div>
      </details>
      <?php if (has_permission('demand.ai_dialog.use') || has_permission('demand.ai_api.use')): ?>
        <section class="demand-ai-dialog-section">
          <h3>Задача</h3>
          <form method="post" class="form-stack demand-ai-dialog-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="<?= e($tab) ?>">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_ai_dialog_ask">
            <?= demand_ai_content_command_fields('demand_ai_dialog_ask', $entityType, $entityId) ?>
            <input type="hidden" name="context_tab" value="<?= e($tab) ?>">
            <input type="hidden" name="entity_type" value="<?= e($entityType) ?>">
            <input type="hidden" name="entity_id" value="<?= e($entityId) ?>">
            <textarea name="ai_dialog_message" rows="4" data-demand-ai-dialog-input placeholder="Например: Собери запросы по теме аренды авто по городам Крыма и расставь действия по приоритету."></textarea>
            <div class="demand-ai-dialog-quick">
              <?php foreach (array_slice(demand_ai_dialog_quick_prompts(), 0, 5) as $prompt): ?>
                <button class="btn secondary small" type="button" data-demand-ai-dialog-prompt="<?= e((string) ($prompt['message'] ?? '')) ?>"><?= e((string) ($prompt['label'] ?? '')) ?></button>
              <?php endforeach; ?>
            </div>
            <button class="btn" type="submit">Спросить AI</button>
          </form>
        </section>
      <?php endif; ?>
      <?php if ($messages): ?>
        <details class="demand-ai-dialog-section demand-ai-dialog-details">
          <summary>История</summary>
          <div class="demand-ai-dialog-section-head">
            <?php if (demand_ai_dialog_permission_allowed('demand.ai_dialog.use')): ?>
              <form method="post">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="tab" value="<?= e($tab) ?>">
                <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                <input type="hidden" name="action" value="demand_ai_dialog_clear">
                <?= demand_ai_content_command_fields('demand_ai_dialog_clear') ?>
                <button class="btn secondary small" type="submit">Очистить</button>
              </form>
            <?php endif; ?>
          </div>
          <div class="demand-ai-dialog-history">
            <?php foreach ($messages as $message): ?>
              <?php if (!is_array($message)) { continue; } ?>
              <p class="is-<?= e((string) ($message['role'] ?? 'assistant')) ?>"><strong><?= e((string) ($message['role'] ?? '') === 'user' ? 'Вы' : 'AI') ?>:</strong> <?= e((string) ($message['text'] ?? '')) ?></p>
            <?php endforeach; ?>
          </div>
        </details>
      <?php endif; ?>
      <?php if ($workflow): ?>
        <?php $workflowSummary = demand_admin_plain_ai_text((string) ($workflow['summary'] ?? '')); ?>
        <section class="demand-ai-dialog-section demand-ai-dialog-workflow">
          <h3>Что делает AI</h3>
          <p><strong><?= e(demand_ai_dialog_intent_label((string) ($workflow['dialogIntent'] ?? ''))) ?>.</strong> <?= e($workflowSummary) ?></p>
          <?php if (!empty($workflow['apiError'])): ?><p class="field-hint">Внешний AI не ответил: <?= e((string) $workflow['apiError']) ?>. Показан безопасный локальный план.</p><?php endif; ?>
          <div class="demand-ai-dialog-result-grid">
            <article>
              <strong>Кратко</strong>
              <p><?= e($workflowSummary !== '' ? $workflowSummary : 'AI подготовил безопасный план действий.') ?></p>
            </article>
            <article>
              <strong>Что уже готово</strong>
              <p>Фразы: <?= e((string) count((array) ($workflow['createdKeywordIds'] ?? []))) ?>. ТЗ: <?= e((string) count((array) ($workflow['createdBriefIds'] ?? []))) ?>. Черновики: <?= e((string) count((array) ($workflow['createdDraftIds'] ?? []))) ?>. Подсказки: <?= e((string) count((array) ($workflow['createdHintIds'] ?? []))) ?>.</p>
            </article>
            <article>
              <strong>Что требует подтверждения</strong>
              <p><?= e((string) (count((array) ($workflow['requiresConfirmation'] ?? [])) + count((array) ($workflow['specialConfirmation'] ?? [])))) ?> действий. Публикация и поиск не запускаются автоматически.</p>
            </article>
            <article>
              <strong>Риски</strong>
              <p><?= e((string) count((array) ($workflow['risks'] ?? []))) ?> пунктов. sitemap.xml и robots.txt не менялись.</p>
            </article>
          </div>
          <ol class="demand-ai-dialog-progress" aria-label="Прогресс AI">
            <?php foreach (demand_admin_ai_dialog_progress_steps($workflow) as $step): ?>
              <li class="<?= !empty($step['done']) ? 'is-done' : (!empty($step['current']) ? 'is-current' : '') ?>"><?= e((string) ($step['label'] ?? '')) ?></li>
            <?php endforeach; ?>
          </ol>
          <?php $priorities = (array) ($workflow['expectedResult']['priorityActions'] ?? []); ?>
          <?php if ($priorities): ?>
            <section class="demand-ai-dialog-compact-block">
              <h3>Что сделать сейчас</h3>
              <ol class="demand-ai-dialog-priority-list">
                <?php foreach (array_slice($priorities, 0, 5) as $item): ?>
                  <?php if (!is_array($item)) { continue; } ?>
                  <li>
                    <strong><?= e((string) ($item['title'] ?? '')) ?></strong>
                    <span class="status <?= e(demand_admin_status_class((string) ($item['priority'] ?? 'medium'))) ?>"><?= e(demand_admin_priority_label((string) ($item['priority'] ?? 'medium'))) ?></span>
                    <p><?= e((string) ($item['action'] ?? '')) ?></p>
                  </li>
                <?php endforeach; ?>
              </ol>
            </section>
          <?php endif; ?>
          <?php
            $visibleAiActions = array_values(array_filter(array_merge(
                (array) ($workflow['safeToRunNow'] ?? []),
                (array) ($workflow['requiresConfirmation'] ?? []),
                (array) ($workflow['specialConfirmation'] ?? [])
            ), 'is_array'));
          ?>
          <?php if ($visibleAiActions): ?>
            <section class="demand-ai-dialog-compact-block">
              <h3>Кнопки действий</h3>
              <div class="demand-ai-dialog-action-list">
                <?php foreach (array_slice($visibleAiActions, 0, 5) as $action): ?>
                  <?php demand_admin_ai_dialog_render_action($action, (string) ($workflow['id'] ?? ''), $tab, $scopeFilter, $entityType, $entityId); ?>
                <?php endforeach; ?>
              </div>
            </section>
          <?php endif; ?>
          <details class="demand-ai-dialog-details">
            <summary>Что я понял</summary>
            <ul><?php foreach (array_slice((array) ($workflow['whatIUnderstood'] ?? []), 0, 6) as $item): ?><li><?= e((string) $item) ?></li><?php endforeach; ?></ul>
          </details>
          <details class="demand-ai-dialog-details">
            <summary>Подробный план</summary>
            <div class="demand-ai-dialog-action-list">
              <?php foreach ((array) ($workflow['safeToRunNow'] ?? []) as $action): ?>
                <?php if (is_array($action)) { demand_admin_ai_dialog_render_action($action, (string) ($workflow['id'] ?? ''), $tab, $scopeFilter, $entityType, $entityId); } ?>
              <?php endforeach; ?>
            </div>
          </details>
          <details class="demand-ai-dialog-details">
            <summary>Что требует подтверждения</summary>
            <div class="demand-ai-dialog-action-list">
              <?php foreach ((array) ($workflow['requiresConfirmation'] ?? []) as $action): ?>
                <?php if (is_array($action)) { demand_admin_ai_dialog_render_action($action, (string) ($workflow['id'] ?? ''), $tab, $scopeFilter, $entityType, $entityId); } ?>
              <?php endforeach; ?>
              <?php if (empty($workflow['requiresConfirmation'])): ?><p class="muted">Для этого запроса нет действий с записью данных.</p><?php endif; ?>
            </div>
          </details>
          <?php if (!empty($workflow['specialConfirmation'])): ?>
            <details>
              <summary>Wordstat: отдельное подтверждение</summary>
              <div class="demand-ai-dialog-action-list">
                <?php foreach ((array) ($workflow['specialConfirmation'] ?? []) as $action): ?>
                  <?php if (is_array($action)) { demand_admin_ai_dialog_render_action($action, (string) ($workflow['id'] ?? ''), $tab, $scopeFilter, $entityType, $entityId); } ?>
                <?php endforeach; ?>
              </div>
            </details>
          <?php endif; ?>
          <?php if (!empty($workflow['risks'])): ?>
            <details class="demand-ai-dialog-details">
              <summary>Риски</summary>
              <ul class="demand-ai-risk-list">
                <?php foreach (array_slice((array) ($workflow['risks'] ?? []), 0, 8) as $risk): ?>
                  <?php if (!is_array($risk)) { continue; } ?>
                  <li class="is-<?= e((string) ($risk['level'] ?? 'medium')) ?>"><?= e((string) ($risk['message'] ?? '')) ?></li>
                <?php endforeach; ?>
              </ul>
            </details>
          <?php endif; ?>
          <details class="demand-ai-dialog-details">
            <summary>Технические детали</summary>
            <p class="field-hint">Диалоговый AI не может публиковать страницы, открывать индексацию, менять sitemap/robots, цены, залоги, автомобили, заявки, аренды, клиентов, штрафы, финансы, документы, пользователей, роли и права.</p>
          </details>
        </section>
      <?php endif; ?>
      <?php if ($result): ?>
        <section class="demand-ai-dialog-section">
          <h3>Результат выполнения</h3>
          <p><?= e((string) ($result['message'] ?? '')) ?></p>
        </section>
      <?php endif; ?>
    </aside>
    <?php
}

function demand_admin_ai_api_render_panel(string $contextTab, string $scopeFilter, array $tasks, string $entityType = '', string $entityId = '', $latestState = null, array $settings = []): void
{
    if (!has_permission('demand.ai_api.view') && !has_permission('demand.ai_api.use')) {
        return;
    }
    $settings = $settings ?: (function_exists('openai_ai_settings') ? openai_ai_settings() : []);
    $matches = demand_admin_ai_api_context_matches($latestState, $contextTab, $entityType, $entityId);
    $response = $matches && is_array($latestState['response'] ?? null) ? $latestState['response'] : null;
    $diff = $matches && is_array($latestState['diff'] ?? null) ? $latestState['diff'] : null;
    $proposal = $matches && is_array($latestState['proposal'] ?? null) ? $latestState['proposal'] : [];
    $panelId = $matches ? 'demand-ai-api-helper' : 'demand-ai-api-helper-' . preg_replace('/[^A-Za-z0-9_-]+/', '-', $contextTab . '-' . $entityType . '-' . $entityId);
    $apiReady = !empty($settings['enabled']) && !empty($settings['apiKeyConfigured']);
    ?>
    <article class="demand-ai-api-panel" id="<?= e($panelId) ?>">
      <div class="panel-head">
        <div>
          <h2>AI-помощник</h2>
          <p class="muted">AI объяснит текущий экран и предложит следующий безопасный шаг. Он не публикует страницы и ничего не меняет без подтверждения.</p>
        </div>
        <span class="status <?= $apiReady ? 'status-free' : 'status-service' ?>"><?= $apiReady ? 'API включён' : 'Ручной режим' ?></span>
      </div>
      <div class="notice warning demand-ai-warning">AI может ошибаться. Проверьте цены, залог, наличие авто, подачу и любые обещания перед применением.</div>
      <div class="demand-ai-api-actions">
        <?php if ($apiReady && has_permission('demand.ai_api.use')): ?>
          <?php foreach ($tasks as $task => $label): ?>
            <form method="post" class="demand-ai-inline-form">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="<?= e($contextTab) ?>">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="demand_ai_api_ask">
              <?= demand_ai_content_command_fields('demand_ai_api_ask', $entityType, $entityId) ?>
              <input type="hidden" name="context_tab" value="<?= e($contextTab) ?>">
              <input type="hidden" name="entity_type" value="<?= e($entityType) ?>">
              <input type="hidden" name="entity_id" value="<?= e($entityId) ?>">
              <input type="hidden" name="ai_api_task" value="<?= e((string) $task) ?>">
              <button class="btn secondary small" type="submit"><?= e((string) $label) ?></button>
            </form>
          <?php endforeach; ?>
        <?php else: ?>
          <p class="muted">AI API отключён или ключ не настроен. Можно продолжить через безопасный пакет для ручной вставки в ChatGPT или другой AI-сервис.</p>
          <?php if ($entityType !== '' && $entityId !== '' && has_permission('demand.ai.package')): ?>
            <?php $firstTask = (string) array_key_first($tasks); ?>
            <form method="post" class="demand-ai-inline-form">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="<?= e($contextTab) ?>">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="demand_ai_generate_package">
              <?= demand_ai_content_command_fields('demand_ai_generate_package', $entityType, $entityId) ?>
              <input type="hidden" name="entity_type" value="<?= e($entityType) ?>">
              <input type="hidden" name="entity_id" value="<?= e($entityId) ?>">
              <input type="hidden" name="ai_task" value="<?= e(demand_admin_ai_api_fallback_task($entityType, $firstTask)) ?>">
              <button class="btn secondary small" type="submit">Сформировать пакет для AI вручную</button>
            </form>
          <?php endif; ?>
        <?php endif; ?>
      </div>
      <?php if ($response): ?>
        <section class="demand-ai-api-result">
          <h3>Кратко</h3>
          <p><?= e((string) ($response['summary'] ?? '')) ?></p>
          <div class="demand-ai-api-result-grid">
            <div>
              <h4>Что важно</h4>
              <ul><?php foreach (array_slice((array) ($response['importantFindings'] ?? []), 0, 6) as $item): ?><li><?= e((string) $item) ?></li><?php endforeach; ?></ul>
            </div>
            <div>
              <h4>Риски</h4>
              <ul class="demand-ai-risk-list">
                <?php foreach (array_slice((array) ($response['risks'] ?? []), 0, 6) as $risk): ?>
                  <li class="is-<?= e((string) ($risk['level'] ?? 'medium')) ?>"><?= e((string) ($risk['message'] ?? '')) ?></li>
                <?php endforeach; ?>
                <?php if (empty($response['risks'])): ?><li>Отдельных рисков AI не выделил. Всё равно проверьте факты вручную.</li><?php endif; ?>
              </ul>
            </div>
            <div>
              <h4>Следующий шаг</h4>
              <strong><?= e((string) ($response['nextStep']['label'] ?? '')) ?></strong>
              <p><?= e((string) ($response['nextStep']['reason'] ?? '')) ?></p>
            </div>
            <div>
              <h4>Что проверить</h4>
              <ul><?php foreach (array_slice((array) ($response['mustCheckBeforeApply'] ?? []), 0, 6) as $item): ?><li><?= e((string) $item) ?></li><?php endforeach; ?></ul>
            </div>
          </div>
          <?php if (!empty($response['suggestedActions'])): ?>
            <h4>Предложения</h4>
            <ul class="demand-ai-action-list">
              <?php foreach (array_slice((array) ($response['suggestedActions'] ?? []), 0, 6) as $action): ?>
                <li><strong><?= e((string) ($action['label'] ?? '')) ?></strong><span><?= e((string) ($action['explanation'] ?? '')) ?></span></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </section>
      <?php endif; ?>
      <?php if ($diff): ?>
        <section class="demand-ai-preview">
          <h3>Preview / diff</h3>
          <div class="table-wrap">
            <table class="report-table demand-ai-diff-table">
              <thead><tr><th>Поле</th><th>Было</th><th>Станет</th></tr></thead>
              <tbody>
                <?php foreach ((array) ($diff['rows'] ?? []) as $row): ?>
                  <tr class="<?= !empty($row['changed']) ? 'is-changed' : '' ?>">
                    <th><?= e((string) ($row['label'] ?? $row['field'] ?? '')) ?></th>
                    <td><pre><?= e((string) ($row['before'] ?? '')) ?></pre></td>
                    <td><pre><?= e((string) ($row['after'] ?? '')) ?></pre></td>
                  </tr>
                <?php endforeach; ?>
                <?php if (empty($diff['rows'])): ?><tr><td colspan="3">Нет изменений для разрешённых полей.</td></tr><?php endif; ?>
              </tbody>
            </table>
          </div>
          <div class="demand-ai-actions">
            <?php if (!empty($diff['applySupported']) && $proposal && has_permission('demand.ai_api.apply')): ?>
              <form method="post">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="tab" value="<?= e($contextTab) ?>">
                <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                <input type="hidden" name="action" value="demand_ai_api_apply_proposal">
                <?= demand_ai_content_command_fields('demand_ai_api_apply_proposal', $entityType, $entityId) ?>
                <input type="hidden" name="entity_type" value="<?= e($entityType) ?>">
                <input type="hidden" name="entity_id" value="<?= e($entityId) ?>">
                <input type="hidden" name="ai_api_token" value="<?= e((string) ($latestState['token'] ?? '')) ?>">
                <button class="btn" type="submit">Применить предложение</button>
              </form>
              <small>Изменения сохранятся только в разрешённых полях. Страница не будет опубликована и не будет открыта для поиска.</small>
            <?php endif; ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="<?= e($contextTab) ?>">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="demand_ai_api_reject">
              <?= demand_ai_content_command_fields('demand_ai_api_reject', $entityType, $entityId) ?>
              <input type="hidden" name="entity_type" value="<?= e($entityType) ?>">
              <input type="hidden" name="entity_id" value="<?= e($entityId) ?>">
              <input type="hidden" name="ai_api_token" value="<?= e((string) ($latestState['token'] ?? '')) ?>">
              <button class="btn secondary" type="submit">Отклонить</button>
            </form>
          </div>
        </section>
      <?php endif; ?>
    </article>
    <?php
}

function demand_admin_ai_copy_context_matches($latestState, string $draftId): bool
{
    return is_array($latestState)
        && (string) ($latestState['entityType'] ?? '') === 'draft'
        && (string) ($latestState['entityId'] ?? '') === $draftId;
}

function demand_admin_ai_copy_quality_label(string $field, string $value): string
{
    $labels = [
        'clarity' => [
            'good' => 'Понятность: хорошо',
            'needs_simpler' => 'Понятность: нужно проще',
        ],
        'humanTone' => [
            'good' => 'Живость: хорошо',
            'too_dry' => 'Живость: суховато',
            'too_salesy' => 'Живость: слишком рекламно',
        ],
        'seoOveruse' => [
            'none' => 'SEO-переспам: нет',
            'possible' => 'SEO-переспам: есть повторы',
            'high' => 'SEO-переспам: много повторов',
        ],
        'promiseRisk' => [
            'none' => 'Риски обещаний: нет',
            'needs_check' => 'Риски обещаний: проверить',
            'high' => 'Риски обещаний: высокий риск',
        ],
        'specificity' => [
            'good' => 'Достаточно конкретики: да',
            'needs_more_facts' => 'Достаточно конкретики: мало фактов',
        ],
    ];

    return $labels[$field][$value] ?? ($field . ': ' . $value);
}

function demand_admin_ai_copy_settings_from_payload(array $payload): array
{
    return [
        'style' => (string) ($payload['copy_style'] ?? 'calm_human'),
        'baseInstruction' => (string) ($payload['copy_base_instruction'] ?? ''),
        'avoid' => is_array($payload['copy_avoid'] ?? null) ? array_values((array) $payload['copy_avoid']) : [],
        'emphasis' => is_array($payload['copy_emphasis'] ?? null) ? array_values((array) $payload['copy_emphasis']) : [],
    ];
}

function demand_admin_ai_copy_options_from_payload(array $payload): array
{
    $options = demand_admin_ai_copy_settings_from_payload($payload);
    $options['preserveSeoMeaning'] = !empty($payload['preserve_seo_meaning']);
    $options['reduceKeywordRepeats'] = !empty($payload['reduce_keyword_repeats']);
    $options['preserveFacts'] = !empty($payload['preserve_facts']);
    $options['noUnconfirmedPromises'] = !empty($payload['no_unconfirmed_promises']);
    $options['targetBlockIndex'] = array_key_exists('block_index', $payload) ? $payload['block_index'] : null;
    $options['oneTimeInstruction'] = (string) ($payload['copy_one_time_instruction'] ?? '');

    return function_exists('demand_ai_normalize_copy_options') ? demand_ai_normalize_copy_options($options) : $options;
}

function demand_admin_ai_copy_selected_labels(array $selected, array $options): array
{
    $labels = [];
    foreach ($selected as $key) {
        $key = (string) $key;
        if (isset($options[$key])) {
            $labels[] = (string) $options[$key];
        }
    }

    return $labels;
}

function demand_admin_ai_copy_hidden_inputs(string $draftId, string $scopeFilter, string $task, array $options = [], ?int $blockIndex = null): void
{
    $options = function_exists('demand_ai_normalize_copy_options') ? demand_ai_normalize_copy_options($options) : $options;
    ?>
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="tab" value="drafts">
    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
    <input type="hidden" name="action" value="demand_ai_copy_regenerate">
    <?= demand_ai_content_command_fields('demand_ai_copy_regenerate', 'draft', $draftId) ?>
    <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
    <input type="hidden" name="ai_copy_task" value="<?= e($task) ?>">
    <input type="hidden" name="copy_style" value="<?= e((string) ($options['style'] ?? 'calm_human')) ?>">
    <input type="hidden" name="copy_base_instruction" value="<?= e((string) ($options['baseInstruction'] ?? '')) ?>">
    <?php foreach ((array) ($options['avoid'] ?? []) as $avoidKey): ?>
      <input type="hidden" name="copy_avoid[]" value="<?= e((string) $avoidKey) ?>">
    <?php endforeach; ?>
    <?php foreach ((array) ($options['emphasis'] ?? []) as $emphasisKey): ?>
      <input type="hidden" name="copy_emphasis[]" value="<?= e((string) $emphasisKey) ?>">
    <?php endforeach; ?>
    <?php if ((string) ($options['oneTimeInstruction'] ?? '') !== ''): ?>
      <input type="hidden" name="copy_one_time_instruction" value="<?= e((string) $options['oneTimeInstruction']) ?>">
    <?php endif; ?>
    <input type="hidden" name="preserve_seo_meaning" value="<?= !empty($options['preserveSeoMeaning']) ? '1' : '0' ?>">
    <input type="hidden" name="reduce_keyword_repeats" value="<?= !empty($options['reduceKeywordRepeats']) ? '1' : '0' ?>">
    <input type="hidden" name="preserve_facts" value="<?= !empty($options['preserveFacts']) ? '1' : '0' ?>">
    <input type="hidden" name="no_unconfirmed_promises" value="<?= !empty($options['noUnconfirmedPromises']) ? '1' : '0' ?>">
    <?php if ($blockIndex !== null): ?><input type="hidden" name="block_index" value="<?= e((string) $blockIndex) ?>"><?php endif; ?>
    <?php
}

function demand_admin_ai_copy_render_panel(array $draft, string $scopeFilter, $latestState = null): void
{
    if (!has_permission('demand.ai_api.use') && !has_permission('demand.ai.package')) {
        return;
    }
    $draftId = (string) ($draft['id'] ?? '');
    if ($draftId === '') {
        return;
    }
    $styles = function_exists('demand_ai_copy_style_options') ? demand_ai_copy_style_options() : ['calm_human' => 'Живой и спокойный'];
    $copySettings = function_exists('demand_ai_draft_copy_settings') ? demand_ai_draft_copy_settings($draft) : [
        'defaultStyle' => 'calm_human',
        'defaultBaseInstruction' => function_exists('demand_ai_copy_default_base_instruction') ? demand_ai_copy_default_base_instruction() : '',
        'avoidList' => [],
        'defaultEmphasisList' => [],
    ];
    $defaultOptions = function_exists('demand_ai_normalize_copy_options') ? demand_ai_normalize_copy_options([
        'style' => (string) ($copySettings['defaultStyle'] ?? 'calm_human'),
        'baseInstruction' => (string) ($copySettings['defaultBaseInstruction'] ?? ''),
        'avoid' => (array) ($copySettings['avoidList'] ?? []),
        'emphasis' => (array) ($copySettings['defaultEmphasisList'] ?? []),
        'preserveSeoMeaning' => true,
        'reduceKeywordRepeats' => true,
        'preserveFacts' => true,
        'noUnconfirmedPromises' => true,
    ]) : [
        'style' => 'calm_human',
        'baseInstruction' => '',
        'avoid' => [],
        'emphasis' => [],
        'preserveSeoMeaning' => true,
        'reduceKeywordRepeats' => true,
        'preserveFacts' => true,
        'noUnconfirmedPromises' => true,
    ];
    $blockOptions = $defaultOptions;
    $avoidOptions = function_exists('demand_ai_copy_avoid_options') ? demand_ai_copy_avoid_options() : [];
    $emphasisOptions = function_exists('demand_ai_copy_emphasis_options') ? demand_ai_copy_emphasis_options() : [];
    $selectedAvoid = (array) ($defaultOptions['avoid'] ?? []);
    $selectedEmphasis = (array) ($defaultOptions['emphasis'] ?? []);
    $matches = demand_admin_ai_copy_context_matches($latestState, $draftId);
    $response = $matches && is_array($latestState['response'] ?? null) ? $latestState['response'] : null;
    $diff = $matches && is_array($latestState['diff'] ?? null) ? $latestState['diff'] : null;
    $proposal = $matches && is_array($latestState['proposal'] ?? null) ? $latestState['proposal'] : [];
    $requestOptions = $matches && is_array($latestState['request']['options'] ?? null)
        ? (function_exists('demand_ai_normalize_copy_options') ? demand_ai_normalize_copy_options((array) $latestState['request']['options']) : (array) $latestState['request']['options'])
        : [];
    $requestAvoidLabels = demand_admin_ai_copy_selected_labels((array) ($requestOptions['avoid'] ?? []), $avoidOptions);
    $requestEmphasisLabels = demand_admin_ai_copy_selected_labels((array) ($requestOptions['emphasis'] ?? []), $emphasisOptions);
    $quality = function_exists('demand_ai_normalize_copy_quality')
        ? demand_ai_normalize_copy_quality((array) ($response['copyQuality'] ?? []))
        : (array) ($response['copyQuality'] ?? []);
    $proposalJson = $proposal ? json_encode($proposal, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) : '';
    $proposalId = 'demand-ai-copy-proposal-' . preg_replace('/[^A-Za-z0-9_-]+/', '-', $draftId);
    ?>
    <article class="panel demand-copy-regeneration" id="demand-ai-copy-regeneration">
      <div class="panel-head">
        <div>
          <h2>Перегенерация текста</h2>
          <p class="muted">AI подготовит более живой вариант, но ничего не заменит без preview/diff и ручного применения.</p>
        </div>
        <span class="status status-service">preview only</span>
      </div>
      <form method="post" class="demand-copy-settings">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="tab" value="drafts">
        <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
        <input type="hidden" name="action" value="demand_ai_copy_regenerate">
        <?= demand_ai_content_command_fields('demand_ai_copy_regenerate', 'draft', $draftId) ?>
        <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
        <section class="demand-copy-settings-panel" aria-label="Настройки генерации текста">
          <div class="panel-head">
            <div>
              <h3>Настройки генерации текста</h3>
              <p class="muted">AI подготовит вариант текста. Ничего не заменится без вашего подтверждения.</p>
            </div>
          </div>
          <div class="demand-copy-controls">
            <label>Стиль текста
              <select name="copy_style">
                <?php foreach ($styles as $styleKey => $styleLabel): ?>
                  <option value="<?= e((string) $styleKey) ?>" <?= (string) $styleKey === (string) ($defaultOptions['style'] ?? 'calm_human') ? 'selected' : '' ?>><?= e((string) $styleLabel) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
            <label>Блок
              <select name="block_index">
                <?php foreach ((array) ($draft['contentBlocks'] ?? []) as $blockIndex => $block): ?>
                  <?php if (!is_array($block)) { continue; } ?>
                  <option value="<?= e((string) $blockIndex) ?>"><?= e(((int) $blockIndex + 1) . '. ' . (string) ($block['title'] ?? 'Блок')) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
          </div>
          <label>Базовая инструкция для AI
            <textarea class="demand-copy-textarea" name="copy_base_instruction" rows="5"><?= e((string) ($defaultOptions['baseInstruction'] ?? '')) ?></textarea>
          </label>
          <div class="demand-copy-checkbox-grid">
            <fieldset>
              <legend>Чего избегать</legend>
              <?php foreach ($avoidOptions as $avoidKey => $avoidLabel): ?>
                <label class="check-row">
                  <input type="checkbox" name="copy_avoid[]" value="<?= e((string) $avoidKey) ?>" <?= in_array((string) $avoidKey, $selectedAvoid, true) ? 'checked' : '' ?>>
                  <span><?= e((string) $avoidLabel) ?></span>
                </label>
              <?php endforeach; ?>
            </fieldset>
            <fieldset>
              <legend>На чём сделать акцент</legend>
              <?php foreach ($emphasisOptions as $emphasisKey => $emphasisLabel): ?>
                <label class="check-row">
                  <input type="checkbox" name="copy_emphasis[]" value="<?= e((string) $emphasisKey) ?>" <?= in_array((string) $emphasisKey, $selectedEmphasis, true) ? 'checked' : '' ?>>
                  <span><?= e((string) $emphasisLabel) ?></span>
                </label>
              <?php endforeach; ?>
            </fieldset>
          </div>
          <label>Разовая инструкция
            <textarea class="demand-copy-textarea" name="copy_one_time_instruction" rows="3" placeholder="Например: сделай текст короче, теплее и без повторов слова ‘аренда’."></textarea>
          </label>
          <div class="demand-copy-toggles">
            <label class="check-row"><input type="checkbox" name="preserve_seo_meaning" value="1" <?= !empty($defaultOptions['preserveSeoMeaning']) ? 'checked' : '' ?>><span>Сохранить SEO-смысл</span></label>
            <label class="check-row"><input type="checkbox" name="reduce_keyword_repeats" value="1" <?= !empty($defaultOptions['reduceKeywordRepeats']) ? 'checked' : '' ?>><span>Сделать меньше ключевых повторов</span></label>
            <label class="check-row"><input type="checkbox" name="preserve_facts" value="1" <?= !empty($defaultOptions['preserveFacts']) ? 'checked' : '' ?>><span>Не менять факты</span></label>
            <label class="check-row"><input type="checkbox" name="no_unconfirmed_promises" value="1" <?= !empty($defaultOptions['noUnconfirmedPromises']) ? 'checked' : '' ?>><span>Не добавлять неподтверждённые обещания</span></label>
          </div>
          <div class="demand-copy-settings-actions">
            <button class="btn secondary" type="submit" name="ai_copy_settings_save" value="draft">Сохранить для этого черновика</button>
            <?php if (has_permission('demand.ai_api.settings.manage')): ?>
              <button class="btn secondary" type="submit" name="ai_copy_settings_save" value="global">Сохранить как базовую инструкцию</button>
            <?php endif; ?>
          </div>
        </section>
        <div class="demand-copy-actions">
          <button class="btn" type="submit" name="ai_copy_task" value="regenerate_landing_draft_human">Оживить весь текст</button>
          <button class="btn secondary" type="submit" name="ai_copy_task" value="regenerate_landing_intro">Перегенерировать intro</button>
          <button class="btn secondary" type="submit" name="ai_copy_task" value="regenerate_content_blocks">Перегенерировать все блоки</button>
          <button class="btn secondary" type="submit" name="ai_copy_task" value="regenerate_faq">Перегенерировать FAQ</button>
          <button class="btn secondary" type="submit" name="ai_copy_task" value="regenerate_single_content_block">Перегенерировать выбранный блок</button>
          <button class="btn secondary" type="submit" name="ai_copy_task" value="make_copy_more_human">Сделать проще</button>
          <button class="btn secondary" type="submit" name="ai_copy_task" value="reduce_seo_overoptimization">Убрать SEO-переспам</button>
          <button class="btn secondary" type="submit" name="ai_copy_task" value="rewrite_block_human">Проверить и оживить текст</button>
          <?php if ($response): ?>
            <button class="btn secondary" type="submit" name="copy_regenerate_again" value="1">Сгенерировать ещё раз</button>
          <?php endif; ?>
        </div>
      </form>
      <?php if ($response): ?>
        <section class="demand-copy-preview">
          <div class="panel-head">
            <div>
              <h3>AI подготовил новый вариант</h3>
              <p class="muted"><?= e((string) ($response['summary'] ?? '')) ?></p>
            </div>
            <span class="status status-free"><?= e((string) ($response['styleUsed'] ?? 'Живой и спокойный')) ?></span>
          </div>
          <div class="demand-copy-quality" aria-label="Оценка текста">
            <strong>Оценка текста</strong>
            <?php foreach (['clarity', 'humanTone', 'seoOveruse', 'promiseRisk', 'specificity'] as $field): ?>
              <span><?= e(demand_admin_ai_copy_quality_label($field, (string) ($quality[$field] ?? ''))) ?></span>
            <?php endforeach; ?>
          </div>
          <?php if ($requestOptions): ?>
            <div class="demand-copy-instruction-summary">
              <strong>Какие инструкции учтены</strong>
              <ul>
                <li>Стиль: <?= e(demand_ai_copy_style_label((string) ($requestOptions['style'] ?? 'calm_human'))) ?></li>
                <?php if ($requestAvoidLabels): ?><li>Избегать: <?= e(implode(', ', $requestAvoidLabels)) ?></li><?php endif; ?>
                <?php if ($requestEmphasisLabels): ?><li>Акценты: <?= e(implode(', ', $requestEmphasisLabels)) ?></li><?php endif; ?>
                <?php if ((string) ($requestOptions['oneTimeInstruction'] ?? '') !== ''): ?><li>Разовая инструкция учтена только для этой генерации.</li><?php endif; ?>
                <?php if (!empty($requestOptions['regenerateAgain'])): ?><li>Запрошен другой вариант без повторения прошлой структуры.</li><?php endif; ?>
              </ul>
              <?php if ((string) ($requestOptions['baseInstruction'] ?? '') !== ''): ?>
                <details>
                  <summary>Базовая инструкция</summary>
                  <p><?= e((string) $requestOptions['baseInstruction']) ?></p>
                </details>
              <?php endif; ?>
            </div>
          <?php endif; ?>
          <?php if (!empty($response['mustCheckBeforeApply'])): ?>
            <div class="notice warning demand-copy-checks">
              <strong>Что нужно проверить</strong>
              <ul><?php foreach (array_slice((array) ($response['mustCheckBeforeApply'] ?? []), 0, 8) as $item): ?><li><?= e((string) $item) ?></li><?php endforeach; ?></ul>
            </div>
          <?php endif; ?>
          <?php if (!empty($response['notAllowed'])): ?>
            <div class="notice info demand-copy-checks">
              <strong>Что AI не использовал</strong>
              <ul><?php foreach (array_slice((array) ($response['notAllowed'] ?? []), 0, 8) as $item): ?><li><?= e((string) $item) ?></li><?php endforeach; ?></ul>
            </div>
          <?php endif; ?>
          <?php if ($diff): ?>
            <div class="table-wrap">
              <table class="report-table demand-ai-diff-table">
                <thead><tr><th>Поле</th><th>Было</th><th>Станет</th></tr></thead>
                <tbody>
                  <?php foreach ((array) ($diff['rows'] ?? []) as $row): ?>
                    <tr class="<?= !empty($row['changed']) ? 'is-changed' : '' ?>">
                      <th><?= e((string) ($row['label'] ?? $row['field'] ?? '')) ?></th>
                      <td><pre><?= e((string) ($row['before'] ?? '')) ?></pre></td>
                      <td><pre><?= e((string) ($row['after'] ?? '')) ?></pre></td>
                    </tr>
                  <?php endforeach; ?>
                  <?php if (empty($diff['rows'])): ?><tr><td colspan="3">Нет изменений для разрешённых текстовых полей.</td></tr><?php endif; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
          <textarea id="<?= e($proposalId) ?>" class="demand-ai-json" rows="8" readonly><?= e((string) $proposalJson) ?></textarea>
          <div class="demand-copy-preview-actions">
            <?php if (has_permission('demand.ai.apply')): ?>
              <?php foreach (['all' => 'Применить', 'intro' => 'Применить только intro', 'blocks' => 'Применить выбранные блоки', 'faq' => 'Применить FAQ'] as $mode => $label): ?>
                <form method="post">
                  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="tab" value="drafts">
                  <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                  <input type="hidden" name="action" value="demand_ai_copy_apply">
                  <?= demand_ai_content_command_fields('demand_ai_copy_apply', 'draft', $draftId) ?>
                  <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
                  <input type="hidden" name="ai_copy_token" value="<?= e((string) ($latestState['token'] ?? '')) ?>">
                  <input type="hidden" name="apply_mode" value="<?= e($mode) ?>">
                  <button class="btn<?= $mode === 'all' ? '' : ' secondary' ?>" type="submit"><?= e($label) ?></button>
                </form>
              <?php endforeach; ?>
            <?php endif; ?>
            <button class="btn secondary" type="button" data-ai-copy-target="#<?= e($proposalId) ?>">Скопировать</button>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="drafts">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="demand_ai_copy_regenerate">
              <?= demand_ai_content_command_fields('demand_ai_copy_regenerate', 'draft', $draftId) ?>
              <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
              <input type="hidden" name="copy_regenerate_again" value="1">
              <button class="btn secondary" type="submit">Сгенерировать ещё раз</button>
            </form>
            <?php if (has_permission('demand.ai.view')): ?>
              <form method="post">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="tab" value="drafts">
                <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                <input type="hidden" name="action" value="demand_ai_copy_reject">
                <?= demand_ai_content_command_fields('demand_ai_copy_reject', 'draft', $draftId) ?>
                <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
                <input type="hidden" name="ai_copy_token" value="<?= e((string) ($latestState['token'] ?? '')) ?>">
                <button class="btn secondary" type="submit">Отклонить</button>
              </form>
            <?php endif; ?>
          </div>
        </section>
      <?php else: ?>
        <p class="field-hint">Для страницы, блока и FAQ используется безопасный контекст: город/регион, тип авто, связанные авто, риски, mustNotPromise, safeContentBlocks и факты, которые нельзя менять.</p>
      <?php endif; ?>
    </article>
    <?php
}

function demand_admin_preview_mode($value): string
{
    $mode = (string) $value;

    return in_array($mode, ['view', 'edit', 'check'], true) ? $mode : 'view';
}

function demand_admin_draft_visual_preview_url(array $draft, string $scopeFilter, bool $keepEditor = false, string $previewMode = 'view'): string
{
    $draftId = (string) ($draft['id'] ?? '');
    $extra = ['preview_draft' => $draftId];
    if ($keepEditor) {
        $extra['edit_draft'] = $draftId;
    }
    $previewMode = demand_admin_preview_mode($previewMode);
    if ($previewMode !== 'view') {
        $extra['preview_mode'] = $previewMode;
    }

    return demand_admin_scope_filter_url('drafts', $scopeFilter, $extra) . '#demand-draft-visual-preview';
}

function demand_admin_preview_mode_label(string $mode): string
{
    return [
        'view' => 'Просмотр',
        'edit' => 'Редактировать текст',
        'check' => 'Проверка',
    ][$mode] ?? 'Просмотр';
}

function demand_admin_landing_preview_block_body(array $block): string
{
    return trim((string) ($block['body'] ?? $block['text'] ?? $block['suggestedTextTemplate'] ?? ''));
}

function demand_admin_landing_preview_photo_path(array $car, string $fallback): string
{
    $photo = '';
    if (function_exists('car_photos')) {
        $photos = car_photos($car);
        $photo = (string) ($photos[0]['path'] ?? '');
    }
    if ($photo === '') {
        $photo = (string) ($car['image'] ?? '');
    }
    if (trim($photo) === '') {
        return $fallback;
    }

    return '/' . ltrim(str_replace('\\', '/', $photo), '/');
}

function demand_admin_landing_preview_linked_cars(array $draft): array
{
    $cars = [];
    foreach ((array) ($draft['linkedCars'] ?? []) as $slug) {
        $car = find_car((string) $slug);
        if (!$car) {
            continue;
        }
        if (function_exists('public_car_visible_for_api') && !public_car_visible_for_api($car)) {
            continue;
        }
        $cars[] = $car;
    }

    return array_values($cars);
}

function demand_admin_landing_preview_first_photo(array $cars): string
{
    $fallback = '/assets/img/cars/omoda-c5/omoda-c5-1.jpg';
    foreach ($cars as $car) {
        if (!is_array($car)) {
            continue;
        }
        $photo = demand_admin_landing_preview_photo_path($car, '');
        if ($photo !== '') {
            return $photo;
        }
    }

    return $fallback;
}

function demand_admin_landing_preview_faq_items(array $draft): array
{
    $items = [];
    foreach ((array) ($draft['contentBlocks'] ?? []) as $block) {
        if (!is_array($block) || (string) ($block['type'] ?? '') !== 'faq') {
            continue;
        }
        foreach ((array) ($block['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }
            $question = trim((string) ($item['question'] ?? ''));
            $answer = trim((string) ($item['answer'] ?? ''));
            if ($question !== '' && $answer !== '') {
                $items[] = ['question' => $question, 'answer' => $answer];
            }
        }
    }
    if ($items) {
        return array_slice($items, 0, 8);
    }

    foreach ((array) ($draft['recommendedFaq'] ?? []) as $item) {
        if (!is_array($item)) {
            continue;
        }
        $question = trim((string) ($item['question'] ?? ''));
        $answer = trim((string) ($item['answer'] ?? $item['answerGuidance'] ?? ''));
        if ($question !== '' && $answer !== '') {
            $items[] = ['question' => $question, 'answer' => $answer];
        }
    }

    return array_slice($items, 0, 8);
}

function demand_admin_landing_preview_paragraphs(string $text): void
{
    $text = trim($text);
    if ($text === '') {
        return;
    }
    $chunks = preg_split('/\R{2,}/u', $text) ?: [$text];
    foreach ($chunks as $chunk) {
        $chunk = trim((string) $chunk);
        if ($chunk === '') {
            continue;
        }
        ?><p><?= nl2br(e($chunk)) ?></p><?php
    }
}

function demand_admin_preview_hidden_inputs(string $draftId, string $scopeFilter, string $previewMode): void
{
    ?>
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="tab" value="drafts">
    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
    <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
    <input type="hidden" name="preview_mode" value="<?= e(demand_admin_preview_mode($previewMode)) ?>">
    <?php
}

function demand_admin_preview_field_editor(string $draftId, string $scopeFilter, string $previewMode, string $field, string $label, string $value, bool $textarea = true): void
{
    ?>
    <details class="demand-preview-edit-popover" data-preview-editor="field-<?= e($field) ?>">
      <summary class="btn secondary small">Изменить</summary>
      <form method="post" class="demand-preview-editor-form">
        <?php demand_admin_preview_hidden_inputs($draftId, $scopeFilter, $previewMode); ?>
        <input type="hidden" name="action" value="preview_text_save">
        <?= demand_editorial_command_fields('preview_text_save') ?>
        <input type="hidden" name="preview_edit_target" value="field">
        <input type="hidden" name="preview_field" value="<?= e($field) ?>">
        <label><?= e($label) ?>
          <?php if ($textarea): ?>
            <textarea name="preview_value" rows="5"><?= e($value) ?></textarea>
          <?php else: ?>
            <input type="text" name="preview_value" value="<?= e($value) ?>">
          <?php endif; ?>
        </label>
        <div class="demand-preview-editor-actions">
          <button class="btn small" type="submit">Сохранить в черновик</button>
          <button class="btn secondary small" type="submit" name="preview_after_save" value="check">Сохранить и проверить готовность</button>
        </div>
      </form>
    </details>
    <?php
}

function demand_admin_preview_ai_button(string $draftId, string $scopeFilter, string $previewMode, string $task, string $label, ?int $blockIndex = null, string $instruction = ''): void
{
    if (!has_permission('demand.ai_api.use') && !has_permission('demand.ai.package')) {
        return;
    }
    $options = [
        'style' => 'calm_human',
        'preserveSeoMeaning' => true,
        'preserveFacts' => true,
        'noUnconfirmedPromises' => true,
        'reduceKeywordRepeats' => in_array($task, ['reduce_preview_block_seo_overuse', 'rewrite_preview_block_shorter'], true),
        'oneTimeInstruction' => $instruction,
    ];
    ?>
    <form method="post" class="demand-preview-ai-action">
      <?php demand_admin_ai_copy_hidden_inputs($draftId, $scopeFilter, $task, $options, $blockIndex); ?>
      <input type="hidden" name="return_to_preview" value="1">
      <input type="hidden" name="preview_mode" value="<?= e(demand_admin_preview_mode($previewMode)) ?>">
      <button class="btn secondary small" type="submit"><?= e($label) ?></button>
    </form>
    <?php
}

function demand_admin_landing_preview_public_blocks(array $draft, array $linkedCars): array
{
    $items = [];
    foreach ((array) ($draft['contentBlocks'] ?? []) as $index => $block) {
        if (!is_array($block)) {
            continue;
        }
        $type = demand_clean_string((string) ($block['type'] ?? 'text'), 80);
        $title = demand_clean_string((string) ($block['title'] ?? ''), 180);
        $visibility = demand_normalize_content_block_visibility((string) ($block['visibility'] ?? ''), $type, $title);
        if ($visibility !== 'public' || in_array($type, ['faq', 'internal_links', 'internal_linking', 'available_cars'], true)) {
            continue;
        }
        $body = demand_public_landing_block_body($draft, $block, $linkedCars);
        if ($body === '') {
            continue;
        }
        $publicTitle = demand_public_landing_public_title($type, $title);
        $items[] = [
            'index' => (int) $index,
            'type' => $type !== '' ? $type : 'text',
            'title' => $publicTitle !== '' ? $publicTitle : ($title !== '' ? $title : 'Когда подойдёт такой автомобиль'),
            'rawTitle' => $title,
            'body' => $body,
            'rawBody' => demand_admin_landing_preview_block_body($block),
        ];
    }

    return array_values($items);
}

function demand_admin_landing_preview_faq_entries(array $draft): array
{
    $entries = [];
    foreach ((array) ($draft['contentBlocks'] ?? []) as $blockIndex => $block) {
        if (!is_array($block) || (string) ($block['type'] ?? '') !== 'faq') {
            continue;
        }
        foreach ((array) ($block['items'] ?? []) as $itemIndex => $item) {
            if (!is_array($item)) {
                continue;
            }
            $question = trim((string) ($item['question'] ?? ''));
            $answer = trim((string) ($item['answer'] ?? ''));
            if ($question !== '' && $answer !== '') {
                $entries[] = [
                    'blockIndex' => (int) $blockIndex,
                    'itemIndex' => (int) $itemIndex,
                    'question' => $question,
                    'answer' => $answer,
                ];
            }
        }
    }

    return array_slice($entries, 0, 8);
}

function demand_admin_landing_preview_car_price(array $car): string
{
    $carSlug = normalize_car_slug((string) ($car['slug'] ?? ''));
    $price = null;
    if (function_exists('rate_for_car') && $carSlug !== '') {
        $rate = rate_for_car($carSlug, $car);
        $price = normalize_rate_price($rate['base'] ?? ($car['price'] ?? null));
    } else {
        $price = normalize_rate_price($car['price'] ?? null);
    }
    if ($price === null) {
        return 'Цена уточняется менеджером';
    }

    return 'от ' . format_money((int) $price) . ' / сутки';
}

function demand_admin_landing_preview_render_content(array $draft, array $linkedCars, string $firstPhoto, string $scopeFilter = '', string $previewMode = 'view'): void
{
    $previewMode = demand_admin_preview_mode($previewMode);
    $draftId = (string) ($draft['id'] ?? '');
    $publicContent = demand_prepare_public_landing_content($draft);
    $canEditPreview = $previewMode === 'edit'
        && $draftId !== ''
        && has_permission('demand.drafts.edit')
        && demand_preview_text_edit_is_allowed($draft);
    $h1 = trim((string) ($draft['h1'] ?? $draft['title'] ?? 'Аренда авто в Крыму'));
    $intro = trim((string) ($publicContent['heroIntro'] ?? $draft['intro'] ?? 'Подберите автомобиль под задачу и уточните условия у менеджера.'));
    $slug = trim((string) ($draft['slug'] ?? ''));
    $faqItems = demand_admin_landing_preview_faq_entries($draft);
    if (!$faqItems) {
        $faqItems = demand_admin_landing_preview_faq_items($draft);
    }
    $publicBlocks = demand_admin_landing_preview_public_blocks($draft, $linkedCars);
    $publicSections = (array) ($publicContent['publicTextSections'] ?? []);
    $conditionCards = array_slice((array) ($publicContent['conditionCards'] ?? []), 0, 5);
    $publicInternalLinks = array_slice((array) ($publicContent['internalLinks'] ?? []), 0, 5);
    $ctaText = trim((string) ($publicContent['cta'] ?? 'Оставьте даты и пожелания — менеджер проверит доступные авто и условия.'));
    $internalLinkState = is_array($_SESSION['demand_internal_links_latest'] ?? null) ? $_SESSION['demand_internal_links_latest'] : [];
    $previewInternalSuggestions = (string) ($internalLinkState['draftId'] ?? '') === $draftId
        ? array_values(array_filter((array) ($internalLinkState['suggestions']['internalLinkSuggestions'] ?? []), 'is_array'))
        : [];
    ?>
    <div class="demand-public-page-preview<?= $canEditPreview ? ' is-preview-edit' : '' ?><?= $previewMode === 'check' ? ' is-preview-check' : '' ?>" data-preview-mode="<?= e($previewMode) ?>">
      <header class="demand-public-preview-header">
        <a class="demand-public-preview-brand" href="#" aria-label="Rent RK preview">Rent RK <span>автопрокат в Ялте</span></a>
        <nav aria-label="Навигация предпросмотра">
          <a href="#">Автомобили</a>
          <a href="#">Условия</a>
          <a href="#">FAQ</a>
          <a href="#">Контакты</a>
        </nav>
        <div class="demand-public-preview-contacts">
          <span>+7 (978) 948-51-11</span>
          <span>Telegram</span>
        </div>
      </header>
      <div class="demand-public-preview-breadcrumbs">Главная / <?= e($h1) ?></div>
      <section class="demand-public-preview-hero demand-preview-editable" data-preview-edit-zone="hero" style="--preview-hero-image: url('<?= e($firstPhoto) ?>')">
        <?php if ($canEditPreview): ?>
          <div class="demand-preview-edit-controls">
            <?php demand_admin_preview_field_editor($draftId, $scopeFilter, $previewMode, 'h1', 'H1', $h1, false); ?>
            <?php demand_admin_preview_field_editor($draftId, $scopeFilter, $previewMode, 'intro', 'Hero subtitle / intro', (string) ($draft['intro'] ?? $intro), true); ?>
            <?php demand_admin_preview_ai_button($draftId, $scopeFilter, $previewMode, 'regenerate_landing_intro', 'Оживить через AI', null, 'Перепиши hero subtitle для клиента, без HTML и без SEO-повторов.'); ?>
          </div>
        <?php endif; ?>
        <div>
          <p class="demand-public-preview-eyebrow">Rent RK</p>
          <h1><?= e($h1) ?></h1>
          <p class="demand-public-preview-lead"><?= e($intro) ?></p>
          <div class="demand-public-preview-buttons">
            <span>Оставить заявку</span>
            <span>Смотреть авто</span>
          </div>
        </div>
      </section>
      <?php if ($linkedCars): ?>
        <section class="demand-public-preview-section">
          <p class="demand-public-preview-eyebrow">Подходящие автомобили</p>
          <h2>Авто по этому запросу</h2>
          <div class="demand-public-preview-cars">
            <?php foreach (array_slice($linkedCars, 0, 6) as $car): ?>
              <?php
                if (!is_array($car)) {
                    continue;
                }
                $carSlug = normalize_car_slug((string) ($car['slug'] ?? ''));
                $photo = demand_admin_landing_preview_photo_path($car, $firstPhoto);
                $carName = (string) ($car['name'] ?? ($carSlug !== '' ? car_name($carSlug) : 'Автомобиль'));
                $carMeta = trim((string) ($car['class'] ?? $car['body'] ?? 'Автомобиль'));
                if ((int) ($car['seats'] ?? 0) > 0) {
                    $carMeta .= ' · ' . (int) $car['seats'] . ' мест';
                }
              ?>
              <article class="demand-public-preview-car-card">
                <img src="<?= e($photo) ?>" alt="<?= e($carName) ?>" loading="lazy">
                <div>
                  <h3><?= e($carName) ?></h3>
                  <p><?= e($carMeta) ?></p>
                  <small><?= e(demand_admin_landing_preview_car_price($car)) ?></small>
                  <span>Выбрать авто</span>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
        </section>
      <?php else: ?>
        <section class="demand-public-preview-section is-soft">
          <h2>Авто будут показаны после привязки</h2>
          <p>В черновике пока нет публично доступных связанных автомобилей. Такой предпросмотр помогает увидеть текст и структуру, но перед публикацией стоит проверить автопарк.</p>
        </section>
      <?php endif; ?>
      <section class="demand-public-preview-section is-soft">
        <?php foreach (($publicBlocks ?: $publicSections) as $block): ?>
          <?php $body = (string) ($block['body'] ?? ''); ?>
          <?php if (trim((string) ($block['title'] ?? '')) === '' && $body === '') { continue; } ?>
          <article class="demand-public-preview-text-block demand-preview-editable" data-preview-edit-zone="content-block" data-preview-block-index="<?= e((string) ($block['index'] ?? '')) ?>">
            <?php if ($canEditPreview && isset($block['index'])): ?>
              <div class="demand-preview-edit-controls">
                <details class="demand-preview-edit-popover" data-preview-editor="block-<?= e((string) $block['index']) ?>">
                  <summary class="btn secondary small">Изменить</summary>
                  <form method="post" class="demand-preview-editor-form">
                    <?php demand_admin_preview_hidden_inputs($draftId, $scopeFilter, $previewMode); ?>
                    <input type="hidden" name="action" value="preview_text_save">
                    <?= demand_editorial_command_fields('preview_text_save') ?>
                    <input type="hidden" name="preview_edit_target" value="block">
                    <input type="hidden" name="block_index" value="<?= e((string) $block['index']) ?>">
                    <label>Заголовок
                      <input type="text" name="block_title" value="<?= e((string) ($block['rawTitle'] ?? $block['title'] ?? '')) ?>">
                    </label>
                    <label>Тип блока
                      <select name="block_type">
                        <?php foreach (['text', 'who_is_it_for', 'conditions', 'deposit_explanation', 'pickup_delivery', 'what_to_confirm_before_booking', 'weekly_rental'] as $type): ?>
                          <option value="<?= e($type) ?>" <?= (string) ($block['type'] ?? '') === $type ? 'selected' : '' ?>><?= e($type) ?></option>
                        <?php endforeach; ?>
                      </select>
                    </label>
                    <label>Текст
                      <textarea name="block_body" rows="7"><?= e((string) ($block['rawBody'] ?? $body)) ?></textarea>
                    </label>
                    <label>Заметка admin
                      <input type="text" name="block_admin_note" value="">
                    </label>
                    <div class="demand-preview-editor-actions">
                      <button class="btn small" type="submit">Сохранить в черновик</button>
                      <button class="btn secondary small" type="submit" name="preview_after_save" value="check">Сохранить и проверить готовность</button>
                    </div>
                  </form>
                </details>
                <?php demand_admin_preview_ai_button($draftId, $scopeFilter, $previewMode, 'regenerate_preview_block_human', 'Оживить через AI', (int) $block['index'], 'Перепиши выбранный публичный блок живее, сохрани факты и не добавляй HTML.'); ?>
                <?php demand_admin_preview_ai_button($draftId, $scopeFilter, $previewMode, 'rewrite_preview_block_shorter', 'Сделать короче', (int) $block['index'], 'Сократи выбранный блок без потери фактов и без рекламных штампов.'); ?>
                <?php demand_admin_preview_ai_button($draftId, $scopeFilter, $previewMode, 'reduce_preview_block_seo_overuse', 'Убрать SEO-повторы', (int) $block['index'], 'Убери механические повторы ключевых фраз, оставь естественный клиентский текст.'); ?>
                <?php demand_admin_preview_ai_button($draftId, $scopeFilter, $previewMode, 'regenerate_preview_block_human', 'Сгенерировать ещё раз', (int) $block['index'], 'Дай другой вариант этого блока для клиента.'); ?>
              </div>
            <?php endif; ?>
            <h2><?= e((string) ($block['title'] ?? 'Важно знать')) ?></h2>
            <?php demand_admin_landing_preview_paragraphs($body); ?>
          </article>
        <?php endforeach; ?>
      </section>
      <section class="demand-public-preview-section">
        <h2>Условия</h2>
        <div class="demand-public-preview-condition-cards">
          <?php foreach ($conditionCards as $card): ?>
            <article>
              <h3><?= e((string) ($card['title'] ?? 'Условие')) ?></h3>
              <p><?= e((string) ($card['text'] ?? 'Уточняется менеджером перед бронированием.')) ?></p>
            </article>
          <?php endforeach; ?>
        </div>
      </section>
      <?php if ($publicInternalLinks || $previewMode !== 'view'): ?>
        <section class="demand-public-preview-section is-soft demand-preview-internal-links" id="demand-preview-internal-links" data-preview-edit-zone="internal-links">
          <h2>Также может подойти</h2>
          <?php if ($publicInternalLinks): ?>
            <p>Если вы ещё выбираете формат поездки, посмотрите похожие варианты.</p>
            <div class="demand-public-preview-related-links">
              <?php foreach ($publicInternalLinks as $link): ?>
                <a href="<?= e((string) ($link['url'] ?? '#')) ?>"><?= e((string) ($link['anchorText'] ?? $link['title'] ?? 'Похожий вариант')) ?></a>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <p>Ссылки пока не добавлены.</p>
            <?php if ($canEditPreview || $previewMode === 'check'): ?>
              <div class="demand-preview-editor-actions">
                <form method="post">
                  <?php demand_admin_preview_hidden_inputs($draftId, $scopeFilter, $previewMode); ?>
                  <input type="hidden" name="action" value="draft_internal_links_suggest">
                  <?= demand_editorial_command_fields('draft_internal_links_suggest') ?>
                  <input type="hidden" name="return_to_preview" value="1">
                  <button class="btn secondary small" type="submit">Подобрать через AI</button>
                </form>
                <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $draftId]) . '#demand-internal-links') ?>">Добавить вручную</a>
              </div>
              <?php if ($previewInternalSuggestions): ?>
                <form method="post" class="demand-preview-link-suggestions">
                  <?php demand_admin_preview_hidden_inputs($draftId, $scopeFilter, $previewMode); ?>
                  <input type="hidden" name="action" value="draft_internal_links_apply">
                  <?= demand_editorial_command_fields('draft_internal_links_apply') ?>
                  <input type="hidden" name="return_to_preview" value="1">
                  <input type="hidden" name="internal_links_token" value="<?= e((string) ($internalLinkState['token'] ?? '')) ?>">
                  <div class="demand-preview-check-list">
                    <?php foreach (array_slice($previewInternalSuggestions, 0, 5) as $index => $suggestion): ?>
                      <label class="check-row">
                        <input type="checkbox" name="internal_link_indexes[]" value="<?= e((string) $index) ?>" <?= !empty($suggestion['safeToApply']) ? 'checked' : '' ?>>
                        <span>
                          <strong><?= e((string) ($suggestion['anchorText'] ?? $suggestion['targetTitle'] ?? 'Ссылка')) ?></strong>
                          <small><?= e((string) ($suggestion['reason'] ?? $suggestion['status'] ?? '')) ?></small>
                        </span>
                      </label>
                    <?php endforeach; ?>
                  </div>
                  <div class="demand-preview-editor-actions">
                    <button class="btn small" type="submit" name="apply_mode" value="selected">Добавить выбранные ссылки</button>
                    <button class="btn secondary small" type="submit" name="apply_mode" value="all_safe">Добавить все безопасные</button>
                  </div>
                </form>
              <?php endif; ?>
            <?php endif; ?>
          <?php endif; ?>
        </section>
      <?php endif; ?>
      <?php if ($faqItems): ?>
        <section class="demand-public-preview-section is-soft">
          <h2>FAQ</h2>
          <?php foreach ($faqItems as $item): ?>
            <details class="demand-preview-editable" data-preview-edit-zone="faq" data-preview-faq-index="<?= e((string) ($item['itemIndex'] ?? '')) ?>">
              <summary><?= e((string) ($item['question'] ?? 'Вопрос')) ?></summary>
              <p><?= e((string) ($item['answer'] ?? 'Уточняется менеджером.')) ?></p>
              <?php if ($canEditPreview && isset($item['blockIndex'], $item['itemIndex'])): ?>
                <div class="demand-preview-edit-controls">
                  <details class="demand-preview-edit-popover" data-preview-editor="faq-<?= e((string) $item['blockIndex']) ?>-<?= e((string) $item['itemIndex']) ?>">
                    <summary class="btn secondary small">Изменить</summary>
                    <form method="post" class="demand-preview-editor-form">
                      <?php demand_admin_preview_hidden_inputs($draftId, $scopeFilter, $previewMode); ?>
                      <input type="hidden" name="action" value="preview_text_save">
                      <?= demand_editorial_command_fields('preview_text_save') ?>
                      <input type="hidden" name="preview_edit_target" value="faq">
                      <input type="hidden" name="block_index" value="<?= e((string) $item['blockIndex']) ?>">
                      <input type="hidden" name="faq_index" value="<?= e((string) $item['itemIndex']) ?>">
                      <label>Вопрос
                        <input type="text" name="faq_question" value="<?= e((string) ($item['question'] ?? '')) ?>">
                      </label>
                      <label>Ответ
                        <textarea name="faq_answer" rows="5"><?= e((string) ($item['answer'] ?? '')) ?></textarea>
                      </label>
                      <div class="demand-preview-editor-actions">
                        <button class="btn small" type="submit">Сохранить в черновик</button>
                      </div>
                    </form>
                  </details>
                  <?php demand_admin_preview_ai_button($draftId, $scopeFilter, $previewMode, 'regenerate_preview_faq', 'Сгенерировать FAQ ещё раз', (int) $item['blockIndex'], 'Перепиши FAQ как короткие клиентские ответы, без HTML и без служебных подсказок.'); ?>
                </div>
              <?php endif; ?>
            </details>
          <?php endforeach; ?>
        </section>
      <?php endif; ?>
      <section class="demand-public-preview-booking demand-preview-editable" id="preview-booking" data-preview-edit-zone="cta">
        <?php if ($canEditPreview): ?>
          <div class="demand-preview-edit-controls">
            <?php demand_admin_preview_field_editor($draftId, $scopeFilter, $previewMode, 'ctaText', 'CTA перед формой', (string) ($draft['ctaText'] ?? $ctaText), true); ?>
          </div>
        <?php endif; ?>
        <div>
          <p class="demand-public-preview-eyebrow">Заявка</p>
          <h2>Подобрать автомобиль</h2>
          <p><?= e($ctaText) ?></p>
        </div>
        <div class="demand-public-preview-form" aria-label="Макет формы заявки">
          <span>Имя</span>
          <span>Телефон</span>
          <span>Дата подачи</span>
          <span>Место подачи</span>
          <strong>Отправить заявку</strong>
        </div>
      </section>
      <footer class="demand-public-preview-footer">
        <strong>Rent RK</strong>
        <span><?= $slug !== '' ? e('/landing.php?slug=' . $slug) : 'Черновик без slug' ?></span>
      </footer>
    </div>
    <?php
}

function demand_admin_render_preview_ai_diff(array $draft, string $scopeFilter, $latestState = null): void
{
    if (!is_array($latestState) || (string) ($latestState['entityType'] ?? '') !== 'draft') {
        return;
    }
    $draftId = (string) ($draft['id'] ?? '');
    if ($draftId === '' || (string) ($latestState['entityId'] ?? '') !== $draftId) {
        return;
    }
    $request = is_array($latestState['request'] ?? null) ? $latestState['request'] : [];
    if (empty($request['returnToPreview'])) {
        return;
    }
    $diff = is_array($latestState['diff'] ?? null) ? $latestState['diff'] : [];
    $rows = array_values(array_filter((array) ($diff['rows'] ?? []), 'is_array'));
    $proposalId = 'demand-preview-ai-proposal-' . preg_replace('/[^A-Za-z0-9_-]+/', '-', $draftId);
    ?>
    <section class="demand-preview-ai-diff" id="demand-preview-ai-diff">
      <div class="panel-head">
        <div>
          <h3>AI-вариант для preview</h3>
          <p class="muted">Проверьте diff перед применением. AI не публикует страницу, не открывает индексацию и не меняет sitemap.xml или robots.txt.</p>
        </div>
        <span class="status status-reserved"><?= e(demand_ai_task_label((string) ($latestState['task'] ?? ''))) ?></span>
      </div>
      <?php if ($rows): ?>
        <div class="demand-copy-preview-grid" id="<?= e($proposalId) ?>">
          <?php foreach ($rows as $row): ?>
            <article>
              <h4><?= e((string) ($row['label'] ?? $row['field'] ?? 'поле')) ?></h4>
              <p class="muted">Было</p>
              <pre><?= e((string) ($row['before'] ?? '')) ?></pre>
              <p class="muted">Станет</p>
              <pre><?= e((string) ($row['after'] ?? '')) ?></pre>
            </article>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <p class="muted">AI подготовил ответ, но в нём нет применимых текстовых изменений для черновика.</p>
      <?php endif; ?>
      <div class="demand-copy-preview-actions">
        <?php if (has_permission('demand.ai.apply')): ?>
          <?php foreach (['all' => 'Применить к блоку', 'blocks' => 'Применить только блоки', 'faq' => 'Применить FAQ'] as $mode => $label): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="drafts">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="demand_ai_copy_apply">
              <?= demand_ai_content_command_fields('demand_ai_copy_apply', 'draft', $draftId) ?>
              <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
              <input type="hidden" name="ai_copy_token" value="<?= e((string) ($latestState['token'] ?? '')) ?>">
              <input type="hidden" name="apply_mode" value="<?= e($mode) ?>">
              <button class="btn<?= $mode === 'all' ? '' : ' secondary' ?> small" type="submit"><?= e($label) ?></button>
            </form>
          <?php endforeach; ?>
        <?php endif; ?>
        <button class="btn secondary small" type="button" data-ai-copy-target="#<?= e($proposalId) ?>">Скопировать</button>
        <form method="post">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="tab" value="drafts">
          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
          <input type="hidden" name="action" value="demand_ai_copy_regenerate">
          <?= demand_ai_content_command_fields('demand_ai_copy_regenerate', 'draft', $draftId) ?>
          <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
          <input type="hidden" name="copy_regenerate_again" value="1">
          <input type="hidden" name="return_to_preview" value="1">
          <input type="hidden" name="preview_mode" value="<?= e(demand_admin_preview_mode($request['previewMode'] ?? 'edit')) ?>">
          <button class="btn secondary small" type="submit">Сгенерировать ещё раз</button>
        </form>
        <?php if (has_permission('demand.ai.view')): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="drafts">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_ai_copy_reject">
            <?= demand_ai_content_command_fields('demand_ai_copy_reject', 'draft', $draftId) ?>
            <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
            <input type="hidden" name="ai_copy_token" value="<?= e((string) ($latestState['token'] ?? '')) ?>">
            <button class="btn secondary small" type="submit">Отклонить</button>
          </form>
        <?php endif; ?>
      </div>
    </section>
    <?php
}

function demand_admin_preview_check_issues(array $draft): array
{
    $issues = [];
    $textParts = [
        (string) ($draft['h1'] ?? ''),
        (string) ($draft['intro'] ?? ''),
        (string) ($draft['ctaText'] ?? ''),
    ];
    $hasDeposit = false;
    $hasServiceTitle = false;
    $hasLongBlock = false;
    foreach ((array) ($draft['contentBlocks'] ?? []) as $block) {
        if (!is_array($block)) {
            continue;
        }
        $title = (string) ($block['title'] ?? '');
        $body = demand_admin_landing_preview_block_body($block);
        $textParts[] = $title;
        $textParts[] = $body;
        if (stripos($title . ' ' . $body, 'залог') !== false) {
            $hasDeposit = true;
        }
        if (function_exists('demand_public_landing_is_service_title') && demand_public_landing_is_service_title($title)) {
            $hasServiceTitle = true;
        }
        if (function_exists('mb_strlen') ? mb_strlen($body, 'UTF-8') > 900 : strlen($body) > 900) {
            $hasLongBlock = true;
        }
    }
    $text = demand_lower(implode(' ', $textParts));
    if (!$hasDeposit) {
        $issues[] = ['code' => 'missing_deposit', 'title' => 'Нет блока залога', 'hint' => 'Добавьте спокойное объяснение, что точный залог зависит от автомобиля и условий.'];
    }
    if (!demand_public_internal_links($draft)) {
        $issues[] = ['code' => 'missing_internal_links', 'title' => 'Нет внутренних ссылок', 'hint' => 'AI может подобрать связи с авто, условиями или похожими посадочными.'];
    }
    $h1Needle = demand_lower((string) ($draft['h1'] ?? ''));
    if (preg_match('/(.{12,80})\\s+\\1/iu', $text) || ($h1Needle !== '' && substr_count($text, $h1Needle) > 3)) {
        $issues[] = ['code' => 'seo_repeats', 'title' => 'Есть SEO-повторы', 'hint' => 'Сократите механические повторы ключевой фразы.'];
    }
    if ($hasServiceTitle) {
        $issues[] = ['code' => 'service_heading', 'title' => 'Есть служебный заголовок', 'hint' => 'Проверьте, что Stage C/guidance не попали в публичный текст.'];
    }
    if ($hasLongBlock) {
        $issues[] = ['code' => 'long_block', 'title' => 'Слишком длинный блок', 'hint' => 'Разбейте или сократите текст, чтобы страница не стала простынёй.'];
    }
    foreach (['без залога', 'самая низкая', 'самые низкие', 'всегда доступ', 'подача в любое время'] as $marker) {
        if ($marker !== '' && str_contains($text, $marker)) {
            $issues[] = ['code' => 'risky_promise', 'title' => 'Рискованное обещание', 'hint' => 'Не обещайте условия без подтверждения в данных.'];
            break;
        }
    }
    if (!demand_draft_editorial_has_faq($draft)) {
        $issues[] = ['code' => 'missing_faq', 'title' => 'FAQ отсутствует', 'hint' => 'Добавьте ответы на 3–5 реальных вопросов клиента.'];
    }
    $cta = trim((string) ($draft['ctaText'] ?? ''));
    if ($cta === '' || (function_exists('mb_strlen') ? mb_strlen($cta, 'UTF-8') < 60 : strlen($cta) < 60)) {
        $issues[] = ['code' => 'weak_cta', 'title' => 'CTA слабый', 'hint' => 'Перед формой стоит коротко объяснить, что менеджер проверит даты, авто и условия.'];
    }

    return $issues;
}

function demand_admin_render_preview_check_issues(array $draft, string $scopeFilter, string $previewMode): void
{
    $issues = demand_admin_preview_check_issues($draft);
    if (!$issues) {
        ?>
        <section class="notice success demand-preview-check-panel">
          <strong>Проблемы preview не найдены.</strong>
          <p>Перед публикацией всё равно проверьте факты, авто, залог и условия вручную.</p>
        </section>
        <?php
        return;
    }
    $draftId = (string) ($draft['id'] ?? '');
    ?>
    <section class="demand-preview-check-panel" data-preview-check-panel>
      <div class="panel-head">
        <div>
          <h3>Проверка preview</h3>
          <p class="muted">Подсвечены только редакторские вопросы. Исправления остаются в черновике и не меняют публикацию или индекс.</p>
        </div>
        <span class="status status-reserved"><?= count($issues) ?> к проверке</span>
      </div>
      <div class="demand-preview-check-list">
        <?php foreach ($issues as $issue): ?>
          <article data-preview-check-issue="<?= e((string) ($issue['code'] ?? 'issue')) ?>">
            <strong><?= e((string) ($issue['title'] ?? 'Проверить')) ?></strong>
            <p><?= e((string) ($issue['hint'] ?? 'Проверьте текст перед публикацией.')) ?></p>
            <div class="demand-preview-editor-actions">
              <a class="btn secondary small" href="<?= e(demand_admin_draft_visual_preview_url($draft, $scopeFilter, true, 'edit')) ?>">Исправить</a>
              <?php demand_admin_preview_ai_button($draftId, $scopeFilter, $previewMode, (string) ($issue['code'] ?? '') === 'missing_faq' ? 'regenerate_preview_faq' : 'make_copy_more_human', 'Попросить AI', null, 'Исправь проблему preview: ' . (string) ($issue['title'] ?? '')); ?>
              <button class="btn secondary small" type="button">Пропустить</button>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    </section>
    <?php
}

function demand_admin_render_draft_visual_preview(array $draft, string $scopeFilter, bool $showEditLink = true): void
{
    $linkedCars = demand_admin_landing_preview_linked_cars($draft);
    $firstPhoto = demand_admin_landing_preview_first_photo($linkedCars);
    $draftId = (string) ($draft['id'] ?? '');
    $isPublic = demand_public_landing_is_available($draft);
    $previewMode = demand_admin_preview_mode($_GET['preview_mode'] ?? $_POST['preview_mode'] ?? 'view');
    $keepEditor = !$showEditLink;
    $latestAiCopy = is_array($_SESSION['demand_ai_copy_latest'] ?? null) ? $_SESSION['demand_ai_copy_latest'] : null;
    ?>
    <article class="panel demand-preview-panel demand-page-preview-panel is-preview-mode-<?= e($previewMode) ?>" id="demand-draft-visual-preview" data-preview-mode="<?= e($previewMode) ?>">
      <div class="panel-head">
        <div>
          <h2>Предпросмотр страницы: <?= e((string) ($draft['h1'] ?? $draft['title'] ?? 'Черновик')) ?></h2>
          <p class="muted"><?= $isPublic ? 'Публичная ссылка уже доступна по текущему этапу. Ниже показан внешний вид страницы внутри админки.' : 'Только в админке: предпросмотр не публикует страницу, не открывает индексацию и не меняет sitemap.xml или robots.txt.' ?></p>
        </div>
        <span class="status status-service">admin-only preview</span>
      </div>
      <div class="demand-page-preview-actions">
        <nav class="demand-preview-mode-tabs" aria-label="Режим предпросмотра">
          <?php foreach (['view', 'edit', 'check'] as $mode): ?>
            <a class="btn small<?= $previewMode === $mode ? '' : ' secondary' ?>" href="<?= e(demand_admin_draft_visual_preview_url($draft, $scopeFilter, $keepEditor, $mode)) ?>"><?= e(demand_admin_preview_mode_label($mode)) ?></a>
          <?php endforeach; ?>
        </nav>
        <?php if ($showEditLink && has_permission('demand.drafts.edit')): ?>
          <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $draftId])) ?>">Редактировать черновик</a>
        <?php endif; ?>
        <a class="btn secondary small" href="<?= e(demand_admin_draft_visual_preview_url($draft, $scopeFilter, $keepEditor, $previewMode)) ?>">Обновить предпросмотр</a>
        <?php if ($isPublic): ?>
          <a class="btn secondary small" href="<?= e(demand_public_landing_path($draft)) ?>" target="_blank" rel="noopener">Открыть публичную страницу</a>
        <?php endif; ?>
      </div>
      <div class="notice info demand-page-preview-safety">
        Это визуальный макет будущей страницы. Публикационный статус: <?= e(demand_admin_ui_label((string) ($draft['publishStatus'] ?? 'draft'))) ?>, индексация: <?= e(demand_admin_ui_label((string) ($draft['indexStatus'] ?? 'blocked'))) ?>. Форма заявки в предпросмотре не отправляет данные.
      </div>
      <?php if ($previewMode === 'edit' && has_permission('demand.drafts.edit') && demand_preview_text_edit_is_allowed($draft)): ?>
        <section class="demand-preview-meta-editor" data-preview-edit-zone="meta">
          <h3>Meta / заголовки</h3>
          <p class="muted">Title и description меняются через управляемую форму, без inline HTML.</p>
          <div class="demand-preview-editor-actions">
            <?php demand_admin_preview_field_editor($draftId, $scopeFilter, $previewMode, 'title', 'Meta title', (string) ($draft['title'] ?? ''), false); ?>
            <?php demand_admin_preview_field_editor($draftId, $scopeFilter, $previewMode, 'metaDescription', 'Meta description', (string) ($draft['metaDescription'] ?? ''), true); ?>
          </div>
        </section>
      <?php elseif ($previewMode === 'edit'): ?>
        <section class="notice warning demand-preview-meta-editor">
          <strong>Редактирование текста недоступно для этого предпросмотра.</strong>
          <p>Inline-правка включается только для draft / published_noindex без открытой индексации. Indexed, archived, merged и rolled_back страницы защищены от прямой правки.</p>
        </section>
      <?php endif; ?>
      <div class="demand-page-preview-browser" aria-label="Визуальный предпросмотр посадочной страницы">
        <div class="demand-page-preview-topbar">
          <span aria-hidden="true"></span><span aria-hidden="true"></span><span aria-hidden="true"></span>
          <code><?= e('/landing.php?slug=' . (string) ($draft['slug'] ?? '')) ?></code>
        </div>
        <?php demand_admin_landing_preview_render_content($draft, $linkedCars, $firstPhoto, $scopeFilter, $previewMode); ?>
      </div>
      <?php demand_admin_render_preview_ai_diff($draft, $scopeFilter, $latestAiCopy); ?>
      <?php if ($previewMode === 'check'): ?>
        <?php demand_admin_render_preview_check_issues($draft, $scopeFilter, $previewMode); ?>
      <?php endif; ?>
      <div class="demand-brief-grid demand-page-preview-diagnostics">
        <div>
          <h3>Что должна объяснить страница</h3>
          <p><?= e(demand_admin_stage_c_questions_text($draft, 5)) ?></p>
        </div>
        <div>
          <h3>Что нельзя обещать</h3>
          <p><?= e(implode('; ', array_slice(array_map('strval', (array) ($draft['mustNotPromise'] ?? [])), 0, 5))) ?></p>
        </div>
        <div>
          <h3>Готовность для пользователя</h3>
          <p><?= e(demand_admin_stage_c_score_text($draft, 'userClarityScore')) ?></p>
        </div>
        <div>
          <h3>Готовность для поиска/AI</h3>
          <p><?= e(demand_admin_stage_c_score_text($draft, 'aiSearchReadiness')) ?></p>
        </div>
      </div>
    </article>
    <?php
}

function demand_admin_ai_inline_buttons(string $entityType, string $entityId, string $scopeFilter, string $tab, array $tasks): void
{
    if (!has_permission('demand.ai.package')) {
        return;
    }
    foreach ($tasks as $task => $label): ?>
      <form method="post" class="demand-ai-inline-form">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="tab" value="<?= e($tab) ?>">
        <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
        <input type="hidden" name="action" value="demand_ai_generate_package">
        <?= demand_ai_content_command_fields('demand_ai_generate_package', $entityType, $entityId) ?>
        <input type="hidden" name="entity_type" value="<?= e($entityType) ?>">
        <input type="hidden" name="entity_id" value="<?= e($entityId) ?>">
        <input type="hidden" name="ai_task" value="<?= e((string) $task) ?>">
        <button class="btn secondary small" type="submit"><?= e((string) $label) ?></button>
      </form>
    <?php endforeach;
}

function demand_admin_ai_render_panel(string $entityType, string $entityId, string $scopeFilter, string $tab, array $tasks, $latestPackage = null, $latestPreview = null): void
{
    global $demandIsDetailedView;

    if (!has_permission('demand.ai.view')) {
        return;
    }
    $hasPackage = demand_admin_ai_context_matches($latestPackage, $entityType, $entityId);
    $hasPreview = demand_admin_ai_context_matches($latestPreview, $entityType, $entityId);
    $package = $hasPackage && is_array($latestPackage['package'] ?? null) ? $latestPackage['package'] : null;
    $packageJson = $package ? json_encode($package, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) : '';
    $packageText = $hasPackage ? (string) ($latestPackage['text'] ?? '') : '';
    $preview = $hasPreview && is_array($latestPreview['diff'] ?? null) ? $latestPreview['diff'] : null;
    $jsonId = 'demand-ai-json-' . preg_replace('/[^A-Za-z0-9_-]+/', '-', $entityType . '-' . $entityId);
    $textId = 'demand-ai-text-' . preg_replace('/[^A-Za-z0-9_-]+/', '-', $entityType . '-' . $entityId);
    $panelId = ($hasPackage || $hasPreview)
        ? 'demand-ai-helper'
        : 'demand-ai-helper-' . preg_replace('/[^A-Za-z0-9_-]+/', '-', $entityType . '-' . $entityId);
    ?>
    <article class="demand-ai-panel" id="<?= e($panelId) ?>">
      <div class="panel-head">
        <div>
          <h2>AI-помощник</h2>
          <p class="muted">Система соберёт безопасный пакет данных. Его можно скопировать в ChatGPT или другой AI-сервис. Ответ можно вставить обратно и применить только после проверки.</p>
        </div>
        <span class="status status-service"><?= e(demand_ai_entity_label($entityType)) ?></span>
      </div>
      <div class="notice warning demand-ai-warning">AI может ошибаться. Проверьте цены, залог, наличие авто, условия подачи и любые обещания клиенту.</div>
      <?php if ($demandIsDetailedView && has_permission('demand.ai.package')): ?>
        <div class="demand-ai-task-grid">
          <?php demand_admin_ai_inline_buttons($entityType, $entityId, $scopeFilter, $tab, $tasks); ?>
        </div>
      <?php endif; ?>
      <?php if ($package): ?>
        <section class="demand-ai-package">
          <h3>Пакет для AI</h3>
          <?php if (!empty($package['testMode'])): ?>
            <div class="notice warning">
              Тестовый AI-пакет: он собран для smoke/QA-проверки и не используется для реального SEO-плана, публикации, открытия поиска или приоритизации.
            </div>
          <?php endif; ?>
          <?php if (is_array($package['finalDecision'] ?? null)): ?>
            <div class="notice">
              Итоговая защита: <?= e((string) ($package['finalDecision']['action'] ?? 'manual_review_before_draft')) ?>.
              Совпадение спроса и авто: <?= e((string) ($package['finalDecision']['supplyFitStatus'] ?? 'no_confirmed_fit')) ?>.
            </div>
          <?php endif; ?>
          <div class="demand-ai-actions">
            <button class="btn secondary small" type="button" data-ai-copy-target="#<?= e($jsonId) ?>">Скопировать пакет</button>
            <button class="btn secondary small" type="button" data-ai-download-target="#<?= e($jsonId) ?>" data-ai-download-name="rent-rk-ai-package-<?= e((string) ($package['task'] ?? 'task')) ?>.json">Скачать пакет</button>
            <button class="btn secondary small" type="button" data-ai-copy-target="#<?= e($textId) ?>">Скопировать текстовую версию</button>
          </div>
          <textarea id="<?= e($jsonId) ?>" class="demand-ai-textarea" rows="12" readonly><?= e($packageJson) ?></textarea>
          <details class="demand-technical-details">
            <summary><span>Текстовая версия пакета</span><small>Можно скопировать вместо JSON.</small></summary>
            <textarea id="<?= e($textId) ?>" class="demand-ai-textarea" rows="10" readonly><?= e($packageText) ?></textarea>
          </details>
        </section>
      <?php endif; ?>
      <section class="demand-ai-response">
        <h3>Вставить ответ AI</h3>
        <form method="post" class="form-stack">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="tab" value="<?= e($tab) ?>">
          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
          <input type="hidden" name="action" value="demand_ai_preview_response">
          <?= demand_ai_content_command_fields('demand_ai_preview_response', $entityType, $entityId) ?>
          <input type="hidden" name="entity_type" value="<?= e($entityType) ?>">
          <input type="hidden" name="entity_id" value="<?= e($entityId) ?>">
          <label>
            Задача
            <select name="ai_task">
              <?php foreach ($tasks as $task => $label): ?>
                <option value="<?= e((string) $task) ?>" <?= $package && (string) ($package['task'] ?? '') === (string) $task ? 'selected' : '' ?>><?= e(demand_ai_task_label((string) $task)) ?></option>
              <?php endforeach; ?>
            </select>
          </label>
          <label class="rental-field-wide">JSON от AI <textarea name="ai_response_json" rows="7" placeholder='{"title":"...","intro":"...","notesForAdmin":["..."]}'></textarea></label>
          <button class="btn secondary" type="submit">Показать изменения</button>
        </form>
      </section>
      <?php if ($preview): ?>
        <section class="demand-ai-preview">
          <h3>Preview / diff</h3>
          <ul class="demand-check-list">
            <?php foreach ((array) ($preview['warnings'] ?? []) as $warning): ?><li class="is-warn"><?= e((string) $warning) ?></li><?php endforeach; ?>
            <?php foreach ((array) ($latestPreview['ignoredFields'] ?? []) as $field): ?><li class="is-warn">Поле <?= e((string) $field) ?> проигнорировано: оно не входит в allow-list.</li><?php endforeach; ?>
          </ul>
          <div class="table-wrap">
            <table class="report-table demand-ai-diff-table">
              <thead><tr><th>Поле</th><th>Было</th><th>Станет</th></tr></thead>
              <tbody>
                <?php foreach ((array) ($preview['rows'] ?? []) as $row): ?>
                  <tr class="<?= !empty($row['changed']) ? 'is-changed' : '' ?>">
                    <th><?= e((string) ($row['label'] ?? $row['field'] ?? '')) ?></th>
                    <td><pre><?= e((string) ($row['before'] ?? '')) ?></pre></td>
                    <td><pre><?= e((string) ($row['after'] ?? '')) ?></pre></td>
                  </tr>
                <?php endforeach; ?>
                <?php if (empty($preview['rows'])): ?><tr><td colspan="3">Нет изменений для разрешённых полей.</td></tr><?php endif; ?>
              </tbody>
            </table>
          </div>
          <div class="demand-ai-actions">
            <?php if (!empty($preview['applySupported']) && has_permission('demand.ai.apply')): ?>
              <form method="post">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="tab" value="<?= e($tab) ?>">
                <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                <input type="hidden" name="action" value="demand_ai_apply_proposal">
                <?= demand_ai_content_command_fields('demand_ai_apply_proposal', $entityType, $entityId) ?>
                <input type="hidden" name="entity_type" value="<?= e($entityType) ?>">
                <input type="hidden" name="entity_id" value="<?= e($entityId) ?>">
                <input type="hidden" name="ai_preview_token" value="<?= e((string) ($latestPreview['token'] ?? '')) ?>">
                <button class="btn" type="submit">Применить предложение</button>
              </form>
              <small>Изменения сохранятся в черновике/ТЗ/подсказке. Страница не будет опубликована и не будет открыта для поиска.</small>
            <?php else: ?>
              <small>Для этого контекста MVP показывает только preview. Автоматического применения нет.</small>
            <?php endif; ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="<?= e($tab) ?>">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="demand_ai_reject_proposal">
              <?= demand_ai_content_command_fields('demand_ai_reject_proposal', $entityType, $entityId) ?>
              <input type="hidden" name="entity_type" value="<?= e($entityType) ?>">
              <input type="hidden" name="entity_id" value="<?= e($entityId) ?>">
              <input type="hidden" name="ai_preview_token" value="<?= e((string) ($latestPreview['token'] ?? '')) ?>">
              <button class="btn secondary" type="submit">Отклонить</button>
            </form>
          </div>
        </section>
      <?php endif; ?>
    </article>
    <?php
}

function demand_admin_next_action(array $stats, array $clusters, array $plans, array $drafts, string $scopeFilter): array
{
    if ((int) ($stats['keywords'] ?? 0) === 0) {
        return [
            'title' => 'Добавьте первые фразы спроса',
            'text' => 'Начните с ручной фразы или CSV/JSON. Это безопасно: страницы не публикуются.',
            'button' => 'Загрузить фразы',
            'href' => demand_admin_scope_filter_url('import', $scopeFilter),
            'tone' => 'safe',
        ];
    }

    if (!$clusters) {
        return [
            'title' => 'Постройте карту спроса',
            'text' => 'Система сгруппирует похожие запросы и покажет, какие направления стоит готовить первыми.',
            'button' => 'Перейти к карте спроса',
            'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter),
            'tone' => 'safe',
        ];
    }

    if ($plans && (int) ($stats['drafts'] ?? 0) === 0) {
        return [
            'title' => 'Создайте первый черновик',
            'text' => 'Откройте план страниц и выберите безопасный пункт, где есть спрос и реальные авто.',
            'button' => 'Открыть план страниц',
            'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter) . '#seo-launch-plan',
            'tone' => 'safe',
        ];
    }

    foreach ($drafts as $draft) {
        $readiness = (string) ($draft['readinessStatus'] ?? 'not_checked');
        if (in_array($readiness, ['not_checked', 'needs_fixes', 'blocked'], true)) {
            return [
                'title' => 'Проверьте готовность черновиков',
                'text' => 'Проверка покажет, что уже готово, что нужно дополнить и что блокирует публикацию для просмотра.',
                'button' => 'Открыть черновики',
                'href' => demand_admin_scope_filter_url('drafts', $scopeFilter),
                'tone' => $readiness === 'blocked' ? 'warning' : 'safe',
            ];
        }
    }

    foreach ($drafts as $draft) {
        $status = (string) ($draft['publishStatus'] ?? 'draft');
        if (in_array($status, ['draft', 'needs_review', 'approved_for_public_preview', 'approved_for_future_publication'], true)) {
            return [
                'title' => 'Опубликуйте страницу для просмотра',
                'text' => 'Страница станет доступна по ссылке, но останется закрытой от поисковиков и не попадёт в карту сайта.',
                'button' => 'Открыть черновики',
                'href' => demand_admin_scope_filter_url('drafts', $scopeFilter),
                'tone' => 'review',
            ];
        }
        if ($status === 'published_noindex') {
            return [
                'title' => 'Проверьте страницу глазами',
                'text' => 'Страница уже доступна для просмотра и закрыта от поиска. Проверьте текст, авто и условия перед открытием для Яндекса и Google.',
                'button' => 'Открыть черновики',
                'href' => demand_admin_scope_filter_url('drafts', $scopeFilter),
                'tone' => 'review',
            ];
        }
    }

    return [
        'title' => 'Посмотрите советы системы',
        'text' => 'Система подскажет, где создать черновик, где доработать карточку авто, а где страницу лучше не делать.',
        'button' => 'Открыть советы',
        'href' => demand_admin_scope_filter_url('recommendations', $scopeFilter),
        'tone' => 'safe',
    ];
}

function demand_admin_user_mode_for_tab(string $tab): string
{
    if (in_array($tab, ['technical', 'integrations', 'wordstat_help', 'settings'], true)) {
        return 'technical';
    }
    if (in_array($tab, ['materials', 'drafts', 'car_hints', 'recommendations'], true)) {
        return 'materials';
    }

    return 'master';
}

function demand_admin_direction_status_label(string $status): string
{
    return match ($status) {
        'not_started' => 'Не начато',
        'in_progress' => 'В работе',
        'prepared' => 'Подготовлено',
        'needs_decision' => 'Нужно решение',
        'postponed' => 'Отложено',
        'not_relevant' => 'Не делать',
        'stale' => 'Требует актуализации',
        'ready_for_manual_publish_review' => 'Готово к ручной проверке',
        default => demand_admin_ui_label($status),
    };
}

function demand_admin_direction_priority_label(string $priority): string
{
    return match ($priority) {
        'high' => 'Высокий',
        'medium' => 'Средний',
        'low' => 'Низкий',
        'no_go' => 'Не делать',
        default => demand_admin_ui_label($priority),
    };
}

function demand_admin_direction_wordstat_status_label(string $status): string
{
    return match ($status) {
        'dry_run_ready' => 'проверка без изменения данных готова',
        'live_result_ready' => 'есть результат Wordstat',
        'dry_run_stale' => 'данные устарели',
        'not_checked' => 'Wordstat не проверялся',
        default => demand_admin_ui_label($status !== '' ? $status : 'not_checked'),
    };
}

function demand_admin_confirmation_level_label(string $level): string
{
    return match ($level) {
        'grouped' => 'Нужно подтвердить',
        'start_session' => 'Можно запустить',
        'human_decision' => 'Требует решения владельца',
        'special', 'special_confirmation', 'special_confirmation_required' => 'Нужно отдельное подтверждение',
        'none', '' => 'Информационно',
        default => demand_admin_ui_label($level),
    };
}

function demand_admin_decision_type_label(string $type): string
{
    return match ($type) {
        'direction_start_confirm' => 'Запуск AI-сессии',
        'direction_budget_warning' => 'Бюджет AI',
        'direction_neighbor_found' => 'Соседние направления',
        'direction_draft_batch_confirm' => 'Черновики',
        'direction_internal_links_apply' => 'Внутренние ссылки',
        'direction_wordstat_dry_run_confirm' => 'Проверка Wordstat без изменения данных',
        'wordstat_dry_run_ready' => 'Проверка Wordstat без изменения данных',
        'direction_wordstat_live_special_confirm' => 'Реальные данные Wordstat',
        'direction_refresh_due' => 'Актуализация',
        'direction_business_risk_review' => 'Бизнес-риск',
        default => demand_admin_ui_label($type),
    };
}

function demand_admin_simple_ai_workspace_defaults(): array
{
    return [
        'workspaceMode' => 'simple',
        'activeAiTask' => '',
        'activeEntityType' => '',
        'activeEntityId' => '',
        'activeDirectionId' => '',
        'activeProposalId' => '',
        'lastResult' => [],
        'pendingDecisions' => [],
        'editableProposal' => [],
        'nextSafeAction' => [],
        'returnAnchor' => 'simple-ai-workspace',
        'history' => [],
    ];
}

function demand_admin_set_simple_ai_workspace(array $patch): void
{
    $current = is_array($_SESSION['demand_simple_ai_workspace'] ?? null)
        ? $_SESSION['demand_simple_ai_workspace']
        : demand_admin_simple_ai_workspace_defaults();
    $state = array_merge(demand_admin_simple_ai_workspace_defaults(), $current, $patch, [
        'workspaceMode' => 'simple',
        'returnAnchor' => 'simple-ai-workspace',
    ]);
    $history = array_values(array_filter((array) ($state['history'] ?? []), 'is_array'));
    if (!empty($patch['lastResult']) && is_array($patch['lastResult'])) {
        array_unshift($history, [
            'title' => (string) ($patch['lastResult']['title'] ?? $patch['lastResult']['type'] ?? 'AI-действие'),
            'text' => (string) ($patch['lastResult']['summary'] ?? $patch['lastResult']['message'] ?? ''),
            'createdAt' => now_iso(),
        ]);
    }
    $state['history'] = array_slice($history, 0, 6);
    $_SESSION['demand_simple_ai_workspace'] = $state;
}

function demand_admin_simple_ai_return_anchor(): string
{
    $anchor = preg_replace('/[^A-Za-z0-9_-]+/', '', (string) ($_POST['return_anchor'] ?? ''));

    return $anchor === 'simple-ai-workspace' ? 'simple-ai-workspace' : '';
}

function demand_admin_simple_ai_return_url(string $fallbackTab, string $scopeFilter, array $params = [], string $fallbackAnchor = ''): string
{
    $anchor = demand_admin_simple_ai_return_anchor();
    if ($anchor !== '') {
        return demand_admin_scope_filter_url('start', $scopeFilter) . '#' . $anchor;
    }

    $url = demand_admin_scope_filter_url($fallbackTab, $scopeFilter, $params);
    return $fallbackAnchor !== '' ? $url . '#' . ltrim($fallbackAnchor, '#') : $url;
}

function demand_admin_simple_ai_workspace_state(array $workspaceState = []): array
{
    $state = is_array($_SESSION['demand_simple_ai_workspace'] ?? null)
        ? $_SESSION['demand_simple_ai_workspace']
        : [];
    $state = array_merge(demand_admin_simple_ai_workspace_defaults(), $state);
    $state['pendingDecisions'] = array_values(array_filter((array) ($workspaceState['decisionQueue'] ?? []), 'is_array'));
    $state['nextSafeAction'] = is_array($workspaceState['primaryNextAction'] ?? null) ? (array) $workspaceState['primaryNextAction'] : [];

    if (is_array($_SESSION['demand_wordstat_latest_dry_run_snapshot'] ?? null)) {
        $snapshot = (array) $_SESSION['demand_wordstat_latest_dry_run_snapshot'];
        if ((string) ($snapshot['directionId'] ?? '') !== '') {
            $state['activeAiTask'] = 'wordstat_dry_run';
            $state['activeDirectionId'] = (string) ($snapshot['directionId'] ?? '');
            $state['lastResult'] = [
                'type' => 'wordstat_dry_run',
                'title' => 'Проверка Wordstat без изменения данных готова',
                'summary' => 'Live не запускался. Данные спроса, публикация, индексация, sitemap, robots и бизнес-данные не менялись.',
                'plannedRequests' => (int) ($snapshot['plannedRequests'] ?? $snapshot['estimatedRequests'] ?? 0),
                'estimatedCostRub' => (float) ($snapshot['estimatedCostRub'] ?? 0.0),
                'directionTitle' => (string) ($snapshot['directionTitle'] ?? ''),
            ];
        }
    }

    if (is_array($_SESSION['demand_ai_copy_latest'] ?? null)) {
        $copy = (array) $_SESSION['demand_ai_copy_latest'];
        $state['activeAiTask'] = (string) ($copy['task'] ?? 'draft_text');
        $state['activeEntityType'] = 'draft';
        $state['activeEntityId'] = (string) ($copy['entityId'] ?? '');
        $state['activeProposalId'] = (string) ($copy['token'] ?? '');
        $state['editableProposal'] = [
            'type' => 'draft_text',
            'token' => (string) ($copy['token'] ?? ''),
            'draftId' => (string) ($copy['entityId'] ?? ''),
            'proposal' => (array) ($copy['proposal'] ?? []),
            'diff' => is_array($copy['diff'] ?? null) ? (array) $copy['diff'] : [],
            'response' => is_array($copy['response'] ?? null) ? (array) $copy['response'] : [],
        ];
    } elseif (is_array($_SESSION['demand_ai_api_latest'] ?? null)) {
        $api = (array) $_SESSION['demand_ai_api_latest'];
        $state['activeAiTask'] = (string) ($api['task'] ?? '');
        $state['activeEntityType'] = (string) ($api['entityType'] ?? '');
        $state['activeEntityId'] = (string) ($api['entityId'] ?? '');
        $state['activeProposalId'] = (string) ($api['token'] ?? '');
        $state['editableProposal'] = [
            'type' => (string) ($api['entityType'] ?? ''),
            'token' => (string) ($api['token'] ?? ''),
            'proposal' => (array) ($api['proposal'] ?? []),
            'diff' => is_array($api['diff'] ?? null) ? (array) $api['diff'] : [],
            'response' => is_array($api['response'] ?? null) ? (array) $api['response'] : [],
        ];
    } elseif (is_array($_SESSION['demand_internal_links_latest'] ?? null)) {
        $links = (array) $_SESSION['demand_internal_links_latest'];
        $state['activeAiTask'] = 'internal_links';
        $state['activeEntityType'] = 'draft';
        $state['activeEntityId'] = (string) ($links['draftId'] ?? '');
        $state['editableProposal'] = [
            'type' => 'internal_links',
            'token' => (string) ($links['token'] ?? ''),
            'draftId' => (string) ($links['draftId'] ?? ''),
            'suggestions' => (array) ($links['suggestions'] ?? []),
        ];
    }

    return $state;
}

function demand_admin_simple_workspace_primary_draft(array $drafts): ?array
{
    foreach ($drafts as $draft) {
        if (!is_array($draft)) {
            continue;
        }
        if (in_array((string) ($draft['readinessStatus'] ?? ''), ['not_checked', 'needs_fixes', 'blocked'], true)) {
            return $draft;
        }
    }
    foreach ($drafts as $draft) {
        if (is_array($draft)) {
            return $draft;
        }
    }

    return null;
}

function demand_admin_simple_workspace_primary_hint(array $hints): ?array
{
    foreach ($hints as $hint) {
        if (is_array($hint) && (string) ($hint['id'] ?? '') !== '') {
            return $hint;
        }
    }

    return null;
}

function demand_admin_workspace_copy_posted_proposal(array $payload): array
{
    $proposal = [];
    foreach (['title', 'h1', 'metaDescription', 'intro', 'adminNote'] as $field) {
        if (array_key_exists($field, $payload)) {
            $proposal[$field] = demand_clean_string($payload[$field], $field === 'intro' ? 6000 : 1000);
        }
    }
    foreach (['contentBlocks', 'faq'] as $field) {
        if (!array_key_exists($field, $payload)) {
            continue;
        }
        $raw = trim((string) $payload[$field]);
        if ($raw === '') {
            continue;
        }
        $decoded = json_decode($raw, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
            throw new RuntimeException('Не удалось разобрать поле ' . $field . ': ' . json_last_error_msg());
        }
        $proposal[$field] = $decoded;
    }

    return $proposal;
}

function demand_admin_material_groups(array $drafts, array $briefs, array $hints, array $plans, array $keywords, string $scopeFilter): array
{
    $aiSeedCount = 0;
    $postponedCount = 0;
    foreach ($keywords as $keyword) {
        if ((string) ($keyword['source'] ?? '') === 'ai_suggested_seed') {
            $aiSeedCount++;
        }
        if (in_array((string) ($keyword['status'] ?? ''), ['excluded', 'not_target', 'archived'], true)
            || !empty($keyword['negativeIntent'])
            || in_array((string) ($keyword['decisionHint'] ?? ''), ['ignore_as_irrelevant', 'maybe_use_as_negative_ad_keyword'], true)
        ) {
            $postponedCount++;
        }
    }

    return [
        [
            'title' => 'Готовые черновики',
            'text' => 'Страницы, которые AI или карта спроса уже подготовили для проверки.',
            'count' => count($drafts),
            'href' => demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => 'all']) . '#demand-drafts-worklist',
            'button' => 'Открыть черновики',
            'primary' => true,
        ],
        [
            'title' => 'ТЗ для страниц',
            'text' => 'Что должна объяснить будущая страница, какие факты нужны и что нельзя обещать.',
            'count' => count($briefs),
            'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter) . '#demand-content-briefs',
            'button' => 'Открыть ТЗ',
        ],
        [
            'title' => 'FAQ',
            'text' => 'Вопросы про залог, документы, подачу, цену и условия вместо лишних страниц.',
            'count' => count(array_filter($briefs, static fn(array $brief): bool => !empty($brief['faqQuestions']) || !empty($brief['recommendedFaq']))),
            'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter) . '#demand-content-briefs',
            'button' => 'Открыть FAQ',
        ],
        [
            'title' => 'Подсказки для авто',
            'text' => 'Идеи для карточек автомобилей. Сами авто AI не меняет.',
            'count' => count($hints),
            'href' => demand_admin_scope_filter_url('car_hints', $scopeFilter),
            'button' => 'Открыть подсказки',
        ],
        [
            'title' => 'План страниц',
            'text' => 'Приоритеты: что готовить первым, где нужен FAQ, а что лучше не делать.',
            'count' => count($plans),
            'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter) . '#seo-launch-plan',
            'button' => 'Открыть план',
        ],
        [
            'title' => 'AI seed-фразы',
            'text' => 'Идеи AI для проверки через Wordstat. Это не подтвержденная частотность.',
            'count' => $aiSeedCount,
            'href' => demand_admin_scope_filter_url('keywords', $scopeFilter),
            'button' => 'Открыть фразы',
        ],
        [
            'title' => 'Отложенные / не делать',
            'text' => 'Такси, трансфер, покупка, ремонт, без прав и другие нецелевые запросы.',
            'count' => $postponedCount,
            'href' => demand_admin_scope_filter_url('keywords', $scopeFilter),
            'button' => 'Посмотреть',
        ],
    ];
}

function demand_admin_workflow_counts(?array $workflow): array
{
    $workflow = is_array($workflow) ? $workflow : [];

    return [
        'keywords' => count((array) ($workflow['createdKeywordIds'] ?? [])),
        'briefs' => count((array) ($workflow['createdBriefIds'] ?? [])),
        'drafts' => count((array) ($workflow['createdDraftIds'] ?? [])),
        'hints' => count((array) ($workflow['createdHintIds'] ?? [])),
        'excluded' => count((array) ($workflow['excludedKeywordPhrases'] ?? [])),
    ];
}

function demand_admin_map_plan_by_cluster(array $plans): array
{
    $byCluster = [];
    foreach ($plans as $plan) {
        $clusterId = (string) ($plan['clusterId'] ?? '');
        if ($clusterId !== '' && !isset($byCluster[$clusterId])) {
            $byCluster[$clusterId] = $plan;
        }
    }

    return $byCluster;
}

function demand_admin_draft_cluster_ids(array $drafts): array
{
    $ids = [];
    foreach ($drafts as $draft) {
        $clusterId = (string) ($draft['linkedClusterId'] ?? '');
        if ($clusterId !== '') {
            $ids[$clusterId] = true;
        }
    }

    return $ids;
}

function demand_admin_map_group_key(array $cluster, ?array $plan, array $draftClusterIds): string
{
    $clusterId = (string) ($cluster['id'] ?? '');
    if ($clusterId !== '' && isset($draftClusterIds[$clusterId])) {
        return 'drafts';
    }

    $decision = (string) (($plan['recommendedDecision'] ?? null) ?: ($cluster['recommendedDecision'] ?? ''));
    $priority = (string) (($plan['priority'] ?? null) ?: ($cluster['priority'] ?? ''));
    $type = (string) (($plan['planType'] ?? null) ?: ($cluster['clusterType'] ?? ''));
    $risks = array_values(array_map('strval', (array) ($cluster['riskFlags'] ?? ($plan['riskFlags'] ?? []))));
    $riskText = mb_strtolower(implode(' ', array_merge($risks, [(string) ($cluster['name'] ?? ''), (string) ($cluster['primaryPhrase'] ?? '')])), 'UTF-8');

    if ($priority === 'blocked'
        || in_array($decision, ['do_not_create_page', 'block_false_promise_page', 'ignore_as_irrelevant', 'maybe_use_as_negative_ad_keyword'], true)
        || array_intersect($risks, ['not_relevant_for_car_rental', 'unsupported_legal_request'])
        || str_contains($riskText, 'такси')
        || str_contains($riskText, 'трансфер')
        || str_contains($riskText, 'без прав')
    ) {
        return 'no';
    }
    if (in_array($decision, ['needs_business_decision', 'need_human_review', 'manual_review_before_draft'], true)
        || in_array($priority, ['needs_business_decision'], true)
        || array_intersect($risks, ['needs_business_decision', 'region_not_confirmed', 'unknown_region', 'airport_delivery_not_confirmed', 'driver_service_not_confirmed'])
    ) {
        return 'decision';
    }
    if ($type === 'condition' || in_array($decision, ['create_faq', 'add_faq', 'create_condition_explanation', 'add_condition_block'], true)
        || array_intersect($risks, ['possible_false_promise', 'condition_not_supported', 'price_claim_risk'])
    ) {
        return 'faq';
    }

    return 'first';
}

function demand_admin_map_group_label(string $key): string
{
    return [
        'first' => 'Готовить первыми',
        'decision' => 'Нужно решение',
        'faq' => 'FAQ/условия вместо страницы',
        'no' => 'Не делать',
        'drafts' => 'Уже есть черновики',
    ][$key] ?? 'Разобрать';
}

function demand_admin_map_primary_action(array $cluster, ?array $plan, string $groupKey, string $scopeFilter, array $briefsByPlanId): array
{
    $planId = (string) ($plan['id'] ?? '');
    if ($groupKey === 'drafts') {
        return ['label' => 'Открыть черновик', 'href' => demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => 'all']) . '#demand-drafts-worklist'];
    }
    if ($groupKey === 'decision') {
        return ['label' => 'Проверить условие', 'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter, ['cluster_id' => (string) ($cluster['id'] ?? '')])];
    }
    if ($groupKey === 'faq') {
        if ($planId !== '' && isset($briefsByPlanId[$planId])) {
            return ['label' => 'Открыть ТЗ', 'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter, ['brief_id' => (string) ($briefsByPlanId[$planId]['id'] ?? '')]) . '#demand-content-briefs'];
        }
        return ['label' => 'Создать ТЗ', 'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter, ['cluster_id' => (string) ($cluster['id'] ?? '')]) . '#seo-launch-plan'];
    }
    if ($groupKey === 'no') {
        return ['label' => 'Не делать', 'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter, ['map_filter' => 'blocked']) . '#demand-map-clusters'];
    }

    return ['label' => 'Создать черновик', 'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter, ['cluster_id' => (string) ($cluster['id'] ?? '')]) . '#seo-launch-plan'];
}

function demand_admin_map_card_rows(array $clusters, array $plansByCluster, array $draftClusterIds, array $briefsByPlanId, string $scopeFilter): array
{
    $groups = ['first' => [], 'decision' => [], 'faq' => [], 'no' => [], 'drafts' => []];
    foreach ($clusters as $cluster) {
        $clusterId = (string) ($cluster['id'] ?? '');
        $plan = $clusterId !== '' ? ($plansByCluster[$clusterId] ?? null) : null;
        $groupKey = demand_admin_map_group_key($cluster, is_array($plan) ? $plan : null, $draftClusterIds);
        $action = demand_admin_map_primary_action($cluster, is_array($plan) ? $plan : null, $groupKey, $scopeFilter, $briefsByPlanId);
        $groups[$groupKey][] = [
            'cluster' => $cluster,
            'plan' => $plan,
            'action' => $action,
        ];
    }

    return $groups;
}

function demand_admin_recommendation_next_step(array $recommendation, string $scopeFilter): array
{
    $type = (string) ($recommendation['recommendationType'] ?? '');
    $status = (string) ($recommendation['actionStatus'] ?? 'new');
    $isClosed = in_array($status, ['done', 'rejected', 'archived'], true);

    if ($isClosed) {
        return [
            'kind' => 'link',
            'label' => 'Посмотреть итог',
            'href' => demand_admin_scope_filter_url('recommendations', $scopeFilter),
            'hint' => 'Совет уже закрыт. При необходимости верните его в работу через статус.',
            'tone' => 'secondary',
        ];
    }

    if (in_array($type, [
        'create_landing_page_draft',
        'create_city_landing_draft',
        'create_class_landing_draft',
        'create_condition_explanation',
    ], true)) {
        return [
            'kind' => has_permission('demand.drafts.create') ? 'create_draft' : 'link',
            'label' => has_permission('demand.drafts.create') ? 'Создать черновик' : 'Открыть черновики',
            'href' => demand_admin_scope_filter_url('drafts', $scopeFilter),
            'hint' => 'Следующий безопасный шаг: создать черновик. Он не публикуется и закрыт от поиска.',
            'tone' => 'primary',
        ];
    }

    if (in_array($type, ['update_car_cards', 'create_card_optimization_hint'], true)) {
        return [
            'kind' => 'link',
            'label' => 'Открыть подсказки для авто',
            'href' => demand_admin_scope_filter_url('car_hints', $scopeFilter),
            'hint' => 'Перейдите к подсказкам: там видно, что добавить в карточки машин.',
            'tone' => 'primary',
        ];
    }

    if (in_array($type, ['add_faq', 'add_internal_links', 'update_existing_page', 'update_title_description', 'improve_landing_conversion', 'improve_answer_blocks', 'check_indexing_status', 'review_low_conversion_page'], true)) {
        return [
            'kind' => 'link',
            'label' => 'Открыть черновики',
            'href' => demand_admin_scope_filter_url('drafts', $scopeFilter),
            'hint' => 'Следующий шаг обычно делается в черновике: добавить FAQ, ссылки или поправить текст.',
            'tone' => 'primary',
        ];
    }

    if (in_array($type, ['create_content_brief', 'create_launch_plan_item'], true)) {
        return [
            'kind' => 'link',
            'label' => 'Открыть план страниц',
            'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter) . '#seo-launch-plan',
            'hint' => 'В плане страниц можно создать ТЗ или черновик и не трогать публикацию.',
            'tone' => 'primary',
        ];
    }

    if (in_array($type, ['connect_external_source'], true)) {
        return [
            'kind' => 'link',
            'label' => 'Открыть Wordstat',
            'href' => demand_admin_scope_filter_url('wordstat_help', $scopeFilter),
            'hint' => 'Настройка источника данных помогает расширить спрос, но сама ничего не публикует.',
            'tone' => 'primary',
        ];
    }

    if (in_array($type, ['do_not_publish', 'block_false_promise_page', 'postpone_until_supply_exists', 'ignore_as_irrelevant', 'do_not_create_page', 'maybe_use_as_negative_ad_keyword'], true)) {
        return [
            'kind' => 'status',
            'status' => 'done',
            'label' => 'Принять: не делать',
            'hint' => 'Сохраняет решение по этому совету. Страницы, поиск и карта сайта не меняются.',
            'tone' => 'warning',
        ];
    }

    if (in_array($type, ['need_human_review', 'needs_business_decision'], true)) {
        return [
            'kind' => 'status',
            'status' => 'in_review',
            'label' => 'Разобрать вручную',
            'hint' => 'Помечает совет как требующий ручной проверки. Никаких публикаций не запускает.',
            'tone' => 'secondary',
        ];
    }

    return [
        'kind' => 'status',
        'status' => 'in_review',
        'label' => 'Взять в работу',
        'hint' => 'Помечает совет как выбранный для ручной проверки.',
        'tone' => 'secondary',
    ];
}

function demand_wordstat_return_tab(): string
{
    $tab = (string) ($_POST['tab'] ?? 'integrations');
    return $tab === 'wordstat_help' ? 'wordstat_help' : 'integrations';
}

function demand_wordstat_setup_state_class(string $state): string
{
    return match ($state) {
        'done' => 'is-done',
        'current' => 'is-current',
        'blocked' => 'is-blocked',
        default => 'is-pending',
    };
}

function demand_help_popover(string $title, string $body): string
{
    static $index = 0;
    $index++;
    $id = 'help-popover-' . $index;

    return '<span class="help-popover" data-help-popover><button type="button" class="help-popover-trigger" data-help-trigger aria-label="' . e($title) . '" aria-expanded="false" aria-describedby="' . e($id) . '">?</button><span class="help-popover-body" id="' . e($id) . '" role="tooltip" data-help-panel hidden><strong>' . e($title) . '</strong><span>' . e($body) . '</span></span></span>';
}

function demand_wordstat_region_normalized_name(array $region): string
{
    $name = (string) ($region['normalizedName'] ?? '');
    if ($name === '' && function_exists('demand_normalize_phrase')) {
        $name = demand_normalize_phrase((string) ($region['name'] ?? ''));
    }

    return $name;
}

function demand_wordstat_region_normalized_path(array $region): string
{
    $path = $region['path'] ?? [];
    if (!is_array($path)) {
        $path = $path !== '' ? [(string) $path] : [];
    }
    $pathText = trim(implode(' ', array_map(static fn($value): string => (string) $value, $path)));
    if ($pathText === '') {
        return '';
    }

    return function_exists('demand_normalize_phrase') ? demand_normalize_phrase($pathText) : strtolower($pathText);
}

function demand_wordstat_region_path_label(array $region): string
{
    $path = $region['path'] ?? [];
    if (!is_array($path)) {
        $path = $path !== '' ? [(string) $path] : [];
    }
    $path = array_values(array_filter(array_map(static fn($value): string => trim((string) $value), $path)));

    return $path ? implode(' / ', $path) : '';
}

function demand_wordstat_region_chip(array $region): string
{
    $id = trim((string) ($region['id'] ?? ''));
    $name = trim((string) ($region['name'] ?? ''));
    $label = ($name !== '' ? $name : 'Region') . ($id !== '' ? ' #' . $id : '');
    $title = demand_wordstat_region_path_label($region);
    $searchText = trim($label . ' ' . $title);

    if ($id === '') {
        return '<span' . ($title !== '' ? ' title="' . e($title) . '"' : '') . '>' . e($label) . '</span>';
    }

    $ariaLabel = 'Добавить регион ' . $label . ' в поля регионов';

    return '<button type="button" class="wordstat-region-chip" data-wordstat-region-id="' . e($id) . '" data-wordstat-region-name="' . e($name) . '" data-wordstat-region-search="' . e($searchText) . '" aria-label="' . e($ariaLabel) . '"' . ($title !== '' ? ' title="' . e($title) . '"' : '') . '>' . e($label) . '</button>';
}

function demand_wordstat_join_values($values, string $empty = '—'): string
{
    if (!is_array($values)) {
        $values = preg_split('/[\s,;]+/u', (string) $values) ?: [];
    }
    $values = array_values(array_filter(array_map(static fn($value): string => trim((string) $value), $values)));

    return $values ? implode(', ', $values) : $empty;
}

function demand_wordstat_run_count($values): int
{
    if (!is_array($values)) {
        $values = preg_split('/[\s,;]+/u', (string) $values) ?: [];
    }

    return count(array_values(array_filter(array_map(static fn($value): string => trim((string) $value), $values))));
}

function demand_wordstat_can_view_runs(): bool
{
    foreach ([
        'demand.wordstat.view',
        'demand.wordstat.test',
        'demand.wordstat.sync',
        'demand.wordstat.manage',
        'demand.wordstat.live',
        'demand.wordstat.logs.view',
        'demand.wordstat.costs.view',
    ] as $permission) {
        if (has_permission($permission)) {
            return true;
        }
    }

    return false;
}

function demand_wordstat_latest_dry_run(array $runs): ?array
{
    foreach ($runs as $run) {
        if (!is_array($run)) {
            continue;
        }
        if ((string) ($run['source'] ?? '') === 'wordstat' && !empty($run['dryRun'])) {
            return $run;
        }
    }

    return null;
}

function demand_wordstat_session_dry_run(string $scopeFilter = ''): ?array
{
    $run = $_SESSION['demand_wordstat_latest_dry_run_snapshot'] ?? null;
    if (!is_array($run)
        || (string) ($run['source'] ?? '') !== 'wordstat'
        || empty($run['dryRun'])
    ) {
        return null;
    }

    $scopes = demand_current_scope_filter($scopeFilter);
    if (!$scopes) {
        return null;
    }
    $scopes = array_values(array_unique(array_map(static fn($scopeId): string => demand_normalize_scope_id((string) $scopeId), $scopes)));
    if ($scopeFilter === 'all' && current_user_is_platform_admin() && !in_array('rent_rk', $scopes, true)) {
        array_unshift($scopes, 'rent_rk');
    }

    return in_array(demand_normalize_scope_id((string) ($run['scope_id'] ?? 'rent_rk')), $scopes, true) ? $run : null;
}

function demand_wordstat_visible_sync_runs(string $scopeFilter = ''): array
{
    if (!demand_wordstat_can_view_runs()) {
        return [];
    }
    if (!function_exists('demand_integrations_read_sync_runs')) {
        return [];
    }

    $scopes = demand_current_scope_filter($scopeFilter);
    if (!$scopes) {
        return [];
    }
    $scopes = array_values(array_unique(array_map(static fn($scopeId): string => demand_normalize_scope_id((string) $scopeId), $scopes)));
    if ($scopeFilter === 'all' && current_user_is_platform_admin() && !in_array('rent_rk', $scopes, true)) {
        array_unshift($scopes, 'rent_rk');
    }

    return array_values(array_filter(
        demand_integrations_read_sync_runs()['items'],
        static function ($item) use ($scopes): bool {
            return is_array($item)
                && (string) ($item['source'] ?? '') === 'wordstat'
                && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopes, true);
        }
    ));
}

function demand_wordstat_sync_run_by_id(string $runId, string $scopeFilter = ''): ?array
{
    $runId = trim($runId);
    if ($runId === '') {
        return null;
    }

    foreach (demand_wordstat_visible_sync_runs($scopeFilter) as $run) {
        if (is_array($run) && (string) ($run['id'] ?? '') === $runId) {
            return $run;
        }
    }

    return null;
}

function demand_wordstat_latest_dry_run_for_admin(string $scopeFilter = ''): ?array
{
    if (!demand_wordstat_can_view_runs()) {
        return null;
    }
    if (!function_exists('demand_integrations_read_sync_runs')) {
        return null;
    }

    $scopes = demand_current_scope_filter($scopeFilter);
    if (!$scopes) {
        return null;
    }
    $scopes = array_values(array_unique(array_map(static fn($scopeId): string => demand_normalize_scope_id((string) $scopeId), $scopes)));
    if ($scopeFilter === 'all' && current_user_is_platform_admin() && !in_array('rent_rk', $scopes, true)) {
        array_unshift($scopes, 'rent_rk');
    }

    $runs = array_values(array_filter(
        (array) (demand_integrations_read_sync_runs()['items'] ?? []),
        static function ($item) use ($scopes): bool {
            return is_array($item)
                && (string) ($item['source'] ?? '') === 'wordstat'
                && !empty($item['dryRun'])
                && in_array(demand_normalize_scope_id((string) ($item['scope_id'] ?? 'rent_rk')), $scopes, true);
        }
    ));

    return demand_wordstat_latest_dry_run($runs);
}

function demand_wordstat_region_matches_target(array $region, array $target): bool
{
    $id = (string) ($region['id'] ?? '');
    $targetId = (string) ($target['id'] ?? '');
    if ($targetId !== '' && $id === $targetId) {
        return true;
    }

    $name = demand_wordstat_region_normalized_name($region);
    if ($name === '') {
        return false;
    }

    $names = isset($target['names']) && is_array($target['names']) ? $target['names'] : [];
    $matchedName = false;
    foreach ($names as $needle) {
        $needle = function_exists('demand_normalize_phrase') ? demand_normalize_phrase((string) $needle) : strtolower((string) $needle);
        if ($needle !== '' && $name === $needle) {
            $matchedName = true;
            break;
        }
    }
    if (!$matchedName) {
        return false;
    }

    $pathNeedles = isset($target['pathNeedles']) && is_array($target['pathNeedles']) ? $target['pathNeedles'] : [];
    if (!$pathNeedles) {
        return true;
    }

    $path = demand_wordstat_region_normalized_path($region);
    foreach ($pathNeedles as $pathNeedle) {
        $pathNeedle = function_exists('demand_normalize_phrase') ? demand_normalize_phrase((string) $pathNeedle) : strtolower((string) $pathNeedle);
        if ($pathNeedle !== '' && str_contains($path, $pathNeedle)) {
            return true;
        }
    }

    return false;
}

function demand_wordstat_key_regions(array $regions): array
{
    $targets = [
        ['id' => '977', 'names' => ['республика крым', 'крым']],
        ['id' => '11470', 'names' => ['ялта'], 'pathNeedles' => ['крым']],
        ['id' => '146', 'names' => ['симферополь'], 'pathNeedles' => ['крым']],
        ['id' => '959', 'names' => ['севастополь']],
        ['id' => '11471', 'names' => ['алушта'], 'pathNeedles' => ['крым']],
        ['id' => '11463', 'names' => ['евпатория'], 'pathNeedles' => ['крым']],
        ['id' => '11469', 'names' => ['феодосия'], 'pathNeedles' => ['крым']],
        ['id' => '11464', 'names' => ['керчь'], 'pathNeedles' => ['крым']],
        ['id' => '20556', 'names' => ['саки'], 'pathNeedles' => ['крым']],
    ];
    $result = [];
    $seen = [];

    foreach ($targets as $target) {
        foreach ($regions as $region) {
            if (!is_array($region) || !demand_wordstat_region_matches_target($region, $target)) {
                continue;
            }
            $id = (string) ($region['id'] ?? '');
            if ($id === '' || isset($seen[$id])) {
                continue;
            }
            $seen[$id] = true;
            $result[] = $region;
            break;
        }
    }

    return $result;
}

function demand_wordstat_crimea_regions(array $regions): array
{
    $byId = [];
    foreach ($regions as $region) {
        if (!is_array($region)) {
            continue;
        }
        $id = (string) ($region['id'] ?? '');
        if ($id !== '') {
            $byId[$id] = $region;
        }
    }

    $rootIds = ['977' => true, '959' => true];
    $excludedIds = ['99281' => true, '10995' => true, '239' => true];
    $result = [];
    $seen = [];

    $hasCrimeaAncestor = static function (array $region) use (&$byId, &$rootIds): bool {
        $parentId = (string) ($region['parentId'] ?? '');
        $guard = 0;
        while ($parentId !== '' && isset($byId[$parentId]) && $guard < 12) {
            if (isset($rootIds[$parentId])) {
                return true;
            }
            $parent = $byId[$parentId];
            $parentId = (string) ($parent['parentId'] ?? '');
            $guard++;
        }

        return false;
    };

    foreach ($regions as $region) {
        if (!is_array($region)) {
            continue;
        }

        $id = (string) ($region['id'] ?? '');
        if ($id === '' || isset($seen[$id]) || isset($excludedIds[$id])) {
            continue;
        }

        $name = demand_wordstat_region_normalized_name($region);
        $path = demand_wordstat_region_normalized_path($region);
        $isCrimeanDistrict = $name === 'крымский район' || str_contains($path, 'крымский район');
        $isKrymsk = $name === 'крымск' || str_contains($path, 'краснодарский край');
        if ($isCrimeanDistrict || $isKrymsk) {
            continue;
        }

        $matches = isset($rootIds[$id])
            || str_contains($path, 'республика крым')
            || preg_match('/(^| )крым( |$)/u', $path) === 1
            || $hasCrimeaAncestor($region);

        if (!$matches) {
            continue;
        }

        $seen[$id] = true;
        $result[] = $region;
    }

    usort($result, static function (array $left, array $right): int {
        $priority = ['977' => 0, '959' => 1, '11470' => 2, '146' => 3];
        $leftId = (string) ($left['id'] ?? '');
        $rightId = (string) ($right['id'] ?? '');
        $leftPriority = $priority[$leftId] ?? 100;
        $rightPriority = $priority[$rightId] ?? 100;
        if ($leftPriority !== $rightPriority) {
            return $leftPriority <=> $rightPriority;
        }

        return strnatcasecmp((string) ($left['name'] ?? ''), (string) ($right['name'] ?? ''));
    });

    return $result;
}

function demand_wordstat_auth_status_label(string $status): string
{
    return match ($status) {
        'test_success' => 'Проверка прошла',
        'configured' => 'Доступы сохранены, проверка ещё не пройдена',
        'test_failed' => 'Проверка не прошла',
        'error' => 'Ошибка подключения',
        'not_required' => 'Доступ не требуется',
        default => 'Доступы не настроены',
    };
}

function demand_wordstat_connection_problem(array $status): array
{
    $authStatus = trim((string) ($status['authStatus'] ?? 'not_configured'));
    $rawError = trim((string) ($status['lastError'] ?? ''));
    $code = trim((string) ($status['lastErrorCode'] ?? ''));
    $advice = trim((string) ($status['lastErrorAdvice'] ?? ''));
    $technical = trim((string) ($status['lastErrorTechnical'] ?? ''));
    $message = $rawError;
    $hasProblem = $rawError !== '' || $code !== '' || in_array($authStatus, ['test_failed', 'error'], true);

    if ($hasProblem && function_exists('wordstat_connection_error_details')) {
        $detailsInput = trim(($code !== '' ? $code . ' ' : '') . ($rawError !== '' ? $rawError : $authStatus));
        $details = wordstat_connection_error_details($detailsInput);
        if ($code === '') {
            $code = (string) ($details['code'] ?? '');
        }
        if ($advice === '') {
            $advice = (string) ($details['advice'] ?? '');
        }
        if ($technical === '') {
            $technical = (string) ($details['technical'] ?? $rawError);
        }
        $rawLower = strtolower($rawError);
        if ($message === '' || str_contains($rawLower, 'wordstat request failed') || preg_match('/^[a-z0-9_:\- ]+$/i', $rawError)) {
            $message = (string) ($details['message'] ?? $message);
        }
    }

    if ($message === '' && $hasProblem) {
        $message = 'Проверка подключения не прошла.';
    }

    return [
        'hasProblem' => $hasProblem,
        'authStatus' => $authStatus,
        'statusLabel' => demand_wordstat_auth_status_label($authStatus),
        'code' => $code !== '' ? $code : 'connection_failed',
        'message' => $message,
        'advice' => $advice,
        'technical' => $technical,
        'updatedAt' => trim((string) ($status['lastErrorAt'] ?? '')),
    ];
}

function demand_wordstat_recent_run(array $runs, ?bool $dryRun): ?array
{
    foreach ($runs as $run) {
        if (!is_array($run) || (string) ($run['source'] ?? '') !== 'wordstat') {
            continue;
        }
        if ($dryRun !== null && !empty($run['dryRun']) !== $dryRun) {
            continue;
        }
        return $run;
    }

    return null;
}

function demand_wordstat_setup_steps(array $status, array $regionsCache, array $runs): array
{
    $credentialsOk = !empty($status['apiKeyConfigured']) && !empty($status['folderIdConfigured']) && !empty($status['baseUrlConfigured']);
    $authStatus = (string) ($status['authStatus'] ?? 'not_configured');
    $testOk = $authStatus === 'test_success';
    $authReady = in_array($authStatus, ['configured', 'test_success'], true);
    $regionsOk = !empty($regionsCache['regions']);
    $planOk = !empty($status['defaultSeedPhrases']) && !empty($status['defaultRegionIds']) && (int) ($status['perRunRequestLimit'] ?? 0) > 0;
    $dryRun = demand_wordstat_recent_run($runs, true);
    $dryRunOk = is_array($dryRun) && (string) ($dryRun['status'] ?? '') === 'success';
    $liveRun = demand_wordstat_recent_run($runs, false);
    $liveAvailable = $credentialsOk
        && $authReady
        && !empty($status['enabled'])
        && (string) ($status['mode'] ?? '') === 'live_controlled'
        && !empty($status['liveEnabled']);
    $liveOk = $liveAvailable && is_array($liveRun) && (string) ($liveRun['status'] ?? '') === 'success';

    return [
        [
            'number' => 1,
            'state' => $credentialsOk ? 'done' : 'current',
            'title' => 'Доступы',
            'summary' => $credentialsOk ? 'Ключ доступа, ID каталога и адрес API найдены в безопасном месте.' : 'Сначала добавьте ключ доступа и ID каталога.',
        ],
        [
            'number' => 2,
            'state' => $testOk ? 'done' : ($credentialsOk ? 'current' : 'blocked'),
            'title' => 'Проверка',
            'summary' => $testOk ? 'Подключение проверено успешно.' : 'Проверка покажет, что доступы работают.',
        ],
        [
            'number' => 3,
            'state' => $regionsOk ? 'done' : ($credentialsOk ? 'current' : 'blocked'),
            'title' => 'Регионы',
            'summary' => $regionsOk ? 'Справочник регионов загружен.' : 'Загрузите регионы для подсказок и ID.',
        ],
        [
            'number' => 4,
            'state' => $planOk ? 'done' : 'current',
            'title' => 'План',
            'summary' => $planOk ? 'Стартовые фразы, регионы и лимиты заданы.' : 'Задайте стартовые фразы, регионы и лимиты.',
        ],
        [
            'number' => 5,
            'state' => $dryRunOk ? 'done' : ($planOk ? 'current' : 'blocked'),
            'title' => 'Пробная проверка',
            'summary' => $dryRunOk ? 'Последняя пробная проверка записана.' : 'Сделайте безопасный расчёт без изменений.',
        ],
        [
            'number' => 6,
            'state' => $liveOk ? 'done' : ($liveAvailable ? 'current' : 'blocked'),
            'title' => 'Ручная загрузка',
            'summary' => $liveOk ? 'Данные Wordstat уже загружались вручную.' : 'Включается только вручную после проверки и лимитов.',
        ],
    ];
}

$tabs = [
    'start' => 'Мастер спроса',
    'materials' => 'Материалы',
    'technical' => 'Техническое',
    'overview' => 'Обзор',
    'keywords' => 'Что ищут люди',
    'import' => 'Загрузить фразы',
    'recommendations' => 'Советы системы',
    'demand_map' => 'Карта спроса',
    'drafts' => 'Черновики и публикация',
    'car_hints' => 'Подсказки для авто',
    'integrations' => 'Данные и Wordstat',
    'wordstat_help' => 'Wordstat',
    'settings' => 'Настройки и техническое',
];
$tabDescriptions = [
    'start' => 'AI-мастер: задача, прогресс, результат, готовые материалы и следующее действие.',
    'materials' => 'Быстрый доступ к тому, что уже подготовил AI или карта спроса: черновики, ТЗ, FAQ, подсказки и план.',
    'technical' => 'Служебные журналы, настройки, Wordstat, AI API и raw-данные. По умолчанию всё свернуто.',
    'overview' => 'Сводка по фразам, советам, черновикам и следующему действию.',
    'keywords' => 'Фразы, по которым люди ищут аренду авто. По ним система понимает, какие страницы и карточки стоит готовить.',
    'import' => 'Ручное добавление фраз или загрузка файла. Это безопасно: страницы не публикуются.',
    'recommendations' => 'Система подсказывает, что лучше сделать: создать черновик, доработать авто или не делать страницу из-за риска.',
    'demand_map' => 'Карта спроса',
    'drafts' => 'Здесь страницы проходят путь от черновика до публикации: сначала для просмотра, потом вручную для поиска.',
    'car_hints' => 'Что добавить в карточки автомобилей, чтобы они лучше отвечали тому, что ищут клиенты.',
    'integrations' => 'Источники данных, история загрузок и служебная аналитика. Основная настройка Wordstat вынесена отдельно.',
    'wordstat_help' => 'Настройка и загрузка данных из Яндекс Wordstat. Данные помогают понять спрос, но сами ничего не публикуют.',
    'settings' => 'Служебные настройки, логи, лимиты, ошибки и технические данные.',
];
$tabDescriptions['demand_map'] = 'Похожие запросы сгруппированы по смыслу: города, классы авто, условия, маршруты и сезоны.';
$tab = (string) ($_GET['tab'] ?? ($_POST['tab'] ?? 'start'));
if (!isset($tabs[$tab])) {
    $tab = 'start';
}
if ($tab === 'settings'
    && !has_permission('demand.settings.manage')
    && !has_permission('demand.ai_api.settings.manage')
    && !has_permission('demand.ai_api.logs.view')
) {
    $tab = 'start';
}
if ($tab === 'integrations' && !has_permission('demand.integrations.view') && !has_permission('demand.performance.view')) {
    $tab = 'start';
}
if ($tab === 'demand_map' && !has_permission('demand.map.view')) {
    $tab = 'start';
}
if ($tab === 'wordstat_help' && !has_permission('demand.wordstat.view') && !has_permission('demand.wordstat.manage')) {
    $tab = 'start';
}

$allowedScopes = demand_visible_scope_ids_for_current_user();
$requestedScope = (string) ($_GET['scope'] ?? ($_POST['scope'] ?? 'all'));
$scopeFilter = current_user_is_platform_admin() ? ($requestedScope !== '' ? $requestedScope : 'all') : ($allowedScopes[0] ?? 'all');
$scopeIds = demand_current_scope_filter($scopeFilter);
if (!$scopeIds) {
    deny_scope_access();
}

$message = (string) ($_SESSION['demand_flash_message'] ?? '');
$messageType = (string) ($_SESSION['demand_flash_type'] ?? 'success');
$refreshCarsPreview = null;
if (!in_array($messageType, ['success', 'warning', 'error', 'info'], true)) {
    $messageType = 'success';
}
$error = '';
unset($_SESSION['demand_flash_message']);
unset($_SESSION['demand_flash_type']);
$importPreview = null;
$importWarnings = [];
$importPreviewToken = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');
    try {
        if ($action === 'preview_import') {
            $previewPayload = $_POST;
            if (isset($_FILES['demand_file']['tmp_name']) && is_string($_FILES['demand_file']['tmp_name']) && is_file($_FILES['demand_file']['tmp_name'])) {
                $previewPayload['upload_sha256'] = hash_file('sha256', $_FILES['demand_file']['tmp_name']);
            }
            $previewResult = demand_editorial_execute($action, $previewPayload, $scopeFilter, static function (): array {
                $targetScope = demand_normalize_scope_id((string) ($_POST['target_scope_id'] ?? 'rent_rk'));
                $kind = (string) ($_POST['import_kind'] ?? 'csv');
                $parsed = ['rows' => [], 'errors' => [], 'warnings' => []];
                if ($kind === 'manual') {
                    $manualPhrase = trim((string) ($_POST['manual_phrase'] ?? ''));
                    $manualRegion = trim((string) ($_POST['manual_region_name'] ?? ''));
                    $manualFrequency = (string) ($_POST['manual_frequency'] ?? '0');
                    $warnings = [];
                    $parsed = [
                        'rows' => [[
                            'scope_id' => $targetScope,
                            'phrase' => $manualPhrase,
                            'regionName' => $manualRegion,
                            'frequency' => demand_parse_frequency($manualFrequency, $warnings, 1),
                            'source' => 'manual_wordstat_import',
                        ]],
                        'errors' => $manualPhrase === '' ? ['Укажите фразу для ручного добавления.'] : [],
                        'warnings' => $warnings,
                    ];
                } else {
                    if (!isset($_FILES['demand_file']) || !is_array($_FILES['demand_file']) || (int) ($_FILES['demand_file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                        throw new RuntimeException('Выберите CSV или JSON файл.');
                    }
                    $raw = file_get_contents((string) $_FILES['demand_file']['tmp_name']);
                    if (!is_string($raw)) throw new RuntimeException('Не удалось прочитать файл импорта.');
                    $parsed = $kind === 'json' ? demand_parse_json_rows($raw, $targetScope) : demand_parse_csv_rows($raw, $targetScope);
                }
                if (!empty($parsed['errors'])) throw new RuntimeException(implode("\n", array_map('strval', $parsed['errors'])));
                $preview = demand_preview_import_rows((array) ($parsed['rows'] ?? []));
                $warnings = array_merge((array) ($parsed['warnings'] ?? []), (array) ($preview['errors'] ?? []));
                if (empty($preview['rows'])) throw new RuntimeException('Нет корректных строк для импорта.');
                return ['preview' => $preview, 'warnings' => $warnings, 'token' => demand_store_import_preview($preview, $warnings)];
            });
            $importPreview = (array) ($previewResult['preview'] ?? []);
            $importWarnings = (array) ($previewResult['warnings'] ?? []);
            $importPreviewToken = (string) ($previewResult['token'] ?? '');
            $tab = 'import';
        } elseif ($action === 'apply_import') {
            $previewToken = (string) ($_POST['preview_token'] ?? '');
            $result = demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_apply_import_preview($previewToken));
            unset($_SESSION['demand_import_previews'][$previewToken]);
            $_SESSION['demand_flash_message'] = 'Импорт применен: добавлено ' . $result['added'] . ', обновлено ' . $result['updated'] . ', пропущено ' . $result['skipped'] . '.';
            redirect_to(demand_admin_scope_filter_url('keywords', $scopeFilter));
        } elseif ($action === 'recalculate_keyword') {
            $keywordId = (string) ($_POST['keyword_id'] ?? '');
            demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_recalculate_keyword_recommendations($keywordId));
            $_SESSION['demand_flash_message'] = 'Рекомендации пересчитаны.';
            redirect_to(demand_admin_scope_filter_url('keywords', $scopeFilter));
        } elseif ($action === 'keyword_status') {
            demand_editorial_execute($action, $_POST, $scopeFilter, static function (): array {
                demand_update_keyword_status((string) ($_POST['keyword_id'] ?? ''), (string) ($_POST['status'] ?? 'active'));
                return ['keywordId' => (string) ($_POST['keyword_id'] ?? ''), 'status' => (string) ($_POST['status'] ?? 'active')];
            });
            $_SESSION['demand_flash_message'] = 'Статус запроса обновлен.';
            redirect_to(demand_admin_scope_filter_url('keywords', $scopeFilter));
        } elseif ($action === 'create_draft') {
            $draft = demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_create_landing_page_draft((string) ($_POST['recommendation_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Черновик создан: ' . (string) $draft['slug'] . '. Он не опубликован, закрыт от поиска и не добавлен в карту сайта.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['preview_draft' => (string) $draft['id']]));
        } elseif ($action === 'recommendation_status') {
            demand_editorial_execute($action, $_POST, $scopeFilter, static function (): array {
                demand_update_recommendation_status((string) ($_POST['recommendation_id'] ?? ''), (string) ($_POST['status'] ?? 'new'));
                return ['recommendationId' => (string) ($_POST['recommendation_id'] ?? ''), 'status' => (string) ($_POST['status'] ?? 'new')];
            });
            $_SESSION['demand_flash_message'] = 'Статус рекомендации обновлен.';
            redirect_to(demand_admin_scope_filter_url('recommendations', $scopeFilter));
        } elseif ($action === 'save_draft') {
            demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_update_landing_page_draft((string) ($_POST['draft_id'] ?? ''), $_POST));
            $_SESSION['demand_flash_message'] = 'Черновик сохранен. Публичная индексация не включалась.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => (string) ($_POST['draft_id'] ?? '')]));
        } elseif ($action === 'preview_text_save') {
            $draftId = (string) ($_POST['draft_id'] ?? '');
            $result = demand_editorial_execute($action, $_POST, $scopeFilter, static function () use ($draftId): array {
                $saved = demand_update_landing_preview_text($draftId, $_POST, current_admin_user() ?: 'system');
                if (!empty($_POST['preview_after_save']) && (string) $_POST['preview_after_save'] === 'check') {
                    $saved['draft'] = demand_update_draft_readiness($draftId);
                }
                return $saved;
            });
            $draft = (array) ($result['draft'] ?? []);
            if (!empty($_POST['preview_after_save']) && (string) $_POST['preview_after_save'] === 'check') {
                $_SESSION['demand_flash_message'] = 'Текст сохранен, готовность проверена: ' . demand_readiness_label((string) ($draft['readinessStatus'] ?? 'not_checked')) . '. Публикация, индексация, sitemap.xml и robots.txt не менялись.';
                redirect_to(demand_admin_draft_visual_preview_url($draft, $scopeFilter, true, 'check'));
            }
            $_SESSION['demand_flash_message'] = !empty($result['changed'])
                ? 'Текст preview сохранен в черновик. Готовность сброшена на повторную проверку; публикация и индексация не менялись.'
                : 'Изменений в preview-тексте не было.';
            redirect_to(demand_admin_draft_visual_preview_url($draft ?: ['id' => $draftId], $scopeFilter, true, demand_admin_preview_mode($_POST['preview_mode'] ?? 'edit')));
        } elseif ($action === 'draft_internal_links_suggest') {
            $draftId = (string) ($_POST['draft_id'] ?? '');
            $suggestResult = demand_editorial_execute($action, $_POST, $scopeFilter, static function () use ($draftId): array {
                $draft = demand_find_draft($draftId);
                $suggestions = demand_suggest_internal_links_for_draft($draft ?: []);
                $state = ['token' => 'dil_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)), 'draftId' => $draftId, 'suggestions' => $suggestions, 'createdAt' => now_iso()];
                $_SESSION['demand_internal_links_latest'] = $state;
                return ['draft' => $draft, 'state' => $state];
            });
            $draft = (array) ($suggestResult['draft'] ?? []);
            $suggestions = (array) ($suggestResult['state']['suggestions'] ?? []);
            $_SESSION['demand_internal_links_latest'] = (array) ($suggestResult['state'] ?? []);
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => 'internal_links',
                    'activeEntityType' => 'draft',
                    'activeEntityId' => $draftId,
                    'editableProposal' => [
                        'type' => 'internal_links',
                        'token' => (string) ($_SESSION['demand_internal_links_latest']['token'] ?? ''),
                        'draftId' => $draftId,
                        'suggestions' => $suggestions,
                    ],
                    'lastResult' => [
                        'type' => 'internal_links',
                        'title' => 'AI подобрал внутренние ссылки',
                        'summary' => 'Проверьте готовые публичные ссылки и добавьте только безопасные. Будущие или отсутствующие цели не станут публичными ссылками.',
                    ],
                ]);
            }
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = 'AI подобрал внутренние ссылки. Проверьте список и добавьте выбранные одной кнопкой; публикация и индексация не меняются.';
            if (demand_admin_simple_ai_return_anchor() !== '') {
                redirect_to(demand_admin_simple_ai_return_url('drafts', $scopeFilter, ['edit_draft' => $draftId], 'demand-internal-links'));
            }
            if (!empty($_POST['return_to_preview'])) {
                redirect_to(demand_admin_draft_visual_preview_url($draft, $scopeFilter, true, demand_admin_preview_mode($_POST['preview_mode'] ?? 'edit')) . '#demand-preview-internal-links');
            }
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $draftId]) . '#demand-internal-links');
        } elseif ($action === 'draft_internal_links_apply') {
            $draftId = (string) ($_POST['draft_id'] ?? '');
            $token = (string) ($_POST['internal_links_token'] ?? '');
            $state = is_array($_SESSION['demand_internal_links_latest'] ?? null) ? $_SESSION['demand_internal_links_latest'] : [];
            $mode = (string) ($_POST['apply_mode'] ?? 'selected');
            $selected = array_map('intval', (array) ($_POST['internal_link_indexes'] ?? []));
            $result = demand_editorial_execute($action, $_POST, $scopeFilter, static function () use ($draftId, $token, $state, $selected, $mode): array {
                if ($token === '' || $token !== (string) ($state['token'] ?? '') || $draftId !== (string) ($state['draftId'] ?? '')) {
                    throw new RuntimeException('Предложения внутренних ссылок устарели. Подберите ссылки заново.');
                }
                return demand_apply_internal_link_suggestions(
                    $draftId, (array) ($state['suggestions']['internalLinkSuggestions'] ?? []), $selected,
                    $mode === 'all_safe' ? 'all_safe' : 'selected', current_admin_user() ?: 'system'
                );
            });
            unset($_SESSION['demand_internal_links_latest']);
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => 'internal_links',
                    'activeEntityType' => 'draft',
                    'activeEntityId' => $draftId,
                    'editableProposal' => [],
                    'lastResult' => [
                        'type' => 'internal_links',
                        'title' => 'Внутренние ссылки добавлены',
                        'summary' => 'Добавлено безопасных ссылок: ' . count((array) ($result['added'] ?? [])) . '. Черновик остался в прежнем статусе, готовность нужно проверить заново.',
                    ],
                    'nextSafeAction' => [
                        'title' => 'Проверить готовность',
                        'text' => 'После ссылок стоит обновить readiness summary через существующую проверку.',
                        'button' => 'Проверить готовность',
                    ],
                ]);
            }
            $_SESSION['demand_flash_message'] = 'Добавлены внутренние ссылки: ' . count((array) ($result['added'] ?? [])) . '. Черновик остался в прежнем статусе, готовность сброшена на повторную проверку.';
            if (demand_admin_simple_ai_return_anchor() !== '') {
                redirect_to(demand_admin_simple_ai_return_url('drafts', $scopeFilter, ['edit_draft' => $draftId], 'demand-internal-links'));
            }
            if (!empty($_POST['return_to_preview'])) {
                $draft = demand_find_draft($draftId) ?: ['id' => $draftId];
                redirect_to(demand_admin_draft_visual_preview_url($draft, $scopeFilter, true, demand_admin_preview_mode($_POST['preview_mode'] ?? 'edit')) . '#demand-preview-internal-links');
            }
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $draftId]) . '#demand-internal-links');
        } elseif ($action === 'draft_internal_links_reject') {
            $draftId = (string) ($_POST['draft_id'] ?? '');
            demand_editorial_execute($action, $_POST, $scopeFilter, static function (): array {
                $previous = is_array($_SESSION['demand_internal_links_latest'] ?? null) ? $_SESSION['demand_internal_links_latest'] : [];
                unset($_SESSION['demand_internal_links_latest']);
                return ['rejectedToken' => (string) ($previous['token'] ?? '')];
            });
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = 'Предложения внутренних ссылок отклонены. Данные черновика не менялись.';
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => 'internal_links',
                    'activeEntityType' => 'draft',
                    'activeEntityId' => $draftId,
                    'editableProposal' => [],
                    'lastResult' => [
                        'type' => 'internal_links',
                        'title' => 'Внутренние ссылки отклонены',
                        'summary' => 'Черновик и публичные ссылки не менялись.',
                    ],
                ]);
                redirect_to(demand_admin_simple_ai_return_url('drafts', $scopeFilter, ['edit_draft' => $draftId], 'demand-internal-links'));
            }
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $draftId]) . '#demand-internal-links');
        } elseif ($action === 'draft_editorial_add_block') {
            $draft = demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_draft_editorial_append_safe_block((string) ($_POST['draft_id'] ?? ''), (string) ($_POST['block_type'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Заготовка блока добавлена в черновик. Проверьте готовность заново; публикация, индексация, sitemap и robots.txt не менялись.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => (string) ($draft['id'] ?? '')]) . '#demand-editorial-helper');
        } elseif ($action === 'draft_editorial_add_faq') {
            $draft = demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_draft_editorial_append_faq((string) ($_POST['draft_id'] ?? ''), (int) ($_POST['faq_index'] ?? -1)));
            $_SESSION['demand_flash_message'] = 'FAQ добавлен в черновик. Проверьте готовность заново; публикация, индексация, sitemap и robots.txt не менялись.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => (string) ($draft['id'] ?? '')]) . '#demand-editorial-helper');
        } elseif ($action === 'workflow_submit_review') {
            demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_workflow_submit_for_review((string) ($_POST['draft_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Черновик отправлен на проверку.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter));
        } elseif ($action === 'workflow_approve') {
            demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_workflow_approve((string) ($_POST['draft_id'] ?? ''), (string) ($_POST['review_note'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Черновик готов к публикации для просмотра.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter));
        } elseif ($action === 'workflow_reject') {
            demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_workflow_reject((string) ($_POST['draft_id'] ?? ''), (string) ($_POST['review_note'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Черновик отклонен и возвращен в draft.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter));
        } elseif ($action === 'workflow_publish_noindex') {
            demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_workflow_publish_noindex((string) ($_POST['draft_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Страница опубликована для просмотра, закрыта от поиска и не добавлена в карту сайта.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter));
        } elseif ($action === 'workflow_request_index') {
            demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_workflow_request_index_review((string) ($_POST['draft_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Страница отправлена на ручное решение: открывать ли её для поиска.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter));
        } elseif ($action === 'workflow_publish_indexed') {
            demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_workflow_publish_indexed((string) ($_POST['draft_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Страница открыта для поиска и добавлена в карту сайта.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter));
        } elseif ($action === 'workflow_return_noindex') {
            demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_workflow_return_noindex((string) ($_POST['draft_id'] ?? ''), (string) ($_POST['review_note'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Открытие для поиска отклонено, страница возвращена в режим просмотра без поиска.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter));
        } elseif ($action === 'workflow_close_index') {
            demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_workflow_close_from_index((string) ($_POST['draft_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Страница закрыта от поиска и удалена из карты сайта.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter));
        } elseif ($action === 'workflow_archive') {
            demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_workflow_archive((string) ($_POST['draft_id'] ?? ''), (string) ($_POST['review_note'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Страница архивирована.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter));
        } elseif ($action === 'workflow_merge') {
            demand_publication_execute($action, $_POST, $scopeFilter, static function (): array {
                if ((string) ($_POST['merge_confirm'] ?? '') !== '1') {
                    throw new RuntimeException('Подтвердите объединение страницы.', 409);
                }
                return demand_workflow_merge(
                    (string) ($_POST['draft_id'] ?? ''),
                    (string) ($_POST['target_page_id'] ?? ''),
                    (string) ($_POST['target_url'] ?? ''),
                    (string) ($_POST['merge_reason'] ?? '')
                );
            });
            $_SESSION['demand_flash_message'] = 'Страница помечена как объединенная. Автоматический редирект не включался.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter));
        } elseif ($action === 'workflow_restore_draft') {
            demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_workflow_restore_draft((string) ($_POST['draft_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Страница восстановлена как черновик.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter));
        } elseif ($action === 'workflow_rollback') {
            demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_workflow_apply_rollback((string) ($_POST['draft_id'] ?? ''), (string) ($_POST['version_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Откат к предыдущей версии применен.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter));
        } elseif ($action === 'draft_status') {
            throw new RuntimeException(
                'DEPRECATED_DUPLICATE_ACTION_DISABLED: используйте штатные действия архивирования или объединения.',
                409
            );
        } elseif ($action === 'refresh_draft_cars_preview') {
            $refreshCarsPreview = demand_refresh_draft_linked_cars_preview((string) ($_POST['draft_id'] ?? ''));
            $message = 'Предпросмотр готов. Данные черновика не изменялись.';
            $messageType = 'info';
        } elseif ($action === 'refresh_draft_cars') {
            $result = demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_refresh_draft_linked_cars(
                (string) ($_POST['draft_id'] ?? ''),
                (string) ($_POST['refresh_confirm'] ?? '') === '1'
            ));
            $_SESSION['demand_flash_type'] = !empty($result['changed']) ? 'success' : 'info';
            $_SESSION['demand_flash_message'] = !empty($result['changed'])
                ? 'Связанные авто пересчитаны. Готовность черновика сброшена на повторную проверку.'
                : 'Список авто уже актуален. Содержимое черновика не изменялось.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => (string) ($_POST['draft_id'] ?? '')]) . '#demand-refresh-draft-cars');
        } elseif ($action === 'wizard_check_readiness') {
            $draft = demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_update_draft_readiness((string) ($_POST['draft_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Готовность проверена: ' . demand_readiness_label((string) ($draft['readinessStatus'] ?? 'not_checked')) . '.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['preview_draft' => (string) ($draft['id'] ?? '')]));
        } elseif ($action === 'wizard_publish_noindex') {
            $draft = demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_wizard_publish_noindex((string) ($_POST['draft_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Страница опубликована для просмотра. Поиску закрыта, карта сайта не изменилась.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['preview_draft' => (string) ($draft['id'] ?? '')]));
        } elseif ($action === 'wizard_open_search') {
            $draft = demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_wizard_open_for_search((string) ($_POST['draft_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Страница вручную открыта для поиска и добавлена в карту сайта.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['preview_draft' => (string) ($draft['id'] ?? '')]));
        } elseif ($action === 'wizard_close_search') {
            $draft = demand_publication_execute($action, $_POST, $scopeFilter, static fn(): array => demand_wizard_close_from_search((string) ($_POST['draft_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Страница закрыта от поиска и удалена из карты сайта.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['preview_draft' => (string) ($draft['id'] ?? '')]));
        } elseif ($action === 'wizard_save_admin_note') {
            $draft = demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_update_draft_admin_note((string) ($_POST['draft_id'] ?? ''), (string) ($_POST['adminNote'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Заметка admin сохранена.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['preview_draft' => (string) ($draft['id'] ?? '')]));
        } elseif ($action === 'demand_car_hint_ai_generate') {
            $hintId = demand_clean_string($_POST['hint_id'] ?? '', 120);
            $aiTask = demand_admin_car_hint_ai_api_task((string) ($_POST['ai_api_task'] ?? 'generate_car_hint_text'));
            $hint = demand_ai_find_car_hint($hintId);
            if (!$hint) {
                throw new RuntimeException('Подсказка для авто не найдена.');
            }
            demand_scope_guard($hint, 'demand.card_hints.view');
            if (!has_permission('demand.ai_api.use') && !has_permission('demand.ai.package')) {
                require_permission('demand.ai_api.use');
            }

            $settings = openai_ai_settings();
            $apiReady = has_permission('demand.ai_api.use') && !empty($settings['enabled']) && !empty($settings['apiKeyConfigured']);
            if ($apiReady) {
                try {
                    $entityVersion = demand_ai_entity_version('car_hint', $hintId);
                    $result = demand_ai_content_session_execute($action, $_POST, $scopeFilter, static function () use ($aiTask, $hintId, $scopeFilter, $entityVersion): array {
                        $value = demand_ai_api_ask($aiTask, 'car_hint', $hintId, $scopeFilter, 'car_hints');
                        demand_ai_assert_entity_version('car_hint', $hintId, $entityVersion);
                        $value['contentToken'] = 'aiapi_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4));
                        return $value;
                    });
                    $_SESSION['demand_ai_api_latest'] = [
                        'token' => (string) ($result['contentToken'] ?? ''),
                        'contextTab' => demand_admin_simple_ai_return_anchor() !== '' ? 'start' : 'car_hints',
                        'entityType' => 'car_hint',
                        'entityId' => $hintId,
                        'task' => $aiTask,
                        'run' => (array) ($result['run'] ?? []),
                        'response' => (array) ($result['response'] ?? []),
                        'proposal' => (array) ($result['proposal'] ?? []),
                        'diff' => is_array($result['diff'] ?? null) ? $result['diff'] : null,
                        'entityVersion' => $entityVersion,
                        'createdAt' => now_iso(),
                    ];
                    unset($_SESSION['demand_car_hint_ai_fallback']);
                    if (demand_admin_simple_ai_return_anchor() !== '') {
                        demand_admin_set_simple_ai_workspace([
                            'activeAiTask' => $aiTask,
                            'activeEntityType' => 'car_hint',
                            'activeEntityId' => $hintId,
                            'activeProposalId' => (string) ($_SESSION['demand_ai_api_latest']['token'] ?? ''),
                            'editableProposal' => [
                                'type' => 'car_hint',
                                'token' => (string) ($_SESSION['demand_ai_api_latest']['token'] ?? ''),
                                'proposal' => (array) ($result['proposal'] ?? []),
                            ],
                            'lastResult' => [
                                'type' => 'car_hint',
                                'title' => 'AI подготовил текст для подсказки авто',
                                'summary' => 'Можно поправить вариант перед применением. Карточка авто, цена, залог, характеристики и доступность не меняются.',
                            ],
                        ]);
                    }
                    $_SESSION['demand_flash_type'] = 'info';
                    $_SESSION['demand_flash_message'] = 'AI подготовил текст. Проверьте preview/diff и при необходимости отредактируйте вариант перед применением.';
                    if (demand_admin_simple_ai_return_anchor() !== '') {
                        redirect_to(demand_admin_simple_ai_return_url('car_hints', $scopeFilter, [], 'demand-car-hint-ai-proposal'));
                    }
                    redirect_to(demand_admin_ai_return_url('car_hint', $hintId, 'car_hints', $scopeFilter) . '#demand-car-hint-ai-proposal');
                } catch (Throwable $error) {
                    if (!has_permission('demand.ai.package')) {
                        throw $error;
                    }
                    $_SESSION['demand_car_hint_ai_fallback'] = [
                        'entityType' => 'car_hint',
                        'entityId' => $hintId,
                        'task' => $aiTask,
                        'reason' => $error->getMessage(),
                        'contextTab' => demand_admin_simple_ai_return_anchor() !== '' ? 'start' : 'car_hints',
                        'createdAt' => now_iso(),
                    ];
                    if (demand_admin_simple_ai_return_anchor() !== '') {
                        demand_admin_set_simple_ai_workspace([
                            'activeAiTask' => $aiTask,
                            'activeEntityType' => 'car_hint',
                            'activeEntityId' => $hintId,
                            'lastResult' => [
                                'type' => 'car_hint_fallback',
                                'title' => 'AI сейчас недоступен',
                                'summary' => 'Автоматический текст не был сгенерирован. Доступен ручной режим / без API.',
                            ],
                        ]);
                    }
                    $_SESSION['demand_flash_type'] = 'warning';
                    $_SESSION['demand_flash_message'] = 'Автоматическая генерация недоступна. Можно сформировать ручной пакет без API.';
                    if (demand_admin_simple_ai_return_anchor() !== '') {
                        redirect_to(demand_admin_simple_ai_return_url('car_hints', $scopeFilter, [], 'demand-car-hint-ai-fallback'));
                    }
                    redirect_to(demand_admin_ai_return_url('car_hint', $hintId, 'car_hints', $scopeFilter) . '#demand-car-hint-ai-fallback');
                }
            }

            if (!has_permission('demand.ai.package')) {
                throw new RuntimeException('AI API выключен или ключ не настроен. Для ручного режима нет прав.');
            }
            $_SESSION['demand_car_hint_ai_fallback'] = [
                'entityType' => 'car_hint',
                'entityId' => $hintId,
                'task' => $aiTask,
                'reason' => 'AI API выключен или DeepSeek API key не настроен. Текст автоматически не генерировался.',
                'contextTab' => demand_admin_simple_ai_return_anchor() !== '' ? 'start' : 'car_hints',
                'createdAt' => now_iso(),
            ];
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => $aiTask,
                    'activeEntityType' => 'car_hint',
                    'activeEntityId' => $hintId,
                    'lastResult' => [
                        'type' => 'car_hint_fallback',
                        'title' => 'AI сейчас недоступен',
                        'summary' => 'Автоматический текст не был сгенерирован. Доступен ручной режим / без API.',
                    ],
                ]);
            }
            $_SESSION['demand_flash_type'] = 'warning';
            $_SESSION['demand_flash_message'] = 'AI API недоступен. Откройте ручной режим, чтобы сформировать безопасный пакет без внешнего вызова.';
            if (demand_admin_simple_ai_return_anchor() !== '') {
                redirect_to(demand_admin_simple_ai_return_url('car_hints', $scopeFilter, [], 'demand-car-hint-ai-fallback'));
            }
            redirect_to(demand_admin_ai_return_url('car_hint', $hintId, 'car_hints', $scopeFilter) . '#demand-car-hint-ai-fallback');
        } elseif ($action === 'demand_car_hint_ai_apply_edited') {
            $entityId = demand_clean_string($_POST['hint_id'] ?? '', 120);
            $outcome = demand_ai_content_durable_execute($action, $_POST, $scopeFilter, 'car_hint', $entityId, static function () use ($entityId): array {
                $token = (string) ($_POST['ai_api_token'] ?? '');
                $state = is_array($_SESSION['demand_ai_api_latest'] ?? null) ? $_SESSION['demand_ai_api_latest'] : [];
                if ($token === '' || $token !== (string) ($state['token'] ?? '')) {
                    throw new RuntimeException('Вариант AI устарел. Сгенерируйте вариант заново.', 409);
                }
                if ((string) ($state['entityType'] ?? '') !== 'car_hint' || $entityId !== (string) ($state['entityId'] ?? '')) {
                    throw new RuntimeException('Вариант AI относится к другой подсказке.', 409);
                }
                demand_ai_assert_entity_version('car_hint', $entityId, $state['entityVersion'] ?? null);
                $createdAt = strtotime((string) ($state['createdAt'] ?? '')) ?: 0;
                if ($createdAt > 0 && $createdAt < time() - 21600) {
                    throw new RuntimeException('Вариант AI устарел. Сгенерируйте вариант заново.', 409);
                }
                $postedProposal = is_array($_POST['car_hint_proposal'] ?? null) ? (array) $_POST['car_hint_proposal'] : [];
                $cleanProposal = demand_ai_sanitize_car_hint_proposal($postedProposal);
                if (!$cleanProposal) {
                    throw new RuntimeException('Нет разрешённого текста для применения.');
                }
                $baseProposal = demand_ai_sanitize_car_hint_proposal((array) ($state['proposal'] ?? []));
                $edited = demand_ai_hash($baseProposal) !== demand_ai_hash($cleanProposal);
                $result = demand_ai_apply_car_hint_proposal($entityId, $cleanProposal, current_admin_user() ?: 'system', [
                    'source' => 'deepseek_api',
                    'runId' => (string) ($state['run']['id'] ?? ''),
                    'edited' => $edited,
                ]);
                return ['changed' => !empty($result['changed']), 'edited' => $edited, 'task' => (string) ($state['task'] ?? 'car_hint')];
            });
            $result = ['changed' => !empty($outcome['changed'])];
            $edited = !empty($outcome['edited']);
            unset($_SESSION['demand_ai_api_latest']);
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => (string) ($outcome['task'] ?? 'car_hint'),
                    'activeEntityType' => 'car_hint',
                    'activeEntityId' => $entityId,
                    'editableProposal' => [],
                    'lastResult' => [
                        'type' => 'car_hint',
                        'title' => !empty($result['changed']) ? 'Отредактированный AI-вариант применён' : 'AI-вариант не изменил подсказку',
                        'summary' => 'Сохранены только разрешённые поля подсказки: message, suggestedText, descriptionSuggestion. Карточка автомобиля и бизнес-данные не менялись.',
                    ],
                ]);
            }
            $_SESSION['demand_flash_message'] = !empty($result['changed'])
                ? ($edited ? 'Отредактированный AI-вариант применён только к подсказке авто.' : 'AI-вариант применён только к подсказке авто.')
                : 'AI-вариант не изменил подсказку авто.';
            if (demand_admin_simple_ai_return_anchor() !== '') {
                redirect_to(demand_admin_simple_ai_return_url('car_hints', $scopeFilter, [], 'car-hints'));
            }
            redirect_to(demand_admin_ai_return_url('car_hint', $entityId, 'car_hints', $scopeFilter) . '#car-hints');
        } elseif ($action === 'demand_ai_generate_package') {
            $entityType = (string) ($_POST['entity_type'] ?? '');
            $entityId = (string) ($_POST['entity_id'] ?? '');
            $aiTask = (string) ($_POST['ai_task'] ?? '');
            $entityVersion = demand_ai_entity_version($entityType, $entityId);
            $generated = demand_ai_content_session_execute($action, $_POST, $scopeFilter, static function () use ($entityType, $entityId, $aiTask, $scopeFilter): array {
                $package = demand_ai_build_package($entityType, $entityId, $aiTask, $scopeFilter);
                return ['package' => $package, 'text' => demand_ai_build_text_package($package)];
            });
            $package = (array) ($generated['package'] ?? []);
            $_SESSION['demand_ai_latest_package'] = [
                'entityType' => $entityType,
                'entityId' => $entityId,
                'task' => $aiTask,
                'package' => $package,
                'text' => (string) ($generated['text'] ?? ''),
                'entityVersion' => $entityVersion,
                'createdAt' => now_iso(),
            ];
            unset($_SESSION['demand_ai_latest_preview']);
            if ($entityType === 'car_hint') {
                unset($_SESSION['demand_car_hint_ai_fallback']);
            }
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = 'Безопасный пакет для AI сформирован. Его можно скопировать или скачать; внешние API не вызывались.';
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => $aiTask,
                    'activeEntityType' => $entityType,
                    'activeEntityId' => $entityId,
                    'lastResult' => [
                        'type' => 'manual_mode',
                        'title' => 'Ручной режим / без API подготовлен',
                        'summary' => 'Сформирован ручной пакет для внешнего AI. Автоматическая генерация не запускалась.',
                    ],
                ]);
                redirect_to(demand_admin_simple_ai_return_url((string) ($_POST['tab'] ?? $tab), $scopeFilter, [], 'demand-ai-helper'));
            }
            redirect_to(demand_admin_ai_return_url($entityType, $entityId, (string) ($_POST['tab'] ?? $tab), $scopeFilter) . '#demand-ai-helper');
        } elseif ($action === 'demand_ai_preview_response') {
            $entityType = (string) ($_POST['entity_type'] ?? '');
            $entityId = (string) ($_POST['entity_id'] ?? '');
            $aiTask = (string) ($_POST['ai_task'] ?? '');
            $entityVersion = demand_ai_entity_version($entityType, $entityId);
            $previewResult = demand_ai_content_session_execute($action, $_POST, $scopeFilter, static function () use ($entityType, $entityId, $aiTask): array {
                $raw = trim((string) ($_POST['ai_response_json'] ?? ''));
                if ($raw === '') {
                    throw new RuntimeException('Вставьте JSON-ответ AI.');
                }
                $payload = json_decode($raw, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    throw new RuntimeException('Некорректный JSON: ' . json_last_error_msg());
                }
                $validated = demand_ai_validate_manual_response($aiTask, is_array($payload) ? $payload : []);
                $proposal = (array) ($validated['proposal'] ?? []);
                $diff = demand_ai_build_preview_diff($entityType, $entityId, $proposal);
                demand_ai_record_event($entityType, $entityId, 'ai_manual_response_previewed', 'Ответ AI вставлен вручную и показан в preview. Изменения не применялись.', [
                    'task' => $aiTask,
                    'proposalHash' => demand_ai_hash($proposal),
                    'ignoredFields' => (array) ($validated['ignoredFields'] ?? []),
                ]);
                return [
                    'token' => 'aip_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)),
                    'proposal' => $proposal,
                    'ignoredFields' => (array) ($validated['ignoredFields'] ?? []),
                    'diff' => $diff,
                ];
            });
            $token = (string) ($previewResult['token'] ?? '');
            $_SESSION['demand_ai_latest_preview'] = [
                'token' => $token,
                'entityType' => $entityType,
                'entityId' => $entityId,
                'task' => $aiTask,
                'proposal' => (array) ($previewResult['proposal'] ?? []),
                'ignoredFields' => (array) ($previewResult['ignoredFields'] ?? []),
                'diff' => is_array($previewResult['diff'] ?? null) ? $previewResult['diff'] : null,
                'entityVersion' => $entityVersion,
                'createdAt' => now_iso(),
            ];
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = 'Ответ AI разобран. Проверьте preview перед применением.';
            redirect_to(demand_admin_ai_return_url($entityType, $entityId, (string) ($_POST['tab'] ?? $tab), $scopeFilter) . '#demand-ai-helper');
        } elseif ($action === 'demand_ai_apply_proposal') {
            $entityType = (string) ($_POST['entity_type'] ?? '');
            $entityId = (string) ($_POST['entity_id'] ?? '');
            $result = demand_ai_content_durable_execute($action, $_POST, $scopeFilter, $entityType, $entityId, static function () use ($entityType, $entityId): array {
                $token = (string) ($_POST['ai_preview_token'] ?? '');
                $preview = is_array($_SESSION['demand_ai_latest_preview'] ?? null) ? $_SESSION['demand_ai_latest_preview'] : [];
                if ($token === '' || $token !== (string) ($preview['token'] ?? '')) {
                    throw new RuntimeException('Preview AI устарел. Вставьте ответ AI заново.', 409);
                }
                if ($entityType !== (string) ($preview['entityType'] ?? '') || $entityId !== (string) ($preview['entityId'] ?? '')) {
                    throw new RuntimeException('Preview AI относится к другому объекту.', 409);
                }
                demand_ai_assert_entity_version($entityType, $entityId, $preview['entityVersion'] ?? null);
                return demand_ai_apply_manual_proposal($entityType, $entityId, (array) ($preview['proposal'] ?? []), current_admin_user() ?: 'system');
            });
            unset($_SESSION['demand_ai_latest_preview']);
            $_SESSION['demand_flash_message'] = !empty($result['changed'])
                ? 'AI-предложение применено к разрешённым полям. Проверьте готовность заново; публикация и индексация не выполнялись.'
                : 'AI-предложение не изменило разрешённые поля.';
            redirect_to(demand_admin_ai_return_url($entityType, $entityId, (string) ($_POST['tab'] ?? $tab), $scopeFilter) . '#demand-ai-helper');
        } elseif ($action === 'demand_ai_reject_proposal') {
            $entityType = (string) ($_POST['entity_type'] ?? '');
            $entityId = (string) ($_POST['entity_id'] ?? '');
            demand_ai_content_durable_execute($action, $_POST, $scopeFilter, $entityType, $entityId, static function () use ($entityType, $entityId): array {
                $token = (string) ($_POST['ai_preview_token'] ?? '');
                $preview = is_array($_SESSION['demand_ai_latest_preview'] ?? null) ? $_SESSION['demand_ai_latest_preview'] : [];
                if ($token === '' || $token !== (string) ($preview['token'] ?? '')) {
                    throw new RuntimeException('Preview AI устарел. Вставьте ответ AI заново.', 409);
                }
                if ($entityType !== (string) ($preview['entityType'] ?? '') || $entityId !== (string) ($preview['entityId'] ?? '')) {
                    throw new RuntimeException('Preview AI относится к другому объекту.', 409);
                }
                demand_ai_assert_entity_version($entityType, $entityId, $preview['entityVersion'] ?? null);
                demand_ai_record_event((string) ($preview['entityType'] ?? ''), (string) ($preview['entityId'] ?? ''), 'ai_manual_proposal_rejected', 'AI-предложение отклонено вручную. Изменения не применялись.', [
                    'task' => (string) ($preview['task'] ?? ''),
                    'proposalHash' => demand_ai_hash((array) ($preview['proposal'] ?? [])),
                ]);
                return ['rejected' => true];
            });
            unset($_SESSION['demand_ai_latest_preview']);
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = 'AI-предложение отклонено. Данные не изменялись.';
            redirect_to(demand_admin_scope_filter_url((string) ($_POST['tab'] ?? $tab), $scopeFilter));
        } elseif ($action === 'demand_ai_api_ask') {
            $entityType = (string) ($_POST['entity_type'] ?? '');
            $entityId = (string) ($_POST['entity_id'] ?? '');
            $contextTab = (string) ($_POST['context_tab'] ?? ($_POST['tab'] ?? $tab));
            $aiTask = (string) ($_POST['ai_api_task'] ?? '');
            $entityVersion = demand_ai_entity_version($entityType, $entityId);
            $result = demand_ai_content_session_execute($action, $_POST, $scopeFilter, static function () use ($aiTask, $entityType, $entityId, $scopeFilter, $contextTab, $entityVersion): array {
                $value = demand_ai_api_ask($aiTask, $entityType, $entityId, $scopeFilter, $contextTab);
                demand_ai_assert_entity_version($entityType, $entityId, $entityVersion);
                $value['contentToken'] = 'aiapi_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4));
                return $value;
            });
            $_SESSION['demand_ai_api_latest'] = [
                'token' => (string) ($result['contentToken'] ?? ''),
                'contextTab' => $contextTab,
                'entityType' => $entityType,
                'entityId' => $entityId,
                'task' => $aiTask,
                'run' => (array) ($result['run'] ?? []),
                'response' => (array) ($result['response'] ?? []),
                'proposal' => (array) ($result['proposal'] ?? []),
                'diff' => is_array($result['diff'] ?? null) ? $result['diff'] : null,
                'entityVersion' => $entityVersion,
                'createdAt' => now_iso(),
            ];
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = 'AI-помощник подготовил ответ. Проверьте рекомендации и preview перед любым применением.';
            redirect_to(demand_admin_ai_api_return_url($contextTab, $scopeFilter, $entityType, $entityId) . '#demand-ai-api-helper');
        } elseif ($action === 'demand_ai_api_apply_proposal') {
            $entityType = (string) ($_POST['entity_type'] ?? '');
            $entityId = (string) ($_POST['entity_id'] ?? '');
            $outcome = demand_ai_content_durable_execute($action, $_POST, $scopeFilter, $entityType, $entityId, static function () use ($entityType, $entityId): array {
                $token = (string) ($_POST['ai_api_token'] ?? '');
                $state = is_array($_SESSION['demand_ai_api_latest'] ?? null) ? $_SESSION['demand_ai_api_latest'] : [];
                if ($token === '' || $token !== (string) ($state['token'] ?? '')) {
                    throw new RuntimeException('AI API preview устарел. Запросите предложение заново.', 409);
                }
                if ($entityType !== (string) ($state['entityType'] ?? '') || $entityId !== (string) ($state['entityId'] ?? '')) {
                    throw new RuntimeException('AI API preview относится к другому объекту.', 409);
                }
                demand_ai_assert_entity_version($entityType, $entityId, $state['entityVersion'] ?? null);
                $result = demand_ai_api_apply_proposal(
                    $entityType,
                    $entityId,
                    (array) ($state['proposal'] ?? []),
                    current_admin_user() ?: 'system',
                    (string) ($state['run']['id'] ?? '')
                );
                return ['changed' => !empty($result['changed']), 'contextTab' => (string) ($state['contextTab'] ?? 'drafts')];
            });
            $contextTab = (string) ($outcome['contextTab'] ?? ($_POST['tab'] ?? $tab));
            $result = ['changed' => !empty($outcome['changed'])];
            unset($_SESSION['demand_ai_api_latest']);
            $_SESSION['demand_flash_message'] = !empty($result['changed'])
                ? 'AI API-предложение применено только к разрешённым полям. Проверьте готовность заново; публикация и индексация не выполнялись.'
                : 'AI API-предложение не изменило разрешённые поля.';
            redirect_to(demand_admin_ai_api_return_url($contextTab, $scopeFilter, $entityType, $entityId) . '#demand-ai-api-helper');
        } elseif ($action === 'demand_ai_api_reject') {
            $entityType = (string) ($_POST['entity_type'] ?? '');
            $entityId = (string) ($_POST['entity_id'] ?? '');
            $outcome = demand_ai_content_durable_execute($action, $_POST, $scopeFilter, $entityType, $entityId, static function () use ($entityType, $entityId): array {
                $token = (string) ($_POST['ai_api_token'] ?? '');
                $state = is_array($_SESSION['demand_ai_api_latest'] ?? null) ? $_SESSION['demand_ai_api_latest'] : [];
                if ($token === '' || $token !== (string) ($state['token'] ?? '')) {
                    throw new RuntimeException('AI API preview устарел. Запросите предложение заново.', 409);
                }
                if ($entityType !== (string) ($state['entityType'] ?? '') || $entityId !== (string) ($state['entityId'] ?? '')) {
                    throw new RuntimeException('AI API preview относится к другому объекту.', 409);
                }
                demand_ai_assert_entity_version($entityType, $entityId, $state['entityVersion'] ?? null);
                if ((string) ($state['entityType'] ?? '') !== '' && (string) ($state['entityId'] ?? '') !== '') {
                    demand_ai_record_event((string) $state['entityType'], (string) $state['entityId'], 'ai_api_proposal_rejected', 'DeepSeek API proposal rejected manually. No changes were applied.', [
                        'task' => (string) ($state['task'] ?? ''),
                        'runId' => (string) ($state['run']['id'] ?? ''),
                        'proposalHash' => demand_ai_hash((array) ($state['proposal'] ?? [])),
                    ]);
                }
                return ['task' => (string) ($state['task'] ?? ''), 'entityType' => $entityType, 'entityId' => $entityId];
            });
            $state = $outcome;
            unset($_SESSION['demand_ai_api_latest']);
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = 'AI API-предложение отклонено. Данные не изменялись.';
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => (string) ($state['task'] ?? ''),
                    'activeEntityType' => (string) ($state['entityType'] ?? ''),
                    'activeEntityId' => (string) ($state['entityId'] ?? ''),
                    'editableProposal' => [],
                    'lastResult' => [
                        'type' => 'ai_api_reject',
                        'title' => 'Вариант AI отклонён',
                        'summary' => 'Данные не менялись.',
                    ],
                ]);
                redirect_to(demand_admin_simple_ai_return_url((string) ($_POST['tab'] ?? $tab), $scopeFilter));
            }
            redirect_to(demand_admin_scope_filter_url((string) ($_POST['tab'] ?? $tab), $scopeFilter));
        } elseif ($action === 'demand_ai_copy_regenerate') {
            $draftId = (string) ($_POST['draft_id'] ?? '');
            $task = (string) ($_POST['ai_copy_task'] ?? $_POST['copy_task'] ?? 'regenerate_landing_draft_human');
            $again = !empty($_POST['copy_regenerate_again']);
            $saveCopySettings = (string) ($_POST['ai_copy_settings_save'] ?? '');
            if ($saveCopySettings !== '') {
                $settingsPayload = demand_admin_ai_copy_settings_from_payload($_POST);
                if ($saveCopySettings === 'global') {
                    demand_ai_save_copy_settings($settingsPayload);
                    $_SESSION['demand_flash_type'] = 'success';
                    $_SESSION['demand_flash_message'] = 'Базовая инструкция генерации текста сохранена. Секреты, prompt и полный response не сохранялись.';
                } elseif ($saveCopySettings === 'draft') {
                    demand_ai_save_draft_copy_settings($draftId, $settingsPayload, $scopeFilter);
                    $_SESSION['demand_flash_type'] = 'success';
                    $_SESSION['demand_flash_message'] = 'Настройки генерации текста сохранены для этого черновика. Публикация и индексация не менялись.';
                } else {
                    throw new RuntimeException('Неизвестный тип сохранения настроек AI-текста.');
                }
                redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $draftId]) . '#demand-ai-copy-regeneration');
            }
            if ($again) {
                $previous = is_array($_SESSION['demand_ai_copy_latest'] ?? null) ? $_SESSION['demand_ai_copy_latest'] : [];
                $request = is_array($previous['request'] ?? null) ? $previous['request'] : [];
                $draftId = $draftId !== '' ? $draftId : (string) ($request['draftId'] ?? '');
                $task = (string) ($request['task'] ?? 'generate_alternative_variant');
                if ($task === '') {
                    $task = 'generate_alternative_variant';
                }
                $options = is_array($request['options'] ?? null) ? $request['options'] : [];
                if (array_key_exists('copy_style', $_POST) || array_key_exists('copy_base_instruction', $_POST)) {
                    $options = array_merge($options, demand_admin_ai_copy_options_from_payload($_POST));
                }
                $options['regenerateAgain'] = true;
                $options['previousVariantHash'] = (string) ($request['proposalHash'] ?? '');
            } else {
                $options = demand_admin_ai_copy_options_from_payload($_POST);
            }
            $entityVersion = demand_ai_entity_version('draft', $draftId);
            $generated = demand_ai_content_session_execute($action, $_POST, $scopeFilter, static function () use ($draftId, $task, $scopeFilter, $options, $entityVersion): array {
                $value = demand_ai_copy_generate_preview($draftId, $task, $scopeFilter, $options);
                demand_ai_assert_entity_version('draft', $draftId, $entityVersion);
                $value['contentToken'] = 'aicopy_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4));
                return $value;
            });
            $returnToPreview = !empty($_POST['return_to_preview']);
            $previewMode = demand_admin_preview_mode($_POST['preview_mode'] ?? 'edit');
            $_SESSION['demand_ai_copy_latest'] = [
                'token' => (string) ($generated['contentToken'] ?? ''),
                'entityType' => 'draft',
                'entityId' => $draftId,
                'task' => $task,
                'source' => (string) ($generated['source'] ?? 'local_safe_fallback'),
                'run' => (array) ($generated['run'] ?? []),
                'response' => (array) ($generated['response'] ?? []),
                'proposal' => (array) ($generated['proposal'] ?? []),
                'diff' => is_array($generated['diff'] ?? null) ? $generated['diff'] : null,
                'request' => array_merge((array) ($generated['request'] ?? []), [
                    'returnToPreview' => $returnToPreview,
                    'previewMode' => $previewMode,
                ]),
                'entityVersion' => $entityVersion,
                'createdAt' => now_iso(),
            ];
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = 'AI подготовил новый вариант текста. Проверьте preview/diff перед применением.';
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => $task,
                    'activeEntityType' => 'draft',
                    'activeEntityId' => $draftId,
                    'activeProposalId' => (string) ($_SESSION['demand_ai_copy_latest']['token'] ?? ''),
                    'editableProposal' => [
                        'type' => 'draft_text',
                        'token' => (string) ($_SESSION['demand_ai_copy_latest']['token'] ?? ''),
                        'draftId' => $draftId,
                        'proposal' => (array) ($generated['proposal'] ?? []),
                        'diff' => is_array($generated['diff'] ?? null) ? $generated['diff'] : [],
                    ],
                    'lastResult' => [
                        'type' => 'draft_text',
                        'title' => 'AI подготовил вариант текста',
                        'summary' => 'Проверьте текущий текст, AI-вариант, diff и отредактируйте итог перед применением.',
                    ],
                ]);
                redirect_to(demand_admin_simple_ai_return_url('drafts', $scopeFilter, ['edit_draft' => $draftId], 'demand-ai-copy-regeneration'));
            }
            if ($returnToPreview) {
                $draft = demand_find_draft($draftId) ?: ['id' => $draftId];
                redirect_to(demand_admin_draft_visual_preview_url($draft, $scopeFilter, true, $previewMode) . '#demand-preview-ai-diff');
            }
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $draftId]) . '#demand-ai-copy-regeneration');
        } elseif ($action === 'demand_ai_copy_apply') {
            $draftId = (string) ($_POST['draft_id'] ?? '');
            $outcome = demand_ai_content_durable_execute($action, $_POST, $scopeFilter, 'draft', $draftId, static function () use ($draftId): array {
                $token = (string) ($_POST['ai_copy_token'] ?? '');
                $state = is_array($_SESSION['demand_ai_copy_latest'] ?? null) ? $_SESSION['demand_ai_copy_latest'] : [];
                if ($token === '' || $token !== (string) ($state['token'] ?? '')) {
                    throw new RuntimeException('Preview AI-текста устарел. Сгенерируйте вариант заново.', 409);
                }
                if ($draftId !== (string) ($state['entityId'] ?? '')) {
                    throw new RuntimeException('Preview AI-текста относится к другому черновику.', 409);
                }
                demand_ai_assert_entity_version('draft', $draftId, $state['entityVersion'] ?? null);
                $mode = (string) ($_POST['apply_mode'] ?? 'all');
                $proposal = demand_ai_copy_subset_proposal((array) ($state['proposal'] ?? []), $mode);
                if (!$proposal) {
                    throw new RuntimeException('В выбранной части preview нет разрешенных изменений.');
                }
                $result = demand_ai_apply_manual_proposal('draft', $draftId, $proposal, current_admin_user() ?: 'system');
                demand_ai_record_event('draft', $draftId, 'ai_copy_regeneration_applied', 'AI human copy proposal applied manually after preview. Publication and indexing were not changed.', [
                    'task' => (string) ($state['task'] ?? ''),
                    'mode' => $mode,
                    'source' => (string) ($state['source'] ?? ''),
                    'runId' => (string) ($state['run']['id'] ?? ''),
                    'proposalHash' => demand_ai_hash($proposal),
                ]);
                return ['changed' => !empty($result['changed']), 'task' => (string) ($state['task'] ?? ''), 'request' => (array) ($state['request'] ?? []), 'mode' => $mode];
            });
            $result = ['changed' => !empty($outcome['changed'])];
            $state = ['task' => (string) ($outcome['task'] ?? ''), 'request' => (array) ($outcome['request'] ?? [])];
            $mode = (string) ($outcome['mode'] ?? 'all');
            unset($_SESSION['demand_ai_copy_latest']);
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => (string) ($state['task'] ?? 'draft_text'),
                    'activeEntityType' => 'draft',
                    'activeEntityId' => $draftId,
                    'editableProposal' => [],
                    'lastResult' => [
                        'type' => 'draft_text',
                        'title' => !empty($result['changed']) ? 'AI-текст применён' : 'AI-текст не изменил черновик',
                        'summary' => 'Изменены только разрешённые текстовые поля. PublishStatus, indexStatus, sitemap, robots и public routes не менялись.',
                    ],
                    'nextSafeAction' => [
                        'title' => 'Проверить готовность',
                        'text' => 'После изменения текста нужно обновить readiness summary.',
                        'button' => 'Проверить готовность',
                    ],
                ]);
            }
            $_SESSION['demand_flash_type'] = !empty($result['changed']) ? 'success' : 'info';
            $_SESSION['demand_flash_message'] = !empty($result['changed'])
                ? 'AI-текст применен только к выбранным полям. Готовность сброшена, публикация и индексация не менялись.'
                : 'AI-текст не изменил выбранные поля.';
            $request = is_array($state['request'] ?? null) ? $state['request'] : [];
            if (demand_admin_simple_ai_return_anchor() !== '') {
                redirect_to(demand_admin_simple_ai_return_url('drafts', $scopeFilter, ['edit_draft' => $draftId], 'demand-ai-copy-regeneration'));
            }
            if (!empty($request['returnToPreview'])) {
                demand_ai_record_event('draft', $draftId, 'preview_ai_block_applied', 'AI preview block proposal applied manually after preview/diff. Publication and indexing were not changed.', [
                    'task' => (string) ($state['task'] ?? ''),
                    'mode' => $mode,
                ]);
                $draft = demand_find_draft($draftId) ?: ['id' => $draftId];
                redirect_to(demand_admin_draft_visual_preview_url($draft, $scopeFilter, true, demand_admin_preview_mode($request['previewMode'] ?? 'edit')));
            }
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $draftId]) . '#demand-ai-copy-regeneration');
        } elseif ($action === 'demand_ai_copy_apply_edited') {
            $draftId = (string) ($_POST['draft_id'] ?? '');
            $outcome = demand_ai_content_durable_execute($action, $_POST, $scopeFilter, 'draft', $draftId, static function () use ($draftId): array {
                $token = (string) ($_POST['ai_copy_token'] ?? '');
                $state = is_array($_SESSION['demand_ai_copy_latest'] ?? null) ? $_SESSION['demand_ai_copy_latest'] : [];
                if ($token === '' || $token !== (string) ($state['token'] ?? '')) {
                    throw new RuntimeException('Preview AI-текста устарел. Сгенерируйте вариант заново.', 409);
                }
                if ($draftId !== (string) ($state['entityId'] ?? '')) {
                    throw new RuntimeException('Preview AI-текста относится к другому черновику.', 409);
                }
                demand_ai_assert_entity_version('draft', $draftId, $state['entityVersion'] ?? null);
                $postedProposal = is_array($_POST['ai_copy_proposal'] ?? null) ? (array) $_POST['ai_copy_proposal'] : [];
                $proposal = demand_admin_workspace_copy_posted_proposal($postedProposal);
                if (!$proposal) {
                    throw new RuntimeException('Нет разрешённого текста для применения.');
                }
                $baseProposal = (array) ($state['proposal'] ?? []);
                $result = demand_ai_apply_manual_proposal('draft', $draftId, $proposal, current_admin_user() ?: 'system');
                demand_ai_record_event('draft', $draftId, 'ai_copy_workspace_edited_applied', 'Edited AI text proposal applied from Simple View workspace. Publication and indexing were not changed.', [
                    'task' => (string) ($state['task'] ?? ''),
                    'source' => (string) ($state['source'] ?? ''),
                    'runId' => (string) ($state['run']['id'] ?? ''),
                    'edited' => demand_ai_hash($baseProposal) !== demand_ai_hash($proposal),
                    'proposalHash' => demand_ai_hash($proposal),
                ]);
                return ['changed' => !empty($result['changed']), 'task' => (string) ($state['task'] ?? 'draft_text')];
            });
            $result = ['changed' => !empty($outcome['changed'])];
            $state = ['task' => (string) ($outcome['task'] ?? 'draft_text')];
            unset($_SESSION['demand_ai_copy_latest']);
            demand_admin_set_simple_ai_workspace([
                'activeAiTask' => (string) ($state['task'] ?? 'draft_text'),
                'activeEntityType' => 'draft',
                'activeEntityId' => $draftId,
                'editableProposal' => [],
                'lastResult' => [
                    'type' => 'draft_text',
                    'title' => !empty($result['changed']) ? 'Отредактированный AI-вариант применён' : 'Отредактированный вариант не изменил черновик',
                    'summary' => 'Сохранены только разрешённые текстовые поля. Публикация, индексация, sitemap, robots и public routes не менялись.',
                ],
                'nextSafeAction' => [
                    'title' => 'Проверить готовность',
                    'text' => 'После изменения текста нужно обновить readiness summary.',
                    'button' => 'Проверить готовность',
                ],
            ]);
            $_SESSION['demand_flash_type'] = !empty($result['changed']) ? 'success' : 'info';
            $_SESSION['demand_flash_message'] = !empty($result['changed'])
                ? 'Отредактированный AI-вариант применён только к разрешённым полям. Готовность сброшена; публикация и индексация не менялись.'
                : 'Отредактированный AI-вариант не изменил черновик.';
            redirect_to(demand_admin_simple_ai_return_url('drafts', $scopeFilter, ['edit_draft' => $draftId], 'demand-ai-copy-regeneration'));
        } elseif ($action === 'demand_ai_copy_reject') {
            $draftId = (string) ($_POST['draft_id'] ?? '');
            $outcome = demand_ai_content_durable_execute($action, $_POST, $scopeFilter, 'draft', $draftId, static function () use ($draftId): array {
                $token = (string) ($_POST['ai_copy_token'] ?? '');
                $state = is_array($_SESSION['demand_ai_copy_latest'] ?? null) ? $_SESSION['demand_ai_copy_latest'] : [];
                if ($token === '' || $token !== (string) ($state['token'] ?? '')) {
                    throw new RuntimeException('Preview AI-текста устарел. Сгенерируйте вариант заново.', 409);
                }
                if ($draftId !== (string) ($state['entityId'] ?? '')) {
                    throw new RuntimeException('Preview AI-текста относится к другому черновику.', 409);
                }
                demand_ai_assert_entity_version('draft', $draftId, $state['entityVersion'] ?? null);
                demand_ai_record_event('draft', (string) ($state['entityId'] ?? ''), 'ai_copy_regeneration_rejected', 'AI human copy proposal rejected manually. No changes were applied.', [
                    'task' => (string) ($state['task'] ?? ''),
                    'proposalHash' => demand_ai_hash((array) ($state['proposal'] ?? [])),
                ]);
                return ['task' => (string) ($state['task'] ?? 'draft_text')];
            });
            $state = $outcome;
            unset($_SESSION['demand_ai_copy_latest']);
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = 'Вариант AI-текста отклонен. Черновик не менялся.';
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => (string) ($state['task'] ?? 'draft_text'),
                    'activeEntityType' => 'draft',
                    'activeEntityId' => $draftId,
                    'editableProposal' => [],
                    'lastResult' => [
                        'type' => 'draft_text',
                        'title' => 'Вариант AI-текста отклонён',
                        'summary' => 'Черновик не менялся.',
                    ],
                ]);
                redirect_to(demand_admin_simple_ai_return_url('drafts', $scopeFilter, $draftId !== '' ? ['edit_draft' => $draftId] : [], 'demand-ai-copy-regeneration'));
            }
            $request = is_array($state['request'] ?? null) ? $state['request'] : [];
            if (!empty($request['returnToPreview'])) {
                $draft = demand_find_draft($draftId) ?: ['id' => $draftId];
                redirect_to(demand_admin_draft_visual_preview_url($draft, $scopeFilter, true, demand_admin_preview_mode($request['previewMode'] ?? 'edit')));
            }
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, $draftId !== '' ? ['edit_draft' => $draftId] : []) . '#demand-ai-copy-regeneration');
        } elseif ($action === 'demand_ai_dialog_ask') {
            $contextTab = (string) ($_POST['context_tab'] ?? ($_POST['tab'] ?? $tab));
            $entityType = (string) ($_POST['entity_type'] ?? '');
            $entityId = (string) ($_POST['entity_id'] ?? '');
            $messageText = (string) ($_POST['ai_dialog_message'] ?? '');
            $dialogOptions = [
                'directionId' => (string) ($_POST['direction_id'] ?? ''),
                'directionTitle' => (string) ($_POST['direction_title'] ?? ''),
                'budgetMode' => (string) ($_POST['direction_budget_mode'] ?? ''),
                'processingFingerprint' => (string) ($_POST['processing_fingerprint'] ?? ''),
                'source' => (string) ($_POST['direction_session_source'] ?? 'demand_master'),
            ];
            $entityVersion = demand_ai_entity_version($entityType, $entityId);
            $dialogWorkflow = demand_ai_content_session_execute($action, $_POST, $scopeFilter, static function () use ($messageText, $scopeFilter, $contextTab, $entityType, $entityId, $dialogOptions, $entityVersion): array {
                $value = demand_ai_dialog_ask($messageText, $scopeFilter, $contextTab, $entityType, $entityId, $dialogOptions);
                if ($entityType !== '' && $entityId !== '') {
                    demand_ai_assert_entity_version($entityType, $entityId, $entityVersion);
                }
                return $value;
            });
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = (string) ($dialogWorkflow['stopReason'] ?? '') === 'stale_fingerprint_reused'
                ? 'AI не тратил лимиты повторно: направление уже обработано, данные не изменились.'
                : (!empty($dialogWorkflow['autoExecutedActions'])
                ? 'AI-помощник выполнил безопасные подготовительные шаги и собрал план действий. Публикация и поиск не менялись.'
                : 'AI-помощник собрал безопасный план действий. Данные не менялись.');
            if (!empty($dialogWorkflow['requiresDirectionSelection'])) {
                $_SESSION['demand_flash_message'] = 'Широкая задача разбита на направления. Выберите direction-session и бюджет перед расходом лимитов.';
            }
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => 'ai_dialog',
                    'activeEntityType' => $entityType,
                    'activeEntityId' => $entityId,
                    'activeDirectionId' => (string) ($dialogWorkflow['directionSession']['directionId'] ?? ''),
                    'lastResult' => [
                        'type' => 'ai_dialog',
                        'title' => 'AI-помощник подготовил план',
                        'summary' => (string) ($dialogWorkflow['summary'] ?? $dialogWorkflow['ownerSummary'] ?? $_SESSION['demand_flash_message']),
                    ],
                ]);
                redirect_to(demand_admin_simple_ai_return_url($contextTab, $scopeFilter));
            }
            redirect_to(demand_admin_ai_dialog_return_url($contextTab, $scopeFilter, $entityType, $entityId) . '#demand-ai-dialog');
        } elseif ($action === 'demand_direction_neighbor_decision') {
            $directionId = (string) ($_POST['direction_id'] ?? '');
            $neighborAction = (string) ($_POST['neighbor_action'] ?? '');
            demand_editorial_execute($action, $_POST, $scopeFilter, static function () use ($directionId, $neighborAction): array {
                demand_ai_apply_direction_session_override($directionId, $neighborAction);
                return ['directionId' => $directionId, 'neighborAction' => $neighborAction];
            });
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = match ($neighborAction) {
                'add_to_queue' => 'Направление добавлено в очередь. AI не запускался без подтверждения.',
                'process_now' => 'Открыто подтверждение AI-сессии для соседнего направления. Работа не запущена.',
                'ignore' => 'Направление скрыто из очереди в этой сессии.',
                'postpone' => 'Направление отложено. AI не тратил лимиты.',
                default => 'Решение по направлению сохранено в этой сессии.',
            };
            if ($neighborAction === 'process_now' && $directionId !== '') {
                $_SESSION['demand_direction_open_modal'] = $directionId;
            }
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => 'decision',
                    'activeDirectionId' => $directionId,
                    'lastResult' => [
                        'type' => 'decision',
                        'title' => 'Решение по соседнему направлению сохранено',
                        'summary' => $_SESSION['demand_flash_message'],
                    ],
                ]);
                redirect_to(demand_admin_simple_ai_return_url('start', $scopeFilter));
            }
            redirect_to(demand_admin_scope_filter_url('start', $scopeFilter) . '#demand-direction-sessions');
        } elseif ($action === 'demand_ai_dialog_run_action') {
            $contextTab = (string) ($_POST['context_tab'] ?? ($_POST['tab'] ?? $tab));
            $entityType = (string) ($_POST['entity_type'] ?? '');
            $entityId = (string) ($_POST['entity_id'] ?? '');
            $result = demand_ai_content_session_execute($action, $_POST, $scopeFilter, static function () use ($entityType, $entityId, $scopeFilter): array {
                return demand_ai_dialog_execute_action(
                    (string) ($_POST['workflow_id'] ?? ''),
                    (string) ($_POST['workflow_action_id'] ?? ''),
                    $scopeFilter,
                    [
                        'explicit_confirm' => !empty($_POST['explicit_confirm']),
                        'draft_id' => $entityType === 'draft' ? $entityId : (string) ($_POST['draft_id'] ?? ''),
                    ]
                );
            });
            $_SESSION['demand_flash_type'] = !empty($result['changed']) ? 'success' : 'info';
            $_SESSION['demand_flash_message'] = (string) ($result['message'] ?? 'Действие AI выполнено.');
            if (demand_admin_simple_ai_return_anchor() !== '' || (string) ($result['returnAnchor'] ?? '') === 'simple-ai-workspace') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => (string) ($_POST['workflow_action_id'] ?? ''),
                    'activeEntityType' => $entityType,
                    'activeEntityId' => $entityId,
                    'activeDirectionId' => (string) ($result['directionId'] ?? ''),
                    'lastResult' => [
                        'type' => 'ai_dialog_action',
                        'title' => 'AI подготовил следующий шаг',
                        'summary' => (string) ($result['message'] ?? ''),
                    ],
                ]);
                redirect_to(demand_admin_scope_filter_url('start', $scopeFilter) . '#simple-ai-workspace');
            }
            redirect_to(demand_admin_ai_dialog_return_url($contextTab, $scopeFilter, $entityType, $entityId) . '#demand-ai-dialog');
        } elseif ($action === 'demand_ai_dialog_clear') {
            demand_ai_content_session_execute($action, $_POST, $scopeFilter, static function (): array {
                demand_ai_dialog_clear_state();
                return ['cleared' => true];
            });
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = 'Диалог AI очищен. Данные не менялись.';
            redirect_to(demand_admin_scope_filter_url((string) ($_POST['tab'] ?? $tab), $scopeFilter));
        } elseif ($action === 'demand_ai_dialog_stop') {
            $result = demand_ai_content_session_execute($action, $_POST, $scopeFilter, static fn(): array => demand_ai_dialog_stop_state());
            $_SESSION['demand_flash_type'] = 'info';
            $_SESSION['demand_flash_message'] = (string) ($result['message'] ?? 'AI остановлен.');
            redirect_to(demand_admin_scope_filter_url((string) ($_POST['tab'] ?? $tab), $scopeFilter) . '#demand-ai-dialog');
        } elseif ($action === 'demand_map_recalculate') {
            $result = demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_map_recalculate($scopeFilter));
            $_SESSION['demand_flash_message'] = 'Карта спроса пересчитана: групп запросов ' . (int) $result['clusters'] . ', пунктов плана ' . (int) $result['plans'] . '. Публикация, карта сайта и robots.txt не менялись.';
            redirect_to(demand_admin_scope_filter_url('demand_map', $scopeFilter));
        } elseif ($action === 'demand_map_create_brief') {
            $brief = demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_map_create_content_brief((string) ($_POST['plan_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'ТЗ для страницы сохранено: ' . (string) ($brief['title'] ?? $brief['id'] ?? '') . '. Оно показано ниже в блоке "ТЗ для страниц" и доступно только в админке.';
            redirect_to(demand_admin_scope_filter_url('demand_map', $scopeFilter, ['cluster_id' => (string) ($_POST['cluster_id'] ?? ''), 'brief_id' => (string) ($brief['id'] ?? '')]) . '#demand-content-briefs');
        } elseif ($action === 'demand_map_create_card_hints') {
            $hints = demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_map_create_card_hints((string) ($_POST['plan_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Подсказки для карточек созданы: ' . count($hints) . '. Карточки авто не изменялись автоматически.';
            redirect_to(demand_admin_scope_filter_url('demand_map', $scopeFilter, ['cluster_id' => (string) ($_POST['cluster_id'] ?? '')]));
        } elseif ($action === 'demand_map_create_draft') {
            $draft = demand_editorial_execute($action, $_POST, $scopeFilter, static fn(): array => demand_map_create_landing_draft_from_plan((string) ($_POST['plan_id'] ?? '')));
            $_SESSION['demand_flash_message'] = 'Черновик создан из плана страниц: ' . (string) ($draft['slug'] ?? '') . '. Он закрыт от поиска, карта сайта не менялась.';
            redirect_to(demand_admin_scope_filter_url('drafts', $scopeFilter, ['preview_draft' => (string) ($draft['id'] ?? '')]));
        } elseif ($action === 'demand_map_plan_status') {
            $status = (string) ($_POST['launchStatus'] ?? 'planned');
            demand_editorial_execute($action, $_POST, $scopeFilter, static function () use ($status): array {
                demand_map_update_plan_status((string) ($_POST['plan_id'] ?? ''), $status);
                return ['planId' => (string) ($_POST['plan_id'] ?? ''), 'launchStatus' => $status];
            });
            $_SESSION['demand_flash_message'] = 'Статус пункта плана обновлён: ' . demand_admin_ui_label($status) . '.';
            redirect_to(demand_admin_scope_filter_url('demand_map', $scopeFilter, ['cluster_id' => (string) ($_POST['cluster_id'] ?? '')]));
        } elseif ($action === 'save_integrations_settings') {
            demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => demand_integrations_save_settings($_POST));
            $_SESSION['demand_flash_message'] = 'Настройки источников сохранены. Wordstat загружает данные только вручную и не меняет поиск или карту сайта.';
            redirect_to(demand_admin_scope_filter_url('integrations', $scopeFilter));
        } elseif ($action === 'wordstat_refresh_credentials_status') {
            $settings = demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => wordstat_refresh_credentials_metadata());
            $_SESSION['demand_flash_message'] = !empty($settings['apiKeyConfigured']) && !empty($settings['folderIdConfigured']) && !empty($settings['baseUrlConfigured'])
                ? 'Статус доступов Wordstat обновлён: данные найдены в безопасном месте.'
                : 'Статус доступов Wordstat обновлён: пока не хватает ключа доступа, ID каталога или адреса API.';
            redirect_to(demand_admin_scope_filter_url(demand_wordstat_return_tab(), $scopeFilter));
        } elseif ($action === 'wordstat_wizard_save_credentials') {
            $settings = demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => wordstat_write_private_credentials($_POST));
            $_SESSION['demand_flash_message'] = !empty($settings['apiKeyConfigured']) && !empty($settings['folderIdConfigured']) && !empty($settings['baseUrlConfigured'])
                ? 'Доступы Wordstat сохранены в private-файл. Ключи не записаны в обычные JSON и не показываются в админке.'
                : 'Доступы Wordstat сохранены, но система пока не видит полный набор: ключ доступа, ID каталога и адрес API.';
            redirect_to(demand_admin_scope_filter_url('wordstat_help', $scopeFilter));
        } elseif ($action === 'wordstat_wizard_clear_credentials') {
            $settings = demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => wordstat_clear_private_credentials());
            $_SESSION['demand_flash_message'] = !empty($settings['apiKeyConfigured'])
                ? 'Private-доступы Wordstat удалены. Сейчас используются доступы из настроек сервера.'
                : 'Private-доступы Wordstat удалены. Wordstat ожидает новый ключ доступа и ID каталога.';
            redirect_to(demand_admin_scope_filter_url('wordstat_help', $scopeFilter));
        } elseif ($action === 'wordstat_wizard_save_dry_run_settings') {
            $regions = wordstat_parse_region_ids((string) ($_POST['default_region_ids'] ?? ''));
            $seeds = wordstat_parse_seed_phrases((string) ($_POST['default_seed_phrases'] ?? ''));
            if (!$seeds) {
                throw new RuntimeException('Укажите хотя бы одну seed-фразу для Wordstat.');
            }
            demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => wordstat_update_source_settings([
                'enabled' => true,
                'mode' => 'dry_run',
                'liveEnabled' => false,
                'defaultRegionIds' => $regions,
                'defaultSeedPhrases' => $seeds,
                'dailyRequestLimit' => $_POST['dailyRequestLimit'] ?? null,
                'monthlyRequestLimit' => $_POST['monthlyRequestLimit'] ?? null,
                'perRunRequestLimit' => $_POST['perRunRequestLimit'] ?? null,
                'estimatedCostLimitRub' => $_POST['estimatedCostLimitRub'] ?? null,
                'cooldownSecondsBetweenRequests' => $_POST['cooldownSecondsBetweenRequests'] ?? null,
                'retryAttempts' => $_POST['retryAttempts'] ?? null,
                'retryBackoffSeconds' => $_POST['retryBackoffSeconds'] ?? null,
            ]));
            $_SESSION['demand_flash_message'] = 'Wordstat настроен на пробную проверку без изменений: ручная загрузка выключена, поиск и карта сайта не менялись.';
            redirect_to(demand_admin_scope_filter_url('wordstat_help', $scopeFilter));
        } elseif ($action === 'wordstat_wizard_enable_live') {
            $currentWordstat = wordstat_current_settings();
            if (empty($currentWordstat['apiKeyConfigured']) || empty($currentWordstat['folderIdConfigured']) || empty($currentWordstat['baseUrlConfigured'])) {
                throw new RuntimeException('Нельзя разрешить ручную загрузку Wordstat: сначала настройте ключ доступа, ID каталога и адрес API в безопасном месте.');
            }
            if (!in_array((string) ($currentWordstat['authStatus'] ?? ''), ['configured', 'test_success'], true)) {
                throw new RuntimeException('Нельзя разрешить ручную загрузку Wordstat: сначала выполните проверку подключения.');
            }
            demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => wordstat_update_source_settings([
                'enabled' => true,
                'mode' => 'live_controlled',
                'liveEnabled' => true,
            ]));
            $_SESSION['demand_flash_message'] = 'Ручная загрузка Wordstat разрешена. Она обновляет только спрос, метрики и советы; страницы, карта сайта и поиск не меняются автоматически.';
            redirect_to(demand_admin_scope_filter_url('wordstat_help', $scopeFilter));
        } elseif ($action === 'wordstat_wizard_disable_live') {
            demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => wordstat_update_source_settings([
                'enabled' => true,
                'mode' => 'dry_run',
                'liveEnabled' => false,
            ]));
            $_SESSION['demand_flash_message'] = 'Wordstat возвращён в безопасную пробную проверку. Ручная загрузка выключена.';
            redirect_to(demand_admin_scope_filter_url('wordstat_help', $scopeFilter));
        } elseif ($action === 'wordstat_test_connection') {
            $result = demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => wordstat_test_connection());
            if (!empty($result['ok'])) {
                $_SESSION['demand_flash_type'] = 'success';
                $_SESSION['demand_flash_message'] = 'Проверка Wordstat прошла. Ключи не показывались и не сохранялись в tracked JSON.';
            } else {
                $_SESSION['demand_flash_type'] = 'warning';
                $_SESSION['demand_flash_message'] = 'Проверка Wordstat не прошла. Смотрите шаг 2 «Проверка подключения»: там показана причина и что проверить. Причина: '
                    . (string) ($result['message'] ?? 'неизвестная ошибка') . '.';
            }
            redirect_to(demand_admin_scope_filter_url(demand_wordstat_return_tab(), $scopeFilter));
        } elseif ($action === 'wordstat_load_regions') {
            $result = demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => wordstat_load_regions_tree_controlled());
            $_SESSION['demand_flash_message'] = 'Справочник регионов Wordstat загружен: ' . count((array) ($result['regions'] ?? [])) . ' регионов. Режим: ' . (!empty($result['mock']) ? 'тестовые данные' : 'ручная загрузка') . '.';
            redirect_to(demand_admin_scope_filter_url(demand_wordstat_return_tab(), $scopeFilter));
        } elseif ($action === 'wordstat_dry_run') {
            $result = demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => wordstat_run_dry_run(
                demand_normalize_scope_id((string) ($_POST['target_scope_id'] ?? 'rent_rk')),
                (string) ($_POST['seed_phrases'] ?? ''),
                (string) ($_POST['region_ids'] ?? ''),
                (array) ($_POST['methods'] ?? [])
            ));
            $_SESSION['demand_wordstat_latest_dry_run_id'] = (string) ($result['run']['id'] ?? '');
            $dryRunSnapshot = is_array($result['run'] ?? null) ? $result['run'] : [];
            foreach (['scope_id', 'seedPhrases', 'regionIds', 'methods', 'plannedRequests', 'estimatedCostRub', 'planBreakdown', 'warnings'] as $key) {
                if (!array_key_exists($key, $dryRunSnapshot) && array_key_exists($key, $result['plan'] ?? [])) {
                    $dryRunSnapshot[$key] = $result['plan'][$key];
                }
            }
            if (!array_key_exists('limitPreview', $dryRunSnapshot) && array_key_exists('limits', $result)) {
                $dryRunSnapshot['limitPreview'] = $result['limits'];
            }
            $dryRunSnapshot['source'] = 'wordstat';
            $dryRunSnapshot['dryRun'] = true;
            $_SESSION['demand_wordstat_latest_dry_run_snapshot'] = $dryRunSnapshot;
            $_SESSION['demand_flash_message'] = 'Пробная проверка рассчитана. Подробная расшифровка показана ниже в блоке “Результат последней пробной проверки”: там видно фразы, регионы, методы и почему получилось именно ' . (int) ($result['plan']['plannedRequests'] ?? 0) . ' запроса.';
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => 'wordstat_dry_run',
                    'lastResult' => [
                        'type' => 'wordstat_dry_run',
                        'title' => 'Проверка Wordstat без изменения данных готова',
                        'summary' => 'Live не запускался. Данные спроса, публикация, индексация, sitemap, robots и бизнес-данные не менялись.',
                        'plannedRequests' => (int) ($result['plan']['plannedRequests'] ?? 0),
                        'estimatedCostRub' => (float) ($result['plan']['estimatedCostRub'] ?? 0.0),
                    ],
                ]);
                redirect_to(demand_admin_simple_ai_return_url(demand_wordstat_return_tab(), $scopeFilter, [], 'wordstat-dry-run-result'));
            }
            redirect_to(demand_admin_scope_filter_url(demand_wordstat_return_tab(), $scopeFilter) . '#wordstat-dry-run-result');
        } elseif ($action === 'direction_wordstat_dry_run') {
            require_permission('demand.wordstat.sync');
            if (!current_user_is_platform_admin()) {
                deny_scope_access();
            }
            if ((string) ($_POST['dry_run_only'] ?? '') !== '1' || isset($_POST['live']) || isset($_POST['confirmed'])) {
                throw new RuntimeException('Эта карточка запускает только проверку без изменения данных. Реальные данные Wordstat требуют отдельного подтверждения.');
            }
            $directionId = demand_clean_string($_POST['direction_id'] ?? '', 160);
            $packetId = demand_clean_string($_POST['packet_id'] ?? '', 120);
            $targetScope = demand_normalize_scope_id((string) ($_POST['target_scope_id'] ?? 'rent_rk'));
            $directionContext = demand_ai_workspace_context($scopeFilter);
            $directionContext['directions'] = demand_ai_build_directions($scopeFilter, $directionContext);
            $direction = demand_find_direction_by_id($directionId, $scopeFilter, $directionContext);
            if (!$direction) {
                throw new RuntimeException('Направление для проверки Wordstat не найдено.');
            }
            $seedPhrases = wordstat_parse_seed_phrases($_POST['seed_phrases'] ?? []);
            $regionIds = wordstat_parse_region_ids($_POST['region_ids'] ?? []);
            $methods = demand_direction_wordstat_normalize_methods($_POST['methods'] ?? []);
            if (!$seedPhrases) {
                throw new RuntimeException('Нужно добавить стартовые фразы перед проверкой Wordstat.');
            }
            if (!$regionIds) {
                throw new RuntimeException('Нужно выбрать регион Wordstat перед проверкой.');
            }
            if (!$methods) {
                throw new RuntimeException('Нужно выбрать методы проверки Wordstat.');
            }
            $cost = demand_direction_wordstat_cost_preview($seedPhrases, $regionIds, $methods);
            $fingerprint = demand_direction_wordstat_packet_fingerprint($seedPhrases, $regionIds, $methods);
            $postedFingerprint = demand_clean_string($_POST['packet_fingerprint'] ?? '', 160);
            if ($postedFingerprint !== '' && $postedFingerprint !== $fingerprint && empty($_POST['wordstat_workspace_editable'])) {
                throw new RuntimeException('Параметры проверки изменились. Откройте карточку Wordstat и подтвердите запуск ещё раз.');
            }
            if ($packetId === '') {
                $packetId = 'dwp_' . substr(hash('sha256', $directionId . '|' . $fingerprint), 0, 18);
            }
            $regionMap = demand_direction_wordstat_regions_by_id((array) ($directionContext['regionsCache']['regions'] ?? []));
            $regionLabels = [];
            foreach ($regionIds as $regionId) {
                $regionLabels[] = isset($regionMap[$regionId]) ? demand_direction_wordstat_region_label($regionMap[$regionId]) : ('Region #' . $regionId);
            }
            $packet = [
                'packetId' => $packetId,
                'directionId' => $directionId,
                'directionTitle' => (string) ($direction['title'] ?? ''),
                'seedPhrases' => $seedPhrases,
                'regionIds' => $regionIds,
                'regionLabels' => $regionLabels,
                'methods' => $methods,
                'estimatedRequests' => (int) ($cost['estimatedRequests'] ?? 0),
                'estimatedCostRub' => (float) ($cost['estimatedCostRub'] ?? 0.0),
                'dryRunOnly' => true,
                'liveRequiresSpecialConfirmation' => true,
                'notChangedGuarantees' => demand_direction_wordstat_not_changed_guarantees(),
                'warnings' => [],
                'budgetMode' => demand_clean_string($_POST['budget_mode'] ?? ($direction['budgetMode'] ?? 'standard'), 80),
                'packetFingerprint' => $fingerprint,
            ];
            $existing = demand_direction_wordstat_existing_dry_run($packet, $directionContext);
            if ($existing && empty($_POST['force_rebuild'])) {
                $_SESSION['demand_wordstat_latest_dry_run_id'] = (string) ($existing['id'] ?? '');
                $existing['source'] = 'wordstat';
                $existing['dryRun'] = true;
                $_SESSION['demand_wordstat_latest_dry_run_snapshot'] = $existing;
                $_SESSION['demand_flash_type'] = 'info';
                $_SESSION['demand_flash_message'] = 'Проверка Wordstat по этому направлению уже подготовлена. Данные не изменились.';
                if (demand_admin_simple_ai_return_anchor() !== '') {
                    demand_admin_set_simple_ai_workspace([
                        'activeAiTask' => 'wordstat_dry_run',
                        'activeDirectionId' => $directionId,
                        'lastResult' => [
                            'type' => 'wordstat_dry_run',
                            'title' => 'Параметры проверки не изменились',
                            'summary' => 'Используем уже подготовленный результат. Новая проверка и live не запускались.',
                        ],
                    ]);
                    redirect_to(demand_admin_simple_ai_return_url('start', $scopeFilter));
                }
                redirect_to(demand_admin_scope_filter_url('start', $scopeFilter) . '#direction-wordstat-' . rawurlencode($directionId));
            }

            $result = demand_integration_execute($action, $_POST, $scopeFilter, static function () use (
                $targetScope, $seedPhrases, $regionIds, $methods, $directionId, $direction, $packetId, $fingerprint, $scopeFilter, $packet
            ): array {
                $result = wordstat_run_dry_run($targetScope, $seedPhrases, $regionIds, $methods);
                $runId = (string) ($result['run']['id'] ?? '');
                if ($runId !== '') {
                    wordstat_patch_sync_run($runId, [
                        'directionId' => $directionId,
                        'directionTitle' => (string) ($direction['title'] ?? ''),
                        'packetId' => $packetId,
                        'packetFingerprint' => $fingerprint,
                        'packetSource' => 'ai_direction_wordstat_packet',
                        'dryRun' => true,
                        'notChangedGuarantees' => demand_direction_wordstat_not_changed_guarantees(),
                        'metadata' => [
                            'source' => 'ai_direction_wordstat_packet',
                            'directionId' => $directionId,
                            'directionTitle' => (string) ($direction['title'] ?? ''),
                            'packetId' => $packetId,
                            'packetFingerprint' => $fingerprint,
                            'dryRun' => true,
                        ],
                    ]);
                }
                $patchedRun = $runId !== ''
                    ? (demand_wordstat_sync_run_by_id($runId, $scopeFilter) ?: (array) ($result['run'] ?? []))
                    : (array) ($result['run'] ?? []);
                demand_direction_wordstat_append_dry_run_follow_up($direction, $packet, $patchedRun);
                $result['run'] = $patchedRun;
                return $result;
            });
            $runId = (string) ($result['run']['id'] ?? '');
            $patchedRun = (array) ($result['run'] ?? []);
            $_SESSION['demand_wordstat_latest_dry_run_id'] = $runId;
            $dryRunSnapshot = $patchedRun;
            foreach (['scope_id', 'seedPhrases', 'regionIds', 'methods', 'plannedRequests', 'estimatedCostRub', 'planBreakdown', 'warnings'] as $key) {
                if (!array_key_exists($key, $dryRunSnapshot) && array_key_exists($key, $result['plan'] ?? [])) {
                    $dryRunSnapshot[$key] = $result['plan'][$key];
                }
            }
            if (!array_key_exists('limitPreview', $dryRunSnapshot) && array_key_exists('limits', $result)) {
                $dryRunSnapshot['limitPreview'] = $result['limits'];
            }
            $dryRunSnapshot['source'] = 'wordstat';
            $dryRunSnapshot['dryRun'] = true;
            $dryRunSnapshot['directionId'] = $directionId;
            $dryRunSnapshot['directionTitle'] = (string) ($direction['title'] ?? '');
            $dryRunSnapshot['packetId'] = $packetId;
            $dryRunSnapshot['packetFingerprint'] = $fingerprint;
            $_SESSION['demand_wordstat_latest_dry_run_snapshot'] = $dryRunSnapshot;
            $_SESSION['demand_flash_type'] = 'success';
            $_SESSION['demand_flash_message'] = 'Проверка Wordstat без изменения данных готова для направления. Реальные данные Wordstat не загружались; фразы, рекомендации, карта спроса, sitemap.xml, robots.txt, публикация, индексация и бизнес-данные не менялись.';
            if (demand_admin_simple_ai_return_anchor() !== '') {
                demand_admin_set_simple_ai_workspace([
                    'activeAiTask' => 'wordstat_dry_run',
                    'activeDirectionId' => $directionId,
                    'lastResult' => [
                        'type' => 'wordstat_dry_run',
                        'title' => 'Проверка Wordstat без изменения данных готова',
                        'summary' => 'Live не запускался. Demand keywords, recommendations, demand map, sitemap, robots, публикация, индексация и бизнес-данные не менялись.',
                        'plannedRequests' => (int) ($dryRunSnapshot['plannedRequests'] ?? $packet['estimatedRequests'] ?? 0),
                        'estimatedCostRub' => (float) ($dryRunSnapshot['estimatedCostRub'] ?? $packet['estimatedCostRub'] ?? 0.0),
                        'directionTitle' => (string) ($direction['title'] ?? ''),
                    ],
                    'nextSafeAction' => [
                        'title' => 'Проверить готовность материалов',
                        'text' => 'Проверка без изменения данных готова. Следующий безопасный шаг: продолжить с материалами или вручную загрузить реальные данные отдельно.',
                        'button' => 'Продолжить без live',
                    ],
                ]);
                redirect_to(demand_admin_simple_ai_return_url('start', $scopeFilter));
            }
            redirect_to(demand_admin_scope_filter_url('start', $scopeFilter) . '#direction-wordstat-' . rawurlencode($directionId));
        } elseif ($action === 'wordstat_live_sync') {
            $liveDirectionId = demand_clean_string($_POST['direction_id'] ?? '', 160);
            $livePacketId = demand_clean_string($_POST['packet_id'] ?? '', 120);
            $livePacketFingerprint = demand_clean_string($_POST['packet_fingerprint'] ?? '', 160);
            $liveScope = demand_normalize_scope_id((string) ($_POST['target_scope_id'] ?? 'rent_rk'));
            $liveSeeds = (string) ($_POST['seed_phrases'] ?? '');
            $liveRegions = (string) ($_POST['region_ids'] ?? '');
            $liveMethods = (array) ($_POST['methods'] ?? []);
            $liveConfirmed = isset($_POST['confirmed']);
            $liveDirectionTitle = demand_clean_string($_POST['direction_title'] ?? '', 240);
            $result = demand_integration_execute_waiting_command(
                $action,
                $_POST,
                $scopeFilter,
                static fn(): array => wordstat_prepare_controlled_live_sync(
                    $liveScope, $liveSeeds, $liveRegions, $liveMethods, ['confirmed' => $liveConfirmed]
                ),
                static fn(array $prepared): array => wordstat_fetch_controlled_live_sync($prepared),
                static function (array $prepared, array $fetched) use (
                    $liveDirectionId, $livePacketId, $livePacketFingerprint, $liveDirectionTitle, $scopeFilter
                ): array {
                    $result = wordstat_commit_controlled_live_sync($prepared, $fetched);
                if ($liveDirectionId !== '' && !empty($result['run']['id'])) {
                    $liveContext = demand_ai_workspace_context($scopeFilter);
                    $liveContext['directions'] = demand_ai_build_directions($scopeFilter, $liveContext);
                    $liveDirection = demand_find_direction_by_id($liveDirectionId, $scopeFilter, $liveContext) ?? [
                        'directionId' => $liveDirectionId,
                        'title' => $liveDirectionTitle,
                    ];
                    wordstat_patch_sync_run((string) ($result['run']['id'] ?? ''), [
                        'directionId' => $liveDirectionId,
                        'directionTitle' => (string) ($liveDirection['title'] ?? ''),
                        'packetId' => $livePacketId,
                        'packetFingerprint' => $livePacketFingerprint,
                        'packetSource' => 'direction_wordstat_live_special_confirmation',
                        'metadata' => [
                            'source' => 'direction_wordstat_live_special_confirmation',
                            'directionId' => $liveDirectionId,
                            'directionTitle' => (string) ($liveDirection['title'] ?? ''),
                            'packetId' => $livePacketId,
                            'packetFingerprint' => $livePacketFingerprint,
                            'dryRun' => false,
                            'specialConfirmation' => $liveConfirmed,
                        ],
                    ]);
                    $result['run'] = demand_wordstat_sync_run_by_id((string) ($result['run']['id'] ?? ''), $scopeFilter) ?: $result['run'];
                    if (in_array((string) ($result['run']['status'] ?? ''), ['success', 'partial_success'], true)) {
                        demand_direction_wordstat_append_live_follow_up($liveDirection, $result, [
                            'directionId' => $liveDirectionId,
                            'directionTitle' => (string) ($liveDirection['title'] ?? ''),
                            'packetId' => $livePacketId,
                            'packetFingerprint' => $livePacketFingerprint,
                        ]);
                    }
                }
                return $result;
                }
            );
            $_SESSION['demand_flash_message'] = 'Загрузка данных Wordstat завершена: создано ' . (int) ($result['created'] ?? 0) . ', обновлено ' . (int) ($result['updated'] ?? 0) . '. Live мог обновить Wordstat-derived Demand keyword metrics/recommendations; страницы, sitemap.xml, robots.txt, публикация и индексация не менялись. Следующий безопасный шаг: пересчитать карту спроса по новым данным или открыть обновлённые рекомендации.';
            redirect_to(demand_admin_scope_filter_url(demand_wordstat_return_tab(), $scopeFilter));
        } elseif ($action === 'integration_mock_sync') {
            $source = (string) ($_POST['source'] ?? '');
            $targetScope = demand_normalize_scope_id((string) ($_POST['target_scope_id'] ?? 'rent_rk'));
            demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => demand_integrations_import_mock_metrics($source, $targetScope));
            $_SESSION['demand_flash_message'] = 'Пробная загрузка выполнена для источника ' . demand_admin_ui_label($source) . '. Внешние API не вызывались.';
            redirect_to(demand_admin_scope_filter_url('integrations', $scopeFilter));
        } elseif ($action === 'integration_build_snapshot') {
            $targetScope = current_user_is_platform_admin()
                ? demand_normalize_scope_id((string) ($_POST['target_scope_id'] ?? 'rent_rk'))
                : (demand_integrations_visible_scope_ids_for_current_user()[0] ?? '');
            if ($targetScope === '') {
                deny_scope_access();
            }
            demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => ['snapshots' => demand_integrations_build_performance_snapshot(
                $targetScope,
                (string) ($_POST['period_from'] ?? date('Y-m-01')),
                (string) ($_POST['period_to'] ?? date('Y-m-t'))
            )]);
            $_SESSION['demand_flash_message'] = 'Снимок эффективности собран из локальных и тестовых данных.';
            redirect_to(demand_admin_scope_filter_url('integrations', $scopeFilter));
        } elseif ($action === 'save_ai_api_settings') {
            demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => openai_ai_save_settings($_POST));
            $_SESSION['demand_flash_message'] = 'Настройки AI API сохранены. API key хранится только в private secrets/env и не выводится в HTML.';
            redirect_to(demand_admin_scope_filter_url('settings', $scopeFilter) . '#demand-ai-api-settings');
        } elseif ($action === 'save_ai_api_credentials') {
            $settings = demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => openai_ai_write_private_credentials($_POST));
            $_SESSION['demand_flash_type'] = !empty($settings['apiKeyConfigured']) ? 'success' : 'warning';
            $_SESSION['demand_flash_message'] = !empty($settings['apiKeyConfigured'])
                ? 'DeepSeek API key сохранён в private secrets file. Ключ не выводится в HTML, JS или журналы.'
                : 'DeepSeek credentials сохранены, но статус пока не видит API key.';
            redirect_to(demand_admin_scope_filter_url('settings', $scopeFilter) . '#demand-ai-api-settings');
        } elseif ($action === 'clear_ai_api_credentials') {
            $settings = demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => openai_ai_clear_private_credentials());
            $_SESSION['demand_flash_type'] = !empty($settings['apiKeyConfigured']) ? 'info' : 'success';
            $_SESSION['demand_flash_message'] = !empty($settings['apiKeyConfigured'])
                ? 'Private DeepSeek key удалён. AI API всё ещё видит ключ из env-переменных сервера.'
                : 'Private DeepSeek key удалён. Для работы AI API добавьте новый ключ.';
            redirect_to(demand_admin_scope_filter_url('settings', $scopeFilter) . '#demand-ai-api-settings');
        } elseif ($action === 'openai_test_connection') {
            $result = demand_integration_execute($action, $_POST, $scopeFilter, static fn(): array => openai_ai_test_connection());
            $_SESSION['demand_flash_type'] = !empty($result['ok']) ? 'success' : 'warning';
            $_SESSION['demand_flash_message'] = !empty($result['ok'])
                ? 'Проверка DeepSeek API прошла. Секреты не выводились и не записывались в журнал.'
                : 'Проверка DeepSeek API не прошла: ' . (string) ($result['message'] ?? 'ошибка подключения') . '.';
            redirect_to(demand_admin_scope_filter_url('settings', $scopeFilter) . '#demand-ai-api-settings');
        } elseif ($action === 'save_settings') {
            save_demand_settings($_POST);
            $_SESSION['demand_flash_message'] = 'Настройки спроса сохранены. Автоиндексация осталась выключенной.';
            redirect_to(demand_admin_scope_filter_url('settings', $scopeFilter));
        }
    } catch (Throwable $exception) {
        $editorialActions = [
            'preview_import', 'apply_import', 'recalculate_keyword', 'keyword_status', 'create_draft',
            'recommendation_status', 'save_draft', 'preview_text_save', 'draft_internal_links_suggest',
            'draft_internal_links_apply', 'draft_internal_links_reject', 'draft_editorial_add_block',
            'draft_editorial_add_faq', 'draft_status', 'refresh_draft_cars_preview', 'refresh_draft_cars', 'wizard_check_readiness',
            'wizard_save_admin_note', 'demand_direction_neighbor_decision', 'demand_map_recalculate',
            'demand_map_create_brief', 'demand_map_create_card_hints', 'demand_map_create_draft',
            'demand_map_plan_status',
        ];
        if ($action === 'save_settings' || in_array($action, $editorialActions, true) || in_array($action, demand_publication_actions(), true)
            || in_array($action, demand_integration_actions(), true) || in_array($action, demand_ai_content_actions(), true)) {
            http_response_code(in_array($exception->getCode(), [403, 409, 503], true) ? $exception->getCode() : 400);
        }
        $error = $exception->getMessage();
    }
}

$scopeOptions = [];
foreach (scope_list() as $scope) {
    $scopeId = (string) ($scope['scope_id'] ?? '');
    if ($scopeId !== '') {
        $scopeOptions[$scopeId] = (string) (($scope['name'] ?? '') ?: $scopeId);
    }
}
$keywords = demand_visible_keywords($scopeFilter);
$recommendations = demand_visible_recommendations($scopeFilter);
$drafts = demand_visible_drafts($scopeFilter);
$keywordsById = [];
foreach ($keywords as $keyword) {
    $keywordsById[(string) ($keyword['id'] ?? '')] = $keyword;
}
$createDraftRecommendationByKeyword = [];
foreach ($recommendations as $recommendation) {
    if ((string) ($recommendation['recommendationType'] ?? '') === 'create_landing_page_draft') {
        $createDraftRecommendationByKeyword[(string) ($recommendation['keywordId'] ?? '')] = $recommendation;
    }
}
$recommendationFilter = (string) ($_GET['filter'] ?? 'all');
if ($recommendationFilter !== 'all') {
    $recommendations = array_values(array_filter($recommendations, static function (array $item) use ($recommendationFilter): bool {
        if ($recommendationFilter === 'high') {
            return (string) ($item['priority'] ?? '') === 'high';
        }
        return (string) ($item['recommendationType'] ?? '') === $recommendationFilter;
    }));
}
$stats = demand_overview_stats($scopeFilter);
$settings = demand_settings()['rent_rk'];
$integrationSources = demand_integrations_list_sources();
$integrationRuns = demand_integrations_visible_sync_runs($scopeFilter);
$integrationErrors = demand_integrations_visible_errors($scopeFilter);
$integrationMetrics = demand_integrations_visible_metrics($scopeFilter);
$performanceSnapshots = demand_integrations_visible_performance_snapshots($scopeFilter);
$wordstatStatus = function_exists('wordstat_current_settings') ? wordstat_current_settings() : [];
$wordstatRegionsCache = function_exists('wordstat_read_regions_cache') ? wordstat_read_regions_cache() : ['regions' => [], 'lastUpdatedAt' => null];
$wordstatCostLedger = function_exists('wordstat_read_cost_ledger') ? wordstat_read_cost_ledger() : ['items' => []];
$wordstatCostTotals = function_exists('wordstat_cost_totals') ? wordstat_cost_totals() : ['dailyRequests' => 0, 'monthlyRequests' => 0, 'monthlyCostRub' => 0];
$wordstatMethods = function_exists('wordstat_supported_methods') ? wordstat_supported_methods() : [];
$wordstatDefaultSeeds = implode("\n", (array) ($wordstatStatus['defaultSeedPhrases'] ?? ['аренда авто ялта']));
$wordstatDefaultRegions = implode(', ', (array) ($wordstatStatus['defaultRegionIds'] ?? ['11470', '977']));
$wordstatRecentRuns = demand_wordstat_visible_sync_runs($scopeFilter);
$wordstatLatestDryRun = demand_wordstat_latest_dry_run($wordstatRecentRuns);
$wordstatPinnedDryRun = demand_wordstat_sync_run_by_id((string) ($_SESSION['demand_wordstat_latest_dry_run_id'] ?? ''), $scopeFilter);
if (is_array($wordstatPinnedDryRun) && !empty($wordstatPinnedDryRun['dryRun'])) {
    $wordstatRecentRuns = array_values(array_filter(
        $wordstatRecentRuns,
        static fn(array $run): bool => (string) ($run['id'] ?? '') !== (string) ($wordstatPinnedDryRun['id'] ?? '')
    ));
    array_unshift($wordstatRecentRuns, $wordstatPinnedDryRun);
}
$wordstatSessionDryRun = demand_wordstat_session_dry_run($scopeFilter);
if (is_array($wordstatSessionDryRun) && !empty($wordstatSessionDryRun['dryRun'])) {
    $wordstatRecentRuns = array_values(array_filter(
        $wordstatRecentRuns,
        static fn(array $run): bool => (string) ($run['id'] ?? '') !== (string) ($wordstatSessionDryRun['id'] ?? '')
    ));
    array_unshift($wordstatRecentRuns, $wordstatSessionDryRun);
}
$wordstatRecentErrors = array_values(array_filter($integrationErrors, static fn(array $item): bool => (string) ($item['source'] ?? '') === 'wordstat'));
$wordstatConnectionProblem = demand_wordstat_connection_problem($wordstatStatus);
$wordstatLastError = (string) ($wordstatConnectionProblem['message'] ?? '');
$wordstatLastErrorCode = (string) ($wordstatConnectionProblem['code'] ?? '');
$wordstatLastErrorAdvice = (string) ($wordstatConnectionProblem['advice'] ?? '');
$wordstatLastErrorTechnical = (string) ($wordstatConnectionProblem['technical'] ?? '');
$wordstatLastErrorAt = (string) ($wordstatConnectionProblem['updatedAt'] ?? '');
$wordstatHasConnectionProblem = !empty($wordstatConnectionProblem['hasProblem']);
$wordstatAllRegions = (array) ($wordstatRegionsCache['regions'] ?? []);
$wordstatRegionCount = count($wordstatAllRegions);
$wordstatRegionPreviewLimit = 8;
$wordstatRegions = array_slice($wordstatAllRegions, 0, $wordstatRegionPreviewLimit);
$wordstatKeyRegions = demand_wordstat_key_regions($wordstatAllRegions);
$wordstatCrimeaRegions = demand_wordstat_crimea_regions($wordstatAllRegions);
$wordstatLiveAvailable = has_permission('demand.wordstat.live')
    && !empty($wordstatStatus['enabled'])
    && (string) ($wordstatStatus['mode'] ?? '') === 'live_controlled'
    && in_array((string) ($wordstatStatus['authStatus'] ?? ''), ['configured', 'test_success'], true)
    && !empty($wordstatStatus['liveEnabled'])
    && !empty($wordstatStatus['apiKeyConfigured'])
    && !empty($wordstatStatus['folderIdConfigured'])
    && !empty($wordstatStatus['baseUrlConfigured']);
$wordstatSetupSteps = demand_wordstat_setup_steps($wordstatStatus, $wordstatRegionsCache, $wordstatRecentRuns);
$demandMapClusters = has_permission('demand.map.view') ? demand_map_visible_clusters($scopeFilter) : [];
$demandMapPlans = has_permission('demand.launch_plan.view') ? demand_map_visible_launch_plan($scopeFilter) : [];
$demandMapCardHints = has_permission('demand.card_hints.view') ? demand_map_visible_card_hints($scopeFilter) : [];
$demandMapBriefs = has_permission('demand.content_briefs.view') ? demand_map_visible_content_briefs($scopeFilter) : [];
$demandMapStats = demand_map_stats($demandMapClusters, $demandMapPlans, $demandMapCardHints);
$demandMapClustersById = [];
foreach ($demandMapClusters as $cluster) {
    $demandMapClustersById[(string) ($cluster['id'] ?? '')] = $cluster;
}
$demandMapBriefsById = [];
$demandMapBriefsByPlanId = [];
foreach ($demandMapBriefs as $brief) {
    $briefId = (string) ($brief['id'] ?? '');
    $planId = (string) ($brief['launchPlanId'] ?? '');
    if ($briefId !== '') {
        $demandMapBriefsById[$briefId] = $brief;
    }
    if ($planId !== '') {
        $demandMapBriefsByPlanId[$planId] = $brief;
    }
}
$demandMapFilter = (string) ($_GET['map_filter'] ?? 'all');
$demandMapDisplayClusters = array_values(array_filter($demandMapClusters, static function (array $cluster) use ($demandMapFilter): bool {
    return match ($demandMapFilter) {
        'high' => (string) ($cluster['priority'] ?? '') === 'high',
        'city' => (string) ($cluster['clusterType'] ?? '') === 'city',
        'car_class' => (string) ($cluster['clusterType'] ?? '') === 'car_class',
        'condition' => (string) ($cluster['clusterType'] ?? '') === 'condition',
        'blocked' => (string) ($cluster['priority'] ?? '') === 'blocked',
        'needs_business_decision' => (string) ($cluster['priority'] ?? '') === 'needs_business_decision',
        'no_matching_cars' => in_array('no_matching_cars', (array) ($cluster['riskFlags'] ?? []), true),
        'ready_draft' => !empty($cluster['linkedCars']) && empty($cluster['hasExistingPage']) && !array_intersect((array) ($cluster['riskFlags'] ?? []), ['possible_false_promise', 'condition_not_supported', 'no_matching_cars', 'region_not_confirmed', 'unknown_region', 'not_relevant_for_car_rental', 'unsupported_legal_request']),
        default => true,
    };
}));
$selectedDemandClusterId = (string) ($_GET['cluster_id'] ?? '');
$selectedDemandCluster = $selectedDemandClusterId !== '' ? ($demandMapClustersById[$selectedDemandClusterId] ?? null) : null;
$selectedDemandBriefId = (string) ($_GET['brief_id'] ?? '');
$selectedDemandBrief = $selectedDemandBriefId !== '' ? ($demandMapBriefsById[$selectedDemandBriefId] ?? null) : ($demandMapBriefs[0] ?? null);
$demandMapPlansByCluster = demand_admin_map_plan_by_cluster($demandMapPlans);
$demandDraftClusterIds = demand_admin_draft_cluster_ids($drafts);
$demandMapCardGroups = demand_admin_map_card_rows($demandMapClusters, $demandMapPlansByCluster, $demandDraftClusterIds, $demandMapBriefsByPlanId, $scopeFilter);
$demandWorkspaceState = function_exists('demand_build_workspace_state') ? demand_build_workspace_state($scopeFilter) : [];
$demandDirectionState = is_array($demandWorkspaceState['directions'] ?? null) ? $demandWorkspaceState['directions'] : [];
$demandDirectionQueue = is_array($demandDirectionState['queue'] ?? null) ? $demandDirectionState['queue'] : [];
$demandDirectionCounts = is_array($demandDirectionState['counts'] ?? null) ? $demandDirectionState['counts'] : [];
$demandWorkspacePrimaryAction = is_array($demandWorkspaceState['primaryNextAction'] ?? null) ? $demandWorkspaceState['primaryNextAction'] : [];
$demandDecisionQueue = array_values(array_filter((array) ($demandWorkspaceState['decisionQueue'] ?? []), 'is_array'));
$demandBudgetModes = is_array($demandWorkspaceState['budgetStatus']['modes'] ?? null) ? $demandWorkspaceState['budgetStatus']['modes'] : (function_exists('demand_ai_budget_modes') ? demand_ai_budget_modes() : []);
$demandRecentAiSessions = array_values(array_filter((array) ($demandWorkspaceState['recentAiSessions'] ?? []), 'is_array'));
$demandNextAction = demand_admin_next_action($stats, $demandMapClusters, $demandMapPlans, $drafts, $scopeFilter);
$demandNextAction = $demandWorkspacePrimaryAction ? array_merge($demandNextAction, [
    'title' => (string) ($demandWorkspacePrimaryAction['title'] ?? $demandNextAction['title']),
    'text' => (string) ($demandWorkspacePrimaryAction['text'] ?? $demandNextAction['text']),
    'button' => (string) ($demandWorkspacePrimaryAction['button'] ?? $demandNextAction['button']),
    'tone' => (string) ($demandWorkspacePrimaryAction['tone'] ?? $demandNextAction['tone']),
    'href' => '#demand-direction-sessions',
]) : $demandNextAction;
$demandUiMode = demand_admin_ui_mode();
$demandIsDetailedView = $demandUiMode === 'detail';
$demandIsSimpleStart = $tab === 'start' && !$demandIsDetailedView;
$demandSimpleTabs = demand_admin_simple_tabs();
$demandDraftCounts = demand_admin_draft_counts($drafts);
$demandDraftFilterOptions = demand_admin_draft_filter_options();
$demandMaterialGroups = demand_admin_material_groups($drafts, $demandMapBriefs, $demandMapCardHints, $demandMapPlans, $keywords, $scopeFilter);
$demandUserMode = demand_admin_user_mode_for_tab($tab);
$demandModeNav = [
    'master' => [
        'label' => 'Мастер спроса',
        'href' => demand_admin_scope_filter_url('start', $scopeFilter),
        'hint' => 'задача, прогресс, следующий шаг',
    ],
    'materials' => [
        'label' => 'Материалы',
        'href' => demand_admin_scope_filter_url('materials', $scopeFilter),
        'hint' => 'черновики, ТЗ, FAQ, подсказки',
    ],
    'technical' => [
        'label' => 'Техническое',
        'href' => demand_admin_scope_filter_url('technical', $scopeFilter),
        'hint' => 'логи, Wordstat, AI API, raw-данные',
    ],
];
$draftFilter = (string) ($_GET['draft_filter'] ?? 'all');
if (!isset($demandDraftFilterOptions[$draftFilter])) {
    $draftFilter = 'all';
}
$draftDisplayRows = array_values(array_filter($drafts, static fn(array $draft): bool => demand_admin_draft_matches_filter($draft, $draftFilter)));
$demandStageNavItems = demand_admin_stage_nav_items($stats, $demandMapPlans, $drafts, $scopeFilter);
$demandAiLatestPackage = is_array($_SESSION['demand_ai_latest_package'] ?? null) ? $_SESSION['demand_ai_latest_package'] : null;
$demandAiLatestPreview = is_array($_SESSION['demand_ai_latest_preview'] ?? null) ? $_SESSION['demand_ai_latest_preview'] : null;
$demandAiApiSettings = function_exists('openai_ai_settings') ? openai_ai_settings() : [];
$demandAiApiLatest = is_array($_SESSION['demand_ai_api_latest'] ?? null) ? $_SESSION['demand_ai_api_latest'] : null;
$demandCarHintAiFallback = is_array($_SESSION['demand_car_hint_ai_fallback'] ?? null) ? $_SESSION['demand_car_hint_ai_fallback'] : null;
$demandAiCopyLatest = is_array($_SESSION['demand_ai_copy_latest'] ?? null) ? $_SESSION['demand_ai_copy_latest'] : null;
$demandSimpleAiWorkspace = demand_admin_simple_ai_workspace_state($demandWorkspaceState);
if ($tab === 'demand_map' && isset($_GET['export'])) {
    $export = (string) $_GET['export'];
    $rows = demand_map_export_rows($demandMapPlans);
    if ($export === 'json') {
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="seo-launch-plan.json"');
        echo json_encode(['items' => $rows, 'exportedAt' => now_iso()], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }
    if ($export === 'csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="seo-launch-plan.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['cluster', 'priority', 'action', 'reason', 'risk', 'linkedCars', 'status']);
        foreach ($rows as $row) {
            fputcsv($out, $row);
        }
        fclose($out);
        exit;
    }
    if ($export === 'print') {
        header('Content-Type: text/html; charset=utf-8');
        ?><!doctype html><html lang="ru"><meta charset="utf-8"><title>План страниц</title><style>body{font-family:Arial,sans-serif;margin:24px;color:#263238}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:8px;text-align:left;vertical-align:top}th{background:#f4f4f4}</style><h1>План страниц</h1><table><thead><tr><th>Группа запросов</th><th>Приоритет</th><th>Действие</th><th>Причина</th><th>Риск</th><th>Авто</th><th>Статус</th></tr></thead><tbody><?php foreach ($rows as $row): ?><tr><td><?= e($row['cluster']) ?></td><td><?= e($row['priority']) ?></td><td><?= e($row['action']) ?></td><td><?= e($row['reason']) ?></td><td><?= e($row['risk']) ?></td><td><?= e($row['linkedCars']) ?></td><td><?= e($row['status']) ?></td></tr><?php endforeach; ?></tbody></table></html><?php
        exit;
    }
}
$previewDraft = null;
if (isset($_GET['preview_draft'])) {
    $previewDraft = demand_find_draft((string) $_GET['preview_draft']);
    if ($previewDraft) {
        demand_scope_guard($previewDraft, 'demand.view');
    }
}
$editDraft = null;
if (isset($_GET['edit_draft'])) {
    $editDraft = demand_find_draft((string) $_GET['edit_draft']);
    if ($editDraft) {
        demand_scope_guard($editDraft, 'demand.drafts.edit');
    }
} elseif ($refreshCarsPreview !== null && (string) ($refreshCarsPreview['draftId'] ?? '') !== '') {
    $editDraft = demand_find_draft((string) $refreshCarsPreview['draftId']);
    if ($editDraft) {
        demand_scope_guard($editDraft, 'demand.drafts.edit');
    }
}
$demandAiDialogState = function_exists('demand_ai_dialog_state') ? demand_ai_dialog_state() : ['messages' => [], 'workflow' => null, 'lastResult' => null];
$demandAiDialogWorkflow = is_array($demandAiDialogState['workflow'] ?? null) ? $demandAiDialogState['workflow'] : [];
$demandBroadDirectionQueue = is_array($demandAiDialogWorkflow['broadDirectionQueue'] ?? null) ? $demandAiDialogWorkflow['broadDirectionQueue'] : [];
$demandBroadRecommendedDirectionId = !empty($demandAiDialogWorkflow['requiresDirectionSelection'])
    ? (string) ($demandBroadDirectionQueue['recommendedDirectionId'] ?? '')
    : '';
$demandAutoOpenDirectionId = (string) ($_SESSION['demand_direction_open_modal'] ?? '');
unset($_SESSION['demand_direction_open_modal']);
if ($demandAutoOpenDirectionId === '' && $demandBroadRecommendedDirectionId !== '') {
    $demandAutoOpenDirectionId = $demandBroadRecommendedDirectionId;
}
$demandLimitWorkflow = ((string) ($demandAiDialogWorkflow['stopReason'] ?? '') === 'budget_limit_reached') ? $demandAiDialogWorkflow : [];
$demandAiDialogEntityType = '';
$demandAiDialogEntityId = '';
if (is_array($editDraft)) {
    $demandAiDialogEntityType = 'draft';
    $demandAiDialogEntityId = (string) ($editDraft['id'] ?? '');
} elseif (is_array($previewDraft)) {
    $demandAiDialogEntityType = 'draft';
    $demandAiDialogEntityId = (string) ($previewDraft['id'] ?? '');
} elseif (is_array($selectedDemandBrief)) {
    $demandAiDialogEntityType = 'content_brief';
    $demandAiDialogEntityId = (string) ($selectedDemandBrief['id'] ?? '');
} elseif (is_array($selectedDemandCluster)) {
    $demandAiDialogEntityType = 'demand_cluster';
    $demandAiDialogEntityId = (string) ($selectedDemandCluster['id'] ?? '');
}

admin_header('Спрос', 'demand');
?>
<section class="page-head demand-page-head">
  <div>
    <p class="eyebrow">Маркетинг</p>
    <h1>Спрос</h1>
    <?php if ($demandIsSimpleStart): ?>
      <p class="muted">AI помогает проверить спрос, подготовить тексты, ссылки и решения. Вы решаете, что применять. Данные сайта не меняются.</p>
    <?php else: ?>
      <p class="muted">AI-мастер помогает подготовить страницы: собирает запросы, чистит мусор, делает план, создает ТЗ и безопасные черновики. Технические детали спрятаны отдельно.</p>
    <?php endif; ?>
  </div>
  <div class="actions">
    <?php if ($demandIsSimpleStart): ?>
      <a class="btn" href="#simple-ai-workspace"><?= admin_icon('ai-assistant', 'rr-action-icon') ?>Начать с AI</a>
      <a class="btn secondary" href="#simple-ai-decisions-summary"><?= admin_icon('decision', 'rr-action-icon') ?>Открыть решения</a>
      <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('technical', $scopeFilter)) ?>"><?= admin_icon('settings', 'rr-action-icon') ?>Технический вид</a>
    <?php else: ?>
      <?php if (function_exists('demand_ai_dialog_can_access') && demand_ai_dialog_can_access()): ?>
        <button class="btn" type="button" data-demand-ai-dialog-open data-demand-ai-dialog-prompt="Собери запросы по теме аренды авто по городам Крыма, очисти лишнее, предложи действия, расставь по приоритету и подготовь материалы."><?= admin_icon('ai-assistant', 'rr-action-icon') ?>Собрать спрос по городам Крыма</button>
      <?php endif; ?>
      <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => 'all'])) ?>#demand-drafts-worklist"><?= admin_icon('drafts', 'rr-action-icon') ?>Готовые черновики</a>
      <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter)) ?>#seo-launch-plan"><?= admin_icon('sitemap', 'rr-action-icon') ?>Подготовить план страниц</a>
    <?php endif; ?>
  </div>
</section>

<?php if ($message): ?><div class="notice <?= e($messageType) ?>"><?= e($message) ?></div><?php endif; ?>
<?php if ($error): ?><?= admin_error_notice($error) ?><?php endif; ?>

<?php if (!$demandIsSimpleStart): ?>
  <nav class="demand-mode-nav" aria-label="Режимы раздела спроса">
    <?php foreach ($demandModeNav as $modeKey => $modeItem): ?>
      <a class="<?= $demandUserMode === $modeKey ? 'is-active' : '' ?>" href="<?= e((string) ($modeItem['href'] ?? '#')) ?>">
        <strong><?= e((string) ($modeItem['label'] ?? '')) ?></strong>
        <span><?= e((string) ($modeItem['hint'] ?? '')) ?></span>
      </a>
    <?php endforeach; ?>
  </nav>

  <section class="demand-guard-strip">
    <div><strong>Безопасно начинать</strong><span>Фразы, карта спроса и советы не публикуют страницы сами.</span></div>
    <div><strong>Поиск под контролем</strong><span>Сначала страница открывается только для просмотра, потом вручную для поиска.</span></div>
    <div><strong>Без автопубликации</strong><span>Wordstat не меняет карту сайта, robots.txt и статусы страниц.</span></div>
  </section>

  <section class="demand-quick-access" id="demand-quick-access" aria-label="Быстрый доступ">
    <div class="demand-quick-access-head">
      <div>
        <span>Быстрый доступ</span>
        <strong>Куда перейти прямо сейчас</strong>
      </div>
      <div class="demand-quick-access-actions">
        <a class="btn" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => 'all'])) ?>#demand-drafts-worklist"><?= admin_icon('drafts', 'rr-action-icon') ?>Открыть готовые черновики</a>
        <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter)) ?>#seo-launch-plan"><?= admin_icon('sitemap', 'rr-action-icon') ?>Открыть план страниц</a>
        <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter)) ?>#demand-map-clusters"><?= admin_icon('demand', 'rr-action-icon') ?>Открыть карту спроса</a>
        <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('import', $scopeFilter)) ?>"><?= admin_icon('upload', 'rr-action-icon') ?>Загрузить фразы</a>
        <?php if (function_exists('demand_ai_dialog_can_access') && demand_ai_dialog_can_access()): ?>
          <button class="btn secondary" type="button" data-demand-ai-dialog-open><?= admin_icon('ai-assistant', 'rr-action-icon') ?>Спросить AI</button>
        <?php endif; ?>
      </div>
    </div>
    <div class="demand-quick-draft-counters" aria-label="Счётчики черновиков">
      <span>Всего <strong><?= e((string) $demandDraftCounts['all']) ?></strong></span>
      <span>Требуют правок <strong><?= e((string) $demandDraftCounts['needs_fixes']) ?></strong></span>
      <span>Готовы к просмотру <strong><?= e((string) $demandDraftCounts['ready_preview']) ?></strong></span>
      <span>Опубликованы для просмотра <strong><?= e((string) $demandDraftCounts['noindex_preview']) ?></strong></span>
      <span>Готовы к поиску <strong><?= e((string) $demandDraftCounts['ready_search']) ?></strong></span>
    </div>
  </section>

  <nav class="demand-stage-nav" aria-label="Этапы работы со спросом">
    <?php foreach ($demandStageNavItems as $index => $stageItem): ?>
      <a class="is-<?= e((string) ($stageItem['state'] ?? 'pending')) ?>" href="<?= e((string) ($stageItem['href'] ?? '#')) ?>">
        <span><?= (int) $index + 1 ?></span>
        <strong><?= e((string) ($stageItem['label'] ?? '')) ?></strong>
        <small><?= e((string) ($stageItem['hint'] ?? '')) ?></small>
      </a>
    <?php endforeach; ?>
  </nav>
<?php endif; ?>

<?php if (!$demandIsSimpleStart): ?>
  <div class="demand-toolbar">
    <nav class="demand-tabs" aria-label="Разделы спроса">
      <?php foreach ($tabs as $key => $label): ?>
        <?php if ($key === 'settings' && !has_permission('demand.settings.manage') && !has_permission('demand.ai_api.settings.manage') && !has_permission('demand.ai_api.logs.view')) { continue; } ?>
        <?php if ($key === 'integrations' && !has_permission('demand.integrations.view') && !has_permission('demand.performance.view')) { continue; } ?>
        <?php if ($key === 'demand_map' && !has_permission('demand.map.view')) { continue; } ?>
        <?php if ($key === 'wordstat_help' && !has_permission('demand.wordstat.view') && !has_permission('demand.wordstat.manage')) { continue; } ?>
        <?php if (!$demandIsDetailedView && !isset($demandSimpleTabs[$key])) { continue; } ?>
        <a class="<?= $key === $tab ? 'is-active' : '' ?>" href="<?= e(demand_admin_scope_filter_url($key, $scopeFilter)) ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
    <nav class="demand-view-switch" aria-label="Режим отображения">
      <a class="<?= !$demandIsDetailedView ? 'is-active' : '' ?>" href="<?= e(demand_admin_scope_filter_url($tab, $scopeFilter, ['view' => 'simple'])) ?>">Простой вид</a>
      <a class="<?= $demandIsDetailedView ? 'is-active' : '' ?>" href="<?= e(demand_admin_scope_filter_url($tab, $scopeFilter, ['view' => 'detail'])) ?>">Подробный вид</a>
    </nav>
    <?php if (current_user_is_platform_admin()): ?>
      <form method="get" class="demand-scope-filter">
        <input type="hidden" name="tab" value="<?= e($tab) ?>">
        <input type="hidden" name="view" value="<?= e($demandUiMode) ?>">
        <label>
          Контур
          <select name="scope" onchange="this.form.submit()">
            <option value="all" <?= $scopeFilter === 'all' ? 'selected' : '' ?>>Все контуры</option>
            <?php foreach ($scopeOptions as $scopeId => $scopeLabel): ?>
              <option value="<?= e($scopeId) ?>" <?= $scopeFilter === $scopeId ? 'selected' : '' ?>><?= e($scopeLabel) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
      </form>
    <?php endif; ?>
  </div>
<?php endif; ?>

<?php if (!$demandIsSimpleStart && !empty($tabDescriptions[$tab])): ?>
  <p class="demand-tab-description"><?= e($tabDescriptions[$tab]) ?></p>
<?php endif; ?>

<?php if ($tab !== 'start'): ?>
  <section class="demand-next-action demand-next-action-global is-<?= e((string) ($demandNextAction['tone'] ?? 'safe')) ?>">
    <div>
      <span>Следующее действие</span>
      <strong><?= e((string) $demandNextAction['title']) ?></strong>
      <p><?= e((string) $demandNextAction['text']) ?></p>
    </div>
    <a class="btn secondary" href="<?= e((string) $demandNextAction['href']) ?>"><?= admin_icon(admin_action_icon_for_href((string) $demandNextAction['href'], 'open'), 'rr-action-icon') ?><?= e((string) $demandNextAction['button']) ?></a>
  </section>
<?php endif; ?>

<?php
$demandAiApiScreenTasks = match ($tab) {
    'start' => [
        'explain_current_screen' => 'Объясни, что делать дальше',
        'suggest_next_step' => 'Составь простой план на сегодня',
    ],
    'import' => [
        'summarize_import_preview' => 'Объясни результат загрузки',
        'suggest_next_step' => 'Что из этого полезно?',
        'check_false_promises' => 'Какие запросы нельзя использовать?',
    ],
    'keywords' => [
        'explain_current_screen' => 'Объясни эти фразы',
        'prioritize_launch_plan' => 'Какие фразы важнее?',
        'suggest_next_step' => 'Что можно игнорировать?',
    ],
    'demand_map' => [
        'explain_demand_map' => 'Объясни карту спроса',
        'prioritize_launch_plan' => 'С чего начать подготовку страниц?',
        'check_false_promises' => 'Где риски?',
    ],
    'recommendations' => [
        'explain_recommendation' => 'Объясни рекомендации',
        'suggest_next_step' => 'Что сделать дальше?',
    ],
    'drafts' => [
        'improve_landing_draft' => 'Что исправить в черновике?',
        'prepare_publication_checklist' => 'Проверь страницу перед публикацией',
        'create_faq' => 'Собери FAQ',
    ],
    default => [],
};
if ($demandAiApiScreenTasks && $demandIsDetailedView) {
    demand_admin_ai_api_render_panel($tab, $scopeFilter, $demandAiApiScreenTasks, '', '', $demandAiApiLatest, $demandAiApiSettings);
}
?>

<?php if ($tab === 'start'): ?>
  <?php
    $masterWorkflow = is_array($demandAiDialogState['workflow'] ?? null) ? $demandAiDialogState['workflow'] : null;
    $masterWorkflowCounts = demand_admin_workflow_counts($masterWorkflow);
    $masterPriorityGroups = $demandMapCardGroups['first'] ?? [];
    $masterDecisionGroups = $demandMapCardGroups['decision'] ?? [];
    $masterNoGroups = $demandMapCardGroups['no'] ?? [];
  ?>
  <?php if ($demandIsDetailedView): ?>
  <article class="panel demand-master-panel" id="demand-master">
    <div class="demand-master-layout">
      <section class="demand-master-task">
        <span class="eyebrow">Мастер спроса</span>
        <h2>Напишите задачу, а AI разложит рутину по шагам</h2>
        <p class="muted">Например: “Собери запросы по аренде авто по городам Крыма, очисти лишнее, предложи действия, расставь по приоритету и подготовь черновики”.</p>
        <?php if (function_exists('demand_ai_dialog_can_access') && demand_ai_dialog_can_access()): ?>
          <form method="post" class="form-stack demand-master-ai-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="start">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_ai_dialog_ask">
            <?= demand_ai_content_command_fields('demand_ai_dialog_ask') ?>
            <input type="hidden" name="context_tab" value="start">
            <textarea name="ai_dialog_message" rows="4">Собери запросы по теме аренды авто по городам Крыма, после этого предложи какие действия можно сделать и расположи их в порядке приоритета.</textarea>
            <button class="btn" type="submit">Запустить AI-мастер</button>
          </form>
        <?php else: ?>
          <div class="notice warning">AI-мастер недоступен для текущей роли.</div>
        <?php endif; ?>
        <div class="demand-master-scenarios">
          <?php foreach ([
            'Собрать спрос по городам Крыма' => 'Собери запросы по теме аренды авто по городам Крыма, очисти лишнее, предложи действия и расставь их по приоритету.',
            'Подготовить план страниц' => 'Подготовь план страниц по самым важным направлениям спроса. Не публикуй страницы и не открывай индексацию.',
            'Найти мусорные запросы' => 'Найди мусорные запросы: такси, трансфер, покупка авто, ремонт, запчасти, работа водителем, каршеринг, аренда жилья, без прав, без паспорта, без договора.',
            'Подготовить ТЗ' => 'Подготовь безопасные ТЗ по самым приоритетным пунктам плана спроса.',
            'Создать безопасные черновики' => 'Подготовь безопасные черновики только для пунктов без критических рисков. Черновики должны остаться draft и blocked.',
            'Оживить тексты черновиков' => 'Оживи тексты черновиков: спокойно, для обычного человека, без SEO-простыни и без неподтвержденных обещаний.',
            'Проверить риски' => 'Проверь риски по текущему плану спроса: залог, аэропорт, неподтвержденные города, цены, наличие авто и юридические ограничения.',
          ] as $label => $prompt): ?>
            <button class="btn secondary small" type="button" data-demand-ai-dialog-open data-demand-ai-dialog-prompt="<?= e($prompt) ?>"><?= e($label) ?></button>
          <?php endforeach; ?>
        </div>
      </section>

      <section class="demand-master-now">
        <h3>AI уже подготовил</h3>
        <div class="demand-master-metrics">
          <span>Фраз <strong><?= e((string) $masterWorkflowCounts['keywords']) ?></strong></span>
          <span>Отсеяно <strong><?= e((string) $masterWorkflowCounts['excluded']) ?></strong></span>
          <span>ТЗ <strong><?= e((string) ($masterWorkflowCounts['briefs'] ?: count($demandMapBriefs))) ?></strong></span>
          <span>Черновиков <strong><?= e((string) ($masterWorkflowCounts['drafts'] ?: $demandDraftCounts['all'])) ?></strong></span>
          <span>Подсказок <strong><?= e((string) ($masterWorkflowCounts['hints'] ?: count($demandMapCardHints))) ?></strong></span>
        </div>
        <p class="field-hint">Фразы, предложенные AI, считаются идеями для проверки и не являются подтверждённой частотностью. Для реальной частотности проверьте их через Wordstat.</p>
      </section>
    </div>
  </article>

  <section class="demand-next-action is-<?= e((string) ($demandNextAction['tone'] ?? 'safe')) ?>">
    <div>
      <span>Что делать дальше</span>
      <strong><?= e((string) $demandNextAction['title']) ?></strong>
      <p><?= e((string) $demandNextAction['text']) ?></p>
    </div>
    <a class="btn" href="<?= e((string) $demandNextAction['href']) ?>"><?= e((string) $demandNextAction['button']) ?></a>
  </section>
  <?php endif; ?>

  <?php if (!empty($demandAiDialogWorkflow['requiresDirectionSelection']) && $demandBroadDirectionQueue): ?>
    <section class="panel demand-direction-broad-route" data-demand-direction-auto-open="<?= e($demandBroadRecommendedDirectionId) ?>">
      <div class="panel-head">
        <div>
          <span class="eyebrow">AI не запускает широкий workflow</span>
          <h2>Широкая задача разбита на направления</h2>
          <p class="muted">Чтобы не тратить лимиты впустую, AI сначала предлагает очередь. Рекомендуем начать с “<?= e((string) ($demandBroadDirectionQueue['recommendedDirectionTitle'] ?? 'первого направления')) ?>” в режиме economy.</p>
        </div>
        <?php if ($demandBroadRecommendedDirectionId !== ''): ?>
          <button class="btn" type="button" data-demand-direction-modal-open="<?= e($demandBroadRecommendedDirectionId) ?>">Открыть запуск</button>
        <?php endif; ?>
      </div>
      <div class="demand-direction-queue">
        <?php foreach (array_slice((array) ($demandBroadDirectionQueue['directions'] ?? []), 0, 5) as $direction): ?>
          <?php if (!is_array($direction)) { continue; } ?>
          <button class="demand-direction-row" type="button" data-demand-direction-modal-open="<?= e((string) ($direction['directionId'] ?? '')) ?>">
            <span><?= e((string) ($direction['title'] ?? 'Направление спроса')) ?></span>
            <small><?= e(demand_admin_direction_priority_label((string) ($direction['priority'] ?? 'medium'))) ?> · AI начнёт только после подтверждения</small>
          </button>
        <?php endforeach; ?>
      </div>
    </section>
  <?php endif; ?>

  <?php
    $currentDirection = is_array($demandDirectionState['current'] ?? null) ? $demandDirectionState['current'] : [];
    $nextDirection = is_array($demandDirectionState['next'] ?? null) ? $demandDirectionState['next'] : [];
    $preparedDirections = array_slice(array_values(array_filter((array) ($demandDirectionQueue['prepared'] ?? []), 'is_array')), 0, 4);
    $decisionDirections = array_slice(array_values(array_filter((array) ($demandDirectionQueue['needs_decision'] ?? []), 'is_array')), 0, 4);
    $staleDirections = array_slice(array_values(array_filter((array) ($demandDirectionQueue['stale'] ?? []), 'is_array')), 0, 4);
    $queuePreview = array_slice(array_values(array_filter(array_merge(
        (array) ($demandDirectionQueue['next'] ?? []),
        (array) ($demandDirectionQueue['backlog'] ?? []),
        (array) ($demandDirectionQueue['prepared'] ?? [])
    ), 'is_array')), 0, 8);
    $modalDirectionsById = [];
    foreach (array_merge([$currentDirection, $nextDirection], $queuePreview, $decisionDirections, $staleDirections) as $direction) {
        if (is_array($direction) && (string) ($direction['directionId'] ?? '') !== '') {
            $modalDirectionsById[(string) $direction['directionId']] = $direction;
        }
    }
    $allDirectionsById = $modalDirectionsById;
    foreach ((array) ($demandDirectionQueue ?? []) as $queueItems) {
        foreach ((array) $queueItems as $direction) {
            if (is_array($direction) && (string) ($direction['directionId'] ?? '') !== '') {
                $allDirectionsById[(string) $direction['directionId']] = $direction;
            }
        }
    }
    foreach ((array) ($demandBroadDirectionQueue['directions'] ?? []) as $direction) {
        if (is_array($direction) && (string) ($direction['directionId'] ?? '') !== '') {
            $allDirectionsById[(string) $direction['directionId']] = $direction;
            $modalDirectionsById[(string) $direction['directionId']] = $direction;
        }
    }
    if ($demandLimitWorkflow && is_array($demandLimitWorkflow['directionSession'] ?? null)) {
        $limitSession = $demandLimitWorkflow['directionSession'];
        $limitId = (string) ($limitSession['directionId'] ?? '');
        if ($limitId !== '' && !isset($modalDirectionsById[$limitId])) {
            $modalDirectionsById[$limitId] = [
                'directionId' => $limitId,
                'title' => (string) ($limitSession['directionTitle'] ?? 'Направление спроса'),
                'priority' => 'medium',
                'status' => 'not_started',
                'budgetMode' => (string) ($limitSession['budgetMode'] ?? 'economy'),
                'processingFingerprint' => (string) ($limitSession['processingFingerprint'] ?? ''),
                'nextAction' => ['actionKey' => 'direction_start_confirm', 'label' => 'Запустить AI-сессию'],
            ];
        }
    }
    foreach ($demandDecisionQueue as $decision) {
        foreach ((array) ($decision['relatedObjectIds']['neighborDirections'] ?? []) as $neighborId) {
            $neighborId = (string) $neighborId;
            if (isset($allDirectionsById[$neighborId])) {
                $modalDirectionsById[$neighborId] = $allDirectionsById[$neighborId];
            }
        }
    }
    $demandDirectionWordstatContext = [
        'scopeFilter' => $scopeFilter,
        'scopeIds' => demand_current_scope_filter($scopeFilter),
        'keywords' => $keywords,
        'syncRuns' => $wordstatRecentRuns,
        'regionsCache' => $wordstatRegionsCache,
        'directions' => array_values($allDirectionsById),
    ];
    $demandDirectionWordstatPackets = [];
    foreach ($modalDirectionsById as $packetDirection) {
        if (!is_array($packetDirection)) {
            continue;
        }
        $packetDirectionId = (string) ($packetDirection['directionId'] ?? '');
        if ($packetDirectionId !== '' && function_exists('demand_build_direction_wordstat_packet')) {
            $demandDirectionWordstatPackets[$packetDirectionId] = demand_build_direction_wordstat_packet(
                $packetDirection,
                $scopeFilter,
                (string) ($packetDirection['budgetMode'] ?? 'standard'),
                $demandDirectionWordstatContext
            );
        }
    }
    $workspaceDraft = demand_admin_simple_workspace_primary_draft($drafts);
    $workspaceDraftId = is_array($workspaceDraft) ? (string) ($workspaceDraft['id'] ?? '') : '';
    $workspaceHint = demand_admin_simple_workspace_primary_hint($demandMapCardHints);
    $workspaceHintId = is_array($workspaceHint) ? (string) ($workspaceHint['id'] ?? '') : '';
    $workspaceDirectionId = (string) ($currentDirection['directionId'] ?? ($nextDirection['directionId'] ?? ''));
    $workspaceWordstatModalId = $workspaceDirectionId !== '' ? 'wordstat-' . $workspaceDirectionId : '';
    $workspaceWordstatPacket = $workspaceDirectionId !== '' ? ($demandDirectionWordstatPackets[$workspaceDirectionId] ?? null) : null;
    $workspaceEditable = is_array($demandSimpleAiWorkspace['editableProposal'] ?? null) ? (array) $demandSimpleAiWorkspace['editableProposal'] : [];
    $workspaceLastResult = is_array($demandSimpleAiWorkspace['lastResult'] ?? null) ? (array) $demandSimpleAiWorkspace['lastResult'] : [];
    $workspaceHistory = array_values(array_filter((array) ($demandSimpleAiWorkspace['history'] ?? []), 'is_array'));
    $workspaceInternalLinksState = is_array($_SESSION['demand_internal_links_latest'] ?? null) ? (array) $_SESSION['demand_internal_links_latest'] : [];
    $workspaceInternalLinkSuggestions = array_values(array_filter((array) ($workspaceInternalLinksState['suggestions']['internalLinkSuggestions'] ?? []), 'is_array'));
    $workspaceDraftInternalLinks = is_array($workspaceDraft) ? demand_normalize_internal_links($workspaceDraft['internalLinks'] ?? []) : [];
    $workspacePrimaryAction = $demandWorkspacePrimaryAction ?: [
        'title' => (string) ($demandNextAction['title'] ?? 'Выберите задачу'),
        'text' => (string) ($demandNextAction['text'] ?? 'AI покажет результат здесь и остановится перед применением.'),
        'button' => (string) ($demandNextAction['button'] ?? 'Продолжить подготовку'),
        'href' => (string) ($demandNextAction['href'] ?? '#simple-ai-workspace'),
    ];
    $workspacePrimaryDirectionId = (string) ($workspacePrimaryAction['directionId'] ?? '');
    $workspacePrimaryActionKey = (string) ($workspacePrimaryAction['actionKey'] ?? '');
    $workspacePrimaryModalTarget = '';
    if ($workspacePrimaryDirectionId !== '') {
        $workspacePrimaryModalTarget = in_array($workspacePrimaryActionKey, ['wordstat_dry_run_ready', 'open_wordstat_dry_run_result', 'direction_wordstat_dry_run_confirm'], true)
            ? 'wordstat-' . $workspacePrimaryDirectionId
            : $workspacePrimaryDirectionId;
    }
    $workspaceDirectionCount = max((int) ($demandDirectionCounts['prepared'] ?? 0), count($allDirectionsById));
    $workspaceWordstatCheckCount = count(array_filter($wordstatRecentRuns, 'is_array'));
    $workspacePreparedSummary = [
        ['label' => 'направлений', 'count' => $workspaceDirectionCount],
        ['label' => 'текста', 'count' => (int) ($demandDraftCounts['all'] ?? 0)],
        ['label' => 'проверки Wordstat', 'count' => $workspaceWordstatCheckCount],
        ['label' => 'подсказки для авто', 'count' => count($demandMapCardHints)],
    ];
    $workspaceDecisionPreview = array_slice($demandDecisionQueue, 0, 2);
  ?>
  <?php if (!$demandIsDetailedView): ?>
    <section class="panel demand-simple-ai-workspace" id="simple-ai-workspace" data-simple-ai-workspace>
      <div class="panel-head">
        <div>
          <span class="eyebrow">Простой вид: одно окно AI</span>
          <h2>AI-помощник</h2>
          <p class="muted">Поставьте задачу — AI подготовит безопасный вариант, а вы решите, применять его или нет.</p>
        </div>
        <span class="status status-service">просто и эффективно</span>
      </div>

      <div class="demand-simple-ai-grid demand-simple-ai-first-screen">
        <section class="demand-simple-ai-task">
          <h3>Задача</h3>
          <?php if (function_exists('demand_ai_dialog_can_access') && demand_ai_dialog_can_access()): ?>
            <form method="post" class="form-stack">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="start">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="demand_ai_dialog_ask">
              <?= demand_ai_content_command_fields('demand_ai_dialog_ask') ?>
              <input type="hidden" name="context_tab" value="start">
              <input type="hidden" name="return_anchor" value="simple-ai-workspace">
              <div class="demand-simple-ai-input-row">
                <textarea name="ai_dialog_message" rows="2" placeholder="Опишите, что нужно сделать..."></textarea>
                <button class="btn" type="submit">Начать</button>
              </div>
            </form>
            <div class="demand-simple-ai-scenarios">
              <?php foreach ([
                  'Проверить спрос' => 'Проверь спрос через Wordstat по текущему направлению без изменения данных.',
                  'Сформировать текст' => 'Сформируй безопасный текстовый вариант для текущего черновика без SEO-переспама и неподтверждённых обещаний.',
                  'Подобрать ссылки' => 'Подбери безопасные внутренние ссылки для текущего черновика.',
                  'Открыть решения' => null,
                  'Проверить готовность' => 'Проверь готовность текущих материалов и покажи следующий безопасный шаг.',
              ] as $label => $prompt): ?>
                <?php if ($prompt === null): ?>
                  <a class="btn secondary small" href="#simple-ai-decisions-summary"><?= e($label) ?></a>
                <?php else: ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="start">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="action" value="demand_ai_dialog_ask">
                    <?= demand_ai_content_command_fields('demand_ai_dialog_ask') ?>
                    <input type="hidden" name="context_tab" value="start">
                    <input type="hidden" name="return_anchor" value="simple-ai-workspace">
                    <textarea name="ai_dialog_message" hidden><?= e($prompt) ?></textarea>
                    <button class="btn secondary small" type="submit"><?= e($label) ?></button>
                  </form>
                <?php endif; ?>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <div class="notice warning">AI-помощник недоступен для текущей роли.</div>
          <?php endif; ?>
        </section>

        <section class="demand-simple-ai-next demand-simple-ai-main-action" data-simple-ai-primary-action>
          <div>
            <span class="eyebrow">Главное сейчас</span>
            <h3><?= e((string) ($workspacePrimaryAction['title'] ?? 'Продолжить подготовку')) ?></h3>
            <p><?= e((string) ($workspacePrimaryAction['text'] ?? 'AI покажет результат здесь и остановится перед применением.')) ?></p>
          </div>
          <dl>
            <div><dt>Почему важно</dt><dd>Это следующий безопасный шаг, который двигает спрос без изменения данных сайта.</dd></div>
            <div><dt>AI уже подготовил</dt><dd><?= e((string) ($currentDirection['title'] ?? $nextDirection['title'] ?? 'контекст спроса и материалы')) ?></dd></div>
            <div><dt>Что изменится</dt><dd>Только подготовительная проверка или черновой вариант после вашего действия.</dd></div>
            <div><dt>Что не изменится</dt><dd>Публикация, индексация, sitemap и robots; Wordstat live не запускается; цены, залоги, авто и бизнес-данные не меняются.</dd></div>
          </dl>
          <?php if ($workspacePrimaryModalTarget !== ''): ?>
            <button class="btn" type="button" data-demand-direction-modal-open="<?= e($workspacePrimaryModalTarget) ?>"><?= e((string) ($workspacePrimaryAction['button'] ?? 'Продолжить подготовку')) ?></button>
          <?php else: ?>
            <a class="btn" href="<?= e((string) ($workspacePrimaryAction['href'] ?? '#simple-ai-workspace')) ?>"><?= e((string) ($workspacePrimaryAction['button'] ?? 'Продолжить подготовку')) ?></a>
          <?php endif; ?>
        </section>
      </div>

      <details class="demand-simple-ai-extra-actions">
        <summary>Ещё быстрые действия</summary>
        <div class="demand-simple-ai-actions-row">
        <?php if (is_array($workspaceDraft) && $workspaceDraftId !== '' && (has_permission('demand.ai_api.use') || has_permission('demand.ai.package'))): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="start">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_ai_copy_regenerate">
            <?= demand_ai_content_command_fields('demand_ai_copy_regenerate', 'draft', $workspaceDraftId) ?>
            <input type="hidden" name="draft_id" value="<?= e($workspaceDraftId) ?>">
            <input type="hidden" name="ai_copy_task" value="regenerate_landing_draft_human">
            <input type="hidden" name="return_anchor" value="simple-ai-workspace">
            <button class="btn" type="submit">Оживить текст</button>
          </form>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="start">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_ai_copy_regenerate">
            <?= demand_ai_content_command_fields('demand_ai_copy_regenerate', 'draft', $workspaceDraftId) ?>
            <input type="hidden" name="draft_id" value="<?= e($workspaceDraftId) ?>">
            <input type="hidden" name="ai_copy_task" value="regenerate_faq">
            <input type="hidden" name="return_anchor" value="simple-ai-workspace">
            <button class="btn secondary" type="submit">Перегенерировать FAQ</button>
          </form>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="start">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_ai_copy_regenerate">
            <?= demand_ai_content_command_fields('demand_ai_copy_regenerate', 'draft', $workspaceDraftId) ?>
            <input type="hidden" name="draft_id" value="<?= e($workspaceDraftId) ?>">
            <input type="hidden" name="ai_copy_task" value="reduce_seo_overoptimization">
            <input type="hidden" name="return_anchor" value="simple-ai-workspace">
            <button class="btn secondary" type="submit">Убрать SEO-переспам</button>
          </form>
        <?php endif; ?>
        <?php if (is_array($workspaceDraft) && $workspaceDraftId !== ''): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="start">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="draft_internal_links_suggest">
            <?= demand_editorial_command_fields('draft_internal_links_suggest') ?>
            <input type="hidden" name="draft_id" value="<?= e($workspaceDraftId) ?>">
            <input type="hidden" name="return_anchor" value="simple-ai-workspace">
            <button class="btn secondary" type="submit">Подобрать безопасные ссылки</button>
          </form>
        <?php endif; ?>
        <?php if (is_array($workspaceHint) && $workspaceHintId !== ''): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="start">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_car_hint_ai_generate">
            <?= demand_ai_content_command_fields('demand_car_hint_ai_generate', 'car_hint', $workspaceHintId) ?>
            <input type="hidden" name="hint_id" value="<?= e($workspaceHintId) ?>">
            <input type="hidden" name="ai_api_task" value="generate_car_hint_text">
            <input type="hidden" name="return_anchor" value="simple-ai-workspace">
            <button class="btn secondary" type="submit">Сформировать текст подсказки</button>
          </form>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="start">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_car_hint_ai_generate">
            <?= demand_ai_content_command_fields('demand_car_hint_ai_generate', 'car_hint', $workspaceHintId) ?>
            <input type="hidden" name="hint_id" value="<?= e($workspaceHintId) ?>">
            <input type="hidden" name="ai_api_task" value="generate_car_description_suggestion">
            <input type="hidden" name="return_anchor" value="simple-ai-workspace">
            <button class="btn secondary" type="submit">Сформировать текст описания</button>
          </form>
        <?php endif; ?>
        </div>
      </details>

      <?php if ($workspaceLastResult): ?>
        <section class="demand-simple-ai-result">
          <div class="panel-head">
            <div>
              <h3>Последний результат</h3>
              <p class="muted"><?= e((string) ($workspaceLastResult['summary'] ?? $workspaceLastResult['message'] ?? '')) ?></p>
            </div>
            <span class="status status-free"><?= e((string) ($workspaceLastResult['title'] ?? 'Готово')) ?></span>
          </div>
          <?php if ((string) ($workspaceLastResult['type'] ?? '') === 'wordstat_dry_run'): ?>
            <dl class="wordstat-kv">
              <dt>Направление</dt><dd><?= e((string) ($workspaceLastResult['directionTitle'] ?? $currentDirection['title'] ?? '')) ?></dd>
              <dt>Запросов</dt><dd><?= e((string) ($workspaceLastResult['plannedRequests'] ?? 0)) ?></dd>
              <dt>Примерная стоимость</dt><dd><?= e(number_format((float) ($workspaceLastResult['estimatedCostRub'] ?? 0.0), 4, '.', '')) ?> RUB</dd>
            </dl>
          <?php endif; ?>
        </section>
      <?php endif; ?>

      <?php if ((string) ($workspaceEditable['type'] ?? '') === 'draft_text' && $workspaceDraftId !== ''): ?>
        <?php
          $copyProposal = (array) ($workspaceEditable['proposal'] ?? []);
          $copyDiff = is_array($workspaceEditable['diff'] ?? null) ? (array) $workspaceEditable['diff'] : [];
        ?>
        <section class="demand-simple-ai-proposal" data-simple-ai-dirty-scope>
          <div class="panel-head">
            <div>
              <h3>AI подготовил текст</h3>
              <p class="muted">Посмотрите вариант, поправьте при необходимости и решите, применять его или нет.</p>
            </div>
            <span class="status status-service">вариант AI</span>
          </div>
          <form method="post" class="form-stack">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="start">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_ai_copy_apply_edited">
            <?= demand_ai_content_command_fields('demand_ai_copy_apply_edited', 'draft', $workspaceDraftId) ?>
            <input type="hidden" name="draft_id" value="<?= e($workspaceDraftId) ?>">
            <input type="hidden" name="ai_copy_token" value="<?= e((string) ($workspaceEditable['token'] ?? '')) ?>">
            <input type="hidden" name="return_anchor" value="simple-ai-workspace">
            <details class="demand-simple-ai-detail-panel demand-simple-ai-proposal-details">
              <summary>Посмотреть и поправить</summary>
            <div class="demand-simple-ai-edit-grid">
              <?php foreach (['title' => 'Title', 'h1' => 'H1', 'metaDescription' => 'Meta description', 'intro' => 'Intro'] as $field => $label): ?>
                <?php if (!array_key_exists($field, $copyProposal)) { continue; } ?>
                <label><?= e($label) ?>
                  <small>Сейчас: <?= e(demand_clean_string($workspaceDraft[$field] ?? '', 180)) ?></small>
                  <textarea name="ai_copy_proposal[<?= e($field) ?>]" rows="<?= $field === 'intro' ? 6 : 3 ?>" data-simple-ai-edit data-ai-original="<?= e((string) ($copyProposal[$field] ?? '')) ?>"><?= e((string) ($copyProposal[$field] ?? '')) ?></textarea>
                </label>
              <?php endforeach; ?>
              <?php if (array_key_exists('contentBlocks', $copyProposal)): ?>
                <label>Блоки текста
                  <small>Редактируйте только текстовые блоки, которые должны остаться в черновике.</small>
                  <textarea name="ai_copy_proposal[contentBlocks]" rows="8" data-simple-ai-edit><?= e(json_encode($copyProposal['contentBlocks'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT)) ?></textarea>
                </label>
              <?php endif; ?>
              <?php if (array_key_exists('faq', $copyProposal)): ?>
                <label>FAQ
                  <textarea name="ai_copy_proposal[faq]" rows="6" data-simple-ai-edit><?= e(json_encode($copyProposal['faq'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT)) ?></textarea>
                </label>
              <?php endif; ?>
            </div>
            <?php if (!empty($copyDiff['rows'])): ?>
              <details class="demand-simple-ai-diff">
                <summary>Diff</summary>
                <div class="table-wrap">
                  <table class="report-table demand-ai-diff-table">
                    <thead><tr><th>Поле</th><th>Было</th><th>Вариант AI</th></tr></thead>
                    <tbody>
                      <?php foreach ((array) ($copyDiff['rows'] ?? []) as $row): ?>
                        <tr class="<?= !empty($row['changed']) ? 'is-changed' : '' ?>">
                          <th><?= e((string) ($row['label'] ?? $row['field'] ?? '')) ?></th>
                          <td><pre><?= e((string) ($row['before'] ?? '')) ?></pre></td>
                          <td><pre><?= e((string) ($row['after'] ?? '')) ?></pre></td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </details>
            <?php endif; ?>
            <div class="notice info">
              Будут изменены только выбранные текстовые поля черновика. Не будут изменены publishStatus, indexStatus, sitemap, robots, canonical/public routes, карточки авто и бизнес-данные.
            </div>
            <div class="demand-simple-ai-actions-row demand-simple-ai-secondary-actions">
              <button class="btn secondary" type="button" data-simple-ai-reset>Вернуть вариант AI</button>
              <button class="btn secondary" type="submit" formaction="" formmethod="post" name="action" value="demand_ai_copy_regenerate">Сгенерировать ещё раз</button>
              <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $workspaceDraftId])) ?>#demand-ai-copy-regeneration">Открыть полный редактор</a>
            </div>
            </details>
            <div class="demand-simple-ai-actions-row">
              <button class="btn" type="submit">Применить</button>
            </div>
          </form>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="start">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_ai_copy_reject">
            <?= demand_ai_content_command_fields('demand_ai_copy_reject', 'draft', $workspaceDraftId) ?>
            <input type="hidden" name="draft_id" value="<?= e($workspaceDraftId) ?>">
            <input type="hidden" name="ai_copy_token" value="<?= e((string) ($workspaceEditable['token'] ?? '')) ?>">
            <input type="hidden" name="return_anchor" value="simple-ai-workspace">
            <button class="btn secondary" type="submit">Отклонить</button>
          </form>
        </section>
      <?php endif; ?>

      <?php if (is_array($workspaceDraft) && ($workspaceInternalLinkSuggestions || !$workspaceDraftInternalLinks)): ?>
        <section class="demand-simple-ai-links">
          <div class="panel-head">
            <div>
              <h3><?= $workspaceDraftInternalLinks ? 'Внутренние ссылки' : 'Внутренние ссылки отсутствуют' ?></h3>
              <p class="muted">AI может предложить только безопасные ссылки. Будущие или отсутствующие цели остаются рекомендациями и не выводятся публично как ссылки.</p>
            </div>
            <span class="status status-service">безопасное применение</span>
          </div>
          <details class="demand-simple-ai-detail-panel">
            <summary>Открыть ссылки</summary>
          <?php if ($workspaceInternalLinkSuggestions): ?>
            <?php
              $linkBuckets = ['ready_public_link' => [], 'noindex_public_link' => [], 'draft_planned_link' => [], 'missing_target' => [], 'risky_or_irrelevant' => [], 'duplicate' => []];
              foreach ($workspaceInternalLinkSuggestions as $index => $suggestion) {
                  $status = (string) ($suggestion['status'] ?? 'missing_target');
                  $linkBuckets[$status][] = [$index, $suggestion];
              }
            ?>
            <div class="demand-simple-link-buckets">
              <?php foreach ($linkBuckets as $status => $items): ?>
                <section>
                  <h4><?= e(match ($status) {
                      'ready_public_link' => 'Готовые публичные ссылки',
                      'noindex_public_link' => 'Закрытые от индексации ссылки',
                      'draft_planned_link' => 'Будущие ссылки',
                      'missing_target' => 'Цели ещё не готовы',
                      'risky_or_irrelevant' => 'Рискованные ссылки',
                      'duplicate' => 'Дубли',
                      default => demand_admin_ui_label($status),
                  }) ?> <span><?= e((string) count($items)) ?></span></h4>
                  <ul>
                    <?php foreach (array_slice($items, 0, 4) as [$index, $suggestion]): ?>
                      <li><?= e((string) ($suggestion['anchor'] ?? $suggestion['title'] ?? 'Ссылка')) ?> <small><?= e((string) ($suggestion['reason'] ?? '')) ?></small></li>
                    <?php endforeach; ?>
                  </ul>
                </section>
              <?php endforeach; ?>
            </div>
            <div class="demand-simple-ai-actions-row">
              <form method="post">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="tab" value="start">
                <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                <input type="hidden" name="action" value="draft_internal_links_apply">
                <?= demand_editorial_command_fields('draft_internal_links_apply') ?>
                <input type="hidden" name="draft_id" value="<?= e($workspaceDraftId) ?>">
                <input type="hidden" name="internal_links_token" value="<?= e((string) ($workspaceInternalLinksState['token'] ?? '')) ?>">
                <input type="hidden" name="apply_mode" value="all_safe">
                <input type="hidden" name="return_anchor" value="simple-ai-workspace">
                <button class="btn" type="submit">Добавить все безопасные</button>
              </form>
              <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $workspaceDraftId])) ?>#demand-internal-links">Выбрать вручную</a>
              <form method="post">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="tab" value="start">
                <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                <input type="hidden" name="action" value="draft_internal_links_reject">
                <?= demand_editorial_command_fields('draft_internal_links_reject') ?>
                <input type="hidden" name="draft_id" value="<?= e($workspaceDraftId) ?>">
                <input type="hidden" name="return_anchor" value="simple-ai-workspace">
                <button class="btn secondary" type="submit">Пропустить</button>
              </form>
            </div>
          <?php else: ?>
            <div class="demand-simple-ai-actions-row">
              <form method="post">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="tab" value="start">
                <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                <input type="hidden" name="action" value="draft_internal_links_suggest">
                <?= demand_editorial_command_fields('draft_internal_links_suggest') ?>
                <input type="hidden" name="draft_id" value="<?= e($workspaceDraftId) ?>">
                <input type="hidden" name="return_anchor" value="simple-ai-workspace">
                <button class="btn" type="submit">Подобрать безопасные ссылки</button>
              </form>
              <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $workspaceDraftId])) ?>#demand-internal-links-manual">Добавить вручную</a>
              <button class="btn secondary" type="button">Пропустить</button>
            </div>
          <?php endif; ?>
          </details>
        </section>
      <?php endif; ?>

      <section class="demand-simple-ai-decisions" id="simple-ai-decisions-summary">
        <div class="panel-head">
          <div>
            <h3>Нужны решения: <?= e((string) count($demandDecisionQueue)) ?></h3>
            <p class="muted">Кратко: что требует человека. Полный список открывается по клику.</p>
          </div>
        </div>
        <?php if ($workspaceDecisionPreview): ?>
          <ul class="demand-simple-compact-list">
            <?php foreach ($workspaceDecisionPreview as $decision): ?>
              <li><?= e((string) ($decision['title'] ?? 'AI подготовил решение.')) ?></li>
            <?php endforeach; ?>
          </ul>
        <?php else: ?>
          <p class="muted">Сейчас нет срочных решений. AI всё равно остановится перед действиями с риском.</p>
        <?php endif; ?>
        <details class="demand-simple-ai-detail-panel">
          <summary>Открыть решения</summary>
          <div class="demand-simple-decision-list">
            <?php foreach (array_slice($demandDecisionQueue, 0, 6) as $decision): ?>
              <?php
                $decisionType = (string) ($decision['type'] ?? '');
                $decisionDirectionId = (string) ($decision['directionId'] ?? '');
                $decisionTarget = '';
                if (in_array($decisionType, ['direction_wordstat_dry_run_confirm', 'direction_refresh_due', 'wordstat_dry_run_ready'], true) && $decisionDirectionId !== '') {
                    $decisionTarget = 'wordstat-' . $decisionDirectionId;
                } elseif ($decisionDirectionId !== '') {
                    $decisionTarget = $decisionDirectionId;
                }
              ?>
              <article class="demand-simple-decision-card">
                <span><?= e(demand_admin_confirmation_level_label((string) ($decision['confirmationLevel'] ?? ''))) ?></span>
                <h4><?= e((string) ($decision['title'] ?? 'Решение')) ?></h4>
                <p><?= e((string) ($decision['body'] ?? 'AI ждёт решения человека.')) ?></p>
                <ul>
                  <li>Что изменится: <?= e(!empty($decision['safeToApply']) ? 'только безопасная подготовительная часть после подтверждения' : 'ничего не применится автоматически') ?>.</li>
                  <li>Что не изменится: публикация, индексация, sitemap, robots, Wordstat live и бизнес-данные.</li>
                  <li>AI не имеет права менять цены, залоги, карточки авто, заявки, аренды, клиентов, финансы, документы, пользователей и роли.</li>
                </ul>
                <div class="demand-simple-ai-actions-row">
                  <?php if ($decisionTarget !== ''): ?>
                    <button class="btn small" type="button" data-demand-direction-modal-open="<?= e($decisionTarget) ?>"><?= $decisionType === 'wordstat_dry_run_ready' ? 'Открыть проверку' : 'Открыть решение' ?></button>
                  <?php else: ?>
                    <button class="btn small" type="button" data-demand-ai-dialog-open>Открыть решение</button>
                  <?php endif; ?>
                  <details>
                    <summary>Подробнее</summary>
                    <p><?= e(demand_admin_decision_type_label($decisionType)) ?></p>
                  </details>
                  <button class="btn secondary small" type="button">Отложить</button>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
        </details>
      </section>

      <section class="demand-simple-ai-materials" id="simple-ai-materials-summary">
        <div class="panel-head">
          <div>
            <h3>AI уже подготовил</h3>
            <p class="muted">Краткая сводка. Детали открываются отдельно.</p>
          </div>
        </div>
        <div class="demand-simple-ai-summary-stats">
          <?php foreach ($workspacePreparedSummary as $item): ?>
            <span><strong><?= e((string) $item['count']) ?></strong><?= e((string) $item['label']) ?></span>
          <?php endforeach; ?>
        </div>
        <details class="demand-simple-ai-detail-panel">
          <summary>Открыть материалы</summary>
          <div class="demand-master-materials">
            <?php foreach (array_slice($demandMaterialGroups, 0, 3) as $material): ?>
              <?php $isSeed = (string) ($material['title'] ?? '') === 'AI seed-фразы'; ?>
              <article>
                <strong><?= e((string) ($material['title'] ?? 'Материал')) ?></strong>
                <span><?= e((string) ($material['count'] ?? 0)) ?> · <?= e((string) ($material['text'] ?? '')) ?></span>
                <?php if ($isSeed && $workspaceWordstatModalId !== ''): ?>
                  <button class="btn secondary small" type="button" data-demand-direction-modal-open="<?= e($workspaceWordstatModalId) ?>">Проверить через Wordstat без изменения данных</button>
                <?php else: ?>
                  <a class="btn secondary small" href="<?= e((string) ($material['href'] ?? '#')) ?>"><?= e((string) ($material['button'] ?? 'Открыть')) ?></a>
                <?php endif; ?>
              </article>
            <?php endforeach; ?>
          </div>
          <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('materials', $scopeFilter)) ?>">Открыть всё</a>
        </details>
      </section>

      <?php if ($workspaceHistory): ?>
        <details class="demand-simple-ai-history demand-simple-ai-detail-panel">
          <summary>История AI</summary>
          <ul>
            <?php foreach (array_slice($workspaceHistory, 0, 4) as $item): ?>
              <li><strong><?= e((string) ($item['title'] ?? 'AI-действие')) ?></strong><span><?= e((string) ($item['text'] ?? '')) ?></span></li>
            <?php endforeach; ?>
          </ul>
        </details>
      <?php endif; ?>

      <details class="demand-car-hint-manual">
        <summary>Ручной режим / без API</summary>
        <p class="muted">Здесь остаются ручные пакеты для внешнего AI, старый мастер Wordstat и технические логи. Это запасной режим, а не основной путь простого вида.</p>
        <div class="demand-simple-ai-actions-row">
          <?php if (is_array($workspaceHint) && $workspaceHintId !== '' && has_permission('demand.ai.package')): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="start">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="demand_ai_generate_package">
              <?= demand_ai_content_command_fields('demand_ai_generate_package', 'car_hint', $workspaceHintId) ?>
              <input type="hidden" name="entity_type" value="car_hint">
              <input type="hidden" name="entity_id" value="<?= e($workspaceHintId) ?>">
              <input type="hidden" name="ai_task" value="improve_car_hint">
              <input type="hidden" name="return_anchor" value="simple-ai-workspace">
              <button class="btn secondary small" type="submit">Сформировать ручной пакет для внешнего AI</button>
            </form>
          <?php endif; ?>
          <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('wordstat_help', $scopeFilter)) ?>">Ручной режим Wordstat</a>
          <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('technical', $scopeFilter)) ?>">Техническое</a>
        </div>
      </details>
    </section>
    <?php
      demand_admin_car_hint_ai_proposal_modal($demandAiApiLatest, $scopeFilter);
      demand_admin_car_hint_ai_fallback_panel($demandCarHintAiFallback, $scopeFilter);
    ?>
  <?php endif; ?>
  <?php if (!$demandIsDetailedView): ?>
    <details class="panel demand-simple-secondary-sections" id="simple-ai-secondary-sections">
      <summary>
        <span>Дополнительно (свернуто)</span>
        <small>Готовые материалы · Очередь направлений · История AI · Требует актуализации · Приоритетные направления · Не делать · Технические детали</small>
      </summary>
  <?php endif; ?>
  <section class="demand-direction-workspace" id="demand-direction-sessions">
    <article class="panel demand-direction-current">
      <div class="panel-head">
        <div>
          <span class="eyebrow">Текущее направление</span>
          <h2><?= e((string) ($currentDirection['title'] ?? 'Направление ещё не выбрано')) ?></h2>
          <p class="muted">
            <?php if ($currentDirection): ?>
              Статус: <?= e(demand_admin_direction_status_label((string) ($currentDirection['status'] ?? 'not_started'))) ?>.
              Бюджет по умолчанию: <?= e((string) ($currentDirection['budgetMode'] ?? 'economy')) ?>.
              <?php if (!empty($currentDirection['latestRun']['stopReason'])): ?><?= e(demand_ai_stop_reason_label((string) $currentDirection['latestRun']['stopReason'])) ?>.<?php endif; ?>
              <?php if (!empty($currentDirection['reuseMessage'])): ?><?= e((string) $currentDirection['reuseMessage']) ?><?php endif; ?>
            <?php else: ?>
              AI будет работать по одному направлению в рамках бюджета, а не пытаться собрать весь спрос сразу.
            <?php endif; ?>
          </p>
        </div>
        <?php if ($currentDirection): ?>
          <?php $currentAction = (array) ($currentDirection['nextAction'] ?? []); ?>
          <?php if ((string) ($currentAction['actionKey'] ?? '') === 'direction_start_confirm'): ?>
            <button class="btn" type="button" data-demand-direction-modal-open="<?= e((string) ($currentDirection['directionId'] ?? '')) ?>"><?= e((string) ($currentAction['label'] ?? 'Запустить AI-сессию')) ?></button>
          <?php else: ?>
            <a class="btn" href="<?= e(demand_admin_scope_filter_url('materials', $scopeFilter)) ?>"><?= e((string) ($currentAction['label'] ?? 'Открыть материалы')) ?></a>
          <?php endif; ?>
        <?php else: ?>
          <button class="btn" type="button" data-demand-ai-dialog-open data-demand-ai-dialog-prompt="Разбей широкий спрос по аренде авто в Крыму на отдельные направления и предложи, с чего безопасно начать.">Подобрать направление</button>
        <?php endif; ?>
      </div>
      <div class="demand-direction-counts">
        <span>Готово <strong><?= e((string) ($demandDirectionCounts['prepared'] ?? 0)) ?></strong></span>
        <span>Нужны решения <strong><?= e((string) ($demandDirectionCounts['needsDecision'] ?? 0)) ?></strong></span>
        <span>Устарело <strong><?= e((string) ($demandDirectionCounts['stale'] ?? 0)) ?></strong></span>
        <span>Не начато <strong><?= e((string) ($demandDirectionCounts['notStarted'] ?? 0)) ?></strong></span>
      </div>
      <?php if ($currentDirection): ?>
        <?php
          $currentDirectionId = (string) ($currentDirection['directionId'] ?? '');
          $currentWordstatPacket = $demandDirectionWordstatPackets[$currentDirectionId] ?? null;
          $currentWordstatStatus = (string) ($currentDirection['wordstatStatus'] ?? 'not_checked');
          $currentWordstatRunIds = (array) ($currentDirection['linkedWordstatRunIds'] ?? []);
          $currentWordstatModalId = 'wordstat-' . $currentDirectionId;
        ?>
        <section class="demand-direction-wordstat-card" id="direction-wordstat-<?= e($currentDirectionId) ?>">
          <div>
            <span class="eyebrow">Проверка спроса через Wordstat</span>
            <h3><?= e(demand_admin_direction_wordstat_status_label($currentWordstatStatus)) ?></h3>
            <p class="muted">
              <?php if ($currentWordstatStatus === 'dry_run_ready'): ?>
                Проверка без изменения данных готова, реальные данные Wordstat не загружались. Можно открыть результат или продолжить без live.
              <?php elseif ($currentWordstatStatus === 'live_result_ready'): ?>
                Есть результат Wordstat. Если данные обновили метрики, следующий безопасный шаг — открыть рекомендации или пересчитать карту спроса вручную.
              <?php else: ?>
                Wordstat по направлению ещё не проверялся. AI может подготовить фразы, регионы и методы, но запуск будет только после подтверждения в этом окне.
              <?php endif; ?>
            </p>
            <?php if (is_array($currentWordstatPacket) && !empty($currentWordstatPacket['duplicateMessage'])): ?>
              <p class="field-hint warning"><?= e((string) $currentWordstatPacket['duplicateMessage']) ?></p>
            <?php endif; ?>
          </div>
          <div class="demand-direction-wordstat-actions">
            <?php if (is_array($currentWordstatPacket)): ?>
              <button class="btn secondary small" type="button" data-demand-direction-modal-open="<?= e($currentWordstatModalId) ?>">
                <?= $currentWordstatStatus === 'dry_run_ready' ? 'Открыть проверку' : 'Проверить через Wordstat без изменения данных' ?>
              </button>
            <?php endif; ?>
            <?php if ($currentWordstatStatus === 'dry_run_ready'): ?>
              <a class="btn secondary small" href="#simple-ai-workspace">Открыть результат</a>
              <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('materials', $scopeFilter)) ?>">Продолжить без Wordstat live</a>
              <a class="btn warning-action small" href="<?= e(demand_admin_scope_filter_url('wordstat_help', $scopeFilter)) ?>">Загрузить реальные данные Wordstat вручную</a>
            <?php elseif ($currentWordstatStatus === 'live_result_ready'): ?>
              <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('recommendations', $scopeFilter)) ?>">Открыть обновлённые рекомендации</a>
              <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter)) ?>#demand-map-clusters">Пересчитать карту спроса по новым данным</a>
            <?php endif; ?>
          </div>
          <dl class="demand-direction-wordstat-meta">
            <dt>Проверка без изменения данных</dt><dd><?= !empty($currentDirection['lastWordstatDryRunAt']) ? e(format_admin_datetime((string) $currentDirection['lastWordstatDryRunAt'])) : 'не запускалась' ?></dd>
            <dt>Реальные данные Wordstat</dt><dd><?= !empty($currentDirection['lastWordstatLiveAt']) ? e(format_admin_datetime((string) $currentDirection['lastWordstatLiveAt'])) : 'не загружались' ?></dd>
            <dt>Результаты</dt><dd><?= e((string) count($currentWordstatRunIds)) ?></dd>
          </dl>
          <?php if ($currentWordstatStatus === 'dry_run_ready' && is_array($currentWordstatPacket) && has_permission('demand.wordstat.live') && $wordstatLiveAvailable): ?>
            <details class="demand-direction-wordstat-live">
              <summary>Загрузить реальные данные Wordstat вручную</summary>
              <p class="field-hint warning">Реальная загрузка может обновить частотности, метрики спроса и советы системы. Она не меняет публикацию, индексацию, sitemap.xml, robots.txt, цены, автомобили, заявки, аренды, клиентов, финансы, документы, пользователей и роли.</p>
              <form method="post" class="wordstat-sync-form">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="tab" value="start">
                <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                <input type="hidden" name="action" value="wordstat_live_sync">
                <?= demand_integration_command_fields('wordstat_live_sync') ?>
                <input type="hidden" name="target_scope_id" value="<?= e($scopeFilter !== 'all' ? $scopeFilter : 'rent_rk') ?>">
                <input type="hidden" name="direction_id" value="<?= e($currentDirectionId) ?>">
                <input type="hidden" name="direction_title" value="<?= e((string) ($currentDirection['title'] ?? '')) ?>">
                <input type="hidden" name="packet_id" value="<?= e((string) ($currentWordstatPacket['packetId'] ?? '')) ?>">
                <input type="hidden" name="packet_fingerprint" value="<?= e((string) ($currentWordstatPacket['packetFingerprint'] ?? '')) ?>">
                <textarea name="seed_phrases" hidden><?= e(implode("\n", (array) ($currentWordstatPacket['seedPhrases'] ?? []))) ?></textarea>
                <input type="hidden" name="region_ids" value="<?= e(implode(', ', (array) ($currentWordstatPacket['regionIds'] ?? []))) ?>">
                <?php foreach ((array) ($currentWordstatPacket['methods'] ?? []) as $method): ?>
                  <input type="hidden" name="methods[]" value="<?= e((string) $method) ?>">
                <?php endforeach; ?>
                <label class="check-row"><input type="checkbox" name="confirmed" value="1"><span>Отдельное подтверждение: я понимаю, что это загрузка реальных данных Wordstat, а не проверка без изменения данных.</span></label>
                <button class="btn warning-action small" type="submit">Загрузить реальные данные Wordstat вручную</button>
              </form>
            </details>
          <?php endif; ?>
        </section>
      <?php endif; ?>
    </article>

    <article class="panel demand-direction-next">
      <div class="panel-head">
        <div>
          <span class="eyebrow">Следующий безопасный шаг</span>
          <h2><?= e((string) ($demandWorkspacePrimaryAction['title'] ?? $demandNextAction['title'] ?? 'Открыть материалы')) ?></h2>
          <p class="muted"><?= e((string) ($demandWorkspacePrimaryAction['text'] ?? $demandNextAction['text'] ?? '')) ?></p>
        </div>
        <?php if (!empty($demandWorkspacePrimaryAction['directionId'])): ?>
          <?php
            $primaryDirectionModalTarget = (string) $demandWorkspacePrimaryAction['directionId'];
            if (in_array((string) ($demandWorkspacePrimaryAction['actionKey'] ?? ''), ['wordstat_dry_run_ready', 'open_wordstat_dry_run_result'], true)) {
                $primaryDirectionModalTarget = 'wordstat-' . $primaryDirectionModalTarget;
            }
          ?>
          <button class="btn" type="button" data-demand-direction-modal-open="<?= e($primaryDirectionModalTarget) ?>"><?= e((string) ($demandWorkspacePrimaryAction['button'] ?? 'Открыть')) ?></button>
        <?php else: ?>
          <a class="btn" href="<?= e((string) ($demandNextAction['href'] ?? '#')) ?>"><?= e((string) ($demandWorkspacePrimaryAction['button'] ?? $demandNextAction['button'] ?? 'Открыть')) ?></a>
        <?php endif; ?>
      </div>
    </article>

    <div class="demand-direction-grid">
      <article class="panel">
        <h2>AI уже подготовил</h2>
        <div class="demand-direction-mini-list">
          <?php foreach ($preparedDirections as $direction): ?>
            <div>
              <strong><?= e((string) ($direction['title'] ?? 'Направление')) ?></strong>
              <span><?= e(count((array) ($direction['linkedContentBriefIds'] ?? [])) . ' ТЗ, ' . count((array) ($direction['linkedDraftIds'] ?? [])) . ' черновиков, ' . count((array) ($direction['linkedCarHintIds'] ?? [])) . ' подсказок') ?></span>
            </div>
          <?php endforeach; ?>
          <?php if (!$preparedDirections): ?><p class="muted">Пока нет готовых direction-материалов. Запустите первую AI-сессию в режиме economy.</p><?php endif; ?>
        </div>
        <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('materials', $scopeFilter)) ?>">Открыть материалы</a>
      </article>

      <article class="panel">
        <h2>Нужны решения</h2>
        <div class="demand-direction-mini-list">
          <?php foreach (array_slice($demandDecisionQueue, 0, 4) as $decision): ?>
            <div>
              <strong><?= e((string) ($decision['title'] ?? 'Решение')) ?></strong>
              <span><?= e(demand_admin_decision_type_label((string) ($decision['type'] ?? ''))) ?> · <?= e(demand_admin_confirmation_level_label((string) ($decision['confirmationLevel'] ?? ''))) ?></span>
              <?php if ((string) ($decision['type'] ?? '') === 'direction_neighbor_found'): ?>
                <div class="demand-neighbor-actions">
                  <?php foreach ((array) ($decision['relatedObjectIds']['neighborDirections'] ?? []) as $neighborId): ?>
                    <?php
                      $neighborId = (string) $neighborId;
                      $neighbor = $allDirectionsById[$neighborId] ?? null;
                      if (!is_array($neighbor)) {
                          continue;
                      }
                    ?>
                    <article class="demand-neighbor-card">
                      <strong><?= e((string) ($neighbor['title'] ?? 'Соседнее направление')) ?></strong>
                      <small><?= e(demand_admin_direction_priority_label((string) ($neighbor['priority'] ?? 'medium'))) ?> · <?= e(demand_admin_direction_status_label((string) ($neighbor['status'] ?? 'not_started'))) ?></small>
                      <div class="demand-neighbor-card-actions">
                        <form method="post">
                          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                          <input type="hidden" name="tab" value="start">
                          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                          <input type="hidden" name="action" value="demand_direction_neighbor_decision">
                          <?= demand_editorial_command_fields('demand_direction_neighbor_decision') ?>
                          <input type="hidden" name="direction_id" value="<?= e($neighborId) ?>">
                          <input type="hidden" name="neighbor_action" value="add_to_queue">
                          <button class="btn secondary small" type="submit">Добавить в очередь</button>
                        </form>
                        <button class="btn secondary small" type="button" data-demand-direction-modal-open="<?= e($neighborId) ?>">Обработать сейчас</button>
                        <form method="post">
                          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                          <input type="hidden" name="tab" value="start">
                          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                          <input type="hidden" name="action" value="demand_direction_neighbor_decision">
                          <?= demand_editorial_command_fields('demand_direction_neighbor_decision') ?>
                          <input type="hidden" name="direction_id" value="<?= e($neighborId) ?>">
                          <input type="hidden" name="neighbor_action" value="ignore">
                          <button class="btn secondary small" type="submit">Игнорировать</button>
                        </form>
                        <form method="post">
                          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                          <input type="hidden" name="tab" value="start">
                          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                          <input type="hidden" name="action" value="demand_direction_neighbor_decision">
                          <?= demand_editorial_command_fields('demand_direction_neighbor_decision') ?>
                          <input type="hidden" name="direction_id" value="<?= e($neighborId) ?>">
                          <input type="hidden" name="neighbor_action" value="postpone">
                          <button class="btn secondary small" type="submit">Отложить</button>
                        </form>
                      </div>
                    </article>
                  <?php endforeach; ?>
                </div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
          <?php if (!$demandDecisionQueue): ?><p class="muted">Критичных решений сейчас не видно. AI всё равно остановится перед публикацией, индексом, sitemap, robots и Wordstat live.</p><?php endif; ?>
        </div>
        <a class="btn secondary small" href="#demand-direction-sessions">Показать решения</a>
      </article>

      <article class="panel">
        <h2>Очередь направлений</h2>
        <div class="demand-direction-queue">
          <?php foreach ($queuePreview as $direction): ?>
            <button class="demand-direction-row" type="button" data-demand-direction-modal-open="<?= e((string) ($direction['directionId'] ?? '')) ?>">
              <span><?= e((string) ($direction['title'] ?? 'Направление')) ?></span>
              <small><?= e(demand_admin_direction_priority_label((string) ($direction['priority'] ?? 'low'))) ?> · <?= e(demand_admin_direction_status_label((string) ($direction['status'] ?? 'not_started'))) ?></small>
            </button>
          <?php endforeach; ?>
          <?php if (!$queuePreview): ?><p class="muted">Очередь появится после фраз, карты спроса или AI-сбора направлений.</p><?php endif; ?>
        </div>
      </article>

      <article class="panel">
        <h2>История AI</h2>
        <div class="demand-direction-mini-list">
          <?php foreach (array_slice($demandRecentAiSessions, 0, 4) as $run): ?>
            <div>
              <strong><?= e((string) ($run['directionTitle'] ?? 'AI-сессия')) ?></strong>
              <span><?= e(format_admin_datetime((string) ($run['finishedAt'] ?? $run['startedAt'] ?? ''))) ?> · <?= e((string) ($run['budgetMode'] ?? 'economy')) ?> · <?= e((string) ($run['stopReasonLabel'] ?? demand_ai_stop_reason_label((string) ($run['stopReason'] ?? '')))) ?></span>
            </div>
          <?php endforeach; ?>
          <?php if (!$demandRecentAiSessions): ?><p class="muted">История появится после запуска direction-сессии. В ней не сохраняются credentials, raw prompts и полные AI responses.</p><?php endif; ?>
        </div>
        <details class="demand-technical-details">
          <summary>Подробно</summary>
          <p class="muted">История owner-facing: дата, направление, режим, что создано, где AI остановился и что точно не менялось.</p>
        </details>
      </article>

      <article class="panel demand-direction-refresh">
        <h2>Требует актуализации</h2>
        <div class="demand-direction-mini-list">
          <?php foreach ($staleDirections as $direction): ?>
            <div>
              <strong><?= e((string) ($direction['title'] ?? 'Направление')) ?></strong>
              <span>Рекомендуется обновить проверку без изменения данных после <?= e(format_admin_datetime((string) ($direction['nextRefreshRecommendedAt'] ?? ''))) ?></span>
            </div>
          <?php endforeach; ?>
          <?php if (!$staleDirections): ?><p class="muted">Напоминаний нет. AI не запускает обновление спроса без вашего действия.</p><?php endif; ?>
        </div>
        <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('wordstat_help', $scopeFilter)) ?>">Открыть Wordstat</a>
      </article>
    </div>
  </section>

  <div class="demand-master-summary-grid">
    <article class="panel">
      <h2>Приоритетные направления</h2>
      <ul class="demand-master-list">
        <?php foreach (array_slice($masterPriorityGroups, 0, 5) as $row): ?>
          <?php $cluster = (array) ($row['cluster'] ?? []); ?>
          <li><strong><?= e((string) ($cluster['name'] ?? $cluster['primaryPhrase'] ?? 'Направление спроса')) ?></strong><span><?= e((string) ($cluster['scoringExplanation'] ?? $cluster['contentGapSummary'] ?? 'AI считает это полезным направлением для подготовки.')) ?></span></li>
        <?php endforeach; ?>
        <?php if (!$masterPriorityGroups): ?><li><strong>Пока нет приоритетов</strong><span>Запустите AI-мастер или пересчитайте карту спроса.</span></li><?php endif; ?>
      </ul>
    </article>
    <article class="panel">
      <h2>Нужны решения</h2>
      <ul class="demand-master-list">
        <?php foreach (array_slice($masterDecisionGroups, 0, 5) as $row): ?>
          <?php $cluster = (array) ($row['cluster'] ?? []); ?>
          <li><strong><?= e((string) ($cluster['name'] ?? 'Решение')) ?></strong><span><?= e(demand_admin_list_labels((array) ($cluster['riskFlags'] ?? []), 'demand_admin_risk_label')) ?></span></li>
        <?php endforeach; ?>
        <?php if (!$masterDecisionGroups): ?><li><strong>Критичных решений не видно</strong><span>Проверьте залог, аэропорт и неподтвержденные города перед черновиками.</span></li><?php endif; ?>
      </ul>
    </article>
    <article class="panel">
      <h2>Не делать</h2>
      <ul class="demand-master-list">
        <?php foreach (array_slice($masterNoGroups, 0, 5) as $row): ?>
          <?php $cluster = (array) ($row['cluster'] ?? []); ?>
          <li><strong><?= e((string) ($cluster['name'] ?? 'Нецелевой запрос')) ?></strong><span><?= e(demand_admin_list_labels((array) ($cluster['riskFlags'] ?? []), 'demand_admin_risk_label')) ?></span></li>
        <?php endforeach; ?>
        <?php if (!$masterNoGroups): ?><li><strong>Список пуст</strong><span>Мусорные запросы появятся здесь после импорта или AI-сбора.</span></li><?php endif; ?>
      </ul>
    </article>
    <article class="panel">
      <h2>Готовые материалы</h2>
      <div class="demand-master-materials">
        <?php foreach (array_slice($demandMaterialGroups, 0, 5) as $material): ?>
          <a href="<?= e((string) ($material['href'] ?? '#')) ?>"><span><?= e((string) ($material['title'] ?? '')) ?></span><strong><?= e((string) ($material['count'] ?? 0)) ?></strong></a>
        <?php endforeach; ?>
      </div>
    </article>
  </div>

  <details class="panel demand-technical-details demand-master-legacy">
    <summary>
      <span>Подробный маршрут и справка</span>
      <small>Старый пошаговый обзор свернут, чтобы не мешать мастеру.</small>
    </summary>
  <article class="demand-start-panel">
    <div class="panel-head">
      <div>
        <h2>Как работать со спросом</h2>
        <p class="muted">Этот раздел помогает понять, что люди ищут в Яндексе, какие страницы стоит подготовить и как безопасно довести страницу от черновика до публикации.</p>
      </div>
      <a class="btn" href="<?= e($demandNextAction['href']) ?>"><?= e((string) $demandNextAction['button']) ?></a>
    </div>

    <section class="demand-next-action is-<?= e((string) ($demandNextAction['tone'] ?? 'safe')) ?>">
      <div>
        <span>Следующее действие</span>
        <strong><?= e((string) $demandNextAction['title']) ?></strong>
        <p><?= e((string) $demandNextAction['text']) ?></p>
      </div>
      <a class="btn secondary" href="<?= e((string) $demandNextAction['href']) ?>"><?= e((string) $demandNextAction['button']) ?></a>
    </section>

    <div class="demand-start-grid">
      <section class="demand-start-steps">
        <h3>Простой порядок работы</h3>
        <?php foreach ([
          ['Соберите спрос: загрузите фразы или попросите AI предложить стартовые запросы.', 'Загрузить фразы', 'import'],
          ['Посмотрите полезные запросы и группы спроса.', 'Что ищут люди', 'keywords'],
          ['Откройте план страниц и выберите, что готовить первым.', 'План страниц', 'demand_map'],
          ['Откройте готовые черновики и продолжите работу над страницей.', 'Готовые черновики', 'drafts'],
          ['Проверьте готовность, опубликуйте для просмотра и только потом вручную решайте вопрос поиска.', 'Публикация', 'drafts'],
        ] as $index => $step): ?>
          <div class="demand-start-step">
            <span class="demand-start-step-number"><?= (int) $index + 1 ?></span>
            <p><?= e((string) $step[0]) ?></p>
            <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url((string) $step[2], $scopeFilter)) ?>"><?= e((string) $step[1]) ?></a>
          </div>
        <?php endforeach; ?>
      </section>

      <section class="demand-start-card">
        <h3>Что безопасно</h3>
        <ul class="demand-hint-list">
          <li>Загрузка фраз не публикует страницы.</li>
          <li>Пробная проверка Wordstat ничего не меняет.</li>
          <li>Создание черновика не открывает страницу для поисковиков.</li>
          <li>Опубликовать для просмотра — страница доступна по ссылке, но закрыта от поиска.</li>
          <li>Открыть для поиска — отдельное ручное действие, после которого страница может попасть в Яндекс и Google.</li>
        </ul>
      </section>

      <section class="demand-start-card demand-start-card-warning">
        <h3>Когда страницу лучше не создавать</h3>
        <ul class="demand-hint-list">
          <li>Нет подходящих автомобилей или услуга не подтверждена.</li>
          <li>Запрос обещает “без залога”, а в данных залог есть.</li>
          <li>Запрос “дёшево” может создать ложное ожидание.</li>
          <li>Регион не обслуживается или это нужно уточнить.</li>
          <li>Страница будет повторять уже существующую почти без отличий.</li>
        </ul>
      </section>

      <section class="demand-start-card">
        <h3>Где что находится</h3>
        <div class="demand-start-links">
          <a href="<?= e(demand_admin_scope_filter_url('keywords', $scopeFilter)) ?>">Что ищут люди</a>
          <a href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter)) ?>">Карта спроса и план страниц</a>
          <a href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => 'all'])) ?>#demand-drafts-worklist">Готовые черновики</a>
          <?php if ($demandIsDetailedView): ?><a href="<?= e(demand_admin_scope_filter_url('wordstat_help', $scopeFilter)) ?>">Wordstat</a><?php endif; ?>
        </div>
      </section>
    </div>
  </article>
  </details>
  <?php if (!$demandIsDetailedView): ?>
    </details>
  <?php endif; ?>
  <?php if ($demandLimitWorkflow): ?>
    <?php
      $limitDirectionSession = is_array($demandLimitWorkflow['directionSession'] ?? null) ? $demandLimitWorkflow['directionSession'] : [];
      $limitDirectionId = (string) ($limitDirectionSession['directionId'] ?? '');
      $limitDirectionTitle = (string) ($limitDirectionSession['directionTitle'] ?? 'направление спроса');
      $limitBudget = is_array($limitDirectionSession['budgetLimits'] ?? null) ? $limitDirectionSession['budgetLimits'] : [];
      $limitAutoActions = array_values(array_filter(array_map(static fn($item): string => (string) $item, (array) ($demandLimitWorkflow['autoExecutedActions'] ?? []))));
      $limitAllActions = [];
      foreach (['safeToRunNow', 'requiresConfirmation', 'specialConfirmation'] as $bucket) {
          foreach ((array) ($demandLimitWorkflow[$bucket] ?? []) as $actionItem) {
              if (is_array($actionItem)) {
                  $limitAllActions[(string) ($actionItem['action'] ?? $actionItem['id'] ?? '')] = (string) ($actionItem['label'] ?? $actionItem['action'] ?? $actionItem['id'] ?? '');
              }
          }
      }
      $limitDoneLabels = array_values(array_filter(array_map(static fn(string $actionId): string => $limitAllActions[$actionId] ?? $actionId, $limitAutoActions)));
      $limitSkipped = array_values(array_filter(array_map(static fn(array $item): string => (string) ($item['label'] ?? $item['action'] ?? ''), array_slice((array) ($demandLimitWorkflow['safeToRunNow'] ?? []), count($limitAutoActions)))));
    ?>
    <div class="demand-limit-modal-backdrop" data-demand-limit-modal-backdrop hidden></div>
    <section class="demand-limit-modal" data-demand-limit-modal data-demand-auto-open="1" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="demand-limit-modal-title">
      <div class="demand-direction-modal-head">
        <div>
          <span class="eyebrow">Лимит direction-сессии</span>
          <h2 id="demand-limit-modal-title">AI остановился, чтобы не тратить лимиты дальше</h2>
          <p class="muted"><?= e($limitDirectionTitle) ?> · <?= e((string) ($limitDirectionSession['budgetMode'] ?? 'economy')) ?> · <?= e(demand_ai_stop_reason_label('budget_limit_reached')) ?></p>
        </div>
        <button class="icon-btn" type="button" data-demand-limit-modal-close aria-label="Закрыть">×</button>
      </div>
      <div class="demand-limit-modal-body">
        <section>
          <h3>Использовано</h3>
          <ul>
            <li>AI-вызовы: <?= e((string) count($limitAutoActions)) ?> из <?= e((string) ($limitBudget['maxAiCalls'] ?? 0)) ?></li>
            <li>Seed-фразы: <?= e((string) count((array) ($demandLimitWorkflow['seedKeywords'] ?? []))) ?> из <?= e((string) ($limitBudget['maxSeedPhrases'] ?? 0)) ?></li>
            <li>Черновики: <?= e((string) count((array) ($demandLimitWorkflow['createdDraftIds'] ?? []))) ?> из <?= e((string) ($limitBudget['maxDrafts'] ?? 0)) ?></li>
            <li>Проверка Wordstat без изменения данных: не запускалась</li>
            <li>Wordstat live: не запускался</li>
          </ul>
        </section>
        <section>
          <h3>Сделано</h3>
          <ul>
            <?php foreach (array_slice($limitDoneLabels, 0, 8) as $label): ?><li><?= e($label) ?></li><?php endforeach; ?>
            <?php if (!$limitDoneLabels): ?><li>AI остановился до выполнения подготовительных шагов.</li><?php endif; ?>
          </ul>
        </section>
        <section>
          <h3>Не сделано</h3>
          <ul>
            <?php foreach (array_slice($limitSkipped, 0, 8) as $label): ?><li><?= e($label) ?></li><?php endforeach; ?>
            <?php if (!$limitSkipped): ?><li>Следующий шаг требует выбора человека.</li><?php endif; ?>
          </ul>
        </section>
        <section>
          <h3>Не менялось</h3>
          <ul>
            <?php foreach (demand_ai_protected_non_change_guarantees() as $guarantee): ?><li><?= e((string) $guarantee) ?></li><?php endforeach; ?>
          </ul>
        </section>
      </div>
      <div class="demand-direction-modal-actions">
        <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('materials', $scopeFilter)) ?>">Открыть готовые материалы</a>
        <?php if ($limitDirectionId !== ''): ?>
          <button class="btn" type="button" data-demand-direction-modal-open="<?= e($limitDirectionId) ?>" data-demand-direction-budget="standard">Запустить standard</button>
        <?php endif; ?>
        <button class="btn secondary" type="button" data-demand-limit-modal-close>Отложить</button>
      </div>
    </section>
  <?php endif; ?>
  <?php $demandCanOpenAiDirectionModal = function_exists('demand_ai_dialog_can_access') && demand_ai_dialog_can_access(); ?>
  <?php if ($modalDirectionsById && ($demandCanOpenAiDirectionModal || has_permission('demand.wordstat.sync'))): ?>
    <div class="demand-direction-modal-backdrop" data-demand-direction-modal-backdrop hidden></div>
    <?php foreach ($modalDirectionsById as $direction): ?>
      <?php
        $directionId = (string) ($direction['directionId'] ?? '');
        $directionTitle = (string) ($direction['title'] ?? 'Направление спроса');
        $fingerprint = (string) ($direction['processingFingerprint'] ?? '');
        $defaultBudget = (string) ($direction['budgetMode'] ?? 'economy');
        if (!isset($demandBudgetModes[$defaultBudget])) {
            $defaultBudget = 'economy';
        }
        $sessionPrompt = 'Обработай направление "' . $directionTitle . '" как отдельную AI direction-сессию. Работай только внутри выбранного направления, соблюдай выбранный budget mode, не публикуй страницы, не открывай индексацию, не меняй sitemap.xml, robots.txt, цены, залоги, автомобили, заявки, аренды, клиентов, финансы, документы, пользователей, роли и права. Если нужны подтверждение, Wordstat live, публикация, индексация или бизнес-решение — остановись и покажи решение человеку.';
      ?>
      <?php if ($demandCanOpenAiDirectionModal): ?>
      <section class="demand-direction-modal" data-demand-direction-modal="<?= e($directionId) ?>" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="demand-direction-modal-title-<?= e($directionId) ?>">
        <div class="demand-direction-modal-head">
          <div>
            <span class="eyebrow">AI-сессия направления</span>
            <h2 id="demand-direction-modal-title-<?= e($directionId) ?>">Запустить AI-сессию: <?= e($directionTitle) ?></h2>
            <p class="muted">AI обработает одно направление в рамках бюджета и остановится перед действиями, которые требуют контроля.</p>
          </div>
          <button class="icon-btn" type="button" data-demand-direction-modal-close aria-label="Закрыть">×</button>
        </div>
        <form method="post" class="demand-direction-session-form">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="tab" value="start">
          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
          <input type="hidden" name="action" value="demand_ai_dialog_ask">
          <?= demand_ai_content_command_fields('demand_ai_dialog_ask') ?>
          <input type="hidden" name="context_tab" value="start">
          <input type="hidden" name="direction_id" value="<?= e($directionId) ?>">
          <input type="hidden" name="direction_title" value="<?= e($directionTitle) ?>">
          <input type="hidden" name="processing_fingerprint" value="<?= e($fingerprint) ?>">
          <input type="hidden" name="direction_session_source" value="demand_master">
          <textarea name="ai_dialog_message" hidden><?= e($sessionPrompt) ?></textarea>

          <label class="field">
            Режим расхода
            <select name="direction_budget_mode" data-demand-direction-budget-select>
              <?php foreach ($demandBudgetModes as $modeKey => $mode): ?>
                <option value="<?= e((string) $modeKey) ?>" <?= $modeKey === $defaultBudget ? 'selected' : '' ?>><?= e(demand_ai_budget_mode_label((string) $modeKey)) ?></option>
              <?php endforeach; ?>
            </select>
          </label>

          <div class="demand-direction-budget-grid">
            <?php foreach ($demandBudgetModes as $modeKey => $mode): ?>
              <article class="demand-direction-budget-card<?= $modeKey === $defaultBudget ? ' is-default' : '' ?>" data-demand-direction-budget-card="<?= e((string) $modeKey) ?>">
                <strong><?= e(demand_ai_budget_mode_label((string) $modeKey)) ?></strong>
                <span>AI-вызовы: <?= e((string) ($mode['maxAiCalls'] ?? 0)) ?></span>
                <span>Seed-фразы: <?= e((string) ($mode['maxSeedPhrases'] ?? 0)) ?></span>
                <span>Кластеры: <?= e((string) ($mode['maxClusters'] ?? 0)) ?></span>
                <span>Черновики: <?= !empty($mode['draftCreationAllowed']) ? 'до ' . e((string) ($mode['maxDrafts'] ?? 0)) . ' draft/blocked' : 'нет' ?></span>
                <span>Реальные данные Wordstat: отдельное подтверждение</span>
              </article>
            <?php endforeach; ?>
          </div>

          <div class="demand-direction-modal-columns">
            <section>
              <h3>AI может</h3>
              <ul>
                <li>подготовить seed-фразы и классификацию внутри выбранного направления;</li>
                <li>собрать краткое ТЗ, FAQ, подсказки и внутренние ссылки в рамках бюджета;</li>
                <li>в trusted_economy создать не больше 1 безопасного draft/blocked черновика;</li>
                <li>сохранить owner-facing summary в историю AI-сессий.</li>
              </ul>
            </section>
            <section>
              <h3>AI остановится, если</h3>
              <ul>
                <li>достигнет лимита бюджета;</li>
                <li>найдёт соседние направления;</li>
                <li>понадобится бизнес-решение или групповое подтверждение;</li>
                <li>следующий шаг касается публикации, индексации, sitemap, robots или Wordstat live.</li>
              </ul>
            </section>
            <section>
              <h3>AI не будет менять</h3>
              <ul>
                <?php foreach (demand_ai_protected_non_change_guarantees() as $guarantee): ?>
                  <li><?= e((string) $guarantee) ?></li>
                <?php endforeach; ?>
              </ul>
            </section>
          </div>

          <div class="demand-direction-modal-actions">
            <button class="btn" type="submit">Запустить</button>
            <button class="btn secondary" type="button" data-demand-direction-modal-close>Отмена</button>
          </div>
        </form>
      </section>
      <?php endif; ?>
      <?php if (isset($demandDirectionWordstatPackets[$directionId])): ?>
        <?php
          $wordstatPacket = $demandDirectionWordstatPackets[$directionId];
          $wordstatModalId = 'wordstat-' . $directionId;
          $packetSeedPhrases = (array) ($wordstatPacket['seedPhrases'] ?? []);
          $packetRegionIds = (array) ($wordstatPacket['regionIds'] ?? []);
          $packetRegionLabels = (array) ($wordstatPacket['regionLabels'] ?? []);
          $packetMethods = (array) ($wordstatPacket['methods'] ?? []);
          $packetWarnings = (array) ($wordstatPacket['warnings'] ?? []);
          $packetCanRun = (bool) $packetMethods;
          $packetHasDuplicate = !empty($wordstatPacket['existingDryRunId']);
        ?>
        <section class="demand-direction-modal demand-direction-wordstat-modal" data-demand-direction-modal="<?= e($wordstatModalId) ?>" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="demand-direction-wordstat-modal-title-<?= e($directionId) ?>">
          <div class="demand-direction-modal-head">
            <div>
              <span class="eyebrow">Проверка Wordstat по направлению</span>
              <h2 id="demand-direction-wordstat-modal-title-<?= e($directionId) ?>">Проверить без изменения данных: <?= e((string) ($wordstatPacket['directionTitle'] ?? $directionTitle)) ?></h2>
              <p class="muted">Это проверка плана запросов. Она не запускает live и не меняет данные спроса.</p>
            </div>
            <button class="icon-btn" type="button" data-demand-direction-modal-close aria-label="Закрыть">×</button>
          </div>
          <form method="post" class="demand-direction-session-form demand-direction-wordstat-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="start">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="direction_wordstat_dry_run">
            <?= demand_integration_command_fields('direction_wordstat_dry_run') ?>
            <input type="hidden" name="target_scope_id" value="<?= e($scopeFilter !== 'all' ? $scopeFilter : 'rent_rk') ?>">
            <input type="hidden" name="direction_id" value="<?= e($directionId) ?>">
            <input type="hidden" name="direction_title" value="<?= e((string) ($wordstatPacket['directionTitle'] ?? $directionTitle)) ?>">
            <input type="hidden" name="packet_id" value="<?= e((string) ($wordstatPacket['packetId'] ?? '')) ?>">
            <input type="hidden" name="packet_fingerprint" value="<?= e((string) ($wordstatPacket['packetFingerprint'] ?? '')) ?>">
            <input type="hidden" name="budget_mode" value="<?= e((string) ($wordstatPacket['budgetMode'] ?? $defaultBudget)) ?>">
            <input type="hidden" name="dry_run_only" value="1">
            <input type="hidden" name="return_anchor" value="simple-ai-workspace">
            <input type="hidden" name="wordstat_workspace_editable" value="1">
            <?php if ($packetHasDuplicate): ?><input type="hidden" name="force_rebuild" value="1"><?php endif; ?>

            <div class="demand-direction-wordstat-summary">
              <dl class="wordstat-kv">
                <dt>Направление</dt><dd><?= e((string) ($wordstatPacket['directionTitle'] ?? $directionTitle)) ?></dd>
                <dt>Режим работы</dt><dd><?= e(demand_ai_budget_mode_label((string) ($wordstatPacket['budgetMode'] ?? $defaultBudget))) ?></dd>
                <dt>Запросов</dt><dd><?= e((string) ($wordstatPacket['estimatedRequests'] ?? 0)) ?></dd>
                <dt>Примерная стоимость</dt><dd><?= e(number_format((float) ($wordstatPacket['estimatedCostRub'] ?? 0.0), 4, '.', '')) ?> RUB</dd>
              </dl>
            </div>

            <div class="demand-direction-modal-columns">
              <section>
                <h3>Стартовые фразы</h3>
                <?php if (!$packetSeedPhrases): ?><p class="field-hint warning">Нужно добавить стартовые фразы.</p><?php endif; ?>
                <textarea name="seed_phrases" rows="7" data-demand-direction-dirty-watch data-demand-direction-autofocus><?= e(implode("\n", $packetSeedPhrases)) ?></textarea>
              </section>
              <section>
                <h3>Регионы Wordstat</h3>
                <?php if (!$packetRegionIds): ?><p class="field-hint warning">Нужно выбрать регион.</p><?php endif; ?>
                <input type="text" name="region_ids" value="<?= e(implode(', ', $packetRegionIds)) ?>" placeholder="Например: 11470" data-demand-direction-dirty-watch>
                <?php if ($packetRegionLabels): ?><p class="field-hint"><?= e(implode('; ', array_map('strval', $packetRegionLabels))) ?></p><?php endif; ?>
              </section>
              <section>
                <h3>Методы</h3>
                <?php foreach (['getTop', 'getDynamics'] as $method): ?>
                  <label class="check-row">
                    <input type="checkbox" name="methods[]" value="<?= e($method) ?>" <?= in_array($method, $packetMethods, true) ? 'checked' : '' ?> data-demand-direction-dirty-watch>
                    <span><?= e(demand_admin_wordstat_method_label($method)) ?></span>
                  </label>
                <?php endforeach; ?>
              </section>
            </div>

            <?php if ($packetWarnings): ?>
              <div class="notice warning">
                <strong>Предупреждения</strong>
                <ul class="notice-list">
                  <?php foreach ($packetWarnings as $warning): ?>
                    <?php
                      $warningText = match ((string) $warning) {
                          'needs_region_confirmation' => 'Нужно выбрать регион',
                          'needs_seed_phrases' => 'Нужно добавить стартовые фразы',
                          default => demand_admin_ui_label((string) $warning),
                      };
                    ?>
                    <li><?= e($warningText) ?></li>
                  <?php endforeach; ?>
                </ul>
              </div>
            <?php endif; ?>

            <?php if ($packetHasDuplicate): ?>
              <div class="notice info">
                <strong><?= e(str_replace('fingerprint', 'параметры проверки', (string) ($wordstatPacket['duplicateMessage'] ?? 'Проверка по этому направлению уже подготовлена. Данные не изменились.'))) ?></strong>
                <p>Повторная проверка с теми же параметрами не будет создана без явного выбора “Подготовить заново”.</p>
              </div>
            <?php endif; ?>

            <div class="demand-direction-wordstat-guarantees">
              <strong>Гарантированно не меняются</strong>
              <ul>
                <?php foreach (array_merge((array) ($wordstatPacket['notChangedGuarantees'] ?? []), [
                    'prices/deposits/cars/requests/rentals/clients/finance/documents/users/roles',
                ]) as $guarantee): ?>
                  <li><?= e((string) $guarantee) ?></li>
                <?php endforeach; ?>
              </ul>
            </div>

            <div class="demand-direction-modal-actions">
              <?php if ($packetHasDuplicate): ?>
                <button class="btn secondary" type="button" data-demand-direction-modal-close>Открыть результат в этом окне</button>
                <button class="btn" type="submit" <?= $packetCanRun ? '' : 'disabled' ?>>Подготовить заново</button>
              <?php else: ?>
                <button class="btn" type="submit" <?= $packetCanRun ? '' : 'disabled' ?>>Запустить проверку без изменения данных</button>
              <?php endif; ?>
              <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('wordstat_help', $scopeFilter)) ?>">Ручной режим Wordstat</a>
              <button class="btn secondary" type="button" data-demand-direction-modal-close>Отмена</button>
            </div>
          </form>
        </section>
      <?php endif; ?>
    <?php endforeach; ?>
  <?php endif; ?>
<?php elseif ($tab === 'materials'): ?>
  <article class="panel demand-materials-panel" id="demand-materials">
    <div class="panel-head">
      <div>
        <h2>Материалы</h2>
        <p class="muted">Здесь собраны результаты работы AI и карты спроса. Главный вход: готовые черновики, ТЗ, FAQ и подсказки для авто.</p>
      </div>
      <a class="btn" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => 'all'])) ?>#demand-drafts-worklist">Готовые черновики</a>
    </div>
    <div class="demand-material-grid">
      <?php foreach ($demandMaterialGroups as $material): ?>
        <a class="demand-material-card<?= !empty($material['primary']) ? ' is-primary' : '' ?>" href="<?= e((string) ($material['href'] ?? '#')) ?>">
          <span><?= e((string) ($material['title'] ?? '')) ?></span>
          <strong><?= e((string) ($material['count'] ?? 0)) ?></strong>
          <p><?= e((string) ($material['text'] ?? '')) ?></p>
          <em><?= e((string) ($material['button'] ?? 'Открыть')) ?></em>
        </a>
      <?php endforeach; ?>
    </div>
  </article>

  <article class="panel" id="demand-materials-drafts">
    <div class="panel-head">
      <div>
        <h2>Быстрый список черновиков</h2>
        <p class="muted">Черновики доступны за 1 клик. Полный список с фильтрами находится в разделе “Черновики и публикация”.</p>
      </div>
      <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => 'all'])) ?>#demand-drafts-worklist">Все черновики</a>
    </div>
    <div class="demand-draft-worklist is-compact">
      <?php foreach (array_slice($drafts, 0, 6) as $draft): ?>
        <?php
          $stage = demand_simple_publish_stage($draft);
          $draftId = (string) ($draft['id'] ?? '');
          $draftHref = has_permission('demand.drafts.edit') ? demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $draftId]) : demand_admin_scope_filter_url('drafts', $scopeFilter, ['preview_draft' => $draftId]);
        ?>
        <article class="demand-draft-card is-<?= e((string) ($stage['key'] ?? 'draft')) ?>">
          <div class="demand-draft-card-main">
            <div class="demand-draft-card-title">
              <div>
                <h3><?= e((string) ($draft['h1'] ?? $draft['title'] ?? $draft['slug'] ?? 'Черновик')) ?></h3>
                <p><?= e((string) ($draft['slug'] ?? '')) ?></p>
              </div>
              <span class="status <?= e(demand_admin_status_class((string) ($stage['key'] ?? 'draft'))) ?>"><?= e((string) ($stage['label'] ?? 'Черновик')) ?></span>
            </div>
            <dl class="demand-draft-card-meta">
              <div><dt>Что мешает</dt><dd><?= e(demand_admin_draft_blockers_text($draft)) ?></dd></div>
              <div><dt>Главное действие</dt><dd><?= e(demand_admin_draft_next_action_text($draft)) ?></dd></div>
            </dl>
          </div>
          <div class="demand-draft-card-actions">
            <a class="btn" href="<?= e($draftHref) ?>">Открыть</a>
          </div>
        </article>
      <?php endforeach; ?>
      <?php if (!$drafts): ?>
        <div class="demand-empty-state">
          <strong>Черновиков пока нет.</strong>
          <p>Запустите мастер спроса или откройте план страниц и создайте первый безопасный черновик.</p>
          <a class="btn" href="<?= e(demand_admin_scope_filter_url('start', $scopeFilter)) ?>">Открыть мастер спроса</a>
        </div>
      <?php endif; ?>
    </div>
  </article>
<?php elseif ($tab === 'technical'): ?>
  <article class="panel demand-technical-home" id="demand-technical">
    <div class="panel-head">
      <div>
        <h2>Техническое</h2>
        <p class="muted">Сюда вынесены Wordstat logs, dry-run logs, cost ledger, scoring details, raw JSON, lifecycle, AI API logs, workflow metadata, provider details и служебные статусы.</p>
      </div>
      <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('start', $scopeFilter)) ?>">Вернуться к мастеру</a>
    </div>
    <div class="demand-technical-grid">
      <?php foreach ([
        ['title' => 'Wordstat и источники', 'text' => 'Dry-run, controlled live, регионы, cost ledger и журналы загрузок.', 'href' => demand_admin_scope_filter_url('wordstat_help', $scopeFilter, ['view' => 'detail'])],
        ['title' => 'AI API и логи', 'text' => 'DeepSeek settings, лимиты, metadata-only журналы и статусы provider.', 'href' => demand_admin_scope_filter_url('settings', $scopeFilter, ['view' => 'detail']) . '#demand-ai-api-settings'],
        ['title' => 'Жизненный цикл страниц', 'text' => 'История черновиков, readiness, preview/noindex/search workflow.', 'href' => demand_admin_scope_filter_url('drafts', $scopeFilter, ['view' => 'detail']) . '#demand-drafts-worklist'],
        ['title' => 'Raw-таблицы спроса', 'text' => 'Фразы, scoring details, карта спроса и полный launch plan.', 'href' => demand_admin_scope_filter_url('demand_map', $scopeFilter, ['view' => 'detail']) . '#demand-map-technical-table'],
      ] as $item): ?>
        <a class="demand-technical-card" href="<?= e((string) $item['href']) ?>">
          <strong><?= e((string) $item['title']) ?></strong>
          <span><?= e((string) $item['text']) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </article>

  <details class="panel demand-technical-details">
    <summary><span>Что AI может делать автоматически</span><small>Demand-only safe workflow</small></summary>
    <div class="demand-brief-grid">
      <div><h3>auto_safe</h3><p>Анализ экрана, seed-фразы, очистка мусора, классификация, приоритеты, план действий и итог workflow.</p></div>
      <div><h3>safe_write</h3><p>Сохранить AI seed, пересчитать рекомендации/карту, создать ТЗ, подсказку для авто, admin note и summary.</p></div>
      <div><h3>Нужно подтверждение</h3><p>Пакетное создание черновиков, применение текста к черновику, FAQ/безопасные блоки и Wordstat dry-run.</p></div>
      <div><h3>Запрещено</h3><p>Публикация, индексация, sitemap, robots, цены, залоги, авто, заявки, аренды, клиенты, финансы, пользователи, роли и уведомления.</p></div>
    </div>
  </details>
<?php elseif ($tab === 'overview'): ?>
  <section class="stats-grid report-stats">
    <div class="stat-card"><span>Фраз загружено</span><strong><?= e((string) $stats['keywords']) ?></strong><small><?= e(implode(', ', $scopeIds)) ?></small></div>
    <div class="stat-card"><span>Активных рекомендаций</span><strong><?= e((string) $stats['activeRecommendations']) ?></strong><small>новые / на проверке</small></div>
    <div class="stat-card"><span>Черновиков страниц</span><strong><?= e((string) $stats['drafts']) ?></strong><small>пока только в админке</small></div>
    <div class="stat-card stat-card-alert"><span>Не публиковать</span><strong><?= e((string) $stats['doNotPublish']) ?></strong><small>безопасный стоп</small></div>
    <div class="stat-card"><span>Карточки авто</span><strong><?= e((string) $stats['carCardHints']) ?></strong><small>есть подсказки</small></div>
    <div class="stat-card"><span>Последний импорт</span><strong><?= e($stats['lastImport'] !== '' ? format_admin_datetime($stats['lastImport']) : 'нет') ?></strong><small>по обновлению фраз</small></div>
  </section>
  <section class="demand-next-action is-<?= e((string) ($demandNextAction['tone'] ?? 'safe')) ?>">
    <div>
      <span>Следующее действие</span>
      <strong><?= e((string) $demandNextAction['title']) ?></strong>
      <p><?= e((string) $demandNextAction['text']) ?></p>
    </div>
    <a class="btn secondary" href="<?= e((string) $demandNextAction['href']) ?>"><?= e((string) $demandNextAction['button']) ?></a>
  </section>
  <article class="panel">
    <div class="panel-head">
      <div>
        <h2>Безопасный контур работ</h2>
        <p class="muted">Модуль не создаёт публичные файлы, не меняет карту сайта для поисковиков, не открывает страницы для поиска и не обещает условий, которых нет в данных автопарка.</p>
      </div>
    </div>
    <div class="demand-overview-grid">
      <div><strong>Что можно делать</strong><p>Импортировать фразы, пересчитывать рекомендации, готовить черновики и улучшать карточки авто.</p></div>
      <div><strong>Что блокируется</strong><p>Запросы без подходящих авто, ложные обещания вроде “без залога” и массовые дубли город × класс × условие.</p></div>
      <div><strong>Что дальше</strong><p>После накопления идей можно подключать внешние источники и отдельный процесс ручного допуска к индексации.</p></div>
    </div>
  </article>
<?php elseif ($tab === 'demand_map'): ?>
  <section class="stats-grid report-stats">
    <div class="stat-card"><span>Кластеров</span><strong><?= e((string) $demandMapStats['clusters']) ?></strong><small>смысловые группы спроса</small></div>
    <div class="stat-card"><span>Высокий приоритет</span><strong><?= e((string) $demandMapStats['high']) ?></strong><small>готовить первыми</small></div>
    <div class="stat-card"><span>Средний приоритет</span><strong><?= e((string) $demandMapStats['medium']) ?></strong><small>после базовых страниц</small></div>
    <div class="stat-card stat-card-alert"><span>Риски / бизнес-решения</span><strong><?= e((string) $demandMapStats['blocked']) ?></strong><small>без автопубликации</small></div>
    <div class="stat-card"><span>Спрос без предложения</span><strong><?= e((string) $demandMapStats['demandNoSupply']) ?></strong><small>нужна проверка парка</small></div>
    <div class="stat-card"><span>Готово к черновику</span><strong><?= e((string) $demandMapStats['readyForDraft']) ?></strong><small>после ручной проверки</small></div>
  </section>

  <article class="panel demand-map-panel">
    <div class="panel-head">
      <div>
        <h2>Карта спроса</h2>
        <p class="muted">Похожие запросы сгруппированы по смыслу. Карта не публикует страницы, не меняет карту сайта для поисковиков и не открывает поиск.</p>
      </div>
      <div class="actions">
        <?php if (has_permission('demand.map.manage')): ?>
          <form method="post" class="inline-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="demand_map">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_map_recalculate">
            <?= demand_editorial_command_fields('demand_map_recalculate') ?>
            <button class="btn" type="submit">Пересчитать карту</button>
          </form>
        <?php endif; ?>
        <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter, ['export' => 'csv'])) ?>">CSV</a>
        <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter, ['export' => 'json'])) ?>">JSON</a>
        <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter, ['export' => 'print'])) ?>">Печать</a>
      </div>
    </div>

    <?php $demandMapMainGroups = ['first', 'decision', 'faq', 'no', 'drafts']; ?>
    <section class="demand-map-priority-board" aria-label="Основные группы карты спроса">
      <div class="demand-map-summary-row">
        <div><span>Всего направлений</span><strong><?= e((string) $demandMapStats['clusters']) ?></strong></div>
        <div><span>Высокий приоритет</span><strong><?= e((string) $demandMapStats['high']) ?></strong></div>
        <div><span>Готово к черновику</span><strong><?= e((string) $demandMapStats['readyForDraft']) ?></strong></div>
        <div><span>Нужно решение</span><strong><?= e((string) $demandMapStats['blocked']) ?></strong></div>
        <div><span>Не делать</span><strong><?= e((string) count($demandMapCardGroups['no']['items'] ?? [])) ?></strong></div>
      </div>
      <div class="demand-map-group-grid">
        <?php foreach ($demandMapMainGroups as $groupKey): ?>
          <?php
            $group = $demandMapCardGroups[$groupKey] ?? ['label' => demand_admin_map_group_label($groupKey), 'items' => []];
            $groupItems = array_slice((array) ($group['items'] ?? []), 0, 4);
          ?>
          <article class="demand-map-group-card is-<?= e($groupKey) ?>">
            <div class="panel-head">
              <div>
                <h3><?= e((string) ($group['label'] ?? demand_admin_map_group_label($groupKey))) ?></h3>
                <p class="muted"><?= e((string) count((array) ($group['items'] ?? []))) ?> направлений</p>
              </div>
            </div>
            <div class="demand-map-card-list">
              <?php if (!$groupItems): ?>
                <p class="muted">Пока нет направлений в этой группе.</p>
              <?php endif; ?>
              <?php foreach ($groupItems as $item): ?>
                <?php
                  $cluster = (array) ($item['cluster'] ?? []);
                  $plan = (array) ($item['plan'] ?? []);
                  $action = (array) ($item['action'] ?? []);
                  $doneParts = [];
                  if (!empty($plan['briefId'])) {
                      $doneParts[] = 'ТЗ';
                  }
                  if (!empty($item['hasDraft'])) {
                      $doneParts[] = 'черновик';
                  }
                  if (!empty($cluster['stageC']['recommendedFaq'])) {
                      $doneParts[] = 'FAQ';
                  }
                  $doneText = $doneParts ? implode(', ', $doneParts) : 'нужен следующий шаг';
                  $blockerText = demand_admin_stage_b_blocks_text($cluster);
                  if ($blockerText === '') {
                      $blockerText = !empty($plan['blockers']) ? implode(', ', array_slice((array) $plan['blockers'], 0, 2)) : 'нет явного блокера';
                  }
                ?>
                <div class="demand-map-card">
                  <div>
                    <strong><?= e((string) ($cluster['name'] ?? 'Направление')) ?></strong>
                    <p><?= e((string) ($plan['reason'] ?? $cluster['scoringExplanation'] ?? 'AI выделил направление по спросу и готовности предложения.')) ?></p>
                    <small>AI сделал: <?= e($doneText) ?> · Мешает: <?= e($blockerText) ?></small>
                  </div>
                  <?php if (!empty($action['href'])): ?>
                    <a class="btn secondary" href="<?= e((string) $action['href']) ?>"><?= e((string) ($action['label'] ?? 'Открыть')) ?></a>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    </section>

    <details class="demand-technical-details demand-map-all-data" id="demand-map-clusters">
      <summary><span id="demand-map-technical-table">Показать все данные карты спроса</span><small>Таблица, фильтры, scoring и технические признаки свернуты.</small></summary>
      <div class="demand-filter-row">
      <?php foreach ([
        'all' => 'Все',
        'high' => 'Высокий приоритет',
        'city' => 'Города',
        'car_class' => 'Классы авто',
        'condition' => 'Условия',
        'blocked' => 'Заблокировано',
        'needs_business_decision' => 'Нужно решение',
        'no_matching_cars' => 'Нет подходящих авто',
        'ready_draft' => 'Готово к черновику',
      ] as $filterKey => $label): ?>
        <a class="<?= $demandMapFilter === $filterKey ? 'is-active' : '' ?>" href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter, ['map_filter' => $filterKey])) ?>#demand-map-clusters"><?= e($label) ?></a>
      <?php endforeach; ?>
    </div>

      <div class="table-wrap">
      <table class="report-table demand-table demand-map-table">
        <thead><tr><th>Кластер</th><th>Тип</th><th>Регион</th><th>Частотность</th><th>Фраз</th><th>Авто</th><th>Страница</th><th>Риск</th><th>Приоритет</th><th>Действие</th></tr></thead>
        <tbody>
        <?php if (!$demandMapClusters): ?><tr><td colspan="10">Карта спроса пока не пересчитана. Нажмите "Пересчитать карту".</td></tr><?php endif; ?>
        <?php if ($demandMapClusters && !$demandMapDisplayClusters): ?><tr><td colspan="10">По выбранному фильтру кластеров нет.</td></tr><?php endif; ?>
        <?php foreach ($demandMapDisplayClusters as $cluster): ?>
          <?php $clusterPlan = current(array_filter($demandMapPlans, static fn(array $plan): bool => (string) ($plan['clusterId'] ?? '') === (string) ($cluster['id'] ?? ''))) ?: []; ?>
          <tr>
            <th><a href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter, ['cluster_id' => (string) ($cluster['id'] ?? '')])) ?>"><?= e((string) ($cluster['name'] ?? '')) ?></a><small><?= e((string) ($cluster['primaryPhrase'] ?? '')) ?></small></th>
            <td><?= e(demand_admin_ui_label((string) ($cluster['clusterType'] ?? ''))) ?></td>
            <td><?= e((string) ($cluster['regionName'] ?? '')) ?></td>
            <td><?= e((string) ($cluster['totalFrequency'] ?? 0)) ?></td>
            <td><?= e((string) ($cluster['keywordCount'] ?? 0)) ?></td>
            <td><?= e((string) count((array) ($cluster['linkedCars'] ?? []))) ?></td>
            <td><?= !empty($cluster['hasExistingPage']) ? 'есть' : 'нет' ?></td>
            <td><?= e(demand_admin_stage_b_blocks_text($cluster)) ?></td>
            <td><span class="status <?= e(demand_admin_status_class((string) ($cluster['priority'] ?? ''))) ?>"><?= e(demand_admin_priority_label((string) ($cluster['priority'] ?? ''))) ?></span><small><?= e((string) ($cluster['scoringExplanation'] ?? '')) ?></small></td>
            <td><?= e(demand_admin_ui_label((string) ($clusterPlan['recommendedAction'] ?? ''))) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </details>
  </article>

  <?php if ($selectedDemandCluster): ?>
    <?php
      $selectedKeywordIds = (array) ($selectedDemandCluster['keywordIds'] ?? []);
      $selectedKeywords = array_values(array_filter($keywords, static fn(array $keyword): bool => in_array((string) ($keyword['id'] ?? ''), $selectedKeywordIds, true)));
      $selectedPlan = current(array_filter($demandMapPlans, static fn(array $plan): bool => (string) ($plan['clusterId'] ?? '') === (string) ($selectedDemandCluster['id'] ?? ''))) ?: [];
    ?>
    <article class="panel demand-cluster-card">
      <div class="panel-head">
        <div>
          <h2><?= e((string) ($selectedDemandCluster['name'] ?? 'Кластер')) ?></h2>
          <p class="muted"><?= e((string) ($selectedPlan['reason'] ?? '')) ?></p>
        </div>
        <span class="status <?= e(demand_admin_status_class((string) ($selectedDemandCluster['priority'] ?? ''))) ?>"><?= e(demand_admin_priority_label((string) ($selectedDemandCluster['priority'] ?? ''))) ?> · <?= e((string) ($selectedDemandCluster['priorityScore'] ?? 0)) ?></span>
      </div>
      <div class="demand-cluster-grid">
        <div>
          <h3>Фразы</h3>
          <ul class="demand-hint-list">
            <?php foreach ($selectedKeywords as $keyword): ?><li><?= e((string) ($keyword['phrase'] ?? '')) ?> · <?= e((string) ($keyword['frequency'] ?? 0)) ?></li><?php endforeach; ?>
          </ul>
        </div>
        <div>
          <h3>Подходящие авто</h3>
          <ul class="demand-hint-list">
            <?php foreach ((array) ($selectedDemandCluster['linkedCars'] ?? []) as $carSlug): ?><li><?= e(car_name((string) $carSlug)) ?> <small><?= e((string) $carSlug) ?></small></li><?php endforeach; ?>
            <?php if (empty($selectedDemandCluster['linkedCars'])): ?><li>Подходящие авто не подтверждены.</li><?php endif; ?>
          </ul>
        </div>
        <div>
          <h3>Почему такой приоритет</h3>
          <dl class="wordstat-kv">
            <dt>Спрос</dt><dd><?= e((string) ($selectedDemandCluster['totalFrequency'] ?? 0)) ?></dd>
            <dt>Предложение</dt><dd><?= e((string) ($selectedDemandCluster['supplyScore'] ?? 0)) ?></dd>
            <dt>Коммерческий спрос</dt><dd><?= e((string) ($selectedDemandCluster['commercialScore'] ?? 0)) ?></dd>
            <dt>Пробел в контенте</dt><dd><?= e((string) ($selectedDemandCluster['contentGapScore'] ?? 0)) ?></dd>
            <dt>Штраф за риск</dt><dd><?= e((string) ($selectedDemandCluster['riskScore'] ?? 0)) ?></dd>
          </dl>
        </div>
      </div>
      <div class="demand-brief-grid">
        <div>
          <h3>Что должна объяснить страница</h3>
          <p><?= e(demand_admin_stage_c_questions_text($selectedDemandCluster, 5)) ?></p>
        </div>
        <div>
          <h3>Какие блоки нужны</h3>
          <p><?= e(demand_admin_stage_c_blocks_text($selectedDemandCluster, 5)) ?></p>
        </div>
        <div>
          <h3>Чего не хватает</h3>
          <p><?= e(demand_admin_stage_c_gap_text($selectedDemandCluster, 5)) ?></p>
        </div>
        <div>
          <h3>Готовность</h3>
          <p><?= e(demand_admin_stage_c_score_text($selectedDemandCluster, 'userClarityScore')) ?></p>
          <small><?= e(demand_admin_stage_c_score_text($selectedDemandCluster, 'aiSearchReadiness')) ?></small>
        </div>
      </div>
    </article>
    <?php demand_admin_ai_render_panel('demand_cluster', (string) ($selectedDemandCluster['id'] ?? ''), $scopeFilter, 'demand_map', [
        'compare_with_demand' => 'Сформировать пакет по группе запросов',
        'create_page_outline' => 'Сформировать пакет для анализа спроса',
    ], $demandAiLatestPackage, $demandAiLatestPreview); ?>
    <?php demand_admin_ai_api_render_panel('demand_map', $scopeFilter, [
        'explain_demand_map' => 'Объясни эту группу запросов',
        'prioritize_launch_plan' => 'Что делать с этой группой?',
        'check_false_promises' => 'Где риски?',
    ], 'demand_cluster', (string) ($selectedDemandCluster['id'] ?? ''), $demandAiApiLatest, $demandAiApiSettings); ?>
  <?php endif; ?>

  <?php
    $latestAiEntityType = (string) ($demandAiLatestPreview['entityType'] ?? $demandAiLatestPackage['entityType'] ?? '');
    $latestAiEntityId = (string) ($demandAiLatestPreview['entityId'] ?? $demandAiLatestPackage['entityId'] ?? '');
    if ($latestAiEntityType === 'launch_plan_item' && $latestAiEntityId !== '') {
        demand_admin_ai_render_panel('launch_plan_item', $latestAiEntityId, $scopeFilter, 'demand_map', [
            'create_page_outline' => 'Сформировать пакет для будущей страницы',
            'compare_with_demand' => 'Сформировать пакет для проверки, стоит ли делать страницу',
        ], $demandAiLatestPackage, $demandAiLatestPreview);
    }
  ?>

  <article class="panel" id="seo-launch-plan">
    <div class="panel-head">
      <div>
        <h2>План страниц</h2>
        <p class="muted">Здесь видно, какие страницы и материалы стоит подготовить. Черновики остаются закрытыми от поиска и дальше идут только через мастер публикации.</p>
      </div>
    </div>
    <div class="table-wrap">
      <table class="report-table demand-table">
        <thead><tr><th>Приоритет</th><th>Будущая страница / действие</th><th>Причина</th><th>Авто</th><th>Риск</th><th>Статус</th><th>Действия</th></tr></thead>
        <tbody>
        <?php if (!$demandMapPlans): ?><tr><td colspan="7">План пока пуст.</td></tr><?php endif; ?>
        <?php foreach ($demandMapPlans as $plan): ?>
          <?php
            $linkedDraft = null;
            $linkedBrief = $demandMapBriefsByPlanId[(string) ($plan['id'] ?? '')] ?? null;
            if ((string) ($plan['linkedDraftId'] ?? '') !== '') {
                $linkedDraft = demand_find_draft((string) $plan['linkedDraftId']);
            }
          ?>
          <tr>
            <td><span class="status <?= e(demand_admin_status_class((string) ($plan['priority'] ?? ''))) ?>"><?= e(demand_admin_priority_label((string) ($plan['priority'] ?? ''))) ?></span></td>
            <th><?= e((string) ($plan['title'] ?? '')) ?><small><?= e(demand_admin_ui_label((string) ($plan['planType'] ?? ''))) ?> · <?= e(demand_admin_ui_label((string) ($plan['recommendedAction'] ?? ''))) ?></small></th>
            <td>
              <?= e((string) ($plan['reason'] ?? '')) ?>
              <small>Вопросы: <?= e(demand_admin_stage_c_questions_text($plan, 3)) ?></small>
              <small>Блоки: <?= e(demand_admin_stage_c_blocks_text($plan, 3)) ?></small>
            </td>
            <td><?= e(implode(', ', (array) ($plan['linkedCars'] ?? []))) ?></td>
            <td>
              <?= e(demand_admin_stage_b_blocks_text($plan)) ?>
              <small>Чего не хватает: <?= e(demand_admin_stage_c_gap_text($plan, 3)) ?></small>
              <small>Понятность: <?= e(demand_admin_stage_c_score_text($plan, 'userClarityScore')) ?></small>
              <?php if (in_array('possible_false_promise', (array) ($plan['riskFlags'] ?? []), true)): ?>
                <small>Не делать посадочную с неподтверждённым обещанием. Безопаснее объяснить реальные условия.</small>
              <?php elseif (in_array('no_matching_cars', (array) ($plan['riskFlags'] ?? []), true)): ?>
                <small>Сначала нужно подтвердить предложение: подходящие авто не найдены.</small>
              <?php endif; ?>
            </td>
            <td><span class="status <?= e(demand_admin_status_class((string) ($plan['launchStatus'] ?? 'planned'))) ?>"><?= e(demand_admin_ui_label((string) ($plan['launchStatus'] ?? 'planned'))) ?></span></td>
            <td>
              <div class="demand-row-actions">
                <?php if ($linkedBrief): ?>
                  <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter, ['cluster_id' => (string) ($plan['clusterId'] ?? ''), 'brief_id' => (string) ($linkedBrief['id'] ?? '')])) ?>#demand-content-briefs">Открыть ТЗ</a>
                <?php elseif (has_permission('demand.content_briefs.manage')): ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="demand_map">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="action" value="demand_map_create_brief">
                    <?= demand_editorial_command_fields('demand_map_create_brief') ?>
                    <input type="hidden" name="plan_id" value="<?= e((string) ($plan['id'] ?? '')) ?>">
                    <input type="hidden" name="cluster_id" value="<?= e((string) ($plan['clusterId'] ?? '')) ?>">
                    <button class="btn secondary small" type="submit">Создать ТЗ для страницы</button>
                  </form>
                <?php endif; ?>
                <?php if (has_permission('demand.card_hints.manage') && !empty($plan['linkedCars'])): ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="demand_map">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="action" value="demand_map_create_card_hints">
                    <?= demand_editorial_command_fields('demand_map_create_card_hints') ?>
                    <input type="hidden" name="plan_id" value="<?= e((string) ($plan['id'] ?? '')) ?>">
                    <input type="hidden" name="cluster_id" value="<?= e((string) ($plan['clusterId'] ?? '')) ?>">
                    <button class="btn secondary small" type="submit">Подсказки карточек</button>
                  </form>
                <?php endif; ?>
                <?php if ($linkedDraft): ?>
                  <a class="btn small" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['preview_draft' => (string) ($linkedDraft['id'] ?? '')])) ?>">Открыть черновик</a>
                <?php elseif (has_permission('demand.drafts.create') && in_array((string) ($plan['recommendedAction'] ?? ''), ['create_landing_draft', 'create_city_landing_draft'], true)): ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="demand_map">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="action" value="demand_map_create_draft">
                    <?= demand_editorial_command_fields('demand_map_create_draft') ?>
                    <input type="hidden" name="plan_id" value="<?= e((string) ($plan['id'] ?? '')) ?>">
                    <button class="btn small" type="submit">Создать черновик</button>
                  </form>
                <?php endif; ?>
                <?php demand_admin_ai_inline_buttons('launch_plan_item', (string) ($plan['id'] ?? ''), $scopeFilter, 'demand_map', [
                    'create_page_outline' => 'Сформировать пакет для будущей страницы',
                    'compare_with_demand' => 'Сформировать пакет для проверки, стоит ли делать страницу',
                ]); ?>
                <?php if (has_permission('demand.launch_plan.manage')): ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="demand_map">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="action" value="demand_map_plan_status">
                    <?= demand_editorial_command_fields('demand_map_plan_status') ?>
                    <input type="hidden" name="plan_id" value="<?= e((string) ($plan['id'] ?? '')) ?>">
                    <input type="hidden" name="cluster_id" value="<?= e((string) ($plan['clusterId'] ?? '')) ?>">
                    <input type="hidden" name="launchStatus" value="postponed">
                    <button class="btn secondary small" type="submit">Отложить</button>
                  </form>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="demand_map">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="action" value="demand_map_plan_status">
                    <?= demand_editorial_command_fields('demand_map_plan_status') ?>
                    <input type="hidden" name="plan_id" value="<?= e((string) ($plan['id'] ?? '')) ?>">
                    <input type="hidden" name="cluster_id" value="<?= e((string) ($plan['clusterId'] ?? '')) ?>">
                    <input type="hidden" name="launchStatus" value="blocked">
                    <button class="btn secondary small" type="submit">Не делать</button>
                  </form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </article>

  <article class="panel" id="demand-content-briefs">
    <div class="panel-head">
      <div>
        <h2>ТЗ для страниц</h2>
        <p class="muted">ТЗ — это внутренний план будущей посадочной страницы: что написать, какие вопросы закрыть и каких обещаний избегать. Оно не публикуется и хранится в закрытом хранилище.</p>
      </div>
    </div>
    <?php if (!$demandMapBriefs): ?>
      <p class="empty-state">ТЗ пока нет. Нажмите "Создать ТЗ для страницы" в плане страниц — после сохранения оно появится здесь.</p>
    <?php else: ?>
      <div class="demand-brief-layout">
        <aside class="demand-brief-list" aria-label="Список ТЗ для страниц">
          <?php foreach (array_slice($demandMapBriefs, 0, 12) as $brief): ?>
            <?php $isSelectedBrief = (string) ($selectedDemandBrief['id'] ?? '') === (string) ($brief['id'] ?? ''); ?>
            <a class="<?= $isSelectedBrief ? 'is-active' : '' ?>" href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter, ['cluster_id' => (string) ($brief['clusterId'] ?? ''), 'brief_id' => (string) ($brief['id'] ?? '')])) ?>#demand-content-briefs">
              <strong><?= e((string) ($brief['title'] ?? 'ТЗ для страницы')) ?></strong>
              <small><?= e(format_admin_datetime((string) ($brief['updatedAt'] ?? $brief['createdAt'] ?? ''))) ?></small>
            </a>
          <?php endforeach; ?>
        </aside>
        <?php if ($selectedDemandBrief): ?>
          <section class="demand-brief-card">
            <div class="panel-head compact">
              <div>
                <h3><?= e((string) ($selectedDemandBrief['title'] ?? 'ТЗ для страницы')) ?></h3>
                <p class="muted">Статус: <?= e(demand_admin_ui_label((string) ($selectedDemandBrief['status'] ?? 'draft'))) ?> · контур <?= e(scope_display_name((string) ($selectedDemandBrief['scope_id'] ?? 'rent_rk'))) ?></p>
              </div>
            </div>
            <div class="demand-brief-grid">
              <div>
                <h4>Интент</h4>
                <p><?= e((string) ($selectedDemandBrief['targetIntent'] ?? '')) ?></p>
              </div>
              <div>
                <h4>Связанные авто</h4>
                <ul class="demand-hint-list">
                  <?php foreach ((array) ($selectedDemandBrief['linkedCars'] ?? []) as $carSlug): ?><li><?= e(car_name((string) $carSlug)) ?> <small><?= e((string) $carSlug) ?></small></li><?php endforeach; ?>
                  <?php if (empty($selectedDemandBrief['linkedCars'])): ?><li>Авто пока не привязаны.</li><?php endif; ?>
                </ul>
              </div>
              <div>
                <h4>Обязательно ответить</h4>
                <ul class="demand-hint-list">
                  <?php foreach ((array) ($selectedDemandBrief['mustAnswer'] ?? []) as $item): ?><li><?= e((string) $item) ?></li><?php endforeach; ?>
                </ul>
              </div>
              <div>
                <h4>Нельзя обещать</h4>
                <ul class="demand-hint-list">
                  <?php foreach ((array) ($selectedDemandBrief['mustNotPromise'] ?? []) as $item): ?><li><?= e((string) $item) ?></li><?php endforeach; ?>
                </ul>
              </div>
              <div>
                <h4>Блоки страницы</h4>
                <ul class="demand-hint-list">
                  <?php foreach ((array) ($selectedDemandBrief['recommendedBlocks'] ?? []) as $item): ?><li><?= e(demand_admin_ui_label((string) $item)) ?></li><?php endforeach; ?>
                </ul>
              </div>
              <div>
                <h4>FAQ</h4>
                <ul class="demand-hint-list">
                  <?php foreach ((array) ($selectedDemandBrief['faqQuestions'] ?? []) as $item): ?><li><?= e((string) $item) ?></li><?php endforeach; ?>
                </ul>
              </div>
              <div>
                <h4>Вопросы пользователя</h4>
                <p><?= e(demand_admin_stage_c_questions_text($selectedDemandBrief, 5)) ?></p>
              </div>
              <div>
                <h4>Чего не хватает</h4>
                <p><?= e(demand_admin_stage_c_gap_text($selectedDemandBrief, 5)) ?></p>
              </div>
              <div>
                <h4>Готовность для пользователя</h4>
                <p><?= e(demand_admin_stage_c_score_text($selectedDemandBrief, 'userClarityGoals')) ?></p>
              </div>
              <div>
                <h4>Готовность для поиска/AI</h4>
                <p><?= e(demand_admin_stage_c_score_text($selectedDemandBrief, 'aiSearchReadinessGoals')) ?></p>
              </div>
            </div>
            <details class="demand-technical-details">
              <summary>Дополнительные рекомендации Stage C</summary>
              <div class="demand-brief-grid">
                <div>
                  <h4>Внутренние связи</h4>
                  <ul class="demand-hint-list">
                    <?php foreach (array_slice((array) ($selectedDemandBrief['recommendedInternalLinks'] ?? []), 0, 6) as $link): ?>
                      <?php if (!is_array($link)) { continue; } ?>
                      <li><?= e((string) ($link['targetHint'] ?? '')) ?><small><?= e((string) ($link['reason'] ?? '')) ?></small></li>
                    <?php endforeach; ?>
                  </ul>
                </div>
                <div>
                  <h4>Карточки авто</h4>
                  <ul class="demand-hint-list">
                    <?php foreach (array_slice((array) ($selectedDemandBrief['recommendedCarCardHints'] ?? []), 0, 6) as $hint): ?>
                      <?php if (!is_array($hint)) { continue; } ?>
                      <li><?= e((string) ($hint['carName'] ?? $hint['carSlug'] ?? '')) ?><small><?= e(implode('; ', array_map('strval', (array) ($hint['hints'] ?? [])))) ?></small></li>
                    <?php endforeach; ?>
                  </ul>
                </div>
              </div>
            </details>
            <?php demand_admin_ai_render_panel('content_brief', (string) ($selectedDemandBrief['id'] ?? ''), $scopeFilter, 'demand_map', [
                'improve_content_brief' => 'Сформировать пакет для уточнения ТЗ',
                'create_faq' => 'Сформировать пакет для FAQ',
                'create_page_outline' => 'Сформировать пакет для структуры страницы',
            ], $demandAiLatestPackage, $demandAiLatestPreview); ?>
          </section>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </article>

  <div class="demand-map-split">
    <article class="panel">
      <div class="panel-head"><h2>Подсказки для карточек авто</h2></div>
      <div class="table-wrap">
        <table class="report-table demand-table">
          <thead><tr><th>Авто</th><th>Тип</th><th>Приоритет</th><th>Подсказка</th><th>Статус</th></tr></thead>
          <tbody>
          <?php if (!$demandMapCardHints): ?><tr><td colspan="5">Подсказки ещё не созданы.</td></tr><?php endif; ?>
          <?php foreach (array_slice($demandMapCardHints, 0, 20) as $hint): ?>
            <tr><th><?= e(car_name((string) ($hint['carId'] ?? ''))) ?><small><?= e((string) ($hint['carId'] ?? '')) ?></small></th><td><?= e(demand_admin_ui_label((string) ($hint['hintType'] ?? ''))) ?></td><td><?= e(demand_admin_priority_label((string) ($hint['priority'] ?? ''))) ?></td><td><?= e((string) ($hint['message'] ?? '')) ?><small><?= e((string) ($hint['suggestedText'] ?? '')) ?></small></td><td><?= e(demand_admin_ui_label((string) ($hint['status'] ?? 'new'))) ?></td></tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </article>
    <article class="panel">
      <div class="panel-head"><h2>Опасные запросы</h2></div>
      <ul class="demand-risk-list">
        <?php $dangerClusters = array_values(array_filter($demandMapClusters, static fn(array $cluster): bool => (string) ($cluster['clusterType'] ?? '') === 'price' || array_intersect((array) ($cluster['riskFlags'] ?? []), ['possible_false_promise', 'condition_not_supported', 'no_matching_cars', 'needs_human_review']) !== [])); ?>
        <?php if (!$dangerClusters): ?><li>Критичных запросов пока нет.</li><?php endif; ?>
        <?php foreach (array_slice($dangerClusters, 0, 12) as $cluster): ?>
          <li><strong><?= e((string) ($cluster['name'] ?? '')) ?></strong><span><?= e(demand_admin_list_labels((array) ($cluster['riskFlags'] ?? []), 'demand_admin_risk_label')) ?></span><p>Безопасно: сначала подтвердить реальное предложение, условия залога/цены и только потом готовить черновик через мастер публикации.</p></li>
        <?php endforeach; ?>
      </ul>
    </article>
  </div>
<?php elseif ($tab === 'keywords'): ?>
  <article class="panel">
    <div class="panel-head">
      <div>
        <h2>Что ищут люди</h2>
        <p class="muted">Здесь собраны фразы, по которым люди ищут аренду авто. По ним система понимает, какие страницы и карточки стоит готовить.</p>
      </div>
    </div>
    <div class="table-wrap">
      <table class="report-table demand-table">
        <thead><tr><th>Фраза</th><th>Регион</th><th>Частота</th><th>Категория</th><th>Намерение</th><th>Источник</th><th>Статус</th><th>Авто / страницы</th><th>Действия</th></tr></thead>
        <tbody>
        <?php if (!$keywords): ?>
          <tr><td colspan="9">Пока нет фраз спроса. Начните с ручного добавления или загрузки Wordstat. Это безопасно: страницы не публикуются.</td></tr>
        <?php endif; ?>
        <?php foreach ($keywords as $keyword): ?>
          <?php
            $matchedCars = demand_match_cars_for_keyword($keyword);
            $matchedPages = demand_find_similar_pages($keyword);
          ?>
          <tr>
            <th><?= e((string) ($keyword['phrase'] ?? '')) ?><small><?= e((string) ($keyword['scope_id'] ?? 'rent_rk')) ?></small></th>
            <td><?= e((string) ($keyword['regionName'] ?? '')) ?></td>
            <td><?= e((string) ($keyword['frequency'] ?? 0)) ?></td>
            <td><?= e(demand_admin_ui_label((string) ($keyword['category'] ?? 'unknown'))) ?></td>
            <td>
              <?= e(demand_admin_ui_label((string) ($keyword['intent'] ?? 'unknown'))) ?>
              <?php if (!empty($keyword['negativeIntent'])): ?><small><?= e(demand_admin_ui_label((string) $keyword['negativeIntent'])) ?></small><?php endif; ?>
              <?php if (!empty($keyword['decisionHint'])): ?><small>Совет: <?= e(demand_admin_ui_label((string) $keyword['decisionHint'])) ?></small><?php endif; ?>
              <?php if (!empty($keyword['adminExplanation'])): ?><small><?= e((string) $keyword['adminExplanation']) ?></small><?php endif; ?>
            </td>
            <td><?= e((string) ($keyword['source'] ?? '')) ?></td>
            <td><span class="status <?= e(demand_admin_status_class((string) ($keyword['status'] ?? 'active'))) ?>"><?= e(demand_admin_ui_label((string) ($keyword['status'] ?? 'active'))) ?></span></td>
            <td>
              <div class="demand-mini-list">
                <span><?= e((string) count($matchedCars)) ?> авто</span>
                <span><?= e((string) count($matchedPages)) ?> страниц</span>
              </div>
            </td>
            <td>
              <div class="demand-row-actions">
                <form method="post">
                  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="tab" value="keywords">
                  <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                  <input type="hidden" name="action" value="recalculate_keyword">
                  <?= demand_editorial_command_fields('recalculate_keyword') ?>
                  <input type="hidden" name="keyword_id" value="<?= e((string) ($keyword['id'] ?? '')) ?>">
                  <button class="btn secondary small" type="submit">Пересчитать</button>
                </form>
                <?php $draftRec = $createDraftRecommendationByKeyword[(string) ($keyword['id'] ?? '')] ?? null; ?>
                <?php if ($draftRec && has_permission('demand.drafts.create')): ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="keywords">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="action" value="create_draft">
                    <?= demand_editorial_command_fields('create_draft') ?>
                    <input type="hidden" name="recommendation_id" value="<?= e((string) ($draftRec['id'] ?? '')) ?>">
                    <button class="btn small" type="submit">Создать черновик</button>
                  </form>
                <?php endif; ?>
                <?php foreach (['not_target' => 'Нецелевой', 'excluded' => 'Исключить из SEO', 'archived' => 'Архив'] as $status => $label): ?>
                  <?php if (has_permission('demand.manage')): ?>
                    <form method="post">
                      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                      <input type="hidden" name="tab" value="keywords">
                      <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                      <input type="hidden" name="action" value="keyword_status">
                      <?= demand_editorial_command_fields('keyword_status') ?>
                      <input type="hidden" name="keyword_id" value="<?= e((string) ($keyword['id'] ?? '')) ?>">
                      <input type="hidden" name="status" value="<?= e($status) ?>">
                      <button class="btn secondary small" type="submit"><?= e($label) ?></button>
                    </form>
                  <?php endif; ?>
                <?php endforeach; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </article>
<?php elseif ($tab === 'import'): ?>
  <article class="panel">
    <div class="panel-head">
      <div>
        <h2>Загрузить фразы</h2>
        <p class="muted">Можно вручную добавить фразы или загрузить файл. Сначала система покажет предварительную проверку, а страницы не публикуются.</p>
      </div>
    </div>
    <?php if (!has_permission('demand.import')): ?>
      <div class="notice warning">Импорт доступен только admin Rent RK.</div>
    <?php else: ?>
      <div class="demand-import-grid">
        <form method="post" enctype="multipart/form-data" class="form-stack">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="tab" value="import">
          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
          <input type="hidden" name="action" value="preview_import">
          <?= demand_editorial_command_fields('preview_import') ?>
          <label>
            Тип файла
            <select name="import_kind">
              <option value="csv">CSV</option>
              <option value="json">JSON</option>
            </select>
          </label>
          <label>
            Контур для строк без scope_id
            <select name="target_scope_id">
              <?php foreach ($scopeOptions as $scopeId => $scopeLabel): ?><option value="<?= e($scopeId) ?>"><?= e($scopeLabel) ?></option><?php endforeach; ?>
            </select>
          </label>
          <label>
            Файл
            <input type="file" name="demand_file" accept=".csv,.json,text/csv,application/json">
          </label>
          <button class="btn" type="submit">Проверить перед загрузкой</button>
        </form>
        <form method="post" class="form-stack">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="tab" value="import">
          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
          <input type="hidden" name="action" value="preview_import">
          <?= demand_editorial_command_fields('preview_import') ?>
          <input type="hidden" name="import_kind" value="manual">
          <label>
            Контур
            <select name="target_scope_id">
              <?php foreach ($scopeOptions as $scopeId => $scopeLabel): ?><option value="<?= e($scopeId) ?>"><?= e($scopeLabel) ?></option><?php endforeach; ?>
            </select>
          </label>
          <label>Фраза <input name="manual_phrase" placeholder="аренда минивэна ялта"></label>
          <label>Регион <input name="manual_region_name" placeholder="Ялта"></label>
          <label>Частотность <input type="text" name="manual_frequency" inputmode="numeric" value="0"></label>
          <button class="btn secondary" type="submit">Проверить фразу</button>
        </form>
      </div>
    <?php endif; ?>
  </article>

  <?php if ($importPreview): ?>
    <?php
      $importPreviewRows = array_values(array_filter((array) ($importPreview['rows'] ?? []), 'is_array'));
      $importPreviewWarnings = array_values(array_filter(array_map(static fn($item): string => trim((string) $item), $importWarnings)));
      $importPreviewGroups = demand_import_preview_rows_by_group($importPreviewRows);
      $importPreviewDefinitions = demand_import_preview_group_definitions();
      $importPreviewSummary = demand_import_preview_summary($importPreviewRows, count($importPreviewWarnings));
      $importPreviewRegionOptions = [];
      foreach ($importPreviewRows as $row) {
          $kw = is_array($row['keyword'] ?? null) ? $row['keyword'] : [];
          $regionName = trim((string) ($kw['regionName'] ?? ''));
          if ($regionName !== '') {
              $importPreviewRegionOptions[$regionName] = $regionName;
          }
      }
      ksort($importPreviewRegionOptions, SORT_NATURAL | SORT_FLAG_CASE);
      $visiblePreviewLimit = 15;
    ?>
    <article class="panel">
      <div class="panel-head">
        <div>
          <h2>Разбор загруженных фраз</h2>
          <p class="muted">Система сгруппировала строки по полезности. Полный технический список доступен ниже, но по умолчанию не занимает экран.</p>
        </div>
      </div>

      <div class="demand-import-summary-grid">
        <?php foreach ([
          'total' => ['label' => 'Всего фраз', 'tone' => 'neutral'],
          'usable' => ['label' => 'Можно использовать', 'tone' => 'success'],
          'review' => ['label' => 'Нужна проверка', 'tone' => 'warning'],
          'no_page' => ['label' => 'Не создавать страницы', 'tone' => 'attention'],
          'irrelevant' => ['label' => 'Нецелевые', 'tone' => 'muted'],
          'duplicates' => ['label' => 'Дубли / обновления', 'tone' => 'neutral'],
          'errors' => ['label' => 'Ошибки', 'tone' => 'danger'],
        ] as $summaryKey => $summaryItem): ?>
          <div class="demand-import-summary-card is-<?= e((string) $summaryItem['tone']) ?>">
            <span><?= e((string) $summaryItem['label']) ?></span>
            <strong><?= e((string) ($importPreviewSummary[$summaryKey] ?? 0)) ?></strong>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="demand-import-preview-controls" data-demand-preview-controls>
        <label>
          Поиск по фразе
          <input type="search" data-demand-preview-search placeholder="Например: такси, минивэн, залог">
        </label>
        <label>
          Группа
          <select data-demand-preview-group-filter>
            <option value="">Все группы</option>
            <?php foreach (['usable', 'review', 'no_page', 'irrelevant', 'duplicates'] as $groupKey): ?>
              <option value="<?= e($groupKey) ?>"><?= e((string) ($importPreviewDefinitions[$groupKey]['label'] ?? $groupKey)) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label>
          Регион
          <select data-demand-preview-region-filter>
            <option value="">Все регионы</option>
            <?php foreach ($importPreviewRegionOptions as $regionName): ?>
              <option value="<?= e($regionName) ?>"><?= e($regionName) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label class="check-row"><input type="checkbox" data-demand-preview-risk-filter> Только с риском</label>
        <label class="check-row"><input type="checkbox" data-demand-preview-irrelevant-filter> Только нецелевые</label>
        <label class="check-row"><input type="checkbox" data-demand-preview-usable-filter> Только полезные</label>
      </div>

      <div class="demand-import-preview" data-demand-preview>
        <?php foreach (['usable', 'review', 'no_page', 'irrelevant', 'duplicates'] as $groupKey): ?>
          <?php
            $definition = $importPreviewDefinitions[$groupKey];
            $groupRows = $importPreviewGroups[$groupKey] ?? [];
          ?>
          <details class="demand-import-preview-group is-<?= e((string) $definition['tone']) ?>" data-demand-preview-group-block="<?= e($groupKey) ?>" <?= $groupKey === 'usable' ? 'open' : '' ?>>
            <summary>
              <span><?= e((string) $definition['label']) ?></span>
              <small><?= e((string) count($groupRows)) ?></small>
            </summary>
            <p class="muted"><?= e((string) $definition['description']) ?></p>
            <?php if (!$groupRows): ?>
              <p class="demand-import-preview-empty" data-demand-preview-empty><?= e((string) $definition['empty']) ?></p>
            <?php else: ?>
              <div class="demand-import-preview-list">
                <?php foreach ($groupRows as $rowIndex => $row): ?>
                  <?php
                    $kw = is_array($row['keyword'] ?? null) ? $row['keyword'] : [];
                    $phrase = (string) ($kw['phrase'] ?? '');
                    $regionName = trim((string) ($kw['regionName'] ?? ''));
                    $frequency = (int) ($kw['frequency'] ?? 0);
                    $riskLabels = demand_admin_list_labels((array) ($kw['riskFlags'] ?? []), 'demand_admin_risk_label');
                    $searchText = demand_lower(implode(' ', [
                        $phrase,
                        $regionName,
                        (string) ($row['intentLabel'] ?? ''),
                        (string) ($row['decisionLabel'] ?? ''),
                        (string) ($row['adminExplanation'] ?? ''),
                    ]));
                    $isExtraRow = $rowIndex >= $visiblePreviewLimit;
                  ?>
                  <div
                    class="demand-import-preview-row<?= $isExtraRow ? ' is-over-limit' : '' ?>"
                    data-demand-preview-row
                    data-demand-preview-group="<?= e($groupKey) ?>"
                    data-demand-preview-region="<?= e($regionName) ?>"
                    data-demand-preview-risk="<?= !empty($row['hasRisk']) ? '1' : '0' ?>"
                    data-demand-preview-useful="<?= $groupKey === 'usable' ? '1' : '0' ?>"
                    data-demand-preview-text="<?= e($searchText) ?>"
                  >
                    <div class="demand-import-preview-main">
                      <span class="demand-import-row-number">#<?= e((string) ($row['rowNumber'] ?? '')) ?></span>
                      <h3><?= e($phrase) ?></h3>
                      <p><?= e((string) ($row['adminExplanation'] ?? '')) ?></p>
                    </div>
                    <dl class="demand-import-preview-meta">
                      <div><dt>Регион</dt><dd><?= e($regionName !== '' ? $regionName : 'не указан') ?></dd></div>
                      <div><dt>Частотность</dt><dd><?= e(number_format($frequency, 0, '', ' ')) ?></dd></div>
                      <div><dt>Тип</dt><dd><?= e((string) ($row['intentLabel'] ?? 'Нужно определить')) ?></dd></div>
                      <div><dt>Решение</dt><dd><?= e((string) ($row['decisionLabel'] ?? 'Разобрать вручную')) ?></dd></div>
                    </dl>
                    <div class="demand-import-preview-badges">
                      <span class="demand-import-status is-<?= e($groupKey) ?>"><?= e((string) ($definition['summaryLabel'] ?? $definition['label'])) ?></span>
                      <span class="status <?= e(demand_admin_status_class((string) ($row['action'] ?? ''))) ?>"><?= e((string) ($row['actionLabel'] ?? demand_admin_ui_label((string) ($row['action'] ?? '')))) ?></span>
                      <?php if ($riskLabels !== '—'): ?><span class="demand-import-risk"><?= e($riskLabels) ?></span><?php endif; ?>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
              <?php if (count($groupRows) > $visiblePreviewLimit): ?>
                <button class="btn secondary small" type="button" data-demand-preview-show-group="<?= e($groupKey) ?>">Показать все в этой группе</button>
              <?php endif; ?>
            <?php endif; ?>
          </details>
        <?php endforeach; ?>

        <details class="demand-import-preview-group is-danger" data-demand-preview-group-block="errors">
          <summary>
            <span><?= e((string) $importPreviewDefinitions['errors']['label']) ?></span>
            <small><?= e((string) count($importPreviewWarnings)) ?></small>
          </summary>
          <p class="muted"><?= e((string) $importPreviewDefinitions['errors']['description']) ?></p>
          <?php if (!$importPreviewWarnings): ?>
            <p class="demand-import-preview-empty"><?= e((string) $importPreviewDefinitions['errors']['empty']) ?></p>
          <?php else: ?>
            <ul class="notice-list demand-import-error-list">
              <?php foreach ($importPreviewWarnings as $warning): ?><li><?= e($warning) ?></li><?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </details>

        <details class="demand-technical-details demand-import-technical-list" data-demand-preview-technical>
          <summary>
            <span><?= e((string) $importPreviewDefinitions['all']['label']) ?></span>
            <small><?= e((string) $importPreviewDefinitions['all']['description']) ?></small>
          </summary>
          <div class="table-wrap">
            <table class="report-table">
              <thead><tr><th>#</th><th>Фраза</th><th>Регион</th><th>Частота</th><th>Тип</th><th>Решение</th><th>Статус импорта</th><th>Риски</th></tr></thead>
              <tbody>
                <?php foreach ($importPreviewRows as $row): ?>
                  <?php
                    $kw = is_array($row['keyword'] ?? null) ? $row['keyword'] : [];
                    $riskLabels = demand_admin_list_labels((array) ($kw['riskFlags'] ?? []), 'demand_admin_risk_label');
                  ?>
                  <tr>
                    <td><?= e((string) ($row['rowNumber'] ?? '')) ?></td>
                    <th><?= e((string) ($kw['phrase'] ?? '')) ?><small><?= e((string) ($kw['scope_id'] ?? 'rent_rk')) ?></small></th>
                    <td><?= e((string) ($kw['regionName'] ?? '')) ?></td>
                    <td><?= e(number_format((int) ($kw['frequency'] ?? 0), 0, '', ' ')) ?></td>
                    <td><?= e((string) ($row['intentLabel'] ?? '')) ?></td>
                    <td><?= e((string) ($row['decisionLabel'] ?? '')) ?></td>
                    <td><span class="status <?= e(demand_admin_status_class((string) ($row['action'] ?? ''))) ?>"><?= e((string) ($row['actionLabel'] ?? '')) ?></span></td>
                    <td><?= e($riskLabels) ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </details>
      </div>

      <div class="demand-import-after-save">
        <h3>Что будет после сохранения</h3>
        <ul>
          <li>Полезные и спорные фразы будут сохранены в “Что ищут люди”.</li>
          <li>Нецелевые фразы будут сохранены как исключённые и не будут создавать страницы.</li>
          <li>Опасные фразы не будут превращаться в посадочные страницы.</li>
          <li>Дубли будут обновлены или пропущены.</li>
          <li>Страницы не публикуются автоматически.</li>
          <li>Sitemap и поиск не меняются.</li>
        </ul>
      </div>

      <form method="post" class="demand-apply-import">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="tab" value="import">
        <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
        <input type="hidden" name="action" value="apply_import">
        <?= demand_editorial_command_fields('apply_import') ?>
        <input type="hidden" name="preview_token" value="<?= e($importPreviewToken) ?>">
        <button class="btn" type="submit">Сохранить фразы и обновить советы</button>
        <p class="muted">Без публикации страниц и без изменений в поиске.</p>
      </form>
    </article>
  <?php endif; ?>
<?php elseif ($tab === 'recommendations'): ?>
  <article class="panel">
    <div class="panel-head">
      <div>
        <h2>Советы системы</h2>
        <p class="muted">Каждое действие объясняет причину: создать черновик, доработать карточку авто, добавить FAQ или не делать страницу из-за риска.</p>
      </div>
    </div>
    <div class="demand-filter-row">
      <?php foreach ([
        'all' => 'Все',
        'create_landing_page_draft' => 'Создать страницу',
        'update_car_cards' => 'Улучшить карточки',
        'add_faq' => 'FAQ',
        'do_not_publish' => 'Не публиковать',
        'need_human_review' => 'Ручная проверка',
        'high' => 'Высокий приоритет',
      ] as $filterKey => $label): ?>
        <a class="<?= $recommendationFilter === $filterKey ? 'is-active' : '' ?>" href="<?= e(demand_admin_scope_filter_url('recommendations', $scopeFilter, ['filter' => $filterKey])) ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </div>
    <div class="table-wrap">
      <table class="report-table demand-table">
        <thead><tr><th>Фраза</th><th>Рекомендация</th><th>Приоритет</th><th>Причина</th><th>Авто</th><th>Риски</th><th>Статус</th><th>Действия</th></tr></thead>
        <tbody>
        <?php if (!$recommendations): ?><tr><td colspan="8">Советов пока нет. Добавьте фразы или пересчитайте советы системы.</td></tr><?php endif; ?>
        <?php foreach ($recommendations as $rec): ?>
          <?php $kw = $keywordsById[(string) ($rec['keywordId'] ?? '')] ?? null; ?>
          <?php $nextStep = demand_admin_recommendation_next_step($rec, $scopeFilter); ?>
          <tr>
            <th><?= e((string) ($kw['phrase'] ?? $rec['keywordId'] ?? '')) ?><small><?= e((string) ($rec['scope_id'] ?? 'rent_rk')) ?></small></th>
            <td><?= e(demand_admin_recommendation_label((string) ($rec['recommendationType'] ?? ''))) ?></td>
            <td><span class="status <?= e(demand_admin_status_class((string) ($rec['priority'] ?? ''))) ?>"><?= e(demand_admin_priority_label((string) ($rec['priority'] ?? ''))) ?></span></td>
            <td><?= e((string) ($rec['reason'] ?? '')) ?></td>
            <td><?= e(implode(', ', (array) ($rec['linkedCars'] ?? []))) ?></td>
            <td><?= e(demand_admin_list_labels((array) ($rec['riskFlags'] ?? []), 'demand_admin_risk_label')) ?></td>
            <td><span class="status <?= e(demand_admin_status_class((string) ($rec['actionStatus'] ?? 'new'))) ?>"><?= e(demand_admin_recommendation_status_label((string) ($rec['actionStatus'] ?? 'new'))) ?></span></td>
            <td>
              <div class="demand-row-actions">
                <div class="demand-recommendation-next-step">
                <?php if (($nextStep['kind'] ?? '') === 'create_draft'): ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="recommendations">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="action" value="create_draft">
                    <?= demand_editorial_command_fields('create_draft') ?>
                    <input type="hidden" name="recommendation_id" value="<?= e((string) ($rec['id'] ?? '')) ?>">
                    <button class="btn small" type="submit"><?= e((string) ($nextStep['label'] ?? 'Создать черновик')) ?></button>
                  </form>
                <?php elseif (($nextStep['kind'] ?? '') === 'status'): ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="recommendations">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="action" value="recommendation_status">
                    <?= demand_editorial_command_fields('recommendation_status') ?>
                    <input type="hidden" name="recommendation_id" value="<?= e((string) ($rec['id'] ?? '')) ?>">
                    <input type="hidden" name="status" value="<?= e((string) ($nextStep['status'] ?? 'in_review')) ?>">
                    <button class="btn secondary small" type="submit"><?= e((string) ($nextStep['label'] ?? 'Взять в работу')) ?></button>
                  </form>
                <?php else: ?>
                  <a class="btn small <?= ($nextStep['tone'] ?? '') === 'secondary' ? 'secondary' : '' ?>" href="<?= e((string) ($nextStep['href'] ?? demand_admin_scope_filter_url('recommendations', $scopeFilter))) ?>"><?= e((string) ($nextStep['label'] ?? 'Следующий шаг')) ?></a>
                <?php endif; ?>
                  <small><?= e((string) ($nextStep['hint'] ?? '')) ?></small>
                </div>
                <form class="demand-status-form" method="post">
                  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="tab" value="recommendations">
                  <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                  <input type="hidden" name="action" value="recommendation_status">
                  <?= demand_editorial_command_fields('recommendation_status') ?>
                  <input type="hidden" name="recommendation_id" value="<?= e((string) ($rec['id'] ?? '')) ?>">
                  <span class="demand-status-form-label">Статус</span>
                  <select name="status" aria-label="Статус рекомендации">
                    <?php foreach (['new', 'in_review', 'done', 'rejected', 'archived'] as $status): ?><option value="<?= e($status) ?>" <?= (string) ($rec['actionStatus'] ?? 'new') === $status ? 'selected' : '' ?>><?= e(demand_admin_recommendation_status_label($status)) ?></option><?php endforeach; ?>
                  </select>
                  <button class="btn secondary small" type="submit">Сохранить статус</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </article>
<?php elseif ($tab === 'drafts'): ?>
  <?php $wizardDraft = $previewDraft ?: $editDraft; ?>
  <?php if ($wizardDraft): ?>
    <?php
      $wizardStage = demand_simple_publish_stage($wizardDraft);
      $wizardChecks = (array) ($wizardDraft['readinessChecks'] ?? []);
      $wizardGroups = demand_group_readiness_checks($wizardChecks);
      $wizardReadiness = (string) ($wizardDraft['readinessStatus'] ?? 'not_checked');
      $wizardVersions = demand_versions_for_draft((string) ($wizardDraft['id'] ?? ''));
      $wizardStatus = (string) ($wizardDraft['publishStatus'] ?? 'draft');
      $wizardBlocked = $wizardReadiness === 'blocked';
      $wizardDraftId = (string) ($wizardDraft['id'] ?? '');
      $wizardScopeId = demand_normalize_scope_id((string) ($wizardDraft['scope_id'] ?? 'rent_rk'));
      $wizardMergeTargets = array_values(array_filter($drafts, static function (array $candidate) use ($wizardDraftId, $wizardScopeId): bool {
          return (string) ($candidate['id'] ?? '') !== $wizardDraftId
              && demand_normalize_scope_id((string) ($candidate['scope_id'] ?? 'rent_rk')) === $wizardScopeId
              && !in_array((string) ($candidate['publishStatus'] ?? 'draft'), ['archived', 'merged'], true);
      }));
    ?>
    <article class="panel demand-wizard-panel">
      <div class="panel-head">
        <div>
          <h2>Публикация страницы</h2>
          <p class="muted"><?= e((string) $wizardStage['description']) ?></p>
        </div>
        <span class="status <?= e(demand_admin_status_class((string) $wizardStage['key'])) ?>"><?= e((string) $wizardStage['label']) ?></span>
      </div>
      <div class="demand-wizard-steps">
        <div class="<?= in_array($wizardStatus, ['idea', 'draft', 'needs_review'], true) ? 'is-active' : 'is-done' ?>"><strong>1. Черновик</strong><span>Текст, H1, title, description, FAQ и связанные авто.</span></div>
        <div class="<?= in_array($wizardReadiness, ['ready', 'needs_fixes', 'blocked'], true) ? 'is-active' : '' ?>"><strong>2. Проверка</strong><span><?= e(demand_readiness_label($wizardReadiness)) ?></span></div>
        <div class="<?= in_array($wizardStatus, ['published_noindex', 'ready_for_index_review', 'published_indexed'], true) ? 'is-done' : ($wizardStatus === 'approved_for_public_preview' ? 'is-active' : '') ?>"><strong>3. Просмотр без поиска</strong><span>Публичная ссылка, страница закрыта от поисковиков, карта сайта не меняется.</span></div>
        <div class="<?= $wizardStatus === 'published_indexed' ? 'is-done' : ($wizardStatus === 'ready_for_index_review' ? 'is-active' : '') ?>"><strong>4. Открыть для поиска</strong><span>Только вручную: страница открывается для индексации и добавляется в карту сайта.</span></div>
      </div>
      <section class="demand-wizard-next">
        <div>
          <span>Главное следующее действие</span>
          <strong><?= e(demand_admin_draft_next_action_text($wizardDraft)) ?></strong>
          <p><?= e(demand_admin_draft_blockers_text($wizardDraft)) ?></p>
        </div>
        <div class="demand-row-actions">
          <?php if (has_permission('demand.drafts.edit') && in_array((string) ($wizardStage['key'] ?? ''), ['draft', 'needs_fixes'], true)): ?>
            <a class="btn" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => (string) ($wizardDraft['id'] ?? '')])) ?>">Продолжить работу</a>
          <?php elseif (has_permission('demand.publish_wizard.manage') && ($wizardReadiness === 'not_checked' || (string) ($wizardStage['key'] ?? '') === 'draft')): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="drafts">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="view" value="<?= e($demandUiMode) ?>">
              <input type="hidden" name="action" value="wizard_check_readiness">
              <?= demand_editorial_command_fields('wizard_check_readiness') ?>
              <input type="hidden" name="draft_id" value="<?= e((string) ($wizardDraft['id'] ?? '')) ?>">
              <button class="btn" type="submit">Проверить готовность</button>
            </form>
          <?php elseif (has_permission('demand.publish.noindex') && in_array($wizardStatus, ['approved_for_public_preview', 'approved_for_future_publication'], true)): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="drafts">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="view" value="<?= e($demandUiMode) ?>">
              <input type="hidden" name="action" value="wizard_publish_noindex">
              <?= demand_publication_command_fields('wizard_publish_noindex') ?>
              <input type="hidden" name="draft_id" value="<?= e((string) ($wizardDraft['id'] ?? '')) ?>">
              <button class="btn" type="submit" <?= $wizardBlocked ? 'disabled' : '' ?>>Опубликовать для просмотра</button>
            </form>
          <?php elseif (demand_public_landing_is_available($wizardDraft) && !in_array($wizardStatus, ['ready_for_index_review'], true)): ?>
            <a class="btn" href="<?= e(demand_public_landing_path($wizardDraft)) ?>" target="_blank" rel="noopener">Открыть страницу</a>
          <?php elseif (has_permission('demand.publish.index') && in_array($wizardStatus, ['published_noindex', 'ready_for_index_review'], true)): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="drafts">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="view" value="<?= e($demandUiMode) ?>">
              <input type="hidden" name="action" value="wizard_open_search">
              <?= demand_publication_command_fields('wizard_open_search') ?>
              <input type="hidden" name="draft_id" value="<?= e((string) ($wizardDraft['id'] ?? '')) ?>">
              <button class="btn" type="submit" <?= $wizardBlocked ? 'disabled' : '' ?>>Открыть для поиска</button>
            </form>
          <?php endif; ?>
          <a class="btn secondary" href="<?= e(demand_admin_draft_visual_preview_url($wizardDraft, $scopeFilter, (bool) $editDraft)) ?>">Предпросмотр страницы</a>
        </div>
      </section>
      <div class="demand-wizard-actions">
        <?php if (has_permission('demand.publish_wizard.manage')): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="drafts">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="wizard_check_readiness">
            <?= demand_editorial_command_fields('wizard_check_readiness') ?>
            <input type="hidden" name="draft_id" value="<?= e((string) ($wizardDraft['id'] ?? '')) ?>">
            <button class="btn secondary small" type="submit">Проверить готовность</button>
          </form>
        <?php endif; ?>
        <?php if (has_permission('demand.drafts.edit') && !$editDraft): ?>
          <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => (string) ($wizardDraft['id'] ?? '')])) ?>">Редактировать черновик</a>
        <?php endif; ?>
        <a class="btn secondary small" href="<?= e(demand_admin_draft_visual_preview_url($wizardDraft, $scopeFilter, (bool) $editDraft)) ?>">Предпросмотр страницы</a>
        <?php if (has_permission('demand.publish.noindex') && in_array($wizardStatus, ['idea', 'draft', 'needs_review', 'approved_for_public_preview', 'approved_for_future_publication'], true)): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="drafts">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="wizard_publish_noindex">
            <?= demand_publication_command_fields('wizard_publish_noindex') ?>
            <input type="hidden" name="draft_id" value="<?= e((string) ($wizardDraft['id'] ?? '')) ?>">
            <button class="btn small" type="submit" <?= $wizardBlocked ? 'disabled' : '' ?>>Опубликовать для просмотра</button>
          </form>
        <?php endif; ?>
        <?php if (demand_public_landing_is_available($wizardDraft)): ?>
          <a class="btn secondary small" href="<?= e(demand_public_landing_path($wizardDraft)) ?>" target="_blank" rel="noopener">Открыть страницу</a>
        <?php endif; ?>
        <?php if (has_permission('demand.publish.index') && in_array($wizardStatus, ['published_noindex', 'ready_for_index_review'], true)): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="drafts">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="wizard_open_search">
            <?= demand_publication_command_fields('wizard_open_search') ?>
            <input type="hidden" name="draft_id" value="<?= e((string) ($wizardDraft['id'] ?? '')) ?>">
            <button class="btn small" type="submit" <?= $wizardBlocked ? 'disabled' : '' ?>>Открыть для поиска</button>
          </form>
        <?php endif; ?>
        <?php if (has_permission('demand.publish.index') && $wizardStatus === 'published_indexed'): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="drafts">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="wizard_close_search">
            <?= demand_publication_command_fields('wizard_close_search') ?>
            <input type="hidden" name="draft_id" value="<?= e((string) ($wizardDraft['id'] ?? '')) ?>">
            <button class="btn danger small" type="submit">Закрыть от поиска</button>
          </form>
        <?php endif; ?>
        <?php if (has_permission('demand.rollback') && $wizardVersions): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="drafts">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="workflow_rollback">
            <?= demand_publication_command_fields('workflow_rollback') ?>
            <input type="hidden" name="draft_id" value="<?= e((string) ($wizardDraft['id'] ?? '')) ?>">
            <select name="version_id">
              <?php foreach (array_slice($wizardVersions, 0, 10) as $version): ?>
                <option value="<?= e((string) ($version['id'] ?? '')) ?>"><?= e((string) ($version['reason'] ?? 'version')) ?> · <?= e((string) ($version['createdAt'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <button class="btn secondary small" type="submit">Откатить</button>
          </form>
        <?php endif; ?>
        <?php if (has_permission('demand.rollback') && has_permission('demand.sitemap.manage') && !in_array($wizardStatus, ['archived', 'merged'], true)): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="drafts">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="workflow_archive">
            <?= demand_publication_command_fields('workflow_archive') ?>
            <input type="hidden" name="draft_id" value="<?= e((string) ($wizardDraft['id'] ?? '')) ?>">
            <button class="btn danger small" type="submit">Архивировать</button>
          </form>
        <?php endif; ?>
      </div>
      <?php if (has_permission('demand.rollback') && has_permission('demand.sitemap.manage') && !in_array($wizardStatus, ['archived', 'merged'], true)): ?>
        <details class="demand-merge-panel">
          <summary>Объединить страницу</summary>
          <form method="post" class="demand-admin-note">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="drafts">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="workflow_merge">
            <?= demand_publication_command_fields('workflow_merge') ?>
            <input type="hidden" name="draft_id" value="<?= e($wizardDraftId) ?>">
            <p><strong>Объединение не создаёт HTTP-перенаправление.</strong> Исходная страница «<?= e((string) ($wizardDraft['title'] ?? $wizardDraftId)) ?>» получит статус «Объединена» и может быть удалена из карты сайта.</p>
            <label>Целевая страница
              <select name="target_page_id">
                <option value="">Не выбрана — использовать URL ниже</option>
                <?php foreach ($wizardMergeTargets as $mergeTarget): ?>
                  <option value="<?= e((string) ($mergeTarget['id'] ?? '')) ?>"><?= e((string) (($mergeTarget['title'] ?? '') ?: ($mergeTarget['h1'] ?? '') ?: ($mergeTarget['id'] ?? ''))) ?> · <?= e((string) ($mergeTarget['publishStatus'] ?? 'draft')) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
            <label>Или целевой URL
              <input type="text" name="target_url" placeholder="https://example.ru/page или /page">
            </label>
            <p class="muted">Выберите только один вариант: внутреннюю страницу того же контура или URL.</p>
            <label>Причина объединения
              <textarea name="merge_reason" rows="3" required placeholder="Почему исходную страницу нужно объединить с выбранной целью"></textarea>
            </label>
            <label><input type="checkbox" name="merge_confirm" value="1" required> Подтверждаю объединение, изменение статуса исходной страницы и возможное удаление её URL из карты сайта.</label>
            <button class="btn danger small" type="submit">Подтвердить объединение</button>
          </form>
        </details>
      <?php endif; ?>
      <div class="demand-readiness-grid">
        <?php foreach (['ready' => 'Готово', 'needs_fixes' => 'Нужно дополнить', 'blocked' => 'Блокирует публикацию'] as $groupKey => $groupLabel): ?>
          <section>
            <h3><?= e($groupLabel) ?></h3>
            <ul class="demand-check-list">
              <?php if (empty($wizardGroups[$groupKey])): ?><li class="muted">Нет пунктов.</li><?php endif; ?>
              <?php foreach ((array) ($wizardGroups[$groupKey] ?? []) as $check): ?>
                <li class="is-<?= e((string) ($check['status'] ?? 'pass')) ?>"><?= e((string) ($check['message'] ?? '')) ?></li>
              <?php endforeach; ?>
            </ul>
          </section>
        <?php endforeach; ?>
      </div>
      <form method="post" class="demand-admin-note">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="tab" value="drafts">
        <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
        <input type="hidden" name="action" value="wizard_save_admin_note">
        <?= demand_editorial_command_fields('wizard_save_admin_note') ?>
        <input type="hidden" name="draft_id" value="<?= e((string) ($wizardDraft['id'] ?? '')) ?>">
        <label>Заметка admin <textarea name="adminNote" rows="2" placeholder="Например: уточнить подачу в аэропорт Симферополя"><?= e((string) ($wizardDraft['adminNote'] ?? '')) ?></textarea></label>
        <button class="btn secondary small" type="submit">Сохранить заметку</button>
      </form>
    </article>
    <?php if ($demandIsDetailedView): ?>
      <?php demand_admin_ai_render_panel('draft', (string) ($wizardDraft['id'] ?? ''), $scopeFilter, 'drafts', [
          'improve_landing_draft' => 'Сформировать пакет для улучшения страницы',
          'create_faq' => 'Сформировать пакет для FAQ',
          'check_false_promises' => 'Сформировать пакет для проверки рисков',
          'create_title_description' => 'Сформировать пакет для title/description',
      ], $demandAiLatestPackage, $demandAiLatestPreview); ?>
      <?php demand_admin_ai_api_render_panel('drafts', $scopeFilter, [
          'improve_landing_draft' => 'Что исправить в черновике?',
          'check_false_promises' => 'Проверь страницу перед публикацией',
          'simplify_for_client' => 'Сделай текст понятнее',
          'create_faq' => 'Собери FAQ',
          'create_title_description' => 'Сделай title/description',
      ], 'draft', (string) ($wizardDraft['id'] ?? ''), $demandAiApiLatest, $demandAiApiSettings); ?>
    <?php endif; ?>
  <?php endif; ?>

  <?php if ($previewDraft): ?>
    <?php demand_admin_render_draft_visual_preview($previewDraft, $scopeFilter, !$editDraft); ?>
  <?php endif; ?>

  <?php if ($editDraft): ?>
    <?php
      if (empty($editDraft['safeContentBlocks']) && !empty($editDraft['sourceKeywordIds'][0])) {
          $editorialKeyword = demand_find_keyword((string) $editDraft['sourceKeywordIds'][0]);
          if ($editorialKeyword) {
              $editorialCars = array_values(array_filter(array_map(static fn(string $slug): ?array => find_car($slug), array_map('strval', (array) ($editDraft['linkedCars'] ?? [])))));
              $editDraft = array_merge($editDraft, demand_stage_c_analyze_keyword($editorialKeyword, [
                  'cars' => $editorialCars,
                  'contentBlocks' => (array) ($editDraft['contentBlocks'] ?? []),
                  'intro' => (string) ($editDraft['intro'] ?? ''),
              ]));
          }
      }
      $editorialNextAction = demand_draft_editorial_next_action($editDraft);
      $editorialQuestions = demand_admin_editorial_questions($editDraft, 7);
      $editorialGapItems = demand_admin_editorial_gap_items($editDraft, 7);
      $editorialBlockGroups = demand_admin_editorial_block_groups($editDraft);
      $editorialMustNot = demand_admin_editorial_values((array) ($editDraft['mustNotPromise'] ?? []), 8);
      $editorialDangerousClaims = demand_stage_c_detect_dangerous_claims((array) ($editDraft['contentBlocks'] ?? []), (string) ($editDraft['intro'] ?? ''));
      $editorialFaq = array_values(array_filter((array) ($editDraft['recommendedFaq'] ?? []), 'is_array'));
      $editorialLinks = array_values(array_filter((array) ($editDraft['recommendedInternalLinks'] ?? []), 'is_array'));
      $editorialHints = array_values(array_filter((array) ($editDraft['recommendedCarCardHints'] ?? []), 'is_array'));
      $editorialCurrentInternalLinks = demand_normalize_internal_links($editDraft['internalLinks'] ?? []);
      $editorialInternalLinksLatest = is_array($_SESSION['demand_internal_links_latest'] ?? null) ? $_SESSION['demand_internal_links_latest'] : [];
      if ((string) ($editorialInternalLinksLatest['draftId'] ?? '') !== (string) ($editDraft['id'] ?? '')) {
          $editorialInternalLinksLatest = [];
      }
      $editorialInternalLinkSuggestions = array_values(array_filter((array) ($editorialInternalLinksLatest['suggestions']['internalLinkSuggestions'] ?? []), 'is_array'));
      $editorialStoredInternalLinkSuggestions = array_values(array_filter((array) ($editDraft['internalLinkSuggestions']['internalLinkSuggestions'] ?? []), 'is_array'));
      $editorialOpenRisks = !empty($editorialDangerousClaims) || (string) ($editorialNextAction['level'] ?? '') === 'risky';
      $editorialFirstTextBlockIndex = 0;
      foreach ((array) ($editDraft['contentBlocks'] ?? []) as $candidateIndex => $candidateBlock) {
          if (is_array($candidateBlock) && (string) ($candidateBlock['type'] ?? 'text') !== 'faq') {
              $editorialFirstTextBlockIndex = (int) $candidateIndex;
              break;
          }
      }
      $editorialCopySettings = function_exists('demand_ai_draft_copy_settings') ? demand_ai_draft_copy_settings($editDraft) : [
          'defaultStyle' => 'calm_human',
          'defaultBaseInstruction' => function_exists('demand_ai_copy_default_base_instruction') ? demand_ai_copy_default_base_instruction() : '',
          'avoidList' => [],
          'defaultEmphasisList' => [],
      ];
      $editorialCopyOptions = function_exists('demand_ai_normalize_copy_options') ? demand_ai_normalize_copy_options([
          'style' => (string) ($editorialCopySettings['defaultStyle'] ?? 'calm_human'),
          'baseInstruction' => (string) ($editorialCopySettings['defaultBaseInstruction'] ?? ''),
          'avoid' => (array) ($editorialCopySettings['avoidList'] ?? []),
          'emphasis' => (array) ($editorialCopySettings['defaultEmphasisList'] ?? []),
          'preserveSeoMeaning' => true,
          'reduceKeywordRepeats' => true,
          'preserveFacts' => true,
          'noUnconfirmedPromises' => true,
      ]) : [
          'style' => 'calm_human',
          'preserveSeoMeaning' => true,
          'reduceKeywordRepeats' => true,
          'preserveFacts' => true,
          'noUnconfirmedPromises' => true,
      ];
    ?>
    <article class="panel demand-draft-topbar" id="demand-draft-editor-top">
      <div class="panel-head">
        <div>
          <h2><?= e((string) ($editDraft['h1'] ?? $editDraft['title'] ?? 'Черновик')) ?></h2>
          <p class="muted">Следующее действие: <?= e(demand_admin_draft_next_action_text($editDraft)) ?></p>
        </div>
        <span class="status <?= e(demand_admin_status_class((string) ($editDraft['publishStatus'] ?? 'draft'))) ?>"><?= e(demand_admin_ui_label((string) ($editDraft['publishStatus'] ?? 'draft'))) ?></span>
      </div>
      <div class="demand-draft-topbar-actions">
        <?php if (has_permission('demand.ai_api.use') || has_permission('demand.ai.package')): ?>
          <form method="post">
            <?php demand_admin_ai_copy_hidden_inputs((string) ($editDraft['id'] ?? ''), $scopeFilter, 'regenerate_landing_draft_human', $editorialCopyOptions); ?>
            <button class="btn" type="submit">Оживить текст</button>
          </form>
          <form method="post" class="demand-public-copy-action">
            <?php demand_admin_ai_copy_hidden_inputs((string) ($editDraft['id'] ?? ''), $scopeFilter, 'regenerate_landing_draft_human', array_merge($editorialCopyOptions, ['oneTimeInstruction' => 'Перепиши только публичный текст для посетителя: heroSubtitle/public intro, клиентские секции, карточки условий, FAQ и CTA. Не выводи внутренние связи, contentGap, mustAnswer, recommendedBlocks и подсказки редактору как публичный текст.'])); ?>
            <button class="btn secondary" type="submit">Перегенерировать публичный текст</button>
            <small>AI перепишет только текст для посетителя. Служебные подсказки останутся в помощнике редактирования.</small>
          </form>
        <?php endif; ?>
        <?php if (has_permission('demand.publish_wizard.manage')): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="drafts">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="view" value="<?= e($demandUiMode) ?>">
            <input type="hidden" name="action" value="wizard_check_readiness">
            <?= demand_editorial_command_fields('wizard_check_readiness') ?>
            <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
            <button class="btn secondary" type="submit">Проверить готовность</button>
          </form>
        <?php endif; ?>
        <?php if (has_permission('demand.publish.noindex')): ?>
          <?php $canPublishPreview = in_array((string) ($editDraft['publishStatus'] ?? 'draft'), ['approved_for_public_preview', 'approved_for_future_publication'], true) && (string) ($editDraft['readinessStatus'] ?? '') !== 'blocked'; ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="drafts">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="view" value="<?= e($demandUiMode) ?>">
            <input type="hidden" name="action" value="wizard_publish_noindex">
            <?= demand_publication_command_fields('wizard_publish_noindex') ?>
            <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
            <button class="btn secondary" type="submit" <?= $canPublishPreview ? '' : 'disabled' ?>>Опубликовать для просмотра</button>
          </form>
        <?php endif; ?>
        <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => 'all'])) ?>#demand-drafts-worklist">Назад к черновикам</a>
        <a class="btn secondary" href="#demand-ai-copy-regeneration">Настройки генерации</a>
      </div>
    </article>
    <?php demand_admin_ai_copy_render_panel($editDraft, $scopeFilter, $demandAiCopyLatest); ?>
    <div class="demand-draft-editorial-layout">
    <article class="panel">
      <div class="panel-head">
        <div>
          <h2>Редактировать черновик</h2>
          <p class="muted">Перед публикацией можно открыть визуальный предпросмотр страницы прямо из админки.</p>
        </div>
        <a class="btn secondary small" href="<?= e(demand_admin_draft_visual_preview_url($editDraft, $scopeFilter, true)) ?>">Предпросмотр страницы</a>
        <?php if (has_permission('demand.drafts.edit') && demand_preview_text_edit_is_allowed($editDraft)): ?>
          <a class="btn small" href="<?= e(demand_admin_draft_visual_preview_url($editDraft, $scopeFilter, true, 'edit')) ?>">Редактировать предпросмотр</a>
        <?php endif; ?>
      </div>
      <form method="post" class="settings-lessor-form">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="tab" value="drafts">
        <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
        <input type="hidden" name="action" value="save_draft">
        <?= demand_editorial_command_fields('save_draft') ?>
        <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
        <label>Адрес страницы <input name="slug" value="<?= e((string) ($editDraft['slug'] ?? '')) ?>"><small class="field-hint">Короткий адрес латиницей, например arenda-avto-yalta.</small></label>
        <label>Заголовок для поиска <input name="title" value="<?= e((string) ($editDraft['title'] ?? '')) ?>"></label>
        <label>H1 <input name="h1" value="<?= e((string) ($editDraft['h1'] ?? '')) ?>"></label>
        <label class="rental-field-wide">Описание для поиска <textarea name="metaDescription" rows="2"><?= e((string) ($editDraft['metaDescription'] ?? '')) ?></textarea></label>
        <label class="rental-field-wide">Короткое вступление <textarea name="intro" rows="4"><?= e((string) ($editDraft['intro'] ?? '')) ?></textarea></label>
        <label class="rental-field-wide">Связанные авто <input name="linkedCarsInput" value="<?= e(implode(', ', array_map('strval', (array) ($editDraft['linkedCars'] ?? [])))) ?>"><small class="field-hint">Укажите slug авто через запятую. Карточки авто не меняются автоматически.</small></label>
        <div class="rental-field-wide demand-internal-links-editor" id="demand-internal-links-manual">
          <input type="hidden" name="internalLinksEditor" value="1">
          <div class="demand-editor-head">
            <h3>Внутренние ссылки</h3>
            <p class="field-hint">Ссылки сохраняются только в черновик. Публикация, индексация, sitemap.xml и robots.txt не меняются.</p>
          </div>
          <?php if ($editorialCurrentInternalLinks): ?>
            <div class="demand-internal-link-rows">
              <?php foreach ($editorialCurrentInternalLinks as $linkIndex => $link): ?>
                <section class="demand-internal-link-row">
                  <input type="hidden" name="internalLinks[<?= e((string) $linkIndex) ?>][targetType]" value="<?= e((string) ($link['targetType'] ?? 'static')) ?>">
                  <input type="hidden" name="internalLinks[<?= e((string) $linkIndex) ?>][targetId]" value="<?= e((string) ($link['targetId'] ?? '')) ?>">
                  <input type="hidden" name="internalLinks[<?= e((string) $linkIndex) ?>][targetTitle]" value="<?= e((string) ($link['targetTitle'] ?? '')) ?>">
                  <input type="hidden" name="internalLinks[<?= e((string) $linkIndex) ?>][status]" value="<?= e((string) ($link['status'] ?? 'ready_public_link')) ?>">
                  <input type="hidden" name="internalLinks[<?= e((string) $linkIndex) ?>][source]" value="<?= e((string) ($link['source'] ?? 'manual')) ?>">
                  <label>Текст ссылки <input name="internalLinks[<?= e((string) $linkIndex) ?>][anchorText]" value="<?= e((string) ($link['anchorText'] ?? '')) ?>"></label>
                  <label>URL <input name="internalLinks[<?= e((string) $linkIndex) ?>][targetUrl]" value="<?= e((string) ($link['targetUrl'] ?? '')) ?>"></label>
                  <label>Тип связи
                    <select name="internalLinks[<?= e((string) $linkIndex) ?>][relationType]">
                      <?php foreach (demand_internal_link_relation_types() as $relationType): ?>
                        <option value="<?= e($relationType) ?>" <?= (string) ($link['relationType'] ?? 'other') === $relationType ? 'selected' : '' ?>><?= e(demand_internal_link_relation_label($relationType)) ?></option>
                      <?php endforeach; ?>
                    </select>
                  </label>
                  <label>Комментарий admin <input name="internalLinks[<?= e((string) $linkIndex) ?>][adminNote]" value="<?= e((string) ($link['adminNote'] ?? '')) ?>"></label>
                  <div class="demand-internal-link-row__meta">
                    <span><?= e(demand_internal_link_status_label((string) ($link['status'] ?? 'ready_public_link'))) ?></span>
                    <label class="check-row"><input type="checkbox" name="internalLinks[<?= e((string) $linkIndex) ?>][remove]" value="1"><span>Удалить</span></label>
                  </div>
                </section>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <p class="muted">Ссылки пока не добавлены. Можно подобрать их через AI в помощнике справа или добавить вручную ниже.</p>
          <?php endif; ?>
          <section class="demand-internal-link-row is-new">
            <div class="demand-content-block-head"><strong>Добавить вручную</strong></div>
            <label>Текст ссылки <input name="newInternalLinkAnchor" placeholder="условия аренды автомобиля"></label>
            <label>URL / страница <input name="newInternalLinkUrl" placeholder="/pages/conditions.html"></label>
            <label>Тип связи
              <select name="newInternalLinkRelationType">
                <?php foreach (demand_internal_link_relation_types() as $relationType): ?>
                  <option value="<?= e($relationType) ?>"><?= e(demand_internal_link_relation_label($relationType)) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
            <label>Комментарий admin <input name="newInternalLinkAdminNote" placeholder="Зачем добавили эту связь"></label>
          </section>
        </div>
        <label class="rental-field-wide">Причина информационной страницы без авто <textarea name="informationReason" rows="2" placeholder="Заполняйте только если страница не коммерческая и может быть полезной без списка авто"><?= e((string) ($editDraft['informationReason'] ?? '')) ?></textarea></label>
        <div class="rental-field-wide demand-draft-editor">
          <input type="hidden" name="contentBlocksEditor" value="1">
          <div class="demand-editor-head">
            <h3>Блоки страницы</h3>
            <p class="field-hint">Редактируйте текст будущей посадочной. FAQ пишется по строкам: вопрос | ответ. Если удалить все блоки, проверка готовности заблокирует публикацию.</p>
          </div>
          <?php foreach ((array) ($editDraft['contentBlocks'] ?? []) as $blockIndex => $block): ?>
            <?php if (!is_array($block)) { continue; } ?>
            <?php $blockType = (string) ($block['type'] ?? 'text'); ?>
            <section class="demand-content-block-editor">
              <input type="hidden" name="contentBlocks[<?= e((string) $blockIndex) ?>][visibility]" value="<?= e(demand_normalize_content_block_visibility((string) ($block['visibility'] ?? ''), $blockType, (string) ($block['title'] ?? ''))) ?>">
              <div class="demand-content-block-head">
                <strong>Блок <?= e((string) ((int) $blockIndex + 1)) ?></strong>
                <div class="demand-content-block-actions">
                  <?php if (has_permission('demand.ai_api.use') || has_permission('demand.ai.package')): ?>
                    <button class="btn secondary small" type="submit" form="demand-ai-copy-block-<?= e((string) $blockIndex) ?>"><?= $blockType === 'faq' ? 'Перегенерировать FAQ' : 'Перегенерировать блок' ?></button>
                  <?php endif; ?>
                  <label class="check-row"><input type="checkbox" name="contentBlocks[<?= e((string) $blockIndex) ?>][remove]" value="1"><span>Удалить</span></label>
                </div>
              </div>
              <label>Тип
                <select name="contentBlocks[<?= e((string) $blockIndex) ?>][type]">
                  <?php foreach (demand_allowed_content_block_types() as $typeOption): ?>
                    <option value="<?= e($typeOption) ?>" <?= $blockType === $typeOption ? 'selected' : '' ?>><?= e(demand_admin_ui_label($typeOption)) ?></option>
                  <?php endforeach; ?>
                </select>
              </label>
              <label>Заголовок <input name="contentBlocks[<?= e((string) $blockIndex) ?>][title]" value="<?= e((string) ($block['title'] ?? '')) ?>"></label>
              <?php if ($blockType === 'faq'): ?>
                <label class="rental-field-wide">FAQ <textarea name="contentBlocks[<?= e((string) $blockIndex) ?>][faqItems]" rows="5"><?= e(demand_faq_items_to_lines((array) ($block['items'] ?? []))) ?></textarea></label>
              <?php else: ?>
                <label class="rental-field-wide">Текст <textarea name="contentBlocks[<?= e((string) $blockIndex) ?>][body]" rows="4"><?= e((string) ($block['body'] ?? '')) ?></textarea></label>
              <?php endif; ?>
            </section>
          <?php endforeach; ?>
          <section class="demand-content-block-editor is-new">
            <div class="demand-content-block-head"><strong>Добавить блок</strong></div>
            <input type="hidden" name="newBlockVisibility" value="public">
            <label>Тип
              <select name="newBlockType">
                <?php foreach (demand_allowed_content_block_types() as $typeOption): ?>
                  <option value="<?= e($typeOption) ?>"><?= e(demand_admin_ui_label($typeOption)) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
            <label>Заголовок <input name="newBlockTitle" value=""></label>
            <label class="rental-field-wide">Текст нового блока <textarea name="newBlockBody" rows="3"></textarea></label>
            <label class="rental-field-wide">FAQ для нового блока <textarea name="newBlockFaqItems" rows="3" placeholder="Какие документы нужны? | Паспорт и водительское удостоверение."></textarea></label>
          </section>
        </div>
        <label class="rental-field-wide">Заметка admin <textarea name="adminNote" rows="2"><?= e((string) ($editDraft['adminNote'] ?? '')) ?></textarea></label>
        <input type="hidden" name="publishStatus" value="<?= e((string) ($editDraft['publishStatus'] ?? 'draft')) ?>">
        <input type="hidden" name="indexStatus" value="<?= e((string) ($editDraft['indexStatus'] ?? 'blocked')) ?>">
        <input type="hidden" name="qualityStatus" value="<?= e((string) ($editDraft['qualityStatus'] ?? 'needs_human_review')) ?>">
        <p class="field-hint rental-field-wide">После изменения текста готовность сбрасывается: нажмите "Проверить готовность" в мастере.</p>
        <button class="btn" type="submit">Сохранить черновик</button>
      </form>
      <?php
        $refreshCarsAllowed = in_array((string) ($editDraft['publishStatus'] ?? 'draft'), demand_refresh_draft_cars_allowed_statuses(), true);
        $refreshPreviewForDraft = is_array($refreshCarsPreview)
            && (string) ($refreshCarsPreview['draftId'] ?? '') === (string) ($editDraft['id'] ?? '');
      ?>
      <section id="demand-refresh-draft-cars" class="demand-editorial-helper">
        <h3>Пересчитать авто по запросам</h3>
        <p class="muted">Ручной sync/recovery сравнит текущий список с актуальными авто исходных запросов. Предпросмотр ничего не меняет.</p>
        <?php if ($refreshCarsAllowed): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="drafts">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="refresh_draft_cars_preview">
            <?= demand_editorial_command_fields('refresh_draft_cars_preview') ?>
            <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
            <button class="btn secondary small" type="submit">Предпросмотр изменений</button>
          </form>
          <?php if ($refreshPreviewForDraft): ?>
            <div class="info-box">
              <p><strong>Текущие:</strong> <?= e(implode(', ', (array) ($refreshCarsPreview['currentCars'] ?? [])) ?: '—') ?></p>
              <p><strong>После пересчёта:</strong> <?= e(implode(', ', (array) ($refreshCarsPreview['recalculatedCars'] ?? [])) ?: '—') ?></p>
              <p><strong>Будут добавлены:</strong> <?= e(implode(', ', (array) ($refreshCarsPreview['addedCars'] ?? [])) ?: '—') ?></p>
              <p><strong>Будут удалены:</strong> <?= e(implode(', ', (array) ($refreshCarsPreview['removedCars'] ?? [])) ?: '—') ?></p>
              <p><strong>Останутся:</strong> <?= e(implode(', ', (array) ($refreshCarsPreview['unchangedCars'] ?? [])) ?: '—') ?></p>
              <p class="warning"><strong>Важно:</strong> при применении ручной список авто будет заменён рассчитанным.</p>
              <form method="post">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="tab" value="drafts">
                <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                <input type="hidden" name="action" value="refresh_draft_cars">
                <?= demand_editorial_command_fields('refresh_draft_cars') ?>
                <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
                <label><input type="checkbox" name="refresh_confirm" value="1" required> Подтверждаю замену списка авто результатом пересчёта.</label>
                <button class="btn" type="submit" <?= empty($refreshCarsPreview['changed']) ? 'disabled' : '' ?>>Применить пересчёт</button>
              </form>
              <?php if (empty($refreshCarsPreview['changed'])): ?><p class="muted">Изменений нет: применять нечего.</p><?php endif; ?>
            </div>
          <?php endif; ?>
        <?php else: ?>
          <p class="warning">Пересчёт заблокирован: инструмент работает только с непубличными черновиками и состояниями проверки.</p>
        <?php endif; ?>
      </section>
      <?php if (has_permission('demand.ai_api.use') || has_permission('demand.ai.package')): ?>
        <div class="demand-block-copy-forms" aria-hidden="true">
          <?php foreach ((array) ($editDraft['contentBlocks'] ?? []) as $blockIndex => $block): ?>
            <?php if (!is_array($block)) { continue; } ?>
            <?php $blockTask = (string) ($block['type'] ?? 'text') === 'faq' ? 'regenerate_faq' : 'regenerate_single_content_block'; ?>
            <form id="demand-ai-copy-block-<?= e((string) $blockIndex) ?>" method="post">
              <?php demand_admin_ai_copy_hidden_inputs((string) ($editDraft['id'] ?? ''), $scopeFilter, $blockTask, $editorialCopyOptions, (int) $blockIndex); ?>
            </form>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </article>
    <aside class="demand-editorial-helper" id="demand-editorial-helper">
      <div class="panel-head">
        <div>
          <h2>Помощник редактирования</h2>
          <p class="muted">Показывает, что нужно закрыть в черновике перед проверкой готовности. Ничего не публикует и не открывает для поиска.</p>
        </div>
      </div>

      <section class="demand-editorial-next is-<?= e((string) ($editorialNextAction['level'] ?? 'needs_fixes')) ?>">
        <span>Следующее действие</span>
        <strong><?= e((string) ($editorialNextAction['title'] ?? 'Проверьте черновик.')) ?></strong>
        <p><?= e((string) ($editorialNextAction['body'] ?? '')) ?></p>
      </section>

      <details class="demand-editorial-section" open>
        <summary><span>Чего не хватает</span><small><?= e((string) count($editorialGapItems)) ?></small></summary>
        <?php if ($editorialGapItems): ?>
          <ul class="demand-editorial-list">
            <?php foreach ($editorialGapItems as $item): ?><li><?= e((string) $item) ?></li><?php endforeach; ?>
          </ul>
        <?php else: ?>
          <p class="muted">Крупных пробелов не видно. Всё равно проверьте факты, цены, залог и наличие авто вручную.</p>
        <?php endif; ?>
      </details>

      <details class="demand-editorial-section" open>
        <summary><span>Что нельзя обещать</span><small><?= e((string) (count($editorialMustNot) + count($editorialDangerousClaims))) ?></small></summary>
        <?php if ($editorialDangerousClaims): ?>
          <div class="notice warning demand-editorial-risk">
            <strong>Найдено рискованное обещание</strong>
            <ul>
              <?php foreach ($editorialDangerousClaims as $claim): ?><li><?= e((string) $claim) ?></li><?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>
        <?php if ($editorialMustNot): ?>
          <ul class="demand-editorial-list">
            <?php foreach ($editorialMustNot as $item): ?><li><?= e((string) $item) ?></li><?php endforeach; ?>
          </ul>
        <?php else: ?>
          <p class="muted">Отдельные запреты пока не рассчитаны. Проверьте страницу вручную перед публикацией.</p>
        <?php endif; ?>
      </details>

      <details class="demand-editorial-section">
        <summary><span>Что должна объяснить страница</span><small><?= e((string) count($editorialQuestions)) ?></small></summary>
        <?php if ($editorialQuestions): ?>
          <ul class="demand-editorial-list">
            <?php foreach ($editorialQuestions as $item): ?><li><?= e((string) $item) ?></li><?php endforeach; ?>
          </ul>
        <?php else: ?>
          <p class="muted">Пока нет карты вопросов. Пересчитайте карту спроса или создайте ТЗ для страницы.</p>
        <?php endif; ?>
      </details>

      <details class="demand-editorial-section">
        <summary><span>Рекомендуемые блоки</span><small><?= e((string) count((array) ($editDraft['safeContentBlocks'] ?? []))) ?></small></summary>
        <?php foreach ($editorialBlockGroups as $group => $blocks): ?>
          <?php if (!$blocks) { continue; } ?>
          <div class="demand-editorial-block-group">
            <h3><?= e(demand_admin_editorial_group_label((string) $group)) ?></h3>
            <?php foreach ($blocks as $block): ?>
              <?php
                $blockType = (string) ($block['type'] ?? '');
                $blockStatus = demand_draft_editorial_block_status($editDraft, $block);
                $canAddBlock = in_array((string) ($blockStatus['key'] ?? ''), ['missing', 'needs_confirmation'], true);
              ?>
              <div class="demand-editorial-block-item is-<?= e((string) ($blockStatus['key'] ?? 'missing')) ?>">
                <div>
                  <strong><?= e((string) ($block['title'] ?? demand_admin_ui_label($blockType))) ?></strong>
                  <span><?= e((string) ($blockStatus['label'] ?? '')) ?></span>
                  <p><?= e((string) ($blockStatus['explanation'] ?? $block['whyNeeded'] ?? '')) ?></p>
                </div>
                <?php if ($canAddBlock && has_permission('demand.drafts.edit')): ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="drafts">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="action" value="draft_editorial_add_block">
                    <?= demand_editorial_command_fields('draft_editorial_add_block') ?>
                    <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
                    <input type="hidden" name="block_type" value="<?= e($blockType) ?>">
                    <button class="btn secondary small" type="submit"><?= e(demand_admin_editorial_add_block_label($blockStatus)) ?></button>
                  </form>
                <?php elseif ((string) ($blockStatus['key'] ?? '') === 'forbidden'): ?>
                  <button class="btn secondary small" type="button" disabled>Сначала подтвердить условие</button>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endforeach; ?>
        <?php if (!array_filter($editorialBlockGroups)): ?>
          <p class="muted">Безопасные блоки не рассчитаны или запрос исключён из SEO-страниц.</p>
        <?php endif; ?>
      </details>

      <details class="demand-editorial-section">
        <summary><span>FAQ, которые стоит добавить</span><small><?= e((string) count($editorialFaq)) ?></small></summary>
        <?php if ($editorialFaq): ?>
          <div class="demand-editorial-faq-list">
            <?php foreach (array_slice($editorialFaq, 0, 8, true) as $faqIndex => $faq): ?>
              <div class="demand-editorial-faq-item">
                <strong><?= e((string) ($faq['question'] ?? '')) ?></strong>
                <p><?= e((string) ($faq['answerGuidance'] ?? 'Ответить только по подтверждённым данным.')) ?></p>
                <div class="demand-row-actions">
                  <?php if (has_permission('demand.drafts.edit')): ?>
                    <form method="post">
                      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                      <input type="hidden" name="tab" value="drafts">
                      <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                      <input type="hidden" name="action" value="draft_editorial_add_faq">
                      <?= demand_editorial_command_fields('draft_editorial_add_faq') ?>
                      <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
                      <input type="hidden" name="faq_index" value="<?= e((string) $faqIndex) ?>">
                      <button class="btn secondary small" type="submit">Добавить FAQ в черновик</button>
                    </form>
                  <?php endif; ?>
                  <button class="btn secondary small" type="button" data-editorial-copy="<?= e((string) ($faq['question'] ?? '')) ?>">Скопировать вопрос</button>
                  <button class="btn secondary small" type="button" data-editorial-skip>Пропустить</button>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <p class="muted">FAQ-подсказки пока не рассчитаны.</p>
        <?php endif; ?>
      </details>

      <details class="demand-editorial-section" id="demand-internal-links" open>
        <summary><span>Внутренние ссылки</span><small><?= e((string) count($editorialCurrentInternalLinks)) ?></small></summary>
        <?php if (!$editorialCurrentInternalLinks): ?>
          <p class="muted">Ссылки пока не добавлены. AI может подобрать подходящие связи: городские страницы, классы авто, условия аренды, FAQ или карточки автомобилей.</p>
          <div class="demand-row-actions">
            <?php if (has_permission('demand.drafts.edit')): ?>
              <form method="post">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="tab" value="drafts">
                <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                <input type="hidden" name="action" value="draft_internal_links_suggest">
                <?= demand_editorial_command_fields('draft_internal_links_suggest') ?>
                <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
                <button class="btn secondary small" type="submit">Подобрать внутренние ссылки</button>
              </form>
            <?php endif; ?>
            <a class="btn secondary small" href="#demand-internal-links-manual">Добавить вручную</a>
            <button class="btn secondary small" type="button" data-editorial-skip>Пропустить</button>
          </div>
        <?php else: ?>
          <div class="demand-editorial-link-list">
            <?php foreach (array_slice($editorialCurrentInternalLinks, 0, 5) as $link): ?>
              <div class="demand-editorial-link-item">
                <strong><?= e((string) ($link['anchorText'] ?? '')) ?></strong>
                <span><?= e(demand_internal_link_relation_label((string) ($link['relationType'] ?? 'other'))) ?> · <?= e(demand_internal_link_status_label((string) ($link['status'] ?? 'ready_public_link'))) ?></span>
                <?php if (!empty($link['targetUrl'])): ?><code><?= e((string) $link['targetUrl']) ?></code><?php endif; ?>
                <?php if (!empty($link['reason'])): ?><p><?= e((string) $link['reason']) ?></p><?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
          <div class="demand-row-actions">
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="drafts">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="draft_internal_links_suggest">
              <?= demand_editorial_command_fields('draft_internal_links_suggest') ?>
              <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
              <button class="btn secondary small" type="submit">Сгенерировать другие варианты</button>
            </form>
            <a class="btn secondary small" href="#demand-internal-links-manual">Изменить вручную</a>
          </div>
        <?php endif; ?>

        <?php if ($editorialInternalLinkSuggestions): ?>
          <div class="demand-internal-link-suggestions">
            <h3>AI предложил варианты</h3>
            <p class="muted">Готовые public-ссылки можно добавить одной групповой кнопкой. Планируемые связи сохраняются только как подсказка и не выводятся href на лендинге.</p>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="drafts">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="draft_internal_links_apply">
              <?= demand_editorial_command_fields('draft_internal_links_apply') ?>
              <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
              <input type="hidden" name="internal_links_token" value="<?= e((string) ($editorialInternalLinksLatest['token'] ?? '')) ?>">
              <div class="demand-internal-link-suggestion-list">
                <?php foreach ($editorialInternalLinkSuggestions as $suggestionIndex => $suggestion): ?>
                  <?php
                    $suggestionStatus = (string) ($suggestion['status'] ?? 'missing_target');
                    $canApplySuggestion = !empty($suggestion['safeToApply']) && in_array($suggestionStatus, ['ready_public_link', 'noindex_public_link'], true);
                  ?>
                  <label class="demand-internal-link-suggestion is-<?= e($suggestionStatus) ?>">
                    <input type="checkbox" name="internal_link_indexes[]" value="<?= e((string) $suggestionIndex) ?>" <?= $canApplySuggestion ? 'checked' : 'disabled' ?>>
                    <span>
                      <strong><?= e((string) ($suggestion['anchorText'] ?? $suggestion['targetTitle'] ?? '')) ?></strong>
                      <small><?= e(demand_internal_link_target_type_label((string) ($suggestion['targetType'] ?? 'static'))) ?> · <?= e(demand_internal_link_status_label($suggestionStatus)) ?></small>
                      <?php if (!empty($suggestion['targetUrl'])): ?><code><?= e((string) $suggestion['targetUrl']) ?></code><?php endif; ?>
                      <em><?= e((string) ($suggestion['reason'] ?? '')) ?></em>
                    </span>
                  </label>
                <?php endforeach; ?>
              </div>
              <div class="demand-row-actions">
                <button class="btn" type="submit" name="apply_mode" value="selected">Добавить выбранные</button>
                <button class="btn secondary small" type="submit" name="apply_mode" value="all_safe">Добавить все безопасные</button>
                <button class="btn secondary small" type="submit" formaction="" formmethod="post" name="action" value="draft_internal_links_suggest">Сгенерировать другие варианты</button>
              </div>
            </form>
            <form method="post" class="demand-inline-form">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="drafts">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="draft_internal_links_reject">
              <?= demand_editorial_command_fields('draft_internal_links_reject') ?>
              <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
              <button class="btn secondary small" type="submit">Отклонить</button>
            </form>
          </div>
        <?php elseif ($editorialStoredInternalLinkSuggestions): ?>
          <div class="demand-internal-link-suggestions">
            <h3>AI уже предложил идеи</h3>
            <div class="demand-internal-link-suggestion-list">
              <?php foreach (array_slice($editorialStoredInternalLinkSuggestions, 0, 5) as $suggestion): ?>
                <?php $suggestionStatus = (string) ($suggestion['status'] ?? 'missing_target'); ?>
                <div class="demand-internal-link-suggestion is-readonly is-<?= e($suggestionStatus) ?>">
                  <span>
                    <strong><?= e((string) ($suggestion['anchorText'] ?? $suggestion['targetTitle'] ?? '')) ?></strong>
                    <small><?= e(demand_internal_link_target_type_label((string) ($suggestion['targetType'] ?? 'static'))) ?> · <?= e(demand_internal_link_status_label($suggestionStatus)) ?></small>
                    <?php if (!empty($suggestion['targetUrl'])): ?><code><?= e((string) $suggestion['targetUrl']) ?></code><?php endif; ?>
                    <em><?= e((string) ($suggestion['reason'] ?? '')) ?></em>
                  </span>
                </div>
              <?php endforeach; ?>
            </div>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="drafts">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="draft_internal_links_suggest">
              <?= demand_editorial_command_fields('draft_internal_links_suggest') ?>
              <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
              <button class="btn secondary small" type="submit">Подготовить ссылки к добавлению</button>
            </form>
          </div>
        <?php elseif ($editorialLinks): ?>
          <h3>Идеи из Stage C</h3>
          <ul class="demand-editorial-list">
            <?php foreach (array_slice($editorialLinks, 0, 5) as $link): ?>
              <li><?= e((string) ($link['targetHint'] ?? '')) ?><?= !empty($link['reason']) ? ': ' . e((string) $link['reason']) : '' ?></li>
            <?php endforeach; ?>
          </ul>
          <?php if (has_permission('demand.drafts.edit')): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="drafts">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="draft_internal_links_suggest">
              <?= demand_editorial_command_fields('draft_internal_links_suggest') ?>
              <input type="hidden" name="draft_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
              <button class="btn secondary small" type="submit">Подготовить ссылки</button>
            </form>
          <?php endif; ?>
        <?php endif; ?>
      </details>

      <details class="demand-editorial-section">
        <summary><span>Карточки авто</span><small><?= e((string) count($editorialHints)) ?></small></summary>
        <?php if ($editorialHints): ?>
          <ul class="demand-editorial-list">
            <?php foreach (array_slice($editorialHints, 0, 5) as $hint): ?>
              <li><?= e((string) ($hint['hint'] ?? $hint['message'] ?? $hint['suggestedText'] ?? '')) ?></li>
            <?php endforeach; ?>
          </ul>
        <?php else: ?>
          <p class="muted">Отдельных рекомендаций по карточкам авто пока нет.</p>
        <?php endif; ?>
      </details>

      <details class="demand-editorial-section">
        <summary><span>Готовность</span><small>2</small></summary>
        <div class="demand-editorial-score">
          <strong>Понятность для клиента</strong>
          <p><?= e(demand_admin_stage_c_score_text($editDraft, 'userClarityScore')) ?></p>
        </div>
        <div class="demand-editorial-score">
          <strong>Готовность для поискового/AI-ответа</strong>
          <p><?= e(demand_admin_stage_c_score_text($editDraft, 'aiSearchReadiness')) ?></p>
        </div>
      </details>

      <?php if (has_permission('demand.ai_api.use') || has_permission('demand.ai.package')): ?>
        <section class="demand-editorial-section demand-editorial-human-copy">
          <h3>Текст выглядит сухо?</h3>
          <p class="muted">AI подготовит новый вариант, но ничего не заменит без вашего подтверждения.</p>
          <div class="demand-row-actions">
            <form method="post">
              <?php demand_admin_ai_copy_hidden_inputs((string) ($editDraft['id'] ?? ''), $scopeFilter, 'regenerate_landing_draft_human', $editorialCopyOptions); ?>
              <button class="btn" type="submit">Оживить текст через AI</button>
            </form>
            <form method="post">
              <?php demand_admin_ai_copy_hidden_inputs((string) ($editDraft['id'] ?? ''), $scopeFilter, 'regenerate_landing_draft_human', $editorialCopyOptions); ?>
              <button class="btn secondary small" type="submit">Оживить весь черновик</button>
            </form>
            <form method="post">
              <?php demand_admin_ai_copy_hidden_inputs((string) ($editDraft['id'] ?? ''), $scopeFilter, 'regenerate_single_content_block', $editorialCopyOptions, $editorialFirstTextBlockIndex); ?>
              <button class="btn secondary small" type="submit">Оживить выбранный блок</button>
            </form>
            <form method="post">
              <?php
                $simpleCopyOptions = $editorialCopyOptions;
                $simpleCopyOptions['style'] = 'short_clear';
                demand_admin_ai_copy_hidden_inputs((string) ($editDraft['id'] ?? ''), $scopeFilter, 'make_copy_more_human', $simpleCopyOptions);
              ?>
              <button class="btn secondary small" type="submit">Сделать проще</button>
            </form>
            <form method="post">
              <?php demand_admin_ai_copy_hidden_inputs((string) ($editDraft['id'] ?? ''), $scopeFilter, 'regenerate_faq', $editorialCopyOptions); ?>
              <button class="btn secondary small" type="submit">Сгенерировать FAQ живее</button>
            </form>
          </div>
        </section>
      <?php endif; ?>

      <?php if (has_permission('demand.ai.package')): ?>
        <details class="demand-car-hint-manual demand-editorial-ai-form">
          <summary>Ручной режим / без API</summary>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="drafts">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="demand_ai_generate_package">
            <?= demand_ai_content_command_fields('demand_ai_generate_package', 'draft', (string) ($editDraft['id'] ?? '')) ?>
            <input type="hidden" name="entity_type" value="draft">
            <input type="hidden" name="entity_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
            <input type="hidden" name="ai_task" value="improve_landing_draft">
            <button class="btn secondary" type="submit">Сформировать ручной пакет для внешнего AI</button>
            <small>Ручной пакет включает Stage C поля и не отправляется во внешний AI автоматически.</small>
          </form>
        </details>
      <?php endif; ?>
      <?php if ($demandIsDetailedView && has_permission('demand.ai_api.use') && !empty($demandAiApiSettings['enabled']) && !empty($demandAiApiSettings['apiKeyConfigured'])): ?>
        <form method="post" class="demand-editorial-ai-form">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="tab" value="drafts">
          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
          <input type="hidden" name="action" value="demand_ai_api_ask">
          <?= demand_ai_content_command_fields('demand_ai_api_ask', 'draft', (string) ($editDraft['id'] ?? '')) ?>
          <input type="hidden" name="context_tab" value="drafts">
          <input type="hidden" name="entity_type" value="draft">
          <input type="hidden" name="entity_id" value="<?= e((string) ($editDraft['id'] ?? '')) ?>">
          <input type="hidden" name="ai_api_task" value="improve_landing_draft">
          <button class="btn" type="submit">Сформировать предложение через AI API</button>
          <small>AI вернёт предложение только для preview. Публикация и индексация не выполняются.</small>
        </form>
      <?php endif; ?>
    </aside>
    </div>
  <?php endif; ?>

  <article class="panel" id="demand-drafts-worklist">
    <div class="panel-head">
      <div>
        <h2>Черновики и публикация</h2>
        <p class="muted">Короткий путь: черновик → проверка → опубликовать для просмотра → открыть для поиска. Технические статусы остаются внутри системы.</p>
      </div>
    </div>
    <div class="demand-filter-row demand-draft-filter-row" aria-label="Фильтры черновиков">
      <?php foreach ($demandDraftFilterOptions as $filterKey => $filterLabel): ?>
        <?php
          $filterCount = $filterKey === 'archived'
              ? $demandDraftCounts['archived']
              : ($demandDraftCounts[$filterKey] ?? 0);
        ?>
        <a class="<?= $draftFilter === $filterKey ? 'is-active' : '' ?>" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => $filterKey])) ?>#demand-drafts-worklist"><?= e($filterLabel) ?> <strong><?= e((string) $filterCount) ?></strong></a>
      <?php endforeach; ?>
    </div>

    <?php if (!$drafts): ?>
      <div class="demand-empty-state">
        <strong>Черновиков пока нет.</strong>
        <p>Создайте черновик из плана страниц или попросите AI подготовить безопасный черновик.</p>
        <div class="demand-row-actions">
          <a class="btn" href="<?= e(demand_admin_scope_filter_url('demand_map', $scopeFilter)) ?>#seo-launch-plan">Открыть план страниц</a>
          <?php if (function_exists('demand_ai_dialog_can_access') && demand_ai_dialog_can_access()): ?>
            <button class="btn secondary" type="button" data-demand-ai-dialog-open>Попросить AI подготовить черновик</button>
          <?php endif; ?>
        </div>
      </div>
    <?php elseif (!$draftDisplayRows): ?>
      <div class="demand-empty-state">
        <strong>В этом фильтре черновиков нет.</strong>
        <p>Откройте все черновики или выберите другой быстрый фильтр.</p>
        <a class="btn secondary" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['draft_filter' => 'all'])) ?>#demand-drafts-worklist">Все черновики</a>
      </div>
    <?php else: ?>
      <div class="demand-draft-worklist">
        <?php foreach ($draftDisplayRows as $draft): ?>
          <?php
            $draftStatus = (string) ($draft['publishStatus'] ?? 'draft');
            $stage = demand_simple_publish_stage($draft);
            $readiness = (string) ($draft['readinessStatus'] ?? 'not_checked');
            $sourceLabel = '';
            if ((string) ($draft['linkedClusterId'] ?? '') !== '' && function_exists('demand_map_find_cluster')) {
                $cluster = demand_map_find_cluster((string) $draft['linkedClusterId']);
                $sourceLabel = is_array($cluster) ? (string) ($cluster['name'] ?? '') : '';
            }
            if ($sourceLabel === '' && !empty($draft['sourceKeywordIds'][0])) {
                $kw = demand_find_keyword((string) $draft['sourceKeywordIds'][0]);
                $sourceLabel = is_array($kw) ? (string) ($kw['phrase'] ?? '') : (string) $draft['sourceKeywordIds'][0];
            }
            $riskFlags = demand_landing_risk_flags($draft);
            $linkedCarsCount = count((array) ($draft['linkedCars'] ?? []));
            $draftId = (string) ($draft['id'] ?? '');
            $primaryDraftHref = has_permission('demand.drafts.edit') && in_array((string) ($stage['key'] ?? ''), ['draft', 'needs_fixes'], true)
                ? demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $draftId])
                : demand_admin_scope_filter_url('drafts', $scopeFilter, ['preview_draft' => $draftId]);
            $primaryDraftLabel = in_array((string) ($stage['key'] ?? ''), ['draft', 'needs_fixes'], true) ? 'Продолжить работу' : 'Открыть черновик';
          ?>
          <article class="demand-draft-card is-<?= e((string) ($stage['key'] ?? 'draft')) ?>">
            <div class="demand-draft-card-main">
              <div class="demand-draft-card-title">
                <div>
                  <h3><?= e((string) ($draft['h1'] ?? $draft['slug'] ?? 'Черновик')) ?></h3>
                  <p><?= e((string) ($draft['slug'] ?? '')) ?></p>
                </div>
                <span class="status <?= e(demand_admin_status_class((string) ($stage['key'] ?? 'draft'))) ?>"><?= e((string) ($stage['label'] ?? 'Черновик')) ?></span>
              </div>
              <dl class="demand-draft-card-meta">
                <div><dt>Тема/запрос</dt><dd><?= e($sourceLabel !== '' ? $sourceLabel : 'Не указан') ?></dd></div>
                <div><dt>Что мешает</dt><dd><?= e(demand_admin_draft_blockers_text($draft)) ?></dd></div>
                <div><dt>Следующее действие</dt><dd><?= e(demand_admin_draft_next_action_text($draft)) ?></dd></div>
                <div><dt>Готовность</dt><dd><?= e(demand_readiness_label($readiness)) ?></dd></div>
                <div><dt>Авто и риски</dt><dd><?= e((string) $linkedCarsCount) ?> авто · <?= $riskFlags ? e(demand_admin_list_labels($riskFlags, 'demand_admin_risk_label')) : 'рисков не найдено' ?></dd></div>
              </dl>
            </div>
            <div class="demand-draft-card-actions">
              <a class="btn" href="<?= e($primaryDraftHref) ?>"><?= e($primaryDraftLabel) ?></a>
              <div class="demand-row-actions">
                <a class="btn secondary small" href="<?= e(demand_admin_draft_visual_preview_url($draft, $scopeFilter)) ?>">Предпросмотр</a>
                <?php if (has_permission('demand.drafts.edit') && demand_preview_text_edit_is_allowed($draft)): ?>
                  <a class="btn small" href="<?= e(demand_admin_draft_visual_preview_url($draft, $scopeFilter, false, 'edit')) ?>">Редактировать текст</a>
                <?php endif; ?>
                <?php if (has_permission('demand.drafts.edit') && !in_array((string) ($stage['key'] ?? ''), ['draft', 'needs_fixes'], true)): ?>
                  <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('drafts', $scopeFilter, ['edit_draft' => $draftId])) ?>">Редактировать</a>
                <?php endif; ?>
                <?php if (has_permission('demand.publish_wizard.manage') && ($readiness === 'not_checked' || in_array((string) ($stage['key'] ?? ''), ['draft', 'needs_fixes'], true))): ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="drafts">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="view" value="<?= e($demandUiMode) ?>">
                    <input type="hidden" name="action" value="wizard_check_readiness">
                    <?= demand_editorial_command_fields('wizard_check_readiness') ?>
                    <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
                    <button class="btn secondary small" type="submit">Проверить готовность</button>
                  </form>
                <?php elseif (has_permission('demand.publish.noindex') && in_array($draftStatus, ['draft', 'needs_review', 'approved_for_public_preview', 'approved_for_future_publication'], true)): ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="drafts">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="view" value="<?= e($demandUiMode) ?>">
                    <input type="hidden" name="action" value="wizard_publish_noindex">
                    <?= demand_publication_command_fields('wizard_publish_noindex') ?>
                    <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
                    <button class="btn secondary small" type="submit" <?= $readiness === 'blocked' ? 'disabled' : '' ?>>Опубликовать для просмотра</button>
                  </form>
                <?php endif; ?>
                <?php if (demand_public_landing_is_available($draft)): ?>
                  <a class="btn secondary small" href="<?= e(demand_public_landing_path($draft)) ?>" target="_blank" rel="noopener">Открыть страницу</a>
                <?php endif; ?>
                <?php if (has_permission('demand.publish.index') && in_array($draftStatus, ['published_noindex', 'ready_for_index_review'], true)): ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="drafts">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="view" value="<?= e($demandUiMode) ?>">
                    <input type="hidden" name="action" value="wizard_open_search">
                    <?= demand_publication_command_fields('wizard_open_search') ?>
                    <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
                    <button class="btn secondary small" type="submit" <?= $readiness === 'blocked' ? 'disabled' : '' ?>>Открыть для поиска</button>
                  </form>
                <?php endif; ?>
                <?php if (has_permission('demand.publish.index') && $draftStatus === 'published_indexed'): ?>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="tab" value="drafts">
                    <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
                    <input type="hidden" name="view" value="<?= e($demandUiMode) ?>">
                    <input type="hidden" name="action" value="wizard_close_search">
                    <?= demand_publication_command_fields('wizard_close_search') ?>
                    <input type="hidden" name="draft_id" value="<?= e($draftId) ?>">
                    <button class="btn danger small" type="submit">Закрыть от поиска</button>
                  </form>
                <?php endif; ?>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </article>
  <?php if ($demandIsDetailedView && has_permission('demand.lifecycle.view')): ?>
    <details class="panel demand-technical-details">
      <summary>
        <span>История и логи страниц</span>
        <small>Служебная история действий: кто и когда менял статус страницы.</small>
      </summary>
      <div class="table-wrap">
        <table class="report-table">
          <thead><tr><th>Страница</th><th>Событие</th><th>Статус</th><th>Кто / когда</th><th>Сообщение</th></tr></thead>
          <tbody>
          <?php
            $visibleDraftIds = array_fill_keys(array_map(static fn(array $item): string => (string) ($item['id'] ?? ''), $drafts), true);
            $historyRows = array_values(array_filter(read_seo_page_lifecycle()['items'], static fn($item): bool => is_array($item) && isset($visibleDraftIds[(string) ($item['entityId'] ?? '')])));
          ?>
          <?php if (!$historyRows): ?><tr><td colspan="5">Истории пока нет.</td></tr><?php endif; ?>
          <?php foreach (array_slice($historyRows, 0, 60) as $event): ?>
            <tr>
              <th><?= e((string) ($event['entityId'] ?? '')) ?></th>
              <td><?= e(demand_admin_ui_label((string) ($event['event'] ?? ''))) ?></td>
              <td><?= e(demand_admin_ui_label((string) ($event['previousStatus'] ?? ''))) ?> → <?= e(demand_admin_ui_label((string) ($event['newStatus'] ?? ''))) ?></td>
              <td><?= e((string) ($event['createdBy'] ?? 'system')) ?><small><?= e((string) ($event['createdAt'] ?? '')) ?></small></td>
              <td><?= e((string) ($event['message'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </details>
  <?php endif; ?>
<?php elseif ($tab === 'car_hints'): ?>
  <?php $hints = $demandMapCardHints; ?>
  <?php
    $latestAiEntityType = (string) ($demandAiLatestPreview['entityType'] ?? $demandAiLatestPackage['entityType'] ?? '');
    $latestAiEntityId = (string) ($demandAiLatestPreview['entityId'] ?? $demandAiLatestPackage['entityId'] ?? '');
    demand_admin_car_hint_ai_proposal_modal($demandAiApiLatest, $scopeFilter);
    demand_admin_car_hint_ai_fallback_panel($demandCarHintAiFallback, $scopeFilter);
    if ($latestAiEntityType === 'car_hint' && $latestAiEntityId !== '') {
        demand_admin_ai_render_panel('car_hint', $latestAiEntityId, $scopeFilter, 'car_hints', [
            'improve_car_hint' => 'Сформировать пакет для текста подсказки',
            'check_false_promises' => 'Сформировать пакет для улучшения описания авто',
        ], $demandAiLatestPackage, $demandAiLatestPreview);
    }
  ?>
  <article class="panel">
    <div class="panel-head">
      <div>
        <h2>Подсказки для карточек авто</h2>
        <p class="muted">Система показывает формулировки, которые стоит добавить только после проверки реальных свойств автомобиля и условий.</p>
      </div>
    </div>
    <div class="table-wrap">
      <table class="report-table">
        <thead><tr><th>Авто</th><th>Контур</th><th>Тип</th><th>Подсказка</th><th>AI</th></tr></thead>
        <tbody>
          <?php if (!$hints): ?><tr><td colspan="5">Подсказок пока нет.</td></tr><?php endif; ?>
          <?php foreach ($hints as $row): ?>
            <tr>
              <th><?= e(car_name((string) ($row['carId'] ?? ''))) ?><small><?= e((string) ($row['carId'] ?? '')) ?></small></th>
              <td><?= e(scope_display_name((string) ($row['scope_id'] ?? 'rent_rk'))) ?></td>
              <td><?= e(demand_admin_ui_label((string) ($row['hintType'] ?? ''))) ?><small><?= e(demand_admin_priority_label((string) ($row['priority'] ?? ''))) ?></small></td>
              <td>
                <?= e((string) ($row['message'] ?? '')) ?><small><?= e((string) ($row['suggestedText'] ?? '')) ?></small>
                <?php if ((string) ($row['descriptionSuggestion'] ?? '') !== ''): ?><small><?= e((string) ($row['descriptionSuggestion'] ?? '')) ?></small><?php endif; ?>
                <?php $aiStatus = demand_admin_car_hint_ai_status_label($row); ?>
                <?php if ($aiStatus !== ''): ?><span class="status status-service"><?= e($aiStatus) ?></span><?php endif; ?>
              </td>
              <td>
                <div class="demand-row-actions">
                  <?php demand_admin_car_hint_ai_actions($row, $scopeFilter); ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </article>
<?php elseif ($tab === 'integrations'): ?>
  <article class="panel">
    <div class="panel-head">
      <div>
        <h2>Данные и Wordstat</h2>
        <p class="muted">Здесь собраны источники данных и служебная история. Для обычной работы используйте вкладку Wordstat; технические детали ниже свернуты.</p>
      </div>
      <?php if (has_permission('demand.performance.view')): ?>
        <form method="post" class="inline-form demand-snapshot-form">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="tab" value="integrations">
          <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
          <input type="hidden" name="action" value="integration_build_snapshot">
          <?= demand_integration_command_fields('integration_build_snapshot') ?>
          <input type="hidden" name="target_scope_id" value="<?= e($scopeFilter !== 'all' ? $scopeFilter : 'rent_rk') ?>">
          <input type="date" name="period_from" value="<?= e(date('Y-m-01')) ?>">
          <input type="date" name="period_to" value="<?= e(date('Y-m-t')) ?>">
          <button class="btn secondary small" type="submit">Собрать снимок данных</button>
        </form>
      <?php endif; ?>
      <?php if (has_permission('demand.wordstat.view') || has_permission('demand.wordstat.manage')): ?>
        <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('wordstat_help', $scopeFilter)) ?>">Открыть Wordstat</a>
      <?php endif; ?>
    </div>

    <?php if (has_permission('demand.integrations.manage')): ?>
      <details class="demand-technical-details">
        <summary><span>Настройки источников</span><small>Нужны редко: включение источников, режимы и лимиты.</small></summary>
      <form method="post" class="settings-lessor-form">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="tab" value="integrations">
        <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
        <input type="hidden" name="action" value="save_integrations_settings">
        <?= demand_integration_command_fields('save_integrations_settings') ?>
        <label class="check-row"><input type="checkbox" name="enabled" value="1" <?= !empty(demand_integrations_get_settings()['rent_rk']['enabled']) ? 'checked' : '' ?>><span>Включить интеграционный слой спроса</span></label>
        <div class="demand-source-grid">
          <?php foreach ($integrationSources as $source => $sourceSettings): ?>
            <section class="metric-card">
              <h3><?= e((string) ($sourceSettings['label'] ?? $source)) ?></h3>
              <p class="muted"><?= e((string) ($sourceSettings['description'] ?? '')) ?></p>
              <label class="check-row"><input type="checkbox" name="sources[<?= e($source) ?>][enabled]" value="1" <?= !empty($sourceSettings['enabled']) ? 'checked' : '' ?>><span>Источник включён</span></label>
              <label>
                Режим
                <select name="sources[<?= e($source) ?>][mode]">
                  <?php foreach ((array) ($sourceSettings['allowedModes'] ?? []) as $modeOption): ?>
                    <option value="<?= e((string) $modeOption) ?>" <?= (string) ($sourceSettings['mode'] ?? '') === (string) $modeOption ? 'selected' : '' ?>><?= e(demand_admin_ui_label((string) $modeOption)) ?></option>
                  <?php endforeach; ?>
                </select>
              </label>
              <label>
                Статус доступа
                <select name="sources[<?= e($source) ?>][authStatus]">
                  <?php foreach (($source === 'wordstat' ? ['not_configured', 'configured', 'test_success', 'test_failed', 'error'] : ['not_configured', 'configured', 'error', 'not_required']) as $authStatus): ?>
                    <option value="<?= e($authStatus) ?>" <?= (string) ($sourceSettings['authStatus'] ?? '') === $authStatus ? 'selected' : '' ?>><?= e(demand_admin_ui_label($authStatus)) ?></option>
                  <?php endforeach; ?>
                </select>
              </label>
              <label class="check-row"><input type="checkbox" name="sources[<?= e($source) ?>][dryRunOnly]" value="1" <?= !empty($sourceSettings['dryRunOnly']) ? 'checked' : '' ?>><span>Только пробная проверка без изменений</span></label>
              <label class="check-row"><input type="checkbox" name="sources[<?= e($source) ?>][allowExternalScopes]" value="1" <?= !empty($sourceSettings['allowExternalScopes']) ? 'checked' : '' ?>><span>Разрешить внешним контурам агрегированный просмотр</span></label>
              <?php if ($source === 'wordstat'): ?>
                <div class="wordstat-settings-fields">
                  <label class="check-row"><input type="checkbox" name="sources[wordstat][liveEnabled]" value="1" <?= !empty($sourceSettings['liveEnabled']) ? 'checked' : '' ?>><span>Разрешить ручную загрузку данных</span></label>
                  <label>Дневной лимит запросов <input type="number" min="0" name="sources[wordstat][dailyRequestLimit]" value="<?= e((string) ($sourceSettings['dailyRequestLimit'] ?? 100)) ?>"></label>
                  <label>Месячный лимит запросов <input type="number" min="0" name="sources[wordstat][monthlyRequestLimit]" value="<?= e((string) ($sourceSettings['monthlyRequestLimit'] ?? 1000)) ?>"></label>
                  <label>Лимит за один запуск <input type="number" min="0" name="sources[wordstat][perRunRequestLimit]" value="<?= e((string) ($sourceSettings['perRunRequestLimit'] ?? 20)) ?>"></label>
                  <label>Лимит стоимости, RUB <input type="number" min="0" step="0.01" name="sources[wordstat][estimatedCostLimitRub]" value="<?= e((string) ($sourceSettings['estimatedCostLimitRub'] ?? 500)) ?>"></label>
                  <label>Пауза между запросами, сек <input type="number" min="0" name="sources[wordstat][cooldownSecondsBetweenRequests]" value="<?= e((string) ($sourceSettings['cooldownSecondsBetweenRequests'] ?? 2)) ?>"></label>
                  <label>Повторных попыток <input type="number" min="0" name="sources[wordstat][retryAttempts]" value="<?= e((string) ($sourceSettings['retryAttempts'] ?? 2)) ?>"></label>
                  <label>Пауза перед повтором, сек <input type="number" min="0" name="sources[wordstat][retryBackoffSeconds]" value="<?= e((string) ($sourceSettings['retryBackoffSeconds'] ?? 5)) ?>"></label>
                  <label class="wordstat-wide-field">ID регионов по умолчанию <input name="sources[wordstat][defaultRegionIds]" value="<?= e(implode(', ', (array) ($sourceSettings['defaultRegionIds'] ?? []))) ?>"></label>
                  <label class="wordstat-wide-field">Стартовые фразы по умолчанию <textarea name="sources[wordstat][defaultSeedPhrases]" rows="3"><?= e(implode("\n", (array) ($sourceSettings['defaultSeedPhrases'] ?? []))) ?></textarea></label>
                </div>
              <?php endif; ?>
              <p class="field-hint">Последняя загрузка: <?= e((string) ($sourceSettings['lastSyncAt'] ?? '')) ?: '—' ?>; последняя ошибка: <?= e((string) ($sourceSettings['lastError'] ?? '')) ?: '—' ?></p>
            </section>
          <?php endforeach; ?>
        </div>
        <button class="btn" type="submit">Сохранить настройки источников</button>
      </form>
      </details>
    <?php else: ?>
      <div class="demand-source-grid">
        <?php foreach ($integrationSources as $source => $sourceSettings): ?>
          <?php if (!demand_integrations_can_user_view_source((string) $source)) { continue; } ?>
          <section class="metric-card">
            <h3><?= e((string) ($sourceSettings['label'] ?? $source)) ?></h3>
            <p class="muted"><?= e((string) ($sourceSettings['description'] ?? '')) ?></p>
            <p><span class="status <?= e(demand_admin_status_class(!empty($sourceSettings['enabled']) ? 'active' : 'blocked')) ?>"><?= !empty($sourceSettings['enabled']) ? 'включён' : 'выключен' ?></span></p>
            <p class="field-hint">Режим: <?= e(demand_admin_ui_label((string) ($sourceSettings['mode'] ?? ''))) ?>; доступ: <?= e(demand_admin_ui_label((string) ($sourceSettings['authStatus'] ?? ''))) ?>; только пробная проверка: <?= !empty($sourceSettings['dryRunOnly']) ? 'да' : 'нет' ?></p>
          </section>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </article>

  <?php if (has_permission('demand.wordstat.view') || has_permission('demand.wordstat.manage')): ?>
    <?php
      $wordstatMethods = wordstat_supported_methods();
      $wordstatDefaultSeeds = implode("\n", (array) ($wordstatStatus['defaultSeedPhrases'] ?? ['аренда авто ялта']));
      $wordstatDefaultRegions = implode(', ', (array) ($wordstatStatus['defaultRegionIds'] ?? ['11470', '977']));
      $wordstatRecentRuns = demand_wordstat_visible_sync_runs($scopeFilter);
      $wordstatRecentErrors = array_values(array_filter($integrationErrors, static fn(array $item): bool => (string) ($item['source'] ?? '') === 'wordstat'));
      $wordstatLatestDryRun = demand_wordstat_latest_dry_run($wordstatRecentRuns);
      $wordstatPinnedDryRun = demand_wordstat_sync_run_by_id((string) ($_SESSION['demand_wordstat_latest_dry_run_id'] ?? ''), $scopeFilter);
      if (is_array($wordstatPinnedDryRun) && !empty($wordstatPinnedDryRun['dryRun'])) {
          $wordstatLatestDryRun = $wordstatPinnedDryRun;
      }
      $wordstatSessionDryRun = demand_wordstat_session_dry_run($scopeFilter);
      if (is_array($wordstatSessionDryRun) && !empty($wordstatSessionDryRun['dryRun'])) {
          $wordstatLatestDryRun = $wordstatSessionDryRun;
      }
      if (!$wordstatLatestDryRun) {
          $wordstatLatestDryRun = demand_wordstat_latest_dry_run_for_admin($scopeFilter);
      }
      $wordstatAllRegions = (array) ($wordstatRegionsCache['regions'] ?? []);
      $wordstatRegionCount = count($wordstatAllRegions);
      $wordstatRegionPreviewLimit = 8;
      $wordstatRegions = array_slice($wordstatAllRegions, 0, $wordstatRegionPreviewLimit);
      $wordstatKeyRegions = demand_wordstat_key_regions($wordstatAllRegions);
      $wordstatCrimeaRegions = demand_wordstat_crimea_regions($wordstatAllRegions);
      $wordstatLiveAvailable = has_permission('demand.wordstat.live')
          && !empty($wordstatStatus['enabled'])
          && (string) ($wordstatStatus['mode'] ?? '') === 'live_controlled'
          && in_array((string) ($wordstatStatus['authStatus'] ?? ''), ['configured', 'test_success'], true)
          && !empty($wordstatStatus['liveEnabled'])
          && !empty($wordstatStatus['apiKeyConfigured'])
          && !empty($wordstatStatus['folderIdConfigured'])
          && !empty($wordstatStatus['baseUrlConfigured']);
    ?>
    <article class="panel wordstat-panel">
      <div class="panel-head">
        <div>
          <h2>Wordstat</h2>
          <p class="muted">Пробная проверка показывает план без изменений. Ручная загрузка доступна только admin Rent RK, с лимитами и без публикации страниц, карты сайта или robots.txt.</p>
        </div>
        <div class="demand-row-actions">
          <?php if (has_permission('demand.wordstat.test')): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="integrations">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="wordstat_test_connection">
              <?= demand_integration_command_fields('wordstat_test_connection') ?>
              <button class="btn secondary small" type="submit">Проверить подключение</button>
            </form>
          <?php endif; ?>
          <?php if (has_permission('demand.wordstat.sync')): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="integrations">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="wordstat_load_regions">
              <?= demand_integration_command_fields('wordstat_load_regions') ?>
              <button class="btn secondary small" type="submit">Загрузить регионы</button>
            </form>
          <?php endif; ?>
        </div>
      </div>

      <div class="wordstat-status-grid">
        <section class="metric-card">
          <h3>Статус</h3>
          <dl class="wordstat-kv">
            <dt>Режим</dt><dd><?= e(demand_admin_ui_label((string) ($wordstatStatus['mode'] ?? ''))) ?></dd>
            <dt>Проверка доступа</dt><dd><?= e(demand_admin_ui_label((string) ($wordstatStatus['authStatus'] ?? ''))) ?></dd>
            <dt>Где хранятся доступы</dt><dd><?= e(demand_admin_ui_label((string) ($wordstatStatus['credentialSource'] ?? 'not_configured'))) ?></dd>
            <dt>Ключ доступа</dt><dd><?= !empty($wordstatStatus['apiKeyConfigured']) ? 'настроен' : 'не настроен' ?></dd>
            <dt>ID каталога</dt><dd><?= !empty($wordstatStatus['folderIdConfigured']) ? 'настроен' : 'не настроен' ?></dd>
            <dt>Адрес API</dt><dd><?= !empty($wordstatStatus['baseUrlConfigured']) ? 'настроен' : 'не настроен' ?></dd>
            <dt>Метка доступа</dt><dd><?= e((string) ($wordstatStatus['maskedCredentialLabel'] ?? 'не настроено')) ?></dd>
          </dl>
        </section>
        <section class="metric-card">
          <h3>Лимиты и стоимость</h3>
          <dl class="wordstat-kv">
            <dt>Сегодня</dt><dd><?= e((string) ($wordstatCostTotals['dailyRequests'] ?? 0)) ?> / <?= e((string) ($wordstatStatus['dailyRequestLimit'] ?? 0)) ?></dd>
            <dt>За месяц</dt><dd><?= e((string) ($wordstatCostTotals['monthlyRequests'] ?? 0)) ?> / <?= e((string) ($wordstatStatus['monthlyRequestLimit'] ?? 0)) ?></dd>
            <dt>За один запуск</dt><dd><?= e((string) ($wordstatStatus['perRunRequestLimit'] ?? 0)) ?></dd>
            <dt>Стоимость за месяц</dt><dd><?= e((string) ($wordstatCostTotals['monthlyCostRub'] ?? 0)) ?> / <?= e((string) ($wordstatStatus['estimatedCostLimitRub'] ?? 0)) ?> RUB</dd>
            <dt>Последняя загрузка</dt><dd><?= e((string) ($wordstatStatus['lastSyncAt'] ?? '')) ?: '—' ?></dd>
            <dt>Последняя ошибка</dt><dd><?= e((string) ($wordstatStatus['lastError'] ?? '')) ?: '—' ?></dd>
          </dl>
        </section>
        <section class="metric-card">
          <h3>Справочник регионов</h3>
          <p class="field-hint">
            Обновлено: <?= e((string) ($wordstatRegionsCache['lastUpdatedAt'] ?? '')) ?: '—' ?>;
            всего в справочнике: <?= (int) $wordstatRegionCount ?>;
            ниже показаны первые <?= (int) min($wordstatRegionPreviewLimit, $wordstatRegionCount) ?>.
          </p>
          <div class="demand-mini-list">
            <?php foreach ($wordstatRegions as $region): ?>
              <?php if (!is_array($region)) { continue; } ?>
              <?= demand_wordstat_region_chip($region) ?>
            <?php endforeach; ?>
            <?php if (!$wordstatRegions): ?><span>нет данных</span><?php endif; ?>
          </div>
          <?php if ($wordstatKeyRegions): ?>
            <p class="field-hint wordstat-region-click-hint">Нажмите регион, чтобы добавить его ID в поля регионов.</p>
            <p class="field-hint">Ключевые регионы Rent RK, найденные во всём справочнике:</p>
            <div class="demand-mini-list">
              <?php foreach ($wordstatKeyRegions as $region): ?>
                <?php if (!is_array($region)) { continue; } ?>
                <?= demand_wordstat_region_chip($region) ?>
              <?php endforeach; ?>
            </div>
          <?php elseif ($wordstatRegionCount > 0): ?>
            <p class="field-hint warning">Крым, Ялта и Симферополь не найдены во всём справочнике. Стоит перезагрузить регионы или проверить ответ API.</p>
          <?php endif; ?>
        </section>
      </div>

      <?php if (has_permission('demand.wordstat.sync')): ?>
        <div class="wordstat-action-grid">
          <form method="post" class="metric-card wordstat-sync-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="integrations">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="wordstat_dry_run">
            <?= demand_integration_command_fields('wordstat_dry_run') ?>
            <input type="hidden" name="target_scope_id" value="<?= e($scopeFilter !== 'all' ? $scopeFilter : 'rent_rk') ?>">
            <h3>Пробная проверка без изменений</h3>
            <label>Стартовые фразы <textarea name="seed_phrases" rows="4"><?= e($wordstatDefaultSeeds) ?></textarea></label>
            <label>ID регионов <input name="region_ids" value="<?= e($wordstatDefaultRegions) ?>"></label>
            <div class="wordstat-methods">
              <?php foreach ($wordstatMethods as $method): ?>
                <label class="check-row"><input type="checkbox" name="methods[]" value="<?= e($method) ?>" checked><span><?= e(demand_admin_wordstat_method_label((string) $method)) ?></span></label>
              <?php endforeach; ?>
            </div>
            <p class="field-hint">Покажет план запросов, примерную стоимость и предупреждения. Фразы спроса и советы системы не изменятся.</p>
            <button class="btn secondary" type="submit">Проверить без изменений</button>
          </form>

          <?php if (has_permission('demand.wordstat.live') && $wordstatLiveAvailable): ?>
            <form method="post" class="metric-card wordstat-sync-form">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="integrations">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="wordstat_live_sync">
              <?= demand_integration_command_fields('wordstat_live_sync') ?>
              <input type="hidden" name="target_scope_id" value="<?= e($scopeFilter !== 'all' ? $scopeFilter : 'rent_rk') ?>">
              <h3>Загрузить данные Wordstat</h3>
              <label>Стартовые фразы <textarea name="seed_phrases" rows="4"><?= e($wordstatDefaultSeeds) ?></textarea></label>
              <label>ID регионов <input name="region_ids" value="<?= e($wordstatDefaultRegions) ?>"></label>
              <div class="wordstat-methods">
                <?php foreach ($wordstatMethods as $method): ?>
                  <label class="check-row"><input type="checkbox" name="methods[]" value="<?= e($method) ?>" checked><span><?= e(demand_admin_wordstat_method_label((string) $method)) ?></span></label>
                <?php endforeach; ?>
              </div>
              <label class="check-row"><input type="checkbox" name="confirmed" value="1"><span>Подтверждаю ручной запуск: live может обновить Wordstat-derived Demand keyword metrics/recommendations. Страницы, sitemap.xml, robots.txt, публикация и индексация не меняются.</span></label>
              <p class="field-hint warning">Доступно после проверки подключения, ручного разрешения загрузки и проверки лимитов. Direction metadata сохраняется только если запуск пришёл из direction flow.</p>
              <button class="btn" type="submit">Загрузить данные Wordstat</button>
            </form>
          <?php elseif (has_permission('demand.wordstat.live')): ?>
            <section class="metric-card wordstat-sync-form">
              <h3>Загрузить данные Wordstat</h3>
              <p class="field-hint warning">Пока недоступно: сначала проверьте подключение, разрешите ручную загрузку и убедитесь, что лимиты в норме.</p>
              <p class="field-hint">Даже после включения загрузка обновляет только спрос, метрики и советы системы. Публичные страницы, карта сайта для поисковиков, robots.txt и индексация остаются под ручным мастером публикации.</p>
            </section>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <details class="demand-technical-details">
        <summary><span>История и технические детали Wordstat</span><small>Запуски, стоимость, методы и безопасные логи без секретов.</small></summary>
      <div class="table-wrap wordstat-table-wrap">
        <table class="report-table">
          <thead><tr><th>Запуск</th><th>Режим</th><th>Методы</th><th>Запросы</th><th>Стоимость</th><th>Создано / обновлено</th><th>Статус</th></tr></thead>
          <tbody>
          <?php if (!$wordstatRecentRuns): ?><tr><td colspan="7">Истории запусков Wordstat пока нет.</td></tr><?php endif; ?>
          <?php foreach (array_slice($wordstatRecentRuns, 0, 12) as $run): ?>
            <tr>
              <th><?= e((string) ($run['id'] ?? '')) ?><small><?= e((string) ($run['startedAt'] ?? '')) ?></small></th>
              <td><?= e(demand_admin_ui_label((string) ($run['mode'] ?? ''))) ?><small><?= !empty($run['dryRun']) ? 'Пробная проверка' : 'Ручная загрузка' ?></small></td>
              <td><?= e(demand_admin_list_labels((array) ($run['methods'] ?? []), 'demand_admin_wordstat_method_label')) ?></td>
              <td><?= e((string) ($run['plannedRequests'] ?? $run['itemsRead'] ?? 0)) ?></td>
              <td><?= e((string) ($run['estimatedCostRub'] ?? 0)) ?> RUB</td>
              <td><?= e((string) ($run['itemsCreated'] ?? 0)) ?> / <?= e((string) ($run['itemsUpdated'] ?? 0)) ?></td>
              <td><span class="status <?= e(demand_admin_status_class((string) ($run['status'] ?? ''))) ?>"><?= e(demand_admin_ui_label((string) ($run['status'] ?? ''))) ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <?php if (has_permission('demand.wordstat.logs.view')): ?>
        <div class="table-wrap wordstat-table-wrap">
          <table class="report-table">
            <thead><tr><th>Метод</th><th>Запросы</th><th>Стоимость</th><th>Запуск</th><th>Дата</th></tr></thead>
            <tbody>
            <?php foreach (array_slice((array) ($wordstatCostLedger['items'] ?? []), 0, 12) as $cost): ?>
              <?php if (!is_array($cost)) { continue; } ?>
              <tr>
                <td><?= e(demand_admin_wordstat_method_label((string) ($cost['method'] ?? ''))) ?></td>
                <td><?= e((string) ($cost['requestCount'] ?? 0)) ?></td>
                <td><?= e((string) ($cost['estimatedCostRub'] ?? 0)) ?> RUB</td>
                <td><?= e((string) ($cost['runId'] ?? '')) ?></td>
                <td><?= e((string) ($cost['createdAt'] ?? '')) ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (empty($wordstatCostLedger['items'])): ?><tr><td colspan="5">Журнал стоимости пока пуст.</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
        <div class="table-wrap wordstat-table-wrap">
          <table class="report-table">
            <thead><tr><th>Код</th><th>Сообщение</th><th>Важность</th><th>Дата</th></tr></thead>
            <tbody>
            <?php if (!$wordstatRecentErrors): ?><tr><td colspan="4">Ошибок и предупреждений Wordstat пока нет.</td></tr><?php endif; ?>
            <?php foreach (array_slice($wordstatRecentErrors, 0, 12) as $item): ?>
              <tr>
                <td><?= e((string) ($item['code'] ?? '')) ?></td>
                <td><?= e((string) ($item['message'] ?? '')) ?></td>
                <td><?= e(demand_admin_ui_label((string) ($item['severity'] ?? ''))) ?></td>
                <td><?= e((string) ($item['createdAt'] ?? '')) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
      </details>
    </article>
  <?php endif; ?>

  <?php if (has_permission('demand.integrations.sync')): ?>
    <details class="panel demand-technical-details">
      <summary><span>Проверочные загрузки без внешних API</span><small>Служебные кнопки для тестовых данных и безопасной диагностики.</small></summary>
      <p class="muted">Кнопки создают тестовый запуск и тестовые метрики в private JSON. Сетевые запросы намеренно отсутствуют.</p>
      <div class="demand-row-actions">
        <?php foreach ($integrationSources as $source => $sourceSettings): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="integrations">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="integration_mock_sync">
            <?= demand_integration_command_fields('integration_mock_sync') ?>
            <input type="hidden" name="source" value="<?= e((string) $source) ?>">
            <input type="hidden" name="target_scope_id" value="<?= e($scopeFilter !== 'all' ? $scopeFilter : 'rent_rk') ?>">
            <button class="btn secondary small" type="submit">Проверить <?= e((string) ($sourceSettings['label'] ?? $source)) ?></button>
          </form>
        <?php endforeach; ?>
      </div>
    </details>
  <?php endif; ?>

  <details class="panel demand-technical-details">
    <summary><span>История загрузок и обновлений</span><small>Служебный журнал источников данных.</small></summary>
    <div class="table-wrap">
      <table class="report-table">
        <thead><tr><th>ID</th><th>Источник</th><th>Контур / парк</th><th>Статус</th><th>Пробная проверка</th><th>Прочитано / создано / пропущено</th><th>Время</th></tr></thead>
        <tbody>
        <?php if (!$integrationRuns): ?><tr><td colspan="7">Истории синхронизаций пока нет.</td></tr><?php endif; ?>
        <?php foreach (array_slice($integrationRuns, 0, 30) as $run): ?>
          <tr>
            <th><?= e((string) ($run['id'] ?? '')) ?></th>
            <td><?= e((string) ($run['source'] ?? '')) ?><small><?= e(demand_admin_ui_label((string) ($run['mode'] ?? ''))) ?></small></td>
            <td><?= e(scope_display_name((string) ($run['scope_id'] ?? 'rent_rk'))) ?></td>
            <td><span class="status <?= e(demand_admin_status_class((string) ($run['status'] ?? ''))) ?>"><?= e(demand_admin_ui_label((string) ($run['status'] ?? ''))) ?></span></td>
            <td><?= !empty($run['dryRun']) ? 'да' : 'нет' ?></td>
            <td><?= e((string) ($run['itemsRead'] ?? 0)) ?> / <?= e((string) ($run['itemsCreated'] ?? 0)) ?> / <?= e((string) ($run['itemsSkipped'] ?? 0)) ?></td>
            <td><?= e((string) ($run['startedAt'] ?? '')) ?><small><?= e((string) ($run['finishedAt'] ?? '')) ?></small></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </details>

  <?php if (has_permission('demand.integrations.logs.view')): ?>
    <details class="panel demand-technical-details">
      <summary><span>Ошибки и предупреждения источников</span><small>Показывается при диагностике подключения и загрузок.</small></summary>
      <div class="table-wrap">
        <table class="report-table">
          <thead><tr><th>Источник</th><th>Контур / парк</th><th>Важность</th><th>Код</th><th>Сообщение</th><th>Дата</th></tr></thead>
          <tbody>
          <?php if (!$integrationErrors): ?><tr><td colspan="6">Ошибок нет.</td></tr><?php endif; ?>
          <?php foreach (array_slice($integrationErrors, 0, 30) as $item): ?>
            <tr>
              <td><?= e((string) ($item['source'] ?? '')) ?></td>
              <td><?= e(scope_display_name((string) ($item['scope_id'] ?? 'rent_rk'))) ?></td>
              <td><?= e(demand_admin_ui_label((string) ($item['severity'] ?? ''))) ?></td>
              <td><?= e((string) ($item['code'] ?? '')) ?></td>
              <td><?= e((string) ($item['message'] ?? '')) ?></td>
              <td><?= e((string) ($item['createdAt'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </details>
  <?php endif; ?>

  <details class="panel demand-technical-details">
    <summary><span>Снимки эффективности</span><small>Промежуточные агрегаты по спросу, визитам и заявкам.</small></summary>
    <p class="muted">Агрегаты собираются из черновиков и посадочных, тестовых метрик, локальной аналитики и данных источника заявки. Нули означают “данных пока нет”.</p>
    <div class="table-wrap">
      <table class="report-table">
        <thead><tr><th>Страница</th><th>Период</th><th>Спрос</th><th>Показы</th><th>Клики</th><th>Визиты</th><th>Заявки</th><th>AI-переходы</th><th>Статус</th></tr></thead>
        <tbody>
        <?php if (!$performanceSnapshots): ?><tr><td colspan="9">Снимок эффективности ещё не собран.</td></tr><?php endif; ?>
        <?php foreach (array_slice($performanceSnapshots, 0, 30) as $snapshot): ?>
          <?php $summary = is_array($snapshot['summary'] ?? null) ? $snapshot['summary'] : []; ?>
          <tr>
            <th><?= e((string) ($snapshot['slug'] ?? '')) ?><small><?= e((string) ($snapshot['landingPageId'] ?? '')) ?></small></th>
            <td><?= e((string) ($snapshot['periodFrom'] ?? '')) ?> — <?= e((string) ($snapshot['periodTo'] ?? '')) ?></td>
            <td><?= e((string) ($summary['wordstatFrequency'] ?? 0)) ?></td>
            <td><?= e((string) ($summary['searchImpressions'] ?? 0)) ?></td>
            <td><?= e((string) ($summary['searchClicks'] ?? 0)) ?></td>
            <td><?= e((string) ($summary['visits'] ?? 0)) ?></td>
            <td><?= e((string) ($summary['requests'] ?? 0)) ?></td>
            <td><?= e((string) ($summary['aiReferralVisits'] ?? 0)) ?></td>
            <td><span class="status <?= e(demand_admin_status_class((string) ($snapshot['status'] ?? ''))) ?>"><?= e(demand_admin_ui_label((string) ($snapshot['status'] ?? ''))) ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </details>
<?php elseif ($tab === 'wordstat_help' && (has_permission('demand.wordstat.view') || has_permission('demand.wordstat.manage'))): ?>
  <article class="panel wordstat-help-panel">
    <div class="panel-head">
      <div>
        <h2>Wordstat</h2>
        <p class="muted">Пошаговая настройка: подключить доступы, проверить регионы, сделать пробную проверку и только потом вручную загрузить данные. Страницы, поиск, карта сайта для поисковиков и robots.txt остаются под ручным мастером публикации.</p>
      </div>
      <a class="btn secondary small" href="<?= e(demand_admin_scope_filter_url('integrations', $scopeFilter)) ?>">К источникам данных</a>
    </div>

    <?php if ($wordstatHasConnectionProblem): ?>
      <div class="wordstat-attention-box" role="status">
        <div>
          <strong>Проверка Wordstat не прошла</strong>
          <p>Смотрите шаг 2 «Проверка подключения»: там показаны причина, что именно проверить и безопасная техническая деталь.</p>
        </div>
        <a class="btn secondary small" href="#wordstat-connection-check">К причине ошибки</a>
      </div>
    <?php endif; ?>

    <div class="wordstat-setup-steps">
      <?php foreach ($wordstatSetupSteps as $setupStep): ?>
        <section class="wordstat-setup-step <?= e(demand_wordstat_setup_state_class((string) ($setupStep['state'] ?? 'pending'))) ?>">
          <span class="wordstat-setup-number"><?= e((string) ($setupStep['number'] ?? '')) ?></span>
          <div>
            <h3><?= e((string) ($setupStep['title'] ?? '')) ?></h3>
            <p><?= e((string) ($setupStep['summary'] ?? '')) ?></p>
          </div>
        </section>
      <?php endforeach; ?>
    </div>

    <?php
      $wordstatAccessDetailsOpen = empty($wordstatStatus['apiKeyConfigured'])
          || empty($wordstatStatus['folderIdConfigured'])
          || empty($wordstatStatus['baseUrlConfigured'])
          || $wordstatHasConnectionProblem;
    ?>
    <div class="wordstat-setup-grid">
      <section class="metric-card wordstat-setup-card">
        <div class="wordstat-setup-card-head">
          <span class="wordstat-setup-number">1</span>
          <div>
            <div class="wordstat-card-title">
              <h3>Подключить Yandex Cloud</h3>
              <?= demand_help_popover('Где взять доступы', 'Для текущей интеграции нужен ключ доступа сервисного аккаунта Yandex Cloud с доступом к Search API и ID каталога. Ключ хранится только в private-файле или env, ID каталога берётся в console.yandex.cloud в карточке каталога, адрес API по умолчанию: https://searchapi.api.cloud.yandex.net/v2/wordstat.') ?>
            </div>
            <p class="muted">Сохраните новый ключ доступа и ID каталога. Старые тестовые доступы можно сбросить; в админке виден только статус.</p>
          </div>
        </div>
        <div class="wordstat-setup-summary">
          <span>Доступы: <?= !empty($wordstatStatus['apiKeyConfigured']) && !empty($wordstatStatus['folderIdConfigured']) && !empty($wordstatStatus['baseUrlConfigured']) ? 'настроены' : 'нужно настроить' ?></span>
          <span>Проверка: <?= e(demand_wordstat_auth_status_label((string) ($wordstatStatus['authStatus'] ?? 'not_configured'))) ?></span>
        </div>
        <details class="wordstat-technical-settings" <?= $wordstatAccessDetailsOpen ? 'open' : '' ?>>
          <summary>
            <span>Доступы и технические настройки</span>
            <small>Обычно нужны только при первичном подключении или замене ключа.</small>
          </summary>
        <dl class="wordstat-kv">
          <dt>Где хранятся доступы</dt><dd><?= e(demand_admin_ui_label((string) ($wordstatStatus['credentialSource'] ?? 'not_configured'))) ?></dd>
          <dt>Ключ доступа</dt><dd><?= !empty($wordstatStatus['apiKeyConfigured']) ? 'настроен' : 'не настроен' ?></dd>
          <dt>ID каталога</dt><dd><?= !empty($wordstatStatus['folderIdConfigured']) ? 'настроен' : 'не настроен' ?></dd>
          <dt>Адрес API</dt><dd><?= !empty($wordstatStatus['baseUrlConfigured']) ? 'настроен' : 'не настроен' ?></dd>
          <dt>Метка доступа</dt><dd><?= e((string) ($wordstatStatus['maskedCredentialLabel'] ?? 'не настроено')) ?></dd>
        </dl>
        <div class="wordstat-compact-note">
          <span>Private-файл: <code>private/rent-rk-data/secrets/wordstat-credentials.local.json</code></span>
          <?= demand_help_popover('Env-переменные', 'Можно задать WORDSTAT_API_KEY, WORDSTAT_FOLDER_ID, WORDSTAT_AUTH_MODE и WORDSTAT_BASE_URL на сервере. Если env уже задан, он имеет приоритет над private-файлом из админки.') ?>
        </div>
        <?php if (has_permission('demand.wordstat.manage')): ?>
          <form method="post" class="wordstat-credentials-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="wordstat_help">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="wordstat_wizard_save_credentials">
            <?= demand_integration_command_fields('wordstat_wizard_save_credentials') ?>
            <div class="wordstat-field"><div class="field-label-with-help"><span>Способ авторизации</span><?= demand_help_popover('Способ авторизации', 'Для ключа доступа Yandex Cloud используйте api_key: запрос уйдёт с заголовком Authorization: Api-Key <ключ>. Bearer нужен только если вы осознанно подключаете IAM-токен через env/private-файл.') ?></div>
              <select name="wordstat_auth_mode">
                <option value="api_key" <?= (string) ($wordstatStatus['authMode'] ?? 'api_key') === 'api_key' ? 'selected' : '' ?>>api_key</option>
                <option value="bearer" <?= (string) ($wordstatStatus['authMode'] ?? '') === 'bearer' ? 'selected' : '' ?>>bearer</option>
              </select>
            </div>
            <div class="wordstat-field"><div class="field-label-with-help"><span>Ключ доступа</span><?= demand_help_popover('Ключ доступа', 'Ключ создаётся в Yandex Cloud / AI Studio для сервисного аккаунта. Для Search API у ключа должен быть доступ к выполнению запросов. Не вставляйте ключ в публичные JS, HTML или JSON; в Rent RK он хранится только в private-файле или env.') ?></div><input type="password" name="wordstat_api_key" autocomplete="new-password" placeholder="не показывается после сохранения"></div>
            <div class="wordstat-field"><div class="field-label-with-help"><span>ID каталога Яндекс Cloud</span><?= demand_help_popover('ID каталога Яндекс Cloud', 'Откройте console.yandex.cloud, выберите облако и каталог проекта, затем скопируйте ID каталога. Это не название default, а технический идентификатор из карточки каталога или URL /folders/<folderId>.') ?></div><input name="wordstat_folder_id" autocomplete="off" placeholder="например b1g..."></div>
            <div class="wordstat-field"><div class="field-label-with-help"><span>Адрес API</span><?= demand_help_popover('Адрес API', 'Для Yandex Cloud Search API Wordstat используйте базовый адрес https://searchapi.api.cloud.yandex.net/v2/wordstat. Методы topRequests, dynamics, regions и getRegionsTree мастер добавляет сам.') ?></div><input name="wordstat_base_url" autocomplete="off" placeholder="https://searchapi.api.cloud.yandex.net/v2/wordstat"></div>
            <p class="field-hint">Пустые поля сохраняют прежние private-значения. Если там могли остаться старые тестовые ключи, сначала нажмите “Удалить старые private-доступы”.</p>
            <button class="btn secondary small" type="submit">Сохранить private-файл доступов</button>
          </form>
          <form method="post" class="inline-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="wordstat_help">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="wordstat_wizard_clear_credentials">
            <?= demand_integration_command_fields('wordstat_wizard_clear_credentials') ?>
            <button class="btn secondary small" type="submit">Удалить старые private-доступы</button>
          </form>
        <?php endif; ?>
        <?php if (has_permission('demand.wordstat.test')): ?>
          <form method="post" class="inline-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="wordstat_help">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="wordstat_refresh_credentials_status">
            <?= demand_integration_command_fields('wordstat_refresh_credentials_status') ?>
            <button class="btn secondary small" type="submit">Обновить статус доступов</button>
          </form>
        <?php endif; ?>
        </details>
      </section>

      <section id="wordstat-connection-check" class="metric-card wordstat-setup-card <?= $wordstatHasConnectionProblem ? 'has-wordstat-problem' : '' ?>">
        <div class="wordstat-setup-card-head">
          <span class="wordstat-setup-number">2</span>
          <div>
            <div class="wordstat-card-title">
              <h3>Проверить подключение</h3>
              <?= demand_help_popover('Что проверяет кнопка', 'Проверяется доступность адреса API и авторизация. Ключ доступа не отображается и не попадает в логи ошибок; при ошибке сохраняется только безопасное описание.') ?>
            </div>
            <p class="muted">Без публикаций, изменений спроса и карты сайта для поисковиков. Только статус подключения.</p>
          </div>
        </div>
        <dl class="wordstat-kv">
          <dt>Статус</dt><dd><?= e((string) ($wordstatConnectionProblem['statusLabel'] ?? demand_wordstat_auth_status_label((string) ($wordstatStatus['authStatus'] ?? 'not_configured')))) ?></dd>
          <?php if ($wordstatHasConnectionProblem): ?>
            <dt>Причина</dt><dd><?= e($wordstatLastError) ?></dd>
          <?php endif; ?>
        </dl>
        <?php if ($wordstatHasConnectionProblem): ?>
          <div class="wordstat-error-box" role="status">
            <strong>Причина ошибки подключения</strong>
            <p><b>Что случилось:</b> <?= e($wordstatLastError) ?></p>
            <p><b>Что сделать:</b> <?= e($wordstatLastErrorAdvice !== '' ? $wordstatLastErrorAdvice : 'Проверьте ключ доступа, ID каталога и адрес API. Для текущей интеграции нужен адрес API https://searchapi.api.cloud.yandex.net/v2/wordstat.') ?></p>
            <?php if ($wordstatLastErrorCode !== ''): ?><p><b>Код:</b> <code><?= e($wordstatLastErrorCode) ?></code></p><?php endif; ?>
            <?php if ($wordstatLastErrorTechnical !== ''): ?><details><summary>Показать технические детали</summary><p><?= e($wordstatLastErrorTechnical) ?></p></details><?php endif; ?>
            <?php if ($wordstatLastErrorAt !== ''): ?><small>Обновлено: <?= e($wordstatLastErrorAt) ?></small><?php endif; ?>
          </div>
        <?php endif; ?>
        <?php if (has_permission('demand.wordstat.test')): ?>
          <form method="post" class="inline-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="wordstat_help">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="wordstat_test_connection">
            <?= demand_integration_command_fields('wordstat_test_connection') ?>
            <button class="btn secondary small" type="submit">Проверить подключение</button>
          </form>
        <?php endif; ?>
      </section>

      <section class="metric-card wordstat-setup-card">
        <div class="wordstat-setup-card-head">
          <span class="wordstat-setup-number">3</span>
          <div>
            <div class="wordstat-card-title">
              <h3>Загрузить регионы</h3>
              <?= demand_help_popover('Зачем нужны регионы', 'ID регионов — числовые идентификаторы регионов Яндекса. Они нужны, чтобы спрос считался по нужной географии: Крым, Ялта, Симферополь и близкие регионы. Сначала загрузите регионы кнопкой ниже.') ?>
            </div>
            <p class="muted">Один раз обновите справочник, потом используйте ID регионов в пробной проверке.</p>
          </div>
        </div>
        <p class="field-hint">
          Обновлено: <?= e((string) ($wordstatRegionsCache['lastUpdatedAt'] ?? '')) ?: '—' ?>;
          всего в справочнике: <?= (int) $wordstatRegionCount ?>;
          ниже показаны первые <?= (int) min($wordstatRegionPreviewLimit, $wordstatRegionCount) ?>.
        </p>
        <div class="demand-mini-list">
          <?php foreach ($wordstatRegions as $region): ?>
            <?php if (!is_array($region)) { continue; } ?>
            <?= demand_wordstat_region_chip($region) ?>
          <?php endforeach; ?>
          <?php if (!$wordstatRegions): ?><span>Регионов в справочнике пока нет.</span><?php endif; ?>
        </div>
        <?php if ($wordstatKeyRegions): ?>
          <p class="field-hint wordstat-region-click-hint">Нажмите регион, чтобы добавить его ID в поля регионов справа и ниже.</p>
          <p class="field-hint">Нужные для Rent RK регионы, найденные во всём справочнике:</p>
          <div class="demand-mini-list">
            <?php foreach ($wordstatKeyRegions as $region): ?>
              <?php if (!is_array($region)) { continue; } ?>
              <?= demand_wordstat_region_chip($region) ?>
            <?php endforeach; ?>
          </div>
        <?php elseif ($wordstatRegionCount > 0): ?>
          <p class="field-hint warning">Во всём справочнике не найдены Крым, Ялта и Симферополь. Если после перезагрузки регионов их всё равно нет, нужно смотреть технический ответ API.</p>
        <?php endif; ?>
        <?php if ($wordstatCrimeaRegions): ?>
          <div class="wordstat-region-picker" data-wordstat-region-picker>
            <div class="wordstat-region-picker-head">
              <div>
                <h4>Все найденные регионы Крыма</h4>
                <p class="field-hint">Это не только быстрые кнопки выше. Ищите город по названию и нажимайте регион, чтобы добавить его ID в поля регионов.</p>
              </div>
              <span class="status status-service"><?= count($wordstatCrimeaRegions) ?> регионов</span>
            </div>
            <label class="wordstat-region-search">
              <span>Поиск региона</span>
              <input type="search" data-wordstat-region-search-input placeholder="Например: Судак, Бахчисарай, Джанкой">
            </label>
            <div class="demand-mini-list wordstat-region-picker-list" data-wordstat-region-list>
              <?php foreach ($wordstatCrimeaRegions as $region): ?>
                <?php if (!is_array($region)) { continue; } ?>
                <?= demand_wordstat_region_chip($region) ?>
              <?php endforeach; ?>
            </div>
            <p class="field-hint wordstat-region-empty" data-wordstat-region-empty hidden>В справочнике нет региона с таким названием. Попробуйте более короткий запрос или используйте регион шире: Республика Крым.</p>
          </div>
        <?php endif; ?>
        <?php if (has_permission('demand.wordstat.sync')): ?>
          <form method="post" class="inline-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="wordstat_help">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="wordstat_load_regions">
            <?= demand_integration_command_fields('wordstat_load_regions') ?>
            <button class="btn secondary small" type="submit">Загрузить регионы</button>
          </form>
        <?php endif; ?>
      </section>

      <form method="post" class="metric-card wordstat-setup-card">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="tab" value="wordstat_help">
        <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
        <input type="hidden" name="action" value="wordstat_wizard_save_dry_run_settings">
        <?= demand_integration_command_fields('wordstat_wizard_save_dry_run_settings') ?>
        <div class="wordstat-setup-card-head">
          <span class="wordstat-setup-number">4</span>
          <div>
            <div class="wordstat-card-title">
              <h3>Настроить пробную проверку</h3>
              <?= demand_help_popover('Пробная проверка безопасна', 'Система показывает, какие фразы, регионы и методы будут обработаны, сколько будет запросов и примерная стоимость. Она ничего не публикует, не меняет карту сайта для поисковиков или robots.txt и не отправляет страницы в поиск.') ?>
            </div>
            <p class="muted">Фразы, регионы и лимиты для безопасного расчёта.</p>
          </div>
        </div>
        <div class="wordstat-field"><div class="field-label-with-help"><span>Стартовые фразы</span><?= demand_help_popover('Стартовые фразы', 'Это реальные стартовые запросы клиентов: “аренда авто Ялта”, “прокат авто Симферополь”, “аренда кабриолета Крым”, “минивэн в аренду”. Вводите каждую фразу с новой строки, без служебных символов и случайного текста.') ?></div><textarea name="default_seed_phrases" rows="2"><?= e($wordstatDefaultSeeds) ?></textarea></div>
        <div class="wordstat-field"><div class="field-label-with-help"><span>ID регионов</span><?= demand_help_popover('ID регионов', 'Укажите ID регионов через запятую. Если не знаете ID, сначала нажмите “Загрузить регионы”, затем используйте найденные значения для Крыма, Ялты, Симферополя и нужной географии.') ?></div><input name="default_region_ids" value="<?= e($wordstatDefaultRegions) ?>"></div>
        <details class="wordstat-advanced">
          <summary>Лимиты и повторы</summary>
          <div class="wordstat-settings-fields">
            <label>Дневной лимит запросов <input type="number" min="0" name="dailyRequestLimit" value="<?= e((string) ($wordstatStatus['dailyRequestLimit'] ?? 100)) ?>"></label>
            <label>Месячный лимит запросов <input type="number" min="0" name="monthlyRequestLimit" value="<?= e((string) ($wordstatStatus['monthlyRequestLimit'] ?? 1000)) ?>"></label>
            <label>Лимит за один запуск <input type="number" min="0" name="perRunRequestLimit" value="<?= e((string) ($wordstatStatus['perRunRequestLimit'] ?? 20)) ?>"></label>
            <label>Лимит стоимости, RUB <input type="number" min="0" step="0.01" name="estimatedCostLimitRub" value="<?= e((string) ($wordstatStatus['estimatedCostLimitRub'] ?? 500)) ?>"></label>
            <label>Пауза между запросами, сек <input type="number" min="0" name="cooldownSecondsBetweenRequests" value="<?= e((string) ($wordstatStatus['cooldownSecondsBetweenRequests'] ?? 2)) ?>"></label>
            <label>Повторных попыток <input type="number" min="0" name="retryAttempts" value="<?= e((string) ($wordstatStatus['retryAttempts'] ?? 2)) ?>"></label>
            <label>Пауза перед повтором, сек <input type="number" min="0" name="retryBackoffSeconds" value="<?= e((string) ($wordstatStatus['retryBackoffSeconds'] ?? 5)) ?>"></label>
          </div>
        </details>
        <?php if (has_permission('demand.wordstat.manage')): ?>
          <button class="btn secondary" type="submit">Сохранить настройки пробной проверки</button>
        <?php endif; ?>
      </form>

      <form method="post" class="metric-card wordstat-setup-card">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="tab" value="wordstat_help">
        <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
        <input type="hidden" name="action" value="wordstat_dry_run">
        <?= demand_integration_command_fields('wordstat_dry_run') ?>
        <input type="hidden" name="target_scope_id" value="<?= e($scopeFilter !== 'all' ? $scopeFilter : 'rent_rk') ?>">
        <div class="wordstat-setup-card-head">
          <span class="wordstat-setup-number">5</span>
          <div>
            <div class="wordstat-card-title">
              <h3>Проверить без изменений</h3>
              <?= demand_help_popover('Что будет после проверки', 'Будет создан безопасный журнал проверки с планом запросов, примерной стоимостью, пропущенными пунктами и предупреждениями. Фразы спроса, советы системы, карта сайта для поисковиков, robots.txt и индексация останутся без изменений.') ?>
            </div>
            <p class="muted">Проверка плана без изменения спроса и рекомендаций.</p>
          </div>
        </div>
        <label>Стартовые фразы <textarea name="seed_phrases" rows="2"><?= e($wordstatDefaultSeeds) ?></textarea></label>
        <label>ID регионов <input name="region_ids" value="<?= e($wordstatDefaultRegions) ?>"></label>
        <div class="wordstat-methods">
          <?php foreach ($wordstatMethods as $method): ?>
            <label class="check-row"><input type="checkbox" name="methods[]" value="<?= e($method) ?>" checked><span><?= e(demand_admin_wordstat_method_label((string) $method)) ?></span></label>
          <?php endforeach; ?>
        </div>
        <?php if (has_permission('demand.wordstat.sync')): ?>
          <button class="btn secondary" type="submit">Проверить без изменений</button>
        <?php endif; ?>
      </form>

      <section class="metric-card wordstat-setup-card" id="wordstat-dry-run-result">
        <div class="wordstat-setup-card-head">
          <span class="wordstat-setup-number">✓</span>
          <div>
            <div class="wordstat-card-title">
              <h3>Результат последней пробной проверки</h3>
              <?= demand_help_popover('Где смотреть результат', 'После пробной проверки смотрите этот блок: он показывает, что именно проверялось, сколько запросов запланировано и что система не изменила. Это репетиция перед ручной загрузкой, а не публикация страниц.') ?>
            </div>
            <p class="muted">Пробная проверка ничего не публикует, не меняет карту сайта для поисковиков или robots.txt и не открывает страницы для поиска.</p>
          </div>
        </div>
        <?php
          if (!$wordstatLatestDryRun) {
              $wordstatLatestDryRun = demand_wordstat_latest_dry_run_for_admin($scopeFilter);
          }
        ?>
        <?php if ($wordstatLatestDryRun): ?>
          <?php
            $dryRunPhraseCount = (int) ($wordstatLatestDryRun['planBreakdown']['phraseCount'] ?? demand_wordstat_run_count($wordstatLatestDryRun['seedPhrases'] ?? []));
            $dryRunMethodCount = (int) ($wordstatLatestDryRun['planBreakdown']['methodCount'] ?? demand_wordstat_run_count($wordstatLatestDryRun['methods'] ?? []));
            $dryRunRegionCount = (int) ($wordstatLatestDryRun['planBreakdown']['regionCount'] ?? demand_wordstat_run_count($wordstatLatestDryRun['regionIds'] ?? []));
            $dryRunFormula = (string) ($wordstatLatestDryRun['planBreakdown']['formula'] ?? ($dryRunPhraseCount . ' фраз × ' . $dryRunMethodCount . ' метода'));
            $dryRunExplanation = (string) ($wordstatLatestDryRun['planBreakdown']['explanation'] ?? 'Регионы передаются внутрь каждого Wordstat-запроса, поэтому смена региона меняет географию, но не всегда меняет количество запросов.');
          ?>
          <div class="wordstat-result-summary">
            <strong><?= e($dryRunFormula) ?> = <?= e((string) ($wordstatLatestDryRun['plannedRequests'] ?? $wordstatLatestDryRun['itemsRead'] ?? 0)) ?> запроса</strong>
            <span><?= e((string) $dryRunPhraseCount) ?> фраз, <?= e((string) $dryRunRegionCount) ?> регионов, <?= e((string) $dryRunMethodCount) ?> метода. <?= e($dryRunExplanation) ?></span>
          </div>
          <dl class="wordstat-kv">
            <dt>Статус</dt><dd><span class="status <?= e(demand_admin_status_class((string) ($wordstatLatestDryRun['status'] ?? ''))) ?>"><?= e(demand_admin_ui_label((string) ($wordstatLatestDryRun['status'] ?? ''))) ?></span></dd>
            <dt>Когда</dt><dd><?= e((string) ($wordstatLatestDryRun['finishedAt'] ?? $wordstatLatestDryRun['startedAt'] ?? '')) ?></dd>
            <dt>Фразы</dt><dd><?= e(demand_wordstat_join_values($wordstatLatestDryRun['seedPhrases'] ?? [])) ?></dd>
            <dt>Регионы</dt><dd><?= e(demand_wordstat_join_values($wordstatLatestDryRun['regionIds'] ?? [])) ?></dd>
            <dt>Методы</dt><dd><?= e(demand_admin_list_labels((array) ($wordstatLatestDryRun['methods'] ?? []), 'demand_admin_wordstat_method_label')) ?></dd>
            <dt>Запросов</dt><dd><?= e((string) ($wordstatLatestDryRun['plannedRequests'] ?? $wordstatLatestDryRun['itemsRead'] ?? 0)) ?></dd>
            <dt>Стоимость</dt><dd><?= e((string) ($wordstatLatestDryRun['estimatedCostRub'] ?? 0)) ?> RUB</dd>
          </dl>
          <div class="wordstat-dry-run-next-step">
            <strong>Что реально проверила система</strong>
            <p>Это не получение частотности из Wordstat, а безопасная репетиция запуска: система проверила, какие запросы она бы сделала, сколько это стоило бы по лимитам и что ничего не будет опубликовано автоматически.</p>
            <strong>Почему ответ может выглядеть одинаково</strong>
            <p>Если оставлена одна фраза и включены три метода, расчёт всегда будет `1 × 3 = 3 запроса`. Если добавить вторую фразу, станет `2 × 3 = 6`. Если убрать один метод, станет `1 × 2 = 2`.</p>
          </div>
          <div class="notice success">
            Проверка прошла как репетиция: фразы спроса, советы системы, страницы, карта сайта для поисковиков, robots.txt и индексация не изменялись.
          </div>
          <?php
            $dryRunWarnings = array_values(array_filter(array_map('strval', (array) ($wordstatLatestDryRun['warnings'] ?? $wordstatLatestDryRun['errors'] ?? []))));
            $limitErrors = (array) ($wordstatLatestDryRun['limitPreview']['errors'] ?? []);
          ?>
          <?php if ($dryRunWarnings || $limitErrors): ?>
            <div class="notice warning">
              <strong>Что проверить:</strong>
              <ul class="notice-list">
                <?php foreach (array_merge($dryRunWarnings, $limitErrors) as $warning): ?><li><?= e((string) $warning) ?></li><?php endforeach; ?>
              </ul>
            </div>
          <?php endif; ?>
        <?php else: ?>
          <p class="field-hint">Пробная проверка ещё не запускалась. Заполните фразу и регион, нажмите “Проверить без изменений” — результат появится здесь.</p>
        <?php endif; ?>
      </section>

      <section class="metric-card wordstat-setup-card">
        <div class="wordstat-setup-card-head">
          <span class="wordstat-setup-number">6</span>
          <div>
            <div class="wordstat-card-title">
              <h3>Загрузить данные Wordstat</h3>
              <?= demand_help_popover('Что меняет ручная загрузка', 'Ручная загрузка включается только после проверки доступов и пробной проверки. Она обновляет только слой спроса, метрик и советов системы; не публикует страницы и не меняет карту сайта для поисковиков, robots.txt, основной адрес страницы или статус поиска.') ?>
            </div>
            <p class="muted">Ручной запуск после проверки доступов и лимитов.</p>
          </div>
        </div>
        <dl class="wordstat-kv">
          <dt>Режим</dt><dd><?= e(demand_admin_ui_label((string) ($wordstatStatus['mode'] ?? ''))) ?></dd>
          <dt>Ручная загрузка разрешена</dt><dd><?= !empty($wordstatStatus['liveEnabled']) ? 'да' : 'нет' ?></dd>
          <dt>Можно запускать сейчас</dt><dd><?= $wordstatLiveAvailable ? 'да' : 'нет' ?></dd>
        </dl>
        <div class="demand-row-actions">
          <?php if (has_permission('demand.wordstat.manage') && has_permission('demand.wordstat.live') && !$wordstatLiveAvailable): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="wordstat_help">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="wordstat_wizard_enable_live">
              <?= demand_integration_command_fields('wordstat_wizard_enable_live') ?>
              <button class="btn warning-action small" type="submit">Разрешить ручную загрузку Wordstat</button>
            </form>
          <?php endif; ?>
          <?php if (has_permission('demand.wordstat.manage') && !empty($wordstatStatus['liveEnabled'])): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tab" value="wordstat_help">
              <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
              <input type="hidden" name="action" value="wordstat_wizard_disable_live">
              <?= demand_integration_command_fields('wordstat_wizard_disable_live') ?>
              <button class="btn secondary small" type="submit">Вернуть в режим пробной проверки</button>
            </form>
          <?php endif; ?>
        </div>
        <?php if (has_permission('demand.wordstat.live') && $wordstatLiveAvailable): ?>
          <form method="post" class="wordstat-sync-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="tab" value="wordstat_help">
            <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
            <input type="hidden" name="action" value="wordstat_live_sync">
            <?= demand_integration_command_fields('wordstat_live_sync') ?>
            <input type="hidden" name="target_scope_id" value="<?= e($scopeFilter !== 'all' ? $scopeFilter : 'rent_rk') ?>">
            <label>Стартовые фразы <textarea name="seed_phrases" rows="3"><?= e($wordstatDefaultSeeds) ?></textarea></label>
            <label>ID регионов <input name="region_ids" value="<?= e($wordstatDefaultRegions) ?>"></label>
            <div class="wordstat-methods">
              <?php foreach ($wordstatMethods as $method): ?>
                <label class="check-row"><input type="checkbox" name="methods[]" value="<?= e($method) ?>" checked><span><?= e(demand_admin_wordstat_method_label((string) $method)) ?></span></label>
              <?php endforeach; ?>
            </div>
            <label class="check-row"><input type="checkbox" name="confirmed" value="1"><span>Подтверждаю ручной запуск: live может обновить Wordstat-derived Demand keyword metrics/recommendations; публикация, индексация, sitemap.xml и robots.txt не меняются</span></label>
            <button class="btn" type="submit">Загрузить данные Wordstat</button>
          </form>
        <?php else: ?>
          <p class="field-hint warning">Сначала проверьте подключение и выполните пробную проверку. После этого можно вручную включить загрузку: она обновит только спрос и советы системы, без публикации страниц, карты сайта для поисковиков и индексации.</p>
        <?php endif; ?>
      </section>
    </div>

    <div class="wordstat-safety-strip">
      <section class="metric-card wordstat-safety-card">
        <div class="wordstat-card-title">
          <h3>Секреты</h3>
          <?= demand_help_popover('Private-файл', 'Если не хотите настраивать env, сохраните способ авторизации, ключ доступа, ID каталога и адрес API через форму выше. Файл хранится в private/rent-rk-data/secrets/ и не должен попадать в git, backup или логи.') ?>
        </div>
        <p class="muted">Ключи не выводятся обратно и не попадают в tracked JSON.</p>
      </section>
      <section class="metric-card wordstat-safety-card">
        <div class="wordstat-card-title">
          <h3>Пробная проверка</h3>
          <?= demand_help_popover('Безопасная репетиция', 'Пробная проверка пишет служебный журнал и показывает план, стоимость и предупреждения. Она не меняет demand-keywords.json, рекомендации, страницы, карту сайта для поисковиков или robots.txt.') ?>
        </div>
        <p class="muted">Сначала проверяем план, потом решаем, запускать ли реальную загрузку.</p>
      </section>
      <section class="metric-card wordstat-safety-card">
        <div class="wordstat-card-title">
          <h3>Ручная загрузка</h3>
          <?= demand_help_popover('Ручной запуск', 'Загрузка данных доступна только после проверки доступа, лимитов и ручного включения admin Rent RK. Она обновляет только данные спроса и метрики.') ?>
        </div>
        <p class="muted">Никаких автоматических публикаций и индексации.</p>
      </section>
      <section class="metric-card wordstat-safety-card">
        <div class="wordstat-card-title">
          <h3>Поиск</h3>
          <?= demand_help_popover('Индексация отдельно', 'Открытие страниц для поиска остаётся только в мастере публикации: сначала просмотр без поиска, затем ручное открытие страницы для поиска и добавление в карту сайта для поисковиков после подтверждения.') ?>
        </div>
        <p class="muted">Wordstat не меняет карту сайта для поисковиков, robots.txt, основной адрес и статусы страниц.</p>
      </section>
    </div>
  </article>
<?php elseif ($tab === 'settings'): ?>
<?php if (has_permission('demand.settings.manage')): ?>
  <article class="panel">
    <div class="panel-head">
      <div>
        <h2>Настройки и техническое</h2>
        <p class="muted">Доступны только admin Rent RK. Автоматическое открытие страниц для поиска выключено: публикация остаётся ручной.</p>
      </div>
    </div>
    <form method="post" class="settings-lessor-form">
      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="tab" value="settings">
      <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
      <input type="hidden" name="action" value="save_settings">
      <?= business_form_version_field([DEMAND_SETTINGS_FILE]) ?>
      <label class="check-row"><input type="checkbox" name="enabled" value="1" <?= !empty($settings['enabled']) ? 'checked' : '' ?>><span>Включить модуль спроса</span></label>
      <label class="check-row"><input type="checkbox" name="externalScopesEnabled" value="1" <?= !empty($settings['externalScopesEnabled']) ? 'checked' : '' ?>><span>Разрешить внешним контурам видеть рекомендации</span></label>
      <label class="check-row"><input type="checkbox" name="allowExternalScopeDrafts" value="1" <?= !empty($settings['allowExternalScopeDrafts']) ? 'checked' : '' ?>><span>Разрешить внешним контурам создавать свои черновики, если доступ включён в настройках контура</span></label>
      <label>
        Минимальная частотность для рекомендации черновика
        <input type="number" min="0" step="1" name="minFrequencyForDraftSuggestion" value="<?= e((string) $settings['minFrequencyForDraftSuggestion']) ?>">
      </label>
      <label class="check-row"><input type="checkbox" name="allowAutoDraftCreation" value="1" <?= !empty($settings['allowAutoDraftCreation']) ? 'checked' : '' ?>><span>Разрешить автосоздание черновиков по правилам этапа 1</span></label>
      <label class="check-row"><input type="checkbox" disabled><span>Автоматическое открытие страниц для поиска выключено всегда</span></label>
      <label class="check-row"><input type="checkbox" checked disabled><span>Ручная проверка перед открытием для поиска обязательна</span></label>
      <p class="field-hint rental-field-wide">Для отдельного внешнего контура включите “Модуль спроса доступен” и при необходимости “Черновики посадочных страниц доступны” в настройках контура.</p>
      <button class="btn" type="submit">Сохранить настройки</button>
    </form>
  </article>
<?php endif; ?>
<?php if (has_permission('demand.ai_api.settings.manage') || has_permission('demand.ai_api.logs.view')): ?>
  <?php
    $aiApiRuns = function_exists('openai_ai_read_runs') ? array_reverse((array) (openai_ai_read_runs()['items'] ?? [])) : [];
    $aiApiLimit = function_exists('openai_ai_limit_status') ? openai_ai_limit_status(current_admin_user() ?: 'system', $demandAiApiSettings) : [];
  ?>
  <article class="panel demand-ai-api-settings" id="demand-ai-api-settings">
    <div class="panel-head">
      <div>
        <h2>AI API (DeepSeek)</h2>
        <p class="muted">DeepSeek API помогает объяснять экран и готовить предложения. Он не публикует страницы, не открывает индексацию и ничего не применяет без preview и подтверждения.</p>
      </div>
      <span class="status <?= !empty($demandAiApiSettings['enabled']) ? 'status-free' : 'status-service' ?>"><?= !empty($demandAiApiSettings['enabled']) ? 'Включён' : 'Выключен' ?></span>
    </div>
    <?php if (has_permission('demand.ai_api.settings.manage')): ?>
      <div class="metric-card demand-ai-credentials-card">
        <strong>DeepSeek API key: <?= !empty($demandAiApiSettings['apiKeyConfigured']) ? 'настроен' : 'не настроен' ?></strong>
        <p class="field-hint">Private file: <code>private/rent-rk-data/secrets/deepseek-credentials.local.json</code>. Ключ можно добавить здесь; обратно в HTML он не выводится.</p>
        <p class="field-hint">Если на сервере настроен env `DEEPSEEK_API_KEY`, он имеет приоритет над private file.</p>
      </div>
      <form method="post" class="settings-lessor-form demand-ai-credentials-form" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="tab" value="settings">
        <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
        <input type="hidden" name="action" value="save_ai_api_credentials">
        <?= demand_integration_command_fields('save_ai_api_credentials') ?>
        <label>DeepSeek API key <input type="password" name="deepseek_api_key" value="" autocomplete="new-password" placeholder="<?= !empty($demandAiApiSettings['apiKeyConfigured']) ? 'Оставьте пустым, чтобы сохранить текущий ключ' : 'Вставьте новый ключ DeepSeek' ?>"></label>
        <label>Base URL <input name="deepseek_base_url" value="https://api.deepseek.com" autocomplete="off"></label>
        <label>Модель <input name="deepseek_model" value="<?= e((string) ($demandAiApiSettings['model'] ?? 'deepseek-v4-flash')) ?>" autocomplete="off"></label>
        <label>Timeout, сек <input type="number" min="5" max="120" name="deepseek_timeout_seconds" value="<?= e((string) ($demandAiApiSettings['perRequestTimeoutSeconds'] ?? 45)) ?>"></label>
        <p class="field-hint">Пустой key сохраняет прежний private key только если он уже был создан. В tracked JSON, HTML, JS и AI API logs ключ не записывается.</p>
        <button class="btn secondary" type="submit">Сохранить DeepSeek API key</button>
      </form>
      <form method="post" class="inline-form demand-ai-credentials-clear">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="tab" value="settings">
        <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
        <input type="hidden" name="action" value="clear_ai_api_credentials">
        <?= demand_integration_command_fields('clear_ai_api_credentials') ?>
        <button class="btn secondary small" type="submit">Удалить private DeepSeek key</button>
        <small>Удаляется только private file; env-переменные сервера не меняются.</small>
      </form>
      <form method="post" class="settings-lessor-form">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="tab" value="settings">
        <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
        <input type="hidden" name="action" value="save_ai_api_settings">
        <?= demand_integration_command_fields('save_ai_api_settings') ?>
        <label class="check-row"><input type="checkbox" name="enabled" value="1" <?= !empty($demandAiApiSettings['enabled']) ? 'checked' : '' ?>><span>AI-помощник включён</span></label>
        <div class="metric-card">
          <strong>API key configured: <?= !empty($demandAiApiSettings['apiKeyConfigured']) ? 'да' : 'нет' ?></strong>
          <p class="field-hint">Ключ читается из env или private secrets file. Админка может создать private file, но не показывает сохранённый ключ обратно.</p>
        </div>
        <label>Модель <input name="model" value="<?= e((string) ($demandAiApiSettings['model'] ?? 'deepseek-v4-flash')) ?>"></label>
        <label>Дневной лимит <input type="number" min="0" name="globalDailyLimit" value="<?= e((string) ($demandAiApiSettings['globalDailyLimit'] ?? 100)) ?>"></label>
        <label>Лимит на пользователя в день <input type="number" min="0" name="perUserDailyLimit" value="<?= e((string) ($demandAiApiSettings['perUserDailyLimit'] ?? 30)) ?>"></label>
        <label>Месячный лимит <input type="number" min="0" name="monthlyRequestLimit" value="<?= e((string) ($demandAiApiSettings['monthlyRequestLimit'] ?? 1000)) ?>"></label>
        <label>Timeout, сек <input type="number" min="5" max="120" name="perRequestTimeoutSeconds" value="<?= e((string) ($demandAiApiSettings['perRequestTimeoutSeconds'] ?? 45)) ?>"></label>
        <label>Max context size <input type="number" min="2000" max="200000" name="maxContextSize" value="<?= e((string) ($demandAiApiSettings['maxContextSize'] ?? 35000)) ?>"></label>
        <label>Повторов <input type="number" min="0" max="1" name="retryCount" value="<?= e((string) ($demandAiApiSettings['retryCount'] ?? 0)) ?>"></label>
        <div class="demand-ai-api-status">
          <p><strong>Последний тест:</strong> <?= e((string) ($demandAiApiSettings['lastTestAt'] ?? '')) ?: '—' ?></p>
          <p><strong>Последний успех:</strong> <?= e((string) ($demandAiApiSettings['lastSuccessAt'] ?? '')) ?: '—' ?></p>
          <p><strong>Последняя ошибка:</strong> <?= e((string) ($demandAiApiSettings['lastError'] ?? '')) ?: '—' ?></p>
          <?php if (!empty($demandAiApiSettings['lastErrorTechnical'])): ?>
            <details class="demand-technical-details"><summary>Показать технические детали</summary><pre><?= e((string) $demandAiApiSettings['lastErrorTechnical']) ?></pre></details>
          <?php endif; ?>
        </div>
        <button class="btn" type="submit">Сохранить настройки AI API</button>
      </form>
      <form method="post" class="inline-form">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="tab" value="settings">
        <input type="hidden" name="scope" value="<?= e($scopeFilter) ?>">
        <input type="hidden" name="action" value="openai_test_connection">
        <?= demand_integration_command_fields('openai_test_connection') ?>
        <button class="btn secondary" type="submit">Проверить подключение</button>
      </form>
    <?php endif; ?>
    <?php if (has_permission('demand.ai_api.logs.view')): ?>
      <section class="demand-ai-api-log">
        <h3>Журнал AI API</h3>
        <p class="field-hint">В журнале хранятся только metadata: hash prompt/response, статус, токены и sanitized errors. Полный prompt, ответ и секреты не записываются.</p>
        <p class="field-hint">Сегодня: <?= e((string) ($aiApiLimit['globalUsedToday'] ?? 0)) ?> / <?= e((string) ($aiApiLimit['globalDailyLimit'] ?? 0)) ?>; пользователь: <?= e((string) ($aiApiLimit['perUserUsedToday'] ?? 0)) ?> / <?= e((string) ($aiApiLimit['perUserDailyLimit'] ?? 0)) ?>; месяц: <?= e((string) ($aiApiLimit['monthlyUsed'] ?? 0)) ?> / <?= e((string) ($aiApiLimit['monthlyRequestLimit'] ?? 0)) ?>.</p>
        <div class="table-wrap">
          <table class="report-table">
            <thead><tr><th>Дата</th><th>Задача</th><th>Статус</th><th>Model</th><th>Tokens</th><th>Error</th></tr></thead>
            <tbody>
              <?php foreach (array_slice($aiApiRuns, 0, 12) as $run): ?>
                <?php if (!is_array($run)) { continue; } ?>
                <tr>
                  <td><?= e((string) ($run['createdAt'] ?? '')) ?><small><?= e((string) ($run['id'] ?? '')) ?></small></td>
                  <td><?= e((string) ($run['task'] ?? '')) ?><small><?= e((string) ($run['entityType'] ?? '')) ?> <?= e((string) ($run['entityId'] ?? '')) ?></small></td>
                  <td><span class="status <?= e(demand_admin_status_class((string) ($run['status'] ?? ''))) ?>"><?= e((string) ($run['status'] ?? '')) ?></span></td>
                  <td><?= e((string) ($run['model'] ?? '')) ?></td>
                  <td><?= e((string) (($run['inputTokens'] ?? 0) . ' / ' . ($run['outputTokens'] ?? 0))) ?></td>
                  <td><?= e((string) ($run['sanitizedError'] ?? '')) ?></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$aiApiRuns): ?><tr><td colspan="6">Запусков AI API пока нет.</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </section>
    <?php endif; ?>
  </article>
<?php endif; ?>
<?php endif; ?>

<?php demand_admin_ai_dialog_render_drawer($tab, $scopeFilter, $demandAiDialogState, $demandAiDialogEntityType, $demandAiDialogEntityId, $demandAiApiSettings); ?>

<?php admin_footer(); ?>
