<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
require_permission('cars.manage');

$message = '';
$error = '';

if (isset($_SESSION['admin_flash_message'])) {
    $message = (string) $_SESSION['admin_flash_message'];
    unset($_SESSION['admin_flash_message']);
}
if (isset($_SESSION['admin_flash_error'])) {
    $error = (string) $_SESSION['admin_flash_error'];
    unset($_SESSION['admin_flash_error']);
}

$isScopedLessor = is_lessor_user();
$canManageRentRkShowcase = current_admin_role() === 'admin';
$canManageLessorPublication = current_user_can_manage_lessor_publication_review();
$showLessorPublicationWorkflow = $isScopedLessor || $canManageLessorPublication;
$canModeratePageContent = can_moderate_contour_car_page_content();
$pageContentReviewCount = $canModeratePageContent ? count(contour_page_content_submitted_queue()) : 0;

function car_admin_create_options_by_group(array $options): array
{
    $groups = [];
    foreach ($options as $code => $option) {
        if (!is_array($option) || empty($option['isActive'])) {
            continue;
        }
        $group = trim((string) ($option['group'] ?? ''));
        if ($group === '') {
            $group = 'Другое';
        }
        $groups[$group][$code] = $option;
    }

    return $groups;
}

function car_admin_create_extra_specs_from_post(): array
{
    $keys = $_POST['extraSpecs_key'] ?? [];
    $labels = $_POST['extraSpecs_label'] ?? [];
    $values = $_POST['extraSpecs_value'] ?? [];
    $units = $_POST['extraSpecs_unit'] ?? [];
    $sorts = $_POST['extraSpecs_sort'] ?? [];
    foreach (['keys', 'labels', 'values', 'units', 'sorts'] as $varName) {
        if (!is_array($$varName)) {
            $$varName = [$$varName];
        }
    }

    $rows = [];
    $count = min(20, max(count($keys), count($labels), count($values), count($units), count($sorts)));
    for ($index = 0; $index < $count; $index++) {
        $rows[] = [
            'key' => (string) ($keys[$index] ?? ''),
            'label' => (string) ($labels[$index] ?? ''),
            'value' => (string) ($values[$index] ?? ''),
            'unit' => (string) ($units[$index] ?? ''),
            'sort' => (string) ($sorts[$index] ?? ''),
        ];
    }

    return $rows;
}

function car_detail_tabs_for_ui(): array
{
    return [
        'summary' => 'Сводка',
        'rentals' => 'Аренды и брони',
        'tariffs' => 'Тарифы и залог',
        'service' => 'ТО и сервис',
        'fines' => 'Штрафы и проверки',
        'documents' => 'Документы',
        'publication' => 'Публикация и фото',
        'history' => 'История',
    ];
}

function car_card_plate_html(string $plate): string
{
    $plate = trim($plate);
    if ($plate === '') {
        return e('госномер не указан');
    }
    $compactPlate = preg_replace('/[\s\-]+/u', '', $plate) ?? $plate;
    if (preg_match('/^([A-Za-zА-Яа-яЁё]\d{3}[A-Za-zА-Яа-яЁё]{2})(\d{2,3})$/u', $compactPlate, $matches)) {
        $core = preg_replace_callback('/\d+/', static function (array $match): string {
            return '<span class="car-card-plate-digits">' . e($match[0]) . '</span>';
        }, e($matches[1])) ?? e($matches[1]);
        $region = '<span class="car-card-plate-region"><span class="car-card-plate-digits">' . e($matches[2]) . '</span></span>';
        return $core . $region;
    } else {
        $plate = preg_replace('/\s+/u', ' ', $plate) ?? $plate;
    }

    return preg_replace_callback('/\d+/', static function (array $match): string {
        return '<span class="car-card-plate-digits">' . e($match[0]) . '</span>';
    }, e($plate)) ?? e($plate);
}

function car_detail_normalize_tab(string $tab): string
{
    $tab = strtolower(trim($tab));
    $aliases = [
        'rates' => 'tariffs',
        'rate' => 'tariffs',
        'photos' => 'publication',
        'photo' => 'publication',
        'publishing' => 'publication',
        'archive' => 'history',
        'logs' => 'history',
    ];
    $tab = $aliases[$tab] ?? $tab;

    return array_key_exists($tab, car_detail_tabs_for_ui()) ? $tab : 'summary';
}

function car_detail_tab_url(string $slug, string $tab = 'summary', array $params = []): string
{
    $query = array_merge(['view' => normalize_car_slug($slug), 'tab' => car_detail_normalize_tab($tab)], $params);
    return 'cars.php?' . http_build_query($query);
}

function car_detail_panel_attrs(string $tab, string $activeTab): string
{
    $normalizedTab = car_detail_normalize_tab($tab);
    return ' data-car-detail-panel="' . e($normalizedTab) . '"' . ($normalizedTab !== $activeTab ? ' hidden' : '');
}

function car_detail_return_params(): array
{
    $returnTo = admin_safe_return_to($_GET['return_to'] ?? null, '');
    return $returnTo !== '' ? ['return_to' => $returnTo] : [];
}

function car_admin_is_detail_request(string $slug): bool
{
    return normalize_car_slug((string) ($_GET['view'] ?? '')) === normalize_car_slug($slug);
}

function car_admin_list_redirect_url(string $slug, array $params = []): string
{
    $view = (string) ($_GET['view'] ?? 'cards');
    if (!in_array($view, ['cards', 'table', 'readiness'], true)) {
        $view = 'cards';
    }
    $state = (string) ($_GET['state'] ?? 'active');
    if (!in_array($state, ['active', 'archive'], true)) {
        $state = 'active';
    }
    $query = array_merge(['view' => $view, 'state' => $state], $params);

    return 'cars.php?' . http_build_query($query) . '#' . rawurlencode(normalize_car_slug($slug));
}

function car_admin_after_action_url(string $slug, string $tab, array $params = []): string
{
    if (car_admin_is_detail_request($slug)) {
        return car_detail_tab_url($slug, $tab, array_merge(car_detail_return_params(), $params));
    }

    return car_admin_list_redirect_url($slug, $params);
}

function fleet_readiness_statuses_for_ui(): array
{

    return [
        'ready' => ['label' => 'Готова', 'class' => 'status-free'],
        'attention' => ['label' => 'Требует внимания', 'class' => 'status-reserved'],
        'blocked' => ['label' => 'Не готова', 'class' => 'status-canceled'],
        'busy' => ['label' => 'Занята', 'class' => 'status-busy'],
        'service' => ['label' => 'Сервис', 'class' => 'status-service'],
        'hidden' => ['label' => 'Скрыта / не опубликована', 'class' => 'status-archive'],
        'unknown' => ['label' => 'Нужно проверить', 'class' => 'status-hold'],
    ];
}

function fleet_readiness_filters_for_ui(): array
{
    return [
        'all' => 'Все',
        'ready' => 'Готовы',
        'attention' => 'Требуют внимания',
        'blocked' => 'Не готовы',
        'busy' => 'Заняты',
        'service' => 'Сервис',
        'documents' => 'Документы',
        'tariffs' => 'Тарифы',
        'card' => 'Фото / карточка',
        'publication' => 'Публикация',
        'fines' => 'Штрафы',
    ];
}

function vehicle_center_admin_route_exists(string $route): bool
{
    $route = trim(str_replace('\\', '/', $route), '/');
    if ($route === '' || str_contains($route, '..') || !preg_match('/^[a-z0-9_\/-]+\.php$/i', $route)) {
        return false;
    }

    return is_file(__DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $route));
}

function vehicle_center_queue_href(string $filter, string $fleetState): string
{
    return 'cars.php?' . http_build_query([
        'view' => 'readiness',
        'state' => $fleetState,
        'ready' => $filter,
    ]);
}

function vehicle_center_detail_href(string $slug, string $fleetState, string $tab = 'summary'): string
{
    $params = [
        'view' => normalize_car_slug($slug),
        'return_to' => 'cars.php?view=cards&state=' . $fleetState,
    ];
    if ($tab !== 'summary') {
        $params['tab'] = $tab;
    }

    return 'cars.php?' . http_build_query($params);
}

function vehicle_center_first_reason_label(array $item): string
{
    $reasons = is_array($item['reasons'] ?? null) ? $item['reasons'] : [];
    foreach ($reasons as $reason) {
        if (is_array($reason)) {
            $label = trim((string) ($reason['label'] ?? ''));
            if ($label !== '') {
                return $label;
            }
        }
    }

    return 'По известным признакам машина готова.';
}

function fleet_readiness_reason(string $label, string $severity, string $filter, string $link = ''): array
{
    return [
        'label' => $label,
        'severity' => $severity,
        'filter' => $filter,
        'link' => $link,
    ];
}

function fleet_readiness_date_reason(string $label, string $date, DateTimeImmutable $today, string $filter, string $link = ''): ?array
{
    if ($date === '') {
        return null;
    }
    $parsed = parse_date_value($date);
    if (!$parsed) {
        return fleet_readiness_reason($label . ': дата требует проверки', 'warning', $filter, $link);
    }
    if ($parsed < $today) {
        return fleet_readiness_reason($label . ' просрочен: ' . format_ru_date($date), 'danger', $filter, $link);
    }
    if ($parsed <= $today->modify('+30 days')) {
        return fleet_readiness_reason($label . ' скоро истекает: ' . format_ru_date($date), 'warning', $filter, $link);
    }

    return null;
}

function car_readiness_action_for_reason(array $reason): string
{
    $label = trim((string) ($reason['label'] ?? ''));
    if (str_starts_with($label, 'Сервисный период') || str_starts_with($label, 'РЎРµСЂРІРёСЃРЅС‹Р№ РїРµСЂРёРѕРґ')) {
        return 'service_hold';
    }

    return match ($label) {
        'Не указан госномер' => 'plate',
        'Не указан СТС' => 'sts',
        'Не указан ОСАГО' => 'osago',
        'Не указан VIN' => 'vin',
        'Не указана рыночная стоимость' => 'market_value',
        'ТО просрочено' => 'maintenance',
        default => '',
    };
}

function car_readiness_action_meta(string $action): array
{
    return match ($action) {
        'plate' => [
            'title' => 'Указать госномер',
            'buttonTitle' => 'Исправить: указать госномер',
            'flash' => 'Госномер сохранён.',
            'hint' => 'Введите номер так, как он указан в документах. Для поиска штрафов важны буквы и цифры.',
            'primaryField' => 'license_plate',
        ],
        'sts' => [
            'title' => 'Указать данные СТС',
            'buttonTitle' => 'Исправить: указать СТС',
            'flash' => 'Данные СТС сохранены.',
            'hint' => 'СТС используется для проверки готовности автомобиля и документов.',
            'primaryField' => 'registration_certificate',
        ],
        'osago' => [
            'title' => 'Указать ОСАГО',
            'buttonTitle' => 'Исправить: указать ОСАГО',
            'flash' => 'Данные ОСАГО сохранены.',
            'hint' => 'Если срок ОСАГО истёк или не указан, машина считается требующей внимания.',
            'primaryField' => 'osago_number',
        ],
        'vin' => [
            'title' => 'Указать VIN',
            'buttonTitle' => 'Исправить: указать VIN',
            'flash' => 'VIN сохранён.',
            'hint' => 'VIN подставляется в договор и акты вместе с техническими данными автомобиля.',
            'primaryField' => 'vin',
        ],
        'market_value' => [
            'title' => 'Указать рыночную стоимость',
            'buttonTitle' => 'Исправить: указать рыночную стоимость',
            'flash' => 'Рыночная стоимость сохранена.',
            'hint' => 'Рыночная стоимость подставляется в договор и используется как оценочная стоимость автомобиля.',
            'primaryField' => 'market_value',
        ],
        'maintenance' => [
            'title' => 'ТО просрочено',
            'buttonTitle' => 'Исправить: отметить ТО пройденным',
            'flash' => 'ТО отмечено. Следующее ТО пересчитано.',
            'hint' => 'Если ТО уже выполнено, добавьте запись обслуживания. Это обновит историю и позволит системе пересчитать следующее ТО.',
            'primaryField' => 'service_mileage',
            'submitLabel' => 'Отметить ТО пройденным',
            'nextStep' => 'Отметить ТО пройденным',
        ],
        'service_hold' => [
            'title' => 'Сервисное удержание',
            'buttonTitle' => 'Открыть сервисное удержание',
            'flash' => 'Сервисное удержание обновлено.',
            'hint' => 'Машина временно недоступна из-за сервисного периода. Проверьте детали и верните машину в парк, когда она готова к выдаче.',
            'nextStep' => 'Открыть удержание',
        ],
        default => [],
    };
}

function car_readiness_can_edit_car(array $car): bool
{
    return has_permission('cars.manage') && car_belongs_to_current_scope($car);
}

function car_readiness_can_manage_service_holds(array $car): bool
{
    return !is_lessor_user() && has_permission('calendar.edit') && car_belongs_to_current_scope($car);
}

function car_readiness_modal_key(string $slug, string $action): string
{
    return normalize_car_slug($slug) . '--' . preg_replace('/[^a-z0-9_-]+/', '', $action);
}

function car_readiness_reason_target_tab(array $reason): string
{
    return match ((string) ($reason['filter'] ?? '')) {
        'documents' => 'documents',
        'fines' => 'fines',
        'service' => 'service',
        'publication' => 'publication',
        'card' => 'publication',
        'tariffs' => 'tariffs',
        default => 'summary',
    };
}

function car_readiness_first_actionable_reason(array $readiness): ?array
{
    $rawReasons = $readiness['reasons'] ?? [];
    if (!is_array($rawReasons)) {
        return null;
    }

    $reasons = array_values(array_filter($rawReasons, static fn($reason): bool => is_array($reason)));
    if (!$reasons) {
        return null;
    }

    foreach (['documents', 'service', 'tariffs', 'fines', 'publication', 'card'] as $priorityFilter) {
        foreach ($reasons as $reason) {
            if ((string) ($reason['filter'] ?? '') === $priorityFilter) {
                return $reason;
            }
        }
    }

    return $reasons[0];
}

function car_readiness_next_action_label(array $reason): string
{
    return match (car_readiness_reason_target_tab($reason)) {
        'documents' => 'Проверить документы',
        'fines' => 'Проверить штрафы',
        'service' => 'Открыть ТО и сервис',
        'tariffs' => 'Настроить тарифы',
        'publication' => 'Проверить публикацию и фото',
        default => 'Проверить готовность',
    };
}

function car_detail_next_action_for_ui(string $slug, array $carHub, bool $canEditCar, bool $canManageServiceHolds, array $detailReturnParams, array $carDetailTabs): array
{
    $nextAction = is_array($carHub['nextAction'] ?? null) ? $carHub['nextAction'] : [];
    $href = (string) ($nextAction['href'] ?? '');
    $isServiceHold = $canManageServiceHolds && !empty($carHub['serviceHolds']) && (string) ($nextAction['tone'] ?? '') === 'service';
    $modalKey = '';
    $modalLabel = '';
    $reason = car_readiness_first_actionable_reason(is_array($carHub['readiness'] ?? null) ? $carHub['readiness'] : []);

    if ($reason !== null) {
        $action = car_readiness_action_for_reason($reason);
        $meta = $action !== '' ? car_readiness_action_meta($action) : [];
        $expectedLabel = car_readiness_next_action_label($reason);
        $canUseModal = $action !== ''
            && $canEditCar
            && ($action !== 'service_hold' || $canManageServiceHolds);
        if ($canUseModal && (string) ($nextAction['label'] ?? '') === $expectedLabel) {
            $modalKey = car_readiness_modal_key($slug, $action);
            $modalLabel = (string) ($meta['nextStep'] ?? $meta['title'] ?? $expectedLabel);
        }
    }

    if (str_starts_with($href, '#')) {
        $target = strtolower($href);
        $targetTab = 'summary';
        foreach (array_keys($carDetailTabs) as $candidateTab) {
            if (str_contains($target, (string) $candidateTab)) {
                $targetTab = (string) $candidateTab;
                break;
            }
        }
        $href = car_detail_tab_url($slug, $targetTab, $detailReturnParams);
    }

    return [
        'href' => $href,
        'isServiceHold' => $isServiceHold,
        'modalKey' => $modalKey,
        'modalLabel' => $modalLabel,
    ];
}

function car_readiness_reason_html(array $car, array $reason, bool $canEditCar, array $detailReturnParams = [], string $fallbackHref = '', string $labelOverride = ''): string
{
    $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
    $label = (string) ($reason['label'] ?? 'Проверить');
    $displayLabel = $labelOverride !== '' ? $labelOverride : $label;
    $severity = (string) ($reason['severity'] ?? 'warning');
    $action = car_readiness_action_for_reason($reason);
    $classes = 'fleet-readiness-reason is-' . e($severity);

    if ($action !== '') {
        $canUseAction = $canEditCar && ($action !== 'service_hold' || car_readiness_can_manage_service_holds($car));
        if (!$canUseAction) {
            return '<span class="' . $classes . ' is-readonly" title="Нет прав на редактирование">' . e($displayLabel) . '</span>';
        }
        $meta = car_readiness_action_meta($action);
        return '<button type="button" class="' . $classes . ' car-readiness-action" data-car-readiness-modal-open="' . e(car_readiness_modal_key($slug, $action)) . '" title="' . e((string) ($meta['buttonTitle'] ?? 'Исправить')) . '">' . e($displayLabel) . '</button>';
    }

    $href = (string) ($reason['link'] ?? '');
    if ($href === '' && $fallbackHref !== '') {
        $href = $fallbackHref;
    }
    if ($href === '' && $slug !== '') {
        $href = car_detail_tab_url($slug, car_readiness_reason_target_tab($reason), $detailReturnParams);
    }

    if ($href !== '') {
        return '<a class="' . $classes . '" href="' . e($href) . '">' . e($displayLabel) . '</a>';
    }

    return '<span class="' . $classes . '">' . e($displayLabel) . '</span>';
}

function car_readiness_reason_explanation(array $reason): string
{
    $label = trim((string) ($reason['label'] ?? ''));
    if ($label === 'Не указан госномер') {
        return 'В карточке нет госномера. Без него сложнее сверять документы, штрафы и выдачу.';
    }
    if ($label === 'Не указан СТС') {
        return 'В карточке нет номера СТС. Документы автомобиля не подтверждены для оператора.';
    }
    if ($label === 'Не указан ОСАГО') {
        return 'В карточке нет номера полиса ОСАГО. Машина требует проверки документов перед выдачей.';
    }
    if (str_starts_with($label, 'ОСАГО просрочен')) {
        return 'Срок ОСАГО уже прошёл. Перед выдачей нужен действующий полис.';
    }
    if (str_starts_with($label, 'ОСАГО скоро истекает')) {
        return 'ОСАГО скоро истекает. Нужно проверить, перекрывает ли полис будущую аренду.';
    }
    if (str_starts_with($label, 'Документ/СТС просрочен')) {
        return 'Срок документа/СТС уже прошёл. Перед выдачей нужно обновить документные данные.';
    }
    if (str_starts_with($label, 'Документ/СТС скоро истекает')) {
        return 'Документ/СТС скоро истекает. Оператору нужно проверить актуальность документов.';
    }
    if ($label === 'Не задан базовый тариф') {
        return 'Нет базового тарифа. Машину нельзя корректно рассчитать в заявке или аренде.';
    }
    if ($label === 'Нет главного фото') {
        return 'Нет главного фото. Публикация и подбор машины выглядят неполными.';
    }
    if ($label === 'ТО просрочено') {
        return 'Регламент ТО просрочен. Машину нельзя безопасно выдавать без сервисной проверки.';
    }
    if ($label === 'Скоро ТО') {
        return 'До планового ТО осталось мало пробега. Проверьте, можно ли выдавать машину на будущий период.';
    }
    if (str_starts_with($label, 'Сервисный период')) {
        return 'На машину заведено сервисное удержание. На этот период она недоступна для выдачи.';
    }
    if ($label === 'Сейчас машина в аренде') {
        return 'Машина уже числится в активной аренде и не должна выдаваться повторно.';
    }
    if ($label === 'Просрочен плановый возврат') {
        return 'Плановый возврат просрочен. Сначала нужно закрыть или уточнить текущую аренду.';
    }
    if (str_contains($label, 'активная бронь') || str_contains($label, 'Бронь')) {
        return 'На пересекающийся период уже есть бронь. Проверьте календарь или аренды по машине.';
    }
    if (str_contains($label, 'Публикация')) {
        return 'Публикация требует проверки. Машина может быть скрыта или ожидать решения Rent RK.';
    }
    if (str_contains($label, 'скрыта из публичной витрины')) {
        return 'Машина скрыта из витрины. Для продаж и партнёрских сценариев нужно проверить публикацию.';
    }
    if (str_contains($label, 'штраф')) {
        return 'По машине есть открытые штрафы или проверки. Перед выдачей проверьте риски.';
    }

    return ((string) ($reason['severity'] ?? '') === 'danger')
        ? 'Это блокер готовности. Откройте связанный раздел и устраните причину перед выдачей.'
        : 'Это предупреждение готовности. Проверьте связанный раздел перед выдачей.';
}

function car_readiness_reason_next_step(array $reason): string
{
    $action = car_readiness_action_for_reason($reason);
    $meta = $action !== '' ? car_readiness_action_meta($action) : [];
    if ($meta !== []) {
        return (string) ($meta['nextStep'] ?? $meta['title']);
    }

    return match ((string) ($reason['filter'] ?? '')) {
        'documents' => 'Открыть документы',
        'tariffs' => 'Настроить тарифы',
        'service' => 'Открыть сервис',
        'fines' => 'Открыть штрафы',
        'publication' => 'Проверить публикацию',
        'busy' => 'Открыть аренды/календарь',
        default => 'Открыть связанный раздел',
    };
}

function car_readiness_issue_html(array $car, array $reason, bool $canEditCar, array $detailReturnParams = [], string $fallbackHref = ''): string
{
    $label = (string) ($reason['label'] ?? 'Проверить');
    $severity = (string) ($reason['severity'] ?? 'warning');
    $nextStep = car_readiness_reason_next_step($reason);
    $actionHtml = car_readiness_reason_html($car, $reason, $canEditCar, $detailReturnParams, $fallbackHref, $nextStep);

    return '<div class="fleet-readiness-issue is-' . e($severity) . '">'
        . '<div class="fleet-readiness-issue-copy">'
        . '<strong>' . e($label) . '</strong>'
        . '<p>' . e(car_readiness_reason_explanation($reason)) . '</p>'
        . '</div>'
        . '<div class="fleet-readiness-issue-action">' . $actionHtml . '</div>'
        . '</div>';
}

function car_readiness_panel_title(string $status): string
{
    return match ($status) {
        'ready' => 'Почему машина готова',
        'attention' => 'Что требует внимания',
        'busy' => 'Почему машина занята',
        'service' => 'Почему машина в сервисе',
        'hidden' => 'Почему машина скрыта',
        'blocked' => 'Почему машина не готова',
        default => 'Что известно о готовности',
    };
}

function car_readiness_action_ids_from_reasons(array $reasons): array
{
    $actions = [];
    foreach ($reasons as $reason) {
        if (!is_array($reason)) {
            continue;
        }
        $action = car_readiness_action_for_reason($reason);
        if ($action !== '' && !in_array($action, $actions, true)) {
            $actions[] = $action;
        }
    }

    return $actions;
}

function car_readiness_modal_fields_html(string $action, array $car): string
{
    $documents = normalize_car_document_fields($car);
    if ($action === 'plate') {
        return '<label class="car-readiness-modal-wide">Госномер автомобиля <input data-car-readiness-autofocus data-license-plate-input name="license_plate" value="' . e($documents['licensePlate']) . '" placeholder="А000АА82" required></label>';
    }
    if ($action === 'sts') {
        return '<label class="car-readiness-modal-wide">СТС <input data-car-readiness-autofocus data-sts-input name="registration_certificate" value="' . e($documents['registrationCertificate']) . '" inputmode="numeric" maxlength="11" required></label>';
    }
    if ($action === 'osago') {
        return '<label>ОСАГО № <input data-car-readiness-autofocus name="osago_number" value="' . e($documents['osagoNumber']) . '" required></label>'
            . '<label>ОСАГО действует до <input type="date" name="osago_expires_at" value="' . e($documents['osagoExpiresAt']) . '"></label>';
    }
    if ($action === 'vin') {
        return '<label class="car-readiness-modal-wide">VIN <input data-car-readiness-autofocus name="vin" value="' . e($documents['vin']) . '" maxlength="17" required></label>';
    }
    if ($action === 'market_value') {
        return '<label class="car-readiness-modal-wide">Рыночная стоимость <input data-car-readiness-autofocus name="market_value" value="' . e($documents['marketValue'] === null ? '' : (string) $documents['marketValue']) . '" inputmode="numeric" placeholder="руб." required></label>';
    }

    return '';
}

function car_readiness_service_summary_html(array $car): string
{
    $service = car_service_state($car);
    $remaining = (int) $service['remainingMileage'];
    $overdue = (int) ($service['overdueMileage'] ?? max(0, abs(min(0, $remaining))));
    $nextServiceToneClass = (string) ($service['status'] ?? '') === 'overdue' ? ' is-overdue' : '';

    $rows = [
        'Текущий пробег' => number_format((int) $service['currentMileage'], 0, '', ' ') . ' км',
        'Последнее ТО' => number_format((int) $service['lastServiceMileage'], 0, '', ' ') . ' км',
        'Интервал ТО' => number_format((int) $service['serviceIntervalMileage'], 0, '', ' ') . ' км',
        'Следующее ТО' => number_format((int) $service['nextServiceMileage'], 0, '', ' ') . ' км',
        'Просрочено' => number_format($overdue, 0, '', ' ') . ' км',
    ];

    $html = '<div class="car-readiness-maintenance-summary" aria-label="Текущая картина ТО">';
    foreach ($rows as $label => $value) {
        $html .= '<span><small>' . e($label) . '</small><strong>' . e($value) . '</strong></span>';
    }
    $html .= '</div>';

    return $html;
}

function car_readiness_service_regimen_form_html(array $car, string $formActionUrl): string
{
    $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
    if ($slug === '') {
        return '';
    }

    $service = car_service_state($car);
    $remaining = (int) $service['remainingMileage'];
    $overdue = (int) ($service['overdueMileage'] ?? max(0, abs(min(0, $remaining))));
    $nextServiceToneClass = (string) ($service['status'] ?? '') === 'overdue' ? ' is-overdue' : '';

    return '<form method="post" action="' . e($formActionUrl) . '" class="car-readiness-modal-form car-readiness-regimen-form" data-car-service-regimen-form>'
        . '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">'
        . '<input type="hidden" name="action" value="service_fields">'
        . '<input type="hidden" name="car_slug" value="' . e($slug) . '">' . car_record_version_field($slug)
        . '<input type="hidden" name="service_quick_action" value="maintenance_regimen">'
        . '<input type="hidden" name="next_service_mileage" value="">'
        . '<div class="car-readiness-maintenance-summary is-editable" aria-label="Текущая картина ТО">'
        . '<label class="car-readiness-maintenance-card is-editable"><small>Текущий пробег</small><span class="car-readiness-maintenance-input"><input data-car-readiness-autofocus name="current_mileage" inputmode="numeric" value="' . e((string) $service['currentMileage']) . '" required><b>км</b></span></label>'
        . '<label class="car-readiness-maintenance-card is-editable"><small>Последнее ТО</small><span class="car-readiness-maintenance-input"><input name="last_service_mileage" inputmode="numeric" value="' . e((string) $service['lastServiceMileage']) . '" required><b>км</b></span></label>'
        . '<label class="car-readiness-maintenance-card is-editable"><small>Интервал ТО</small><span class="car-readiness-maintenance-input"><input name="service_interval_mileage" inputmode="numeric" value="' . e((string) $service['serviceIntervalMileage']) . '" required><b>км</b></span></label>'
        . '<span class="car-readiness-maintenance-card' . $nextServiceToneClass . '"><small>Следующее ТО</small><strong data-car-service-next-mileage-text>' . e(number_format((int) $service['nextServiceMileage'], 0, '', ' ') . ' км') . '</strong></span>'
        . '<span class="car-readiness-maintenance-card"><small>Просрочено</small><strong>' . e(number_format($overdue, 0, '', ' ') . ' км') . '</strong></span>'
        . '</div>'
        . '<p class="field-hint">Измените пробег и регламент прямо в карточках. Следующее ТО пересчитается по текущему пробегу и интервалу.</p>'
        . '<div class="car-readiness-modal-actions"><button class="btn secondary" type="submit">Сохранить пробег и регламент</button></div>'
        . '</form>';
}

function car_readiness_maintenance_modal_html(array $car, string $formActionUrl): string
{
    $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
    $meta = car_readiness_action_meta('maintenance');
    if ($slug === '' || $meta === []) {
        return '';
    }

    $service = car_service_state($car);
    $nextServiceToneClass = (string) ($service['status'] ?? '') === 'overdue' ? ' is-overdue' : '';
    $modalKey = car_readiness_modal_key($slug, 'maintenance');
    $titleId = 'car-readiness-title-' . $modalKey;
    $defaultDescription = 'Плановое ТО выполнено.';

    return '<section class="car-readiness-modal is-maintenance" data-car-readiness-modal="' . e($modalKey) . '" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="' . e($titleId) . '">'
        . '<button class="car-readiness-modal-close btn secondary" type="button" data-car-readiness-modal-close aria-label="Закрыть">×</button>'
        . '<div class="car-readiness-modal-head"><h2 id="' . e($titleId) . '">' . e((string) $meta['title']) . '</h2><p class="muted">' . e((string) $meta['hint']) . '</p></div>'
        . car_readiness_service_regimen_form_html($car, $formActionUrl)
        . '<details class="car-readiness-maintenance-details">'
        . '<summary>Изменить пробег и регламент ТО</summary>'
        . '<p class="field-hint">Эти поля меняют ручной регламент машины. Следующее ТО будет пересчитано по текущему пробегу и интервалу; просрочка подсветится красным.</p>'
        . '<form method="post" action="' . e($formActionUrl) . '" class="car-readiness-modal-form" data-car-service-regimen-form>'
        . '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">'
        . '<input type="hidden" name="action" value="service_fields">'
        . '<input type="hidden" name="car_slug" value="' . e($slug) . '">' . car_record_version_field($slug)
        . '<input type="hidden" name="service_quick_action" value="maintenance_regimen">'
        . '<input type="hidden" name="next_service_mileage" value="">'
        . '<div class="car-readiness-modal-grid">'
        . '<label>Текущий пробег <input name="current_mileage" inputmode="numeric" value="' . e((string) $service['currentMileage']) . '" required></label>'
        . '<label>Пробег последнего ТО <input name="last_service_mileage" inputmode="numeric" value="' . e((string) $service['lastServiceMileage']) . '" required></label>'
        . '<label>Интервал ТО <input name="service_interval_mileage" inputmode="numeric" value="' . e((string) $service['serviceIntervalMileage']) . '" required></label>'
        . '<label class="car-readiness-calculated-field' . $nextServiceToneClass . '">Следующее ТО <input data-car-service-next-mileage value="' . e((string) $service['nextServiceMileage']) . '" disabled aria-readonly="true"></label>'
        . '</div>'
        . '<div class="car-readiness-modal-actions"><button class="btn secondary" type="submit">Сохранить регламент</button></div>'
        . '</form>'
        . '</details>'
        . '<form method="post" action="' . e($formActionUrl) . '" class="car-readiness-modal-form">'
        . '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">'
        . '<input type="hidden" name="action" value="service_log">'
        . '<input type="hidden" name="command_id" value="' . e(business_command_form_id()) . '">'
        . '<input type="hidden" name="car_slug" value="' . e($slug) . '">' . car_record_version_field($slug)
        . '<input type="hidden" name="readiness_quick_action" value="maintenance">'
        . '<input type="hidden" name="service_type" value="planned_to">'
        . '<div class="car-readiness-modal-grid">'
        . '<label>Дата ТО <input type="date" name="service_date" value="' . e(date('Y-m-d')) . '" required></label>'
        . '<label>Пробег ТО <input data-car-readiness-autofocus name="service_mileage" inputmode="numeric" value="' . e((string) $service['currentMileage']) . '" required></label>'
        . '<label class="car-readiness-modal-wide">Исполнитель / СТО <input name="service_provider" placeholder="Название сервиса или исполнитель"></label>'
        . '<label class="car-readiness-modal-wide">Описание <textarea name="service_description" rows="2">' . e($defaultDescription) . '</textarea></label>'
        . '<label class="car-readiness-modal-wide">Комментарий <textarea name="service_comment" rows="2" placeholder="Что сделали, номер заказ-наряда или внутренняя заметка"></textarea></label>'
        . '</div>'
        . '<div class="car-readiness-modal-actions"><button class="btn" type="submit">' . e((string) ($meta['submitLabel'] ?? 'Сохранить')) . '</button><button class="btn secondary" type="button" data-car-readiness-modal-close>Отмена</button></div>'
        . '</form>'
        . '<details class="car-readiness-maintenance-details">'
        . '<summary>Обновить только пробег</summary>'
        . '<p class="field-hint">Используйте это, если пробег изменился, но ТО не проходили. Предупреждение о ТО может остаться.</p>'
        . '<form method="post" action="' . e($formActionUrl) . '" class="car-readiness-modal-form">'
        . '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">'
        . '<input type="hidden" name="action" value="service_fields">'
        . '<input type="hidden" name="car_slug" value="' . e($slug) . '">' . car_record_version_field($slug)
        . '<input type="hidden" name="service_quick_action" value="current_mileage">'
        . '<div class="car-readiness-modal-grid"><label class="car-readiness-modal-wide">Текущий пробег <input name="current_mileage" inputmode="numeric" value="' . e((string) $service['currentMileage']) . '" required></label></div>'
        . '<div class="car-readiness-modal-actions"><button class="btn secondary" type="submit">Обновить пробег</button></div>'
        . '</form>'
        . '</details>'
        . '</section>';
}

function car_readiness_service_hold_modal_html(array $car, string $formActionUrl): string
{
    if (!car_readiness_can_manage_service_holds($car)) {
        return '';
    }

    $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
    $holds = active_service_holds($slug);
    if ($slug === '' || !$holds) {
        return '';
    }

    $meta = car_readiness_action_meta('service_hold');
    $service = car_service_state($car);
    $statuses = service_hold_statuses();
    $modalKey = car_readiness_modal_key($slug, 'service_hold');
    $titleId = 'car-readiness-title-' . $modalKey;
    $html = '<section class="car-readiness-modal is-maintenance" data-car-readiness-modal="' . e($modalKey) . '" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="' . e($titleId) . '">'
        . '<button class="car-readiness-modal-close btn secondary" type="button" data-car-readiness-modal-close aria-label="Закрыть">×</button>'
        . '<div class="car-readiness-modal-head"><h2 id="' . e($titleId) . '">' . e((string) ($meta['title'] ?? 'Сервисное удержание')) . '</h2><p class="muted">' . e((string) ($meta['hint'] ?? '')) . '</p></div>';

    foreach ($holds as $hold) {
        $hold = normalize_service_hold_item($hold);
        $holdId = (string) ($hold['id'] ?? '');
        if ($holdId === '') {
            continue;
        }
        $startedDate = substr((string) ($hold['startedAt'] ?? ''), 0, 10);
        $startedTime = substr((string) ($hold['startedAt'] ?? ''), 11, 5) ?: '09:00';
        $startedText = $startedDate !== '' ? format_date_with_time($startedDate, $startedTime) : 'не указано';
        $readyText = (string) ($hold['readyDate'] ?? '') !== '' ? format_ru_date((string) $hold['readyDate']) : 'срок не указан';
        $reasonText = trim((string) (($hold['reason'] ?? '') ?: ($statuses[$hold['status']] ?? $hold['status'] ?? 'service')));
        $checklist = is_array($hold['readyChecklist'] ?? null) ? $hold['readyChecklist'] : [];

        $html .= '<details class="car-readiness-maintenance-details car-service-hold-card" open>'
            . '<summary>' . e($reasonText !== '' ? $reasonText : 'Сервисный период') . '</summary>'
            . '<div class="car-readiness-maintenance-summary car-service-hold-summary" aria-label="Детали сервисного удержания">'
            . '<span><small>Статус</small><strong>' . e($statuses[$hold['status']] ?? (string) $hold['status']) . '</strong></span>'
            . '<span><small>Начало</small><strong>' . e($startedText) . '</strong></span>'
            . '<span><small>Готовность</small><strong>' . e($readyText) . '</strong></span>'
            . '<span><small>Пробег</small><strong>' . e(number_format((int) $service['currentMileage'], 0, '', ' ')) . ' км</strong></span>'
            . '</div>'
            . ((string) ($hold['comment'] ?? '') !== '' ? '<p class="field-hint">' . e((string) $hold['comment']) . '</p>' : '')
            . '<form method="post" action="' . e($formActionUrl) . '" class="car-readiness-modal-form">'
            . '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">'
            . '<input type="hidden" name="action" value="update_car_service_hold">'
            . '<input type="hidden" name="hold_version" value="' . e(business_record_version(SERVICE_HOLDS_FILE, (string) $hold['id'])) . '">'
            . '<input type="hidden" name="car_slug" value="' . e($slug) . '">' . car_record_version_field($slug)
            . '<input type="hidden" name="hold_id" value="' . e($holdId) . '">'
            . '<input type="hidden" name="status" value="ready">'
            . '<div class="car-readiness-modal-grid">'
            . '<label class="car-readiness-modal-wide">Актуальный пробег <input data-car-readiness-autofocus name="current_mileage" inputmode="numeric" value="' . e((string) $service['currentMileage']) . '" required></label>'
            . '<label class="car-readiness-modal-wide">Комментарий <textarea name="comment" rows="2" placeholder="Что проверили перед возвратом в парк">' . e((string) ($hold['comment'] ?? '')) . '</textarea></label>'
            . '</div>'
            . '<div class="car-service-hold-checklist">'
            . '<label class="check-row"><input type="checkbox" name="ready_inspected" value="1" ' . (!empty($checklist['inspected']) ? 'checked ' : '') . 'required><span>Автомобиль осмотрен</span></label>'
            . '<label class="check-row"><input type="checkbox" name="ready_mileage_actual" value="1" ' . (!empty($checklist['mileageActual']) ? 'checked ' : '') . 'required><span>Пробег актуален</span></label>'
            . '<label class="check-row"><input type="checkbox" name="ready_confirmed" value="1" ' . (!empty($checklist['readyConfirmed']) ? 'checked ' : '') . 'required><span>Готов к выдаче</span></label>'
            . '<label class="check-row"><input type="checkbox" name="close_confirmed" value="1" required><span>Снять служебную недоступность с календаря</span></label>'
            . '</div>'
            . '<p class="field-hint">Закрытие удержания вернёт машину в парк и снимет сервисные даты из календаря. Аренды и брони не изменяются автоматически.</p>'
            . '<div class="car-readiness-modal-actions"><button class="btn" type="submit">Вернуть машину в парк</button><button class="btn secondary" type="button" data-car-readiness-modal-close>Отмена</button></div>'
            . '</form>'
            . '</details>';
    }

    return $html . '</section>';
}

function car_readiness_modal_html(array $car, string $action, string $formActionUrl): string
{
    $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
    $meta = car_readiness_action_meta($action);
    if ($slug === '' || $meta === []) {
        return '';
    }
    if ($action === 'maintenance') {
        return car_readiness_maintenance_modal_html($car, $formActionUrl);
    }
    if ($action === 'service_hold') {
        return car_readiness_service_hold_modal_html($car, $formActionUrl);
    }

    $modalKey = car_readiness_modal_key($slug, $action);
    $titleId = 'car-readiness-title-' . $modalKey;

    return '<section class="car-readiness-modal" data-car-readiness-modal="' . e($modalKey) . '" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="' . e($titleId) . '">'
        . '<button class="car-readiness-modal-close btn secondary" type="button" data-car-readiness-modal-close aria-label="Закрыть">×</button>'
        . '<form method="post" action="' . e($formActionUrl) . '" class="car-readiness-modal-form">'
        . '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">'
        . '<input type="hidden" name="action" value="document_fields">'
        . '<input type="hidden" name="car_slug" value="' . e($slug) . '">' . car_record_version_field($slug)
        . '<input type="hidden" name="readiness_quick_action" value="' . e($action) . '">'
        . '<div class="car-readiness-modal-head"><h2 id="' . e($titleId) . '">' . e((string) $meta['title']) . '</h2><p class="muted">' . e((string) $meta['hint']) . '</p></div>'
        . '<div class="car-readiness-modal-grid">' . car_readiness_modal_fields_html($action, $car) . '</div>'
        . '<div class="car-readiness-modal-actions"><button class="btn" type="submit">Сохранить</button><button class="btn secondary" type="button" data-car-readiness-modal-close>Отмена</button></div>'
        . '</form>'
        . '</section>';
}

function car_readiness_modals_html(array $car, array $reasons, string $formActionUrl, array $actionFormUrls = []): string
{
    if (!car_readiness_can_edit_car($car)) {
        return '';
    }

    $html = '';
    foreach (car_readiness_action_ids_from_reasons($reasons) as $action) {
        $html .= car_readiness_modal_html($car, $action, (string) ($actionFormUrls[$action] ?? $formActionUrl));
    }

    return $html;
}

function car_readiness_form_action_url(string $slug, string $view, string $fleetReadinessFilter, array $detailReturnParams = [], string $action = ''): string
{
    if ($view === 'detail') {
        return car_detail_tab_url($slug, in_array($action, ['maintenance', 'service_hold'], true) ? 'service' : 'documents', $detailReturnParams);
    }

    $params = $view === 'readiness' ? ['ready' => $fleetReadinessFilter] : [];

    return car_admin_list_redirect_url($slug, $params);
}

function car_readiness_document_payload(array $car, array $post): array
{
    $current = normalize_car_document_fields($car);

    return [
        'licensePlate' => array_key_exists('license_plate', $post) ? (string) $post['license_plate'] : $current['licensePlate'],
        'vin' => array_key_exists('vin', $post) ? (string) $post['vin'] : $current['vin'],
        'marketValue' => array_key_exists('market_value', $post) ? $post['market_value'] : $current['marketValue'],
        'registrationCertificate' => array_key_exists('registration_certificate', $post) ? (string) $post['registration_certificate'] : $current['registrationCertificate'],
        'osagoNumber' => array_key_exists('osago_number', $post) ? (string) $post['osago_number'] : $current['osagoNumber'],
        'osagoExpiresAt' => array_key_exists('osago_expires_at', $post) ? (string) $post['osago_expires_at'] : $current['osagoExpiresAt'],
        'cascoNumber' => array_key_exists('casco_number', $post) ? (string) $post['casco_number'] : $current['cascoNumber'],
        'cascoExpiresAt' => array_key_exists('casco_expires_at', $post) ? (string) $post['casco_expires_at'] : $current['cascoExpiresAt'],
        'diagnosticCardExpiresAt' => array_key_exists('diagnostic_card_expires_at', $post) ? (string) $post['diagnostic_card_expires_at'] : $current['diagnosticCardExpiresAt'],
        'registrationDocumentExpiresAt' => $current['registrationDocumentExpiresAt'],
    ];
}

function car_readiness_validate_quick_document_payload(string $action, array $fields): void
{
    $documents = normalize_car_document_fields($fields);
    $rawSts = (string) ($fields['registrationCertificate'] ?? '');
    if ($rawSts !== '' && !car_registration_certificate_input_is_valid($rawSts)) {
        throw new RuntimeException('СТС можно вводить цифрами подряд или через пробел/дефис/тире после серии.');
    }
    if ($action === 'plate' && $documents['licensePlate'] === '') {
        throw new RuntimeException('Укажите госномер автомобиля.');
    }
    if ($action === 'sts' && $documents['registrationCertificate'] === '') {
        throw new RuntimeException('Укажите номер СТС.');
    }
    if ($action === 'sts' && car_registration_certificate_digit_count($documents['registrationCertificate']) !== 10) {
        throw new RuntimeException('СТС должен содержать 10 цифр: серия 4 цифры и номер 6 цифр.');
    }
    if ($action === 'osago' && $documents['osagoNumber'] === '') {
        throw new RuntimeException('Укажите номер полиса ОСАГО.');
    }
    if ($action === 'vin' && $documents['vin'] === '') {
        throw new RuntimeException('Укажите VIN автомобиля.');
    }
    if ($action === 'market_value' && (($documents['marketValue'] ?? null) === null || (int) $documents['marketValue'] <= 0)) {
        throw new RuntimeException('Укажите рыночную стоимость автомобиля.');
    }

    foreach (['osagoExpiresAt'] as $field) {
        if (($documents[$field] ?? '') !== '' && !parse_date_value((string) $documents[$field])) {
            throw new RuntimeException('Проверьте дату документа.');
        }
    }
}

function fleet_readiness_rental_uses_car(array $rental, string $slug): bool
{
    if (normalize_car_slug((string) ($rental['carSlug'] ?? $rental['car_slug'] ?? '')) === $slug) {
        return true;
    }
    foreach (($rental['vehicleSegments'] ?? []) as $segment) {
        if (is_array($segment) && normalize_car_slug((string) ($segment['carSlug'] ?? $segment['carId'] ?? '')) === $slug) {
            return true;
        }
    }

    return false;
}

function fleet_readiness_event_label(array $rental, DateTimeImmutable $today): string
{
    $number = format_rental_number($rental);
    $start = (string) ($rental['startDate'] ?? '');
    $end = (string) ($rental['endDate'] ?? '');
    if (rental_is_booking($rental)) {
        return 'Бронь ' . $number . ($start !== '' ? ' с ' . format_ru_date($start) : '');
    }
    if ($end === $today->format('Y-m-d')) {
        return 'Возврат сегодня: ' . $number;
    }
    if ($start === $today->format('Y-m-d')) {
        return 'Выдача сегодня: ' . $number;
    }

    return 'Аренда ' . $number . ($end !== '' ? ' до ' . format_ru_date($end) : '');
}

function fleet_readiness_item_for_ui(array $car, array $rentals, array $fines, DateTimeImmutable $today, bool $canSeePublication, bool $isScopedLessor): array
{
    $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
    $name = trim((string) ($car['name'] ?? ''));
    $documents = normalize_car_document_fields($car);
    $rate = $slug !== '' ? rate_for_car($slug, $car) : default_rate_for_car($car);
    $service = car_service_state($car);
    $reasons = [];
    $events = [];
    $links = [
        ['label' => 'Открыть авто', 'href' => 'cars.php?view=cards&state=active#' . urlencode($slug)],
        ['label' => 'Календарь', 'href' => 'calendar.php?car=' . urlencode($slug)],
    ];

    if (has_permission('rentals.view')) {
        $links[] = ['label' => 'Аренды/брони', 'href' => 'rentals.php?car=' . urlencode($slug)];
    }
    $fineScopeId = car_owner_scope_id($car);
    if ($fineScopeId !== '' && scope_feature_enabled($fineScopeId, 'fines_module_enabled')) {
        $links[] = ['label' => 'Штрафы', 'href' => 'fines.php?car=' . urlencode($slug)];
    }
    if ($canSeePublication || $isScopedLessor) {
        $links[] = ['label' => 'Публикация', 'href' => 'cars.php?view=cards&state=active#' . urlencode($slug)];
    }

    $documentLink = 'cars.php?view=cards&state=active#' . urlencode($slug);
    if ($documents['licensePlate'] === '') {
        $reasons[] = fleet_readiness_reason('Не указан госномер', 'danger', 'documents', $documentLink);
    }
    if ($documents['registrationCertificate'] === '') {
        $reasons[] = fleet_readiness_reason('Не указан СТС', 'danger', 'documents', $documentLink);
    }
    if ($documents['vin'] === '') {
        $reasons[] = fleet_readiness_reason('Не указан VIN', 'danger', 'documents', $documentLink);
    }
    if (($documents['marketValue'] ?? null) === null || (int) $documents['marketValue'] <= 0) {
        $reasons[] = fleet_readiness_reason('Не указана рыночная стоимость', 'danger', 'documents', $documentLink);
    }
    if ($documents['osagoNumber'] === '') {
        $reasons[] = fleet_readiness_reason('Не указан ОСАГО', 'warning', 'documents', $documentLink);
    }
    foreach ([
        'osagoExpiresAt' => 'ОСАГО',
        'cascoExpiresAt' => 'КАСКО',
        'diagnosticCardExpiresAt' => 'Диагностическая карта',
    ] as $field => $label) {
        $reason = fleet_readiness_date_reason($label, (string) ($documents[$field] ?? ''), $today, 'documents', $documentLink);
        if ($reason !== null) {
            $reasons[] = $reason;
        }
    }

    $basePrice = normalize_rate_price($rate['manual'] ?? null)
        ?? normalize_rate_price($rate['base'] ?? null)
        ?? normalize_rate_price($car['price'] ?? null);
    if ($basePrice === null || $basePrice <= 0) {
        $rateReasonLink = current_user_can_view_tariffs(car_owner_scope_id($car)) ? 'rates.php#' . urlencode($slug) : '';
        $reasons[] = fleet_readiness_reason('Не задан базовый тариф', 'warning', 'tariffs', $rateReasonLink);
    }
    $deposit = car_deposit_amount($slug, $car);
    if ($deposit === null || $deposit <= 0) {
        $rateReasonLink = current_user_can_view_tariffs(car_owner_scope_id($car)) ? 'rates.php#' . urlencode($slug) : '';
        $reasons[] = fleet_readiness_reason('Не задан залог', 'warning', 'tariffs', $rateReasonLink);
    }

    $image = trim((string) ($car['image'] ?? ''));
    if ($image === '' && count(car_photos($car)) === 0) {
        $reasons[] = fleet_readiness_reason('Нет главного фото', 'warning', 'card', $documentLink);
    }

    if ($canSeePublication) {
        $publication = car_publication_summary($car);
        if (!$publication['isPublicVisible']) {
            $reasons[] = fleet_readiness_reason('Машина скрыта из публичной витрины', 'warning', 'publication', $documentLink);
        }
        if (!$publication['publishChannels']) {
            $reasons[] = fleet_readiness_reason('Не выбран канал публикации', 'warning', 'publication', $documentLink);
        }
    } elseif ($isScopedLessor && car_owner_type($car) === 'lessor') {
        $lessorPublication = lessor_publication_readiness_summary($car);
        if ($lessorPublication['status'] !== 'approved') {
            $reasons[] = fleet_readiness_reason('Публикация требует проверки Rent RK: ' . $lessorPublication['label'], 'warning', 'publication', $documentLink);
        }
        foreach ($lessorPublication['blockers'] as $blocker) {
            $reasons[] = fleet_readiness_reason((string) $blocker, 'danger', 'publication', $documentLink);
        }
    }

    if ($service['status'] === 'overdue') {
        $reasons[] = fleet_readiness_reason('ТО просрочено', 'danger', 'service', 'service-holds.php?car=' . urlencode($slug));
    } elseif ($service['status'] === 'soon') {
        $reasons[] = fleet_readiness_reason('Скоро ТО', 'warning', 'service', 'service-holds.php?car=' . urlencode($slug));
    }

    foreach (active_service_holds($slug) as $hold) {
        $label = 'Сервисный период';
        if ((string) ($hold['readyDate'] ?? '') !== '') {
            $label .= ' до ' . format_ru_date((string) $hold['readyDate']);
        }
        $reasons[] = fleet_readiness_reason($label, 'danger', 'service', 'service-holds.php#hold-' . urlencode((string) ($hold['id'] ?? '')));
        $events[] = $label;
    }

    $now = new DateTimeImmutable('now');
    $tomorrow = $today->modify('+1 day')->format('Y-m-d');
    foreach ($rentals as $rawRental) {
        $rental = normalize_rental_item(is_array($rawRental) ? $rawRental : []);
        if ($slug === '' || !fleet_readiness_rental_uses_car($rental, $slug) || !rental_blocks_availability($rental)) {
            continue;
        }
        $bounds = rental_period_bounds($rental);
        if (!$bounds) {
            continue;
        }
        [$startAt, $endAt] = $bounds;
        $id = (string) ($rental['id'] ?? '');
        $rentalLink = $id !== '' ? 'rentals.php?edit=' . urlencode($id) : 'rentals.php?car=' . urlencode($slug);
        $startDate = (string) ($rental['startDate'] ?? '');
        $endDate = (string) ($rental['endDate'] ?? '');
        $isReturned = (string) ($rental['returnStatus'] ?? '') === 'returned';

        if ($startAt <= $now && $endAt >= $now && !$isReturned) {
            $label = rental_is_booking($rental) ? 'На выбранные даты есть активная бронь' : 'Сейчас машина в аренде';
            $reasons[] = fleet_readiness_reason($label, 'warning', 'busy', $rentalLink);
            $events[] = fleet_readiness_event_label($rental, $today);
        } elseif (!$isReturned && !rental_is_booking($rental) && $endAt < $now) {
            $reasons[] = fleet_readiness_reason('Просрочен плановый возврат', 'danger', 'busy', $rentalLink);
            $events[] = 'Просрочен возврат: ' . format_rental_number($rental);
        } elseif (!$isReturned && $startDate === $today->format('Y-m-d')) {
            $reasons[] = fleet_readiness_reason(rental_is_booking($rental) ? 'Бронь на сегодня' : 'Выдача сегодня', 'warning', 'busy', $rentalLink);
            $events[] = fleet_readiness_event_label($rental, $today);
        } elseif (!$isReturned && $endDate === $today->format('Y-m-d')) {
            $reasons[] = fleet_readiness_reason('Возврат сегодня', 'warning', 'busy', $rentalLink);
            $events[] = fleet_readiness_event_label($rental, $today);
        } elseif (!$isReturned && ($startDate === $tomorrow || $endDate === $tomorrow)) {
            $events[] = 'Ближайшее событие завтра: ' . format_rental_number($rental);
        }
    }

    $openFineCount = 0;
    foreach ($fines as $fine) {
        if (normalize_car_slug((string) ($fine['car_slug'] ?? $fine['carSlug'] ?? '')) !== $slug) {
            continue;
        }
        $status = (string) ($fine['status'] ?? '');
        if ($status === 'unlinked' || $status === 'disputed' || in_array($status, fine_open_statuses(), true)) {
            $openFineCount++;
        }
    }
    if ($openFineCount > 0) {
        $reasons[] = fleet_readiness_reason('Есть штрафы к решению: ' . $openFineCount, 'warning', 'fines', 'fines.php?car=' . urlencode($slug));
    }

    $hasDanger = (bool) array_filter($reasons, static fn(array $reason): bool => $reason['severity'] === 'danger');
    $hasWarning = (bool) array_filter($reasons, static fn(array $reason): bool => $reason['severity'] === 'warning');
    $hasBusy = (bool) array_filter($reasons, static fn(array $reason): bool => $reason['filter'] === 'busy');
    $hasService = (bool) array_filter($reasons, static fn(array $reason): bool => $reason['filter'] === 'service' && $reason['severity'] === 'danger');
    $hasPublication = (bool) array_filter($reasons, static fn(array $reason): bool => $reason['filter'] === 'publication');

    $status = 'ready';
    if ($slug === '') {
        $status = 'unknown';
    } elseif ($hasService) {
        $status = 'service';
    } elseif ($hasBusy) {
        $status = 'busy';
    } elseif ($hasDanger) {
        $status = 'blocked';
    } elseif ($hasPublication) {
        $status = 'hidden';
    } elseif ($hasWarning) {
        $status = 'attention';
    }

    return [
        'car' => $car,
        'slug' => $slug,
        'name' => $name !== '' ? $name : $slug,
        'plate' => (string) ($documents['licensePlate'] ?? ''),
        'owner' => scope_display_name(car_owner_scope_id($car)),
        'image' => $image,
        'status' => $status,
        'reasons' => $reasons,
        'events' => array_values(array_unique(array_filter($events))),
        'links' => $links,
    ];
}

function fleet_readiness_matches_filter(array $item, string $filter): bool
{
    if ($filter === 'all') {
        return true;
    }
    if ($item['status'] === $filter) {
        return true;
    }
    foreach ($item['reasons'] as $reason) {
        if (($reason['filter'] ?? '') === $filter) {
            return true;
        }
    }

    return false;
}

function car_hub_datetime_from_rental(array $rental, string $fallbackDateKey, string $fallbackTimeKey): ?DateTimeImmutable
{
    $bounds = rental_period_bounds($rental);
    if ($bounds) {
        return $fallbackDateKey === 'endDate' ? $bounds[1] : $bounds[0];
    }
    $date = (string) ($rental[$fallbackDateKey] ?? '');
    if ($date === '') {
        return null;
    }
    $parsed = parse_date_value($date);
    if (!$parsed) {
        return null;
    }

    return make_datetime_value($parsed, parse_time_value((string) ($rental[$fallbackTimeKey] ?? '')));
}

function car_hub_rental_row(array $rental, bool $canSeeFinance): array
{
    $rental = normalize_rental_item($rental);
    $isArchive = !empty($rental['isArchive']) || !empty($rental['isHistorical']);
    $statusLabel = rental_booking_status_label($rental);
    $snapshot = $isArchive ? archive_rental_finance_snapshot($rental) : ['enabled' => false];
    $amount = null;
    $paid = null;
    if ($canSeeFinance) {
        if (!empty($snapshot['enabled'])) {
            $amount = (int) ($snapshot['totalAmount'] ?? 0);
            $paid = (int) ($snapshot['paidAmount'] ?? 0);
        } else {
            $amount = normalize_rate_price($rental['rentalCost'] ?? null) ?? 0;
            $paid = normalize_rate_price($rental['amountPaid'] ?? null) ?? 0;
        }
    }

    return [
        'id' => (string) ($rental['id'] ?? ''),
        'number' => format_rental_number($rental),
        'period' => rental_period_text($rental),
        'client' => trim((string) (($rental['clientName'] ?? '') ?: ($rental['customerName'] ?? '') ?: ($rental['name'] ?? ''))),
        'status' => $statusLabel,
        'isArchive' => $isArchive,
        'amount' => $amount,
        'paid' => $paid,
        'href' => 'rentals.php?edit=' . urlencode((string) ($rental['id'] ?? '')),
        'startAt' => car_hub_datetime_from_rental($rental, 'startDate', 'startTime'),
        'endAt' => car_hub_datetime_from_rental($rental, 'endDate', 'endTime'),
    ];
}

function car_hub_tariff_model_for_ui(string $slug, array $car, bool $canEditRates): array
{
    $rate = $slug !== '' ? rate_for_car($slug, $car) : default_rate_for_car($car);
    $fields = rate_fields();
    $mileagePolicy = car_mileage_policy($car);
    $defaultDeposit = default_deposit_amount();
    $carDeposit = normalize_rate_price($rate['depositAmount'] ?? null);
    $effectiveDeposit = $carDeposit ?? $defaultDeposit;
    $settings = read_rates()['settings'] ?? rate_rules();

    $priceKeys = ['manual', 'base', 'from3', 'from7', 'from14', 'highSeason', 'lowSeason', 'holiday', 'hourly'];
    $prices = [];
    foreach ($priceKeys as $key) {
        $value = normalize_rate_price($rate[$key] ?? null);
        if ($value === null) {
            continue;
        }
        $prices[] = [
            'key' => $key,
            'label' => (string) ($fields[$key] ?? $key),
            'amount' => $value,
            'note' => match ($key) {
                'manual' => 'Перекрывает остальные тарифы при расчёте.',
                'base' => 'Базовая цена за сутки.',
                'from3' => 'Применяется от 3 суток.',
                'from7' => 'Применяется от 7 суток.',
                'from14' => 'Применяется от 14 суток.',
                'highSeason' => 'Для месяцев высокого сезона.',
                'lowSeason' => 'Для месяцев низкого сезона.',
                'holiday' => 'Для праздничных дат.',
                'hourly' => !empty($car['hourlyAvailable']) ? 'Почасовая аренда включена.' : 'Почасовая аренда выключена для этой машины.',
                default => '',
            },
        ];
    }

    $primary = normalize_rate_price($rate['manual'] ?? null)
        ?? normalize_rate_price($rate['base'] ?? null)
        ?? normalize_rate_price($car['price'] ?? null);
    $warnings = [];
    if ((normalize_rate_price($rate['base'] ?? null) ?? 0) <= 0) {
        $warnings[] = 'Базовая цена не заполнена.';
    }
    if ($effectiveDeposit === null) {
        $warnings[] = 'Залог не задан ни для автомобиля, ни по умолчанию.';
    } elseif ($carDeposit === null) {
        $warnings[] = 'Индивидуальный залог не задан, используется общий залог по умолчанию.';
    }
    if (normalize_rate_price($rate['hourly'] ?? null) !== null && empty($car['hourlyAvailable'])) {
        $warnings[] = 'Почасовой тариф указан, но почасовая аренда выключена.';
    }

    $conditions = [];
    $highSeasonMonths = array_map('intval', (array) ($settings['highSeasonMonths'] ?? []));
    $lowSeasonMonths = array_map('intval', (array) ($settings['lowSeasonMonths'] ?? []));
    if ($highSeasonMonths) {
        $conditions[] = 'Высокий сезон: месяцы ' . implode(', ', $highSeasonMonths) . '.';
    }
    if ($lowSeasonMonths) {
        $conditions[] = 'Низкий сезон: месяцы ' . implode(', ', $lowSeasonMonths) . '.';
    }
    $holidayCount = count((array) ($settings['holidayDates'] ?? []));
    if ($holidayCount > 0) {
        $conditions[] = 'Праздничных дат в правилах: ' . $holidayCount . '.';
    }
    $conditions[] = 'Приоритет расчёта: индивидуальная цена, праздники, срок аренды, сезон, базовая цена.';

    return [
        'primaryPrice' => $primary,
        'prices' => $prices,
        'deposit' => $effectiveDeposit,
        'depositSource' => $carDeposit === null ? 'default' : 'car',
        'mileageLimitPerDay' => (int) $mileagePolicy['mileageLimitPerDay'],
        'extraMileageRate' => $mileagePolicy['extraMileageRate'],
        'hourlyAvailable' => !empty($car['hourlyAvailable']),
        'conditions' => $conditions,
        'warnings' => $warnings,
        'updatedAt' => (string) ($rate['updatedAt'] ?? ''),
        'editUrl' => $canEditRates ? 'rates.php#' . urlencode($slug) : '',
    ];
}

function car_hub_model_for_ui(array $car, array $scopedRentals, DateTimeImmutable $today, bool $canSeePublication, bool $isScopedLessor): array
{
    $slug = normalize_car_slug((string) ($car['slug'] ?? ''));
    $documents = normalize_car_document_fields($car);
    $fineSummary = has_permission('fines.view') ? fine_summary_for_car($slug) : fine_empty_summary();
    $service = car_service_state($car);
    $publication = car_publication_summary($car);
    $readiness = fleet_readiness_item_for_ui($car, $scopedRentals, scoped_fines_for_current_user(), $today, $canSeePublication, $isScopedLessor);
    $canSeeFinance = has_permission('finance.view') && !$isScopedLessor;
    $archiveStats = $canSeeFinance ? archive_rental_car_finance_stats($slug) : null;

    $now = new DateTimeImmutable('now', new DateTimeZone(APP_TIMEZONE));
    $rentalRows = ['active' => [], 'future' => [], 'recent' => [], 'archive' => []];
    foreach ($scopedRentals as $rawRental) {
        $rental = normalize_rental_item(is_array($rawRental) ? $rawRental : []);
        if ($slug === '' || !fleet_readiness_rental_uses_car($rental, $slug)) {
            continue;
        }
        $row = car_hub_rental_row($rental, $canSeeFinance);
        $isArchive = !empty($row['isArchive']);
        $isReturned = (string) ($rental['returnStatus'] ?? '') === 'returned' || (string) ($rental['status'] ?? '') === 'closed';
        $startAt = $row['startAt'];
        $endAt = $row['endAt'];

        if ($isArchive) {
            $rentalRows['archive'][] = $row;
        } elseif (!$isReturned && $startAt && $endAt && $startAt <= $now && $endAt >= $now) {
            $rentalRows['active'][] = $row;
        } elseif (!$isReturned && $startAt && $startAt >= $now) {
            $rentalRows['future'][] = $row;
        } elseif ($isReturned) {
            $rentalRows['recent'][] = $row;
        }
    }
    usort($rentalRows['future'], static fn(array $a, array $b): int => ($a['startAt']?->getTimestamp() ?? 0) <=> ($b['startAt']?->getTimestamp() ?? 0));
    usort($rentalRows['recent'], static fn(array $a, array $b): int => ($b['endAt']?->getTimestamp() ?? 0) <=> ($a['endAt']?->getTimestamp() ?? 0));
    usort($rentalRows['archive'], static fn(array $a, array $b): int => ($b['endAt']?->getTimestamp() ?? 0) <=> ($a['endAt']?->getTimestamp() ?? 0));
    $rentalRows['future'] = array_slice($rentalRows['future'], 0, 4);
    $rentalRows['recent'] = array_slice($rentalRows['recent'], 0, 4);
    $rentalRows['archive'] = array_slice($rentalRows['archive'], 0, 4);

    $serviceHolds = active_service_holds($slug);
    $nextAction = ['label' => 'Машина готова к работе', 'href' => '', 'tone' => 'ok'];
    if ($rentalRows['active']) {
        $nextAction = ['label' => 'Открыть текущую аренду', 'href' => (string) $rentalRows['active'][0]['href'], 'tone' => 'busy'];
    } elseif ($rentalRows['future']) {
        $nextAction = ['label' => rental_is_booking(['id' => $rentalRows['future'][0]['id']]) ? 'Открыть ближайшую бронь' : 'Открыть ближайшую аренду', 'href' => (string) $rentalRows['future'][0]['href'], 'tone' => 'busy'];
    } elseif ($serviceHolds) {
        $nextAction = ['label' => 'Открыть сервисное удержание', 'href' => 'service-holds.php#hold-' . urlencode((string) ($serviceHolds[0]['id'] ?? '')), 'tone' => 'service'];
    } elseif ((int) ($fineSummary['openCount'] ?? 0) > 0 || (int) ($fineSummary['unlinkedCount'] ?? 0) > 0) {
        $nextAction = ['label' => 'Проверить штрафы', 'href' => 'fines.php?car=' . urlencode($slug), 'tone' => 'warning'];
    } elseif (!$publication['isPublicVisible'] && $canSeePublication) {
        $nextAction = ['label' => 'Проверить публикацию', 'href' => '#' . $slug . '-publication', 'tone' => 'warning'];
    } elseif (($readiness['status'] ?? '') !== 'ready') {
        $readinessReason = car_readiness_first_actionable_reason($readiness);
        $readinessTab = $readinessReason ? car_readiness_reason_target_tab($readinessReason) : 'summary';
        $nextAction = [
            'label' => $readinessReason ? car_readiness_next_action_label($readinessReason) : 'Проверить готовность',
            'href' => '#' . $slug . '-' . $readinessTab,
            'tone' => 'warning',
        ];
    }

    return [
        'slug' => $slug,
        'plate' => (string) ($documents['licensePlate'] ?? ''),
        'readiness' => $readiness,
        'publication' => $publication,
        'service' => $service,
        'serviceHolds' => $serviceHolds,
        'fineSummary' => $fineSummary,
        'rentals' => $rentalRows,
        'archiveStats' => $archiveStats,
        'nextAction' => $nextAction,
        'canSeeArchiveFinance' => $canSeeFinance,
        'links' => [
            'calendar' => admin_calendar_url(['page' => 'car', 'car' => $slug]),
            'fleetCalendar' => admin_calendar_url(['page' => 'fleet', 'car' => $slug]),
            'finesWizard' => 'fines.php?' . http_build_query(['wizard' => 1, 'quick_car_slug' => $slug, 'return_to' => 'cars.php?view=cards#' . $slug]),
            'serviceHold' => 'service-holds.php?car=' . urlencode($slug),
            'rentals' => 'rentals.php?car=' . urlencode($slug),
            'archiveRentals' => 'rentals.php?car=' . urlencode($slug) . '&archive=1',
            'rates' => current_user_can_view_tariffs(car_owner_scope_id($car)) ? 'rates.php#' . urlencode($slug) : '',
        ],
    ];
}

function car_record_version_field(string $slug): string
{
    $version = $_SERVER['REQUEST_METHOD'] === 'POST' && (string) ($_POST['car_slug'] ?? '') === $slug
        ? (is_string($_POST['expected_version'] ?? null) ? $_POST['expected_version'] : '')
        : business_record_version(CARS_FILE, $slug, 'slug');
    return '<input type="hidden" name="expected_version" value="' . e($version) . '">';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');
    $slug = (string) ($_POST['car_slug'] ?? '');

    try {
        if (in_array($action, ['service_fields', 'usage_fields', 'document_fields', 'showcase_fields', 'publication_fields', 'update_car_service_hold', 'lessor_public_submit', 'lessor_public_review'], true)) {
            require_car_scope($slug);
            if (!is_string($_POST['expected_version'] ?? null) || !hash_equals(business_record_version(CARS_FILE, $slug, 'slug'), $_POST['expected_version'])) {
                throw new RuntimeException('Карточка изменена после открытия формы. Обновите страницу.', 409);
            }
        }
        if ($action === 'create_car') {
            $actorScope = current_user_data_scope_id();
            $assignedLessor = $actorScope !== '' ? admin_user_lessor_slug(current_admin_record() ?? []) : '';
            if ($actorScope !== '' && (array_key_exists('lessor_slug', $_POST)
                && (!is_string($_POST['lessor_slug']) || normalize_lessor_slug($_POST['lessor_slug']) !== $assignedLessor))) {
                deny_scope_access();
            }
            $lessorSlug = $actorScope !== '' ? $assignedLessor : normalize_lessor_slug((string) ($_POST['lessor_slug'] ?? ''));
            if (is_lessor_user() && $lessorSlug === '') {
                deny_scope_access();
            }
            $mainPhotoUpload = $_FILES['main_photo'] ?? [];
            $hasMainPhotoUpload = is_array($mainPhotoUpload) && uploaded_car_photo_present($mainPhotoUpload);
            if ($hasMainPhotoUpload) {
                validate_uploaded_car_photo(normalize_single_uploaded_file($mainPhotoUpload));
            }
            $car = create_car_item([
                'name' => (string) ($_POST['name'] ?? ''),
                'slug' => (string) ($_POST['slug'] ?? ''),
                'class' => (string) ($_POST['class'] ?? ''),
                'brand' => (string) ($_POST['brand'] ?? ''),
                'model' => (string) ($_POST['model'] ?? ''),
                'year' => $_POST['year'] ?? null,
                'generation' => (string) ($_POST['generation'] ?? ''),
                'trim' => (string) ($_POST['trim'] ?? ''),
                'bodyType' => (string) ($_POST['bodyType'] ?? ''),
                'seats' => $_POST['seats'] ?? 5,
                'drive' => (string) ($_POST['drive'] ?? ''),
                'transmission' => (string) ($_POST['transmission'] ?? ''),
                'engine' => (string) ($_POST['engine'] ?? ''),
                'fuelType' => (string) ($_POST['fuelType'] ?? ''),
                'color' => (string) ($_POST['color'] ?? ''),
                'doors' => $_POST['doors'] ?? null,
                'enginePowerHp' => $_POST['enginePowerHp'] ?? null,
                'engineDisplacementL' => $_POST['engineDisplacementL'] ?? null,
                'electricRangeKm' => $_POST['electricRangeKm'] ?? null,
                'equipment' => $_POST['equipment'] ?? [],
                'extraSpecs' => car_admin_create_extra_specs_from_post(),
                'vin' => (string) ($_POST['vin'] ?? ''),
                'marketValue' => $_POST['market_value'] ?? null,
                'price' => $_POST['price'] ?? null,
                'image' => (string) ($_POST['image'] ?? ''),
                'hourlyAvailable' => !empty($_POST['hourly_available']),
                'available_for_rent_rk_partners' => $canManageRentRkShowcase ? !empty($_POST['available_for_rent_rk_partners']) : true,
                'mileageLimitPerDay' => $_POST['mileage_limit_per_day'] ?? null,
                'extraMileageRate' => $_POST['extra_mileage_rate'] ?? null,
                'ownershipType' => (string) ($_POST['ownership_type'] ?? 'own'),
                'ownerName' => (string) ($_POST['owner_name'] ?? ''),
                'ownerCommissionType' => (string) ($_POST['owner_commission_type'] ?? 'rent_rk_percent'),
                'ownerCommissionValue' => $_POST['owner_commission_value'] ?? null,
                'licensePlate' => (string) ($_POST['license_plate'] ?? ''),
                'registrationCertificate' => (string) ($_POST['registration_certificate'] ?? ''),
                'osagoNumber' => (string) ($_POST['osago_number'] ?? ''),
                'osagoExpiresAt' => (string) ($_POST['osago_expires_at'] ?? ''),
                'cascoNumber' => (string) ($_POST['casco_number'] ?? ''),
                'cascoExpiresAt' => (string) ($_POST['casco_expires_at'] ?? ''),
                'diagnosticCardExpiresAt' => (string) ($_POST['diagnostic_card_expires_at'] ?? ''),
                'lessorSlug' => $lessorSlug,
            ]);
            $createdSlug = (string) $car['slug'];
            if ($hasMainPhotoUpload) {
                try {
                    upload_car_main_photo($createdSlug, $mainPhotoUpload);
                    $_SESSION['admin_flash_message'] = 'Автомобиль добавлен, главное фото загружено.';
                    redirect_to(car_detail_tab_url($createdSlug, 'publication'));
                } catch (Throwable $photoException) {
                    $_SESSION['admin_flash_error'] = 'Автомобиль сохранён, но фото не загружено. ' . $photoException->getMessage();
                    redirect_to(car_detail_tab_url($createdSlug, 'publication'));
                }
            }
            $_SESSION['admin_flash_message'] = 'Автомобиль добавлен. Папка для фотографий создана в assets/img/cars/.';
            redirect_to(car_detail_tab_url($createdSlug, 'summary'));
        }

        if ($action === 'archive_car') {
            require_car_scope($slug);
            archive_car_item($slug, (string) ($_POST['archive_reason'] ?? ''));
            $rebuild = PhpPublicationAutomation::enabled() ? null : rebuild_public_site_result();
            $_SESSION['admin_flash_message'] = $rebuild === null ? PhpPublicationAutomation::message($slug) : (($rebuild['success'] && empty($rebuild['skipped']))
                ? 'Автомобиль архивирован и скрыт из витрины, публичный сайт пересобран.'
                : 'Автомобиль архивирован и скрыт из витрины, но публичный сайт не пересобран. Ошибка: ' . $rebuild['error']);
            redirect_to(car_admin_is_detail_request($slug)
                ? car_detail_tab_url($slug, 'history', array_merge(car_detail_return_params(), ['state' => 'archive']))
                : car_admin_list_redirect_url($slug, ['state' => 'archive']));
        }

        if ($action === 'restore_car') {
            require_car_scope($slug);
            restore_car_item($slug);
            if (PhpPublicationAutomation::enabled()) {
                $_SESSION['admin_flash_message'] = 'Сохранено. Для возврата на витрину требуется разрешённая публикация.';
                redirect_to(car_detail_tab_url($slug, 'history'));
            }
            $rebuild = rebuild_public_site_result();
            $_SESSION['admin_flash_message'] = ($rebuild['success'] && empty($rebuild['skipped']))
                ? 'Автомобиль восстановлен из архива, публичный сайт пересобран.'
                : 'Автомобиль восстановлен из архива, но публичный сайт не пересобран. Ошибка: ' . $rebuild['error'];
            redirect_to(car_admin_is_detail_request($slug)
                ? car_detail_tab_url($slug, 'history', array_merge(car_detail_return_params(), ['state' => 'active']))
                : car_admin_list_redirect_url($slug, ['state' => 'active']));
        }

        if ($action === 'delete_car') {
            if (current_admin_role() !== 'admin') {
                deny_scope_access();
            }
            require_car_scope($slug);
            delete_car_item($slug);
            $rebuild = PhpPublicationAutomation::enabled() ? null : rebuild_public_site_result();
            $_SESSION['admin_flash_message'] = $rebuild === null ? PhpPublicationAutomation::message($slug) : (($rebuild['success'] && empty($rebuild['skipped']))
                ? 'Автомобиль физически удалён, публичный сайт пересобран.'
                : 'Автомобиль физически удалён, но публичный сайт не пересобран. Ошибка: ' . $rebuild['error']);
            redirect_to('cars.php?view=' . urlencode((string) ($_GET['view'] ?? 'cards')) . '&state=archive');
        }

        if ($action === 'car_main_photo_upload') {
            require_car_scope($slug);
            upload_car_main_photo($slug, $_FILES['main_photo'] ?? []);
            if (PhpPublicationAutomation::enabled()) {
                $_SESSION['admin_flash_message'] = 'Сохранено. Для публикации нового главного фото требуется одобрение.';
                redirect_to(car_admin_after_action_url($slug, 'publication'));
            }
            $rebuild = rebuild_public_site_result();
            $_SESSION['admin_flash_message'] = ($rebuild['success'] && empty($rebuild['skipped']))
                ? 'Главное фото автомобиля обновлено, публичный сайт пересобран.'
                : 'Главное фото автомобиля обновлено, но публичный сайт не пересобран. Ошибка: ' . $rebuild['error'];
            redirect_to(car_admin_after_action_url($slug, 'publication'));
        }

        if ($action === 'car_photo_upload') {
            require_car_scope($slug);
            $result = upload_car_photos($slug, $_FILES['photos'] ?? []);
            if (!$result['uploaded']) {
                throw new RuntimeException($result['errors'] ? implode("\n", $result['errors']) : 'Фото не загружены.');
            }
            if (PhpPublicationAutomation::enabled()) {
                $_SESSION['admin_flash_message'] = 'Сохранено. Для публикации новых фото требуется одобрение.';
                if ($result['errors']) $_SESSION['admin_flash_error'] = implode("\n", $result['errors']);
                redirect_to(car_admin_after_action_url($slug, 'publication'));
            }
            $rebuild = rebuild_public_site_result();
            $_SESSION['admin_flash_message'] = ($rebuild['success'] && empty($rebuild['skipped']))
                ? 'Фото загружено, публичный сайт пересобран.'
                : 'Фото загружено, но публичный сайт не пересобран. Ошибка: ' . $rebuild['error'];
            if ($result['errors']) {
                $_SESSION['admin_flash_error'] = implode("\n", $result['errors']);
            }
            redirect_to(car_admin_after_action_url($slug, 'publication'));
        }

        if ($action === 'car_photo_main') {
            require_car_scope($slug);
            set_car_main_photo($slug, (string) ($_POST['photo_key'] ?? ''));
            if (PhpPublicationAutomation::enabled()) {
                $_SESSION['admin_flash_message'] = 'Сохранено. Для публикации нового главного фото требуется одобрение.';
                redirect_to(car_admin_after_action_url($slug, 'publication'));
            }
            $rebuild = rebuild_public_site_result();
            $_SESSION['admin_flash_message'] = ($rebuild['success'] && empty($rebuild['skipped']))
                ? 'Главное фото обновлено, публичный сайт пересобран.'
                : 'Главное фото обновлено, но публичный сайт не пересобран. Ошибка: ' . $rebuild['error'];
            redirect_to(car_admin_after_action_url($slug, 'publication'));
        }

        if ($action === 'car_photo_move') {
            require_car_scope($slug);
            move_car_photo($slug, (string) ($_POST['photo_key'] ?? ''), (string) ($_POST['direction'] ?? ''));
            if (PhpPublicationAutomation::enabled()) {
                $_SESSION['admin_flash_message'] = PhpPublicationAutomation::message($slug);
                redirect_to(car_admin_after_action_url($slug, 'publication'));
            }
            $rebuild = rebuild_public_site_result();
            $_SESSION['admin_flash_message'] = ($rebuild['success'] && empty($rebuild['skipped']))
                ? 'Порядок фотографий обновлён, публичный сайт пересобран.'
                : 'Порядок фотографий обновлён, но публичный сайт не пересобран. Ошибка: ' . $rebuild['error'];
            redirect_to(car_admin_after_action_url($slug, 'publication'));
        }

        if ($action === 'car_photo_delete') {
            require_car_scope($slug);
            delete_car_photo($slug, (string) ($_POST['photo_key'] ?? ''));
            if (PhpPublicationAutomation::enabled()) {
                $_SESSION['admin_flash_message'] = 'Сохранено. Утверждённая версия витрины не изменялась.';
                redirect_to(car_admin_after_action_url($slug, 'publication'));
            }
            $rebuild = rebuild_public_site_result();
            $_SESSION['admin_flash_message'] = ($rebuild['success'] && empty($rebuild['skipped']))
                ? 'Фото удалено, публичный сайт пересобран.'
                : 'Фото удалено, но публичный сайт не пересобран. Ошибка: ' . $rebuild['error'];
            redirect_to(car_admin_after_action_url($slug, 'publication'));
        }

        if ($action === 'update_car_service_hold') {
            if (!has_permission('calendar.edit') || is_lessor_user()) {
                deny_scope_access();
            }
            $holdId = trim((string) ($_POST['hold_id'] ?? ''));
            $hold = $holdId !== '' ? find_service_hold($holdId) : null;
            if (!$hold) {
                throw new RuntimeException('Сервисное удержание не найдено.');
            }
            $hold = normalize_service_hold_item($hold);
            $slug = normalize_car_slug((string) ($hold['carSlug'] ?? ''));
            require_car_scope($slug);
            if ($hold['closedAt'] !== '' || $hold['status'] === 'ready') {
                throw new RuntimeException('Сервисное удержание уже закрыто.');
            }

            $currentMileage = normalize_mileage($_POST['current_mileage'] ?? null);
            if ($currentMileage === null || $currentMileage <= 0) {
                throw new RuntimeException('Укажите актуальный пробег автомобиля.');
            }

            $readyChecklist = [
                'inspected' => isset($_POST['ready_inspected']),
                'mileageActual' => isset($_POST['ready_mileage_actual']),
                'readyConfirmed' => isset($_POST['ready_confirmed']),
                'confirmedAt' => '',
                'confirmedBy' => '',
            ];
            $missing = [];
            if (!$readyChecklist['inspected']) {
                $missing[] = 'Подтвердите, что автомобиль осмотрен.';
            }
            if (!$readyChecklist['mileageActual']) {
                $missing[] = 'Подтвердите, что пробег актуален.';
            }
            if (!$readyChecklist['readyConfirmed']) {
                $missing[] = 'Подтвердите готовность к выдаче.';
            }
            if (empty($_POST['close_confirmed'])) {
                $missing[] = 'Подтвердите снятие служебной недоступности с календаря.';
            }
            if ($missing) {
                throw new RuntimeException(implode("\n", $missing));
            }
            $readyChecklist['confirmedAt'] = now_iso();
            $readyChecklist['confirmedBy'] = current_admin_user() ?: 'system';

            rental_return_require_compatible_hold_writer($hold);
            $updated = update_service_hold_with_mileage($holdId, [
                'status' => 'ready',
                'readyDate' => '',
                'comment' => trim(strip_tags((string) ($_POST['comment'] ?? $hold['comment']))),
                'readyChecklist' => $readyChecklist,
            ], $currentMileage, (string) ($_POST['hold_version'] ?? ''), (string) ($_POST['expected_version'] ?? ''));
            if (!$updated) {
                throw new RuntimeException('Не удалось закрыть сервисное удержание.');
            }

            redirect_to(car_admin_after_action_url($slug, 'service', ['service_hold_saved' => 1]));
        }

        if ($action === 'service_fields') {
            require_car_scope($slug);
            $serviceQuickAction = (string) ($_POST['service_quick_action'] ?? '');
            if ($serviceQuickAction !== '' && !in_array($serviceQuickAction, ['current_mileage', 'maintenance_regimen'], true)) {
                throw new RuntimeException('Неизвестное быстрое действие ТО.');
            }
            if ($serviceQuickAction === 'current_mileage') {
                $quickMileage = normalize_mileage($_POST['current_mileage'] ?? null);
                if ($quickMileage === null || $quickMileage <= 0) {
                    throw new RuntimeException('Укажите текущий пробег автомобиля.');
                }
            }
            if ($serviceQuickAction === 'maintenance_regimen') {
                $quickCurrentMileage = normalize_mileage($_POST['current_mileage'] ?? null);
                $quickLastServiceMileage = normalize_mileage($_POST['last_service_mileage'] ?? null);
                $quickServiceIntervalMileage = normalize_mileage($_POST['service_interval_mileage'] ?? null);
                if ($quickCurrentMileage === null || $quickCurrentMileage <= 0) {
                    throw new RuntimeException('Укажите текущий пробег автомобиля.');
                }
                if ($quickLastServiceMileage === null) {
                    throw new RuntimeException('Укажите пробег последнего ТО.');
                }
                if ($quickServiceIntervalMileage === null || $quickServiceIntervalMileage <= 0) {
                    throw new RuntimeException('Укажите интервал ТО.');
                }
            }
            if (array_key_exists('last_service_mileage', $_POST) && array_key_exists('service_interval_mileage', $_POST)) {
                $postedCurrentMileage = normalize_mileage($_POST['current_mileage'] ?? null);
                $postedLastServiceMileage = normalize_mileage($_POST['last_service_mileage'] ?? null);
                $postedServiceIntervalMileage = normalize_mileage($_POST['service_interval_mileage'] ?? null);
                $postedNextServiceMileage = car_calculate_next_service_mileage($postedCurrentMileage, $postedLastServiceMileage, $postedServiceIntervalMileage);
                $_POST['next_service_mileage'] = $postedNextServiceMileage !== null ? (string) $postedNextServiceMileage : '';
            }
            $serviceFields = [];
            foreach ([
                'current_mileage' => 'currentMileage',
                'last_service_mileage' => 'lastServiceMileage',
                'service_interval_mileage' => 'serviceIntervalMileage',
                'next_service_mileage' => 'nextServiceMileage',
            ] as $postKey => $fieldKey) {
                if (array_key_exists($postKey, $_POST)) {
                    $serviceFields[$fieldKey] = $_POST[$postKey];
                }
            }
            if (!update_car_service_fields($slug, $serviceFields)) {
                throw new RuntimeException('Автомобиль не найден.');
            }
            $redirectParams = match ($serviceQuickAction) {
                'current_mileage' => ['mileage_saved' => 1],
                'maintenance_regimen' => ['service_regimen_saved' => 1],
                default => ['saved' => 1],
            };
            if (isset($_GET['ready']) && array_key_exists((string) $_GET['ready'], fleet_readiness_filters_for_ui())) {
                $redirectParams['ready'] = (string) $_GET['ready'];
            }
            $redirectTab = $serviceQuickAction !== ''
                ? 'service'
                : car_detail_normalize_tab((string) ($_GET['tab'] ?? 'service'));
            redirect_to(car_admin_after_action_url($slug, $redirectTab, $redirectParams));
        }

        if ($action === 'usage_fields') {
            $scopedCar = require_car_scope($slug);
            if (!current_user_can_edit_tariffs(car_owner_scope_id($scopedCar))) {
                deny_scope_access();
            }
            if (!update_car_usage_fields($slug, [
                'mileageLimitPerDay' => $_POST['mileage_limit_per_day'] ?? null,
                'extraMileageRate' => $_POST['extra_mileage_rate'] ?? null,
            ])) {
                throw new RuntimeException('Автомобиль не найден.');
            }
            redirect_to(car_admin_after_action_url($slug, 'tariffs', ['usage' => 1]));
        }

        if ($action === 'document_fields') {
            $scopedCar = require_car_scope($slug);
            $carScopeId = car_owner_scope_id($scopedCar);
            $quickAction = (string) ($_POST['readiness_quick_action'] ?? '');
            if (!array_key_exists($quickAction, ['' => true, 'plate' => true, 'sts' => true, 'osago' => true, 'vin' => true, 'market_value' => true])) {
                throw new RuntimeException('Неизвестное быстрое исправление готовности.');
            }
            $identityPostKeys = ['license_plate', 'vin', 'registration_certificate', 'osago_number', 'osago_expires_at', 'casco_number', 'casco_expires_at', 'diagnostic_card_expires_at'];
            $needsIdentityPermission = in_array($quickAction, ['plate', 'sts', 'osago', 'vin'], true);
            foreach ($identityPostKeys as $identityPostKey) {
                if (array_key_exists($identityPostKey, $_POST)) {
                    $needsIdentityPermission = true;
                    break;
                }
            }
            $needsMarketPermission = $quickAction === 'market_value' || array_key_exists('market_value', $_POST);
            if ($needsIdentityPermission && !current_user_can_edit_car_identity($carScopeId)) {
                deny_scope_access();
            }
            if ($needsMarketPermission && !current_user_can_edit_car_market_value($carScopeId)) {
                deny_scope_access();
            }
            $documentFields = car_readiness_document_payload($scopedCar, $_POST);
            if ($quickAction !== '') {
                car_readiness_validate_quick_document_payload($quickAction, $documentFields);
            } elseif ($documentFields['registrationCertificate'] !== '' && !car_registration_certificate_input_is_valid($documentFields['registrationCertificate'])) {
                throw new RuntimeException('СТС можно вводить цифрами подряд или через пробел/дефис/тире после серии.');
            } elseif ($documentFields['registrationCertificate'] !== '' && car_registration_certificate_digit_count($documentFields['registrationCertificate']) !== 10) {
                throw new RuntimeException('СТС должен содержать 10 цифр: серия 4 цифры и номер 6 цифр.');
            }
            if (!update_car_document_fields($slug, $documentFields)) {
                throw new RuntimeException('Автомобиль не найден.');
            }
            $redirectParams = [];
            if (isset($_GET['ready']) && array_key_exists((string) $_GET['ready'], fleet_readiness_filters_for_ui())) {
                $redirectParams['ready'] = (string) $_GET['ready'];
            }
            if ($quickAction !== '') {
                $redirectParams['readiness_saved'] = $quickAction;
            } else {
                $redirectParams['documents'] = 1;
            }
            redirect_to(car_admin_after_action_url($slug, 'documents', $redirectParams));
        }

        if ($action === 'showcase_fields') {
            if (!$canManageRentRkShowcase) {
                deny_scope_access();
            }
            require_car_scope($slug);
            if (!update_car_showcase_fields($slug, [
                'available_for_rent_rk_partners' => !empty($_POST['available_for_rent_rk_partners']),
            ])) {
                throw new RuntimeException('Автомобиль не найден.');
            }
            $rebuild = rebuild_public_site_result();
            $_SESSION['admin_flash_message'] = ($rebuild['success'] && empty($rebuild['skipped']))
                ? 'Видимость автомобиля для партнёров Rent RK сохранена, публичный сайт пересобран.'
                : 'Видимость автомобиля для партнёров Rent RK сохранена, но публичный сайт не пересобран. Ошибка: ' . $rebuild['error'];
            redirect_to(car_admin_after_action_url($slug, 'publication'));
        }

        if ($action === 'publication_fields') {
            if (current_admin_role() !== 'admin') {
                deny_scope_access();
            }
            require_car_scope($slug);
            if (!update_car_publication_fields($slug, [
                'adminStatus' => (string) ($_POST['admin_status'] ?? ''),
                'publicStatus' => (string) ($_POST['public_status'] ?? ''),
                'publishChannels' => $_POST['publish_channels'] ?? [],
                'publishBlockedReason' => (string) ($_POST['publish_blocked_reason'] ?? ''),
            ])) {
                throw new RuntimeException('Автомобиль не найден.');
            }
            if (PhpPublicationAutomation::enabled()) {
                $_SESSION['admin_flash_message'] = PhpPublicationAutomation::message($slug);
                redirect_to(car_admin_after_action_url($slug, 'publication'));
            }
            $rebuild = rebuild_public_site_result();
            $_SESSION['admin_flash_message'] = ($rebuild['success'] && empty($rebuild['skipped']))
                ? 'Публикационный статус сохранен, публичный сайт пересобран.'
                : 'Публикационный статус сохранен, но публичный сайт не пересобран. Ошибка: ' . $rebuild['error'];
            redirect_to(car_admin_after_action_url($slug, 'publication'));
        }

        if ($action === 'lessor_public_submit') {
            lessor_submit_car_for_review($slug, (string) ($_POST['lessor_comment'] ?? ''), (string) ($_POST['expected_version'] ?? ''));
            $_SESSION['admin_flash_message'] = 'Автомобиль отправлен на проверку Rent RK. Публикация на сайте не включалась.';
            redirect_to(car_admin_is_detail_request($slug)
                ? car_detail_tab_url($slug, 'publication', car_detail_return_params())
                : car_admin_list_redirect_url($slug, ['readiness' => 'submitted']));
        }

        if ($action === 'lessor_public_review') {
            if (!$canManageLessorPublication) {
                deny_scope_access();
            }
            require_car_scope($slug);
            $decision = (string) ($_POST['decision'] ?? '');
            admin_review_lessor_publication($slug, $decision, (string) ($_POST['review_comment'] ?? ''), (string) ($_POST['expected_version'] ?? ''));
            $_SESSION['admin_flash_message'] = PhpPublicationAutomation::enabled() ? PhpPublicationAutomation::message($slug)
                : 'Решение сохранено, но публичная витрина ещё не обновлена. Изменение добавлено в очередь отдельной безопасной локальной сборки и code-only публикации.';
            redirect_to(car_admin_is_detail_request($slug)
                ? car_detail_tab_url($slug, 'publication', car_detail_return_params())
                : car_admin_list_redirect_url($slug, ['readiness' => (string) ($_GET['readiness'] ?? 'all')]));
        }

        if ($action === 'service_log') {
            $scopedCar = require_car_scope($slug);
            $quickAction = (string) ($_POST['readiness_quick_action'] ?? '');
            if ($quickAction !== '' && $quickAction !== 'maintenance') {
                throw new RuntimeException('Неизвестное быстрое действие обслуживания.');
            }
            if ($quickAction === 'maintenance') {
                $serviceState = car_service_state($scopedCar);
                $serviceMileage = normalize_mileage($_POST['service_mileage'] ?? null);
                if ($serviceMileage === null || $serviceMileage <= 0) {
                    throw new RuntimeException('Укажите пробег, на котором пройдено ТО.');
                }
                if ($serviceMileage < (int) $serviceState['lastServiceMileage']) {
                    throw new RuntimeException('Пробег ТО не может быть меньше пробега последнего ТО.');
                }
                $serviceDate = (string) ($_POST['service_date'] ?? date('Y-m-d'));
                if (!parse_date_value($serviceDate)) {
                    throw new RuntimeException('Некорректная дата ТО.');
                }
            }
            add_service_log_entry([
                'carId' => $slug,
                'date' => (string) ($_POST['service_date'] ?? date('Y-m-d')),
                'mileage' => $_POST['service_mileage'] ?? null,
                'type' => $quickAction === 'maintenance' ? 'planned_to' : (string) ($_POST['service_type'] ?? 'other'),
                'description' => $quickAction === 'maintenance' ? trim(strip_tags((string) ($_POST['service_description'] ?? 'Плановое ТО выполнено.'))) : trim((string) ($_POST['service_description'] ?? '')),
                'cost' => $_POST['service_cost'] ?? null,
                'provider' => $quickAction === 'maintenance' ? trim(strip_tags((string) ($_POST['service_provider'] ?? ''))) : trim((string) ($_POST['service_provider'] ?? '')),
                'comment' => $quickAction === 'maintenance' ? trim(strip_tags((string) ($_POST['service_comment'] ?? ''))) : trim((string) ($_POST['service_comment'] ?? '')),
            ], business_command_id($_POST['command_id'] ?? null));
            $redirectParams = $quickAction === 'maintenance' ? ['maintenance_saved' => 1] : ['service' => 1];
            if (isset($_GET['ready']) && array_key_exists((string) $_GET['ready'], fleet_readiness_filters_for_ui())) {
                $redirectParams['ready'] = (string) $_GET['ready'];
            }
            redirect_to(car_admin_after_action_url($slug, 'service', $redirectParams));
        }
    } catch (Throwable $exception) {
        if (in_array($exception->getCode(), [409, 503], true)) http_response_code($exception->getCode());
        $error = $exception->getMessage();
    }
}

if (isset($_GET['saved'])) {
    $message = 'Данные ТО сохранены.';
}
if (isset($_GET['mileage_saved'])) {
    $message = 'Пробег обновлён.';
}
if (isset($_GET['service_regimen_saved'])) {
    $message = 'Регламент ТО сохранён. Следующее ТО пересчитано.';
}
if (isset($_GET['service_hold_saved'])) {
    $message = 'Сервисное удержание закрыто. Машина вернулась в парк.';
}
if (isset($_GET['service'])) {
    $message = 'Запись обслуживания добавлена.';
}
if (isset($_GET['maintenance_saved'])) {
    $message = 'ТО отмечено. Следующее ТО пересчитано.';
}
if (isset($_GET['usage'])) {
    $message = 'Условия пробега сохранены.';
}
if (isset($_GET['readiness_saved'])) {
    $savedAction = (string) $_GET['readiness_saved'];
    $meta = car_readiness_action_meta($savedAction);
    if ($meta !== []) {
        $message = (string) $meta['flash'];
    }
}
if (isset($_GET['documents'])) {
    $message = 'Страховка и документы автомобиля сохранены.';
}

if (isset($_GET['created'])) {
    $message = 'Автомобиль добавлен. Папка для фотографий создана в assets/img/cars/.';
}

$allScopedCars = scope_cars_for_current_user(read_cars());
$fleetState = (string) ($_GET['state'] ?? 'active');
if (!in_array($fleetState, ['active', 'archive'], true)) {
    $fleetState = 'active';
}
$activeCarsCount = count(array_filter($allScopedCars, static fn(array $car): bool => !car_is_archived($car)));
$archivedCarsCount = count(array_filter($allScopedCars, static fn(array $car): bool => car_is_archived($car)));
$cars = array_values(array_filter($allScopedCars, static fn(array $car): bool => car_is_archived($car) === ($fleetState === 'archive')));
$viewRaw = trim((string) ($_GET['view'] ?? 'cards'));
$detailCarSlug = '';
$detailCar = null;
$view = $viewRaw;
if (!in_array($view, ['cards', 'table', 'readiness'], true)) {
    $candidateSlug = normalize_car_slug($viewRaw);
    foreach ($allScopedCars as $candidateCar) {
        if (normalize_car_slug((string) ($candidateCar['slug'] ?? '')) === $candidateSlug) {
            $detailCarSlug = $candidateSlug;
            $detailCar = $candidateCar;
            break;
        }
    }
    if ($detailCar !== null) {
        $view = 'detail';
        $fleetState = car_is_archived($detailCar) ? 'archive' : 'active';
        $cars = [$detailCar];
    } else {
        $view = 'cards';
        if ($viewRaw !== '') {
            $error = trim($error . "\n" . 'Автомобиль для подробного просмотра не найден или недоступен.');
        }
    }
}
$readinessFilter = (string) ($_GET['readiness'] ?? 'all');
$readinessStatuses = lessor_publication_statuses();
if ($readinessFilter !== 'all' && !array_key_exists($readinessFilter, $readinessStatuses)) {
    $readinessFilter = 'all';
}
$lessorReadinessCounts = array_fill_keys(array_keys($readinessStatuses), 0);
foreach ($allScopedCars as $publicationCar) {
    if (car_is_archived($publicationCar) || car_owner_type($publicationCar) !== 'lessor') {
        continue;
    }
    $publicationStatus = lessor_publication_state($publicationCar)['readinessStatus'];
    if (isset($lessorReadinessCounts[$publicationStatus])) {
        $lessorReadinessCounts[$publicationStatus]++;
    }
}
if ($view !== 'readiness' && $view !== 'detail' && $readinessFilter !== 'all') {
    $cars = array_values(array_filter($cars, static fn(array $car): bool => lessor_publication_state($car)['readinessStatus'] === $readinessFilter));
}
$carDetailTabs = car_detail_tabs_for_ui();
$activeCarTab = car_detail_normalize_tab((string) ($_GET['tab'] ?? 'summary'));
if ($view === 'detail') {
    if (!isset($_GET['tab'])) {
        if (isset($_GET['documents'])) {
            $activeCarTab = 'documents';
        } elseif (isset($_GET['usage'])) {
            $activeCarTab = 'tariffs';
        } elseif (isset($_GET['service']) || isset($_GET['saved'])) {
            $activeCarTab = 'service';
        }
    }
} else {
    $activeCarTab = 'summary';
}
$availability = read_availability()['cars'];
$today = new DateTimeImmutable('today');
$limit = $today->modify('+60 days');
$scopedRentalsForCarHub = scope_rentals_for_current_user(read_rentals()['items'] ?? []);
$serviceTypes = service_log_types();
$deleteDependencyLabels = car_delete_dependency_labels();
$fleetReadinessFilter = (string) ($_GET['ready'] ?? 'all');
$fleetReadinessFilters = fleet_readiness_filters_for_ui();
if (!array_key_exists($fleetReadinessFilter, $fleetReadinessFilters)) {
    $fleetReadinessFilter = 'all';
}
$fleetReadinessItems = [];
$fleetReadinessCounts = array_fill_keys(array_keys(fleet_readiness_statuses_for_ui()), 0);
$fleetReadinessReasonCounts = array_fill_keys(['documents', 'tariffs', 'card', 'publication', 'fines'], 0);
$vehicleCenterScopeCars = array_values(array_filter(
    $allScopedCars,
    static fn(array $car): bool => car_is_archived($car) === ($fleetState === 'archive')
));
$vehicleCenterScopedFines = scoped_fines_for_current_user();
$vehicleCenterItems = array_map(
    static fn(array $car): array => fleet_readiness_item_for_ui($car, $scopedRentalsForCarHub, $vehicleCenterScopedFines, $today, $canManageRentRkShowcase || current_admin_role() === 'manager', $isScopedLessor),
    $vehicleCenterScopeCars
);
$vehicleCenterCounts = array_fill_keys(array_keys(fleet_readiness_statuses_for_ui()), 0);
$vehicleCenterReasonCounts = array_fill_keys(['documents', 'tariffs', 'card', 'service', 'busy', 'publication', 'fines'], 0);
foreach ($vehicleCenterItems as $item) {
    $status = (string) ($item['status'] ?? 'unknown');
    $vehicleCenterCounts[$status] = ($vehicleCenterCounts[$status] ?? 0) + 1;
    $reasonFilters = [];
    foreach (($item['reasons'] ?? []) as $reason) {
        if (!is_array($reason)) {
            continue;
        }
        $filter = (string) ($reason['filter'] ?? '');
        if ($filter !== '') {
            $reasonFilters[$filter] = true;
        }
    }
    foreach (array_keys($reasonFilters) as $filter) {
        if (isset($vehicleCenterReasonCounts[$filter])) {
            $vehicleCenterReasonCounts[$filter]++;
        }
    }
}
$vehicleCenterQueues = [
    [
        'key' => 'ready',
        'label' => 'Готовы к выдаче',
        'count' => (int) ($vehicleCenterCounts['ready'] ?? 0),
        'href' => vehicle_center_queue_href('ready', $fleetState),
        'hint' => 'Можно открывать карточку и календарь перед выдачей.',
    ],
    [
        'key' => 'documents',
        'label' => 'Документы',
        'count' => (int) ($vehicleCenterReasonCounts['documents'] ?? 0),
        'href' => vehicle_center_queue_href('documents', $fleetState),
        'hint' => 'Номер, СТС, VIN, страховки или рыночная стоимость.',
    ],
    [
        'key' => 'tariffs',
        'label' => 'Цена / залог',
        'count' => (int) ($vehicleCenterReasonCounts['tariffs'] ?? 0),
        'href' => vehicle_center_queue_href('tariffs', $fleetState),
        'hint' => 'Базовый тариф или залог не готовы к продаже.',
    ],
    [
        'key' => 'card',
        'label' => 'Фото / карточка',
        'count' => (int) ($vehicleCenterReasonCounts['card'] ?? 0),
        'href' => vehicle_center_queue_href('card', $fleetState),
        'hint' => 'Карточке не хватает фото или витринных данных.',
    ],
    [
        'key' => 'service',
        'label' => 'Сервис',
        'count' => (int) max(($vehicleCenterCounts['service'] ?? 0), ($vehicleCenterReasonCounts['service'] ?? 0)),
        'href' => vehicle_center_queue_href('service', $fleetState),
        'hint' => 'ТО, сервисные удержания и технические ограничения.',
    ],
    [
        'key' => 'busy',
        'label' => 'Заняты / календарь',
        'count' => (int) max(($vehicleCenterCounts['busy'] ?? 0), ($vehicleCenterReasonCounts['busy'] ?? 0)),
        'href' => vehicle_center_queue_href('busy', $fleetState),
        'hint' => 'Активные аренды, брони, выдачи и возвраты.',
    ],
    [
        'key' => 'publication',
        'label' => 'Публикация',
        'count' => (int) max(($vehicleCenterCounts['hidden'] ?? 0), ($vehicleCenterReasonCounts['publication'] ?? 0)),
        'href' => vehicle_center_queue_href('publication', $fleetState),
        'hint' => 'Машина скрыта или не готова к витрине.',
    ],
    [
        'key' => 'fines',
        'label' => 'Штрафы',
        'count' => (int) ($vehicleCenterReasonCounts['fines'] ?? 0),
        'href' => vehicle_center_queue_href('fines', $fleetState),
        'hint' => 'Открытые, непривязанные или требующие решения штрафы.',
    ],
];
$vehicleCenterRiskItems = array_values(array_filter(
    $vehicleCenterItems,
    static fn(array $item): bool => (string) ($item['status'] ?? '') !== 'ready' || !empty($item['reasons'])
));
usort($vehicleCenterRiskItems, static function (array $a, array $b): int {
    $score = static function (array $item): int {
        $status = (string) ($item['status'] ?? 'unknown');
        $statusScore = match ($status) {
            'blocked', 'service' => 500,
            'busy' => 400,
            'hidden', 'attention' => 300,
            'unknown' => 200,
            default => 100,
        };
        $reasonScore = 0;
        foreach (($item['reasons'] ?? []) as $reason) {
            if (!is_array($reason)) {
                continue;
            }
            $reasonScore += match ((string) ($reason['severity'] ?? 'warning')) {
                'danger' => 20,
                'warning' => 10,
                default => 4,
            };
        }

        return $statusScore + $reasonScore;
    };

    return $score($b) <=> $score($a);
});
$vehicleCenterRiskItems = array_slice($vehicleCenterRiskItems, 0, 5);
$vehicleCenterQuickLinks = [
    ['label' => 'Все машины', 'href' => 'cars.php?view=cards&state=' . $fleetState],
];
if (vehicle_center_admin_route_exists('fleet-calendar.php') && has_permission('calendar.view')) {
    $vehicleCenterQuickLinks[] = ['label' => 'Календарь парка', 'href' => 'fleet-calendar.php'];
}
if (vehicle_center_admin_route_exists('service-holds.php') && !is_lessor_user() && has_permission('calendar.edit')) {
    $vehicleCenterQuickLinks[] = ['label' => 'Сервисные удержания', 'href' => 'service-holds.php'];
}
if (vehicle_center_admin_route_exists('rates.php') && current_user_can_view_tariffs()) {
    $vehicleCenterQuickLinks[] = ['label' => 'Тарифы и залог', 'href' => 'rates.php'];
}
if (vehicle_center_admin_route_exists('rentals.php') && has_permission('rentals.view')) {
    $vehicleCenterQuickLinks[] = ['label' => 'Аренды и брони', 'href' => 'rentals.php'];
}
if (vehicle_center_admin_route_exists('fines.php') && has_permission('fines.view')) {
    $vehicleCenterQuickLinks[] = ['label' => 'Штрафы', 'href' => 'fines.php'];
}
if (vehicle_center_admin_route_exists('promo-badges.php') && can_view_promo_badges()) {
    $vehicleCenterQuickLinks[] = ['label' => 'Промо-метки', 'href' => 'promo-badges.php'];
}
if (vehicle_center_admin_route_exists('page-content-review.php') && $canModeratePageContent) {
    $vehicleCenterQuickLinks[] = ['label' => 'Очередь проверки витрины', 'href' => 'page-content-review.php'];
}
if ($view === 'readiness') {
    $fleetReadinessItems = $vehicleCenterItems;
    foreach ($fleetReadinessItems as $item) {
        $fleetReadinessCounts[$item['status']] = ($fleetReadinessCounts[$item['status']] ?? 0) + 1;
        foreach ($item['reasons'] as $reason) {
            $filter = (string) ($reason['filter'] ?? '');
            if (isset($fleetReadinessReasonCounts[$filter])) {
                $fleetReadinessReasonCounts[$filter]++;
            }
        }
    }
    $fleetReadinessItems = array_values(array_filter(
        $fleetReadinessItems,
        static fn(array $item): bool => fleet_readiness_matches_filter($item, $fleetReadinessFilter)
    ));
}

$detailPageHeader = null;
if ($view === 'detail' && $detailCar !== null) {
    $detailHeaderSlug = normalize_car_slug((string) ($detailCar['slug'] ?? ''));
    $detailHeaderAvailabilityCount = 0;
    foreach (($availability[$detailHeaderSlug] ?? []) as $date => $entry) {
        $parsed = parse_date_value((string) $date);
        if ($parsed && $parsed >= $today && $parsed <= $limit) {
            $detailHeaderAvailabilityCount++;
        }
    }
    $detailHeaderService = car_service_state($detailCar);
    $detailHeaderServiceText = match ($detailHeaderService['status']) {
        'overdue' => 'ТО просрочено',
        'soon' => 'Скоро ТО',
        default => 'ТО по графику',
    };
    $detailHeaderCarFinance = normalize_car_finance_fields($detailCar);
    $detailHeaderPublicationSummary = car_publication_summary($detailCar);
    $detailHeaderHub = car_hub_model_for_ui($detailCar, $scopedRentalsForCarHub, $today, $canManageRentRkShowcase || current_admin_role() === 'manager', $isScopedLessor);
    $detailHeaderCanViewTariffs = current_user_can_view_tariffs(car_owner_scope_id($detailCar));
    if ($activeCarTab === 'tariffs' && !$detailHeaderCanViewTariffs) {
        deny_scope_access();
    }
    $detailHeaderCanEditTariffs = current_user_can_edit_tariffs(car_owner_scope_id($detailCar));
    $detailHeaderTariff = car_hub_tariff_model_for_ui($detailHeaderSlug, $detailCar, $detailHeaderCanEditTariffs);
    $detailHeaderReturnParams = car_detail_return_params();
    $detailHeaderCanEdit = car_readiness_can_edit_car($detailCar);
    $detailHeaderCanManageServiceHolds = car_readiness_can_manage_service_holds($detailCar);
    $detailHeaderNextAction = car_detail_next_action_for_ui($detailHeaderSlug, $detailHeaderHub, $detailHeaderCanEdit, $detailHeaderCanManageServiceHolds, $detailHeaderReturnParams, $carDetailTabs);
    $detailPageHeader = [
        'slug' => $detailHeaderSlug,
        'name' => trim((string) ($detailCar['name'] ?? $detailHeaderSlug)),
        'class' => trim((string) ($detailCar['class'] ?? '')),
        'seats' => trim((string) ($detailCar['seats'] ?? '')),
        'isArchived' => car_is_archived($detailCar),
        'archivedAt' => (string) ($detailCar['archivedAt'] ?? ''),
        'archivedBy' => (string) ($detailCar['archivedBy'] ?? ''),
        'ownership' => (string) (car_ownership_types()[$detailHeaderCarFinance['ownershipType']] ?? $detailHeaderCarFinance['ownershipType']),
        'ownerName' => (string) ($detailHeaderCarFinance['ownerName'] ?? ''),
        'availabilityCount' => $detailHeaderAvailabilityCount,
        'currentAvailabilityLabel' => availability_statuses_with_free()[availability_status_for_date($detailHeaderSlug, $today->format('Y-m-d'))] ?? availability_status_for_date($detailHeaderSlug, $today->format('Y-m-d')),
        'service' => $detailHeaderService,
        'serviceText' => $detailHeaderServiceText,
        'hub' => $detailHeaderHub,
        'publication' => $detailHeaderPublicationSummary,
        'tariff' => $detailHeaderTariff,
        'returnParams' => $detailHeaderReturnParams,
        'backUrl' => admin_safe_return_to($_GET['return_to'] ?? null, 'cars.php?view=cards&state=' . $fleetState),
        'canEdit' => $detailHeaderCanEdit,
        'serviceHoldModalKey' => car_readiness_modal_key($detailHeaderSlug, 'service_hold'),
        'nextAction' => $detailHeaderNextAction,
    ];
}

$createBodyTypeGroups = car_admin_create_options_by_group(car_body_type_options());
$createFuelTypeGroups = car_admin_create_options_by_group(car_fuel_type_options());
$createEquipmentGroups = car_admin_create_options_by_group(car_equipment_options());
$createMaxYear = (int) date('Y') + 2;

admin_header($isScopedLessor ? 'Мои машины' : 'Автомобили', 'cars');
?>
<?php if ($detailPageHeader !== null): ?>
  <section class="page-head car-detail-page-head">
    <div class="car-detail-page-head-main">
      <p class="car-detail-backline"><a href="<?= e((string) $detailPageHeader['backUrl']) ?>">← Назад к списку автомобилей</a></p>
      <p class="eyebrow">Карточка авто</p>
      <h1><?= e((string) $detailPageHeader['name']) ?></h1>
      <?php if (can_view_car_page_content_editor($detailCar)): ?>
        <p><a class="btn secondary compact" href="<?= e('cars/page-content.php?slug=' . rawurlencode((string) $detailPageHeader['slug'])) ?>">Редактировать page-content</a></p>
      <?php endif; ?>
      <?php if (!empty($detailPageHeader['isArchived'])): ?>
        <p><span class="status status-canceled">Архив</span> <span class="muted">с <?= e((string) $detailPageHeader['archivedAt'] !== '' ? format_admin_datetime((string) $detailPageHeader['archivedAt']) : 'дата не указана') ?><?= (string) $detailPageHeader['archivedBy'] !== '' ? ', ' . e((string) $detailPageHeader['archivedBy']) : '' ?></span></p>
      <?php endif; ?>
      <p class="muted">
        <?= e((string) $detailPageHeader['class']) ?><?= (string) $detailPageHeader['seats'] !== '' ? ' · ' . e((string) $detailPageHeader['seats']) . ' мест' : '' ?>
        · <?= e((string) $detailPageHeader['ownership']) ?><?= (string) $detailPageHeader['ownerName'] !== '' ? ' · ' . e((string) $detailPageHeader['ownerName']) : '' ?>
        · <?= e((string) $detailPageHeader['availabilityCount']) ?> отмеченных дат на 60 дней
      </p>
      <div class="service-metrics car-hero-metrics">
        <span>Госномер <strong><?= e((string) ($detailPageHeader['hub']['plate'] !== '' ? $detailPageHeader['hub']['plate'] : 'не указан')) ?></strong></span>
        <span>Мест <strong><?= e((string) $detailPageHeader['seats']) ?></strong></span>
        <span>Публикация <strong><?= e((string) $detailPageHeader['publication']['publicLabel']) ?></strong></span>
        <span>Доступность <strong><?= e((string) $detailPageHeader['currentAvailabilityLabel']) ?></strong></span>
        <span>ТО <strong><?= e((string) $detailPageHeader['serviceText']) ?></strong></span>
        <span>Штрафы <strong><?= e((string) ($detailPageHeader['hub']['fineSummary']['openCount'] ?? 0)) ?> открытых</strong></span>
        <span>Пробег <strong><?= e(number_format((int) $detailPageHeader['service']['currentMileage'], 0, '', ' ')) ?> км</strong></span>
        <span>Залог <strong><?= e($detailPageHeader['tariff']['deposit'] === null ? 'не задан' : format_money((int) $detailPageHeader['tariff']['deposit'])) ?></strong></span>
        <span>Базовая цена <strong><?= e($detailPageHeader['tariff']['primaryPrice'] === null ? 'не задана' : format_money((int) $detailPageHeader['tariff']['primaryPrice']) . '/сутки') ?></strong></span>
      </div>
      <?php if (!empty($detailPageHeader['hub']['readiness']['reasons'])): ?>
        <div class="car-hub-reasons car-hero-alerts">
          <?php foreach (array_slice($detailPageHeader['hub']['readiness']['reasons'], 0, 3) as $reason): ?>
            <?= car_readiness_reason_html($detailCar, $reason, (bool) $detailPageHeader['canEdit'], (array) $detailPageHeader['returnParams']) ?>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <div class="car-hub-next is-<?= e((string) $detailPageHeader['hub']['nextAction']['tone']) ?>">
        <strong>Следующая операция</strong>
        <?php if (!empty($detailPageHeader['nextAction']['isServiceHold'])): ?>
          <button type="button" data-car-readiness-modal-open="<?= e((string) $detailPageHeader['serviceHoldModalKey']) ?>"><?= e((string) $detailPageHeader['hub']['nextAction']['label']) ?></button>
        <?php elseif ((string) $detailPageHeader['nextAction']['modalKey'] !== ''): ?>
          <button type="button" data-car-readiness-modal-open="<?= e((string) $detailPageHeader['nextAction']['modalKey']) ?>"><?= e((string) $detailPageHeader['nextAction']['modalLabel']) ?></button>
        <?php elseif ((string) $detailPageHeader['nextAction']['href'] !== ''): ?>
          <a href="<?= e((string) $detailPageHeader['nextAction']['href']) ?>"><?= e((string) $detailPageHeader['hub']['nextAction']['label']) ?></a>
        <?php else: ?>
          <span><?= e((string) $detailPageHeader['hub']['nextAction']['label']) ?></span>
        <?php endif; ?>
      </div>
    </div>
  </section>
<?php else: ?>
  <section class="page-head">
    <div>
      <p class="eyebrow"><?= $isScopedLessor ? 'Мой автопарк' : 'Автопарк' ?></p>
      <h1><?= $isScopedLessor ? 'Мои машины' : 'Автопарк' ?></h1>
      <p class="muted"><?= $isScopedLessor ? 'Показываются только автомобили вашего контура. Быстрые переходы ведут в scoped календарь, заявки и аренды.' : 'Список автомобилей, пробег, ТО, финансовая модель и быстрый переход в календарь занятости.' ?></p>
    </div>
    <?php if ($isScopedLessor): ?>
      <div class="actions">
        <a class="btn secondary" href="my-scope.php">Мой кабинет</a>
        <a class="btn secondary" href="fleet-calendar.php">Мой календарь</a>
        <a class="btn secondary" href="requests.php">Мои заявки</a>
        <?php if (has_permission('rentals.view')): ?><a class="btn secondary" href="rentals.php">Мои аренды</a><?php endif; ?>
      </div>
    <?php endif; ?>
  </section>
<?php endif; ?>

<?php if ($message): ?><div class="notice success"><?= e($message) ?></div><?php endif; ?>
<?php if ($error): ?><?= admin_error_notice($error) ?><?php endif; ?>
<?php if ($canManageLessorPublication && $view !== 'detail' && ($lessorReadinessCounts['submitted'] ?? 0) > 0): ?>
  <div class="notice">Машины арендодателей на проверке: <strong><?= e((string) $lessorReadinessCounts['submitted']) ?></strong>. <a href="cars.php?readiness=submitted">Открыть очередь</a></div>
<?php endif; ?>

<?php if ($view !== 'detail'): ?>
<section class="panel vehicle-center-entry" data-vehicle-center-entry>
  <div class="vehicle-center-head">
    <div>
      <p class="eyebrow">Центр автопарка</p>
      <h2><?= $fleetState === 'archive' ? 'Архив машин' : 'Рабочее состояние парка' ?></h2>
      <p class="muted">Сводка не меняет машины, тарифы, календарь, штрафы или публикацию. Она показывает, куда перейти для профильной проверки.</p>
    </div>
    <div class="vehicle-center-total">
      <span><?= $fleetState === 'archive' ? 'В архиве' : 'В активном парке' ?></span>
      <strong><?= e((string) count($vehicleCenterScopeCars)) ?></strong>
    </div>
  </div>

  <div class="vehicle-center-stats" aria-label="Сводка автопарка">
    <div class="vehicle-center-stat"><span>Готовы</span><strong><?= e((string) ($vehicleCenterCounts['ready'] ?? 0)) ?></strong></div>
    <div class="vehicle-center-stat"><span>Требуют внимания</span><strong><?= e((string) ($vehicleCenterCounts['attention'] ?? 0)) ?></strong></div>
    <div class="vehicle-center-stat"><span>Не готовы</span><strong><?= e((string) ($vehicleCenterCounts['blocked'] ?? 0)) ?></strong></div>
    <div class="vehicle-center-stat"><span>Заняты</span><strong><?= e((string) ($vehicleCenterCounts['busy'] ?? 0)) ?></strong></div>
    <div class="vehicle-center-stat"><span>Сервис</span><strong><?= e((string) ($vehicleCenterCounts['service'] ?? 0)) ?></strong></div>
    <div class="vehicle-center-stat"><span>Скрыты</span><strong><?= e((string) ($vehicleCenterCounts['hidden'] ?? 0)) ?></strong></div>
  </div>

  <div class="vehicle-center-layout">
    <div>
      <div class="vehicle-center-section-head">
        <div>
          <p class="eyebrow">Очереди</p>
          <h3>Что проверить сейчас</h3>
        </div>
        <a class="small-link" href="<?= e(vehicle_center_queue_href('all', $fleetState)) ?>">Вся готовность</a>
      </div>
      <div class="vehicle-center-queues">
        <?php foreach ($vehicleCenterQueues as $queue): ?>
          <?php
            $queueCount = (int) ($queue['count'] ?? 0);
            $queueKey = (string) ($queue['key'] ?? '');
            $queueLabel = (string) ($queue['label'] ?? $queueKey);
            $queueHint = (string) ($queue['hint'] ?? '');
            $queueHref = (string) ($queue['href'] ?? '');
            $queueDisabled = $queueCount <= 0 || $queueHref === '';
          ?>
          <?php if ($queueDisabled): ?>
            <span class="vehicle-center-queue is-disabled" aria-disabled="true" data-vehicle-queue="<?= e($queueKey) ?>" data-vehicle-queue-count="0">
              <span><?= e($queueLabel) ?></span>
              <strong>0</strong>
              <small><?= e($queueHint !== '' ? $queueHint : 'Нет ожидающих машин.') ?></small>
            </span>
          <?php else: ?>
            <a class="vehicle-center-queue" href="<?= e($queueHref) ?>" data-vehicle-queue="<?= e($queueKey) ?>" data-vehicle-queue-count="<?= e((string) $queueCount) ?>">
              <span><?= e($queueLabel) ?></span>
              <strong><?= e((string) $queueCount) ?></strong>
              <small><?= e($queueHint) ?></small>
            </a>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    </div>

    <aside class="vehicle-center-risks" aria-label="Машины с рисками">
      <div class="vehicle-center-section-head">
        <div>
          <p class="eyebrow">Контроль</p>
          <h3>Машины с рисками</h3>
        </div>
      </div>
      <?php if (!$vehicleCenterRiskItems): ?>
        <div class="vehicle-center-empty">
          <strong>Критичных сигналов нет</strong>
          <span>Парк можно проверять через карточки и календарь.</span>
        </div>
      <?php else: ?>
        <div class="vehicle-center-risk-list">
          <?php foreach ($vehicleCenterRiskItems as $riskItem): ?>
            <?php
              $riskSlug = (string) ($riskItem['slug'] ?? '');
              $riskStatus = (string) ($riskItem['status'] ?? 'unknown');
              $riskStatusMeta = (fleet_readiness_statuses_for_ui()[$riskStatus] ?? fleet_readiness_statuses_for_ui()['unknown']);
              $riskReason = car_readiness_first_actionable_reason($riskItem);
              $riskTab = $riskReason ? car_readiness_reason_target_tab($riskReason) : 'summary';
            ?>
            <a class="vehicle-center-risk" href="<?= e(vehicle_center_detail_href($riskSlug, $fleetState, $riskTab)) ?>">
              <span class="status <?= e((string) $riskStatusMeta['class']) ?>"><?= e((string) $riskStatusMeta['label']) ?></span>
              <strong><?= e((string) ($riskItem['name'] ?? $riskSlug)) ?></strong>
              <small><?= e(vehicle_center_first_reason_label($riskItem)) ?></small>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </aside>
  </div>

  <div class="vehicle-center-links" aria-label="Быстрые переходы по автопарку">
    <?php foreach ($vehicleCenterQuickLinks as $quickLink): ?>
      <a class="small-link" href="<?= e((string) $quickLink['href']) ?>"><?= e((string) $quickLink['label']) ?></a>
    <?php endforeach; ?>
  </div>
</section>

<div class="view-switch">
    <a class="btn <?= $view === 'readiness' ? '' : 'secondary' ?>" href="cars.php?view=readiness&state=<?= e($fleetState) ?>">Готовность парка</a>
    <a class="btn <?= $view === 'cards' ? '' : 'secondary' ?>" href="cars.php?view=cards&state=<?= e($fleetState) ?>">Карточки</a>
    <a class="btn <?= $view === 'table' ? '' : 'secondary' ?>" href="cars.php?view=table&state=<?= e($fleetState) ?>">Таблица</a>
    <?php if ($canModeratePageContent): ?><a class="btn secondary" href="page-content-review.php">Page-content на проверке (<?= e((string) $pageContentReviewCount) ?>)</a><?php endif; ?>
    <a class="btn <?= $fleetState === 'active' ? '' : 'secondary' ?>" href="cars.php?view=<?= e($view) ?>&state=active">Активные (<?= e((string) $activeCarsCount) ?>)</a>
    <a class="btn <?= $fleetState === 'archive' ? '' : 'secondary' ?>" href="cars.php?view=<?= e($view) ?>&state=archive">Архив (<?= e((string) $archivedCarsCount) ?>)</a>
    <?php if ($showLessorPublicationWorkflow && $view !== 'readiness'): ?>
      <a class="btn <?= $readinessFilter === 'all' ? '' : 'secondary' ?>" href="cars.php?view=<?= e($view) ?>&state=<?= e($fleetState) ?>&readiness=all">Все проверки</a>
      <a class="btn <?= $readinessFilter === 'submitted' ? '' : 'secondary' ?>" href="cars.php?view=<?= e($view) ?>&state=<?= e($fleetState) ?>&readiness=submitted">На проверке (<?= e((string) ($lessorReadinessCounts['submitted'] ?? 0)) ?>)</a>
      <a class="btn <?= $readinessFilter === 'changes_requested' ? '' : 'secondary' ?>" href="cars.php?view=<?= e($view) ?>&state=<?= e($fleetState) ?>&readiness=changes_requested">Нужны правки (<?= e((string) ($lessorReadinessCounts['changes_requested'] ?? 0)) ?>)</a>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if ($showLessorPublicationWorkflow && $view !== 'readiness' && $view !== 'detail'): ?>
  <form class="calendar-filter-bar lessor-publication-filter" method="get">
    <input type="hidden" name="view" value="<?= e($view) ?>">
    <input type="hidden" name="state" value="<?= e($fleetState) ?>">
    <label>Статус проверки
      <select name="readiness">
        <option value="all" <?= $readinessFilter === 'all' ? 'selected' : '' ?>>Все</option>
        <?php foreach ($readinessStatuses as $statusKey => $statusLabel): ?>
          <option value="<?= e($statusKey) ?>" <?= $readinessFilter === $statusKey ? 'selected' : '' ?>><?= e($statusLabel) ?> (<?= e((string) ($lessorReadinessCounts[$statusKey] ?? 0)) ?>)</option>
        <?php endforeach; ?>
      </select>
    </label>
    <button class="btn secondary" type="submit">Показать</button>
  </form>
<?php endif; ?>

<?php if ($view !== 'readiness' && $view !== 'detail'): ?>
<details class="add-car-panel">
  <summary>Добавить автомобиль</summary>
  <form method="post" class="service-form car-create-form" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="create_car">
    <div class="rate-field-wide">
      <h3>Основные данные карточки</h3>
    </div>
    <label>Бренд <input name="brand" maxlength="80" autocomplete="off" placeholder="Chery"></label>
    <label>Модель <input name="model" maxlength="80" autocomplete="off" placeholder="Tiggo 8"></label>
    <label>Год <input name="year" type="number" min="1900" max="<?= e((string) $createMaxYear) ?>"></label>
    <label>Поколение <input name="generation" maxlength="80" autocomplete="off" placeholder="Pro Max"></label>
    <label>Комплектация <input name="trim" maxlength="120" autocomplete="off" placeholder="Prestige"></label>
    <label>Кузов
      <select name="bodyType">
        <option value="">Не указан</option>
        <?php foreach ($createBodyTypeGroups as $group => $options): ?>
          <optgroup label="<?= e($group) ?>">
            <?php foreach ($options as $code => $option): ?>
              <option value="<?= e((string) $code) ?>"><?= e((string) $option['label']) ?></option>
            <?php endforeach; ?>
          </optgroup>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Название <input name="name" required placeholder="Например: Chery Tiggo 8"></label>
    <p class="field-hint rate-field-wide">Название можно составить из бренда, модели и года, но форма не меняет его автоматически.</p>
    <label>Код для URL <input name="slug" required placeholder="chery-tiggo-8"></label>
    <label>Класс <input name="class" placeholder="кроссовер"></label>

    <div class="rate-field-wide">
      <h3>Технические характеристики</h3>
    </div>
    <label>Топливо
      <select name="fuelType">
        <option value="">Не указано</option>
        <?php foreach ($createFuelTypeGroups as $group => $options): ?>
          <optgroup label="<?= e($group) ?>">
            <?php foreach ($options as $code => $option): ?>
              <option value="<?= e((string) $code) ?>"><?= e((string) $option['label']) ?></option>
            <?php endforeach; ?>
          </optgroup>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Цвет <input name="color" maxlength="80" placeholder="белый"></label>
    <label>Дверей <input name="doors" type="number" min="1" max="8"></label>
    <label>Мест <input name="seats" type="number" min="1" value="5"></label>
    <label>Привод <input name="drive" placeholder="передний / полный"></label>
    <label>Коробка <input name="transmission" placeholder="автомат"></label>
    <label>Двигатель <input name="engine" placeholder="1.5, 147 л.с."></label>
    <label>Мощность, л.с. <input name="enginePowerHp" type="number" min="1" max="2000"></label>
    <label>Объём, л <input name="engineDisplacementL" type="number" min="0.1" max="20" step="0.1"></label>
    <label>Запас хода EV, км <input name="electricRangeKm" type="number" min="1" max="2000"></label>

    <div class="rate-field-wide">
      <h3>Оснащение</h3>
      <p class="field-hint">В записи автомобиля сохраняются только технические коды. Подписи берутся из общего справочника.</p>
      <?php foreach ($createEquipmentGroups as $group => $options): ?>
        <fieldset>
          <legend><?= e($group) ?></legend>
          <?php foreach ($options as $code => $option): ?>
            <label class="check-row">
              <input type="checkbox" name="equipment[]" value="<?= e((string) $code) ?>">
              <span><?= e((string) $option['label']) ?></span>
            </label>
          <?php endforeach; ?>
        </fieldset>
      <?php endforeach; ?>
    </div>

    <div class="rate-field-wide">
      <h3>Дополнительные характеристики</h3>
      <p class="field-hint">До 20 display-only строк. Пустые строки будут отброшены общим normalizer-слоем при создании.</p>
      <?php for ($extraSpecIndex = 0; $extraSpecIndex < 20; $extraSpecIndex++): ?>
        <div class="service-form">
          <input type="hidden" name="extraSpecs_key[]" value="">
          <label>Название <input name="extraSpecs_label[]" maxlength="80"></label>
          <label>Значение <input name="extraSpecs_value[]" maxlength="160"></label>
          <label>Ед. <input name="extraSpecs_unit[]" maxlength="20"></label>
          <label>Sort <input name="extraSpecs_sort[]" type="number" value="<?= e((string) (($extraSpecIndex + 1) * 10)) ?>"></label>
        </div>
      <?php endfor; ?>
    </div>

    <div class="rate-field-wide">
      <h3>Цена, фото и документы</h3>
    </div>
    <label>VIN <input name="vin" maxlength="17" placeholder="XW8..."></label>
    <label>Рыночная стоимость <input name="market_value" inputmode="numeric" placeholder="руб."></label>
    <label>Базовая цена <input name="price" inputmode="numeric" placeholder="руб."></label>
    <label>Лимит пробега в сутки <input name="mileage_limit_per_day" type="number" min="0" step="1" value="<?= e((string) default_mileage_limit_per_day()) ?>"></label>
    <label>Стоимость 1 км перепробега <input name="extra_mileage_rate" inputmode="numeric" placeholder="руб./км"></label>
    <div class="rate-field-wide car-main-photo-field" data-car-main-photo-upload>
      <label class="car-main-photo-picker">
        Главное фото
        <input type="file" name="main_photo" accept="image/jpeg,image/png,image/webp" data-car-main-photo-input>
      </label>
      <div class="car-main-photo-preview" data-car-main-photo-preview hidden>
        <img alt="">
        <span data-car-main-photo-name></span>
      </div>
      <p class="field-hint">Загрузите главное фото автомобиля. Дополнительные фотографии вы сможете добавить после создания в блоке «Фотографии автомобиля».</p>
      <?php if (current_admin_role() === 'admin'): ?>
        <details class="car-photo-path-fallback">
          <summary>Технический путь к фото</summary>
          <label>Путь <input name="image" placeholder="assets/img/cars/chery-tiggo-8/chery-tiggo-8-1.jpg"></label>
          <p class="field-hint">Используйте только для сохранения уже существующего файла без загрузки.</p>
        </details>
      <?php endif; ?>
    </div>
    <label class="check-row rate-field-wide">
      <input type="checkbox" name="hourly_available" value="1">
      <span>Почасовая аренда включена</span>
    </label>
    <label>
      Финансовая модель
      <select name="ownership_type">
        <?php foreach (car_ownership_types() as $key => $label): ?>
          <option value="<?= e($key) ?>"><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <?php if ($canManageRentRkShowcase): ?>
      <label class="check-row rate-field-wide">
        <input type="checkbox" name="available_for_rent_rk_partners" value="1" checked>
        <span>Показывать партнёрам Rent RK</span>
      </label>
      <p class="field-hint rate-field-wide">Если включено, автомобиль будет доступен партнёрам Rent RK в общей партнёрской витрине. Если выключено, партнёры Rent RK не увидят этот автомобиль и не смогут создать по нему заявку.</p>
    <?php endif; ?>
    <label>Владелец / источник <input name="owner_name" placeholder="если авто на комиссии"></label>
    <label>
      Правило комиссии
      <select name="owner_commission_type">
        <?php foreach (owner_commission_types() as $key => $label): ?>
          <option value="<?= e($key) ?>"><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Значение комиссии <input name="owner_commission_value" inputmode="numeric" placeholder="% или руб."></label>
    <label>Госномер <input data-license-plate-input name="license_plate" placeholder="А000АА82"></label>
    <label>СТС <input name="registration_certificate" inputmode="numeric" maxlength="11" data-sts-input></label>
    <label>ОСАГО № <input name="osago_number"></label>
    <label>ОСАГО до <input type="date" name="osago_expires_at"></label>
    <label>КАСКО № <input name="casco_number"></label>
    <label>КАСКО до <input type="date" name="casco_expires_at"></label>
    <label>Диагностическая карта до <input type="date" name="diagnostic_card_expires_at"></label>
    <button class="btn" type="submit">Добавить автомобиль</button>
  </form>
</details>
<?php endif; ?>

<?php if ($view === 'readiness'): ?>
  <?php $fleetReadinessStatuses = fleet_readiness_statuses_for_ui(); ?>
  <section class="panel fleet-readiness-overview">
    <div class="fleet-readiness-heading">
      <div>
        <p class="eyebrow">Только просмотр</p>
        <h2>Готовность парка</h2>
        <p class="muted">Сводка не меняет машины, публикацию, занятость, штрафы или документы. Она показывает известные причины, почему машину можно или нельзя безопасно выдавать.</p>
      </div>
      <a class="btn secondary" href="calendar.php">Открыть календарь</a>
    </div>

    <div class="fleet-readiness-summary">
      <div class="fleet-readiness-stat"><span>Всего</span><strong><?= e((string) array_sum($fleetReadinessCounts)) ?></strong></div>
      <div class="fleet-readiness-stat"><span>Готовы</span><strong><?= e((string) ($fleetReadinessCounts['ready'] ?? 0)) ?></strong></div>
      <div class="fleet-readiness-stat"><span>Требуют внимания</span><strong><?= e((string) ($fleetReadinessCounts['attention'] ?? 0)) ?></strong></div>
      <div class="fleet-readiness-stat"><span>Не готовы</span><strong><?= e((string) ($fleetReadinessCounts['blocked'] ?? 0)) ?></strong></div>
      <div class="fleet-readiness-stat"><span>Заняты</span><strong><?= e((string) ($fleetReadinessCounts['busy'] ?? 0)) ?></strong></div>
      <div class="fleet-readiness-stat"><span>Сервис</span><strong><?= e((string) ($fleetReadinessCounts['service'] ?? 0)) ?></strong></div>
      <div class="fleet-readiness-stat"><span>Скрыты</span><strong><?= e((string) ($fleetReadinessCounts['hidden'] ?? 0)) ?></strong></div>
    </div>

    <nav class="fleet-readiness-filters" aria-label="Фильтры готовности парка">
      <?php foreach ($fleetReadinessFilters as $filterKey => $filterLabel): ?>
        <?php
          $filterCount = match ($filterKey) {
              'all' => array_sum($fleetReadinessCounts),
              'documents', 'tariffs', 'card', 'publication', 'fines' => $fleetReadinessReasonCounts[$filterKey] ?? 0,
              default => $fleetReadinessCounts[$filterKey] ?? 0,
          };
          $filterDisabled = $filterKey !== 'all' && $filterCount <= 0;
        ?>
        <?php if ($filterDisabled): ?>
          <span class="btn secondary is-disabled" aria-disabled="true" data-vehicle-readiness-filter="<?= e($filterKey) ?>" data-vehicle-readiness-count="0"><?= e($filterLabel) ?> (0)</span>
        <?php else: ?>
          <a class="btn <?= $fleetReadinessFilter === $filterKey ? '' : 'secondary' ?>" href="cars.php?view=readiness&state=<?= e($fleetState) ?>&ready=<?= e($filterKey) ?>" data-vehicle-readiness-filter="<?= e($filterKey) ?>" data-vehicle-readiness-count="<?= e((string) $filterCount) ?>"><?= e($filterLabel) ?> (<?= e((string) $filterCount) ?>)</a>
        <?php endif; ?>
      <?php endforeach; ?>
    </nav>

    <?php if (!$fleetReadinessItems): ?>
      <div class="dashboard-empty-state fleet-readiness-empty">
        <strong><?= $fleetReadinessFilter === 'all' ? 'В текущем контуре нет машин.' : 'Нет машин в этом фильтре.' ?></strong>
        <span><?= $fleetReadinessFilter === 'ready' ? 'Все готовые машины уже показаны в общем списке.' : 'Можно открыть общий список или календарь парка.' ?></span>
        <a href="cars.php?view=readiness&state=<?= e($fleetState) ?>&ready=all">Показать все</a>
      </div>
    <?php else: ?>
      <div class="fleet-readiness-list">
        <?php foreach ($fleetReadinessItems as $item): ?>
          <?php
            $statusMeta = $fleetReadinessStatuses[$item['status']] ?? $fleetReadinessStatuses['unknown'];
            $image = trim((string) $item['image']);
            $readinessItemCar = is_array($item['car'] ?? null) ? $item['car'] : [];
            $readinessItemCanEdit = $readinessItemCar !== [] && car_readiness_can_edit_car($readinessItemCar);
            $readinessItemFormUrl = car_readiness_form_action_url((string) $item['slug'], 'readiness', $fleetReadinessFilter);
            $readinessItemMaintenanceFormUrl = car_readiness_form_action_url((string) $item['slug'], 'readiness', $fleetReadinessFilter, [], 'maintenance');
            $readinessItemServiceHoldFormUrl = car_readiness_form_action_url((string) $item['slug'], 'readiness', $fleetReadinessFilter, [], 'service_hold');
          ?>
          <article class="fleet-readiness-card" id="readiness-<?= e($item['slug']) ?>">
            <div class="fleet-readiness-media">
              <?php if ($image !== ''): ?>
                <img src="../<?= e($image) ?>" alt="">
              <?php else: ?>
                <span>Фото не задано</span>
              <?php endif; ?>
            </div>
            <div class="fleet-readiness-body">
              <div class="fleet-readiness-title-row">
                <div>
                  <h3><?= e($item['name']) ?></h3>
                  <p class="muted"><?= e($item['plate'] !== '' ? $item['plate'] : 'Госномер не указан') ?> · <?= e($item['owner']) ?></p>
                </div>
                <span class="status <?= e($statusMeta['class']) ?>"><?= e($statusMeta['label']) ?></span>
              </div>

              <?php if ($item['events']): ?>
                <div class="fleet-readiness-next">
                  <strong>Ближайшее:</strong> <?= e(implode(' · ', array_slice($item['events'], 0, 2))) ?>
                </div>
              <?php else: ?>
                <div class="fleet-readiness-next muted">Ближайших событий по арендам, броням или сервису не найдено.</div>
              <?php endif; ?>

              <?php if ($item['reasons']): ?>
                <div class="fleet-readiness-decision is-<?= e((string) $item['status']) ?>">
                  <strong><?= e(car_readiness_panel_title((string) $item['status'])) ?></strong>
                  <span>Ниже показаны конкретные причины и действие для оператора.</span>
                </div>
                <div class="fleet-readiness-issues">
                  <?php foreach (array_slice($item['reasons'], 0, 6) as $reason): ?>
                    <?= car_readiness_issue_html($readinessItemCar, $reason, $readinessItemCanEdit, [], (string) ($reason['link'] !== '' ? $reason['link'] : '#readiness-' . $item['slug'])) ?>
                  <?php endforeach; ?>
                </div>
              <?php else: ?>
                <p class="fleet-readiness-ok">По известным признакам машина готова к работе.</p>
              <?php endif; ?>

              <div class="fleet-readiness-actions">
                <?php foreach ($item['links'] as $link): ?>
                  <a class="small-link" href="<?= e($link['href']) ?>"><?= e($link['label']) ?></a>
                <?php endforeach; ?>
              </div>
            </div>
            <?= car_readiness_modals_html($readinessItemCar, $item['reasons'], $readinessItemFormUrl, ['maintenance' => $readinessItemMaintenanceFormUrl, 'service_hold' => $readinessItemServiceHoldFormUrl]) ?>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>
<?php elseif ($view === 'table'): ?>
  <section class="panel fleet-table-panel">
    <div class="report-table-wrap">
      <table class="report-table fleet-table">
        <thead>
          <tr>
            <th>Автомобиль</th>
            <th>Статус сегодня</th>
            <th>Пробег</th>
            <th>Последнее ТО</th>
            <th>Следующее ТО</th>
            <th>Остаток до ТО</th>
            <th>Занятость 60 дней</th>
            <?php if ($canManageRentRkShowcase): ?><th>Публикация</th><?php endif; ?>
            <?php if ($canManageRentRkShowcase): ?><th>Партнёрам Rent RK</th><?php endif; ?>
            <th>Действия</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($cars as $car): ?>
            <?php
              $slug = (string) ($car['slug'] ?? '');
              $dates = $availability[$slug] ?? [];
              $count = 0;
              if (is_array($dates)) {
                  foreach ($dates as $date => $entry) {
                      $parsed = parse_date_value((string) $date);
                      if ($parsed && $parsed >= $today && $parsed <= $limit) {
                          $count++;
                      }
                  }
              }
              $service = car_service_state($car);
              $serviceDistanceText = (string) ($service['status'] ?? '') === 'overdue'
                  ? 'Просрочено ' . number_format((int) ($service['overdueMileage'] ?? 0), 0, '', ' ') . ' км'
                  : number_format((int) $service['remainingMileage'], 0, '', ' ') . ' км';
              $status = availability_status_for_date($slug, $today->format('Y-m-d'));
              $statusLabel = availability_statuses_with_free()[$status] ?? $status;
              $isArchived = car_is_archived($car);
              $deleteSummary = car_delete_dependency_summary($slug);
              $publicationSummary = car_publication_summary($car);
            ?>
            <tr>
              <th><a href="#<?= e($slug) ?>"><?= e($car['name'] ?? '') ?></a><?= $isArchived ? ' <span class="status status-canceled">Архив</span>' : '' ?><br><span class="muted"><?= e($car['class'] ?? '') ?> · <?= e($car['seats'] ?? '') ?> мест</span></th>
              <td><span class="status status-<?= e($status) ?>"><?= e($statusLabel) ?></span></td>
              <td><?= e(number_format($service['currentMileage'], 0, '', ' ')) ?> км</td>
              <td><?= e(number_format($service['lastServiceMileage'], 0, '', ' ')) ?> км</td>
              <td class="<?= (string) ($service['status'] ?? '') === 'overdue' ? 'is-service-overdue' : '' ?>"><?= e(number_format($service['nextServiceMileage'], 0, '', ' ')) ?> км</td>
              <td class="<?= (string) ($service['status'] ?? '') === 'overdue' ? 'is-service-overdue' : '' ?>"><?= e($serviceDistanceText) ?></td>
              <td><?= e((string) $count) ?></td>
              <?php if ($canManageRentRkShowcase): ?><td><span class="status <?= $publicationSummary['isPublicVisible'] ? 'status-free' : 'status-canceled' ?>"><?= e($publicationSummary['publicLabel']) ?></span><br><span class="muted"><?= e($publicationSummary['adminLabel']) ?></span></td><?php endif; ?>
              <?php if ($canManageRentRkShowcase): ?><td><?= car_available_for_rent_rk_partners($car) ? 'да' : 'нет' ?></td><?php endif; ?>
              <td>
                <div class="table-actions">
                  <?php if ($showLessorPublicationWorkflow && car_owner_type($car) === 'lessor'): ?>
                    <?= lessor_publication_badge($car) ?>
                  <?php endif; ?>
                  <a class="small-link" href="calendar.php?car=<?= urlencode($slug) ?>">Календарь</a>
                  <?php if ($isScopedLessor): ?>
                    <a class="small-link" href="requests.php?car=<?= urlencode($slug) ?>">Заявки</a>
                    <?php if (has_permission('rentals.view')): ?><a class="small-link" href="rentals.php?car=<?= urlencode($slug) ?>">Аренды</a><?php endif; ?>
                  <?php endif; ?>
                  <?php if (!$isScopedLessor): ?>
                    <a class="small-link" href="task-create.php?car=<?= urlencode($slug) ?>&type=service">Задача ТО</a>
                  <?php endif; ?>
                  <?php if ($isArchived): ?>
                    <form method="post">
                      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                      <input type="hidden" name="action" value="restore_car">
                      <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
                      <button class="small-link link-button" type="submit">Восстановить</button>
                    </form>
                    <?php if (current_admin_role() === 'admin' && $deleteSummary['can_delete']): ?>
                      <form method="post" onsubmit="return confirm('Физически удалить автомобиль? Это действие нельзя отменить.');">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="action" value="delete_car">
                        <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
                        <button class="small-link link-button" type="submit">Удалить</button>
                      </form>
                    <?php endif; ?>
                  <?php else: ?>
                    <form method="post" onsubmit="return confirm('Архивировать автомобиль? История останется доступной.');">
                      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                      <input type="hidden" name="action" value="archive_car">
                      <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
                      <input type="hidden" name="archive_reason" value="Архивировано из таблицы автопарка">
                      <button class="small-link link-button" type="submit">Архивировать</button>
                    </form>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>
<?php else: ?>
<section class="cars-admin-grid <?= $view === 'detail' ? 'cars-detail-grid' : '' ?>">
  <?php foreach ($cars as $car): ?>
    <?php
      $slug = (string) ($car['slug'] ?? '');
      $dates = $availability[$slug] ?? [];
      $count = 0;
      if (is_array($dates)) {
          foreach ($dates as $date => $entry) {
              $parsed = parse_date_value((string) $date);
              if ($parsed && $parsed >= $today && $parsed <= $limit) {
                  $count++;
              }
          }
      }
      $service = car_service_state($car);
      $availableForRentRkPartners = car_available_for_rent_rk_partners($car);
      $publicationSummary = car_publication_summary($car);
      $mileagePolicy = car_mileage_policy($car);
      $documents = normalize_car_document_fields($car);
      $carFinance = normalize_car_finance_fields($car);
      $photos = car_photos($car);
      $mainPhotoPath = trim(str_replace('\\', '/', (string) ($car['image'] ?? '')));
      $mainPhotoExists = $mainPhotoPath !== '' && car_photo_file_exists($mainPhotoPath);
      $fineScopeId = car_owner_scope_id($car);
      $fineSettings = scope_fine_settings($fineScopeId);
      $fineBalance = scope_balance($fineScopeId);
      $lastFineCheck = last_fine_check_for_car($slug);
      $carFineItems = array_values(array_filter(scoped_fines_for_current_user(), static fn(array $fine): bool => normalize_car_slug((string) ($fine['car_slug'] ?? $fine['carSlug'] ?? '')) === $slug));
      usort($carFineItems, static function (array $a, array $b): int {
          return strcmp((string) ($b['violationDateTime'] ?? $b['createdAt'] ?? ''), (string) ($a['violationDateTime'] ?? $a['createdAt'] ?? ''));
      });
      $carFinesCount = count($carFineItems);
      $carFineSummary = fine_summary_for_car($slug);
      $serviceStatusText = match ($service['status']) {
          'overdue' => 'ТО просрочено',
          'soon' => 'Скоро ТО',
          default => 'ТО по графику',
      };
      $serviceDistanceLabel = (string) ($service['status'] ?? '') === 'overdue' ? 'Просрочено ТО' : 'Остаток до ТО';
      $serviceDistanceValue = (string) ($service['status'] ?? '') === 'overdue'
          ? (int) ($service['overdueMileage'] ?? 0)
          : (int) ($service['remainingMileage'] ?? 0);
      $logItems = array_slice(service_log_for_car($slug), 0, 4);
      $isArchived = car_is_archived($car);
      $deleteSummary = car_delete_dependency_summary($slug);
      $carHub = car_hub_model_for_ui($car, $scopedRentalsForCarHub, $today, $canManageRentRkShowcase || current_admin_role() === 'manager', $isScopedLessor);
      $carHubReadinessStatuses = fleet_readiness_statuses_for_ui();
      $carHubStatusMeta = $carHubReadinessStatuses[$carHub['readiness']['status'] ?? 'unknown'] ?? $carHubReadinessStatuses['unknown'];
      $carCanViewTariffs = current_user_can_view_tariffs(car_owner_scope_id($car));
      $carCanEditTariffs = current_user_can_edit_tariffs(car_owner_scope_id($car));
      $visibleCarDetailTabs = $carDetailTabs;
      if (!$carCanViewTariffs) {
          unset($visibleCarDetailTabs['tariffs']);
      }
      $carTariff = car_hub_tariff_model_for_ui($slug, $car, $carCanEditTariffs);
      $detailReturnParams = $view === 'detail' ? car_detail_return_params() : [];
      $detailBackUrl = admin_safe_return_to($_GET['return_to'] ?? null, 'cars.php?view=cards&state=' . $fleetState);
      $currentAvailabilityStatus = availability_status_for_date($slug, $today->format('Y-m-d'));
      $currentAvailabilityLabel = availability_statuses_with_free()[$currentAvailabilityStatus] ?? $currentAvailabilityStatus;
      $carFineWizardUrl = 'fines.php?' . http_build_query([
          'scope_id' => $fineScopeId,
          'wizard' => 1,
          'quick_car_slug' => $slug,
          'return_to' => $view === 'detail' ? car_detail_tab_url($slug, 'fines', $detailReturnParams) : 'cars.php?view=cards#' . $slug,
      ]);
      $carRatesEditUrl = $carCanViewTariffs && $view === 'detail'
          ? 'rates.php?' . http_build_query(['return_to' => car_detail_tab_url($slug, 'tariffs', $detailReturnParams)]) . '#' . rawurlencode($slug)
          : ($carCanViewTariffs ? (string) ($carTariff['editUrl'] ?? '') : '');
      $canEditCarDocuments = car_readiness_can_edit_car($car);
      $carCanManageServiceHolds = car_readiness_can_manage_service_holds($car);
      $carNextAction = car_detail_next_action_for_ui($slug, $carHub, $canEditCarDocuments, $carCanManageServiceHolds, $detailReturnParams, $carDetailTabs);
      $documentWarnings = array_values(array_filter($carHub['readiness']['reasons'] ?? [], static fn(array $reason): bool => (string) ($reason['filter'] ?? '') === 'documents'));
      $serviceWarnings = array_values(array_filter($carHub['readiness']['reasons'] ?? [], static fn(array $reason): bool => (string) ($reason['filter'] ?? '') === 'service'));
      $carReadinessFormUrl = car_readiness_form_action_url($slug, $view, $fleetReadinessFilter, $detailReturnParams);
      $carMaintenanceFormUrl = car_readiness_form_action_url($slug, $view, $fleetReadinessFilter, $detailReturnParams, 'maintenance');
      $carServiceHoldFormUrl = car_readiness_form_action_url($slug, $view, $fleetReadinessFilter, $detailReturnParams, 'service_hold');
      $carServiceHoldModalKey = car_readiness_modal_key($slug, 'service_hold');
      $serviceStatusActionReason = null;
      if ($service['status'] === 'overdue') {
          foreach ($serviceWarnings as $serviceWarning) {
              if (car_readiness_action_for_reason($serviceWarning) === 'maintenance') {
                  $serviceStatusActionReason = $serviceWarning;
                  break;
              }
          }
          if ($serviceStatusActionReason === null) {
              $serviceStatusActionReason = fleet_readiness_reason($serviceStatusText, 'danger', 'service');
          }
      }
      $latestAuditItems = [];
      if ($view === 'detail') {
          $latestAuditItems = array_slice(array_values(array_filter(read_audit_log()['items'] ?? [], static function ($item) use ($slug): bool {
              return is_array($item)
                  && (string) ($item['entityType'] ?? '') === 'car'
                  && (string) ($item['entityId'] ?? '') === $slug;
          })), 0, 5);
      }
    ?>
    <article class="car-admin-card car-service-card <?= $view === 'detail' ? 'car-detail-card' : '' ?>" id="<?= e($slug) ?>">
      <?php if (trim((string) ($car['image'] ?? '')) !== ''): ?>
        <img src="../<?= e($car['image'] ?? '') ?>" alt="">
      <?php else: ?>
        <div class="car-admin-placeholder">Фото не выбрано</div>
      <?php endif; ?>
      <div>
        <?php if ($view === 'detail'): ?>
          <nav class="car-detail-tabs" id="car-tabs" role="tablist" aria-label="Разделы карточки автомобиля">
            <?php foreach ($visibleCarDetailTabs as $tabKey => $tabLabel): ?>
              <a
                class="<?= $activeCarTab === $tabKey ? 'is-active' : '' ?>"
                href="<?= e(car_detail_tab_url($slug, $tabKey, $detailReturnParams)) ?>"
                role="tab"
                data-car-detail-tab="<?= e($tabKey) ?>"
                aria-selected="<?= $activeCarTab === $tabKey ? 'true' : 'false' ?>"
              ><?= e($tabLabel) ?></a>
            <?php endforeach; ?>
          </nav>
        <?php else: ?>
          <h2 class="car-card-title"><?= e($car['name'] ?? '') ?></h2>
          <div class="car-card-plate-line">
            <small class="car-card-plate<?= trim((string) $carHub['plate']) === '' ? ' is-missing' : '' ?>"><?= car_card_plate_html((string) $carHub['plate']) ?></small>
          </div>
          <?php if ($isArchived): ?>
            <p><span class="status status-canceled">Архив</span> <span class="muted">с <?= e($car['archivedAt'] !== '' ? format_admin_datetime((string) $car['archivedAt']) : 'дата не указана') ?><?= $car['archivedBy'] !== '' ? ', ' . e((string) $car['archivedBy']) : '' ?></span></p>
          <?php endif; ?>
          <p class="muted"><?= e($car['class'] ?? '') ?> · <?= e($car['seats'] ?? '') ?> мест</p>
          <p><strong><?= e(car_ownership_types()[$carFinance['ownershipType']] ?? $carFinance['ownershipType']) ?></strong><?= $carFinance['ownerName'] !== '' ? ' · ' . e($carFinance['ownerName']) : '' ?></p>
          <p><strong><?= $count ?></strong> отмеченных дат на 60 дней</p>
          <?php if ($serviceStatusActionReason !== null): ?>
            <p class="car-service-status-action"><?= car_readiness_reason_html($car, $serviceStatusActionReason, $canEditCarDocuments, $detailReturnParams, '', $serviceStatusText) ?></p>
          <?php else: ?>
            <p class="status status-<?= e($service['status'] === 'soon' ? 'reserved' : 'free') ?>"><?= e($serviceStatusText) ?></p>
          <?php endif; ?>
          <div class="car-compact-summary">
            <div class="service-metrics">
              <span class="car-contract-metric car-vin-metric <?= $documents['vin'] === '' ? 'is-missing' : 'is-filled' ?>">VIN для договора <strong><?= e($documents['vin'] !== '' ? $documents['vin'] : 'не указан') ?></strong></span>
              <span class="car-contract-metric <?= (($documents['marketValue'] ?? null) === null || (int) $documents['marketValue'] <= 0) ? 'is-missing' : 'is-filled' ?>">Рыночная стоимость <strong><?= e((($documents['marketValue'] ?? null) === null || (int) $documents['marketValue'] <= 0) ? 'не указана' : format_money((int) $documents['marketValue'])) ?></strong></span>
              <span>Статус <strong><?= e($carHubStatusMeta['label']) ?></strong></span>
              <?php if ($canManageRentRkShowcase): ?><span>Публикация <strong><?= e($publicationSummary['publicLabel']) ?></strong></span><?php endif; ?>
              <span class="car-contract-metric <?= (($carTariff['primaryPrice'] ?? null) === null || (int) $carTariff['primaryPrice'] <= 0) ? 'is-missing' : 'is-filled' ?>">Цена <strong><?= e((($carTariff['primaryPrice'] ?? null) === null || (int) $carTariff['primaryPrice'] <= 0) ? 'не задана' : format_money((int) $carTariff['primaryPrice'])) ?></strong></span>
              <span class="car-contract-metric <?= (($carTariff['deposit'] ?? null) === null || (int) $carTariff['deposit'] <= 0) ? 'is-missing' : 'is-filled' ?>">Залог <strong><?= e((($carTariff['deposit'] ?? null) === null || (int) $carTariff['deposit'] <= 0) ? 'не задан' : format_money((int) $carTariff['deposit'])) ?></strong></span>
              <span class="car-contract-metric <?= ($mainPhotoExists || count($photos) > 0) ? 'is-filled' : 'is-missing' ?>">Фото <strong><?= e($mainPhotoExists ? 'главное есть' : (count($photos) > 0 ? (string) count($photos) : 'нет')) ?></strong></span>
              <span>Открытые штрафы <strong><?= e((string) ($carHub['fineSummary']['openCount'] ?? 0)) ?></strong></span>
            </div>
            <div class="car-hub-next car-card-next is-<?= e((string) ($carHub['nextAction']['tone'] ?? 'ok')) ?>">
              <strong>Следующий шаг</strong>
              <?php if ((string) ($carNextAction['href'] ?? '') !== ''): ?>
                <a href="<?= e((string) $carNextAction['href']) ?>"><?= e((string) ($carHub['nextAction']['label'] ?? 'Открыть карточку')) ?></a>
              <?php else: ?>
                <span aria-disabled="true"><?= e((string) ($carHub['nextAction']['label'] ?? 'Машина готова к работе')) ?></span>
              <?php endif; ?>
            </div>
            <?php if (!empty($carHub['rentals']['active'][0])): ?>
              <p class="muted">Сейчас: <a href="<?= e((string) $carHub['rentals']['active'][0]['href']) ?>"><?= e((string) $carHub['rentals']['active'][0]['number']) ?></a> · <?= e((string) $carHub['rentals']['active'][0]['period']) ?></p>
            <?php elseif (!empty($carHub['rentals']['future'][0])): ?>
              <p class="muted">Ближайшая бронь/аренда: <a href="<?= e((string) $carHub['rentals']['future'][0]['href']) ?>"><?= e((string) $carHub['rentals']['future'][0]['number']) ?></a> · <?= e((string) $carHub['rentals']['future'][0]['period']) ?></p>
            <?php else: ?>
              <p class="muted">Ближайших активных или будущих аренд по машине не найдено.</p>
            <?php endif; ?>
            <?php if (!empty($carHub['readiness']['reasons'])): ?>
              <div class="car-compact-reasons">
                <?php foreach (array_slice($carHub['readiness']['reasons'], 0, 2) as $reason): ?>
                  <?= car_readiness_reason_html($car, $reason, $canEditCarDocuments, $detailReturnParams) ?>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
            <div class="car-compact-actions">
              <a class="btn" href="<?= e('cars.php?view=' . rawurlencode($slug) . '&return_to=' . rawurlencode('cars.php?view=cards&state=' . $fleetState)) ?>">Подробнее</a>
              <?php if (can_view_car_page_content_editor($car)): ?><a class="btn secondary" href="<?= e('cars/page-content.php?slug=' . rawurlencode($slug)) ?>">Page-content</a><?php endif; ?>
              <a class="btn secondary" href="<?= e($carHub['links']['calendar']) ?>">Календарь</a>
              <a class="btn secondary" href="<?= e($carHub['links']['finesWizard']) ?>">Штраф по номеру</a>
              <?php if (!empty($carHub['rentals']['active'][0]['href'])): ?><a class="btn secondary" href="<?= e((string) $carHub['rentals']['active'][0]['href']) ?>">Активная аренда</a><?php endif; ?>
            </div>
          </div>
          <?= car_readiness_modals_html($car, $carHub['readiness']['reasons'] ?? [], $carReadinessFormUrl, ['maintenance' => $carMaintenanceFormUrl, 'service_hold' => $carServiceHoldFormUrl]) ?>
        </div>
    </article>
    <?php continue; ?>
        <?php endif; ?>
        <section class="car-operational-hub car-summary-panel" id="<?= $view === 'detail' ? 'summary' : e($slug) . '-summary' ?>"<?= car_detail_panel_attrs('summary', $activeCarTab) ?>>
          <div class="car-summary-split">
            <div class="car-summary-box">
              <h3>Краткие технические данные</h3>
              <div class="service-metrics">
                <span>Класс <strong><?= e((string) ($car['class'] ?? 'не указан')) ?></strong></span>
                <span>Привод <strong><?= e((string) (($car['drive'] ?? '') ?: 'не указан')) ?></strong></span>
                <span>Коробка <strong><?= e((string) (($car['transmission'] ?? '') ?: 'не указана')) ?></strong></span>
                <span>Двигатель <strong><?= e((string) (($car['engine'] ?? '') ?: 'не указан')) ?></strong></span>
                <span class="car-contract-metric <?= $documents['vin'] === '' ? 'is-missing' : 'is-filled' ?>">VIN <strong><?= e($documents['vin'] !== '' ? $documents['vin'] : 'не указан') ?></strong><small>идёт в договор</small></span>
                <span class="car-contract-metric <?= (($documents['marketValue'] ?? null) === null || (int) $documents['marketValue'] <= 0) ? 'is-missing' : 'is-filled' ?>">Рыночная стоимость <strong><?= e((($documents['marketValue'] ?? null) === null || (int) $documents['marketValue'] <= 0) ? 'не указана' : format_money((int) $documents['marketValue'])) ?></strong><small>идёт в договор</small></span>
              </div>
            </div>
            <div class="car-summary-box">
              <h3>Ближайшие события и изменения</h3>
              <?php if (!empty($carHub['readiness']['events'])): ?>
                <ul class="compact-list">
                  <?php foreach (array_slice($carHub['readiness']['events'], 0, 4) as $eventLabel): ?><li><?= e((string) $eventLabel) ?></li><?php endforeach; ?>
                </ul>
              <?php elseif (!empty($carHub['rentals']['future'][0])): ?>
                <p class="muted">Ближайшая запись: <a href="<?= e((string) $carHub['rentals']['future'][0]['href']) ?>"><?= e((string) $carHub['rentals']['future'][0]['number']) ?></a> · <?= e((string) $carHub['rentals']['future'][0]['period']) ?></p>
              <?php else: ?>
                <p class="muted">Ближайших событий по машине не найдено.</p>
              <?php endif; ?>
              <?php if ($latestAuditItems): ?>
                <ul class="compact-list">
                  <?php foreach (array_slice($latestAuditItems, 0, 3) as $auditItem): ?><li><?= e(format_admin_datetime((string) ($auditItem['createdAt'] ?? ''))) ?> · <?= e((string) ($auditItem['summary'] ?? $auditItem['action'] ?? 'Изменение')) ?></li><?php endforeach; ?>
                </ul>
              <?php endif; ?>
            </div>
          </div>
        </section>

        <?php if ($carCanViewTariffs): ?>
        <section class="car-tariff-hub car-hub-panel" id="rates"<?= car_detail_panel_attrs('tariffs', $activeCarTab) ?>>
          <div class="car-hub-head">
            <div>
              <p class="eyebrow">Условия продажи и выдачи</p>
              <h3>Тарифы и условия аренды</h3>
              <p class="muted">Read-only сводка по текущей тарифной модели. Расчёты аренды и публичные тарифы здесь не меняются.</p>
            </div>
            <?php if ($carRatesEditUrl !== ''): ?>
              <a class="btn secondary" href="<?= e($carRatesEditUrl) ?>"><?= $carCanEditTariffs ? 'Настроить тарифы' : 'Открыть тарифы' ?></a>
            <?php endif; ?>
          </div>
          <div class="car-tariff-summary">
            <span>Базовая цена <strong><?= e($carTariff['primaryPrice'] === null ? 'не задана' : format_money((int) $carTariff['primaryPrice']) . '/сутки') ?></strong></span>
            <span>Залог <strong><?= e($carTariff['deposit'] === null ? 'не задан' : format_money((int) $carTariff['deposit'])) ?></strong><small><?= e($carTariff['depositSource'] === 'car' ? 'индивидуальный' : 'по умолчанию') ?></small></span>
            <span>Лимит пробега <strong><?= e(number_format((int) $carTariff['mileageLimitPerDay'], 0, '', ' ')) ?> км/сутки</strong></span>
            <span>Перепробег <strong><?= e($carTariff['extraMileageRate'] === null ? 'не задан' : format_money((int) $carTariff['extraMileageRate']) . '/км') ?></strong></span>
          </div>
          <?php if ($carTariff['prices']): ?>
            <div class="car-tariff-grid">
              <?php foreach ($carTariff['prices'] as $priceRow): ?>
                <div class="car-tariff-card">
                  <span><?= e((string) $priceRow['label']) ?></span>
                  <strong><?= e(format_money((int) $priceRow['amount'])) ?></strong>
                  <?php if ((string) $priceRow['note'] !== ''): ?><small><?= e((string) $priceRow['note']) ?></small><?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <p class="notice warning">Тарифы по машине не заполнены. Проверьте базовую цену и правила в разделе тарифов.</p>
          <?php endif; ?>
          <?php if ($carTariff['warnings']): ?>
            <div class="car-tariff-warnings">
              <?php foreach ($carTariff['warnings'] as $warning): ?>
                <span class="fleet-readiness-reason is-warning"><?= e((string) $warning) ?></span>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
          <ul class="compact-list car-tariff-conditions">
            <?php foreach ($carTariff['conditions'] as $condition): ?>
              <li><?= e((string) $condition) ?></li>
            <?php endforeach; ?>
          </ul>
        </section>
        <?php endif; ?>

        <section class="car-hub-grid car-detail-tab-panel" data-car-detail-panel-group="rentals service fines history" <?= !in_array($activeCarTab, ['rentals', 'service', 'fines', 'history'], true) ? 'hidden' : '' ?>>
          <div class="car-hub-panel" id="rentals"<?= car_detail_panel_attrs('rentals', $activeCarTab) ?>>
            <h3>Аренды и брони по машине</h3>
            <div class="button-row">
              <a class="btn secondary" href="<?= e($carHub['links']['calendar']) ?>">Календарь автомобиля</a>
              <a class="btn secondary" href="<?= e($carHub['links']['rentals']) ?>">Все аренды по машине</a>
              <a class="btn secondary" href="<?= e($carHub['links']['archiveRentals']) ?>">Архивные аренды</a>
            </div>
            <?php foreach ([
                'active' => 'Активная аренда',
                'future' => 'Ближайшие брони/аренды',
                'recent' => 'Последние закрытые',
                'archive' => 'Архивные аренды',
            ] as $bucket => $title): ?>
              <div class="car-hub-list-block">
                <strong><?= e($title) ?></strong>
                <?php if (empty($carHub['rentals'][$bucket])): ?>
                  <p class="muted">Нет записей.</p>
                <?php else: ?>
                  <?php foreach ($carHub['rentals'][$bucket] as $row): ?>
                    <a class="car-hub-row" href="<?= e((string) $row['href']) ?>">
                      <span><strong><?= e((string) $row['number']) ?></strong><?= !empty($row['isArchive']) ? ' <em>Архив</em>' : '' ?><br><small><?= e((string) $row['period']) ?><?= $row['client'] !== '' ? ' · ' . e((string) $row['client']) : '' ?></small></span>
                      <span><?= e((string) $row['status']) ?><?php if ($row['amount'] !== null): ?><br><small><?= e(format_money((int) $row['amount'])) ?> / <?= e(format_money((int) $row['paid'])) ?></small><?php endif; ?></span>
                    </a>
                  <?php endforeach; ?>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>

          <?php if ($carHub['canSeeArchiveFinance'] && is_array($carHub['archiveStats'])): ?>
            <div class="car-hub-panel" id="<?= $view === 'detail' ? 'archive-finance' : e($slug) . '-archive-finance' ?>"<?= car_detail_panel_attrs('history', $activeCarTab) ?>>
              <h3>Архивная статистика по машине</h3>
              <p class="muted">Статистический снимок по архивным договорам. Это не ledger и не рабочая задолженность.</p>
              <div class="service-metrics">
                <span>Архивных аренд <strong><?= e((string) ($carHub['archiveStats']['rentalsCount'] ?? 0)) ?></strong></span>
                <span>Дней аренды <strong><?= e((string) ($carHub['archiveStats']['daysTotal'] ?? 0)) ?></strong></span>
                <span>Сумма договоров <strong><?= e(format_money((int) ($carHub['archiveStats']['totalAmount'] ?? 0))) ?></strong></span>
                <span>Оплачено <strong><?= e(format_money((int) ($carHub['archiveStats']['paidAmount'] ?? 0))) ?></strong></span>
                <span>Удержано залога <strong><?= e(format_money((int) ($carHub['archiveStats']['depositWithheld'] ?? 0))) ?></strong></span>
                <span>Исторический долг <strong><?= e(format_money((int) ($carHub['archiveStats']['debtAmount'] ?? 0))) ?></strong></span>
                <span>Неполные финансы <strong><?= e((string) ($carHub['archiveStats']['financeIncompleteCount'] ?? 0)) ?></strong></span>
              </div>
            </div>
          <?php endif; ?>

          <div class="car-hub-panel" id="<?= $view === 'detail' ? 'fines' : e($slug) . '-fines' ?>"<?= car_detail_panel_attrs('fines', $activeCarTab) ?>>
            <h3>Штрафы по машине</h3>
            <div class="service-metrics">
              <span>Всего найдено <strong><?= e((string) $carFinesCount) ?></strong></span>
              <span>Открытые <strong><?= e((string) ($carHub['fineSummary']['openCount'] ?? 0)) ?></strong></span>
              <span>Без привязки <strong><?= e((string) ($carHub['fineSummary']['unlinkedCount'] ?? 0)) ?></strong></span>
              <span>К оплате/разбору <strong><?= e(fine_money((float) ($carHub['fineSummary']['openAmount'] ?? 0))) ?></strong></span>
            </div>
            <div class="button-row">
              <a class="btn secondary" href="<?= e($carFineWizardUrl) ?>">Штраф по номеру</a>
              <a class="btn secondary" href="fines.php?car=<?= urlencode($slug) ?>">Открыть штрафы</a>
            </div>
            <?php if ($carFineItems): ?>
              <ul class="compact-list">
                <?php foreach (array_slice($carFineItems, 0, 4) as $fine): ?>
                  <?php
                    $fineId = (string) ($fine['id'] ?? '');
                    $fineNumber = (string) ($fine['fineNumber'] ?? $fine['uin'] ?? $fine['provider_fine_id'] ?? $fineId);
                    $fineStatus = (string) ($fine['status'] ?? '');
                    $fineHref = 'fines.php?' . http_build_query([
                        'scope_id' => $fineScopeId,
                        'tab' => 'fines',
                        'car_slug' => $slug,
                    ]) . ($fineId !== '' ? '#fine-' . rawurlencode($fineId) : '');
                  ?>
                  <li>
                    <a href="<?= e($fineHref) ?>"><?= e($fineNumber !== '' ? $fineNumber : 'Штраф') ?></a>
                    <span class="muted"><?= e((string) (fine_statuses()[$fineStatus] ?? ($fineStatus !== '' ? $fineStatus : 'Статус не указан'))) ?><?= isset($fine['amount']) ? ' · ' . e(fine_money((float) $fine['amount'])) : '' ?></span>
                  </li>
                <?php endforeach; ?>
              </ul>
            <?php else: ?>
              <p class="muted">По этой машине нет зафиксированных штрафов.</p>
            <?php endif; ?>
          </div>

          <div class="car-hub-panel" id="<?= $view === 'detail' ? 'service' : e($slug) . '-service' ?>"<?= car_detail_panel_attrs('service', $activeCarTab) ?>>
            <h3>Недоступность и сервис</h3>
            <div class="service-metrics">
              <span>ТО <strong><?= e($serviceStatusText) ?></strong></span>
              <span>Активные удержания <strong><?= e((string) count($carHub['serviceHolds'])) ?></strong></span>
              <span class="<?= (string) ($service['status'] ?? '') === 'overdue' ? 'is-service-overdue' : '' ?>"><?= e($serviceDistanceLabel) ?> <strong><?= e(number_format($serviceDistanceValue, 0, '', ' ')) ?> км</strong></span>
            </div>
            <?php if ($carHub['serviceHolds']): ?>
              <ul class="compact-list">
                <?php foreach (array_slice($carHub['serviceHolds'], 0, 4) as $hold): ?>
                  <li>
                    <?php if ($carCanManageServiceHolds): ?>
                      <button type="button" class="car-service-hold-inline-trigger" data-car-readiness-modal-open="<?= e($carServiceHoldModalKey) ?>"><?= e((string) (($hold['reason'] ?? '') ?: ($hold['status'] ?? 'service'))) ?></button>
                    <?php else: ?>
                      <span><?= e((string) (($hold['reason'] ?? '') ?: ($hold['status'] ?? 'service'))) ?></span>
                    <?php endif; ?>
                    <?= (string) ($hold['readyDate'] ?? '') !== '' ? ' до ' . e(format_ru_date((string) $hold['readyDate'])) : '' ?>
                  </li>
                <?php endforeach; ?>
              </ul>
            <?php else: ?>
              <p class="muted">Активных сервисных удержаний нет.</p>
            <?php endif; ?>
            <div class="button-row">
              <?php if ($carCanManageServiceHolds && $carHub['serviceHolds']): ?><button class="btn secondary" type="button" data-car-readiness-modal-open="<?= e($carServiceHoldModalKey) ?>">Открыть сервисное удержание</button><?php endif; ?>
              <?php if (!$isScopedLessor && !$carHub['serviceHolds']): ?><a class="btn secondary" href="<?= e($carHub['links']['serviceHold']) ?>">Создать сервисное удержание</a><?php endif; ?>
              <?php if (!$isScopedLessor): ?><a class="btn secondary" href="task-create.php?car=<?= urlencode($slug) ?>&type=service">Задача ТО</a><?php endif; ?>
            </div>
          </div>
        </section>
        <div class="car-detail-tab-panel"<?= car_detail_panel_attrs('publication', $activeCarTab) ?>>
        <?php if ($showLessorPublicationWorkflow && car_owner_type($car) === 'lessor'): ?>
          <?php $lessorPublicationSummary = lessor_publication_readiness_summary($car); ?>
          <details class="service-details lessor-publication-panel" open>
            <summary>Готовность публикации</summary>
            <div class="service-metrics">
              <span>Статус <strong><?= e($lessorPublicationSummary['label']) ?></strong></span>
              <span>Арендодатель <strong><?= e(car_lessor_slug($car) !== '' ? car_lessor_slug($car) : 'не указан') ?></strong></span>
              <span>Отправлено <strong><?= e($lessorPublicationSummary['submittedAt'] !== '' ? format_admin_datetime((string) $lessorPublicationSummary['submittedAt']) : 'нет') ?></strong></span>
              <span>Review <strong><?= e($lessorPublicationSummary['reviewedAt'] !== '' ? format_admin_datetime((string) $lessorPublicationSummary['reviewedAt']) : 'нет') ?></strong></span>
              <span>Rent RK public <strong><?= $lessorPublicationSummary['isPublishedOnRentRk'] ? 'да' : 'нет' ?></strong></span>
              <span>Blockers <strong><?= e((string) count($lessorPublicationSummary['blockers'])) ?></strong></span>
              <span>Warnings <strong><?= e((string) count($lessorPublicationSummary['warnings'])) ?></strong></span>
            </div>
            <?php if ($lessorPublicationSummary['reviewComment'] !== ''): ?>
              <p class="field-hint rate-field-wide">Комментарий Rent RK: <?= e($lessorPublicationSummary['reviewComment']) ?></p>
            <?php endif; ?>
            <?php if ($lessorPublicationSummary['submitComment'] !== '' && $canManageLessorPublication): ?>
              <p class="field-hint rate-field-wide">Комментарий арендодателя: <?= e($lessorPublicationSummary['submitComment']) ?></p>
            <?php endif; ?>
            <div class="publication-readiness">
              <?php if ($lessorPublicationSummary['completed']): ?>
                <div><strong>Готово</strong><ul class="publication-checklist"><?php foreach ($lessorPublicationSummary['completed'] as $item): ?><li><?= e($item) ?></li><?php endforeach; ?></ul></div>
              <?php endif; ?>
              <?php if ($lessorPublicationSummary['warnings']): ?>
                <div><strong>Warnings</strong><ul class="publication-warning-list"><?php foreach ($lessorPublicationSummary['warnings'] as $item): ?><li><?= e($item) ?></li><?php endforeach; ?></ul></div>
              <?php endif; ?>
              <?php if ($lessorPublicationSummary['blockers']): ?>
                <div><strong>Нельзя отправить</strong><ul class="publication-warning-list"><?php foreach ($lessorPublicationSummary['blockers'] as $item): ?><li><?= e($item) ?></li><?php endforeach; ?></ul></div>
              <?php endif; ?>
            </div>
            <?php if ($isScopedLessor): ?>
              <?php if (lessor_can_submit_car_for_review($car)): ?>
                <form method="post" action="<?= e(car_detail_tab_url($slug, 'publication', $detailReturnParams)) ?>" class="service-form lessor-publication-form">
                  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="action" value="lessor_public_submit">
                  <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
                  <label class="rate-field-wide">Комментарий для Rent RK <textarea name="lessor_comment" rows="2" maxlength="240" placeholder="Коротко: что обновлено или что нужно проверить"></textarea></label>
                  <p class="field-hint rate-field-wide">Отправка не публикует машину на сайте Rent RK и не добавляет канал rent_rk_public.</p>
                  <button class="btn secondary" type="submit">Отправить на проверку</button>
                </form>
              <?php elseif ($lessorPublicationSummary['status'] === 'submitted'): ?>
                <p class="field-hint rate-field-wide">Машина уже отправлена на проверку. Rent RK увидит ее в очереди.</p>
              <?php endif; ?>
            <?php endif; ?>
            <?php if ($canManageLessorPublication): ?>
              <form method="post" action="<?= e(car_detail_tab_url($slug, 'publication', $detailReturnParams)) ?>" class="service-form lessor-publication-review-form">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="lessor_public_review">
                <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
                <label class="rate-field-wide">Комментарий Rent RK <textarea name="review_comment" rows="2" maxlength="240"><?= e($lessorPublicationSummary['reviewComment']) ?></textarea></label>
                <div class="button-row rate-field-wide">
                  <button class="btn secondary" type="submit" name="decision" value="approved">Одобрить</button>
                  <button class="btn secondary" type="submit" name="decision" value="changes_requested">Запросить правки</button>
                  <button class="btn secondary" type="submit" name="decision" value="rejected">Отклонить</button>
                  <button class="btn secondary" type="submit" name="decision" value="suspended">Приостановить</button>
                  <button class="btn" type="submit" name="decision" value="publish" <?= $lessorPublicationSummary['blockers'] ? 'disabled' : '' ?>>Опубликовать на Rent RK</button>
                  <button class="btn secondary" type="submit" name="decision" value="hide">Скрыть с Rent RK</button>
                </div>
                <?php if ($lessorPublicationSummary['blockers']): ?><p class="field-hint rate-field-wide">Публикация заблокирована, пока есть blockers.</p><?php endif; ?>
              </form>
            <?php endif; ?>
          </details>
        <?php endif; ?>
        <?php if ($canManageRentRkShowcase): ?>
          <details class="service-details publication-status-panel" id="<?= $view === 'detail' ? 'publication' : e($slug) . '-publication' ?>">
            <summary>Публикация на сайте</summary>
            <div class="service-metrics">
              <span>Админ-статус <strong><?= e($publicationSummary['adminLabel']) ?></strong></span>
              <span>Публичный статус <strong><?= e($publicationSummary['publicLabel']) ?></strong></span>
              <span>Rent RK public <strong><?= $publicationSummary['isPublicVisible'] ? 'да' : 'нет' ?></strong></span>
              <span>Каналы <strong><?= e($publicationSummary['channelLabels'] ? implode(', ', $publicationSummary['channelLabels']) : 'нет') ?></strong></span>
              <span>Обновлено <strong><?= e($publicationSummary['publishUpdatedAt'] !== '' ? format_admin_datetime((string) $publicationSummary['publishUpdatedAt']) : 'не задано') ?></strong></span>
            </div>
            <form method="post" action="<?= e(car_detail_tab_url($slug, 'publication', $detailReturnParams)) ?>" class="service-form publication-status-form">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="publication_fields">
              <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
              <label>
                Админ-статус
                <select name="admin_status">
                  <?php foreach (car_publication_admin_statuses() as $statusKey => $statusLabel): ?>
                    <option value="<?= e($statusKey) ?>" <?= $publicationSummary['adminStatus'] === $statusKey ? 'selected' : '' ?>><?= e($statusLabel) ?></option>
                  <?php endforeach; ?>
                </select>
              </label>
              <label>
                Публичный статус
                <select name="public_status">
                  <?php foreach (car_publication_public_statuses() as $statusKey => $statusLabel): ?>
                    <option value="<?= e($statusKey) ?>" <?= $publicationSummary['publicStatus'] === $statusKey ? 'selected' : '' ?>><?= e($statusLabel) ?></option>
                  <?php endforeach; ?>
                </select>
              </label>
              <?php foreach (car_publication_channels() as $channelKey => $channelLabel): ?>
                <label class="check-row rate-field-wide">
                  <input type="checkbox" name="publish_channels[]" value="<?= e($channelKey) ?>" <?= in_array($channelKey, $publicationSummary['publishChannels'], true) ? 'checked' : '' ?>>
                  <span><?= e($channelLabel) ?></span>
                </label>
              <?php endforeach; ?>
              <label class="rate-field-wide">Причина блокировки / заметка <textarea name="publish_blocked_reason" rows="2"><?= e((string) $publicationSummary['publishBlockedReason']) ?></textarea></label>
              <p class="field-hint rate-field-wide">Арендодатель не может напрямую опубликовать машину на Rent RK public; изменение этого статуса доступно только администратору Rent RK. При сохранении публичный сайт и safe public JSON пересобираются.</p>
              <button class="btn secondary" type="submit">Сохранить публикацию</button>
            </form>
          </details>
          <details class="service-details">
            <summary>Витрина партнёров Rent RK</summary>
            <form method="post" action="<?= e(car_detail_tab_url($slug, 'publication', $detailReturnParams)) ?>" class="service-form">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="showcase_fields">
              <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
              <label class="check-row rate-field-wide">
                <input type="checkbox" name="available_for_rent_rk_partners" value="1" <?= $availableForRentRkPartners ? 'checked' : '' ?>>
                <span>Показывать партнёрам Rent RK</span>
              </label>
              <p class="field-hint rate-field-wide">Если включено, автомобиль будет доступен партнёрам Rent RK в общей партнёрской витрине. Если выключено, партнёры Rent RK не увидят этот автомобиль и не смогут создать по нему заявку.</p>
              <button class="btn secondary" type="submit">Сохранить видимость</button>
            </form>
          </details>
        <?php endif; ?>
        <section class="car-main-photo-panel">
          <div class="car-main-photo-current">
            <?php if ($mainPhotoExists): ?>
              <img src="../<?= e($mainPhotoPath) ?>" alt="">
            <?php else: ?>
              <div class="car-main-photo-empty">Фото не выбрано</div>
            <?php endif; ?>
            <div>
              <h3>Главное фото</h3>
              <p class="muted">Это изображение используется в карточке автомобиля и публичной витрине после штатной пересборки.</p>
              <?php if ($mainPhotoPath !== '' && !$mainPhotoExists): ?>
                <p class="field-hint warning">Текущий файл не найден. Загрузите новое фото, чтобы убрать битую ссылку.</p>
              <?php endif; ?>
              <?php if (current_admin_role() === 'admin' && $mainPhotoPath !== ''): ?>
                <details class="car-photo-path-fallback">
                  <summary>Технический путь к фото</summary>
                  <p class="field-hint"><?= e($mainPhotoPath) ?></p>
                </details>
              <?php endif; ?>
            </div>
          </div>
          <form method="post" action="<?= e(car_detail_tab_url($slug, 'publication', $detailReturnParams)) ?>" class="service-form car-main-photo-form" enctype="multipart/form-data" data-car-main-photo-upload>
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="car_main_photo_upload">
            <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
            <label class="car-main-photo-picker">
              <?= $mainPhotoExists ? 'Заменить фото' : 'Загрузить фото' ?>
              <input type="file" name="main_photo" accept="image/jpeg,image/png,image/webp" required data-car-main-photo-input>
            </label>
            <div class="car-main-photo-preview" data-car-main-photo-preview hidden>
              <img alt="">
              <span data-car-main-photo-name></span>
            </div>
            <p class="field-hint rate-field-wide">JPG, PNG или WebP до 8 МБ. Эта форма заменяет главное фото; несколько фото сразу можно загрузить в блоке «Фотографии автомобиля» ниже.</p>
            <button class="btn secondary" type="submit"><?= $mainPhotoExists ? 'Заменить главное фото' : 'Загрузить главное фото' ?></button>
          </form>
        </section>
        <details class="service-details car-photos-details">
          <summary>Фотографии автомобиля</summary>
          <?php if (!$photos): ?>
            <p class="muted">Фото пока не найдены. Загрузите одно или несколько изображений.</p>
          <?php else: ?>
            <div class="car-photo-grid">
              <?php foreach ($photos as $photoIndex => $photo): ?>
                <?php
                  $photoPath = (string) ($photo['path'] ?? '');
                  $photoKey = car_photo_key($slug, $photoPath);
                  $isMain = !empty($photo['isMain']);
                  $isFirstPhoto = $photoIndex === 0;
                  $isLastPhoto = $photoIndex === count($photos) - 1;
                ?>
                <article class="car-photo-card <?= $isMain ? 'is-main' : '' ?>">
                  <img src="../<?= e($photoPath) ?>" alt="">
                  <div class="car-photo-meta">
                    <span class="car-photo-badge"><?= $isMain ? 'Главное фото' : 'Фото' ?></span>
                    <small><?= e($photoPath) ?></small>
                  </div>
                  <div class="car-photo-actions">
                    <?php if (!$isFirstPhoto): ?>
                      <form method="post" action="<?= e(car_detail_tab_url($slug, 'publication', $detailReturnParams)) ?>">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="action" value="car_photo_move">
                        <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
                        <input type="hidden" name="photo_key" value="<?= e($photoKey) ?>">
                        <input type="hidden" name="direction" value="up">
                        <button class="btn secondary compact" type="submit">Вверх</button>
                      </form>
                    <?php endif; ?>
                    <?php if (!$isLastPhoto): ?>
                      <form method="post" action="<?= e(car_detail_tab_url($slug, 'publication', $detailReturnParams)) ?>">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="action" value="car_photo_move">
                        <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
                        <input type="hidden" name="photo_key" value="<?= e($photoKey) ?>">
                        <input type="hidden" name="direction" value="down">
                        <button class="btn secondary compact" type="submit">Вниз</button>
                      </form>
                    <?php endif; ?>
                    <?php if (!$isMain): ?>
                      <form method="post" action="<?= e(car_detail_tab_url($slug, 'publication', $detailReturnParams)) ?>">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="action" value="car_photo_main">
                        <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
                        <input type="hidden" name="photo_key" value="<?= e($photoKey) ?>">
                        <button class="btn secondary compact" type="submit">Сделать главным</button>
                      </form>
                    <?php endif; ?>
                    <form method="post" action="<?= e(car_detail_tab_url($slug, 'publication', $detailReturnParams)) ?>" onsubmit="return confirm('Удалить это фото?');">
                      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                      <input type="hidden" name="action" value="car_photo_delete">
                      <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
                      <input type="hidden" name="photo_key" value="<?= e($photoKey) ?>">
                      <button class="btn danger compact" type="submit">Удалить</button>
                    </form>
                  </div>
                </article>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
          <form method="post" action="<?= e(car_detail_tab_url($slug, 'publication', $detailReturnParams)) ?>" class="service-form car-photo-upload-form" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="car_photo_upload">
            <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
            <label>Загрузить фото <input type="file" name="photos[]" accept="image/jpeg,image/png,image/webp" multiple required></label>
            <p class="field-hint rate-field-wide">Можно выбрать несколько файлов сразу. Главное фото меняйте через блок выше или кнопкой «Сделать главным» в галерее.</p>
            <button class="btn secondary" type="submit">Загрузить фото</button>
          </form>
        </details>
        </div>
        <div class="car-detail-tab-panel"<?= car_detail_panel_attrs('fines', $activeCarTab) ?>>
        <details class="service-details" open>
          <summary>Штрафы и проверки</summary>
          <div class="service-metrics">
            <span>Последняя проверка <strong><?= e($lastFineCheck ? format_admin_datetime((string) ($lastFineCheck['finished_at'] ?? $lastFineCheck['created_at'] ?? '')) : 'не было') ?></strong></span>
            <span>Режим <strong><?= e(fine_modes()[$fineSettings['mode']] ?? $fineSettings['mode']) ?></strong></span>
            <span>Найдено штрафов <strong><?= e((string) $carFinesCount) ?></strong></span>
            <span>Баланс контура <strong><?= e(fine_money((float) $fineBalance['balance'])) ?></strong></span>
            <span>Стоимость проверки <strong><?= e(fine_money(fine_check_cost(1))) ?></strong></span>
            <span>Данные авто <strong><?= fine_car_has_required_data($car) ? 'готовы' : 'нужен госномер и СТС' ?></strong></span>
            <span>Открытых штрафов <strong><?= e((string) $carFineSummary['openCount']) ?></strong></span>
            <span>Без привязки <strong><?= e((string) $carFineSummary['unlinkedCount']) ?></strong></span>
            <span>К оплате/разбору <strong><?= e(fine_money((float) $carFineSummary['openAmount'])) ?></strong></span>
          </div>
          <form method="post" action="fines.php" class="service-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="create_manual_job">
            <input type="hidden" name="command_id" value="<?= e(business_command_form_id()) ?>">
            <input type="hidden" name="scenario" value="single_car">
            <input type="hidden" name="car_slugs[]" value="<?= e($slug) ?>">
            <input type="hidden" name="return_to" value="<?= e(car_detail_tab_url($slug, 'fines', $detailReturnParams)) ?>">
            <p class="field-hint rate-field-wide">Автоматизированный мониторинг доступных данных о штрафах. Будут отправлены госномер и СТС выбранного автомобиля, после успешной проверки с баланса спишется ориентировочная стоимость.</p>
            <button class="btn secondary" type="submit">Проверить сейчас</button>
            <a class="btn secondary" href="<?= e($carFineWizardUrl) ?>">Штраф по номеру</a>
            <a class="btn secondary" href="fines.php?scope_id=<?= urlencode($fineScopeId) ?>&tab=manual#manual-fine-entry">Внести штраф вручную</a>
          </form>
        </details>
        </div>
        <div class="car-detail-tab-panel"<?= car_detail_panel_attrs('history', $activeCarTab) ?>>
        <details class="service-details">
          <summary>Архивирование и удаление</summary>
          <?php if ($isArchived): ?>
            <?php if ((string) ($car['archiveReason'] ?? '') !== ''): ?>
              <p class="field-hint rate-field-wide">Причина архива: <?= e((string) $car['archiveReason']) ?></p>
            <?php endif; ?>
            <form method="post" action="<?= e(car_detail_tab_url($slug, 'history', $detailReturnParams)) ?>" class="service-form">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="restore_car">
              <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
              <button class="btn secondary" type="submit">Восстановить из архива</button>
            </form>
            <?php if ($deleteSummary['can_delete']): ?>
              <p class="field-hint rate-field-wide">Рабочих зависимостей не найдено. При физическом удалении запись машины, пустой календарь и тариф будут очищены; фотофайлы и audit-log остаются в истории.</p>
              <?php if (current_admin_role() === 'admin'): ?>
                <form method="post" action="<?= e(car_detail_tab_url($slug, 'history', $detailReturnParams)) ?>" class="service-form" onsubmit="return confirm('Физически удалить автомобиль? Это действие нельзя отменить.');">
                  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="action" value="delete_car">
                  <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
                  <button class="btn danger" type="submit">Физически удалить</button>
                </form>
              <?php else: ?>
                <p class="field-hint rate-field-wide">Физическое удаление доступно только администратору Rent RK.</p>
              <?php endif; ?>
            <?php else: ?>
              <p class="field-hint rate-field-wide">Физическое удаление запрещено, потому что у автомобиля есть связанные данные:</p>
              <ul class="compact-list">
                <?php foreach ($deleteSummary['blocking'] as $key => $dependencyCount): ?>
                  <li><?= e($deleteDependencyLabels[$key] ?? $key) ?>: <?= e((string) $dependencyCount) ?></li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>
          <?php else: ?>
            <form method="post" action="<?= e(car_detail_tab_url($slug, 'history', $detailReturnParams)) ?>" class="service-form" onsubmit="return confirm('Архивировать автомобиль? Он будет скрыт из витрины и партнёрских доступов, но история останется.');">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="archive_car">
              <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
              <label class="rate-field-wide">Причина архива <textarea name="archive_reason" rows="2" placeholder="Тестовое авто / снято с проката"></textarea></label>
              <button class="btn secondary" type="submit">Архивировать автомобиль</button>
            </form>
            <p class="field-hint rate-field-wide">Архивирование сохраняет машину для заявок, аренд, штрафов, календаря, задач и scoped export, но убирает её из активного парка и партнёрской витрины.</p>
          <?php endif; ?>
        </details>
        </div>
        <div class="car-detail-tab-panel"<?= car_detail_panel_attrs('service', $activeCarTab) ?>>
        <details class="service-details" open>
          <summary>Пробег и регламент ТО</summary>
          <?php if ($serviceWarnings): ?>
            <div class="car-hub-reasons">
              <?php foreach ($serviceWarnings as $reason): ?><?= car_readiness_reason_html($car, $reason, $canEditCarDocuments, $detailReturnParams) ?><?php endforeach; ?>
            </div>
          <?php endif; ?>
          <form method="post" action="<?= e(car_detail_tab_url($slug, 'service', $detailReturnParams)) ?>" class="service-form" data-car-service-regimen-form>
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="service_fields">
            <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
            <input type="hidden" name="next_service_mileage" value="">
            <label>Текущий пробег <input name="current_mileage" inputmode="numeric" value="<?= e((string) $service['currentMileage']) ?>"></label>
            <label>Пробег последнего ТО <input name="last_service_mileage" inputmode="numeric" value="<?= e((string) $service['lastServiceMileage']) ?>"></label>
            <label>Интервал ТО <input name="service_interval_mileage" inputmode="numeric" value="<?= e((string) $service['serviceIntervalMileage']) ?>"></label>
            <label class="car-readiness-calculated-field<?= (string) ($service['status'] ?? '') === 'overdue' ? ' is-overdue' : '' ?>">Следующий пробег ТО <input data-car-service-next-mileage inputmode="numeric" value="<?= e((string) $service['nextServiceMileage']) ?>" disabled aria-readonly="true"></label>
            <button class="btn secondary" type="submit">Сохранить ТО</button>
          </form>
          <?php if ($logItems): ?>
            <div class="service-log-list">
              <?php foreach ($logItems as $entry): ?>
                <div>
                  <strong><?= e(format_ru_date((string) ($entry['date'] ?? ''))) ?> · <?= e($serviceTypes[$entry['type'] ?? ''] ?? ($entry['type'] ?? '')) ?></strong>
                  <span><?= e(number_format((int) ($entry['mileage'] ?? 0), 0, '', ' ')) ?> км · <?= e(format_money(normalize_rate_price($entry['cost'] ?? null))) ?></span>
                  <p><?= e($entry['description'] ?? '') ?></p>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </details>
        </div>
        <div class="car-detail-tab-panel"<?= car_detail_panel_attrs('documents', $activeCarTab) ?>>
        <details class="service-details" id="<?= $view === 'detail' ? 'documents' : e($slug) . '-documents' ?>">
          <summary>Страховка и документы</summary>
          <?php if ($documentWarnings): ?>
            <div class="car-hub-reasons">
              <?php foreach ($documentWarnings as $reason): ?><?= car_readiness_reason_html($car, $reason, $canEditCarDocuments, $detailReturnParams) ?><?php endforeach; ?>
            </div>
          <?php endif; ?>
          <form method="post" action="<?= e(car_detail_tab_url($slug, 'documents', $detailReturnParams)) ?>" class="service-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="document_fields">
            <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
            <label>Госномер <input data-license-plate-input name="license_plate" value="<?= e($documents['licensePlate']) ?>" placeholder="А000АА82"></label>
            <label>VIN <input name="vin" value="<?= e($documents['vin']) ?>" maxlength="17" placeholder="XW8..."></label>
            <label>Рыночная стоимость <input name="market_value" value="<?= e($documents['marketValue'] === null ? '' : (string) $documents['marketValue']) ?>" inputmode="numeric" placeholder="руб."></label>
            <label>СТС <input name="registration_certificate" value="<?= e($documents['registrationCertificate']) ?>" inputmode="numeric" maxlength="11" data-sts-input></label>
            <label>ОСАГО № <input name="osago_number" value="<?= e($documents['osagoNumber']) ?>"></label>
            <label>ОСАГО действует до <input type="date" name="osago_expires_at" value="<?= e($documents['osagoExpiresAt']) ?>"></label>
            <label>КАСКО № <input name="casco_number" value="<?= e($documents['cascoNumber']) ?>"></label>
            <label>КАСКО действует до <input type="date" name="casco_expires_at" value="<?= e($documents['cascoExpiresAt']) ?>"></label>
            <label>Диагностическая карта до <input type="date" name="diagnostic_card_expires_at" value="<?= e($documents['diagnosticCardExpiresAt']) ?>"></label>
            <button class="btn secondary" type="submit">Сохранить документы</button>
          </form>
        </details>
        </div>
        <?php if ($carCanViewTariffs): ?>
        <div class="car-detail-tab-panel"<?= car_detail_panel_attrs('tariffs', $activeCarTab) ?>>
        <details class="service-details" id="<?= $view === 'detail' ? 'rates-settings' : e($slug) . '-rates' ?>">
          <summary>Условия пробега</summary>
          <p class="field-hint rate-field-wide">Тарифы, залог и условия пробега могут попадать в документы аренды и расчёты заявки. Базовые цены и индивидуальный залог редактируются в разделе тарифов.</p>
          <?php if (!$carCanEditTariffs): ?><p class="notice">У вас есть доступ только на просмотр тарифов.</p><?php endif; ?>
          <form method="post" action="<?= e(car_detail_tab_url($slug, 'tariffs', $detailReturnParams)) ?>" class="service-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="usage_fields">
            <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
            <label>Лимит пробега в сутки <input name="mileage_limit_per_day" inputmode="numeric" value="<?= e((string) $mileagePolicy['mileageLimitPerDay']) ?>"<?= $carCanEditTariffs ? '' : ' disabled' ?>></label>
            <label>Стоимость 1 км перепробега <input name="extra_mileage_rate" inputmode="numeric" value="<?= e($mileagePolicy['extraMileageRate'] === null ? '' : $mileagePolicy['extraMileageRate']) ?>" placeholder="руб./км"<?= $carCanEditTariffs ? '' : ' disabled' ?>></label>
            <?php if ($carCanEditTariffs): ?><button class="btn secondary" type="submit">Сохранить условия</button><?php endif; ?>
          </form>
        </details>
        </div>
        <?php endif; ?>
        <div class="car-detail-tab-panel"<?= car_detail_panel_attrs('history', $activeCarTab) ?>>
        <details class="service-details" open>
          <summary>Журнал обслуживания</summary>
          <?php if (!$logItems): ?>
            <p class="muted">Записей пока нет.</p>
          <?php else: ?>
            <div class="service-log-list">
              <?php foreach ($logItems as $entry): ?>
                <div>
                  <strong><?= e(format_ru_date((string) ($entry['date'] ?? ''))) ?> · <?= e($serviceTypes[$entry['type'] ?? ''] ?? ($entry['type'] ?? '')) ?></strong>
                  <span><?= e(number_format((int) ($entry['mileage'] ?? 0), 0, '', ' ')) ?> км · <?= e(format_money(normalize_rate_price($entry['cost'] ?? null))) ?></span>
                  <p><?= e($entry['description'] ?? '') ?></p>
                  <?php if (!empty($entry['provider'])): ?><small><?= e($entry['provider']) ?></small><?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
          <?php if ($latestAuditItems): ?>
            <div class="service-log-list">
              <?php foreach ($latestAuditItems as $auditItem): ?>
                <div>
                  <strong><?= e(format_admin_datetime((string) ($auditItem['createdAt'] ?? ''))) ?> · <?= e((string) ($auditItem['action'] ?? 'car.update')) ?></strong>
                  <p><?= e((string) ($auditItem['summary'] ?? 'Изменение автомобиля')) ?></p>
                  <?php if ((string) ($auditItem['actor'] ?? '') !== ''): ?><small><?= e((string) $auditItem['actor']) ?></small><?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
          <form method="post" action="<?= e(car_detail_tab_url($slug, 'history', $detailReturnParams)) ?>" class="service-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="service_log">
            <input type="hidden" name="command_id" value="<?= e(business_command_form_id()) ?>">
            <input type="hidden" name="car_slug" value="<?= e($slug) ?>"><?= car_record_version_field($slug) ?>
            <label>Дата <input type="date" name="service_date" value="<?= e(date('Y-m-d')) ?>"></label>
            <label>Пробег <input name="service_mileage" inputmode="numeric"></label>
            <label>
              Тип
              <select name="service_type">
                <?php foreach ($serviceTypes as $key => $label): ?>
                  <option value="<?= e($key) ?>"><?= e($label) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
            <label>Стоимость <input name="service_cost" inputmode="numeric"></label>
            <label>Исполнитель / СТО <input name="service_provider"></label>
            <label>Описание <textarea name="service_description" rows="3"></textarea></label>
            <label>Комментарий <textarea name="service_comment" rows="2"></textarea></label>
            <button class="btn secondary" type="submit">Добавить запись</button>
          </form>
        </details>
        </div>
      </div>
      <?= car_readiness_modals_html($car, $carHub['readiness']['reasons'] ?? [], $carReadinessFormUrl, ['maintenance' => $carMaintenanceFormUrl, 'service_hold' => $carServiceHoldFormUrl]) ?>
    </article>
  <?php endforeach; ?>
  <?php if (!$cars): ?>
    <article class="panel admin-empty <?= $isScopedLessor ? 'scoped-empty-state' : '' ?>">
      <p><?= $isScopedLessor ? 'В вашем контуре пока нет автомобилей в выбранном состоянии.' : 'Автомобилей в выбранном состоянии пока нет.' ?></p>
    </article>
  <?php endif; ?>
</section>
<?php endif; ?>
<div class="car-readiness-modal-backdrop" data-car-readiness-modal-backdrop hidden></div>
<?php admin_footer(); ?>
