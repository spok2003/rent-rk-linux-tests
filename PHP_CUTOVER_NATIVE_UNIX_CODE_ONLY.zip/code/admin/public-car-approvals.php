<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/approved-public-car-snapshot.php';
require_permission('cars.view');
$service = null; $error = ''; $notice = ''; $candidate = null; $plan = null; $renewal = null; $handoffs = []; $applyPreview = null;
$slug = is_string($_POST['slug'] ?? $_GET['slug'] ?? null) ? (string) ($_POST['slug'] ?? $_GET['slug']) : '';
try { $service = ApprovedPublicCarSnapshots::fromServer(); } catch (Throwable $e) { $error = $e->getMessage(); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    try {
        if (!$service) throw new RuntimeException('BLOCKED_TRUST_CONFIGURATION_UNAVAILABLE', 503);
        foreach (['action', 'slug', 'review_version', 'reason', 'confirm_publish', 'plan_mode'] as $field) {
            if (isset($_POST[$field]) && !is_string($_POST[$field])) throw new RuntimeException('Некорректная структура запроса.', 422);
        }
        $action = (string) ($_POST['action'] ?? '');
        if ($action === 'approve') {
            $r = $service->approve($slug, (string) ($_POST['review_version'] ?? ''), ($_POST['confirm_publish'] ?? '') === '1');
            $notice = $r['status'] === 'APPROVED_NOT_PUBLISHED' ? 'Версия одобрена. Витрина не обновлялась.' : 'Эта версия уже одобрена. Повторной записи нет.';
            if (PhpPublicationAutomation::enabled()) $notice = PhpPublicationAutomation::message($slug);
        } elseif ($action === 'recover_revoked_key') {
            $service->recoverRevokedKey($slug, (string) ($_POST['review_version'] ?? ''), ($_POST['confirm_publish'] ?? '') === '1');
            $notice = 'Новая версия одобрена действующим ключом. Витрина не обновлялась.';
            if (PhpPublicationAutomation::enabled()) $notice = PhpPublicationAutomation::message($slug);
        } elseif ($action === 'reattest') {
            $r = $service->reattest($slug, (string) ($_POST['review_version'] ?? ''));
            $notice = $r['status'] === 'REATTESTED_NOT_PUBLISHED' ? 'Подпись обновлена. Одобрение и витрина не изменились.' : 'Подпись ещё действует.';
        } elseif ($action === 'revoke') {
            $service->revoke($slug, (string) ($_POST['review_version'] ?? ''), trim((string) ($_POST['reason'] ?? '')));
            $notice = 'Одобрение отозвано. Публичные файлы не изменялись.';
            if (PhpPublicationAutomation::enabled()) $notice = PhpPublicationAutomation::message($slug);
        } elseif ($action === 'handoff' && PhpPublicationAutomation::enabled()) {
            PhpPublicationAutomation::handoff($slug, is_array($_POST['handoff'] ?? null) ? $_POST['handoff'] : [],
                ($_POST['confirm_handoff'] ?? null) === '1');
            $notice = 'Сопровождение выбранных страниц передано. Содержимое и одобрения не изменились.';
        } elseif ($action === 'prepare_cutover' && PhpPublicationCutover::selected()) {
            $mode = (string) ($_POST['plan_mode'] ?? '');
            $plan = $service->cutoverPreview($slug, $mode, true);
            $prepared = $service->preparePhpApply($slug, $mode, $plan);
            $applyPreview = bin2hex(random_bytes(16));
            $_SESSION['php_cutover_preview'] = $prepared + ['id' => $applyPreview, 'slug' => $slug, 'mode' => $mode];
            $notice = 'Точный план подготовлен. Публичные файлы ещё не изменены.';
        } elseif ($action === 'apply_cutover' && PhpPublicationCutover::selected()) {
            $prepared = $_SESSION['php_cutover_preview'] ?? null;
            if (!is_array($prepared) || $prepared['slug'] !== $slug || !is_string($_POST['preview_id'] ?? null)
                || !hash_equals($prepared['id'], $_POST['preview_id']) || ($_POST['confirm_publish'] ?? '') !== '1') {
                throw new RuntimeException('BLOCKED_PHP_APPLY_CONFIRMATION_REQUIRED', 403);
            }
            $r = $service->applyPhpPlan($slug, $prepared['mode'], $prepared['plan'], $prepared['ticket'], true);
            $notice = $r['status'] === 'ALREADY_APPLIED' ? 'Результат уже подтверждён. Повторной записи нет.' : 'Точный PHP-план применён.';
        } elseif ($action === 'plan') {
            $plan = $service->plan($slug, (string) ($_POST['plan_mode'] ?? 'Car'));
            $notice = $plan['status'] === 'PLAN_ONLY' ? 'План сформирован без публикации.' : 'План заблокирован: ' . $plan['status'];
        } else throw new InvalidArgumentException('Неизвестное действие.');
    } catch (Throwable $e) { $error = $e->getMessage(); http_response_code(in_array($e->getCode(), [403, 409, 422, 503], true) ? $e->getCode() : 503); }
}
if ($service && $slug !== '') {
    try { $candidate = $service->candidate($slug); } catch (Throwable $e) { $error = $e->getMessage(); }
    if (PhpPublicationAutomation::enabled() && ApprovedPublicCarSnapshots::canApprove($slug)) {
        try { $handoffs = PhpPublicationAutomation::handoffPreview($slug); } catch (Throwable $e) { $error = $e->getMessage(); }
    }
}
$store = ApprovedPublicCarSnapshots::store();
if ($service && $slug !== '' && empty($candidate['recoveryVersion']) && ($store['active'][$slug]['state'] ?? '') === 'approved' && ApprovedPublicCarSnapshots::canApprove($slug)) {
    try { $renewal = $service->renewalVersion($slug); } catch (RuntimeException $e) {
        if ($error === '') $error = $e->getMessage();
    }
}
$labels = ['slug' => 'Адрес карточки', 'scopeId' => 'Контур', 'name' => 'Название', 'description' => 'Описание', 'price' => 'Цена за сутки, ₽', 'deposit' => 'Залог, ₽',
    'parkCallback' => 'Обратный звонок парка', 'mode' => 'Режим', 'enabled' => 'Включён', 'delaySeconds' => 'Задержка, секунд',
    'repeatPolicy' => 'Повтор показа', 'texts' => 'Тексты формы', 'button_text' => 'Кнопка', 'success_text' => 'Подтверждение отправки',
    'image' => 'Главное фото', 'gallery' => 'Порядок фотографий', 'specs' => 'Характеристики и условия', 'seo' => 'Поисковые данные', 'type' => 'Класс', 'seats' => 'Мест',
    'drive' => 'Привод', 'year' => 'Год', 'bodyType' => 'Кузов', 'fuelType' => 'Топливо', 'equipment' => 'Оснащение', 'features' => 'Особенности', 'conditions' => 'Условия аренды',
    'faq' => 'Вопросы и ответы', 'content' => 'Разделы страницы', 'brand' => 'Марка', 'model' => 'Модель', 'hero' => 'Первый экран', 'title' => 'Заголовок',
    'text' => 'Текст', 'heading' => 'Раздел', 'question' => 'Вопрос', 'answer' => 'Ответ', 'eyebrow' => 'Подзаголовок', 'subtitle' => 'Вступление',
    'priceText' => 'Текст цены', 'primaryCta' => 'Кнопка бронирования', 'secondaryCta' => 'Дополнительная кнопка'];
$renderValue = static function (mixed $value) use (&$renderValue, $labels): void {
    if (!is_array($value)) { echo e((string) $value); return; }
    if (!$value) { echo '—'; return; }
    if (array_is_list($value)) { echo '<ul>'; foreach ($value as $item) { echo '<li>'; $renderValue($item); echo '</li>'; } echo '</ul>'; }
    else { echo '<dl>'; foreach ($value as $k => $v) { echo '<dt>' . e($labels[$k] ?? $k) . '</dt><dd>'; $renderValue($v); echo '</dd>'; } echo '</dl>'; }
};
admin_header('Публичные версии автомобилей', 'cars');
?>
<style>.public-approval-table{overflow-x:auto}.public-car-candidate dd,.public-car-candidate pre{white-space:pre-wrap;overflow-wrap:anywhere}.public-car-candidate img{width:180px;max-width:100%;height:120px;object-fit:contain}</style>
<section class="panel">
  <header><h1>Публичные версии автомобилей</h1><a class="btn secondary" href="cars.php">Автопарк</a></header>
  <?php if ($notice): ?><p role="status"><?= e($notice) ?></p><?php endif; ?>
  <?php if ($error): ?><p role="alert"><?= e($error) ?></p><?php endif; ?>
  <div class="public-approval-table"><table><thead><tr><th>Автомобиль</th><th>Контур</th><th>Текущая видимость</th><th>Утверждённая версия</th><th></th></tr></thead><tbody>
  <?php foreach (scope_cars_for_current_user(read_cars()) as $car): $head = $store['active'][$car['slug']] ?? null; ?>
    <tr><td><?= e((string) $car['name']) ?></td><td><?= e(car_owner_scope_id($car)) ?></td><td><?= car_visible_in_public_rent_rk_showcase($car) ? 'Виден' : 'Скрыт' ?></td><td><?= $head ? e($head['state'] . ' / ' . $head['revision']) : 'Нет одобрения' ?></td><td><a href="?slug=<?= e(rawurlencode($car['slug'])) ?>">Просмотреть кандидата</a></td></tr>
  <?php endforeach; ?></tbody></table></div>
</section>
<?php if ($candidate): ?>
<section class="panel public-car-candidate">
  <h2><?= e($candidate['material']['car']['name']) ?></h2>
  <p><?= $candidate['matchesApproved'] ? 'Показанное содержимое совпадает с утверждённой версией.' : 'Показанный кандидат не одобрен. Прежняя утверждённая версия, если она есть, сохраняется.' ?></p>
  <div><?php foreach ($candidate['material']['car']['gallery'] as $image): ?><img src="../<?= e($image) ?>" alt="<?= e($candidate['material']['car']['name']) ?>"><?php endforeach; ?></div>
  <?php $renderValue($candidate['material']['car']); ?>
  <details><summary>Публичные настройки и происхождение полей</summary><pre><?= e(json_encode(['site' => $candidate['material']['site'], 'sources' => $candidate['material']['fieldSources'], 'assets' => $candidate['material']['assets']], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)) ?></pre></details>
  <?php if (ApprovedPublicCarSnapshots::canApprove($slug) && $candidate['eligible']): ?>
  <?php $recovering = $candidate['recoveryVersion'] !== null; ?>
  <?php if ($recovering): ?><p role="alert">Ключ прежней версии отозван. Проверьте показанные данные: подтверждение создаст новую версию, не восстанавливая доверие к старой подписи.</p><?php endif; ?>
  <form method="post"><?php csrf_field(); ?><input type="hidden" name="slug" value="<?= e($slug) ?>"><input type="hidden" name="review_version" value="<?= e($recovering ? $candidate['recoveryVersion'] : $candidate['reviewVersion']) ?>">
    <label><input type="checkbox" name="confirm_publish" value="1" required>Разрешаю публикацию показанной версии этого автомобиля</label>
    <button class="btn" name="action" value="<?= $recovering ? 'recover_revoked_key' : 'approve' ?>"><?= $recovering ? 'Одобрить новую версию' : 'Подтвердить эту машину' ?></button>
  </form>
  <?php endif; ?>
  <?php if (($candidate['currentApproval']['state'] ?? '') === 'approved'): ?>
  <form method="post"><?php csrf_field(); ?><input type="hidden" name="slug" value="<?= e($slug) ?>"><input type="hidden" name="action" value="plan"><button class="btn secondary" name="plan_mode" value="Car">PHP-план автомобиля</button> <button class="btn secondary" name="plan_mode" value="Full">Полный PHP-план</button></form>
  <?php if (PhpPublicationCutover::selected() && ApprovedPublicCarSnapshots::canApprove($slug)): ?>
  <form method="post"><?php csrf_field(); ?><input type="hidden" name="slug" value="<?= e($slug) ?>"><input type="hidden" name="action" value="prepare_cutover">
    <button class="btn secondary" name="plan_mode" value="Car">Подготовить публикацию автомобиля</button>
    <button class="btn secondary" name="plan_mode" value="Full">Подготовить полную публикацию</button>
  </form>
  <?php endif; ?>
  <?php endif; ?>
</section>
<?php endif; ?>
<?php if ($service && $slug !== '' && ($store['active'][$slug]['state'] ?? '') === 'approved' && ApprovedPublicCarSnapshots::canApprove($slug)): ?>
<section class="panel"><h2>Отзыв действующей версии</h2>
  <form method="post"><?php csrf_field(); ?><input type="hidden" name="slug" value="<?= e($slug) ?>"><input type="hidden" name="review_version" value="<?= e(ApprovedPublicCarSnapshots::revokeVersion($slug)) ?>"><label>Причина отзыва<input name="reason" required maxlength="600"></label><button class="btn secondary" name="action" value="revoke">Отозвать одобрение</button></form>
</section>
<?php endif; ?>
<?php if ($renewal): ?>
<section class="panel"><h2>Подпись утверждённой версии <?= e((string) $renewal['revision']) ?></h2>
  <form method="post"><?php csrf_field(); ?><input type="hidden" name="slug" value="<?= e($slug) ?>"><input type="hidden" name="review_version" value="<?= e($renewal['version']) ?>">
    <button class="btn secondary" name="action" value="reattest"><?= $renewal['rotating'] ? 'Переподписать действующим ключом' : 'Обновить истёкшую подпись' ?></button>
  </form>
</section>
<?php endif; ?>
<?php if ($plan): ?><section class="panel"><h2>Результат плана</h2><p><?= e($plan['status']) ?></p><ul><?php foreach ($plan['outputs'] as $output): ?><li><?= e($output['path']) ?>: <?= e($output['sha256']) ?></li><?php endforeach; ?></ul></section><?php endif; ?>
<?php if ($applyPreview !== null): ?>
<form method="post" class="panel"><?php csrf_field(); ?><input type="hidden" name="slug" value="<?= e($slug) ?>">
  <input type="hidden" name="preview_id" value="<?= e($applyPreview) ?>">
  <label><input type="checkbox" name="confirm_publish" value="1" required>Подтверждаю применение показанного плана</label>
  <button class="btn" name="action" value="apply_cutover">Применить план</button>
</form>
<?php endif; ?>
<?php if ($candidate && PhpPublicationAutomation::enabled()): ?>
<section class="panel"><h2>Состояние публикации</h2><p><?= e(PhpPublicationAutomation::message($slug)) ?></p></section>
<?php endif; ?>
<?php if ($handoffs): ?>
<section class="panel"><h2>Передача сопровождения Option C</h2>
  <form method="post"><?php csrf_field(); ?><input type="hidden" name="slug" value="<?= e($slug) ?>">
    <?php foreach ($handoffs as $path => $token): ?>
      <label><input type="checkbox" name="handoff[<?= e($path) ?>]" value="<?= e($token) ?>"> <?= e($path) ?></label>
    <?php endforeach; ?>
    <label><input type="checkbox" name="confirm_handoff" value="1" required> Передать только выбранные страницы. Содержимое и одобрения не меняются.</label>
    <button class="btn secondary" name="action" value="handoff">Передать сопровождение</button>
  </form>
</section>
<?php endif; ?>
<?php admin_footer(); ?>
