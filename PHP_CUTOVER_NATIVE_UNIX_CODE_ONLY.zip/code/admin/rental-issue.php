<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
require_permission('rentals.view');

if (!in_array(current_admin_role(), ['admin', 'manager'], true)) {
    deny_scope_access();
}

$id = trim((string) ($_GET['id'] ?? $_POST['id'] ?? ''));
$rental = $id !== '' ? find_rental($id) : null;
$message = '';
$error = '';
$returnTo = admin_safe_return_to($_GET['return_to'] ?? $_POST['return_to'] ?? '', 'rental-issue.php?id=' . urlencode($id));

if (!$rental) {
    http_response_code(404);
    admin_header('Выдача автомобиля', 'rentals');
    ?>
    <section class="page-head">
      <div>
        <p class="eyebrow">CRM</p>
        <h1>Выдача автомобиля</h1>
        <p class="muted">Аренда не найдена.</p>
      </div>
      <div class="actions"><a class="btn secondary" href="rentals.php">К арендам</a></div>
    </section>
    <article class="panel"><p class="muted">Откройте существующую аренду и нажмите “Выдать автомобиль”.</p></article>
    <?php
    admin_footer();
    exit;
}

require_rental_scope($rental);
$rental = normalize_rental_item($rental);
$isClosed = !empty($rental['closedAt']) || (string) ($rental['returnStatus'] ?? '') === 'returned';
$workflow = normalize_rental_issue_workflow($rental['issueWorkflow'] ?? []);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_permission('rentals.edit');
    verify_csrf();
    if (isset($rental['returnCloseV2'])) {
        http_response_code(409);
        exit('Возврат V2 уже начат. Изменение выдачи через старую форму недоступно.');
    }

    $action = (string) ($_POST['action'] ?? 'issue_save_draft');
    if (!in_array($action, ['issue_save_draft', 'issue_complete'], true)) {
        http_response_code(400);
        $error = 'Неизвестное действие выдачи.';
    } else {
        try {
            $redirectUrl = RentalReturnStore::transaction(static function () use ($id, $action, $returnTo, &$rental, &$workflow, &$isClosed): string {
            require_permission('rentals.edit');
            $currentRental = find_rental($id);
            if (!$currentRental) throw new RuntimeException('Аренда не найдена.', 404);
            $rental = $currentRental;
            require_rental_scope($rental);
            if (isset($rental['returnCloseV2'])) throw new RuntimeException('Возврат V2 уже начат.', 409);
            $expected = $_POST['expected_version'] ?? null;
            if (!is_string($expected) || !hash_equals(business_record_version(RENTALS_FILE, $id), $expected)) {
                throw new RuntimeException('Аренда изменена после открытия формы. Обновите данные перед сохранением выдачи.', 409);
            }
            $rental = normalize_rental_item($rental);
            $isClosed = !empty($rental['closedAt']) || (string) ($rental['returnStatus'] ?? '') === 'returned';
            $workflow = normalize_rental_issue_workflow($rental['issueWorkflow'] ?? []);
            if ($isClosed) {
                throw new RuntimeException('Закрытую аренду нельзя выдать.', 409);
            }
            if ($workflow['status'] === 'completed') {
                throw new RuntimeException('Выдача уже завершена. Можно добавлять только фото через блок фотофиксации.', 409);
            }

            $issueDate = trim((string) ($_POST['issue_date'] ?? ($rental['startDate'] ?: date('Y-m-d'))));
            $issueTime = trim((string) ($_POST['issue_time'] ?? ($rental['startTime'] ?: date('H:i'))));
            $mileage = normalize_mileage($_POST['issue_workflow_mileage'] ?? null);
            $fuelLevel = (string) ($_POST['issue_workflow_fuel'] ?? '');
            if (!array_key_exists($fuelLevel, rental_fuel_levels())) {
                $fuelLevel = '';
            }

            $workflow['issuedAt'] = parse_date_value($issueDate) && parse_time_value($issueTime) !== null
                ? rental_datetime_text($issueDate, $issueTime)
                : '';
            $workflow['mileage'] = $mileage;
            $workflow['fuelLevel'] = $fuelLevel;
            $workflow['checklist'] = normalize_rental_workflow_checklist($workflow['checklist'], rental_issue_checklist_defaults());
            if (array_key_exists('issue_manual_handover_present', $_POST) || $action === 'issue_complete') {
                $workflow['checklist']['keysAndDocsHanded'] = isset($_POST['issue_manual_handover']);
            }
            $workflow['comment'] = rental_workflow_comment($_POST['issue_workflow_comment'] ?? '');

            $previewRental = normalize_rental_item(array_merge($rental, [
                'issueWorkflow' => $workflow,
                'startMileage' => $mileage ?? $rental['startMileage'],
            ]));
            $workflow['checklist'] = rental_issue_legacy_checklist_from_readiness($previewRental, $workflow['checklist']);
            if (array_key_exists('issue_manual_handover_present', $_POST) || $action === 'issue_complete') {
                $workflow['checklist']['keysAndDocsHanded'] = isset($_POST['issue_manual_handover']);
            }
            $previewRental = normalize_rental_item(array_merge($previewRental, ['issueWorkflow' => $workflow]));

            $changes = ['issueWorkflow' => $workflow];
            $auditAction = 'rental.issue.draft_saved';
            $redirectFlag = 'draft';

            if ($action === 'issue_complete') {
                assert_rental_can_be_issued($previewRental);

                $workflow['status'] = 'completed';
                $workflow['completedAt'] = now_iso();
                $workflow['completedBy'] = current_admin_user();
                $changes['issueWorkflow'] = $workflow;
                $changes['issueStatus'] = 'issued';
                $changes['startMileage'] = $mileage;
                if ($workflow['photos'] && (string) ($rental['photosUploadedAt'] ?? '') === '') {
                    $changes['photosUploadedAt'] = now_iso();
                }
                $segments = $rental['vehicleSegments'];
                foreach ($segments as $index => $segment) {
                    if ((string) ($segment['endedAt'] ?? '') === '') {
                        $segments[$index]['startMileage'] = $mileage;
                        break;
                    }
                }
                $changes['vehicleSegments'] = $segments;
                $auditAction = 'rental.issue.completed';
                $redirectFlag = 'completed';
            }

            $saved = update_rental_item($id, $changes);
            if (!$saved) {
                throw new RuntimeException('Не удалось сохранить выдачу.');
            }
            rental_workflow_audit_event($id, $auditAction, [
                'stage' => 'issue',
                'changedFields' => array_keys($changes),
                'checklistCounts' => rental_workflow_checklist_counts($workflow['checklist']),
            ]);
            $redirectUrl = 'rental-issue.php?id=' . urlencode($id) . '&' . $redirectFlag . '=1';
            if ($returnTo !== '' && $returnTo !== 'rental-issue.php?id=' . urlencode($id)) {
                $redirectUrl = admin_url_with_return_to($redirectUrl, $returnTo);
            }
            if ($redirectFlag === 'completed' && $returnTo !== '' && $returnTo !== 'rental-issue.php?id=' . urlencode($id)) {
                return $returnTo;
            }
            return $redirectUrl;
            });
            redirect_to($redirectUrl);
        } catch (Throwable $exception) {
            http_response_code(in_array((int) $exception->getCode(), [403, 404, 409, 503], true) ? (int) $exception->getCode() : 400);
            $error = $exception->getMessage();
            $rental = normalize_rental_item(array_merge($rental, ['issueWorkflow' => $workflow]));
        }
    }
}

if (isset($_GET['draft'])) {
    $message = 'Черновик выдачи сохранен.';
}
if (isset($_GET['completed'])) {
    $message = 'Выдача завершена. Статус аренды обновлен.';
}

$rental = normalize_rental_item(find_rental($id) ?? $rental);
$workflow = normalize_rental_issue_workflow($rental['issueWorkflow'] ?? []);
$summary = rental_issue_workflow_summary($rental);
$issueReadiness = rental_issue_readiness_summary($rental);
$issuePhotoReadinessKeys = ['photos_body', 'photos_interior', 'photo_odometer'];
$issuePhotoReadinessItems = array_values(array_filter(
    $issueReadiness['items'],
    static fn(array $item): bool => in_array((string) ($item['key'] ?? ''), $issuePhotoReadinessKeys, true)
));
$issueCoreReadinessItems = array_values(array_filter(
    $issueReadiness['items'],
    static fn(array $item): bool => !in_array((string) ($item['key'] ?? ''), $issuePhotoReadinessKeys, true)
));
$issueCoreReadiness = rental_readiness_summary_from_items($issueCoreReadinessItems);
$issueReadinessVisibleItems = array_values(array_filter(
    $issueCoreReadinessItems,
    static fn(array $item): bool => (string) ($item['state'] ?? '') !== 'ready'
));
$issueReadinessActionItems = array_values(array_filter(
    $issueCoreReadinessItems,
    static fn(array $item): bool => (string) ($item['actionLabel'] ?? '') !== '' && (string) ($item['actionModal'] ?? '') !== ''
));
$issueReadinessActionModals = [];
foreach ($issueReadinessActionItems as $item) {
    $issueReadinessActionModals[(string) $item['actionModal']] = $item;
}
$issuePhotoRecommendedItems = array_values(array_filter(
    $issuePhotoReadinessItems,
    static fn(array $item): bool => (string) ($item['state'] ?? '') !== 'ready'
));
$issuePhotoReadyCount = count($issuePhotoReadinessItems) - count($issuePhotoRecommendedItems);
$issuePhotoRequiredTotal = max(1, count($issuePhotoReadinessItems));
$issueHandoverConfirmed = !empty($workflow['checklist']['keysAndDocsHanded']);
$issueFinalBlockingItems = array_values((array) ($issueCoreReadiness['problemItems'] ?? []));
if (!$issueHandoverConfirmed) {
    $issueFinalBlockingItems[] = [
        'label' => 'Подтверждение передачи',
        'state' => 'missing',
        'stateLabel' => 'не заполнено',
        'detail' => 'Отметьте ниже, что ключи, документы и автомобиль переданы клиенту.',
        'required' => true,
        'actionLabel' => '',
        'actionModal' => '',
    ];
}
$issueFinalAttentionItems = array_values(array_merge(
    (array) ($issueCoreReadiness['attentionItems'] ?? []),
    $issuePhotoRecommendedItems
));
$issueFinalRequiredItems = array_values(array_filter(
    $issueCoreReadinessItems,
    static fn(array $item): bool => !empty($item['required'])
));
$issueFinalRequiredReadyItems = array_values(array_filter(
    $issueFinalRequiredItems,
    static fn(array $item): bool => (string) ($item['state'] ?? '') !== 'missing'
));
$issueFinalRequiredTotal = max(1, count($issueFinalRequiredItems) + 1);
$issueFinalRequiredReady = count($issueFinalRequiredReadyItems) + ($issueHandoverConfirmed ? 1 : 0);
$issueFinalState = $summary['isCompleted']
    ? 'done'
    : ($issueFinalBlockingItems ? 'blocked' : ($issueFinalAttentionItems ? 'attention' : 'ready'));
$issueFinalHeadline = match ($issueFinalState) {
    'done' => 'Выдача уже завершена',
    'ready' => 'Можно завершать выдачу',
    'attention' => 'Можно завершать, есть пункты внимания',
    default => 'Перед завершением есть незаполненные пункты',
};
$issueFinalDetail = match ($issueFinalState) {
    'done' => 'Данные выдачи сохранены и поля доступны только для просмотра.',
    'ready' => 'Все обязательные данные заполнены. Осталось только финальное действие менеджера.',
    'attention' => 'Обязательные данные заполнены, но ниже есть рекомендации, которые стоит проверить.',
    default => 'Сначала закройте пункты из списка ниже. После этого финальное подтверждение станет безопасным.',
};
$issueFinalStatusLabel = match ($issueFinalState) {
    'done' => 'завершено',
    'ready' => 'готово',
    'attention' => 'проверьте',
    default => 'не готово',
};
$issueFinalStatusClass = match ($issueFinalState) {
    'done',
    'ready' => 'status-free',
    'attention' => 'status-reserved',
    default => 'status-canceled',
};
$issueDateValue = '';
$issueTimeValue = '';
if ($workflow['issuedAt'] !== '') {
    $issueDateValue = substr($workflow['issuedAt'], 0, 10);
    $issueTimeValue = substr($workflow['issuedAt'], 11, 5);
}
if ($issueDateValue === '') {
    $issueDateValue = $rental['startDate'] ?: date('Y-m-d');
}
if ($issueTimeValue === '') {
    $issueTimeValue = $rental['startTime'] ?: date('H:i');
}
$workflowLocked = $isClosed || $workflow['status'] === 'completed';
$canEditWorkflow = has_permission('rentals.edit') && !$isClosed;
$fuelLevels = rental_fuel_levels();
$issueCategories = rental_media_categories('issue');
$issuePaymentStatuses = rental_payment_statuses();
$issueDepositStatuses = rental_deposit_statuses();
$issuePaymentStatus = (string) ($rental['paymentStatus'] ?? '');
$issueDepositStatus = (string) ($rental['depositStatus'] ?? '');
$issuePaymentLabel = $issuePaymentStatuses[$issuePaymentStatus] ?? ($issuePaymentStatus !== '' ? $issuePaymentStatus : 'не указан');
$issueDepositLabel = $issueDepositStatuses[$issueDepositStatus] ?? ($issueDepositStatus !== '' ? $issueDepositStatus : 'не указан');
$issuePaymentState = in_array($issuePaymentStatus, ['paid', 'refund_due', 'refunded'], true) ? 'success' : ($issuePaymentStatus === 'partially_paid' ? 'warning' : 'danger');
$issueDepositState = in_array($issueDepositStatus, ['received', 'not_required', 'returned', 'partially_retained'], true) ? 'success' : 'warning';
$issueDocumentGroups = array_values(array_filter(
    rental_document_groups_for_ui($rental, $id),
    static fn (array $document): bool => in_array((string) ($document['type'] ?? ''), ['contract', 'issue-act', 'personal-data-consent'], true)
));
$issueDocumentReadyCount = 0;
foreach ($issueDocumentGroups as $document) {
    if (($document['state'] ?? '') === 'ready') {
        $issueDocumentReadyCount++;
    }
}
$issueDocumentState = !$issueDocumentGroups ? 'muted' : ($issueDocumentReadyCount === count($issueDocumentGroups) ? 'success' : 'warning');
$issueChecklistDone = (int) ($summary['checklistCounts']['done'] ?? 0);
$issueChecklistTotal = max(1, (int) ($summary['checklistCounts']['total'] ?? 0));
$issueChecklistState = $issueChecklistDone >= $issueChecklistTotal ? 'success' : ($issueChecklistDone > 0 ? 'warning' : 'danger');
$issueNextHref = $summary['isCompleted'] ? '#issue-result' : (!empty($issueCoreReadiness['ready']) ? '#issue-finish' : '#issue-readiness');
$issueNextLabel = $summary['isCompleted'] ? 'Посмотреть результат' : (!empty($issueCoreReadiness['ready']) ? 'Перейти к завершению' : 'Проверить готовность');
$issueSteps = [
    ['label' => 'Сделка', 'state' => 'success'],
    ['label' => 'Клиент', 'state' => trim((string) ($rental['clientName'] ?? '')) !== '' ? 'success' : 'warning'],
    ['label' => 'Автомобиль', 'state' => trim((string) ($rental['carSlug'] ?? '')) !== '' ? 'success' : 'warning'],
    ['label' => 'Период', 'state' => trim((string) ($rental['startDate'] ?? '')) !== '' ? 'success' : 'warning'],
    ['label' => 'Деньги', 'state' => $issuePaymentState],
    ['label' => 'Залог', 'state' => $issueDepositState],
    ['label' => 'Документы', 'state' => $issueDocumentState],
    ['label' => 'Финиш', 'state' => $summary['isCompleted'] ? 'success' : (!empty($issueCoreReadiness['ready']) ? 'active' : 'muted')],
];
$issueCommandTiles = [
    ['label' => 'Готовность', 'value' => (string) $issueCoreReadiness['stateLabel'], 'detail' => 'к выдаче', 'state' => (string) $issueCoreReadiness['state']],
    ['label' => 'Оплата', 'value' => $issuePaymentLabel, 'detail' => $rental['rentalCost'] === null ? 'сумма не указана' : format_money((int) $rental['rentalCost']), 'state' => $issuePaymentState],
    ['label' => 'Залог', 'value' => $issueDepositLabel, 'detail' => $rental['deposit'] === null ? 'сумма не указана' : format_money((int) $rental['deposit']), 'state' => $issueDepositState],
    ['label' => 'Фото', 'value' => (string) $summary['photoCount'], 'detail' => 'до ' . rental_media_max_stage_photos(), 'state' => ((int) $summary['photoCount']) > 0 ? 'success' : 'warning'],
    ['label' => 'Документы', 'value' => $issueDocumentGroups ? $issueDocumentReadyCount . '/' . count($issueDocumentGroups) : 'нет', 'detail' => 'договор / акт', 'state' => $issueDocumentState],
    ['label' => 'Чек-лист', 'value' => $issueChecklistDone . '/' . $issueChecklistTotal, 'detail' => 'перед выдачей', 'state' => $issueChecklistState],
];
$issueSectionNavLinks = array_values(array_filter([
    ['label' => 'Сводка', 'href' => '#issue-summary', 'show' => true],
    ['label' => 'Клиент и авто', 'href' => '#issue-client-car', 'show' => true],
    ['label' => 'Деньги и залог', 'href' => '#issue-finance', 'show' => true],
    ['label' => 'Документы', 'href' => '#issue-documents', 'show' => (bool) $issueDocumentGroups],
    ['label' => 'Фото', 'href' => '#issue-condition', 'show' => true],
    ['label' => 'Готовность', 'href' => '#issue-readiness', 'show' => true],
    ['label' => 'Факт выдачи', 'href' => '#issue-fact', 'show' => true],
    ['label' => 'Завершение', 'href' => '#issue-finish', 'show' => true],
], static fn(array $link): bool => !empty($link['show'])));

admin_header('Выдача автомобиля', 'rentals');
?>
<section class="page-head">
  <div>
    <p class="eyebrow"><?= e(format_rental_number($rental)) ?></p>
    <h1>Выдача автомобиля</h1>
    <p class="muted"><?= e($rental['carName'] ?: car_name((string) $rental['carSlug'])) ?> · <?= e($rental['clientName'] ?: 'клиент не указан') ?></p>
  </div>
  <div class="actions">
    <?php if ($returnTo !== '' && $returnTo !== 'rental-issue.php?id=' . urlencode($id)): ?><a class="btn secondary" href="<?= e($returnTo) ?>">Вернуться к очереди</a><?php endif; ?>
    <a class="btn secondary" href="rentals.php?edit=<?= urlencode($id) ?>#issue">Карточка аренды</a>
    <a class="btn secondary" href="document-print.php?type=issue-act&rental=<?= urlencode($id) ?>" target="_blank" rel="noopener">Акт выдачи</a>
  </div>
</section>

<section class="panel calendar-context-links compact-summary">
  <a class="btn secondary compact" href="<?= e(admin_calendar_url([
    'page' => 'car',
    'car' => (string) ($rental['carSlug'] ?? ''),
    'date' => $issueDateValue,
    'from' => $issueDateValue,
    'to' => $issueDateValue,
    'view' => 'day',
    'rental_id' => $id,
    'return_to' => 'rental_issue',
    'highlight' => 'issue',
  ])) ?>">Календарь авто на выдачу</a>
  <a class="btn secondary compact" href="<?= e(admin_calendar_url([
    'page' => 'fleet',
    'date' => $issueDateValue,
    'from' => $issueDateValue,
    'to' => $issueDateValue,
    'view' => 'day',
    'car' => (string) ($rental['carSlug'] ?? ''),
    'rental_id' => $id,
    'return_to' => 'rental_issue',
    'highlight' => 'issue',
  ])) ?>">Общий календарь на выдачу</a>
</section>

<section class="panel workflow-command-center workflow-command-center--issue" id="issue-summary" data-stage4c-workflow="issue">
  <div class="workflow-command-head">
    <div>
      <p class="eyebrow">Маршрут выдачи</p>
      <h2><?= e($summary['isCompleted'] ? 'Выдача закрыта в учете' : 'Выдача без лишних переходов') ?></h2>
      <p class="muted"><?= e(format_rental_number($rental)) ?> · <?= e(rental_period_text($rental)) ?> · <?= e($rental['pickupPlace'] ?: 'место выдачи не указано') ?></p>
    </div>
    <a class="btn workflow-command-primary" href="<?= e($issueNextHref) ?>"><?= e($issueNextLabel) ?></a>
  </div>

  <ol class="workflow-stepper" aria-label="Этапы выдачи">
    <?php foreach ($issueSteps as $step): ?>
      <li class="workflow-step workflow-step--<?= e((string) $step['state']) ?>">
        <span><?= e((string) $step['label']) ?></span>
      </li>
    <?php endforeach; ?>
  </ol>

  <div class="workflow-command-tiles">
    <?php foreach ($issueCommandTiles as $tile): ?>
      <article class="workflow-command-tile workflow-command-tile--<?= e((string) $tile['state']) ?>">
        <span><?= e((string) $tile['label']) ?></span>
        <strong><?= e((string) $tile['value']) ?></strong>
        <small><?= e((string) $tile['detail']) ?></small>
      </article>
    <?php endforeach; ?>
  </div>

  <div class="workflow-command-snapshot">
    <article id="issue-client-car">
      <span>Клиент и авто</span>
      <strong><?= e($rental['clientName'] ?: 'клиент не указан') ?></strong>
      <small><?= e($rental['phone'] ?: 'телефон не указан') ?> · <?= e($rental['carName'] ?: car_name((string) $rental['carSlug'])) ?></small>
    </article>
    <article id="issue-period">
      <span>Период и место</span>
      <strong><?= e(rental_period_text($rental)) ?></strong>
      <small><?= e($rental['pickupPlace'] ?: 'место выдачи не указано') ?> → <?= e($rental['returnPlace'] ?: 'место возврата не указано') ?></small>
    </article>
    <article id="issue-finance">
      <span>Деньги и залог</span>
      <strong><?= e($issuePaymentLabel) ?> · <?= e($issueDepositLabel) ?></strong>
      <small><?= e($rental['rentalCost'] === null ? 'стоимость не указана' : format_money((int) $rental['rentalCost'])) ?> · <?= e($rental['deposit'] === null ? 'залог не указан' : format_money((int) $rental['deposit'])) ?></small>
    </article>
  </div>

  <nav class="workflow-anchor-nav" aria-label="Разделы выдачи">
    <?php foreach ($issueSectionNavLinks as $link): ?>
      <a href="<?= e((string) $link['href']) ?>"><?= e((string) $link['label']) ?></a>
    <?php endforeach; ?>
  </nav>
</section>

<?php if ($message): ?><div class="notice success"><?= e($message) ?></div><?php endif; ?>
<?php if ($error): ?><?= admin_error_notice($error) ?><?php endif; ?>
<?php if ($isClosed): ?><div class="notice warning">Аренда уже закрыта. Выдача доступна только для просмотра.</div><?php endif; ?>

<?php if ($issueDocumentGroups): ?>
  <section class="panel workflow-documents" id="issue-documents">
    <div>
      <p class="eyebrow">Документы выдачи</p>
      <h2>Готовность документов</h2>
    </div>
    <?php foreach ($issueDocumentGroups as $document): ?>
      <?php
        $documentState = (string) ($document['state'] ?? 'ready');
        $documentStatusClass = $documentState === 'blocked' ? 'document-status--blocked' : ($documentState === 'warning' ? 'document-status--attention' : '');
      ?>
      <article class="workflow-document-row">
        <div>
          <strong><?= e((string) $document['title']) ?></strong>
          <p class="muted"><?= e((string) $document['readinessLabel']) ?><?= !empty($document['warnings']) ? ' · предупреждений: ' . e((string) count($document['warnings'])) : '' ?></p>
        </div>
        <div class="document-actions">
          <?php if (!empty($document['canPreview'])): ?>
            <a class="btn secondary compact" href="<?= e((string) $document['previewUrl']) ?>" target="_blank" rel="noopener">Предпросмотр</a>
          <?php endif; ?>
          <?php if (!empty($document['canPrint'])): ?>
            <a class="btn secondary compact" href="<?= e((string) $document['printUrl']) ?>" target="_blank" rel="noopener">Печать</a>
          <?php else: ?>
            <span class="document-status <?= e($documentStatusClass) ?>"><?= e((string) $document['readinessLabel']) ?></span>
          <?php endif; ?>
        </div>
      </article>
    <?php endforeach; ?>
  </section>
<?php endif; ?>

<article class="panel workflow-shell">
  <header class="workflow-header">
    <div>
      <p class="eyebrow">Контекст</p>
      <h2><?= e($summary['isCompleted'] ? 'Выдача завершена' : 'Подготовка к выдаче') ?></h2>
      <p class="muted"><?= e(rental_period_text($rental)) ?> · место выдачи: <?= e($rental['pickupPlace'] ?: 'не указано') ?></p>
    </div>
    <div class="workflow-summary">
      <span><strong><?= e((string) $issueCoreReadiness['stateLabel']) ?></strong><small>статус готовности</small></span>
      <span><strong><?= e((string) $summary['photoCount']) ?></strong><small>фото</small></span>
      <span><strong><?= e($summary['mileage'] === null ? 'нет' : number_format((int) $summary['mileage'], 0, '', ' ')) ?></strong><small>пробег</small></span>
      <span><strong><?= e(rental_fuel_level_label((string) $summary['fuelLevel'])) ?></strong><small>топливо</small></span>
    </div>
  </header>

  <section class="workflow-readiness workflow-readiness--<?= e((string) $issueCoreReadiness['state']) ?>" id="issue-readiness">
    <div class="workflow-readiness-head">
      <div>
        <p class="eyebrow">Готовность к выдаче</p>
        <h3><?= e($issueCoreReadiness['state'] === 'ready' ? 'Все обязательные данные заполнены' : ($issueCoreReadiness['state'] === 'missing' ? 'Есть незаполненные данные' : 'Есть пункты внимания')) ?></h3>
      </div>
      <span class="status <?= $issueCoreReadiness['state'] === 'ready' ? 'status-free' : 'status-reserved' ?>"><?= e((string) $issueCoreReadiness['stateLabel']) ?></span>
    </div>
    <?php if ($issueReadinessVisibleItems): ?>
      <div class="workflow-readiness-stats">
        <span>требует внимания <strong><?= e((string) $issueCoreReadiness['counts']['attention']) ?></strong></span>
        <span>не заполнено <strong><?= e((string) $issueCoreReadiness['counts']['missing']) ?></strong></span>
      </div>
      <div class="workflow-readiness-list">
        <?php foreach ($issueReadinessVisibleItems as $item): ?>
          <article class="workflow-readiness-item workflow-readiness-item--<?= e((string) $item['state']) ?>">
            <div>
              <span><?= e((string) $item['stateLabel']) ?></span>
              <strong><?= e((string) $item['label']) ?></strong>
              <small><?= e((string) $item['detail']) ?></small>
            </div>
            <?php if (!$workflowLocked && (string) ($item['actionLabel'] ?? '') !== '' && (string) ($item['actionModal'] ?? '') !== ''): ?>
              <button class="btn secondary compact" type="button" data-rental-attention-modal-open="<?= e((string) $item['actionModal']) ?>"><?= e((string) $item['actionLabel']) ?></button>
            <?php endif; ?>
          </article>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="workflow-ready-note">Система не видит незаполненных обязательных данных для выдачи.</p>
    <?php endif; ?>
    <?php if ($summary['missingItems']): ?>
      <div class="workflow-warning">
        <strong>Завершение выдачи пока заблокировано:</strong>
        <span><?= e(implode(', ', array_slice($summary['missingItems'], 0, 6))) ?><?= count($summary['missingItems']) > 6 ? '…' : '' ?></span>
      </div>
    <?php endif; ?>
    <?php if ($summary['warningItems']): ?>
      <div class="workflow-warning workflow-warning--attention">
        <strong>Перед выдачей стоит проверить:</strong>
        <span><?= e(implode(', ', array_slice($summary['warningItems'], 0, 6))) ?><?= count($summary['warningItems']) > 6 ? '…' : '' ?></span>
      </div>
    <?php endif; ?>
  </section>

  <?php if ($summary['isCompleted']): ?>
    <section class="workflow-result-card" id="issue-result">
      <div>
        <p class="eyebrow">Результат выдачи</p>
        <h3>Выдача завершена <?= e(format_admin_datetime($workflow['completedAt'])) ?><?= $workflow['completedBy'] ? ' · ' . e($workflow['completedBy']) : '' ?></h3>
      </div>
      <div class="workflow-result-grid">
        <span>Пробег: <strong><?= e($summary['mileage'] === null ? 'не указан' : number_format((int) $summary['mileage'], 0, '', ' ') . ' км') ?></strong></span>
        <span>Топливо: <strong><?= e(rental_fuel_level_label((string) $summary['fuelLevel'])) ?></strong></span>
        <span>Фото: <strong><?= e((string) $summary['photoCount']) ?></strong></span>
        <span>Документы: <strong><?= e($issueCoreReadiness['state'] === 'ready' ? 'готовы' : 'требуют проверки') ?></strong></span>
      </div>
    </section>
  <?php endif; ?>

  <form method="post" class="workflow-form">
    <input type="hidden" name="expected_version" value="<?= e(business_record_version(RENTALS_FILE, $id)) ?>">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="id" value="<?= e($id) ?>">
    <input type="hidden" name="return_to" value="<?= e($returnTo) ?>">

    <?php if ($workflowLocked): ?>
      <details class="workflow-service-details workflow-completed-details">
        <summary>Показать подробности выдачи</summary>
    <?php endif; ?>

    <div class="workflow-grid">
      <section class="workflow-card" id="issue-fact">
        <h3>Факт выдачи</h3>
        <div class="workflow-fields">
          <label>Дата выдачи <input type="date" name="issue_date" value="<?= e($issueDateValue) ?>" <?= $workflowLocked ? 'disabled' : '' ?>></label>
          <label>Время выдачи <input type="time" name="issue_time" value="<?= e($issueTimeValue) ?>" <?= $workflowLocked ? 'disabled' : '' ?>></label>
          <label>Пробег <input name="issue_workflow_mileage" inputmode="numeric" value="<?= e($workflow['mileage'] === null ? (($rental['startMileage'] ?? null) === null ? '' : (string) $rental['startMileage']) : (string) $workflow['mileage']) ?>" placeholder="км" <?= $workflowLocked ? 'disabled' : '' ?>></label>
          <label>
            Топливо
            <select name="issue_workflow_fuel" <?= $workflowLocked ? 'disabled' : '' ?>>
              <?php foreach ($fuelLevels as $key => $label): ?>
                <option value="<?= e($key) ?>" <?= $key === $workflow['fuelLevel'] ? 'selected' : '' ?>><?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
          </label>
          <label class="workflow-field-wide">Комментарий выдачи <textarea name="issue_workflow_comment" rows="4" <?= $workflowLocked ? 'disabled' : '' ?>><?= e($workflow['comment']) ?></textarea></label>
        </div>
      </section>

      <section class="workflow-card workflow-final-zone workflow-final-zone--<?= e($issueFinalState) ?>" id="issue-finish">
        <div class="workflow-final-head">
          <div>
            <p class="eyebrow">Финиш выдачи</p>
            <h3>Финальное подтверждение</h3>
          </div>
          <span class="status <?= e($issueFinalStatusClass) ?>"><?= e($issueFinalStatusLabel) ?></span>
        </div>
        <div class="workflow-final-alert workflow-final-alert--<?= e($issueFinalState) ?>">
          <div>
            <strong><?= e($issueFinalHeadline) ?></strong>
            <small><?= e($issueFinalDetail) ?></small>
          </div>
          <div class="workflow-final-metrics">
            <span><strong><?= e((string) $issueFinalRequiredReady) ?>/<?= e((string) $issueFinalRequiredTotal) ?></strong><small>обязательных готово</small></span>
            <span><strong><?= e((string) count($issueFinalBlockingItems)) ?></strong><small>не хватает</small></span>
            <span><strong><?= e((string) count($issueFinalAttentionItems)) ?></strong><small>пунктов внимания</small></span>
          </div>
        </div>
        <?php if ($issueFinalBlockingItems): ?>
          <div class="workflow-final-checklist workflow-final-checklist--blocked">
            <strong>Не хватает перед завершением</strong>
            <?php foreach ($issueFinalBlockingItems as $item): ?>
              <?php
                $actionLabel = (string) ($item['actionLabel'] ?? '');
                $actionModal = (string) ($item['actionModal'] ?? '');
              ?>
              <article class="workflow-final-check is-missing">
                <div>
                  <span><?= e((string) ($item['label'] ?? 'Пункт выдачи')) ?></span>
                  <small><?= e((string) (($item['detail'] ?? '') ?: ($item['stateLabel'] ?? 'Нужно заполнить'))) ?></small>
                </div>
                <?php if (!$workflowLocked && $actionLabel !== '' && $actionModal !== ''): ?>
                  <button class="btn secondary compact" type="button" data-rental-attention-modal-open="<?= e($actionModal) ?>"><?= e($actionLabel) ?></button>
                <?php endif; ?>
              </article>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <?php if ($issueFinalAttentionItems): ?>
          <div class="workflow-final-checklist workflow-final-checklist--attention">
            <strong>Проверить перед выдачей</strong>
            <?php foreach ($issueFinalAttentionItems as $item): ?>
              <?php
                $actionLabel = (string) ($item['actionLabel'] ?? '');
                $actionModal = (string) ($item['actionModal'] ?? '');
              ?>
              <article class="workflow-final-check is-attention">
                <div>
                  <span><?= e((string) ($item['label'] ?? 'Пункт проверки')) ?></span>
                  <small><?= e((string) (($item['detail'] ?? '') ?: ($item['stateLabel'] ?? 'Стоит проверить'))) ?></small>
                </div>
                <?php if (!$workflowLocked && $actionLabel !== '' && $actionModal !== ''): ?>
                  <button class="btn secondary compact" type="button" data-rental-attention-modal-open="<?= e($actionModal) ?>"><?= e($actionLabel) ?></button>
                <?php endif; ?>
              </article>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <ul class="workflow-capture-list">
          <li>Фактические дата, время, пробег и топливо заполнены</li>
          <li>Платежи, залог, клиент и автомобиль проверены</li>
          <li>Менеджер лично подтверждает передачу ключей и документов</li>
        </ul>
        <input type="hidden" name="issue_manual_handover_present" value="1">
        <label class="workflow-final-confirmation <?= $issueHandoverConfirmed ? 'is-done' : 'is-required' ?>">
          <input type="checkbox" name="issue_manual_handover" value="1" <?= $issueHandoverConfirmed ? 'checked' : '' ?> <?= $workflowLocked ? 'disabled' : '' ?>>
          <span>
            <strong>Подтверждаю передачу клиенту</strong>
            <small>Ключи, документы и автомобиль переданы; дата, время, пробег и топливо соответствуют факту.</small>
          </span>
        </label>
      </section>
    </div>

    <details class="workflow-service-details workflow-legacy-checklist" id="issue-checklist">
      <summary>Служебные данные прежнего чеклиста</summary>
      <div class="workflow-checklist">
        <?php foreach (rental_workflow_checklist_labels('issue') as $key => $label): ?>
          <span class="workflow-checklist-item <?= !empty($workflow['checklist'][$key]) ? 'is-done' : '' ?>">
            <?= !empty($workflow['checklist'][$key]) ? '✓' : '—' ?> <?= e($label) ?>
          </span>
        <?php endforeach; ?>
      </div>
    </details>

    <?php if ($workflowLocked): ?>
      </details>
    <?php endif; ?>

    <?php if ($canEditWorkflow && !$workflowLocked): ?>
      <div class="workflow-actions workflow-final-actions">
        <button class="btn secondary" type="submit" name="action" value="issue_save_draft">Сохранить черновик выдачи</button>
        <button class="btn" type="submit" name="action" value="issue_complete" onclick="return confirm('Завершить выдачу и перевести аренду в статус “Выдан”?');">Завершить выдачу</button>
      </div>
    <?php elseif ($workflow['status'] === 'completed'): ?>
      <div class="notice success">Выдача завершена <?= e(format_admin_datetime($workflow['completedAt'])) ?><?= $workflow['completedBy'] ? ' · ' . e($workflow['completedBy']) : '' ?>. Поля доступны только для просмотра.</div>
    <?php endif; ?>
  </form>
</article>

<details class="panel workflow-photo-panel workflow-photo-panel--optional workflow-photo-details" id="issue-condition">
  <summary class="workflow-photo-summary">
    <span>
      <span class="eyebrow">Фотофиксация</span>
      <strong>Фото перед выдачей</strong>
      <small>Не обязательно для завершения выдачи. Можно добавить при необходимости.</small>
    </span>
    <span class="workflow-photo-summary-meta">
      <span>Загружено: <?= e((string) $issuePhotoReadyCount) ?> / <?= e((string) $issuePhotoRequiredTotal) ?></span>
      <strong><?= $issuePhotoRecommendedItems ? 'Рекомендуется' : 'Готово' ?></strong>
    </span>
  </summary>

  <p class="workflow-photo-note">
    Фото не блокируют выдачу. При новой загрузке старое служебное фото этой же машины, этапа и категории будет перенесено в quarantine после успешного сохранения нового файла.
  </p>

  <?php if ($canEditWorkflow): ?>
    <form class="workflow-photo-upload" data-workflow-media-form method="post" enctype="multipart/form-data" action="api/rental-media.php">
      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="upload">
      <input type="hidden" name="rental_id" value="<?= e($id) ?>">
      <input type="hidden" name="stage" value="issue">
      <label>
        Категория
        <select name="category">
          <?php foreach ($issueCategories as $key => $label): ?>
            <option value="<?= e($key) ?>"><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Фото <input type="file" name="photo" accept="image/jpeg,image/png,image/webp" required></label>
      <button class="btn secondary" type="submit">Загрузить фото</button>
      <span class="field-hint">JPG, PNG или WebP до 10 МБ. Фото хранятся в приватной папке.</span>
    </form>
  <?php endif; ?>

  <?php if (!$workflow['photos']): ?>
    <p class="muted">Фото выдачи пока нет. Выдачу можно завершить без фото, если остальные обязательные данные заполнены.</p>
  <?php else: ?>
    <div class="workflow-photo-grid">
      <?php foreach ($workflow['photos'] as $photo): ?>
        <article class="workflow-photo-card" data-workflow-photo-id="<?= e((string) $photo['id']) ?>">
          <a href="api/rental-media.php?action=view&rental_id=<?= urlencode($id) ?>&media_id=<?= urlencode((string) $photo['id']) ?>" target="_blank" rel="noopener">
            <img src="api/rental-media.php?action=view&rental_id=<?= urlencode($id) ?>&media_id=<?= urlencode((string) $photo['id']) ?>" alt="">
          </a>
          <div>
            <strong><?= e(rental_media_category_label('issue', (string) $photo['category'])) ?></strong>
            <small><?= e(format_admin_datetime((string) $photo['uploadedAt'])) ?></small>
          </div>
          <?php if ($canEditWorkflow): ?>
            <form data-workflow-media-delete method="post" action="api/rental-media.php">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="rental_id" value="<?= e($id) ?>">
              <input type="hidden" name="media_id" value="<?= e((string) $photo['id']) ?>">
              <button class="btn secondary compact danger" type="submit">Удалить</button>
            </form>
          <?php endif; ?>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</details>

<?php if ($issueReadinessActionModals): ?>
  <div class="rental-attention-modal-backdrop" data-rental-attention-modal-backdrop hidden></div>
  <?php foreach ($issueReadinessActionModals as $modalKey => $item): ?>
    <aside class="rental-attention-modal is-side-panel" data-rental-attention-modal="<?= e((string) $modalKey) ?>" hidden aria-hidden="true" role="dialog" aria-modal="true">
      <button class="rental-attention-modal-close" type="button" data-rental-attention-modal-close aria-label="Закрыть">×</button>
      <div class="rental-attention-modal-head">
        <div>
          <p class="eyebrow">Готовность к выдаче</p>
          <h2><?= e((string) $item['label']) ?></h2>
          <p class="muted"><?= e((string) $item['detail']) ?></p>
        </div>
      </div>

      <?php if ($modalKey === 'issue-fact'): ?>
        <form class="rental-attention-modal-form" method="post">
          <input type="hidden" name="expected_version" value="<?= e(business_record_version(RENTALS_FILE, $id)) ?>">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="id" value="<?= e($id) ?>">
          <input type="hidden" name="return_to" value="<?= e($returnTo) ?>">
          <input type="hidden" name="action" value="issue_save_draft">
          <div class="rental-attention-modal-grid">
            <label>Дата выдачи <input type="date" name="issue_date" value="<?= e($issueDateValue) ?>" data-rental-attention-autofocus></label>
            <label>Время выдачи <input type="time" name="issue_time" value="<?= e($issueTimeValue) ?>"></label>
            <label>Пробег <input name="issue_workflow_mileage" inputmode="numeric" value="<?= e($workflow['mileage'] === null ? (($rental['startMileage'] ?? null) === null ? '' : (string) $rental['startMileage']) : (string) $workflow['mileage']) ?>" placeholder="км"></label>
            <label>
              Топливо
              <select name="issue_workflow_fuel">
                <?php foreach ($fuelLevels as $key => $label): ?>
                  <option value="<?= e($key) ?>" <?= $key === $workflow['fuelLevel'] ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
            <label class="rental-attention-modal-wide">Комментарий <textarea name="issue_workflow_comment" rows="3"><?= e($workflow['comment']) ?></textarea></label>
          </div>
          <div class="rental-attention-modal-actions">
            <button class="btn" type="submit">Сохранить данные выдачи</button>
            <button class="btn secondary" type="button" data-rental-attention-modal-close>Отмена</button>
          </div>
        </form>
      <?php elseif (in_array($modalKey, ['issue-photo-body', 'issue-photo-interior', 'issue-photo-odometer'], true)): ?>
        <form class="rental-attention-modal-form" data-workflow-media-form method="post" enctype="multipart/form-data" action="api/rental-media.php">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="action" value="upload">
          <input type="hidden" name="rental_id" value="<?= e($id) ?>">
          <input type="hidden" name="stage" value="issue">
          <?php if ($modalKey === 'issue-photo-body'): ?>
            <label>
              Категория кузова
              <select name="category" data-rental-attention-autofocus>
                <?php foreach (['front', 'rear', 'left', 'right'] as $categoryKey): ?>
                  <option value="<?= e($categoryKey) ?>"><?= e(rental_media_category_label('issue', $categoryKey)) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
          <?php else: ?>
            <input type="hidden" name="category" value="<?= $modalKey === 'issue-photo-interior' ? 'interior' : 'odometer' ?>">
          <?php endif; ?>
          <label>Фото <input type="file" name="photo" accept="image/jpeg,image/png,image/webp" required <?= $modalKey === 'issue-photo-body' ? '' : 'data-rental-attention-autofocus' ?>></label>
          <div class="rental-attention-modal-actions">
            <button class="btn" type="submit">Загрузить фото</button>
            <button class="btn secondary" type="button" data-rental-attention-modal-close>Отмена</button>
          </div>
        </form>
      <?php else: ?>
        <div class="rental-attention-modal-form">
          <p class="muted">Этот пункт заполняется в карточке аренды, где уже есть защищённая форма с нужными правами.</p>
          <div class="rental-attention-modal-actions">
            <?php if ($modalKey === 'issue-payment'): ?>
              <a class="btn" href="rentals.php?edit=<?= urlencode($id) ?>&focus=payment&openFinance=payment">Добавить оплату</a>
            <?php elseif ($modalKey === 'issue-deposit'): ?>
              <a class="btn" href="rentals.php?edit=<?= urlencode($id) ?>&focus=deposit&openFinance=deposit">Внести залог</a>
            <?php elseif ($modalKey === 'issue-contract'): ?>
              <a class="btn" href="rentals.php?edit=<?= urlencode($id) ?>&focus=documents">Подготовить договор</a>
              <a class="btn secondary" href="document-print.php?type=contract&rental=<?= urlencode($id) ?>" target="_blank" rel="noopener">Предпросмотр договора</a>
            <?php elseif ($modalKey === 'issue-customer'): ?>
              <a class="btn" href="rentals.php?edit=<?= urlencode($id) ?>&focus=documents">Заполнить данные клиента</a>
            <?php elseif ($modalKey === 'issue-car'): ?>
              <a class="btn" href="rentals.php?edit=<?= urlencode($id) ?>&focus=car">Назначить автомобиль</a>
            <?php endif; ?>
            <button class="btn secondary" type="button" data-rental-attention-modal-close>Закрыть</button>
          </div>
        </div>
      <?php endif; ?>
    </aside>
  <?php endforeach; ?>
<?php endif; ?>

<?php admin_footer(); ?>
