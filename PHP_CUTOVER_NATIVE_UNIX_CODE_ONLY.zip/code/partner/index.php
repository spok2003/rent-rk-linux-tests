<?php
declare(strict_types=1);

header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
$method = (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET');
if (!in_array($method, ['GET', 'HEAD'], true)) {
    header('Allow: GET, HEAD');
    http_response_code(405);
    exit;
}
$path = parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
if (!is_string($path) || !preg_match('~^/partner/([a-z0-9-]+)(?:/([a-z0-9-]+))?/?$~D', preg_replace('~/index\.html$~', '/', $path), $match)) {
    http_response_code(404);
    exit('Партнёрская ссылка не найдена.');
}
$partnerSlug = $match[1];
$agentSlug = $match[2] ?? '';
try {
    require_once __DIR__ . '/../admin/includes/bootstrap.php';
    $partner = find_partner_by_slug($partnerSlug);
    $agent = $agentSlug !== '' ? find_partner_agent($partnerSlug, $agentSlug) : null;
    $agentUser = $agent ? find_admin_user((string) $agent['login']) : null;
    if (!$partner || $partner['slug'] !== $partnerSlug || empty($partner['active'])
        || ($agentSlug !== '' && (!$agent || $agent['slug'] !== $agentSlug || !$agentUser || empty($agentUser['active']) || !empty($agentUser['archived'])))) {
        http_response_code(404);
        exit('Партнёрская ссылка не найдена или отключена.');
    }
    $canonicalPath = '/partner/' . rawurlencode($partnerSlug) . '/' . ($agentSlug !== '' ? rawurlencode($agentSlug) . '/' : '');
    if ($path !== $canonicalPath || isset($_GET['partner']) || isset($_GET['agent'])) {
        header('Location: ' . $canonicalPath, true, 302);
        exit;
    }
    if ($method === 'GET') {
        partner_deal_register_public_context($partnerSlug, $agentSlug);
    }
    $publicCars = array_values(array_filter(read_cars(), static fn(array $car): bool =>
        preg_match('~^[a-z0-9]+(?:-[a-z0-9]+)*$~D', (string) ($car['slug'] ?? '')) === 1
        && public_car_visible_for_api($car, $partner, 'partner_page')
    ));
    $rates = read_rates()['cars'];
} catch (Throwable $error) {
    http_response_code(503);
    exit('Партнёрская страница временно недоступна. Попробуйте позже.');
}
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
if ($agent) header('X-Robots-Tag: noindex, noarchive');
if ($method === 'HEAD') exit;
?>
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php if ($agent): ?><meta name="robots" content="noindex, noarchive"><?php endif; ?>
  <title>Партнёрская ссылка <?= e($partner['name']) ?> | Rent RK</title>
  <meta name="description" content="Партнёрская страница Rent RK: проверка доступности автомобилей и создание заявки клиента.">
  
  <link rel="canonical" href="https://base-rent.ru<?= e($canonicalPath) ?>">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Rent RK">
  <meta property="og:title" content="Партнёрская ссылка <?= e($partner['name']) ?> | Rent RK">
  <meta property="og:description" content="Партнёрская страница Rent RK: проверка доступности автомобилей и создание заявки клиента.">
  <meta property="og:url" content="https://base-rent.ru<?= e($canonicalPath) ?>">
  <meta property="og:image" content="https://base-rent.ru/assets/img/cars/jaecoo-j7/jaecoo-j7-1.jpg">
  <meta name="twitter:card" content="summary_large_image">
  <link rel="stylesheet" href="/assets/css/main.css?v=20260704200400">
</head>
<body>
  <header class="site-header">
    <div class="container nav">
      <a class="brand" href="/index.html">Rent RK <small>автопрокат в Ялте</small></a>
      <a class="good-place-badge" href="https://yandex.ru/maps/org/apriori/134040500420/" target="_blank" rel="noopener" aria-label="Хорошее место 2026 на Яндекс Картах">
        <img src="/assets/img/good-place-2026.png" alt="Хорошее место 2026" width="178" height="25">
      </a>
      <nav class="menu" aria-label="Основная навигация">
        <a href="#partner-catalog">Автомобили</a>
        <a href="/pages/conditions.html">Условия</a>
        <a href="/pages/faq.html">FAQ</a>
        <a href="/routes/index.html">Маршруты</a>
        
      </nav>
      <div class="header-actions">
        <a class="btn" href="#partner-request">Создать заявку</a>
      </div>
    </div>
  </header>
  <nav class="breadcrumbs container" aria-label="Хлебные крошки">
    <a href="/index.html">Главная</a><span aria-hidden="true">/</span>
    <span aria-current="page">Партнёр <?= e($partner['name']) ?></span>
  </nav>

  <main>
    <section class="hero compact" style="--hero-image: url('/assets/img/cars/jaecoo-j7/jaecoo-j7-1.jpg')">
      <div class="container hero-content">
        <p class="eyebrow">Партнёр Rent RK</p>
        <h1><?= e($partner['name']) ?></h1>
        <p class="lead">Проверьте свободные автомобили по датам или отправьте заявку на подбор. Заявка будет закреплена за партнёрским каналом<?php if ($agent): ?> и представителем <?= e($agent['name']) ?><?php endif; ?>.</p>
      </div>
    </section>

    <section class="section soft">
      <div class="container partner-workspace">
        <article class="feature partner-panel" data-partner-availability data-api="/api/available-cars.php" data-partner="<?= e($partnerSlug) ?>" data-agent="<?= e($agentSlug) ?>" data-site-root="/">
          <div class="section-head compact-head">
            <div>
              <p class="eyebrow">Доступность</p>
              <h2>Проверить даты</h2>
              <p>Система покажет только автомобили, которые свободны на выбранные даты.</p>
            </div>
          </div>
          <form class="partner-search-form">
            <input type="hidden" name="start_date">
            <input type="hidden" name="end_date">
            <div class="date-range-picker" data-date-range-picker data-date-range-start-label="Подача" aria-label="Календарь выбора дат аренды">
              <div class="date-range-picker__head">
                <button class="date-range-picker__nav" type="button" data-date-range-prev aria-label="Предыдущий месяц">&lsaquo;</button>
                <strong data-date-range-month></strong>
                <button class="date-range-picker__nav" type="button" data-date-range-next aria-label="Следующий месяц">&rsaquo;</button>
              </div>
              <p class="date-range-picker__summary" data-date-range-summary>Выберите дату подачи и возврата</p>
              <div class="date-range-picker__grid" data-date-range-grid></div>
            </div>
            <div class="form-grid partner-search-times">
              <label>Время подачи <input type="time" name="start_time"></label>
              <label>Время возврата <input type="time" name="end_time"></label>
            </div>
            <button class="btn" type="submit">Показать свободные авто</button>
          </form>
          <p class="form-note" data-partner-availability-message></p>
          <div class="partner-availability-results" data-partner-availability-results></div>
        </article>

        <article class="feature partner-panel" id="partner-request">
          <div class="section-head compact-head">
            <div>
              <p class="eyebrow">Заявка</p>
              <h2>Создать заявку клиента</h2>
              <p>Менеджер Rent RK проверит детали, подтвердит бронь и свяжется с клиентом.</p>
            </div>
          </div>
          <form class="booking-form" data-booking-form data-partner-request-form action="/api/request.php" method="post">
            <input type="hidden" name="partner_slug" value="<?= e($partnerSlug) ?>">
            <input type="hidden" name="partner_agent_slug" value="<?= e($agentSlug) ?>">
            <label class="hp-field">Не заполняйте это поле <input name="website" tabindex="-1" autocomplete="off"></label>
            <div class="form-grid">
              <input type="hidden" name="car_slug" data-partner-car-select>
              <input type="hidden" name="car_name" data-partner-car-name>
              <input type="hidden" name="request_kind" value="specific" data-partner-request-kind>
              <label>Имя клиента <input name="name" autocomplete="name" placeholder="Как обращаться"></label>
              <label>Телефон клиента <input name="phone" autocomplete="tel" placeholder="+7..." required></label>
              <label>Дата подачи <input type="date" name="start_date" required></label>
              <label>Время подачи <input type="time" name="start_time"></label>
              <label>Дата возврата <input type="date" name="end_date" required></label>
              <label>Время возврата <input type="time" name="end_time"></label>
            </div>
            <div class="form-grid">
              <label>Место подачи <input name="pickup_place" value="<?= e($partner['defaultPickupPlace']) ?>" placeholder="Отель, адрес, город"></label>
              <label>Место возврата <input name="return_place" placeholder="Если отличается от подачи"></label>
            </div>
            <div class="partner-selected-car" data-partner-selected-car>
              <strong>Автомобиль не выбран</strong>
              <span>Сначала проверьте даты и выберите свободную машину. Если клиенту нужен подбор, отправьте заявку на подбор.</span>
            </div>
            <label>Комментарий <textarea name="message" rows="4" placeholder="Номер комнаты, пожелания клиента, детское кресло"></textarea></label>
            <label class="check-row">
              <input type="checkbox" name="consent" value="1" required>
              <span>Клиент согласен на передачу данных менеджеру Rent RK для связи по заявке.</span>
            </label>
            <div class="partner-form-actions">
              <button class="btn" type="submit" data-partner-specific-submit disabled>Отправить по выбранному авто</button>
              <button class="btn secondary" type="submit" data-partner-selection-submit>Заявка на подбор</button>
            </div>
            <p class="form-note" data-form-message></p>
          </form>
          <div class="booking-success feature" data-booking-success hidden>
            <p class="eyebrow">Заявка принята</p>
            <h3>Заявка передана менеджеру</h3>
            <p>Спасибо. Менеджер проверит календарь и свяжется с клиентом для подтверждения условий.</p>
          </div>
        </article>
      </div>
    </section>

    <section class="section">
      <div class="container section-head">
        <div>
          <p class="eyebrow">Каталог</p>
          <h2>Выбрать автомобиль</h2>
          <p>Все переходы из этого каталога сохраняют партнёрскую метку <?= e($partnerSlug) ?>.</p>
        </div>
      </div>
      <div class="container grid cards" id="partner-catalog">
        <?php foreach ($publicCars as $car):
          $carSlug = (string) $car['slug'];
          $carUrl = '/cars/' . rawurlencode($carSlug) . '.html?' . http_build_query(array_filter(['partner' => $partnerSlug, 'agent' => $agentSlug], static fn($value) => $value !== ''));
          $rate = $rates[$carSlug] ?? [];
          $price = normalize_rate_price($rate['manual'] ?? null) ?? normalize_rate_price($rate['base'] ?? null) ?? normalize_rate_price($car['price'] ?? null);
          $image = ltrim((string) ($car['image'] ?? ''), '/');
          if (!preg_match('~^assets/img/cars/[a-zA-Z0-9_./-]+$~D', $image) || str_contains($image, '..')) $image = 'assets/img/cars/jaecoo-j7/jaecoo-j7-1.jpg';
        ?>
        <article class="card car-card" data-car-card data-slug="<?= e($carSlug) ?>" data-car-slug="<?= e($carSlug) ?>">
          <div class="car-card__media">
            <a href="<?= e($carUrl) ?>" class="car-card__image"><img src="/<?= e($image) ?>" alt="<?= e($car['name'] ?? $carSlug) ?>" loading="lazy" width="1280" height="720"></a>
            <?php if ($price !== null): ?><div class="car-card__price-badge">от <?= e(number_format($price, 0, ',', ' ')) ?> ₽/сут</div><?php endif; ?>
          </div>
          <div class="card-body car-card__body">
            <div class="car-card__heading"><h3><a href="<?= e($carUrl) ?>"><?= e($car['name'] ?? $carSlug) ?></a></h3></div>
            <div class="meta car-card__features">
              <?php foreach (['class', 'transmission', 'drive'] as $field): if (!empty($car[$field]) && is_string($car[$field])): ?><span class="pill car-card__feature"><?= e($car[$field]) ?></span><?php endif; endforeach; ?>
              <?php if (!empty($car['seats'])): ?><span class="pill car-card__feature"><?= (int) $car['seats'] ?> мест</span><?php endif; ?>
            </div>
            <div class="car-card__availability"><small>Выберите даты, чтобы увидеть статус автомобиля.</small></div>
            <div class="card-bottom car-card__actions"><a class="btn" href="<?= e($carUrl) ?>#booking" data-car-primary-action>Проверить даты</a><a class="btn secondary" href="<?= e($carUrl) ?>" data-car-detail-link>Подробнее</a></div>
          </div>
        </article>
        <?php endforeach; ?>
        <?php if (!$publicCars): ?><p class="muted">Сейчас в каталоге канала нет доступных автомобилей. Отправьте заявку на подбор — менеджер уточнит варианты.</p><?php endif; ?>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container footer-grid">
      <div>
        <strong>Rent RK</strong>
        <p class="muted">Аренда автомобилей в Ялте и Крыму. Бесплатная доставка по Ялте, подача по Крыму по договоренности.</p>
      </div>
            <div>
        <strong>Партнёрская заявка</strong>
        <p><a href="#partner-request">Создать заявку клиента</a><br>Заявка будет закреплена за партнёрским каналом.</p>
      </div>
      <div>
        <strong>Документы</strong>
        <p><a href="/pages/conditions.html">Условия аренды</a><br><a href="/pages/faq.html">Вопросы и ответы</a><br><a href="#partner-catalog">Каталог автомобилей</a></p>
      </div>
    </div>
    <div class="container"><p class="muted">© <span data-current-year></span> АПРИОРИ.</p></div>
  </footer>
  
  <script src="/assets/js/analytics-tracker.js?v=20260522204637"></script>
  <script src="/assets/js/main.js?v=20260704205200"></script>
</body>
</html>
