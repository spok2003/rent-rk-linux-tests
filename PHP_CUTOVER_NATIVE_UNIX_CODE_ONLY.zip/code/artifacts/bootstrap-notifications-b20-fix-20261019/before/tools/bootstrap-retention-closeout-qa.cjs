'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process'),crypto=require('crypto'),net=require('net');
const root=path.resolve(__dirname,'..'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const canonical=x=>Array.isArray(x)?x.map(canonical):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,canonical(x[k])])):x;
const same=(a,b)=>JSON.stringify(canonical(a))===JSON.stringify(canonical(b));
const INPUT_ENTRIES=[
 'artifacts/bootstrap-admin-remediation-20261018/final-5/primary.json',
 'artifacts/bootstrap-admin-remediation-20261018/final-5/receipt.json',
 'artifacts/bootstrap-admin-remediation-20261018/source-final.json',
 'artifacts/bootstrap-retention-dependency-closeout-20261018/before/admin/includes/bootstrap.php'
];
const ARTIFACT_ENTRIES=INPUT_ENTRIES.map(p=>", {\n  path: '"+p+"',\n  artifactClass: 'version-bound-qa-evidence-input',\n  purpose: 'Retention closeout: preserved phase04 evidence and exact pre-hook runtime for bounded applicability.'\n}").join('');
async function main(options={}){
 const run=process.env.RENT_RK_QA_RUN_BINDING;
 if(!/^[a-f0-9]{32}$/.test(run||'')||path.resolve(process.env.RENT_RK_AUDIT_LAB_ROOT||'')!==root||!fs.existsSync(path.join(root,'.rent-rk-test-lab')))throw Error('Verified laboratory required');
 const out=path.join(root,'tmp/bootstrap-admin-operations',run);fs.mkdirSync(out,{recursive:true});
 const rows=[],observations=[],environments=[];let failure=null;
 const check=(test,actual,expected)=>{const passed=same(actual,expected);rows.push({test,passed,actual,expected});if(!passed)throw Error(test);};
 const php=process.env.RENT_RK_QA_PHP||process.env.PHP_BINARY||'php',args=['-d','opcache.enable=0','-d','opcache.enable_cli=0','-d','opcache.file_cache=','-d','opcache.file_cache_only=0'];
 const worker=(script,args2)=>{const r=cp.spawnSync(php,[...args,script,...args2],{cwd:root,env:process.env,encoding:'utf8',windowsHide:true,timeout:30000});if(r.status!==0)throw Error('Worker failed '+r.status+':'+r.stderr.slice(0,150));const j=JSON.parse(r.stdout);if(j.environment)environments.push(j.environment);return j;};
 const old={id:'old-photo',stage:'issue',category:'front',relativePath:'rental-media/phase-old/issue/old-photo.png',uploadedAt:'2036-01-01T10:00:00+03:00'};
 const photo={id:'new-photo',stage:'issue',category:'front',relativePath:'rental-media/phase-new/issue/new-photo.png',uploadedAt:'2036-01-02T10:00:00+03:00'};
 const bytes=Buffer.from('TASK OWNED ORIGINAL RETENTION PHOTO');
 const snap=d=>Object.fromEntries(fs.readdirSync(d).filter(x=>x.endsWith('.json')).sort().map(n=>[n,fs.readFileSync(path.join(d,n),'utf8')]));
 const tree=d=>{const result={};if(!fs.existsSync(d))return result;const walk=(p,rel='')=>{for(const e of fs.readdirSync(p,{withFileTypes:true})){if(e.isSymbolicLink())throw Error('Unexpected link');if(e.isDirectory())walk(path.join(p,e.name),rel+e.name+'/');else result[rel+e.name]=sha(fs.readFileSync(path.join(p,e.name)));}};walk(d);return result;};
 try{
  const read=p=>JSON.parse(fs.readFileSync(path.join(root,p))),norm=p=>fs.readFileSync(path.join(root,p),'utf8').replaceAll('\r\n','\n');
  const oldPrimary=read(INPUT_ENTRIES[0]),oldReceipt=read(INPUT_ENTRIES[1]),oldSource=read(INPUT_ENTRIES[2]);
  const chunks=s=>{const list=[...s.matchAll(/^function ([a-zA-Z_0-9]+)\(/gm)];return{prefix:s.slice(0,list[0].index),functions:Object.fromEntries(list.map((x,i)=>[x[1],s.slice(x.index,list[i+1]?.index)]))};};
  const before=chunks(norm(INPUT_ENTRIES[3])),after=chunks(norm('admin/includes/bootstrap.php'));
  const changed=Object.keys({...before.functions,...after.functions}).filter(k=>before.functions[k]!==after.functions[k]);
  check('retention_only_authorized_runtime_delta',{prefix:before.prefix===after.prefix,changed},{prefix:true,changed:['rental_media_retention_after_successful_upload']});
  let reversed=after.functions.rental_media_retention_after_successful_upload;
  const start=reversed.indexOf('    // Fixed I/O outcomes'),end=reversed.indexOf('    $result = [',start);
  reversed=reversed.slice(0,start)+reversed.slice(end);
  reversed=reversed.replace("$retentionIo('copy', $quarantinePath, static fn() => copy($sourceReal, $quarantinePath))","copy($sourceReal, $quarantinePath)")
   .replace("$retentionIo('open', $quarantinePath, static fn() => fopen($quarantinePath, 'r+b'))","fopen($quarantinePath, 'r+b')")
   .replace("$retentionIo('flush', $quarantinePath, static fn() => fflush($copyStream))","fflush($copyStream)")
   .replace("$retentionIo('sync', $quarantinePath, static fn() => fsync($copyStream))","fsync($copyStream)");
  check('retention_disabled_original_body_parity',reversed===before.functions.rental_media_retention_after_successful_upload,true);
  check('retained_phase04_primary_integrity',{sha:sha(fs.readFileSync(path.join(root,INPUT_ENTRIES[0])))===oldReceipt.primaryReport.sha256,status:oldPrimary.status,count:oldPrimary.results.length,failed:oldPrimary.results.filter(x=>!x.passed).length},{sha:true,status:'PASS',count:174,failed:0});
  const permitted=['admin/includes/bootstrap.php','tools/business-data-review-policy.json','tools/business-data-audit.cjs','tools/bootstrap-admin-operations-qa.cjs','tools/bootstrap-admin-remediation-qa.cjs'];
  const mismatches=Object.entries(oldSource.hashes).filter(([p,h])=>!permitted.includes(p)&&sha(fs.readFileSync(path.join(root,p)))!==h).map(([p])=>p);
  check('retained_phase04_unchanged_native_dependencies',mismatches,[]);
  observations.push({id:'retained_phase04_applicability',primary:INPUT_ENTRIES[0],sha256:oldReceipt.primaryReport.sha256,originalSource:oldReceipt.sourceSha256,originalLaboratoryId:oldReceipt.laboratoryId,originalRunBinding:oldReceipt.runBinding,changedFunctions:changed,limit:'Historical 174 checks remain historical. This run proves narrow applicability for unchanged functions, not a new execution of those 174 or all callers.'});
  for(const mode of ['copy_short','copy_corrupt','open','flush','sync','normal','denial-run','denial-env-only','denial-root','denial-source','unknown']){
   const dir=path.join(out,mode);fs.mkdirSync(dir,{recursive:true});worker('tools/bootstrap-admin-operations-qa.php',['seed',dir]);
   const data=path.join(dir,'data'),rentals={items:[{id:'phase-old',carSlug:'phase-north',car_owner_scope_id:'north',car_owner_type:'lessor',future:{keep:1},issueWorkflow:{status:'pending',photos:[old]}},{id:'phase-new',carSlug:'phase-north',car_owner_scope_id:'north',car_owner_type:'lessor',issueWorkflow:{photos:[photo]}}],nextNumber:100,future:{keep:2}};
   fs.writeFileSync(path.join(data,'rentals.json'),JSON.stringify(rentals));
   for(const p of [old,photo]){const f=path.join(data,p.relativePath);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,bytes);}
   const before=snap(data),source=path.join(data,old.relativePath);
   const invoke=(m,denial='')=>{fs.writeFileSync(path.join(dir,'retention-job.json'),JSON.stringify({mode:m,denial,photo}));return worker('tools/bootstrap-retention-closeout-qa.php',[dir]);};
   const denial=mode.startsWith('denial-')?mode.slice(7):'',fault=['copy_short','copy_corrupt','open','flush','sync'].includes(mode);
   const response=invoke(denial?'open':mode,denial),after=snap(data),quarantine=tree(path.join(data,'photo-trash'));
   observations.push({id:mode,before,after,response,quarantine,originalSha256:fs.existsSync(source)?sha(fs.readFileSync(source)):null,originalExpectedSha256:sha(bytes)});
   if(fault){
    const expected=mode.startsWith('copy_')?['copy']:mode==='open'?['copy','open']:mode==='flush'?['copy','open','flush']:['copy','open','flush','sync'];
    check('B17_'+mode+'_exact_boundary',response.trace.map(x=>[x.operation,x.injected]),expected.map(x=>[x,x===(mode.startsWith('copy_')?'copy':mode)]));
    check('B17_'+mode+'_no_false_move',{moved:response.result?.moved,reason:response.result?.skipped.map(x=>x.reason),metadata:same(before,after),original:fs.existsSync(source)?sha(fs.readFileSync(source)):null},{moved:[],reason:[mode.startsWith('copy_')?'quarantine_copy_failed':'exception'],metadata:true,original:sha(bytes)});
    check('B17_'+mode+'_copy_custody',{copies:Object.keys(quarantine).length,copyHash:response.trace[0].copySha256===sha(bytes)},{copies:mode.startsWith('copy_')?1:0,copyHash:!mode.startsWith('copy_')});
    const retry=invoke('normal'),committed=snap(data);observations.push({id:mode+'-retry',response:retry,after:committed,quarantine:tree(path.join(data,'photo-trash'))});
    check('B17_'+mode+'_safe_retry',{moved:retry.result?.moved.length,oldExists:fs.existsSync(source),copy:retry.result?.moved[0]?sha(fs.readFileSync(path.join(data,retry.result.moved[0].quarantinePath))):null,oldMetadata:JSON.parse(committed['rentals.json']).items[0].issueWorkflow.photos.length,neighbor:JSON.parse(committed['rentals.json']).future},{moved:1,oldExists:false,copy:sha(bytes),oldMetadata:0,neighbor:{keep:2}});
    const again=invoke('normal');check('B17_'+mode+'_repeat',{moved:again.result?.moved,stores:same(committed,snap(data))},{moved:[],stores:true});
   }else check('B17_'+mode+'_disabled_normal_path',{trace:response.trace,moved:response.result?.moved.length,oldExists:fs.existsSync(source),copy:response.result?.moved[0]?sha(fs.readFileSync(path.join(data,response.result.moved[0].quarantinePath))):null},{trace:[],moved:1,oldExists:false,copy:sha(bytes)});
  }
  const noGuardDir=path.join(out,'no-guard');fs.mkdirSync(noGuardDir,{recursive:true});
  const noGuard=cp.spawnSync(php,[...args,'-d','auto_prepend_file=','tools/bootstrap-retention-closeout-qa.php',noGuardDir],{cwd:root,env:process.env,encoding:'utf8',windowsHide:true,timeout:10000});
  check('B17_no_prepend_worker_refuses_before_application',{exit:noGuard.status,output:noGuard.stdout,files:fs.readdirSync(noGuardDir)},{exit:2,output:'',files:[]});
  const socket=net.createServer();await new Promise(resolve=>socket.listen(0,'127.0.0.1',resolve));const port=socket.address().port;await new Promise(resolve=>socket.close(resolve));
  const server=cp.spawn(php,[...args,'-S','127.0.0.1:'+port,'-t',root],{cwd:root,env:process.env,windowsHide:true,stdio:['ignore','ignore','ignore']});
  try{
   let ready=false;for(let i=0;i<60&&!ready;i++){ready=await new Promise(resolve=>{const c=net.connect(port,'127.0.0.1');c.once('connect',()=>{c.destroy();resolve(true);});c.once('error',()=>{c.destroy();resolve(false);});});if(!ready)await new Promise(resolve=>setTimeout(resolve,50));}
   if(!ready)throw Error('Owned HTTP handler startup failed');
   const response=await fetch('http://127.0.0.1:'+port+'/tools/bootstrap-retention-closeout-qa.php?mode=open',{method:'POST',body:'mode=open&run='+run,signal:AbortSignal.timeout(10000)});
   check('B17_http_cannot_activate_worker',{body:await response.text(),files:fs.readdirSync(noGuardDir)},{body:'',files:[]});
  }finally{if(server.exitCode===null){const ended=new Promise(resolve=>server.once('exit',resolve));server.kill();await ended;}}
  check('B17_all_cli_participants_cache_free',environments.every(x=>x.opcache==='0'&&x.opcacheCli==='0'&&!x.fileCache&&x.fileCacheOnly==='0'&&x.rebuild.reason==='disabled'),true);
 }catch(e){failure=e.message;rows.push({test:'B17_series_completed',passed:false,actual:e.message,expected:'all declared checks complete'});}
 const result={schemaVersion:1,scope:'B17_TARGETED_NATIVE_HANDLER_WITH_INJECTED_IO_NOT_PHYSICAL_DEVICE_FAILURE',runId:run,status:failure?'FAIL':'PASS',checks:rows.length,passed:rows.filter(x=>x.passed).length,failed:rows.filter(x=>!x.passed).length,results:rows,observations,environments,failure,limits:['Corrupted rejected quarantine copies remain in place under the pre-existing continue branch; no false transfer or original loss.','No physical device/power-loss guarantee.','No full Gate or caller-wide acceptance.']};
 if(options.collect)return result;
 const file='tmp/bootstrap-admin-operations/'+run+'/batch-primary.json';fs.writeFileSync(path.join(root,file),JSON.stringify(result,null,2));console.log(JSON.stringify({status:result.status,report:file}));if(failure)process.exitCode=1;
}
module.exports={main,INPUT_ENTRIES,ARTIFACT_ENTRIES};
