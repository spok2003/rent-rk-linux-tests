<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !defined('RENT_RK_AUDIT_ISOLATION_VERIFIED')) exit(2);
$root=realpath((string)getenv('RENT_RK_AUDIT_LAB_ROOT'));
$dir=realpath((string)($argv[1]??''));
if (!$root || !$dir || !str_starts_with($dir,$root.DIRECTORY_SEPARATOR.'tmp'.DIRECTORY_SEPARATOR.'public-content-extra'.DIRECTORY_SEPARATOR)) exit(2);
$job=json_decode((string)file_get_contents($dir.'/job.json'),true,512,JSON_THROW_ON_ERROR);
putenv('RENT_RK_ALLOW_TEST_DATA_DIR=1');putenv('RENT_RK_TEST_DATA_DIR='.$dir.'/data');
ini_set('session.save_path',$dir.'/sessions');
require $root.'/admin/includes/bootstrap.php';
$result=['environment'=>['php'=>PHP_VERSION,'sapi'=>PHP_SAPI,'opcacheCli'=>ini_get('opcache.enable_cli'),'opcache'=>ini_get('opcache.enable'),'fileCache'=>ini_get('opcache.file_cache'),'allowUrlFopen'=>ini_get('allow_url_fopen'),'isolated'=>defined('RENT_RK_AUDIT_ISOLATION_VERIFIED')]];
if($job['mode']==='direct'){
 class PublicContentFixedIo {
  public $context;
  private $handle;
  private string $key;
  private int $written=0;
  public static array $trace=[];
  public static string $base;
  public static string $scenario;
  private static function file(string $url):string {
   if(!preg_match('~^qaout://fixed/(page\.html|\.page-content-[a-f0-9]{12}\.tmp)$~D',$url,$m))throw new RuntimeException('Fixed QA path refused');
   return self::$base.'/'.$m[1];
  }
  public function stream_open($url,$mode,$options,&$opened):bool {
   $this->key=basename(self::file($url));self::$trace[]=['operation'=>'open','key'=>$this->key,'mode'=>$mode];
   $this->handle=fopen(self::file($url),$mode);return $this->handle!==false;
  }
  public function stream_write($bytes):int {
   $fail=(self::$scenario==='short-temp'&&str_ends_with($this->key,'.tmp'))||(self::$scenario==='partial-copy'&&$this->key==='page.html');
   if($fail){if($this->written>=3)return 0;$bytes=substr($bytes,0,3-$this->written);}
   $n=fwrite($this->handle,$bytes);$this->written+=$n;self::$trace[]=['operation'=>'write','key'=>$this->key,'bytes'=>$n];return $n;
  }
  public function stream_read($n){return fread($this->handle,$n);}
  public function stream_eof(){return feof($this->handle);}
  public function stream_tell(){return ftell($this->handle);}
  public function stream_seek($offset,$whence=SEEK_SET){return fseek($this->handle,$offset,$whence)===0;}
  public function stream_stat(){return fstat($this->handle);}
  public function stream_close(){fclose($this->handle);}
  public function stream_lock($op){return flock($this->handle,$op);}
  public function url_stat($url,$flags){$f=self::file($url);return is_file($f)?stat($f):false;}
  public function rename($from,$to):bool {
   self::$trace[]=['operation'=>'rename','forcedFailure'=>self::$scenario!=='success'];
   return self::$scenario==='success'?rename(self::file($from),self::file($to)):false;
  }
  public function unlink($url):bool{self::$trace[]=['operation'=>'unlink','key'=>basename(self::file($url))];return unlink(self::file($url));}
 }
 PublicContentFixedIo::$base=$dir.'/io';PublicContentFixedIo::$scenario=$job['scenario'];
 stream_wrapper_register('qaout',PublicContentFixedIo::class);
 file_put_contents($dir.'/io/page.html','ORIGINAL-PUBLIC-BYTES');
 try{car_page_content_write_public_output_atomically('qaout://fixed/page.html','REVIEWED-NEW-PUBLIC-CONTENT','cars/synthetic.html');$result['returned']=true;}catch(Throwable $e){$result['error']=['class'=>get_class($e),'message'=>$e->getMessage()];}
 $result['before']='ORIGINAL-PUBLIC-BYTES';$result['after']=file_get_contents($dir.'/io/page.html');$result['files']=array_values(array_diff(scandir($dir.'/io'),['.','..']));$result['trace']=PublicContentFixedIo::$trace;$result['transactionActive']=RentalReturnStore::active();
}else{
 $map=[
 'build'=>['save_build_state',BUILD_STATE_FILE],
 'content'=>['save_car_page_content_store',CAR_PAGE_CONTENT_FILE],
 'page-policy'=>['save_contour_page_content_policy_store',CONTOUR_PAGE_CONTENT_POLICY_FILE],
 'submissions'=>['save_contour_page_content_submissions',CONTOUR_PAGE_CONTENT_SUBMISSIONS_FILE],
 'promos'=>['save_promo_badges_store',PROMO_BADGES_FILE],
 'promo-policy'=>['save_contour_promo_policy_store',CONTOUR_PROMO_POLICY_FILE]];
 [$function,$file]=$map[$job['store']];$fired=[];
 if(isset($job['fault']))$GLOBALS['rental_return_test_io_failure']=static function($stage,$path)use($job,&$fired,$file){if($stage===$job['fault']&&basename($path)===basename($file)&&!$fired){$fired[]=['stage'=>$stage,'file'=>basename($path)];return ['write'=>'WRITE','flush'=>'FFLUSH','fsync'=>'FSYNC','rename'=>'RENAME'][$stage];}return null;};
 $before=file_get_contents($file);
 try{RentalReturnStore::transaction(static function()use($function,$job){$function($job['payload']);});$result['returned']=true;}catch(Throwable $e){$result['error']=['class'=>get_class($e),'message'=>$e->getMessage()];}
 $result['before']=$before;$result['after']=file_get_contents($file);$result['faultReached']=$fired;$result['target']=basename($file);
}
echo json_encode($result,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);

