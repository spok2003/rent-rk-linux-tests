<?php

declare(strict_types=1);

// This adapter is local test infrastructure, never a deployment candidate.
if (PHP_SAPI !== 'cli-server' || !in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)
    || getenv('RENT_RK_ALLOW_TEST_DATA_DIR') !== '1') { http_response_code(404); exit; }
if (function_exists('opcache_reset')) { opcache_reset(); }
$root = dirname(__DIR__);
$data = realpath((string) getenv('RENT_RK_TEST_DATA_DIR'));
$tmp = str_replace('\\', '/', (string) realpath($root . '/tmp')) . '/';
if ($data === false || !str_starts_with(str_replace('\\', '/', $data) . '/', $tmp)) { http_response_code(404); exit; }
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$transportPlanPath = dirname($data) . '/demand-transport-plan.json';
$transportStatePath = dirname($data) . '/demand-transport-state.json';
if (getenv('RENT_RK_QA_DEMAND_TRANSPORT') === '1') {
    $GLOBALS['rent_rk_demand_test_transport'] = static function (string $provider, array $request) use ($transportPlanPath, $transportStatePath, $data): array {
        if (!in_array($provider, ['wordstat', 'deepseek'], true) || !is_file($transportPlanPath)) {
            throw new RuntimeException('Controlled Demand transport has no matching laboratory plan.');
        }
        $plan = json_decode((string) file_get_contents($transportPlanPath), true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($plan) || !is_array($plan['responses'] ?? null)) {
            throw new RuntimeException('Controlled Demand transport plan is invalid.');
        }
        $lock = fopen($transportStatePath . '.lock', 'c+b');
        if (!$lock || !flock($lock, LOCK_EX)) {
            throw new RuntimeException('Controlled Demand transport state is unavailable.');
        }
        try {
            $state = is_file($transportStatePath)
                ? json_decode((string) file_get_contents($transportStatePath), true, 512, JSON_THROW_ON_ERROR)
                : ['nextIndex' => 0, 'observations' => []];
            $index = max(0, (int) ($state['nextIndex'] ?? 0));
            $response = $plan['responses'][$index] ?? null;
            if (!is_array($response) || (string) ($response['provider'] ?? '') !== $provider) {
                throw new RuntimeException('Controlled Demand transport response sequence mismatch.');
            }
            $expectedOperation = (string) ($response['operation'] ?? '');
            if ($expectedOperation !== '' && $expectedOperation !== (string) ($request['operation'] ?? '')) {
                throw new RuntimeException('Controlled Demand transport operation mismatch.');
            }
            $state['nextIndex'] = $index + 1;
            $state['observations'][] = [
                'index' => $index,
                'provider' => $provider,
                'operation' => (string) ($request['operation'] ?? ''),
                'method' => (string) ($request['method'] ?? ''),
                'urlHash' => hash('sha256', (string) ($request['url'] ?? '')),
                'bodyHash' => hash('sha256', (string) ($request['body'] ?? '')),
                'headerNames' => array_values(array_map('strval', (array) ($request['headerNames'] ?? []))),
                'timeoutSeconds' => (int) ($request['timeoutSeconds'] ?? 0),
                'status' => (int) ($response['status'] ?? 0),
                'errno' => (int) ($response['errno'] ?? 0),
            ];
            file_put_contents($transportStatePath, json_encode($state, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT), LOCK_EX);
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
        $pauseId = (string) ($response['pauseId'] ?? '');
        if ($pauseId !== '') {
            if (!preg_match('/^[a-z0-9_-]{8,80}$/D', $pauseId)) throw new RuntimeException('Invalid controlled transport pause id.');
            $held = dirname($data) . '/transport-' . $pauseId . '.held';
            $release = dirname($data) . '/transport-' . $pauseId . '.release';
            file_put_contents($held, 'held');
            $pauseTimeoutSeconds = max(5, min(30, (int) ($response['pauseTimeoutSeconds'] ?? 8)));
            $until = microtime(true) + $pauseTimeoutSeconds;
            while (!is_file($release)) {
                if (microtime(true) >= $until) throw new RuntimeException('Controlled Demand transport pause timed out.');
                usleep(10000);
            }
        }
        return [
            'status' => (int) ($response['status'] ?? 0),
            'body' => array_key_exists('body', $response) ? (string) $response['body'] : false,
            'errno' => (int) ($response['errno'] ?? 0),
            'error' => (string) ($response['error'] ?? ''),
        ];
    };
}
$routes = ['/admin/rental-close.php', '/admin/rentals.php', '/admin/document-print.php', '/admin/finance.php', '/admin/reports.php',
    '/admin/scope-settings.php', '/admin/my-scope.php', '/admin/document-template-download.php',
    '/admin/analytics/cars.php', '/admin/api/rental-media.php', '/admin/api/car-picker.php', '/admin/api/customer-search.php',
    '/admin/cars.php', '/admin/customers.php', '/admin/calendar.php', '/admin/rental-issue.php', '/admin/service-holds.php',
    '/admin/partner-payout-apply.php', '/admin/partner-payout-receipt.php', '/admin/index.php', '/admin/logout.php', '/admin/database.php',
    '/admin/requests.php', '/admin/rental-replace.php', '/admin/partners.php', '/admin/fines.php', '/admin/archive-rental.php', '/admin/rental-fact-recovery.php',
    '/admin/cars/page-content.php', '/admin/page-content-review.php', '/admin/promo-badges.php', '/admin/car-edit.php',
    '/admin/car-card-review.php', '/admin/cars/page-content-diff.php', '/admin/demand.php',
    '/api/request.php', '/api/callback.php', '/landing.php'];
if (str_starts_with((string) $path, '/admin/assets/') || str_starts_with((string) $path, '/assets/')) {
    $file = realpath($root . $path);
    if ($file !== false && str_starts_with(str_replace('\\', '/', $file), str_replace('\\', '/', realpath($root)) . '/')
        && in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), ['css', 'js', 'svg', 'png', 'webp', 'jpg', 'woff', 'woff2'], true)) { return false; }
    http_response_code(404); exit;
}
if (!in_array($path, ['/_qa/session', '/_qa/demand-session-state', '/_qa/demand-ai-content-seed', '/_qa/demand-publication-command-fields', '/_qa/demand-transport-state', '/_qa/runtime', '/_qa/wordstat-cost-totals'], true)
    && !in_array($path, $routes, true)) { http_response_code(404); exit; }
$barrier = (string) ($_SERVER['HTTP_X_QA_BARRIER'] ?? '');
$barrierDirectory = dirname($data) . '/barriers';
if ($barrier !== '' && preg_match('/^[a-z0-9_-]{16,80}$/', $barrier) && is_dir($barrierDirectory)) {
    file_put_contents($barrierDirectory . '/' . $barrier . '.' . $_SERVER['SERVER_PORT'] . '.arrived', 'arrived');
} else {
    $barrier = '';
}
define('AUTO_REBUILD_SITE_AFTER_ADMIN_CHANGES', false);
define('ADMIN_USER', 'rr-admin');
set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
    if (!(error_reporting() & $severity)) { return false; }
    throw new ErrorException($message, 500, $severity, $file, $line);
}, E_WARNING | E_NOTICE | E_USER_WARNING | E_USER_NOTICE);
if (str_starts_with((string) getenv('RENT_RK_QA_PAUSE_POINT'), 'recovery.')) {
    $pause = (string) getenv('RENT_RK_QA_PAUSE_POINT');
    $GLOBALS['rental_return_test_hook'] = static function (string $point) use ($pause, $data): void {
        if ($point !== $pause) { return; }
        file_put_contents(dirname($data) . '/.checkpoint', $point);
        $release = dirname($data) . '/.checkpoint-release';
        while (!is_file($release) || file_get_contents($release) !== $pause) { usleep(10000); }
    };
}
require_once $root . '/admin/includes/bootstrap.php';
if (realpath(DATA_DIR) !== $data) { throw new RuntimeException('Invalid QA data root.'); }
if (getenv('RENT_RK_QA_ATTEST') === '1') {
    require_once __DIR__ . '/rental-return-v2-attest.php';
    rental_return_qa_attest(dirname($data));
    register_shutdown_function(static fn() => rental_return_qa_attest(dirname($data)));
}
register_shutdown_function(static function () use ($data): void {
    if (!empty($GLOBALS['rental_return_io_failures'])) {
        file_put_contents(dirname($data) . '/io-failure-' . bin2hex(random_bytes(6)) . '.json',
            json_encode(['events' => $GLOBALS['rental_return_io_failures']], JSON_THROW_ON_ERROR));
    }
});
if ($path === '/_qa/runtime') {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') { http_response_code(405); exit; }
    $sourceFiles = [
        'admin/demand.php',
        'admin/includes/bootstrap.php',
        'admin/includes/demand.php',
        'admin/includes/analytics.php',
        'admin/includes/demand-launch-map.php',
        'admin/includes/demand-integrations.php',
        'admin/includes/demand-ai.php',
        'admin/includes/demand-ai-api.php',
        'admin/includes/demand-ai-dialog.php',
        'admin/includes/wordstat-client.php',
        'admin/includes/ai-openai-client.php',
        'tools/business-data-demand-ai-content-qa.cjs',
        'tools/rental-return-v2-qa-router.php',
    ];
    $sources = [];
    foreach ($sourceFiles as $relative) {
        $file = realpath($root . '/' . $relative);
        $sources[$relative] = $file === false ? null : [
            'realpath' => $file,
            'sha256' => hash_file('sha256', $file),
        ];
    }
    header('Content-Type: application/json');
    echo json_encode([
        'role' => (string) getenv('RENT_RK_QA_PROCESS_ROLE'),
        'pid' => getmypid(),
        'phpBinary' => PHP_BINARY,
        'phpVersion' => PHP_VERSION,
        'sapi' => PHP_SAPI,
        'opcache' => [
            'enable' => (string) ini_get('opcache.enable'),
            'enableCli' => (string) ini_get('opcache.enable_cli'),
            'fileCache' => (string) ini_get('opcache.file_cache'),
            'fileCacheOnly' => (string) ini_get('opcache.file_cache_only'),
        ],
        'transport' => [
            'curlExec' => function_exists('curl_exec'),
            'fsockopen' => function_exists('fsockopen'),
            'streamSocketClient' => function_exists('stream_socket_client'),
            'allowUrlFopen' => (string) ini_get('allow_url_fopen'),
            'controlledDemandHook' => is_callable($GLOBALS['rent_rk_demand_test_transport'] ?? null),
        ],
        'dataRoot' => realpath(DATA_DIR),
        'sources' => $sources,
    ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
    exit;
}
if ($path === '/_qa/demand-transport-state') {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET' || !str_starts_with((string) ($_SESSION['admin_user'] ?? ''), 'rr-')) {
        http_response_code(403);
        exit;
    }
    header('Content-Type: application/json');
    echo is_file($transportStatePath) ? (string) file_get_contents($transportStatePath) : '{"nextIndex":0,"observations":[]}';
    exit;
}
if ($path === '/_qa/wordstat-cost-totals') {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') { http_response_code(405); exit; }
    header('Content-Type: application/json');
    echo json_encode(wordstat_cost_totals(), JSON_THROW_ON_ERROR);
    exit;
}
if ($path === '/_qa/session') {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') { http_response_code(405); exit; }
    $_SESSION = [];
    $actor = is_string($_GET['actor'] ?? null) ? $_GET['actor'] : '';
    $user = $actor !== '' ? find_admin_user($actor) : null;
    if ($user && str_starts_with($actor, 'rr-')) {
        $_SESSION['admin_user'] = $actor;
        $_SESSION['admin_role'] = $user['role'];
        $_SESSION['admin_name'] = $user['name'];
        $_SESSION['demand_qa_unrelated_sentinel'] = 'preserve-session-state';
    }
    header('Content-Type: application/json');
    echo json_encode(['syntheticSession' => $user !== null, 'csrfToken' => csrf_token()]);
    exit;
}
if ($path === '/_qa/demand-ai-content-seed') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !str_starts_with((string) ($_SESSION['admin_user'] ?? ''), 'rr-')) {
        http_response_code(403);
        exit;
    }
    $preset = is_string($_POST['preset'] ?? null) ? (string) $_POST['preset'] : 'draft';
    $draftId = $preset === 'external' ? 'd-external' : 'd-main';
    $draft = demand_ai_find_entity('draft', $draftId);
    $hint = demand_ai_find_entity('car_hint', 'hint-main');
    if (!$draft || !$hint) {
        http_response_code(409);
        exit;
    }
    $draftVersion = demand_ai_entity_version('draft', $draftId);
    $hintVersion = demand_ai_entity_version('car_hint', 'hint-main');
    $manualToken = 'qa-manual-preview-token';
    $apiToken = 'qa-api-preview-token';
    $copyToken = 'qa-copy-preview-token';
    $hintToken = 'qa-hint-preview-token';
    $proposal = ['title' => 'QA authorized proposal', 'intro' => 'QA authorized intro'];
    $hintProposal = ['message' => 'QA hint message', 'suggestedText' => 'QA hint text', 'descriptionSuggestion' => 'QA hint description'];
    $_SESSION['demand_ai_latest_preview'] = [
        'token' => $manualToken,
        'entityType' => 'draft',
        'entityId' => $draftId,
        'task' => 'improve_landing_draft',
        'proposal' => $proposal,
        'ignoredFields' => [],
        'diff' => ['applySupported' => true, 'rows' => []],
        'entityVersion' => $draftVersion,
        'createdAt' => now_iso(),
    ];
    $_SESSION['demand_ai_api_latest'] = $preset === 'hint' ? [
        'token' => $hintToken,
        'contextTab' => 'car_hints',
        'entityType' => 'car_hint',
        'entityId' => 'hint-main',
        'task' => 'generate_car_hint_text',
        'run' => ['id' => 'qa-hint-run', 'status' => 'success'],
        'response' => ['summary' => 'QA synthetic response'],
        'proposal' => $hintProposal,
        'diff' => ['applySupported' => true, 'rows' => []],
        'entityVersion' => $hintVersion,
        'createdAt' => now_iso(),
    ] : [
        'token' => $apiToken,
        'contextTab' => 'drafts',
        'entityType' => 'draft',
        'entityId' => $draftId,
        'task' => 'improve_landing_draft',
        'run' => ['id' => 'qa-api-run', 'status' => 'success'],
        'response' => ['summary' => 'QA synthetic response'],
        'proposal' => $proposal,
        'diff' => ['applySupported' => true, 'rows' => []],
        'entityVersion' => $draftVersion,
        'createdAt' => now_iso(),
    ];
    $_SESSION['demand_ai_copy_latest'] = [
        'token' => $copyToken,
        'entityType' => 'draft',
        'entityId' => $draftId,
        'task' => 'regenerate_landing_draft_human',
        'source' => 'local_safe_fallback',
        'run' => ['id' => 'qa-copy-run', 'status' => 'local_preview'],
        'response' => ['summary' => 'QA synthetic response', 'styleUsed' => 'calm_human'],
        'proposal' => $proposal,
        'diff' => ['applySupported' => true, 'rows' => []],
        'request' => ['draftId' => $draftId, 'task' => 'regenerate_landing_draft_human', 'options' => [], 'proposalHash' => demand_ai_hash($proposal)],
        'entityVersion' => $draftVersion,
        'createdAt' => now_iso(),
    ];
    $_SESSION['demand_car_hint_ai_fallback'] = null;
    $_SESSION['demand_ai_dialog'] = [
        'messages' => [],
        'workflow' => [
            'id' => 'qa-auth-workflow',
            'status' => 'running',
            'scope_id' => 'rent_rk',
            'entityType' => '',
            'entityId' => '',
            'safeToRunNow' => [[
                'id' => 'qa-read-action',
                'action' => 'analyze_current_tab',
                'label' => 'QA read action',
                'kind' => 'read',
                'status' => 'pending',
                'riskLevel' => 'auto_safe',
                'requiresConfirmation' => false,
                'requiresExplicitConfirmation' => false,
                'permission' => 'demand.ai_workflow.run',
            ]],
            'requiresConfirmation' => [],
            'specialConfirmation' => [],
        ],
        'lastResult' => null,
    ];
    header('Content-Type: application/json');
    echo json_encode([
        'csrfToken' => csrf_token(),
        'draftVersion' => $draftVersion,
        'hintVersion' => $hintVersion,
        'manualToken' => $manualToken,
        'apiToken' => $apiToken,
        'copyToken' => $copyToken,
        'hintToken' => $hintToken,
        'workflowId' => 'qa-auth-workflow',
        'workflowActionId' => 'qa-read-action',
    ]);
    exit;
}
if ($path === '/_qa/demand-session-state') {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET' || !str_starts_with((string) ($_SESSION['admin_user'] ?? ''), 'rr-')) {
        http_response_code(403);
        exit;
    }
    $previews = [];
    foreach ((array) ($_SESSION['demand_import_previews'] ?? []) as $token => $entry) {
        if (!is_string($token) || !is_array($entry)) continue;
        $rows = [];
        foreach ((array) ($entry['preview']['rows'] ?? []) as $row) {
            if (!is_array($row)) continue;
            $keyword = is_array($row['keyword'] ?? null) ? $row['keyword'] : [];
            $rows[] = [
                'action' => (string) ($row['action'] ?? ''),
                'scope_id' => (string) ($keyword['scope_id'] ?? ''),
                'phrase' => (string) ($keyword['phrase'] ?? ''),
                'frequency' => (int) ($keyword['frequency'] ?? 0),
            ];
        }
        $previews[] = ['tokenHash' => hash('sha256', $token), 'rows' => $rows];
    }
    $links = is_array($_SESSION['demand_internal_links_latest'] ?? null) ? $_SESSION['demand_internal_links_latest'] : [];
    $receipts = [];
    foreach ((array) ($_SESSION['demand_editorial_receipts'] ?? []) as $key => $receipt) {
        if (!is_string($key) || !is_array($receipt)) continue;
        $receipts[] = [
            'key' => $key,
            'fingerprint' => (string) ($receipt['fingerprint'] ?? ''),
            'resultHash' => hash('sha256', json_encode($receipt['result'] ?? [], JSON_THROW_ON_ERROR)),
        ];
    }
    $integrationReceipts = [];
    foreach ((array) ($_SESSION['demand_integration_receipts'] ?? []) as $key => $receipt) {
        if (!is_string($key) || !is_array($receipt)) continue;
        $integrationReceipts[] = [
            'key' => $key,
            'fingerprint' => (string) ($receipt['fingerprint'] ?? ''),
            'resultHash' => hash('sha256', json_encode($receipt['result'] ?? [], JSON_THROW_ON_ERROR)),
        ];
    }
    $safeAiState = static function ($value, string $kind): ?array {
        if (!is_array($value) || $value === []) return null;
        $safe = [
            'kind' => $kind,
            'tokenHash' => hash('sha256', (string) ($value['token'] ?? '')),
            'entityType' => (string) ($value['entityType'] ?? ''),
            'entityId' => (string) ($value['entityId'] ?? ''),
            'task' => (string) ($value['task'] ?? ''),
            'entityVersion' => (string) ($value['entityVersion'] ?? ''),
            'proposalHash' => hash('sha256', json_encode($value['proposal'] ?? [], JSON_THROW_ON_ERROR)),
            'diffHash' => hash('sha256', json_encode($value['diff'] ?? [], JSON_THROW_ON_ERROR)),
            'createdAt' => (string) ($value['createdAt'] ?? ''),
        ];
        if (is_array($value['run'] ?? null)) {
            $safe['run'] = [
                'id' => (string) ($value['run']['id'] ?? ''),
                'status' => (string) ($value['run']['status'] ?? ''),
            ];
        }
        if (is_array($value['ignoredFields'] ?? null)) {
            $safe['ignoredFields'] = array_values(array_map('strval', $value['ignoredFields']));
        }
        if (is_array($value['request'] ?? null)) {
            $safe['requestHash'] = hash('sha256', json_encode($value['request'], JSON_THROW_ON_ERROR));
        }
        return $safe;
    };
    $package = is_array($_SESSION['demand_ai_latest_package'] ?? null) ? $_SESSION['demand_ai_latest_package'] : [];
    $dialog = is_array($_SESSION['demand_ai_dialog'] ?? null) ? $_SESSION['demand_ai_dialog'] : [];
    $workflow = is_array($dialog['workflow'] ?? null) ? $dialog['workflow'] : [];
    $dialogActions = [];
    foreach (['safeToRunNow', 'requiresConfirmation', 'specialConfirmation'] as $bucket) {
        foreach ((array) ($workflow[$bucket] ?? []) as $action) {
            if (!is_array($action)) continue;
            $dialogActions[] = [
                'bucket' => $bucket,
                'id' => (string) ($action['id'] ?? ''),
                'action' => (string) ($action['action'] ?? ''),
                'status' => (string) ($action['status'] ?? ''),
            ];
        }
    }
    $aiReceipts = [];
    foreach ((array) ($_SESSION['demand_ai_content_receipts'] ?? []) as $key => $receipt) {
        if (!is_string($key) || !is_array($receipt)) continue;
        $aiReceipts[] = [
            'key' => $key,
            'fingerprint' => (string) ($receipt['fingerprint'] ?? ''),
            'resultHash' => hash('sha256', json_encode($receipt['result'] ?? [], JSON_THROW_ON_ERROR)),
        ];
    }
    header('Content-Type: application/json');
    echo json_encode([
        'importPreviews' => $previews,
        'internalLinks' => $links ? [
            'tokenHash' => hash('sha256', (string) ($links['token'] ?? '')),
            'draftId' => (string) ($links['draftId'] ?? ''),
            'suggestionHash' => hash('sha256', json_encode($links['suggestions'] ?? [], JSON_THROW_ON_ERROR)),
            'suggestions' => array_values(array_map(static fn(array $item): array => [
                'url' => (string) ($item['url'] ?? $item['targetUrl'] ?? ''),
                'status' => (string) ($item['status'] ?? ''),
                'safeToApply' => !empty($item['safeToApply']),
            ], array_values(array_filter(
                (array) (($links['suggestions']['internalLinkSuggestions'] ?? null) ?: []),
                'is_array'
            )))),
        ] : null,
        'directionDecisions' => (array) ($_SESSION['demand_direction_decisions'] ?? []),
        'receipts' => $receipts,
        'integrationReceipts' => $integrationReceipts,
        'aiContentReceipts' => $aiReceipts,
        'aiPackage' => $package ? [
            'entityType' => (string) ($package['entityType'] ?? ''),
            'entityId' => (string) ($package['entityId'] ?? ''),
            'task' => (string) ($package['task'] ?? ''),
            'entityVersion' => (string) ($package['entityVersion'] ?? ''),
            'packageHash' => hash('sha256', json_encode($package['package'] ?? [], JSON_THROW_ON_ERROR)),
            'textHash' => hash('sha256', (string) ($package['text'] ?? '')),
            'createdAt' => (string) ($package['createdAt'] ?? ''),
        ] : null,
        'aiPreview' => $safeAiState($_SESSION['demand_ai_latest_preview'] ?? null, 'manual-preview'),
        'aiApi' => $safeAiState($_SESSION['demand_ai_api_latest'] ?? null, 'api-preview'),
        'aiCopy' => $safeAiState($_SESSION['demand_ai_copy_latest'] ?? null, 'copy-preview'),
        'aiFallback' => $safeAiState($_SESSION['demand_car_hint_ai_fallback'] ?? null, 'car-hint-fallback'),
        'aiDialog' => $workflow ? [
            'id' => (string) ($workflow['id'] ?? ''),
            'status' => (string) ($workflow['status'] ?? ''),
            'scopeId' => (string) ($workflow['scope_id'] ?? ''),
            'entityType' => (string) ($workflow['entityType'] ?? ''),
            'entityId' => (string) ($workflow['entityId'] ?? ''),
            'entityVersion' => (string) ($workflow['entityVersion'] ?? ''),
            'actions' => $dialogActions,
            'messagesCount' => count((array) ($dialog['messages'] ?? [])),
            'lastResultHash' => hash('sha256', json_encode($dialog['lastResult'] ?? [], JSON_THROW_ON_ERROR)),
        ] : null,
        'simpleAiWorkspaceHash' => hash('sha256', json_encode($_SESSION['demand_simple_ai_workspace'] ?? [], JSON_THROW_ON_ERROR)),
        'unrelatedSentinel' => (string) ($_SESSION['demand_qa_unrelated_sentinel'] ?? ''),
    ], JSON_THROW_ON_ERROR);
    exit;
}
if ($path === '/_qa/demand-publication-command-fields') {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET' || !str_starts_with((string) ($_SESSION['admin_user'] ?? ''), 'rr-')) {
        http_response_code(403);
        exit;
    }
    $action = is_string($_GET['action'] ?? null) ? $_GET['action'] : '';
    if (!in_array($action, demand_publication_actions(), true)) {
        http_response_code(400);
        exit;
    }
    header('Content-Type: application/json');
    echo json_encode(['html' => demand_publication_command_fields($action)], JSON_THROW_ON_ERROR);
    exit;
}
$_SERVER['SCRIPT_NAME'] = $path;
if (getenv('RENT_RK_QA_IO_PLAN') === '1' && $_SERVER['REQUEST_METHOD'] === 'POST' && is_file(dirname($data) . '/io-plan.json')) {
    $plan = json_decode(file_get_contents(dirname($data) . '/io-plan.json'), true, 512, JSON_THROW_ON_ERROR);
    $matches = 0;
    $GLOBALS['rental_return_test_io_failure'] = static function (string $stage, string $name) use ($plan, &$matches): ?string {
        $target = $plan['file'] === '@media' ? preg_match('/^media_[a-f0-9]+\.(png|webp|jpe?g)$/D', $name) === 1 : $name === $plan['file'];
        if ($stage !== $plan['stage'] || !$target) { return null; }
        $matches++;
        return $matches === $plan['occurrence'] ? $plan['fault'] : null;
    };
}
if ($barrier !== '' && ($_SERVER['HTTP_X_QA_PAUSE'] ?? '') === '1') {
    $requestedPoint = (string) ($_SERVER['HTTP_X_QA_POINT'] ?? '');
    $barrierPoint = in_array($requestedPoint, ['legacy.after_read', 'service.after_version', 'transaction.after_lock', 'fact_recovery.before_commit'], true) ? $requestedPoint : 'service.after_version';
    $GLOBALS['rental_return_test_hook'] = static function (string $point) use ($barrier, $barrierDirectory, $barrierPoint): void {
        if ($point !== $barrierPoint) { return; }
        file_put_contents($barrierDirectory . '/' . $barrier . '.held', 'held');
        $until = microtime(true) + 8;
        while (!is_file($barrierDirectory . '/' . $barrier . '.release')) {
            if (microtime(true) > $until) { throw new RuntimeException('QA barrier timeout.', 503); }
            usleep(1000);
        }
    };
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && getenv('RENT_RK_QA_PAUSE_POINT')
    && !str_starts_with((string) getenv('RENT_RK_QA_PAUSE_POINT'), 'recovery.')) {
    $pause = (string) getenv('RENT_RK_QA_PAUSE_POINT');
    $GLOBALS['rental_return_test_hook'] = static function (string $point) use ($pause, $data): void {
        if ($point !== $pause && !(str_ends_with($pause, '*') && str_starts_with($point, substr($pause, 0, -1)))) { return; }
        $store = (string) getenv('RENT_RK_QA_PAUSE_FILE');
        if ($point === 'journal.committed' && $store !== '') {
            if (!preg_match('/^[a-z0-9-]+\.json$/D', $store)) throw new RuntimeException('Invalid isolated pause store.');
            $journal = json_decode((string) file_get_contents($data . '/.rental-transactions/journal.json'), true, 512, JSON_THROW_ON_ERROR);
            if (!isset($journal['files'][$store])) return;
        }
        file_put_contents(dirname($data) . '/.checkpoint', $point);
        $release = dirname($data) . '/.checkpoint-release';
        while (!is_file($release) || file_get_contents($release) !== $pause) { usleep(10000); }
    };
}
try {
    require $root . $path;
} catch (Throwable $exception) {
    $classify = (string) ($_SERVER['HTTP_X_QA_CLASSIFY_THROWABLE'] ?? '') === '1';
    $syntheticActor = str_starts_with((string) ($_SESSION['admin_user'] ?? ''), 'rr-');
    if ($classify && $syntheticActor) {
        $category = str_contains($exception->getMessage(), 'Хранилище занято') ? 'store_busy' : 'other';
        http_response_code($category === 'store_busy' ? 503 : 500);
        header('Content-Type: application/json');
        echo json_encode(['qaThrowableCategory' => $category], JSON_THROW_ON_ERROR);
        exit;
    }
    throw $exception;
}
