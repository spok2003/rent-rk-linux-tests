'use strict';
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const crypto = require('crypto');
const a = require('./business-data-audit.cjs');
const {validateExactSourceBindings} = require('./business-data-writer-review.cjs');
// Every entry is reviewed for local setup. A passing component does not certify untested routes.
const suites = [
  ['qa-infrastructure', 'business-data-qa-infrastructure-qa.cjs'],
  ['isolation', 'business-data-audit-isolation-qa.php'],
  ['child-isolation', 'business-data-child-isolation-qa.cjs'],
  ['lifecycle', 'business-data-lifecycle-qa.php'],
  ['priority-writers', 'business-data-priority-writers-qa.php'],
  ['completion', 'business-data-completion-qa.php'],
  ['command', 'business-data-command-qa.php'],
  ['user-commands', 'business-data-user-commands-qa.php'],
  ['auth-command', 'business-data-auth-qa.php'],
  ['operator-command', 'business-data-operator-qa.php'],
  ['alerts-command', 'business-data-alerts-qa.php'],
  ['payment-storage', 'business-data-payment-storage-qa.php'],
  ['fine-settings', 'business-data-fine-settings-qa.php'],
  ['config-command', 'business-data-config-qa.php'],
  ['template-http', 'business-data-template-http-qa.cjs'],
  ['ordinary', 'business-data-ordinary-qa.php'],
  ['fleet-commands', 'business-data-fleet-command-qa.php'],
  ['calendar-command', 'business-data-calendar-qa.php'],
  ['interleavings', 'business-data-interleavings-qa.cjs'],
  ['import-command', 'business-data-import-command-qa.cjs'],
  ['scoped-import', 'business-data-scoped-import-qa.php'],
  ['scoped-http', 'business-data-scoped-http-qa.cjs'],
  ['backup-bundle', 'business-data-backup-bundle-qa.cjs'],
  ['media-boundary', 'business-data-media-boundary-qa.cjs'],
  ['media-retention', 'business-data-retention-qa.php'],
  ['public-boundary', 'business-data-public-boundary-qa.cjs'],
  ['public-command', 'business-data-public-command-qa.cjs'],
  ['public-rate-limit', 'business-data-public-rate-limit-qa.cjs'],
  ['request-browser', 'business-data-request-browser-qa.cjs'],
  ['fact-recovery', 'rental-fact-recovery-qa.php'],
  ['clients', 'clients-remediation-qa.php'],
  ['client-balance', 'rental-create-v2-client-balance-qa.php'],
  ['users-access', 'users-access-v2-integration-qa.php'],
  ['rental-create', 'rental-create-v2-local-integration-qa.php'],
  ['booking-buffer', 'booking-buffer-per-scope-qa.php'],
  ['analytics', 'business-analytics-calculation-tests.php'],
  ['car-analytics', 'car-analytics-calculation-tests.php'],
  ['partner-deal', 'partner-commission-per-deal-qa.php'],
  ['return-service', 'rental-return-v2-service-qa.php'],
  ['legacy-finance', 'business-data-legacy-finance-qa.cjs'],
  ['legacy-partner-paid', 'business-data-legacy-partner-mark-paid-qa.cjs'],
  ['boundaries', 'business-data-boundaries-qa.cjs'],
  ['authorized-correction', 'business-data-correction-qa.cjs'],
  ['return-finance', 'rental-return-v2-finance-qa.cjs'],
  ['return-auth', 'rental-return-v2-auth-qa.cjs'],
  ['return-deposit', 'rental-return-v2-deposit-qa.cjs'],
  ['return-workflow', 'rental-return-v2-workflow-qa.cjs'],
  ['return-writer-compat', 'rental-return-v2-writer-compat-qa.cjs'],
  ['return-storage', 'rental-return-v2-storage-qa.cjs'],
  ['return-io', 'rental-return-v2-io-qa.cjs'],
  ['return-io-matrix', 'rental-return-v2-io-matrix-qa.cjs'],
  ['partial-backup', 'rental-return-v2-partial-backup-qa.cjs'],
  ['return-payout', 'rental-return-v2-payout-qa.cjs'],
  ['return-parity', 'rental-return-v2-parity-qa.cjs'],
  ['return-media', 'rental-return-v2-media-qa.cjs'],
  ['return-http-faults', 'rental-return-v2-http-qa.cjs', '--faults'],
  ['recovery-browser', 'rental-fact-recovery-browser-qa.cjs'],
  ['analytics-browser', 'business-analytics-browser-qa.cjs'],
  ['site-maintenance', 'site-maintenance-smoke.php'],
  ['site-maintenance-http', 'site-maintenance-browser-qa.cjs'],
  ['site-maintenance-drain', 'site-maintenance-writer-drain-qa.cjs'],
  ['prototype-guards', 'business-data-prototype-guards-qa.php'],
  ['demand-editorial', 'business-data-demand-editorial-qa.cjs'],
  ['demand-publication', 'business-data-demand-publication-qa.cjs'],
  ['demand-integrations', 'business-data-demand-integrations-qa.cjs'],
  ['demand-integrations-ai-wait', 'business-data-demand-integrations-qa.cjs', '--ai-wait-only'],
  ['demand-ai-content', 'business-data-demand-ai-content-qa.cjs'],
  ['publication-commands', 'business-data-publication-command-qa.cjs'],
  ['shared-writers-owner-aba', 'shared-writers-owner-aba-qa.cjs'],
  ['shared-writers-seven-gaps', 'shared-writers-seven-gaps-evidence-qa.cjs'],
  ['shared-writers-exact-sinks', 'shared-writers-exact-sink-contracts-qa.cjs'],
  ['bootstrap-json-write', 'bootstrap-json-write-qa.cjs'],
  ['shared-customers-requests', 'shared-customers-requests-writer-qa.cjs'],
  ['writer-review', 'business-data-writer-review-qa.cjs'],
  ['acceptance-hardening', 'business-data-acceptance-hardening-qa.cjs'],
  ['audit-archive-prototype', 'business-data-audit-archive-prototype-qa.cjs'],
];
function componentFailed(result) {
  return result.exitCode !== 0 || /FAIL|BLOCKED/i.test(result.reportedStatus || '') || result.passed === false
    || !!result.failure || result.failureCount > 0 || result.checks?.some(check => check.passed === false);
}
function execute(state, selected = suites) {
  const results = [];
  let failedComponentId = null;
  const seriesBinding = crypto.randomBytes(16).toString('hex');
  const laboratoryInputs = a.validateLaboratoryInputs(state);
  const exactSourceBindings = validateExactSourceBindings(state.lab);
  if (laboratoryInputs.status !== 'PASS_LABORATORY_INPUTS' || exactSourceBindings.status !== 'PASS_EXACT_SOURCE_BINDINGS') {
    const preservation = a.verify(state);
    const report = {schema: 1, createdAt: new Date().toISOString(), sourceSha256: state.baseline.sourceSha256,
      laboratoryId: state.baseline.laboratoryId, seriesBinding,
      applicableSuites: selected.map(s => s[0]), results, preservation, laboratoryInputs, exactSourceBindings,
      termination: {mode: 'PRE_COMPONENT_INPUT_CONTRACT_FAIL_FAST', stopped: true,
        failedComponentId: null, failedComponentIndex: null, completedComponentIds: [],
        notStartedComponentIds: selected.map(suite => suite[0]), childExecution: 'no-business-components-started'},
      status: 'FAIL', globalReleaseStatus: 'BLOCKED',
      reason: 'Mandatory laboratory inputs or exact-source review bindings are stale, missing or unverifiable.'};
    a.save(path.join(state.dir, 'component-gate-' + Date.now() + '.json'), report);
    console.log(JSON.stringify({preflight: laboratoryInputs.status, inputViolations: laboratoryInputs.violations,
      exactSourceBindings: exactSourceBindings.status, bindingFailures: exactSourceBindings.failures, componentsStarted: 0}));
    return report;
  }
  for (const [id, file, ...args] of selected) {
    const result = a.run(state, 'tools/' + file, args, false, {componentId: id, seriesBinding});
    results.push({id, ...result});
    console.log(JSON.stringify({component: id, exitCode: result.exitCode, status: result.reportedStatus, checkCount: result.checkCount, failure: result.failure}));
    if (componentFailed(result)) {
      failedComponentId = id;
      break;
    }
  }
  const preservation = a.verify(state);
  const completedIds = results.map(result => result.id);
  const notStartedIds = selected.map(suite => suite[0]).slice(results.length);
  const preservationFailed = !preservation.canonicalUnchanged || !preservation.laboratorySourceUnchanged
    || preservation.canonicalArtifactsUnchanged === false;
  const failed = failedComponentId !== null || preservationFailed;
  const report = {schema: 1, createdAt: new Date().toISOString(), sourceSha256: state.baseline.sourceSha256,
    laboratoryId: state.baseline.laboratoryId, seriesBinding,
    applicableSuites: selected.map(s => s[0]), results, preservation, laboratoryInputs, exactSourceBindings,
    termination: {
      mode: 'FAIL_FAST', stopped: failedComponentId !== null, failedComponentId,
      failedComponentIndex: failedComponentId === null ? null : results.length - 1,
      completedComponentIds: completedIds, notStartedComponentIds: notStartedIds,
      childExecution: 'synchronous-per-component-no-overlap'
    },
    status: failed ? 'FAIL' : 'PASS_COMPONENTS_ONLY',
    globalReleaseStatus: 'BLOCKED', reason: 'Complete route-to-invariant coverage must be independently reviewed; components are not a global certificate.'};
  a.save(path.join(state.dir, 'component-gate-' + Date.now() + '.json'), report);
  return report;
}
module.exports = {suites, componentFailed, execute};
if (require.main === module) {
  const dir = process.argv[2];
  const state = dir ? a.load(dir) : a.create('critical-gate');
  console.log(JSON.stringify({laboratory: state.dir, sourceSha256: state.baseline.sourceSha256}));
  const ids = process.argv.slice(3);
  if (ids.some(id => !suites.some(s => s[0] === id))) throw Error('Unknown suite');
  const report = execute(state, ids.length ? suites.filter(s => ids.includes(s[0])) : suites);
  console.log(JSON.stringify({status: report.status, globalReleaseStatus: report.globalReleaseStatus, components: report.results.length}));
  process.exitCode = report.status === 'FAIL' ? 1 : 0;
}
