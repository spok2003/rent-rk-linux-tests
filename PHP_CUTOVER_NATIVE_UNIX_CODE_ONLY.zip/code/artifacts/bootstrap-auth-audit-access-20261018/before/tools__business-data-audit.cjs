'use strict';
// Code-only laboratories. Never copy a working database or local access configuration.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cp = require('child_process');
const root = path.resolve(__dirname, '..');
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const slash = value => value.replace(/\\/g, '/');
const sourceRoots = ['admin', 'api', 'assets', 'src', 'routes', 'tools', 'partner', 'cgi-bin', 'pages', 'cars'];
const rootRuntimeFiles = ['maintenance-rr-20260912.html'];
const laboratoryArtifactFiles = [{
  path: 'index.html',
  artifactClass: 'generated-public-release-artifact',
  purpose: 'Deterministic public projection required by publication command QA.'
}, {
  path: 'sitemap.xml',
  artifactClass: 'generated-public-release-artifact',
  purpose: 'Deterministic public projection required by publication command QA.'
}];
const technicalMetadataFiles = [
  'artifacts/test-lifecycle/TEST_REGISTRY.json',
  'artifacts/test-lifecycle/CURRENT_SUMMARY.json',
  'private/rent-rk-data/project-progress-map.json',
  'docs/PROJECT_STATE.md',
  'docs/OPERATION_METHODS_LOG.md',
  'artifacts/retention-ledger/INDEX.json',
  'artifacts/retention-ledger/CURRENT_SUMMARY.json',
  'artifacts/retention-registry-20260929/RETENTION_REGISTRY_DRAFT.json'
];
const environmentDependencies = [
  {id: 'node', kind: 'executable', command: process.execPath},
  {id: 'php', kind: 'executable', command: process.env.RENT_RK_QA_PHP || process.env.PHP_BINARY || 'php'},
  {id: 'jszip', kind: 'node-module', path: 'C:/Users/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/jszip'},
  {id: 'playwright', kind: 'node-module', path: 'C:/Users/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'}
];
const sourceExtensions = ['php', 'cjs', 'mjs', 'js', 'css', 'html', 'json', 'svg', 'tpl'];
const excluded = /(^|\/)(config\.local\.php|\.env[^/]*|\.ftp[^/]*|authorized_key\.json|secrets?|credentials?)(\/|$)/i;
function walk(dir, prefix = '') {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, {withFileTypes: true}).flatMap(entry => {
    const rel = prefix + entry.name, full = path.join(dir, entry.name);
    if (excluded.test(rel)) return [];
    if (fs.lstatSync(full).isSymbolicLink()) throw Error('Symlink rejected: ' + rel);
    return entry.isDirectory() ? walk(full, rel + '/') : [rel];
  });
}
function qaSources() {
  const files = [...sourceRoots.flatMap(dir => walk(path.join(root, dir), dir + '/')),
    ...fs.readdirSync(root).filter(file => file.endsWith('.php')),
    ...rootRuntimeFiles.filter(file => fs.existsSync(path.join(root, file)))]
    .filter(file => new RegExp('\\.(' + sourceExtensions.join('|') + ')$', 'i').test(file) && !/\/(uploads|cache|logs|backups?)\//i.test(file));
  return Object.fromEntries(files.sort().map(file => [file, sha(fs.readFileSync(path.join(root, file)))]));
}
// Backward-compatible name used by existing laboratories and acceptance tooling.
function sources() { return qaSources(); }
function qaSourceIdentity() {
  const sourceHashes = qaSources();
  return {
    schemaVersion: 1,
    definitionId: 'business-data-audit-qa-source-set-v1',
    sourceRoots: [...sourceRoots],
    rootRuntimeFiles: [...rootRuntimeFiles],
    includedExtensions: [...sourceExtensions],
    excludedPathClasses: [
      'config.local.php', '.env*', '.ftp*', 'authorized_key.json',
      'secrets/**', 'credentials/**', 'uploads/**', 'cache/**', 'logs/**', 'backup/**', 'backups/**'
    ],
    pathOrder: 'lexicographic-relative-path',
    digest: 'sha256(JSON.stringify(ordered sourceHashes))',
    fileCount: Object.keys(sourceHashes).length,
    includedPaths: Object.keys(sourceHashes),
    sourceHashesSha256: sha(JSON.stringify(sourceHashes))
  };
}
function laboratoryArtifactIdentity() {
  return {
    schemaVersion: 1,
    definitionId: 'business-data-audit-laboratory-artifact-set-v1',
    entries: laboratoryArtifactFiles.map(entry => {
      const full = path.join(root, entry.path);
      if (!fs.existsSync(full) || !fs.statSync(full).isFile()) throw Error('Missing laboratory artifact: ' + entry.path);
      const bytes = fs.readFileSync(full);
      return {...entry, origin: 'project-root/' + entry.path, bytes: bytes.length, sha256: sha(bytes)};
    })
  };
}
function laboratoryTechnicalMetadataIdentity() {
  const files = [...technicalMetadataFiles];
  for (const relativeDir of ['artifacts/test-lifecycle/entries', 'artifacts/retention-ledger/entries']) {
    const entriesDir = path.join(root, relativeDir);
    if (!fs.existsSync(entriesDir) || !fs.statSync(entriesDir).isDirectory()) {
      throw Error('Missing technical metadata directory: ' + relativeDir);
    }
    for (const name of fs.readdirSync(entriesDir).filter(name => name.endsWith('.json')).sort()) {
      files.push(relativeDir + '/' + name);
    }
  }
  return {
    schemaVersion: 1,
    definitionId: 'business-data-audit-technical-metadata-set-v1',
    entries: files.map(relative => {
      const full = path.join(root, relative);
      if (!fs.existsSync(full) || !fs.statSync(full).isFile()) throw Error('Missing technical metadata: ' + relative);
      const bytes = fs.readFileSync(full);
      return {path: relative, artifactClass: 'project-technical-metadata-snapshot',
        purpose: 'Current Test Lifecycle readiness metadata required by the project validator.',
        origin: 'project-root/' + relative, bytes: bytes.length, sha256: sha(bytes)};
    })
  };
}
function laboratoryEnvironmentIdentity() {
  return {
    schemaVersion: 1,
    definitionId: 'business-data-audit-environment-inputs-v1',
    entries: environmentDependencies.map(entry => ({...entry}))
  };
}
function protectedSnapshot() {
  const locations = {'project-private': path.join(root, 'private/rent-rk-data'),
    'project-public': path.join(root, 'data'), 'host-private': path.resolve(root, '../private/rent-rk-data')};
  const result = {};
  for (const [label, dir] of Object.entries(locations)) {
    for (const file of walk(dir)) {
      if (label === 'project-private' && file === 'project-progress-map.json') continue;
      const bytes = fs.readFileSync(path.join(dir, file));
      result[label + '/' + file] = {bytes: bytes.length, sha256: sha(bytes)};
    }
  }
  return result;
}
function save(file, value) { fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n', {flag: 'wx'}); }
function create(label) {
  if (!/^[a-z0-9-]+$/.test(label)) throw Error('Invalid laboratory label');
  const dir = path.join(root, 'tmp/business-data-audit', Date.now() + '-' + label + '-' + crypto.randomBytes(4).toString('hex'));
  fs.mkdirSync(dir, {recursive: true});
  const baseline = {createdAt: new Date().toISOString(), laboratoryId: path.basename(dir), sourceHashes: sources(),
    artifactDependencies: laboratoryArtifactIdentity(), technicalMetadataDependencies: laboratoryTechnicalMetadataIdentity(),
    environmentDependencies: laboratoryEnvironmentIdentity(), protected: protectedSnapshot(),
    technicalExceptions: ['project-private/project-progress-map.json'],
    secretContentExcluded: ['**/secrets/**', '**/credentials/**', 'admin/config.local.php', '**/.env*', '**/.ftp*', '**/authorized_key.json']};
  baseline.sourceSha256 = sha(JSON.stringify(baseline.sourceHashes));
  save(path.join(dir, 'baseline.json'), baseline);
  const lab = path.join(dir, 'sandbox/app'); fs.mkdirSync(lab, {recursive: true});
  for (const [file, hash] of Object.entries(baseline.sourceHashes)) {
    const target = path.join(lab, file); fs.mkdirSync(path.dirname(target), {recursive: true});
    fs.copyFileSync(path.join(root, file), target, fs.constants.COPYFILE_EXCL);
    if (sha(fs.readFileSync(target)) !== hash) throw Error('Source changed while copying: ' + file);
  }
  for (const artifact of baseline.artifactDependencies.entries) {
    if (baseline.sourceHashes[artifact.path]) throw Error('Artifact mislabeled as QA source: ' + artifact.path);
    const target = path.join(lab, artifact.path); fs.mkdirSync(path.dirname(target), {recursive: true});
    fs.copyFileSync(path.join(root, artifact.path), target, fs.constants.COPYFILE_EXCL);
    if (sha(fs.readFileSync(target)) !== artifact.sha256) throw Error('Artifact changed while copying: ' + artifact.path);
  }
  for (const metadata of baseline.technicalMetadataDependencies.entries) {
    if (baseline.sourceHashes[metadata.path]) throw Error('Technical metadata mislabeled as QA source: ' + metadata.path);
    const target = path.join(lab, metadata.path); fs.mkdirSync(path.dirname(target), {recursive: true});
    fs.copyFileSync(path.join(root, metadata.path), target, fs.constants.COPYFILE_EXCL);
    if (sha(fs.readFileSync(target)) !== metadata.sha256) throw Error('Technical metadata changed while copying: ' + metadata.path);
  }
  for (const suffix of ['data', 'private/rent-rk-data', 'tmp/default-data', 'tmp/sessions', 'tmp/system', 'guard']) fs.mkdirSync(path.join(lab, suffix), {recursive: true});
  fs.writeFileSync(path.join(lab, '.rent-rk-test-lab'), 'isolated-code-only\n', {flag:'wx'});
  fs.copyFileSync(path.join(root, 'tools/business-data-audit-prepend.php'), path.join(lab, 'guard/prepend.php'));
  fs.writeFileSync(path.join(lab, 'guard/isolation.ini'), [
    'open_basedir="' + slash(path.dirname(lab)) + '"',
    'auto_prepend_file="' + slash(path.join(lab, 'guard/prepend.php')) + '"',
    'sys_temp_dir="' + slash(path.join(lab, 'tmp/system')) + '"',
    'upload_tmp_dir="' + slash(path.join(lab, 'tmp/system')) + '"',
    'session.save_path="' + slash(path.join(lab, 'tmp/sessions')) + '"',
    'allow_url_fopen=0', 'allow_url_include=0',
    'disable_functions=mail,curl_exec,curl_multi_exec,fsockopen,pfsockopen,stream_socket_client',
    'display_errors=0', 'log_errors=1',
    'error_log="' + slash(path.join(lab, 'tmp/php-errors.log')) + '"'
  ].join('\n') + '\n');
  save(path.join(lab, 'guard/binding.json'), {root: slash(fs.realpathSync(lab)), boundary: slash(fs.realpathSync(path.dirname(lab))), baseline: baseline.sourceSha256});
  save(path.join(dir, 'laboratory.json'), {dir, lab, sourceSha256: baseline.sourceSha256, status: 'CREATED_NOT_TESTED'});
  return {dir, lab, baseline};
}
function load(dir) {
  const real = fs.realpathSync(dir), parent = fs.realpathSync(path.join(root, 'tmp/business-data-audit'));
  if (!real.startsWith(parent + path.sep)) throw Error('Not an audit laboratory');
  const meta = JSON.parse(fs.readFileSync(path.join(real, 'laboratory.json')));
  if (![path.join(real, 'app'), path.join(real, 'sandbox/app')].includes(fs.realpathSync(meta.lab))) throw Error('Invalid lab binding');
  return {...meta, baseline: JSON.parse(fs.readFileSync(path.join(real, 'baseline.json')))};
}
function env(lab) {
  const allowed = /^(path|pathext|comspec|systemroot|windir|systemdrive|programfiles(?:\(x86\))?|programw6432|commonprogramfiles(?:\(x86\))?|number_of_processors|processor_architecture|os|userprofile|appdata|localappdata|homedrive|homepath|playwright_browsers_path|rent_rk_qa_php)$/i;
  const clean = Object.fromEntries(Object.entries(process.env).filter(([key]) => allowed.test(key)));
  const binding = JSON.parse(fs.readFileSync(path.join(lab,'guard/binding.json')));
  const laboratory = JSON.parse(fs.readFileSync(path.join(path.dirname(path.dirname(lab)), 'baseline.json')));
  return {...clean, PHP_INI_SCAN_DIR: path.join(lab, 'guard'), RENT_RK_AUDIT_LAB_ROOT: lab,
    RENT_RK_AUDIT_SOURCE_SHA256: binding.baseline, RENT_RK_AUDIT_LAB_ID: laboratory.laboratoryId,
    RENT_RK_ALLOW_TEST_DATA_DIR: '1', RENT_RK_TEST_DATA_DIR: path.join(lab, 'tmp/default-data'),
    TMP: path.join(lab, 'tmp/system'), TEMP: path.join(lab, 'tmp/system')};
}
function validateJsonShape(relative, value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return 'JSON_OBJECT_REQUIRED';
  if (relative.endsWith('/TEST_REGISTRY.json') && (!Array.isArray(value.tests) || value.schemaVersion !== 1)) return 'TEST_REGISTRY_SCHEMA_INVALID';
  if (relative.endsWith('/CURRENT_SUMMARY.json') && value.schemaVersion !== 1) return 'CURRENT_SUMMARY_SCHEMA_INVALID';
  if (relative.startsWith('artifacts/test-lifecycle/entries/') && (typeof value.eventId !== 'string' || value.eventId === '')) return 'LIFECYCLE_EVENT_SCHEMA_INVALID';
  if (relative.startsWith('artifacts/retention-ledger/entries/') && (typeof value.entryId !== 'string' || value.entryId === '')) return 'RETENTION_ENTRY_SCHEMA_INVALID';
  return null;
}
function validateLaboratoryInputs(state) {
  const violations = [];
  const add = (component, input, origin, reason) => violations.push({stage: 'pre-gate', component, input, origin, reason});
  const checkFile = (entry, component) => {
    const relative = slash(entry.path);
    const target = path.resolve(state.lab, relative);
    if (!target.startsWith(path.resolve(state.lab) + path.sep)) return add(component, relative, entry.origin, 'PATH_OUTSIDE_LAB');
    let bytes;
    try {
      if (!fs.existsSync(target) || !fs.statSync(target).isFile()) return add(component, relative, entry.origin, 'MISSING_FILE');
      bytes = fs.readFileSync(target);
    } catch (error) { return add(component, relative, entry.origin, 'UNREADABLE_FILE:' + error.code); }
    if (bytes.length !== entry.bytes) add(component, relative, entry.origin, 'SIZE_MISMATCH');
    if (sha(bytes) !== entry.sha256) add(component, relative, entry.origin, 'SHA256_MISMATCH');
    if (relative.endsWith('.json')) {
      try {
        const shape = validateJsonShape(relative, JSON.parse(bytes));
        if (shape) add(component, relative, entry.origin, shape);
      } catch { add(component, relative, entry.origin, 'INVALID_JSON'); }
    }
  };
  for (const [relative, digest] of Object.entries(state.baseline.sourceHashes || {})) {
    const target = path.resolve(state.lab, relative);
    if (!target.startsWith(path.resolve(state.lab) + path.sep)) { add('all-components', relative, 'qa-source-set', 'PATH_OUTSIDE_LAB'); continue; }
    try {
      if (!fs.existsSync(target) || !fs.statSync(target).isFile()) add('all-components', relative, 'qa-source-set', 'MISSING_FILE');
      else if (sha(fs.readFileSync(target)) !== digest) add('all-components', relative, 'qa-source-set', 'SHA256_MISMATCH');
    } catch (error) { add('all-components', relative, 'qa-source-set', 'UNREADABLE_FILE:' + error.code); }
  }
  for (const entry of state.baseline.artifactDependencies?.entries || []) checkFile(entry, 'publication-components');
  for (const entry of state.baseline.technicalMetadataDependencies?.entries || []) checkFile(entry, 'qa-infrastructure,lifecycle-validator');
  for (const entry of state.baseline.environmentDependencies?.entries || []) {
    if (entry.kind === 'node-module') {
      if (!fs.existsSync(entry.path)) add('environment-dependent-components', entry.id, entry.path, 'NODE_MODULE_UNAVAILABLE');
    } else if (entry.id === 'php') {
      const probe = cp.spawnSync(entry.command, ['-v'], {encoding: 'utf8', timeout: 10000});
      if (probe.status !== 0) add('php-components', entry.id, entry.command, 'EXECUTABLE_UNAVAILABLE');
    } else if (entry.id === 'node' && !fs.existsSync(entry.command)) {
      add('node-components', entry.id, entry.command, 'EXECUTABLE_UNAVAILABLE');
    }
  }
  return {schemaVersion: 1, status: violations.length ? 'BLOCKED_LABORATORY_INPUTS' : 'PASS_LABORATORY_INPUTS',
    checkedSourceCount: Object.keys(state.baseline.sourceHashes || {}).length,
    checkedArtifactCount: (state.baseline.artifactDependencies?.entries || []).length,
    checkedTechnicalMetadataCount: (state.baseline.technicalMetadataDependencies?.entries || []).length,
    checkedEnvironmentCount: (state.baseline.environmentDependencies?.entries || []).length,
    violations};
}
function verify(state) {
  const current = protectedSnapshot();
  const changed = [...new Set([...Object.keys(current), ...Object.keys(state.baseline.protected)])]
    .filter(file => JSON.stringify(current[file]) !== JSON.stringify(state.baseline.protected[file]));
  const copyChanged = Object.entries(state.baseline.sourceHashes).filter(([file, hash]) => !fs.existsSync(path.join(state.lab, file))
    || sha(fs.readFileSync(path.join(state.lab, file))) !== hash).map(([file]) => file);
  const canonicalArtifactChanged = (state.baseline.artifactDependencies?.entries || []).filter(artifact =>
    !fs.existsSync(path.join(root, artifact.path)) || sha(fs.readFileSync(path.join(root, artifact.path))) !== artifact.sha256
  ).map(artifact => artifact.path);
  const laboratoryArtifactChanged = (state.baseline.artifactDependencies?.entries || []).filter(artifact =>
    !fs.existsSync(path.join(state.lab, artifact.path)) || sha(fs.readFileSync(path.join(state.lab, artifact.path))) !== artifact.sha256
  ).map(artifact => artifact.path);
  const canonicalTechnicalMetadataChanged = (state.baseline.technicalMetadataDependencies?.entries || []).filter(entry =>
    !fs.existsSync(path.join(root, entry.path)) || sha(fs.readFileSync(path.join(root, entry.path))) !== entry.sha256
  ).map(entry => entry.path);
  const laboratoryTechnicalMetadataChanged = (state.baseline.technicalMetadataDependencies?.entries || []).filter(entry =>
    !fs.existsSync(path.join(state.lab, entry.path)) || sha(fs.readFileSync(path.join(state.lab, entry.path))) !== entry.sha256
  ).map(entry => entry.path);
  const result = {checkedAt: new Date().toISOString(), canonicalUnchanged: !changed.length, changed,
    laboratorySourceUnchanged: !copyChanged.length, copyChanged,
    canonicalArtifactsUnchanged: !canonicalArtifactChanged.length, canonicalArtifactChanged,
    laboratoryArtifactsUnchanged: !laboratoryArtifactChanged.length, laboratoryArtifactChanged,
    canonicalTechnicalMetadataUnchanged: !canonicalTechnicalMetadataChanged.length, canonicalTechnicalMetadataChanged,
    laboratoryTechnicalMetadataUnchanged: !laboratoryTechnicalMetadataChanged.length, laboratoryTechnicalMetadataChanged,
    protectedFiles: Object.keys(current).length};
  save(path.join(state.dir, 'preservation-' + Date.now() + '.json'), result); return result;
}
function artifactJsonFromResult(state, data) {
  if (!data || typeof data !== 'object') return data;
  const candidate = [data.artifact, data.summary, data.evidence].find(value => typeof value === 'string' && value.trim() !== '');
  if (!candidate) return data;
  const full = path.isAbsolute(candidate) ? candidate : path.resolve(state.lab, candidate);
  let real;
  try { real = fs.realpathSync(full); } catch { return data; }
  if (!real.startsWith(state.lab + path.sep) || path.extname(real).toLowerCase() !== '.json') return data;
  try { return JSON.parse(fs.readFileSync(real)); } catch { return data; }
}
const primaryReportContracts = Object.freeze({
  'tools/bootstrap-json-write-qa.cjs': {
    componentId: 'bootstrap-json-write',
    stdoutField: 'report',
    directory: 'tmp/bootstrap-json-write',
    relativePath: /^tmp\/bootstrap-json-write\/([a-f0-9]{32})\/bootstrap-json-write-primary\.json$/
  },
  'tools/booking-buffer-per-scope-qa.php': {
    componentId: 'booking-buffer',
    stdoutField: 'report',
    directory: 'tmp/booking-buffer-per-scope',
    relativePath: /^tmp\/booking-buffer-per-scope\/([0-9]{8}-[0-9]{6}-[a-f0-9]{8})\/booking-buffer-per-scope-qa-result\.json$/
  },
  'tools/shared-writers-seven-gaps-evidence-qa.cjs': {
    componentId: 'shared-writers-seven-gaps',
    stdoutField: 'report',
    directory: 'tmp/shared-writers-seven-gaps',
    relativePath: /^tmp\/shared-writers-seven-gaps\/([a-f0-9]{32})\/shared-writers-seven-gaps-result\.json$/
  },
  'tools/business-data-public-rate-limit-qa.cjs': {
    componentId: 'public-rate-limit',
    stdoutField: 'report',
    directory: 'tmp/public-rate-limit',
    relativePath: /^tmp\/public-rate-limit\/([0-9]{8}-[0-9]{6}-[a-f0-9]{8})\/public-rate-limit-primary-result\.json$/
  },
  'tools/shared-writers-owner-aba-qa.cjs': {
    componentId: 'shared-writers-owner-aba',
    stdoutField: 'report',
    directory: 'tmp/shared-writers-owner-aba',
    relativePath: /^tmp\/shared-writers-owner-aba\/([0-9]{8}-[0-9]{6}-[a-f0-9]{8})\/shared-writers-owner-aba-primary-result\.json$/
  }
});
function pathInside(parent, candidate) {
  const relative = path.relative(parent, candidate);
  return relative !== '' && !relative.startsWith('..' + path.sep) && relative !== '..' && !path.isAbsolute(relative);
}
function hasLinkedPathSegment(rootDir, target) {
  const relative = path.relative(rootDir, target);
  let current = rootDir;
  for (const segment of relative.split(path.sep)) {
    current = path.join(current, segment);
    if (fs.lstatSync(current).isSymbolicLink()) return true;
  }
  return false;
}
function primaryReportSnapshot(state, script) {
  const contract = primaryReportContracts[script];
  if (!contract?.directory) return [];
  const rootDir = path.join(state.lab, contract.directory);
  if (!fs.existsSync(rootDir)) return [];
  return fs.readdirSync(rootDir, {withFileTypes: true}).filter(entry => entry.isDirectory()).flatMap(entry => {
    const dir = path.join(rootDir, entry.name);
    try {
      return fs.readdirSync(dir).filter(name => name.endsWith('.json')).map(name => path.resolve(dir, name))
        .filter(file => fs.lstatSync(file).isFile());
    } catch { return []; }
  });
}
function validatePrimaryReport(state, script, args, stdout, context = {}) {
  const contract = primaryReportContracts[script];
  if (!contract) return {configured: false, errors: [], data: null, checks: null, provenance: null};
  const errors = [];
  if (context.exitCode !== 0) errors.push('CHILD_PROCESS_EXIT_NONZERO');
  if (context.signal) errors.push('CHILD_PROCESS_SIGNALLED');
  if (context.errorCode) errors.push('CHILD_PROCESS_ERROR:' + context.errorCode);
  if (!stdout || typeof stdout !== 'object' || Array.isArray(stdout)) errors.push('PRIMARY_STDOUT_JSON_REQUIRED');
  const candidate = stdout?.[contract.stdoutField];
  if (typeof candidate !== 'string' || candidate.trim() === '') errors.push('PRIMARY_REPORT_PATH_MISSING');
  const lab = path.resolve(state.lab);
  let full = null, relative = null, bytes = null, data = null;
  if (typeof candidate === 'string' && candidate.trim() !== '') {
    full = path.resolve(path.isAbsolute(candidate) ? candidate : path.join(lab, candidate));
    if (!pathInside(lab, full)) errors.push('PRIMARY_REPORT_PATH_OUTSIDE_LAB');
    else {
      relative = slash(path.relative(lab, full));
      const match = relative.match(contract.relativePath);
      if (!match) errors.push('PRIMARY_REPORT_PATH_CONTRACT_MISMATCH');
      try {
        if (!fs.existsSync(full) || !fs.lstatSync(full).isFile()) errors.push('PRIMARY_REPORT_REGULAR_FILE_REQUIRED');
        else if (hasLinkedPathSegment(lab, full)) errors.push('PRIMARY_REPORT_LINK_REJECTED');
        else {
          const realLab = fs.realpathSync(lab), real = fs.realpathSync(full);
          if (!pathInside(realLab, real)) errors.push('PRIMARY_REPORT_REALPATH_OUTSIDE_LAB');
          else {
            bytes = fs.readFileSync(real);
            try { data = JSON.parse(bytes); } catch { errors.push('PRIMARY_REPORT_MALFORMED_JSON'); }
          }
        }
      } catch (error) { errors.push('PRIMARY_REPORT_UNREADABLE:' + (error.code || 'UNKNOWN')); }
      if (data && match && data.runId !== match[1]) errors.push('PRIMARY_REPORT_RUN_PATH_MISMATCH');
    }
  }
  if (!data || typeof data !== 'object' || Array.isArray(data)) errors.push('PRIMARY_REPORT_OBJECT_REQUIRED');
  if (context.componentId !== contract.componentId) errors.push('PRIMARY_REPORT_COMPONENT_MISMATCH');
  if (!context.runBinding) errors.push('PRIMARY_REPORT_RUN_BINDING_MISSING');
  if (context.sourceSha256 !== state.baseline.sourceSha256) errors.push('PRIMARY_REPORT_SOURCE_MISMATCH');
  if (full && (context.preexistingPaths || []).map(value => path.resolve(value)).includes(full)) errors.push('PRIMARY_REPORT_PREEXISTED_RUN');
  const results = Array.isArray(data?.results) ? data.results : null;
  const checks = results ? results.map(row => ({id: row?.test, passed: row?.passed})) : null;
  if (!results) errors.push('PRIMARY_REPORT_RESULTS_REQUIRED');
  else {
    const ids = checks.map(row => row.id);
    if (checks.some(row => typeof row.id !== 'string' || row.id === '' || typeof row.passed !== 'boolean')) errors.push('PRIMARY_REPORT_CHECK_SHAPE_INVALID');
    if (new Set(ids).size !== ids.length) errors.push('PRIMARY_REPORT_CHECK_ID_DUPLICATE');
    const passed = checks.filter(row => row.passed === true).length;
    const failed = checks.length - passed;
    if (data.checks !== checks.length || data.passed !== passed || data.failed !== failed) errors.push('PRIMARY_REPORT_COUNTER_MISMATCH');
    if ((data.status === 'PASS') !== (failed === 0)) errors.push('PRIMARY_REPORT_STATUS_CONTRADICTION');
  }
  const normalizedChecksSha256 = checks ? sha(JSON.stringify(checks)) : null;
  return {configured: true, errors, data, checks,
    provenance: {status: errors.length ? 'INVALID' : 'VALID', componentId: contract.componentId,
      path: relative, sha256: bytes ? sha(bytes) : null, sourceSha256: state.baseline.sourceSha256,
      laboratoryId: state.baseline.laboratoryId, runBinding: context.runBinding || null,
      script, args, entrySha256: context.entrySha256 || null,
      normalizedChecksSha256, checkCount: checks?.length ?? null, errors: [...errors]}};
}
function resultRows(data) {
  if (Array.isArray(data?.checks)) return data.checks;
  if (Array.isArray(data?.checks?.items)) return data.checks.items;
  if (Array.isArray(data?.tests)) return data.tests;
  if (Array.isArray(data?.results)) return data.results;
  if (Array.isArray(data?.faults)) return data.faults;
  return null;
}
function run(state, script, args = [], checkPreservation = true, options = {}) {
  if (!/^tools\/[a-z0-9-]+\.(php|cjs|js)$/.test(script)) throw Error('Explicit tools entry required');
  const name = script.replace(/^tools\//, '').replace(/\.[^.]+$/, '');
  const stamp = Date.now() + '-' + name;
  const binary = script.endsWith('.php') ? (process.env.PHP_BINARY || 'php') : process.execPath;
  const timeout = script === 'tools/business-data-audit-isolation-qa.php' ? 20000 : 3600000;
  const runBinding = crypto.randomBytes(16).toString('hex');
  const entrySha256 = sha(fs.readFileSync(path.join(state.lab, script)));
  const preexistingPaths = primaryReportSnapshot(state, script);
  const result = cp.spawnSync(binary, [script, ...args], {cwd: state.lab,
    env: {...env(state.lab), RENT_RK_QA_RUN_BINDING: runBinding}, encoding: 'utf8', timeout, maxBuffer: 16 * 1024 * 1024});
  // Raw test output stays in the private local lab, not the evidence package or chat.
  fs.writeFileSync(path.join(state.dir, stamp + '.stdout.local'), result.stdout || '');
  fs.writeFileSync(path.join(state.dir, stamp + '.stderr.local'), result.stderr || '');
  let data = null; try { data = JSON.parse(result.stdout); } catch {}
  const stdout = data;
  const primary = validatePrimaryReport(state, script, args, stdout, {runBinding, entrySha256,
    componentId: options.componentId || primaryReportContracts[script]?.componentId || null,
    sourceSha256: state.baseline.sourceSha256, preexistingPaths,
    exitCode: result.status, signal: result.signal, errorCode: result.error?.code || null});
  if (primary.configured) data = primary.errors.length ? stdout : primary.data;
  else data = artifactJsonFromResult(state, data);
  const rows = primary.configured ? (primary.errors.length ? null : primary.checks) : resultRows(data);
  const checks = primary.configured && !primary.errors.length ? primary.checks : (rows ? rows.map((c, index) => ({
    id: c.test || c.name || c.id || c.label || ('check-' + index),
    passed: c.passed ?? c.pass ?? c.ok
  })) : null);
  const receipt = {script, args, at: new Date().toISOString(), sourceSha256: state.baseline.sourceSha256,
    laboratoryId: state.baseline.laboratoryId, seriesBinding: options.seriesBinding || null, runBinding,
    exitCode: result.status, signal: result.signal, errorCode: result.error?.code || null,
    reportedStatus: primary.configured && primary.errors.length ? 'FAIL_PRIMARY_REPORT_CONTRACT' : (data?.status ?? null),
    passed: data?.passed ?? null, checks,
    checkCount: checks?.length ?? data?.checkCount ?? data?.checksTotal ?? data?.total ?? data?.passed
      ?? (typeof stdout?.checks === 'number' ? stdout.checks : stdout?.total ?? stdout?.passed ?? null),
    failureCount: primary.configured && primary.errors.length ? primary.errors.length : (data?.failureCount ?? data?.failed ?? null),
    entrySha256,
    stdoutSha256: sha(result.stdout || ''), stderrSha256: sha(result.stderr || ''),
    primaryReport: primary.configured ? primary.provenance : null,
    failure: primary.configured && primary.errors.length
      ? {code: 'PRIMARY_REPORT_CONTRACT_INVALID', errors: primary.errors}
      : (data?.error || data?.fatal || stdout?.error || stdout?.fatal || null),
    preservation: checkPreservation ? verify(state) : 'PENDING_BATCH_END'};
  save(path.join(state.dir, stamp + '.json'), receipt); return receipt;
}
module.exports = {root, sha, sources, qaSources, qaSourceIdentity, laboratoryArtifactIdentity,
  laboratoryTechnicalMetadataIdentity, laboratoryEnvironmentIdentity, validateLaboratoryInputs,
  protectedSnapshot, create, load, env, verify, run, save, validatePrimaryReport, primaryReportContracts, primaryReportSnapshot};
if (require.main === module) {
  const [mode, arg, script, ...args] = process.argv.slice(2);
  let result;
  if (mode === 'identity') result = qaSourceIdentity();
  else if (mode === 'artifacts') result = laboratoryArtifactIdentity();
  else if (mode === 'technical-metadata') result = laboratoryTechnicalMetadataIdentity();
  else if (mode === 'inputs') result = validateLaboratoryInputs(load(arg));
  else if (mode === 'create') { const s = create(arg); result = {dir: s.dir, lab: s.lab, sourceSha256: s.baseline.sourceSha256, protectedFiles: Object.keys(s.baseline.protected).length}; }
  else if (mode === 'verify') result = verify(load(arg));
  else if (mode === 'run') result = run(load(arg), script, args);
  else throw Error('Usage: identity | artifacts | technical-metadata | inputs <lab-directory> | create <label> | verify <lab-directory> | run <lab-directory> tools/<suite> [args]');
  console.log(JSON.stringify(result, null, 2));
}
