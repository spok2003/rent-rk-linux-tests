'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),cp=require('child_process'),net=require('net');
const root=path.resolve(__dirname,'..'),binding=process.env.RENT_RK_QA_RUN_BINDING||'';
const digest=x=>crypto.createHash('sha256').update(x).digest('hex'),sha=p=>digest(fs.readFileSync(path.join(root,p)));
const eq=(a,b)=>JSON.stringify(a)===JSON.stringify(b),parse=s=>{try{return JSON.parse(s);}catch{return null;}};
const B01='artifacts/bootstrap-json-b01-20261018/';
const batch='artifacts/bootstrap-auth-audit-access-20261018/';
const AUDIT_ENTRY="  'tools/bootstrap-auth-audit-access-qa.cjs': {\n    componentId: 'bootstrap-auth-audit-access',\n    stdoutField: 'report',\n    directory: 'tmp/bootstrap-auth-audit-access',\n    relativePath: /^tmp\\/bootstrap-auth-audit-access\\/([a-f0-9]{32})\\/batch-primary\\.json$/\n  },\n";
const INPUT_ENTRIES=[B01+'final/primary.json',B01+'final/receipt.json',B01+'source-final.json',batch+'before/tools__business-data-audit.cjs',batch+'before/tools__business-data-critical-gate.cjs',batch+'reuse-evidence.json'];
const ARTIFACT_ENTRIES=INPUT_ENTRIES.map(p=>", {\n  path: '"+p+"',\n  artifactClass: 'version-bound-qa-evidence-input',\n  purpose: 'B01 prerequisite reuse; preserve original native identity, no native rerun.'\n}").join('');
const GATE_ENTRY="  ['bootstrap-auth-audit-access', 'bootstrap-auth-audit-access-qa.cjs'],\n";
function evaluate(rows){return rows.map(r=>({test:r.test,passed:eq(r.actual,r.expected),actual:r.actual,expected:r.expected,detail:r.detail||null}));}
module.exports={evaluate,AUDIT_ENTRY,ARTIFACT_ENTRIES,GATE_ENTRY,INPUT_ENTRIES};
if(require.main===module)main().catch(e=>{console.error(e.message);process.exitCode=1;});
async function main(){
 if(!/^[a-f0-9]{32}$/.test(binding)||path.resolve(process.env.RENT_RK_AUDIT_LAB_ROOT||'')!==root||!fs.existsSync(path.join(root,'.rent-rk-test-lab')))throw Error('Verified lab/run required');
 const out=path.join(root,'tmp/bootstrap-auth-audit-access',binding);fs.mkdirSync(out,{recursive:true});
 const observations=[],runtime=[];let stage='prerequisite',server=null;
 const check=(test,actual,expected,detail)=>observations.push({test,actual,expected,detail});
 const assertStage=()=>{const bad=evaluate(observations).filter(c=>!c.passed);if(bad.length)throw Error('SEMANTIC_MISMATCH:'+bad.map(c=>c.test).join(','));};
 const password=crypto.randomBytes(24).toString('hex');
 const binary=process.env.RENT_RK_QA_PHP||process.env.PHP_BINARY||'php';
 const php=['-d','opcache.enable_cli=0','-d','opcache.enable=0','-d','opcache.file_cache=','-d','zend.exception_ignore_args=1'];
 const env={...process.env,BATCH_QA_OUT:out,BATCH_QA_PASSWORD:password};
 const start=(mode,args=[])=>{
  const child=cp.spawn(binary,[...php,'tools/bootstrap-auth-audit-access-qa.php',mode,out,...args],{cwd:root,env,windowsHide:true,stdio:['ignore','pipe','pipe']});let stdout='',stderr='';child.stdout.on('data',v=>stdout+=v);child.stderr.on('data',v=>stderr+=v);
  const done=new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',(code,signal)=>{const data=parse(stdout);if(code!==0||!data)return reject(Error('CLI_FAILED:'+mode+':'+code));if(data.environment)runtime.push(data.environment);resolve(data);});});return{child,done};
 };
 const cli=async mode=>start(mode).done;
 const changed=(a,b)=>Object.keys(a.hashes).filter(k=>a.hashes[k]!==b.hashes[k]).sort();
 let rawFailure=null;
 try{
  const oldPrimary=JSON.parse(fs.readFileSync(path.join(root,B01+'final/primary.json'))),receipt=JSON.parse(fs.readFileSync(path.join(root,B01+'final/receipt.json'))),oldSource=JSON.parse(fs.readFileSync(path.join(root,B01+'source-final.json')));
  const audit=fs.readFileSync(path.join(root,'tools/business-data-audit.cjs'),'utf8').replaceAll('\r\n','\n');
  const gate=fs.readFileSync(path.join(root,'tools/business-data-critical-gate.cjs'),'utf8').replaceAll('\r\n','\n');
  const originalAudit=fs.readFileSync(path.join(root,batch+'before/tools__business-data-audit.cjs'),'utf8').replaceAll('\r\n','\n');
  const originalGate=fs.readFileSync(path.join(root,batch+'before/tools__business-data-critical-gate.cjs'),'utf8').replaceAll('\r\n','\n');
  const b01Evaluation=require('./bootstrap-json-write-qa.cjs').evaluate(oldPrimary.observations.cases.facts,oldPrimary.observations.concurrency);
  const deps=Object.entries(oldSource.hashes).filter(([p])=>['admin/includes/bootstrap.php','admin/includes/rental-return-store.php','admin/includes/rental-return-service.php','admin/includes/business-data-command.php','admin/includes/business-data-integrity.php','admin/includes/site-maintenance-service.php','tools/bootstrap-json-write-qa.php','tools/bootstrap-json-write-qa.cjs','tools/business-data-writer-review.cjs','tools/business-data-writers.php'].includes(p));
  check('prerequisite_B01_current_applicability',{
   originalQa:receipt.sourceSha256,primaryHashValid:sha(B01+'final/primary.json')===receipt.primaryReport.sha256,original39:oldPrimary.results.length===39&&oldPrimary.results.every(r=>r.passed),originalRunBound:oldPrimary.runId===receipt.runBinding&&oldPrimary.sourceSha256===receipt.sourceSha256,originalEntryBound:receipt.entrySha256===sha('tools/bootstrap-json-write-qa.cjs'),normalizedChecksBound:digest(JSON.stringify(oldPrimary.results.map(r=>({id:r.test,passed:r.passed}))))===receipt.primaryReport.normalizedChecksSha256,semanticContentsValid:b01Evaluation.length===36&&b01Evaluation.every(r=>r.passed),nativeDependenciesUnchanged:deps.every(([p,s])=>sha(p)===s),oldAuditBound:sha(batch+'before/tools__business-data-audit.cjs')===oldSource.hashes['tools/business-data-audit.cjs'],oldGateBound:sha(batch+'before/tools__business-data-critical-gate.cjs')===oldSource.hashes['tools/business-data-critical-gate.cjs'],onlyAdditiveAuditRegistration:audit.replace(AUDIT_ENTRY,'').replace(ARTIFACT_ENTRIES,'')===originalAudit,onlyAdditiveGateRegistration:gate.replace(GATE_ENTRY,'')===originalGate
  },{originalQa:'1621acc239b5815dfd7d63a4d3cacf31d82a23e4d716bd55f50b4d74a9c4a250',primaryHashValid:true,original39:true,originalRunBound:true,originalEntryBound:true,normalizedChecksBound:true,semanticContentsValid:true,nativeDependenciesUnchanged:true,oldAuditBound:true,oldGateBound:true,onlyAdditiveAuditRegistration:true,onlyAdditiveGateRegistration:true},{nativeReruns:0,originalLab:receipt.laboratoryId,originalRun:receipt.runBinding});assertStage();
  const reuse=JSON.parse(fs.readFileSync(path.join(root,batch+'reuse-evidence.json')));
  check('reuse_existing_auth_users_applicability',{prefix:reuse.bootstrapAuthPrefixUnchanged,auditBody:reuse.auditBodyUnchanged,dependencies:reuse.dependencies.every(x=>sha(x.path)===x.current&&x.current===x.historical),historicalChecksValid:reuse.components.every(c=>c.exitCode===0&&c.checks.every(x=>x.passed)),clockValid:Date.now()<Date.parse('2036-01-01T00:00:00+03:00')},{prefix:true,auditBody:true,dependencies:true,historicalChecksValid:true,clockValid:true},{source:reuse.source,originalQa:reuse.originalQa,components:reuse.components.map(c=>({id:c.id,checks:c.checks.length})),nativeReruns:0});assertStage();
  stage='B02';const relative=await cli('session-relative');check('B02_relative_session_path',{active:relative.active,exists:relative.directoryExists,files:relative.sessionFiles,confined:fs.realpathSync(relative.path).replaceAll('\\','/').startsWith(fs.realpathSync(root).replaceAll('\\','/')+'/tmp/')},{active:true,exists:true,files:1,confined:true},{comparison:'Actual filesystem path, not unnormalised PROJECT_ROOT alias'});assertStage();
  await cli('seed');check('prerequisite_B01_same_php_version',oldPrimary.results.find(x=>x.test==='all_php_participants_cache_free').detail.every(e=>e.version===runtime[0].version),true);assertStage();const port=await new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p));});});
  server=cp.spawn(binary,[...php,'-S','127.0.0.1:'+port,'tools/bootstrap-auth-audit-access-qa.php'],{cwd:root,env,windowsHide:true,stdio:['ignore','ignore','ignore']});
  const origin='http://127.0.0.1:'+port;
  async function request(url,jar=new Map(),post=null,headers={}){
   const opts={redirect:'manual',headers:{'X-Forwarded-Proto':'https',...headers},signal:AbortSignal.timeout(12000)};
   if(jar.size)opts.headers.Cookie=[...jar].map(([k,v])=>k+'='+v).join('; ');
   if(post){opts.method='POST';opts.headers['Content-Type']='application/x-www-form-urlencoded';opts.body=new URLSearchParams(post);}
   const r=await fetch(origin+url,opts),text=await r.text(),cookies=[];
   for(const line of r.headers.getSetCookie()){const [pair,...attrs]=line.split(';'),pos=pair.indexOf('='),name=pair.slice(0,pos),value=pair.slice(pos+1);const flags=Object.fromEntries(attrs.map(x=>{const [k,...v]=x.trim().split('=');return[k.toLowerCase(),v.join('=')||true];}));if(value===''||flags['max-age']==='0')jar.delete(name);else jar.set(name,value);cookies.push({name,path:flags.path||null,httpOnly:flags.httponly===true,secure:flags.secure===true,sameSite:flags.samesite||null,deleted:value===''||flags['max-age']==='0'});}
   return{status:r.status,text,json:parse(text),cookies};
  }
  let ready=false;for(let i=0;i<60;i++){try{await request('/admin/index.php');ready=true;break;}catch{await new Promise(r=>setTimeout(r,50));}}if(!ready)throw Error('HTTP_START_FAILED');
  const csrf=html=>{const t=html.match(/name="csrf_token"[^>]*value="([^"]+)"/);if(!t)throw Error('Native form CSRF missing');return t[1];};
  const version=html=>{const t=html.match(/name="expected_version"[^>]*value="([^"]+)"/);if(!t)throw Error('Native form version missing');return t[1];};
  async function login(login){const jar=new Map(),form=await request('/admin/index.php',jar),before=jar.get('PHPSESSID');const response=await request('/admin/index.php',jar,{csrf_token:csrf(form.text),login,password,remember_me:'1'});return{jar,response,rotated:before!==jar.get('PHPSESSID'),oldSession:before};}
  const manager=await login('batch-manager'),identity=(await request('/admin/__qa/identity',manager.jar)).json;runtime.push(identity.environment);
  check('B02_password_identity',{status:manager.response.status,login:identity.login,role:identity.role,rotated:manager.rotated},{status:302,login:'batch-manager',role:'manager',rotated:true});
  check('B02_remember_cookie_attributes',manager.response.cookies.find(c=>c.name==='rent_rk_admin_remember'),{name:'rent_rk_admin_remember',path:'/admin',httpOnly:true,secure:true,sameSite:'Lax',deleted:false});
  const oldJar=new Map([['PHPSESSID',manager.oldSession]]);check('B02_old_session_does_not_restore',(await request('/admin/__qa/identity',oldJar)).json.authenticated,false);
  const remember=manager.jar.get('rent_rk_admin_remember'),restoreJar=new Map([['rent_rk_admin_remember',remember]]),restored=await request('/admin/__qa/identity',restoreJar);
  check('B02_remember_rotates_identity',{login:restored.json.login,role:restored.json.role,rotated:restoreJar.get('rent_rk_admin_remember')!==remember},{login:'batch-manager',role:'manager',rotated:true});
  const snap1=await cli('snapshot');check('B02_token_rotation_contents',snap1.safe['remember-tokens'].items.map(x=>({login:x.login,status:x.status})),[{login:'batch-manager',status:'revoked'},{login:'batch-manager',status:'active'}]);
  const replay=await request('/admin/__qa/identity',new Map([['rent_rk_admin_remember',remember]]));const snap2=await cli('snapshot');check('B02_old_token_replay',{authenticated:replay.json.authenticated,storesStable:eq(snap1.hashes,snap2.hashes),cleared:replay.cookies.some(c=>c.name==='rent_rk_admin_remember'&&c.deleted)},{authenticated:false,storesStable:true,cleared:true});
  const failedJar=new Map(),failedForm=await request('/admin/index.php',failedJar),beforeFault=await cli('snapshot');
  const failedResponse=await request('/admin/index.php',failedJar,{csrf_token:csrf(failedForm.text),login:'batch-manager',password,remember_me:'1'},{'X-QA-Fault':'audit-log'});
  const afterFault=await cli('snapshot');check('B02_storage_fault_no_identity',{failed:failedResponse.status>=400,authenticated:(await request('/admin/__qa/identity',failedJar)).json.authenticated,storesStable:eq(beforeFault.hashes,afterFault.hashes),rememberIssued:failedJar.has('rent_rk_admin_remember')},{failed:true,authenticated:false,storesStable:true,rememberIssued:false});
  const rogue=await login('rogue-admin');check('B02_nonconfigured_admin_denied',(await request('/admin/__qa/identity',rogue.jar)).json.authenticated,false);
  const logout=await request('/admin/logout.php',restoreJar);check('B02_cookie_revocation_attributes',logout.cookies.find(c=>c.name==='rent_rk_admin_remember'),{name:'rent_rk_admin_remember',path:'/admin',httpOnly:true,secure:true,sameSite:'Lax',deleted:true});
  check('B02_logout_identity',(await request('/admin/__qa/identity',restoreJar)).json.authenticated,false);assertStage();check('group_B02_complete',true,true);
  stage='B07';
  for(const mode of ['technical-mkdir','technical-mkdir-refusal','technical-append-refusal']){
   const data=await cli(mode);
   if(mode==='technical-mkdir')check('B07_technical_mkdir_append',{error:data.error,parent:data.parentExists,lines:data.lines.map(x=>{const p=JSON.parse(x);return{event:p.event,context:p.context};})},{error:null,parent:true,lines:[{event:'batch.technical',context:{marker:'safe',nested:{keep:7}}},{event:'batch.technical.second',context:{marker:'safe'}}]});
   else check('B07_'+mode,{error:data.error,file:data.fileExists,expectedFailureState:mode==='technical-mkdir-refusal'?data.blockerIntact:data.fileIsDirectory},{error:null,file:false,expectedFailureState:true},{contract:'Best effort void logger; no success/durability receipt promised. No secret context supplied.'});
  }
  const workers=await Promise.all([start('technical-worker',['A']).done,start('technical-worker',['B']).done]);
  const lines=fs.readFileSync(path.join(out,'data-technical-concurrent/technical.log'),'utf8').trim().split(/\r?\n/).map(JSON.parse);
  const keys=lines.map(x=>x.event+':'+x.context.worker+':'+x.context.sequence).sort(),want=['A','B'].flatMap(x=>Array.from({length:40},(_,i)=>'batch.append:'+x+':'+i)).sort();check('B07_technical_concurrent_complete_lines',keys,want,{workerCompletion:workers.map(x=>x.done)});
  const auditResult=await cli('audit'),entry=auditResult.after.items[0];
  check('B07_audit_actor_fields',{user:entry.user,role:entry.role,action:entry.action,entityType:entry.entityType,entityId:entry.entityId,summary:entry.summary,meta:entry.meta},{user:'batch-actor',role:'manager',action:'batch.audit',entityType:'test',entityId:'owned',summary:'summary',meta:{nested:{keep:7,invalid:'x\ufffd'}}});
  check('B07_audit_exact_truncation',{count:auditResult.after.items.length,tail:auditResult.after.items.slice(1),future:auditResult.after.futureEnvelope,idValid:/^log_\d{8}_\d{6}_[a-f0-9]{6}$/.test(entry.id),dateValid:Number.isFinite(Date.parse(entry.createdAt))},{count:1000,tail:auditResult.before.items.slice(0,999),future:{keep:31},idValid:true,dateValid:true});
  check('B07_audit_commit_failure_rollback',{fault:auditResult.fault!==null,reached:auditResult.faultReached,artifacts:auditResult.afterFault},{fault:true,reached:true,artifacts:auditResult.beforeFault});assertStage();check('group_B07_complete',true,true);
  stage='B03';const raw=await cli('raw-users');check('B03_raw_helper_exact_result',raw.after,{...raw.before,users:Object.values(raw.before.users)},{limitation:'Known legacy callers delegate to V2 before fallback; this is direct isolated low-level helper execution, not an invented live controller caller.'});
  const rootLogin=await login('batch-root'),north=await login('batch-north');
  const rootJar=rootLogin.jar;
  const records=async()=> (await request('/admin/__qa/records',rootJar)).json.users;
  const userPayload=(login,name,record,scope)=>({action:'user_save',original_login:login,login,name,profile:'manager',scope_id:scope,active:'1',effective_permissions:JSON.stringify(record.effectivePermissions),expected_record_hash:record.recordHash});
  async function userPost(jar,payload){return request('/admin/users.php',jar,{csrf_token:csrf((await request('/admin/profile.php',jar)).text),...payload});}
  let rec=await records(),beforeUser=await cli('snapshot'),p=userPayload('batch-manager','Changed Main',rec['batch-manager'],'rent_rk');
  const saved=await userPost(rootJar,p),afterUser=await cli('snapshot');
  check('B03_root_update_exact_target',{status:saved.status,name:afterUser.safe['admin-users'].users.find(u=>u.login==='batch-manager').name,future:afterUser.safe['admin-users'].futureEnvelope,unrelated:afterUser.safe['admin-users'].users.filter(u=>u.login!=='batch-manager'),changed:changed(beforeUser,afterUser)},{status:200,name:'Changed Main',future:{keep:17},unrelated:beforeUser.safe['admin-users'].users.filter(u=>u.login!=='batch-manager').map(u=>u.login==='batch-root'?{...u,archived:false,partnerSlug:'',partnerAgentSlug:''}:u),changed:['admin-users','audit-log']},{contract:'V2 explicitly canonicalizes configured Root fields on write. Existing fixture omitted three false/empty defaults; no role/scope/unknown-field change is allowed.'});
  check('B03_no_credentials_in_response',/passwordHash|passwordSalt|tokenHash/.test(saved.text),false);
  let stable=await cli('snapshot');const stale=await userPost(rootJar,p);check('B03_stale_and_repeat_refusal',{status:stale.status,unchanged:eq(stable.hashes,(await cli('snapshot')).hashes)},{status:409,unchanged:true});
  rec=await records();stable=await cli('snapshot');const forbidden=await userPost(manager.jar,userPayload('batch-manager','Forbidden',rec['batch-manager'],'rent_rk'));check('B03_permission_own_valid_csrf',{status:forbidden.status,unchanged:eq(stable.hashes,(await cli('snapshot')).hashes)},{status:403,unchanged:true});
  const own=await userPost(north.jar,userPayload('north-manager','Changed North',rec['north-manager'],'north'));let afterOwn=await cli('snapshot');check('B03_scoped_own_positive',{status:own.status,name:afterOwn.safe['admin-users'].users.find(u=>u.login==='north-manager').name,south:afterOwn.safe['admin-users'].users.find(u=>u.login==='south-manager')},{status:200,name:'Changed North',south:stable.safe['admin-users'].users.find(u=>u.login==='south-manager')});
  rec=await records();stable=await cli('snapshot');const foreign=await userPost(north.jar,userPayload('south-manager','Foreign',rec['south-manager'],'south'));check('B03_foreign_scope_valid_csrf',{status:foreign.status,unchanged:eq(stable.hashes,(await cli('snapshot')).hashes)},{status:403,unchanged:true});
  const grant=userPayload('north-manager','Escalated',rec['north-manager'],'north');grant.effective_permissions=JSON.stringify([...rec['north-manager'].effectivePermissions,'finance.manage']);const escalation=await userPost(north.jar,grant);check('B03_finance_escalation_refused',{status:escalation.status,unchanged:eq(stable.hashes,(await cli('snapshot')).hashes)},{status:422,unchanged:true},{contract:'InvalidArgumentException for nondelegable permission list; distinct from route permission/scope403.'});
  let aclForm=await request('/admin/access-rules.php',rootJar),rulePayload={action:'save',from_scope_id:'rent_rk',to_scope_id:'lessor:north','cars[]':'batch-car',status:'active',comment:'Synthetic access','allow_lessor_managers':'1',expected_version:version(aclForm.text),csrf_token:csrf(aclForm.text)};
  const aclBefore=await cli('snapshot'),aclSaved=await request('/admin/access-rules.php',rootJar,rulePayload),aclAfter=await cli('snapshot'),rule=aclAfter.safe['access-rules'].items[0];
  check('B03_access_rule_native_root',{status:aclSaved.status,rule:rule?{from:rule.from_scope_id,to:rule.to_scope_id,cars:rule.cars,status:rule.status,comment:rule.comment}:null,future:aclAfter.safe['access-rules'].futureEnvelope,changed:changed(aclBefore,aclAfter)},{status:302,rule:{from:'rent_rk',to:'lessor:north',cars:['batch-car'],status:'active',comment:'Synthetic access'},future:{keep:19},changed:['access-rules','audit-log']});
  const aclStale=await request('/admin/access-rules.php',rootJar,rulePayload);check('B03_access_stale_no_duplicate',{status:aclStale.status,unchanged:eq(aclAfter.hashes,(await cli('snapshot')).hashes)},{status:409,unchanged:true});
  const northCsrf=csrf((await request('/admin/profile.php',north.jar)).text);const aclDenied=await request('/admin/access-rules.php',north.jar,{...rulePayload,csrf_token:northCsrf});check('B03_access_scope_actor_refusal',{status:aclDenied.status,unchanged:eq(aclAfter.hashes,(await cli('snapshot')).hashes)},{status:403,unchanged:true});
  aclForm=await request('/admin/access-rules.php',rootJar);const disable={action:'disable',id:rule.id,expected_version:version(aclForm.text),csrf_token:csrf(aclForm.text)};
  const aclFault=await request('/admin/access-rules.php',rootJar,disable,{'X-QA-Fault':'audit-log'});check('B03_access_audit_failure_atomic',{status:aclFault.status,unchanged:eq(aclAfter.hashes,(await cli('snapshot')).hashes)},{status:503,unchanged:true});
  const disabled=await request('/admin/access-rules.php',rootJar,disable),disabledSnapshot=await cli('snapshot');check('B03_access_disable_exact',{status:disabled.status,ruleStatus:disabledSnapshot.safe['access-rules'].items[0].status,actor:disabledSnapshot.safe['audit-log'].items[0].user,action:disabledSnapshot.safe['audit-log'].items[0].action},{status:302,ruleStatus:'disabled',actor:'batch-root',action:'access_rule.disable'});assertStage();check('group_B03_complete',true,true);
 }catch(e){rawFailure={stage,message:e.message};}
 finally{if(server){server.kill();await new Promise(r=>server.once('close',r));}}
 const controls=[];
 for(const name of ['prerequisite_B01_current_applicability','B02_password_identity','B02_token_rotation_contents','B07_audit_actor_fields','B07_audit_exact_truncation','B03_root_update_exact_target','B03_foreign_scope_valid_csrf','B03_access_audit_failure_atomic']){
  const copied=structuredClone(observations),row=copied.find(x=>x.test===name);if(row){row.actual={distorted:true};controls.push({name,rejected:evaluate(copied).some(x=>!x.passed)});}
 }
 check('semantic_content_distortions_rejected',controls.every(x=>x.rejected)&&controls.length===8,true,controls);
 check('all_participants_cache_free',runtime.every(e=>e.opcacheCli==='0'&&e.opcacheEnabled==='0'&&e.opcacheFileCache===''),true,runtime);
 const results=evaluate(observations),failed=results.filter(x=>!x.passed).length+(rawFailure?1:0);
 const primary={schemaVersion:1,runId:binding,status:failed?'FAIL':'PASS',checks:results.length,passed:results.filter(x=>x.passed).length,failed:results.filter(x=>!x.passed).length,results,rawFailure,observations,scope:'B02_B07_B03_ONLY; original B01 reused without native execution',runtimeDefectNotAssumed:!!rawFailure,sourceSha256:process.env.RENT_RK_AUDIT_SOURCE_SHA256};
 if(rawFailure){primary.results.push({test:'stage_completed_without_error',passed:false,actual:rawFailure,expected:null});primary.checks++;primary.failed++;}
 const report=path.join(out,'batch-primary.json');fs.writeFileSync(report,JSON.stringify(primary,null,2)+'\n');console.log(JSON.stringify({report,status:primary.status}));if(failed)process.exitCode=1;
}
