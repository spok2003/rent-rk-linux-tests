<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || !RENT_RK_AUDIT_ISOLATION_VERIFIED) {
    throw new RuntimeException('Verified CLI laboratory required.');
}
$root = realpath((string) getenv('RENT_RK_AUDIT_LAB_ROOT'));
if (!$root || realpath(__DIR__ . '/..') !== $root || !is_file($root . '/.rent-rk-test-lab')) {
    throw new RuntimeException('Laboratory location mismatch.');
}
$test = $argv[2] ?? '';
if (!in_array($test, ['', 'open-backup', 'open-output', 'flush-output', 'sync-output', 'rename-output', 'open-state', 'crash-prepared', 'crash-output', 'crash-committed', 'writer'], true)) {
    throw new RuntimeException('Fixed QA scenario required.');
}
require_once $root . '/admin/includes/bootstrap.php';
if ($test === 'writer') {
    RentalReturnStore::transaction(static function (): void {
        $settings = RentalReturnStore::read(SETTINGS_FILE, []);
        $settings['b24SyntheticWriter'] = 'preserved';
        RentalReturnStore::stage(SETTINGS_FILE, $settings);
    });
    echo json_encode(['writer' => true]);
    exit;
}
$hit = false;
$ordinal = 0;
$GLOBALS['rental_return_test_io_failure'] = static function (string $stage, string $file) use ($test, &$hit, &$ordinal): ?string {
    $wanted = ['open-backup' => 'open', 'open-output' => 'open', 'flush-output' => 'flush', 'sync-output' => 'fsync', 'rename-output' => 'rename', 'open-state' => 'open'];
    $target = $test === 'open-state' ? 'build-state.json' : 'index.html';
    // A single injected failure allows the real recovery path to restore bytes.
    if (isset($wanted[$test]) && $stage === $wanted[$test] && $file === $target) { $ordinal++; }
    $requiredOrdinal = in_array($test, ['open-backup', 'open-state'], true) ? 1 : 2;
    if (!$hit && isset($wanted[$test]) && $stage === $wanted[$test] && $file === $target && $ordinal === $requiredOrdinal) {
        $hit = true;
        file_put_contents($GLOBALS['b24QaMarker'], json_encode(['stage' => $stage, 'file' => $file, 'ordinal' => $ordinal, 'kind' => 'injected_not_os']));
        return 'EACCES';
    }
    return null;
};
$GLOBALS['b24QaMarker'] = $root . '/tmp/b24/io-marker.json';
$GLOBALS['rental_return_test_hook'] = static function (string $point) use ($test): void {
    $points = ['crash-prepared' => 'journal.prepared', 'crash-output' => 'write.after_rename.index.html', 'crash-committed' => 'journal.committed'];
    if (($points[$test] ?? '') === $point) {
        file_put_contents($GLOBALS['b24QaMarker'], json_encode(['point' => $point, 'kind' => 'process_exit_not_device_failure']));
        exit(73);
    }
};
require $root . '/tools/build-site-transaction.php';
