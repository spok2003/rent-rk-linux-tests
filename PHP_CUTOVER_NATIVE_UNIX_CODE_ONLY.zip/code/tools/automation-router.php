<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli-server' || !defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || !RENT_RK_AUDIT_ISOLATION_VERIFIED
    || ($_SERVER['REMOTE_ADDR'] ?? '') !== '127.0.0.1') { http_response_code(404); exit; }
$root = realpath((string) getenv('RENT_RK_AUDIT_LAB_ROOT'));
if (!$root || !is_file($root . '/.rent-rk-test-lab') || realpath(__DIR__ . '/..') !== $root) { http_response_code(404); exit; }
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if ($path === '/__qa_session') {
    require $root . '/admin/includes/bootstrap.php';
    require_once $root . '/admin/includes/approved-public-car-snapshot.php';
    $actor = $_GET['actor'] ?? '';
    if (!in_array($actor, ['qa-dry-root', 'qa-rate-editor', 'qa-car-publisher', 'qa-park-preview'], true)) { http_response_code(403); exit; }
    $_SESSION['admin_user'] = $actor;
    $slug = $_GET['car'] ?? 'synthetic-auto-car';
    if (!in_array($slug, ['synthetic-auto-car','synthetic-auto-second','synthetic-auto-third'], true)) { http_response_code(403); exit; }
    $service = ApprovedPublicCarSnapshots::fromServer();
    try { $candidate = $service->candidate($slug); } catch (Throwable $e) { $candidate = null; }
    $store = ApprovedPublicCarSnapshots::store();
    $row = ['csrf' => csrf_token(), 'ratesVersion' => rates_form_version('rent_rk'),
        'carVersion' => business_record_version(CARS_FILE, $slug, 'slug'),
        'rentVersion' => business_record_version(RENTALS_FILE, 'r-existing'),
        'reviewVersion' => $candidate['reviewVersion'] ?? null,
        'active' => $store['active'][$slug] ?? null, 'canPublish' => has_permission('cars.publish'),
        'canSingle' => has_permission('content.publish.single_page'), 'canEdit' => has_permission('cars.edit'),
        'settings' => has_permission('settings.manage'), 'global' => current_user_is_platform_admin(),
        'owns' => ($car = find_car($slug)) && car_belongs_to_current_scope($car),
        'inList' => in_array($slug, array_column(scope_cars_for_current_user(read_cars()), 'slug'), true),
        'scope' => current_user_data_scope_id(),
        'photoKey' => car_photo_key($slug, 'assets/img/cars/' . $slug . '/second.png'),
        'sapi' => PHP_SAPI, 'php' => PHP_VERSION, 'os' => PHP_OS_FAMILY, 'exec' => function_exists('exec'), 'cache' => ini_get('opcache.enable'),
        'fileCache' => ini_get('opcache.file_cache'), 'noUrl' => ini_get('allow_url_fopen') === '0'];
    if ($actor === 'qa-dry-root' && ($store['active'][$slug]['state'] ?? '') === 'approved') {
        $row['revokeVersion'] = ApprovedPublicCarSnapshots::revokeVersion($slug);
    }
    header('Content-Type: application/json');
    echo json_encode($row, JSON_THROW_ON_ERROR);
    exit;
}
if (in_array($path, ['/admin/public-car-approvals.php','/admin/rates.php','/admin/cars.php','/admin/car-edit.php',
    '/admin/rental-issue.php','/admin/access-rules.php','/api/request.php'], true)) {
    require $root . $path;
    exit;
}
if (preg_match('~\A/cars/[a-z0-9-]+\.html\z~D', (string) $path)
    && is_file($root . $path) && realpath($root . $path) === str_replace('/', DIRECTORY_SEPARATOR, $root . $path)) return false;
http_response_code(404);
