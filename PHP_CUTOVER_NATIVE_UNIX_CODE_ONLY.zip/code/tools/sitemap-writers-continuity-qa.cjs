'use strict';
const fs = require('fs'), path = require('path'), cp = require('child_process'), crypto = require('crypto');
const net = require('net');
const audit = require('./business-data-audit.cjs');
const root = path.resolve(__dirname, '..'), php = 'D:/OSPanel/modules/PHP-8.4/php.exe';
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const read = p => JSON.parse(fs.readFileSync(p));
const put = (p, v) => { fs.mkdirSync(path.dirname(p), {recursive: true}); fs.writeFileSync(p, JSON.stringify(v, null, 2) + '\n'); };
const sort = x => Array.isArray(x) ? x.map(sort) : x && typeof x === 'object' ? Object.fromEntries(Object.keys(x).sort().map(k => [k, sort(x[k])])) : x;
const canonical = x => JSON.stringify(sort(x));
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
async function main() {
  const series = process.argv[2];
  if (!series || !/^[a-z0-9-]+$/.test(series)) throw Error('Explicit fresh series required');
  const out = path.join(root, 'artifacts/sitemap-writers-plan-continuity-20261108', series);
  const free = fs.statfsSync('C:/');
  if (free.bavail * free.bsize < 6 * 1024 ** 3) throw Error('Insufficient C: space');
  fs.mkdirSync(out);
  const lab = audit.create('sitemap-continuity', {temporary: true});
  const at = p => path.join(lab.lab, p), data = at('tmp/default-data'), output = (p, x) => put(path.join(out,p), x);
  output('laboratory.json', {dir:lab.dir,lab:lab.lab,laboratoryId:lab.baseline.laboratoryId,sourceSha256:lab.baseline.sourceSha256});
  output('source-binding.json', lab.baseline.sourceHashes);
  fs.appendFileSync(at('guard/isolation.ini'), '\nopcache.enable=0\nopcache.enable_cli=0\nopcache.file_cache=\nopcache.file_cache_only=0\n');
  fs.appendFileSync(at('guard/prepend.php'), '\ndefine("RENT_RK_APPROVED_PUBLIC_SERVER_CONFIG", dirname(__DIR__, 2) . "/sitemap-continuity-context.php");\n');
  const inputs = audit.validateLaboratoryInputs(lab); output('inputs.json',inputs);
  if (inputs.status !== 'PASS_LABORATORY_INPUTS') throw Error('Lab inputs invalid');
  const slug = 'synthetic-approved-car', photo = 'assets/img/cars/' + slug + '/main.png';
  const car = {slug,name:'Synthetic Approved Vehicle',brand:'Synthetic',model:'Approved',year:2025,seats:5,price:4321,depositAmount:12345,
    class:'Sedan',drive:'front',bodyType:'sedan',fuelType:'petrol',equipment:[],active:true,adminStatus:'active',publicStatus:'published',
    isPublished:true,publishChannels:['rent_rk_public'],owner_type:'rent_rk',owner_scope_id:'rent_rk',image:'/'+photo,photos:[{id:'main',path:photo,sort:0}]};
  const users = {users:[{login:'qa-snapshot-root',role:'admin',active:true,name:'Synthetic Root',permissions:[],lessorSlug:''},
    {login:'qa-snapshot-viewer',role:'manager',active:true,name:'Synthetic Viewer',permissions:['cars.view','tariffs.view'],deniedPermissions:['cars.publish','cars.edit','settings.manage'],lessorSlug:''}]};
  for (const [p,x] of Object.entries({'current-cars':[car],rates:{cars:{[slug]:{manual:4321,base:4321,depositAmount:12345}}},
    'car-page-content':{version:1,items:{}},'admin-users':users,partners:{items:[]},lessors:{items:[]},'landing-page-drafts':{items:[]},
    'access-rules':{},settings:{},'callback-settings':{},'audit-log':{items:[]},'build-state':{version:1,outputs:{},dirty:[],conflicts:[],runs:[]}})) put(path.join(data,p+'.json'),x);
  put(path.join(data,'backups/synthetic/manifest.json'),{keep:'sentinel'});
  put(at('data/routes.json'),[]);
  fs.mkdirSync(path.dirname(at(photo)),{recursive:true});
  fs.writeFileSync(at(photo),Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl6XQAAAABJRU5ErkJggg==','base64'));
  fs.writeFileSync(at('index.html'),'SYNTHETIC HOME');
  fs.writeFileSync(at('cars/index.html'),'SYNTHETIC CATALOG');
  fs.writeFileSync(at('sitemap.xml'),'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>https://base-rent.ru/</loc></url><url><loc>https://base-rent.ru/cars/</loc></url><url><loc>https://base-rent.ru/cars/'+slug+'.html</loc></url></urlset>');
  const site = {baseUrl:'https://base-rent.ru',name:'Synthetic Rent RK',phone:'+70000000000',telegram:'https://t.me/synthetic',address:'Synthetic address',
    extraSitemapPaths:[],callback:{enabled:false,delaySeconds:60,repeatPolicy:'daily',texts:{title:'Synthetic',text:'Synthetic',button_text:'Send',success_text:'Saved'}}};
  const pair = crypto.generateKeyPairSync('ed25519');
  const pub = pair.publicKey.export({format:'der',type:'spki'}).subarray(-32);
  const secret = Buffer.concat([pair.privateKey.export({format:'der',type:'pkcs8'}).subarray(-32),pub]);
  const config = {issuer:'synthetic-owner',keyId:'synthetic-key',publicKeyBase64:pub.toString('base64'),secretKeyBase64:secret.toString('base64'),
    site,siteDecisionId:'synthetic-site',signatureLifetimeSeconds:3600,inventory:{decisionId:'synthetic-inventory',siteDigest:sha(canonical(site)),dependencies:{}}};
  secret.fill(0);
  const seal = () => {
    for (const [k,p] of Object.entries({routes:at('data/routes.json'),partners:path.join(data,'partners.json'),representatives:path.join(data,'admin-users.json'),demand:path.join(data,'landing-page-drafts.json')})) config.inventory.dependencies[k]=sha(fs.readFileSync(p));
    fs.writeFileSync(path.join(path.dirname(lab.lab),'sitemap-continuity-context.php'),'<?php return json_decode(base64_decode('+JSON.stringify(Buffer.from(JSON.stringify(config)).toString('base64'))+'),true,512,JSON_THROW_ON_ERROR);');
  };
  seal();
  const env = audit.env(lab.lab), args = (...a) => ['tools/sitemap-writers-continuity-qa.php',...a];
  const checks = [], environments = [];
  const check = (test, passed, detail = {}) => {
    checks.push({test,passed:!!passed,detail});
    output('primary.json',{status:passed?'IN_PROGRESS':'FAIL',sourceSha256:lab.baseline.sourceSha256,laboratoryId:lab.baseline.laboratoryId,results:checks,environments});
    if (!passed) throw Error(test);
  };
  function unpack(status, stdout) {
    let j = {}; try {j=JSON.parse(stdout);} catch {}
    if (j.environment) environments.push(j.environment);
    return {exit:status,...j};
  }
  const run = (...a) => {
    const r=cp.spawnSync(php,args(...a),{cwd:lab.lab,env,encoding:'utf8',timeout:30000,windowsHide:true,maxBuffer:2**20});
    return unpack(r.status,r.stdout);
  };


  const atData=n=>path.join(data,n+'.json'), putData=(n,x)=>put(atData(n),x);
  const nextSlug='synthetic-added-car', base='https://base-rent.ru';
  const existing=[base+'/',base+'/cars/',base+'/cars/'+slug+'.html',base+'/pages/synthetic.html',base+'/partner/synthetic-partner/'];
  const newCarUrl=base+'/cars/'+nextSlug+'.html', demandUrl='https://rent-rk.ru/landing.php?slug=synthetic-demand';
  const sitemap=at('sitemap.xml'), xml=urls=>'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+urls.map(u=>'<url><loc>'+u+'</loc></url>').join('')+'</urlset>';
  const locs=bytes=>[...bytes.toString().matchAll(/<loc>([^<]+)<\/loc>/g)].map(x=>x[1]).sort();
  const expected=xs=>[...xs].sort();
  fs.writeFileSync(sitemap,xml(existing));
  const originalSha=sha(fs.readFileSync(sitemap));
  fs.mkdirSync(at('pages'),{recursive:true});fs.writeFileSync(at('pages/synthetic.html'),'STATIC-SENTINEL');
  config.site.extraSitemapPaths=['/pages/synthetic.html'];config.inventory.siteDigest=sha(canonical(site));
  config.inventory.publicFiles={'pages/synthetic.html':sha(fs.readFileSync(at('pages/synthetic.html')))};
  putData('partners',{items:[{slug:'synthetic-partner',name:'Synthetic Partner',active:true}]});
  const draft={id:'d-main',scope_id:'rent_rk',slug:'synthetic-demand',title:'Synthetic Demand page',h1:'QA rental page in Yalta',
    metaDescription:'Synthetic reviewed local rental information',intro:'Synthetic reviewed information about car hire and contract conditions.',
    ctaText:'Ask about terms',contentBlocks:[{type:'conditions',visibility:'public',title:'Conditions',body:'Synthetic conditions and details.'}],
    linkedCars:[slug],internalLinks:[],riskFlags:[],publishStatus:'ready_for_index_review',indexStatus:'noindex',qualityStatus:'approved',readinessStatus:'ready'};
  putData('landing-page-drafts',{items:[draft]});putData('landing-page-versions',{items:[]});putData('seo-page-lifecycle',{items:[]});putData('analytics-events',{items:[]});
  seal();check('synthetic-bootstrap-ready',!!run('preview',slug).result);seal();
  check('initial-approved-car',run('approve',slug).result?.status==='APPROVED_NOT_PUBLISHED');
  check('known-initial-plan-anchors-original-bytes',run('plan',slug).result?.outputs?.find(o=>o.path==='sitemap.xml')?.beforeSha256===originalSha);
  const state=()=>read(atData('approved-public-car-snapshots')), chain=()=>state().sitemapContinuity||[];
  const auditRows=()=>read(atData('audit-log')).items;
  const publicPaths=['sitemap.xml','index.html','cars/index.html','cars/'+nextSlug+'.html','pages/synthetic.html','data/routes.json'];
  const snapshot=()=>{
    const files={};
    function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
      if(['.rental-store.lock','.rental-transactions','sessions'].includes(entry.name))continue;
      const full=path.join(dir,entry.name);if(entry.isSymbolicLink())throw Error('Linked fixture');if(entry.isDirectory())walk(full);
      else files[path.relative(lab.lab,full).replaceAll('\\','/')]=sha(fs.readFileSync(full));
    }}
    walk(data);for(const name of publicPaths)if(fs.existsSync(at(name)))files[name]=sha(fs.readFileSync(at(name)));
    return canonical(files);
  };
  const publicHashes=()=>Object.fromEntries(publicPaths.map(p=>[p,sha(fs.readFileSync(at(p)))]));
  const next={...car,slug:nextSlug,name:'Synthetic second approved car'};
  putData('current-cars',[car,next]);putData('rates',{cars:{[slug]:{manual:4321,base:4321,depositAmount:12345},[nextSlug]:{manual:2345,base:2345,depositAmount:8765}}});
  fs.writeFileSync(at('cars/'+nextSlug+'.html'),'<!doctype html><html><head><title>Before</title></head><body><p class="car-hero-price">old price</p></body></html>');
  check('second-car-approved-before-its-native-publication',run('approve',nextSlug).result?.status==='APPROVED_NOT_PUBLISHED');
  const prep=()=>run('prepare-option-c',nextSlug);
  const stale=prep();
  check('old-option-c-review-captures-exact-before-hash',stale.result?.immutable.outputs.find(o=>o.path==='sitemap.xml')?.beforeHash===originalSha,{error:stale.error});
  const fields=action=>run('fields',action).result;
  const encoded=obj=>Buffer.from(JSON.stringify(obj)).toString('base64');
  const demand=(action,mode='demand',payload=fields(action))=>run(mode,action,encoded(payload));
  const dstate=()=>read(atData('landing-page-drafts')).items.find(x=>x.id==='d-main').publishStatus;
  fs.writeFileSync(at('tmp/sitemap-router.php'),`<?php
if (!defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || !RENT_RK_AUDIT_ISOLATION_VERIFIED) throw new RuntimeException('Synthetic router only');
define('ADMIN_USER','qa-snapshot-root'); require __DIR__ . '/../admin/includes/bootstrap.php';
$_SESSION['admin_user'] = ($_SERVER['HTTP_X_QA_VIEWER'] ?? '') === '1' ? 'qa-snapshot-viewer' : 'qa-snapshot-root';
if (parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH) === '/qa/environment') {
 echo json_encode(['csrf'=>csrf_token(),'authenticated'=>is_admin_logged_in(),'canPublish'=>has_permission('cars.publish'),
 'cache'=>ini_get('opcache.enable'),'fileCache'=>ini_get('opcache.file_cache'),'sapi'=>PHP_SAPI]); return true;
}
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
if (in_array($path, ['/admin/public-car-approvals.php','/admin/car-edit.php','/admin/demand.php'], true)) {
 require __DIR__ . '/..' . $path; return true;
}
http_response_code(404); return true;`);
  const port=await new Promise(resolve=>{const sock=net.createServer();sock.listen(0,'127.0.0.1',()=>{const n=sock.address().port;sock.close(()=>resolve(n));});});
  const server=cp.spawn(php,['-S','127.0.0.1:'+port,'-t',lab.lab,at('tmp/sitemap-router.php')],{cwd:lab.lab,env,windowsHide:true,stdio:'ignore'});
  const serverClosed=new Promise(resolve=>server.on('close',resolve));
  const url='http://127.0.0.1:'+port, route=url+'/admin/public-car-approvals.php?slug='+slug;
  const request=(u,o={})=>fetch(u,{redirect:'manual',signal:AbortSignal.timeout(25000),...o});
  try {
    let response;
    for(let attempt=0;attempt<50&&!response;attempt++){try{response=await request(url+'/qa/environment');}catch{await delay(100);}}
    const {csrf,...httpEnv}=await response.json(), cookie=response.headers.get('set-cookie').split(';')[0];
    const viewer=await request(url+'/qa/environment',{headers:{'X-QA-Viewer':'1'}});
    const {csrf:viewerCsrf,...viewerEnv}=await viewer.json(), viewerCookie=viewer.headers.get('set-cookie').split(';')[0];
    check('native-http-actors-and-cache-boundary',httpEnv.authenticated&&httpEnv.canPublish&&viewerEnv.authenticated&&!viewerEnv.canPublish&&httpEnv.sapi==='cli-server'&&httpEnv.cache==='0'&&httpEnv.fileCache==='',{httpEnv,viewerEnv});



    const post=(u,body)=>request(u,{method:'POST',headers:{cookie},body:new URLSearchParams({...body,csrf_token:csrf})});
    const demandRoute=url+'/admin/demand.php?tab=drafts&scope=rent_rk';
    const optionRoute=url+'/admin/car-edit.php?id='+nextSlug;
    const apply=record=>post(optionRoute,{id:nextSlug,action:'guarded_publish_apply',publication_plan_id:record.id,publication_plan_digest:record.digest,confirm_publication_plan:'1'});
    const indexResponse=await post(demandRoute,{action:'workflow_publish_indexed',...fields('workflow_publish_indexed')});
    await indexResponse.text();
    check('native-demand-post-commits-authorized-url-only',dstate()==='published_indexed'&&chain().length===1&&canonical(locs(fs.readFileSync(sitemap)))===canonical(expected([...existing,demandUrl])),
      {http:indexResponse.status,writer:chain()[0]?.payload.writer});
    const beforeStale=snapshot(), rejected=await apply(stale.result);await rejected.text();
    const durable=()=>read(atData('car-publication-plans'));
    check('native-option-c-stale-plan-not-rewritten',rejected.status===409&&beforeStale===snapshot()&&canonical(durable().items[stale.result.id].immutable)===canonical(stale.result.immutable),{http:rejected.status});
    const fresh=prep();
    check('fresh-option-c-review-uses-new-demand-sitemap',fresh.result?.immutable.outputs.find(o=>o.path==='sitemap.xml')?.beforeHash===sha(fs.readFileSync(sitemap)),{error:fresh.error});
    const option=await apply(fresh.result);await option.text();
    check('native-option-c-applies-reviewed-bytes-and-keeps-demand-partner',option.status===200&&chain().length===2&&chain()[1].payload.writer==='option_c'&&
      fresh.result.immutable.outputs.every(o=>sha(fs.readFileSync(at(o.path)))===o.afterHash)&&canonical(locs(fs.readFileSync(sitemap)))===canonical(expected([...existing,demandUrl,newCarUrl])),{http:option.status});
    const beforeReplay=snapshot(), replay=await apply(fresh.result);await replay.text();
    check('native-option-c-replay-no-duplicate-transition',replay.status===200&&snapshot()===beforeReplay&&chain().length===2);
    const close=await post(demandRoute,{action:'workflow_close_index',...fields('workflow_close_index')});await close.text();
    check('third-native-write-before-next-plan-removes-only-demand',dstate()==='published_noindex'&&chain().length===3&&canonical(locs(fs.readFileSync(sitemap)))===canonical(expected([...existing,newCarUrl])),{http:close.status});
    const beforePlan=publicHashes(), planned=await post(route,{slug,action:'plan'}), planBody=await planned.text();
    check('ordinary-native-plan-adopts-three-commits-no-public-write',planned.status===200&&planBody.includes('PLAN_ONLY')&&canonical(publicHashes())===canonical(beforePlan),{http:planned.status,before:beforePlan['sitemap.xml']});
  } finally { server.kill(); await serverClosed; }
  const firstThree=chain(), currentSitemap=fs.readFileSync(sitemap), beforePlan=publicHashes(), planned=run('plan',slug).result;
  const proposed=planned?.outputs?.find(o=>o.path==='sitemap.xml');
  check('plan-pins-exact-current-before-and-preserves-non-target-urls',planned?.status==='PLAN_ONLY'&&planned.canApply===false&&
    proposed.beforeSha256===sha(currentSitemap)&&canonical(locs(Buffer.from(proposed.payloadBase64,'base64')))===canonical(expected([...existing,newCarUrl]))&&canonical(publicHashes())===canonical(beforePlan));
  check('advance-to-index-review-without-sitemap-write',demand('workflow_request_index').result?.publishStatus==='ready_for_index_review'&&chain().length===3);
  fs.writeFileSync(sitemap,Buffer.concat([currentSitemap,Buffer.from('\n')]));
  const forged=snapshot(), badPlan=run('plan',slug).result, badWrite=demand('workflow_publish_indexed');
  check('unknown-before-blocks-native-writer-and-plan',badPlan?.status==='BLOCKED_DYNAMIC_INVENTORY_SITEMAP_BASELINE_CHANGED'&&badWrite.error==='BLOCKED_SITEMAP_CONTINUITY_UNTRUSTED_BEFORE'&&snapshot()===forged);
  fs.writeFileSync(sitemap,currentSitemap);
  const fieldsCrash=fields('workflow_publish_indexed'), beforeCrash=snapshot();
  check('prepared-crash-reaches-real-sitemap-replacement',demand('workflow_publish_indexed','crash-prepared',fieldsCrash).exit===73);
  check('prepared-recovery-restores-state-receipts-and-public-exactly',run('inspect').exit===0&&snapshot()===beforeCrash&&chain().length===3);
  check('committed-crash-before-native-response',demand('workflow_publish_indexed','crash-committed',fieldsCrash).exit===74);
  check('committed-recovery-keeps-exact-receipt-and-source',run('inspect').exit===0&&chain().length===4&&dstate()==='published_indexed'&&
    chain()[3].payload.after.beforeSha256===sha(fs.readFileSync(sitemap))&&canonical(locs(fs.readFileSync(sitemap)))===canonical(expected([...existing,newCarUrl,demandUrl])));
  const replayState=snapshot();
  check('durable-command-replay-does-not-repeat-transition',demand('workflow_publish_indexed','demand',fieldsCrash).result?.publishStatus==='published_indexed'&&snapshot()===replayState);
  const old=sha(fs.readFileSync(sitemap)), closeFields=fields('workflow_close_index');
  const workers=[['race-plan',slug],['race-demand','workflow_close_index',encoded(closeFields)]].map(a=>new Promise((resolve,reject)=>{
    const proc=cp.spawn(php,args(...a),{cwd:lab.lab,env,windowsHide:true});let stdout='';
    proc.stdout.on('data',d=>stdout+=d);proc.stderr.resume();proc.on('error',reject);proc.on('close',code=>resolve(unpack(code,stdout)));
  }));
  const ready=()=>['race-plan','race-demand'].every(x=>fs.existsSync(at('tmp/sitemap-ready-'+x))), deadline=Date.now()+10000;
  while(!ready()&&Date.now()<deadline)await delay(30);
  const both=ready();fs.writeFileSync(at('tmp/sitemap-go'),'go');
  const [pRace,dRace]=await Promise.all(workers);
  const afterRace=sha(fs.readFileSync(sitemap)), observed=pRace.result?.outputs?.find(o=>o.path==='sitemap.xml');
  const coherent=observed&&((observed.beforeSha256===old&&locs(Buffer.from(observed.payloadBase64,'base64')).includes(demandUrl))||
    (observed.beforeSha256===afterRace&&!locs(Buffer.from(observed.payloadBase64,'base64')).includes(demandUrl)));
  check('independent-planner-and-native-writer-observe-coherent-generation',both&&coherent&&dRace.result?.publishStatus==='published_noindex'&&chain().length===5,{old,afterRace,observed:observed?.beforeSha256});
  const finalPublic=publicHashes(), finalPlan=run('plan',slug).result, finalOutput=finalPlan?.outputs?.find(o=>o.path==='sitemap.xml');
  check('latest-after-recovery-cannot-restore-withdrawn-demand',finalPlan?.status==='PLAN_ONLY'&&finalPlan.canApply===false&&finalOutput?.beforeSha256===afterRace&&
    canonical(locs(Buffer.from(finalOutput.payloadBase64,'base64')))===canonical(expected([...existing,newCarUrl]))&&canonical(publicHashes())===canonical(finalPublic));
  const signed=chain();
  check('each-native-transition-signature-and-link-independently-verified',signed.every((e,i)=>e.payload.previousSha256===(i?sha(canonical(signed[i-1])):null)&&
    e.payload.before.beforeSha256===(i?signed[i-1].payload.after.beforeSha256:originalSha)&&crypto.verify(null,Buffer.from('RentRK native sitemap transition v1\0'+canonical(e.payload)),pair.publicKey,Buffer.from(e.signature,'base64')))&&
    canonical(signed.slice(0,3))===canonical(firstThree)&&auditRows().filter(x=>x.action==='public_inventory.sitemap_transition').length===5);
  const bytes=fs.readFileSync(sitemap), beforeTamper=fs.readFileSync(atData('approved-public-car-snapshots')), bad=state();
  bad.sitemapContinuity[1].signature=Buffer.alloc(64).toString('base64');putData('approved-public-car-snapshots',bad);
  const broken=snapshot();
  check('damaged-intermediate-transition-blocks-without-state-writes',run('plan',slug).result?.status==='BLOCKED_SITEMAP_CONTINUITY_SIGNATURE'&&snapshot()===broken);
  fs.writeFileSync(atData('approved-public-car-snapshots'),beforeTamper);
  fs.writeFileSync(sitemap,Buffer.concat([bytes,Buffer.from('\n')]));
  check('post-commit-file-tamper-refused',run('plan',slug).result?.status==='BLOCKED_DYNAMIC_INVENTORY_SITEMAP_BASELINE_CHANGED');
  fs.writeFileSync(sitemap,bytes);
  output('continuity-history.json',{synthetic:true,initialBeforeSha256:originalSha,finalBeforeSha256:afterRace,transitions:signed,
    publicKeyBase64:config.publicKeyBase64,inventory:state().dynamicInventory,finalLocs:locs(bytes)});
  check('cache-disabled',environments.length>=10&&environments.every(e=>e.sapi==='cli'&&e.cache==='0'&&e.cliCache==='0'&&e.fileCache===''));
  output('primary.json',{status:'PASS_COMPONENT_ONLY',sourceSha256:lab.baseline.sourceSha256,laboratoryId:lab.baseline.laboratoryId,results:checks,environments});
  console.log(JSON.stringify({status:'PASS_COMPONENT_ONLY',checks:checks.length,lab:lab.dir}));
}
main().catch(e=>{console.error(e.message);process.exitCode=1;});
