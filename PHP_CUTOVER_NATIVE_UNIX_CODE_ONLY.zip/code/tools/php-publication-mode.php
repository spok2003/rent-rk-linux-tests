<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || RENT_RK_AUDIT_ISOLATION_VERIFIED !== true
    || !defined('RENT_RK_PHP_PUBLICATION_CUTOVER') || RENT_RK_PHP_PUBLICATION_CUTOVER !== true) exit(2);
require __DIR__ . '/../admin/includes/bootstrap.php';
try {
    if (($argv[1] ?? '') === 'status') {
        echo json_encode(PhpPublicationCutover::inspect(), JSON_THROW_ON_ERROR), PHP_EOL;
        exit;
    }
    if (!in_array($argv[1] ?? '', ['running', 'paused'], true) || !ctype_digit($argv[2] ?? '')) {
        throw new RuntimeException('BLOCKED_PHP_CUTOVER_CONTROL', 409);
    }
    echo json_encode(PhpPublicationCutover::change($argv[1], (int) $argv[2]), JSON_THROW_ON_ERROR), PHP_EOL;
} catch (Throwable $e) {
    fwrite(STDERR, preg_match('/\ABLOCKED_[A-Z0-9_]+\z/D', $e->getMessage()) ? $e->getMessage() . PHP_EOL : "Cutover control failed.\n");
    exit(1);
}
