'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const {primaryReportContracts} = require('./business-data-audit.cjs');

const projectRoot = path.resolve(__dirname, '..');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const policy = require('./business-data-review-policy.json');
const profiles = policy.profiles;
const exactContracts = policy.contracts;

function readPolicy(root) {
  const file = path.join(root, 'tools/business-data-review-policy.json');
  return {file, value: JSON.parse(fs.readFileSync(file, 'utf8'))};
}

function validateExactSourceBindings(root = projectRoot) {
  const resolvedRoot = path.resolve(root);
  let loaded;
  try {
    loaded = readPolicy(resolvedRoot);
  } catch (error) {
    return {schemaVersion: 1, status: 'BLOCKED_EXACT_SOURCE_BINDINGS', root: resolvedRoot,
      policy: 'tools/business-data-review-policy.json', bindings: [],
      failure: 'POLICY_UNREADABLE', error: error.message};
  }
  const currentPolicy = loaded.value;
  const bindings = [];
  for (const contract of currentPolicy.contracts || []) {
    if (!['REVIEWED_SUBSET', 'REVIEWED_SHARED_WRITER_ENVELOPE', 'REVIEWED_COMPONENT_EVIDENCE'].includes(contract.reviewStatus)) continue;
    const relative = typeof contract.file === 'string' ? contract.file.replace(/\\/g, '/') : '';
    const target = path.resolve(resolvedRoot, relative);
    const insideRoot = relative !== '' && target.startsWith(resolvedRoot + path.sep);
    const reviewEntryValid = typeof contract.id === 'string' && contract.id !== ''
      && typeof contract.profile === 'string' && !!currentPolicy.profiles?.[contract.profile]
      && typeof contract.reviewReason === 'string' && contract.reviewReason !== ''
      && contract.expected && Object.keys(contract.expected).length > 0
      && Array.isArray(contract.dependencyFiles) && contract.dependencyFiles.length > 0
      && (contract.reviewStatus !== 'REVIEWED_SHARED_WRITER_ENVELOPE'
        || (typeof contract.conditionalAdmission?.helper === 'string'
          && Number.isInteger(contract.conditionalAdmission?.expectedCurrentCallerCount)
          && contract.conditionalAdmission.expectedCurrentCallerCount > 0
          && contract.conditionalAdmission.requiredBoundaryCounts
          && typeof contract.conditionalAdmission.requiredBoundaryCounts === 'object'))
      && (contract.reviewStatus !== 'REVIEWED_COMPONENT_EVIDENCE'
        || (typeof contract.conditionalAdmission?.componentId === 'string'
          && contract.conditionalAdmission.componentId !== ''
          && Array.isArray(contract.conditionalAdmission.requiredChecks)
          && contract.conditionalAdmission.requiredChecks.length > 0
          && contract.conditionalAdmission.requiredChecks.every(value => typeof value === 'string' && value !== '')
          && contract.conditionalAdmission.requiredDependencySha256
          && typeof contract.conditionalAdmission.requiredDependencySha256 === 'object'
          && Object.values(contract.conditionalAdmission.requiredDependencySha256)
            .every(value => /^[a-f0-9]{64}$/.test(value))))
      && /^[a-f0-9]{64}$/.test(contract.sourceSha256 || '');
    let actual = null;
    let outcome = 'UNVERIFIABLE';
    if (!insideRoot) {
      outcome = 'UNVERIFIABLE_PATH';
    } else if (!fs.existsSync(target) || !fs.statSync(target).isFile()) {
      outcome = 'MISSING_SOURCE';
    } else {
      actual = sha(fs.readFileSync(target));
      outcome = reviewEntryValid && actual === contract.sourceSha256 ? 'PASS' : (reviewEntryValid ? 'STALE_SOURCE' : 'REVIEW_ENTRY_INVALID');
    }
    bindings.push({contractId: contract.id || null, path: relative || null,
      expected: contract.sourceSha256 || null, actual, reviewEntryValid, outcome});
  }
  const failed = bindings.filter(binding => binding.outcome !== 'PASS');
  return {schemaVersion: 1, status: failed.length ? 'BLOCKED_EXACT_SOURCE_BINDINGS' : 'PASS_EXACT_SOURCE_BINDINGS',
    root: resolvedRoot, policy: path.relative(resolvedRoot, loaded.file).replace(/\\/g, '/'), bindings,
    checkedBindingCount: bindings.length, failedBindingCount: failed.length, failures: failed};
}

function lineText(root, file, line) {
  const lines = fs.readFileSync(path.join(root, file), 'utf8').split(/\r?\n/);
  return lines[line - 1] || '';
}
function base(site, coverage, reason, route) {
  return {...site, coverage, reason, route,
    permissionsAndScope: coverage === 'NOT_APPLICABLE' ? 'No production business-data authority.' : 'BLOCKED: trace live actor, permission and scope from the real entrypoint.',
    allowedFields: coverage === 'NOT_APPLICABLE' ? 'No production business fields.' : (site.storeConstants.length ? site.storeConstants.join(', ') : 'Dynamic target/fields require review.'),
    preconditions: coverage === 'NOT_APPLICABLE' ? 'Explicit technical/local invocation only.' : 'BLOCKED: entrypoint preconditions require review.',
    lockAndCommit: coverage === 'NOT_APPLICABLE' ? 'Outside a production business commit path.' : 'BLOCKED: lock ownership, commit and recovery require review.',
    idempotencyAndStaleState: coverage === 'NOT_APPLICABLE' ? 'Not a production business command.' : 'BLOCKED: retry and stale-state behavior require review.',
    sideEffects: coverage === 'NOT_APPLICABLE' ? `${site.sink}; limited to the stated technical surface.` : `${site.sink}; callers and related writes remain unresolved.`, evidence: []};
}
function pass(site, contract) {
  return {...site, coverage: 'PASS', contractId: contract.id, reason: `Current executable component evidence covers exact contract ${contract.id}.`, ...profiles[contract.profile]};
}
function na(site, reason, route, proof) { return {...base(site, 'NOT_APPLICABLE', reason, route), notApplicableProof: proof}; }
function blocked(site, reason = 'Potential runtime or operational business writer requires individual route-to-invariant review.') {
  return base(site, 'BLOCKED', reason, site.file.startsWith('tools/') ? `Operational CLI candidate: ${site.file}` : `Application candidate: ${site.file}`);
}

function primaryReportContract(result) {
  const byScript = primaryReportContracts[result?.script];
  const matches = Object.entries(primaryReportContracts).filter(([, contract]) => contract.componentId === result?.id);
  if (matches.length > 1) return {invalid: true};
  const byComponent = matches.length === 1 ? {script: matches[0][0], ...matches[0][1]} : null;
  if (byComponent && result?.script !== byComponent.script) return {invalid: true};
  if (byScript && byScript.componentId !== result?.id) return {invalid: true};
  return byComponent || (byScript ? {script: result.script, ...byScript} : null);
}
function primaryReportFailed(result, root, sourceSha256, contract = primaryReportContract(result)) {
  if (contract?.invalid) return true;
  const receipt = result?.primaryReport;
  if (contract && (!receipt || typeof receipt !== 'object' || Array.isArray(receipt))) return true;
  if (!receipt) return false;
  if (receipt.status !== 'VALID' || receipt.componentId !== result.id || receipt.script !== result.script
    || receipt.sourceSha256 !== sourceSha256 || receipt.entrySha256 !== result.entrySha256
    || !receipt.path || !receipt.laboratoryId || !receipt.runBinding
    || receipt.checkCount !== result.checks?.length) return true;
  const normalizedPath = String(receipt.path).replace(/\\/g, '/');
  const contractPath = contract?.relativePath instanceof RegExp ? normalizedPath.match(contract.relativePath) : null;
  if (contract && (!contractPath || contract.componentId !== result.id || contract.script !== result.script)) return true;
  const full = path.resolve(root, receipt.path), relative = path.relative(root, full);
  if (relative === '' || relative === '..' || relative.startsWith('..' + path.sep) || path.isAbsolute(relative)) return true;
  try {
    if (!fs.lstatSync(full).isFile() || fs.lstatSync(full).isSymbolicLink()) return true;
    const bytes = fs.readFileSync(fs.realpathSync(full));
    if (sha(bytes) !== receipt.sha256) return true;
    const primary = JSON.parse(bytes);
    if (contractPath?.[1] && primary?.runId !== contractPath[1]) return true;
    const normalized = Array.isArray(primary.results)
      ? primary.results.map(row => ({id: row?.test, passed: row?.passed})) : null;
    if (!normalized || sha(JSON.stringify(normalized)) !== receipt.normalizedChecksSha256
      || sha(JSON.stringify(result.checks)) !== receipt.normalizedChecksSha256) return true;
  } catch { return true; }
  return false;
}
function gateResultFailed(result, root = null, sourceSha256 = null) {
  const primaryContract = primaryReportContract(result);
  return !result || result.exitCode !== 0 || result.failure || result.failureCount > 0
    || result.passed === false || result.signal || result.errorCode
    || /FAIL|BLOCKED/i.test(result.reportedStatus || '')
    || result.checks?.some(check => check.passed !== true)
    || (root && (primaryContract || result.primaryReport) && primaryReportFailed(result, root, sourceSha256, primaryContract));
}

function validateGateSeriesBinding(root, gate, gateFile, sourceSha256, laboratoryId) {
  const issues = [];
  if (!gate || gate.sourceSha256 !== sourceSha256) issues.push('GATE_SOURCE_VERSION_MISMATCH');
  if (!laboratoryId || gate?.laboratoryId !== laboratoryId) issues.push('GATE_LABORATORY_MISMATCH');
  if (!/^[a-f0-9]{32}$/.test(gate?.seriesBinding || '')) issues.push('GATE_SERIES_BINDING_INVALID');
  try {
    const laboratoryDir = path.dirname(path.dirname(fs.realpathSync(root)));
    if (path.basename(laboratoryDir) !== laboratoryId || path.dirname(fs.realpathSync(gateFile)) !== laboratoryDir) {
      issues.push('GATE_FILE_LABORATORY_BOUNDARY_MISMATCH');
    }
  } catch { issues.push('GATE_FILE_LABORATORY_BOUNDARY_MISMATCH'); }
  for (const result of gate?.results || []) {
    if (result.sourceSha256 !== sourceSha256) issues.push(`GATE_RESULT_SOURCE_MISMATCH:${result.id}`);
    if (result.laboratoryId !== laboratoryId) issues.push(`GATE_RESULT_LABORATORY_MISMATCH:${result.id}`);
    if (result.seriesBinding !== gate.seriesBinding) issues.push(`GATE_RESULT_SERIES_MISMATCH:${result.id}`);
    if (!/^[a-f0-9]{32}$/.test(result.runBinding || '')) issues.push(`GATE_RESULT_RUN_BINDING_INVALID:${result.id}`);
    if (result.primaryReport && result.primaryReport.runBinding !== result.runBinding) issues.push(`PRIMARY_REPORT_RUN_BINDING_MISMATCH:${result.id}`);
    if (result.primaryReport && result.primaryReport.laboratoryId !== laboratoryId) issues.push(`PRIMARY_REPORT_LABORATORY_MISMATCH:${result.id}`);
  }
  return {valid: issues.length === 0, laboratoryId: laboratoryId || null,
    seriesBinding: gate?.seriesBinding || null, gateFile: gateFile || null, issues};
}

function componentEvidenceComplete(root, gate, condition, gateBinding, sourceSha256) {
  const issues = [];
  if (!gateBinding?.valid) issues.push(...(gateBinding?.issues || ['GATE_SERIES_BINDING_INVALID']));
  const matches = (gate?.results || []).filter(result => result.id === condition?.componentId);
  if (matches.length !== 1) issues.push('COMPONENT_RESULT_NOT_UNIQUE');
  const result = matches.length === 1 ? matches[0] : null;
  if (!result || gateResultFailed(result, root, sourceSha256)) issues.push('COMPONENT_RESULT_OR_PRIMARY_INVALID');
  const passedChecks = new Set((result?.checks || []).filter(check => check.passed === true).map(check => check.id));
  for (const check of condition?.requiredChecks || []) {
    if (!passedChecks.has(check)) issues.push(`REQUIRED_CHECK_MISSING:${check}`);
  }
  const dependencyHashes = {};
  for (const [file, expected] of Object.entries(condition?.requiredDependencySha256 || {})) {
    const full = path.join(root, file);
    const actual = fs.existsSync(full) && fs.statSync(full).isFile() ? sha(fs.readFileSync(full)) : null;
    dependencyHashes[file] = actual;
    if (actual !== expected) issues.push(`DEPENDENCY_SHA_MISMATCH:${file}`);
  }
  return {valid: issues.length === 0, componentId: condition?.componentId || null,
    requiredChecks: condition?.requiredChecks || [], dependencyHashes, issues};
}

function sharedWriterEnvelopeComplete(review, condition, gateBinding) {
  const issues = [];
  if (review?.status !== 'PASS_SHARED_WRITER_CURRENT_REVIEW' || review?.mappingValid !== true
    || review?.gapCurrentCallerCount !== 0 || review?.safeRefusalValid !== true) issues.push('SHARED_WRITER_REVIEW_INCOMPLETE');
  if (!gateBinding?.valid) issues.push(...(gateBinding?.issues || ['GATE_SERIES_BINDING_INVALID']));
  const accepted = (review?.acceptedCurrentCalls || []).filter(row => row.helper === condition?.helper);
  const gaps = (review?.gapCurrentCalls || []).filter(row => row.helper === condition?.helper);
  if (accepted.length !== condition?.expectedCurrentCallerCount || gaps.length !== 0) issues.push('HELPER_CALLER_SET_INCOMPLETE');
  const actualCounts = accepted.reduce((counts, row) => {
    const key = row.acceptedBoundaryStatus || 'MISSING';
    counts[key] = (counts[key] || 0) + 1;
    return counts;
  }, {});
  const expectedCounts = condition?.requiredBoundaryCounts || {};
  if (JSON.stringify(Object.entries(actualCounts).sort()) !== JSON.stringify(Object.entries(expectedCounts).sort())) {
    issues.push('HELPER_EVIDENCE_BOUNDARY_COUNTS_MISMATCH');
  }
  if (accepted.some(row => !row.evidenceReceipt || row.issues?.length)) issues.push('HELPER_CALLER_EVIDENCE_INVALID');
  return {status: issues.length ? 'BLOCKED_SHARED_WRITER_ENVELOPE' : 'PASS_SHARED_WRITER_ENVELOPE',
    valid: issues.length === 0, helper: condition?.helper || null,
    expectedCurrentCallerCount: condition?.expectedCurrentCallerCount ?? null,
    acceptedCurrentCallerCount: accepted.length, boundaryCounts: actualCounts,
    gateLaboratoryId: gateBinding?.laboratoryId || null, gateSeriesBinding: gateBinding?.seriesBinding || null, issues};
}

function validateSharedWriterReview(discovery, root, gate, sourceSha256, gateFile = null, shared = policy.sharedWriterReview, laboratoryId = null) {
  if (!shared) return {status: 'NOT_CONFIGURED', mappingValid: false, acceptedCurrentCalls: [], gapCurrentCalls: [], errors: ['SHARED_WRITER_POLICY_MISSING']};
  const errors = [], observed = (discovery.calls || []).filter(call => shared.helpers.includes(call.callee));
  const excludedKeys = new Set((shared.excludedCalls || []).map(spec => spec.key));
  const actual = observed.filter(call => !excludedKeys.has([call.callee, call.file, call.line, call.function].join('|')));
  const byIdentity = new Map();
  for (const call of observed) {
    const key = [call.callee, call.file, call.line, call.function].join('|');
    if (byIdentity.has(key)) errors.push('DUPLICATE_CURRENT_CALL:' + key);
    byIdentity.set(key, call);
  }
  const policyKeys = new Set(), acceptedCurrentCalls = [], gapCurrentCalls = [];
  const gateReceipt = gateFile && fs.existsSync(gateFile) ? {path: path.relative(root, gateFile).replace(/\\/g, '/'), sha256: sha(fs.readFileSync(gateFile))} : null;
  const preservationOk = gate && gate.preservation && gate.preservation.canonicalUnchanged === true
    && gate.preservation.laboratorySourceUnchanged === true && gate.preservation.canonicalArtifactsUnchanged !== false;
  for (const spec of shared.currentCalls || []) {
    if (policyKeys.has(spec.key)) errors.push('DUPLICATE_POLICY_CALL:' + spec.key);
    policyKeys.add(spec.key);
    const call = byIdentity.get(spec.key), issues = [];
    if (!call) issues.push('CURRENT_CALL_MISSING');
    const target = path.join(root, spec.file);
    if (!fs.existsSync(target)) issues.push('CURRENT_SOURCE_MISSING');
    else {
      const bytes = fs.readFileSync(target), text = bytes.toString('utf8').split(/\r?\n/)[spec.line - 1] || '';
      if (sha(bytes) !== spec.sourceSha256 || discovery.sourceHashes?.[spec.file] !== spec.sourceSha256) issues.push('CURRENT_SOURCE_SHA_MISMATCH');
      if (sha(text) !== spec.lineSha256 || sha(text.trim()) !== spec.normalizedLineSha256) issues.push('CURRENT_CALL_LINE_OR_ARGUMENT_MISMATCH');
    }
    if (!Array.isArray(spec.requiredEvidence) || spec.requiredEvidence.length === 0) issues.push('PRIMARY_CHECK_EVIDENCE_NOT_DECLARED');
    if (!gateReceipt) issues.push('PRIMARY_GATE_RECEIPT_MISSING');
    if (!gate || gate.sourceSha256 !== sourceSha256) issues.push('GATE_SOURCE_VERSION_MISMATCH');
    if (!preservationOk) issues.push('GATE_PRESERVATION_NOT_PROVEN');
    for (const proof of spec.requiredEvidence || []) {
      const result = gate?.results?.find(row => row.id === proof.component);
      if (gateResultFailed(result, root, sourceSha256)) issues.push(`EVIDENCE_COMPONENT_FAILED:${proof.component}`);
      else {
        const script = path.join(root, result.script || '');
        if (result.sourceSha256 !== sourceSha256) issues.push(`EVIDENCE_SOURCE_MISMATCH:${proof.component}`);
        if (!fs.existsSync(script) || sha(fs.readFileSync(script)) !== result.entrySha256) issues.push(`EVIDENCE_ENTRY_SHA_MISMATCH:${proof.component}`);
        if (!result.checks?.some(check => check.id === proof.check && check.passed === true)) issues.push(`EVIDENCE_CHECK_MISSING:${proof.component}:${proof.check}`);
      }
    }
    const row = {...spec, currentCallObserved: Boolean(call), evidenceReceipt: gateReceipt, issues};
    (issues.length ? gapCurrentCalls : acceptedCurrentCalls).push(row);
  }
  for (const key of byIdentity.keys()) if (!policyKeys.has(key) && !excludedKeys.has(key)) errors.push('UNDECLARED_CURRENT_CALL:' + key);
  if (actual.length !== shared.currentCallerCount) errors.push(`CURRENT_CALLER_COUNT_MISMATCH:${actual.length}:${shared.currentCallerCount}`);
  const safeRefusals = [];
  for (const spec of shared.removedSafeRefusals || []) {
    const issues = [];
    if (actual.some(call => call.function === 'mark_rental_task' && call.callee === spec.helper)) issues.push('DISABLED_CALL_REAPPEARED');
    if (!gateReceipt || !preservationOk || gate?.sourceSha256 !== sourceSha256) issues.push('SAFE_REFUSAL_GATE_UNBOUND');
    for (const proof of spec.requiredEvidence || []) {
      const result = gate?.results?.find(row => row.id === proof.component);
      if (gateResultFailed(result, root, sourceSha256) || result?.sourceSha256 !== sourceSha256 || !result?.checks?.some(check => check.id === proof.check && check.passed === true)) {
        issues.push(`SAFE_REFUSAL_EVIDENCE_MISSING:${proof.component}:${proof.check}`);
      }
    }
    safeRefusals.push({...spec, evidenceReceipt: gateReceipt, issues});
  }
  const excludedCalls = [];
  for (const spec of shared.excludedCalls || []) {
    const issues = [], call = byIdentity.get(spec.key);
    if (!call) issues.push('EXCLUDED_CALL_MISSING');
    const target = path.join(root, spec.file);
    if (!fs.existsSync(target)) issues.push('EXCLUDED_SOURCE_MISSING');
    else {
      const bytes = fs.readFileSync(target), text = bytes.toString('utf8').split(/\r?\n/)[spec.line - 1] || '';
      if (sha(bytes) !== spec.sourceSha256 || discovery.sourceHashes?.[spec.file] !== spec.sourceSha256) issues.push('EXCLUDED_SOURCE_SHA_MISMATCH');
      if (sha(text) !== spec.lineSha256 || sha(text.trim()) !== spec.normalizedLineSha256) issues.push('EXCLUDED_CALL_LINE_OR_ARGUMENT_MISMATCH');
    }
    if (!Array.isArray(spec.requiredEvidence) || spec.requiredEvidence.length === 0) issues.push('EXCLUDED_CALL_EVIDENCE_NOT_DECLARED');
    for (const proof of spec.requiredEvidence || []) {
      const result = gate?.results?.find(row => row.id === proof.component);
      if (gateResultFailed(result, root, sourceSha256) || result?.sourceSha256 !== sourceSha256
        || !result?.checks?.some(check => check.id === proof.check && check.passed === true)) {
        issues.push(`EXCLUDED_CALL_EVIDENCE_MISSING:${proof.component}:${proof.check}`);
      }
    }
    excludedCalls.push({...spec, currentCallObserved: Boolean(call), evidenceReceipt: gateReceipt, issues});
  }
  for (const key of excludedKeys) if (!byIdentity.has(key)) errors.push('EXCLUDED_CALL_NOT_OBSERVED:' + key);
  if ((shared.currentCalls || []).length + safeRefusals.length + excludedCalls.length !== shared.sourceUniverse?.historicalRowCount) errors.push('HISTORICAL_LINEAGE_COUNT_MISMATCH');
  const safeRefusalValid = safeRefusals.every(row => row.issues.length === 0);
  const excludedCallsValid = excludedCalls.every(row => row.issues.length === 0);
  const mappingValid = errors.length === 0 && excludedCallsValid;
  return {status: mappingValid && gapCurrentCalls.length === 0 && safeRefusalValid ? 'PASS_SHARED_WRITER_CURRENT_REVIEW' : 'PARTIAL_SHARED_WRITER_CURRENT_REVIEW',
    mappingValid, observedCallerCount: observed.length, actualCurrentCallerCount: actual.length, acceptedCurrentCallerCount: acceptedCurrentCalls.length,
    gapCurrentCallerCount: gapCurrentCalls.length, acceptedCurrentCalls, gapCurrentCalls, excludedCalls, excludedCallsValid, safeRefusals, safeRefusalValid, errors,
    semantics: shared.semantics};
}

function classify(site, root, validContracts = new Map()) {
  const bytes=fs.readFileSync(path.join(root,site.file));
  const args=Number.isInteger(site.argumentByteOffset)&&Number.isInteger(site.argumentByteLength)?bytes.subarray(site.argumentByteOffset,site.argumentByteOffset+site.argumentByteLength).toString('utf8'):'';
  if (site.sink === 'fopen' && /^\(\s*(['"])php:\/\/output\1\s*[,)]/i.test(args)) return na(site, 'Opens only the response stream; content and export authorization are separate obligations.', `${site.file} response export`, {kind:'literal-target', target:'php://output', reachability:'Response stream only; no server-side path.'});
  if (['fwrite', 'fputs'].includes(site.sink) && /^\(\s*STD(?:OUT|ERR)\s*[,)]/.test(args)) return na(site, 'Writes only CLI stdout/stderr; this does not certify output confidentiality.', `${site.file} CLI response`, {kind:'literal-target', target:'STDOUT_OR_STDERR', reachability:'Process output stream only; no server-side path.'});
  const contract = validContracts.get(site.id);
  if (contract) return pass(site, contract);
  return blocked(site);
}

function build(discoveryFile, outputFile, options = {}) {
  const root = path.resolve(options.root || projectRoot);
  const discovery = JSON.parse(fs.readFileSync(discoveryFile));
  if (discovery.schema !== 2) throw new Error('WRITER_DISCOVERY_SCHEMA_UNSUPPORTED');
  const ids = new Set(), fingerprints = new Set();
  for (const site of discovery.sites) {
    if (!site.id || ids.has(site.id)) throw new Error('DUPLICATE_OR_MISSING_WRITER_ID');
    if (!site.siteFingerprint || fingerprints.has(site.siteFingerprint)) throw new Error('DUPLICATE_OR_MISSING_WRITER_FINGERPRINT');
    ids.add(site.id); fingerprints.add(site.siteFingerprint);
  }
  const sourceSha256 = options.sourceSha256 || process.env.RENT_RK_AUDIT_SOURCE_SHA256 || null;
  const laboratoryId = options.laboratoryId || process.env.RENT_RK_AUDIT_LAB_ID || null;
  const sharedWriterReview = validateSharedWriterReview(discovery, root, options.gate || null,
    sourceSha256, options.gateFile || null, policy.sharedWriterReview, laboratoryId);
  const sharedCustomerRequestReview = policy.sharedCustomerRequestReview
    ? validateSharedWriterReview(discovery, root, options.gate || null, sourceSha256,
      options.gateFile || null, policy.sharedCustomerRequestReview, laboratoryId)
    : null;
  const gateSeriesBinding = validateGateSeriesBinding(root, options.gate || null, options.gateFile || null,
    sourceSha256, laboratoryId);
  const validContracts = new Map(), contracts = [];
  for (const contract of exactContracts) {
    const keys = Object.keys(contract.expected);
    const functions = new Set(keys.map(key => key.slice(0, key.lastIndexOf('|'))));
    const candidates = discovery.sites.filter(site => site.file === contract.file && functions.has(site.function));
    const actual = {};
    for (const site of candidates) actual[`${site.function}|${site.sink}`] = (actual[`${site.function}|${site.sink}`] || 0) + 1;
    const normalizeCounts = value => JSON.stringify(Object.entries(value).sort(([a],[b]) => a.localeCompare(b)));
    const expectedSiteBindings = Array.isArray(contract.expectedSites) ? contract.expectedSites : [];
    const actualSiteBindings = candidates.map(site => ({id: site.id, siteFingerprint: site.siteFingerprint}))
      .sort((a, b) => a.id.localeCompare(b.id));
    const siteBindingsValid = expectedSiteBindings.length === 0 || JSON.stringify(actualSiteBindings) === JSON.stringify(
      expectedSiteBindings.map(site => ({id: site.id, siteFingerprint: site.siteFingerprint})).sort((a, b) => a.id.localeCompare(b.id))
    );
    const valid = candidates.length > 0 && candidates.every(site => site.sourceSha256 === contract.sourceSha256)
      && normalizeCounts(actual) === normalizeCounts(contract.expected) && siteBindingsValid;
    const conditionalReview = contract.conditionalAdmission?.reviewGroup === 'customers-requests'
      ? sharedCustomerRequestReview : sharedWriterReview;
    const conditionalAdmission = contract.reviewStatus === 'REVIEWED_SHARED_WRITER_ENVELOPE'
      ? sharedWriterEnvelopeComplete(conditionalReview, contract.conditionalAdmission, gateSeriesBinding)
      : (contract.reviewStatus === 'REVIEWED_COMPONENT_EVIDENCE'
        ? componentEvidenceComplete(root, options.gate || null, contract.conditionalAdmission,
          gateSeriesBinding, sourceSha256) : null);
    const approved = valid && (contract.reviewStatus === 'REVIEWED_SUBSET' || conditionalAdmission?.valid === true);
    if (approved) for (const site of candidates) validContracts.set(site.id, contract);
    const suites = require('./business-data-critical-gate.cjs').suites;
    const dependencyFiles = contract.dependencyFiles.map(file => file.startsWith('@component:')
      ? 'tools/' + (suites.find(suite => suite[0] === file.slice(11))?.[1] || 'MISSING') : file);
    const dependencyHashes = Object.fromEntries(dependencyFiles.map(file => [file, fs.existsSync(path.join(root,file)) ? sha(fs.readFileSync(path.join(root,file))) : null]));
    contracts.push({...contract, reviewedSourceSha256:contract.sourceSha256, sourceSha256:discovery.sourceHashes[contract.file], valid:approved, bindingValid:valid, siteBindingsValid, conditionalAdmissionResult:conditionalAdmission, dependencyHashes, sites:actualSiteBindings, contract: {...profiles[contract.profile]}});
  }
  const sites = discovery.sites.map(site => classify(site, root, validContracts));
  const unresolvedSites = sites.filter(site => site.coverage === 'BLOCKED');
  const requiredSurfaceFile = path.join(root, 'tools/business-data-required-surfaces.json');
  const requiredSurfaces = JSON.parse(fs.readFileSync(requiredSurfaceFile)).surfaces;
  const missingSurfaces = options.includeExternalSurfaces === false ? [] : requiredSurfaces.map(surface => ({...surface, coverage: 'BLOCKED', reason: 'Required external writer surface has no current executable contract and complete evidence set.'}));
  const groups = new Map();
  for (const site of unresolvedSites) {
    const key = `${site.file}::${site.function}`;
    if (!groups.has(key)) groups.set(key, {file: site.file, function: site.function, sites: 0, sinks: new Set(), storeConstants: new Set()});
    const group = groups.get(key); group.sites++; group.sinks.add(site.sink); for (const value of site.storeConstants) group.storeConstants.add(value);
  }
  const unresolvedCriticalPaths = unresolvedSites.length + missingSurfaces.length;
  const review = {schema: 4, createdAt: new Date().toISOString(), sourceSha256: options.sourceSha256 || process.env.RENT_RK_AUDIT_SOURCE_SHA256 || null,
    laboratoryId: options.laboratoryId || process.env.RENT_RK_AUDIT_LAB_ID || null,
    discoverySha256: sha(fs.readFileSync(discoveryFile)), globalStatus: unresolvedCriticalPaths ? 'BLOCKED' : 'PASS', unresolvedCriticalPaths,
    countMeaning: 'Unresolved unique sink sites plus independently required missing writer surfaces; not a vulnerability count.', sites, missingSurfaces, contracts, sharedWriterReview, sharedCustomerRequestReview,
    unresolvedOperationGroups: [...groups.values()].map(group => ({...group, sinks: [...group.sinks].sort(), storeConstants: [...group.storeConstants].sort()})).sort((a,b)=>a.file.localeCompare(b.file)||a.function.localeCompare(b.function)),
    counts: {sinkSites:sites.length, passSites:sites.filter(site=>site.coverage==='PASS').length, notApplicableSites:sites.filter(site=>site.coverage==='NOT_APPLICABLE').length, blockedSites:unresolvedSites.length,
      contracts:contracts.length, reviewedContracts:contracts.filter(contract=>contract.valid).length, technicalGroups:new Set(sites.map(site=>`${site.file}::${site.function}`)).size, unresolvedTechnicalGroups:groups.size, provenBusinessOperations:null},
    rules: {failClosedDefault:'BLOCKED', policyFile:'tools/business-data-review-policy.json', notApplicable:'Literal response streams only; export content and authorization remain separate security obligations.'},
    limitations: ['PASS is assigned only to named contracts with exact current component/check evidence.', 'Operational business migrations remain BLOCKED until separately exercised on an isolated copy.', 'Dynamic includes and method dispatch require separate review. Owner-excluded projects are outside this Rent RK model.']};
  fs.writeFileSync(outputFile, JSON.stringify(review, null, 2) + '\n', {flag: 'wx'});
  return review;
}

if (require.main === module) {
  const [discoveryFile, outputFile] = process.argv.slice(2);
  if (discoveryFile === '--check-exact-source-bindings') {
    const result = validateExactSourceBindings(outputFile || projectRoot);
    console.log(JSON.stringify(result, null, 2));
    process.exitCode = result.status === 'PASS_EXACT_SOURCE_BINDINGS' ? 0 : 1;
    return;
  }
  if (!discoveryFile || !outputFile) throw new Error('Usage: node tools/business-data-writer-review.cjs <discovery.json> <review.json>');
  const review = build(path.resolve(discoveryFile), path.resolve(outputFile));
  console.log(JSON.stringify({status: review.globalStatus, unresolvedPaths: review.unresolvedCriticalPaths, unresolvedSites: review.sites.filter(site=>site.coverage==='BLOCKED').length, unresolvedOperationGroups: review.unresolvedOperationGroups.length, classifiedPass: review.sites.filter(site=>site.coverage==='PASS').length, classifiedNotApplicable: review.sites.filter(site=>site.coverage==='NOT_APPLICABLE').length}, null, 2));
}

module.exports = {build, classify, profiles, exactContracts, validateExactSourceBindings, validateSharedWriterReview,
  validateGateSeriesBinding, sharedWriterEnvelopeComplete, componentEvidenceComplete};
