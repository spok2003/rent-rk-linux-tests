'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process'),crypto=require('crypto');
const a=require('./business-data-audit.cjs');
const root=path.resolve(__dirname,'..'),evidence=path.join(root,'artifacts/bootstrap-b24-remediation-20261021'),php='D:/OSPanel/modules/PHP-8.4/php.exe';
process.env.RENT_RK_QA_PHP=php;process.env.PHP_BINARY=php;
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=f=>JSON.parse(fs.readFileSync(f,'utf8'));
const put=(f,x)=>{fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,JSON.stringify(x,null,2)+'\n');};
const series=process.argv[2]||'smoke-1',out=path.join(evidence,series);if(!/^[a-z0-9-]+$/.test(series)||fs.existsSync(out))throw Error('Fresh explicit series required');fs.mkdirSync(out,{recursive:true});
const free=()=>{const s=fs.statfsSync('C:/');return s.bavail*s.bsize;};
if(free()<Math.max(250000000,5*1024**3+300*1024**2))throw Error('Insufficient C headroom; no cleanup');
const existingLab=path.resolve(process.env.RENT_RK_AUDIT_LAB_ROOT||'.')===root&&fs.existsSync(path.join(root,'.rent-rk-test-lab'));
function currentLab(){const dir=path.resolve(root,'../..'),meta=read(path.join(dir,'laboratory.json')),baseline=read(path.join(dir,'baseline.json'));if(fs.realpathSync(meta.lab)!==fs.realpathSync(root)||baseline.laboratoryId!==path.basename(dir)||baseline.sourceSha256!==process.env.RENT_RK_AUDIT_SOURCE_SHA256||a.qaSourceIdentity().sourceHashesSha256!==baseline.sourceSha256)throw Error('Frozen current laboratory binding mismatch');return {...meta,dir,baseline};}
const s=existingLab?currentLab():a.create('b24-remediation',{temporary:true});put(path.join(out,'laboratory.json'),{dir:s.dir,lab:s.lab,id:s.baseline.laboratoryId,freeBefore:free(),temporary:true});
const runBinding=process.env.RENT_RK_QA_RUN_BINDING||crypto.randomBytes(16).toString('hex');
const inputs=a.validateLaboratoryInputs(s);put(path.join(out,'inputs.json'),inputs);if(inputs.status!=='PASS_LABORATORY_INPUTS')throw Error('Standard lab input validation failed');
const file=f=>path.join(s.lab,f),data=file('tmp/default-data');
fs.appendFileSync(file('guard/isolation.ini'),'\nopcache.enable=0\nopcache.enable_cli=0\nopcache.file_cache=\nopcache.file_cache_only=0\n');
const car={slug:'qa-b24-car',name:'B24 Synthetic Vehicle \u0422\u0435\u0441\u0442',brand:'Synthetic',model:'B24',year:2025,seats:5,price:4321,deposit:12345,active:true,adminStatus:'active',publicStatus:'published',isPublished:true,publishChannels:['rent_rk_public'],owner_type:'rent_rk',owner_scope_id:'rent_rk',image:'/assets/img/cars/synthetic/main.webp',detailDescription:'Synthetic only.'};
for(const [name,value]of Object.entries({'current-cars':[car],rates:{cars:{[car.slug]:{daily:4321,deposit:12345}}},'car-page-content':{version:1,items:{}},partners:[],lessors:[],'admin-users':[],'access-rules':{},'callback-settings':{},settings:{},'build-state':{version:1,outputs:{},dirty:[],conflicts:[],runs:[],unrelatedEnvelope:{keep:'B24 sentinel'}}}))put(path.join(data,name+'.json'),value);
put(file('data/routes.json'),[]);put(file('data/promo-badges.json'),{version:1,items:[]});
for(const name of ['index.html','cars/index.html','sitemap.xml'])fs.writeFileSync(file(name),'B24 ORIGINAL '+name+'\n');fs.writeFileSync(file('cars/qa-b24-neighbor.html'),'B24 NEIGHBOR\n');
fs.mkdirSync(file('tmp/b24'),{recursive:true});
const flags=['-d','opcache.enable=0','-d','opcache.enable_cli=0','-d','opcache.file_cache=','-d','opcache.file_cache_only=0'];
const env=()=>({...a.env(s.lab),PHP_BINARY:php,RENT_RK_QA_PHP:php});
const checks=[],observations=[];const check=(id,passed,detail={})=>{checks.push({id,passed,detail});put(path.join(out,'primary.json'),{status:checks.every(x=>x.passed)?'PASS_COMPONENT_ONLY':'FAIL',sourceSha256:s.baseline.sourceSha256,laboratoryId:s.baseline.laboratoryId,checks,observations});if(!passed)throw Error('Assertion failed '+id);};
function call(action,label){const r=cp.spawnSync(php,[...flags,'tools/bootstrap-b24-native-qa.php',action],{cwd:s.lab,env:env(),encoding:'utf8',windowsHide:true,timeout:120000,maxBuffer:4*1024**2});let response=null;try{response=JSON.parse(r.stdout);}catch{}const o={label,exit:r.status,error:r.error?.message||null,stderr:r.stderr,response};observations.push(o);put(path.join(out,label+'.json'),o);return o;}
function parallelCall(action,label){return new Promise((resolve,reject)=>{const p=cp.spawn(php,[...flags,'tools/bootstrap-b24-native-qa.php',action],{cwd:s.lab,env:env(),windowsHide:true});let stdout='',stderr='';const timer=setTimeout(()=>reject(Error('Bounded native child timeout '+label)),120000);p.stdout.on('data',b=>stdout+=b);p.stderr.on('data',b=>stderr+=b);p.on('error',reject);p.on('close',exit=>{clearTimeout(timer);let response=null;try{response=JSON.parse(stdout);}catch{}const o={label,exit,stderr,response};observations.push(o);put(path.join(out,label+'.json'),o);resolve(o);});});}
function ps(command){const p=cp.spawn('powershell',['-NoProfile','-ExecutionPolicy','Bypass','-Command',command],{cwd:s.lab,env:env(),windowsHide:true});let stdout='',stderr='';p.stdout.on('data',b=>stdout+=b);p.stderr.on('data',b=>stderr+=b);return new Promise((resolve,reject)=>{p.on('error',reject);p.on('close',exit=>resolve({exit,stdout,stderr}));});}
const quote=value=>"'"+value.replaceAll("'","''")+"'";
async function untilFile(p){const end=Date.now()+15000;while(!fs.existsSync(p)){if(Date.now()>end)throw Error('Owned barrier not reached');await new Promise(r=>setTimeout(r,30));}}
function bridge(action,payload={},fault=''){
 const r=cp.spawnSync(php,[...flags,'tools/bootstrap-b24-transaction-qa.php',action,fault],{cwd:s.lab,env:env(),input:JSON.stringify(payload),encoding:'utf8',windowsHide:true,timeout:20000,maxBuffer:40*1024**2});
 let value=null;try{value=JSON.parse(r.stdout);}catch{}return {exit:r.status,value,stderr:r.stderr,error:r.error?.message};
}
function proposal(){const prepared=bridge('prepare');if(prepared.exit!==0)throw Error('Prepare failed '+JSON.stringify(prepared));const state=read(path.join(data,'build-state.json')),id='20261021-120000-'+crypto.randomBytes(16).toString('hex'),bytes='B24 transactional output '+id+'\n';state.runs.unshift({id,mode:'Full'});state.lastRun=state.runs[0];state.outputs['index.html']={outputHash:'sha256:'+sha(bytes)};return {id,version:prepared.value.version,state,outputs:{'index.html':bytes},deletes:[]};}
function exactTree(){const result={};function visit(dir){if(!fs.existsSync(dir))return;for(const row of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,row.name);if(row.isDirectory())visit(p);else if(row.isFile())result[path.relative(s.lab,p).replaceAll('\\','/')]=sha(fs.readFileSync(p));}}for(const p of ['index.html','cars/index.html','sitemap.xml'])result[p]=sha(fs.readFileSync(file(p)));visit(path.join(data,'backups/generated-output-backups'));for(const name of fs.readdirSync(data).filter(n=>n.endsWith('.json')).sort())result['data/'+name]=sha(fs.readFileSync(path.join(data,name)));return result;}
async function main(){
 check('standard-temp-confinement',s.dir.startsWith(path.join(process.env.LOCALAPPDATA,'Temp')+path.sep)&&(!s.dir.startsWith(root)||existingLab),{dir:s.dir});
 for(const name of ['tools/build-site.ps1','tools/build-state.ps1','tools/build-site-transaction.php','admin/includes/bootstrap.php','admin/includes/rental-return-store.php']){const expected=s.baseline.sourceHashes[name]||s.baseline.artifactDependencies.entries.find(x=>x.path===name)?.sha256;check('frozen-input-'+name,sha(fs.readFileSync(file(name)))===expected);}
 const result=call('full','native-full');check('native-full-success',result.exit===0&&result.response?.result?.success===true&&!result.response.error,{response:result.response?.result});
 const state=read(path.join(data,'build-state.json'));check('single-run',state.runs.length===1);check('unknown-envelope-preserved',state.unrelatedEnvelope?.keep==='B24 sentinel');
 for(const name of ['index.html','cars/index.html','cars/qa-b24-car.html','sitemap.xml'])check('output-state-'+name,state.outputs[name]?.outputHash==='sha256:'+sha(fs.readFileSync(file(name))));
 check('synthetic-content',fs.readFileSync(file('cars/qa-b24-car.html'),'utf8').includes('B24 Synthetic Vehicle'));
 check('unicode-roundtrip',fs.readFileSync(file('cars/qa-b24-car.html'),'utf8').includes('\u0422\u0435\u0441\u0442'));
 const backup=path.join(data,'backups/generated-output-backups',state.lastRun.id,'index.html');check('exact-before-backup',fs.readFileSync(backup,'utf8')==='B24 ORIGINAL index.html\n');
 check('unique-run-id-format',/^\d{8}-\d{6}-[a-f0-9]{32}$/.test(state.lastRun.id));
 check('neighbor-untouched',fs.readFileSync(file('cars/qa-b24-neighbor.html'),'utf8')==='B24 NEIGHBOR\n');
 for(const pair of [['full','full'],['full','car']]){
  const before=read(path.join(data,'build-state.json')),beforeBytes={};
  for(const name of Object.keys(before.outputs))if(fs.existsSync(file(name)))beforeBytes[name]=fs.readFileSync(file(name));
  const label=pair.join('-'),results=await Promise.all(pair.map((action,i)=>parallelCall(action,label+'-'+i)));
  check('parallel-'+label+'-both-success',results.every(r=>r.exit===0&&r.response?.result?.success===true&&!r.response.error));
  const after=read(path.join(data,'build-state.json')),added=after.runs.filter(r=>!before.runs.some(b=>b.id===r.id));
  check('parallel-'+label+'-history-preserved',after.runs.length===before.runs.length+2&&added.length===2&&before.runs.every(b=>after.runs.some(r=>r.id===b.id)));
  check('parallel-'+label+'-unique-ids',new Set(after.runs.map(r=>r.id)).size===after.runs.length,{addedIds:added.map(r=>r.id)});
  check('parallel-'+label+'-state-bytes',Object.entries(after.outputs).every(([name,row])=>!row.outputHash||row.outputHash==='sha256:'+sha(fs.readFileSync(file(name)))));
  const oldest=added[added.length-1];
  check('parallel-'+label+'-first-backup-exact',Object.entries(beforeBytes).every(([name,bytes])=>{const p=path.join(data,'backups/generated-output-backups',oldest.id,name);return !fs.existsSync(p)||sha(fs.readFileSync(p))===sha(bytes);}));
  check('parallel-'+label+'-neighbor-preserved',fs.readFileSync(file('cars/qa-b24-neighbor.html'),'utf8')==='B24 NEIGHBOR\n');
 }
 {const ready=file('tmp/b24/lease-ready'),release=file('tmp/b24/lease-release'),lock=file('private/rent-rk-data/.site-build.lock');
  const held=ps('$f=[IO.File]::Open('+quote(lock)+',[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None); try { [IO.File]::WriteAllText('+quote(ready)+',"ready"); $t=[Diagnostics.Stopwatch]::StartNew(); while(-not(Test-Path -LiteralPath '+quote(release)+')) { if($t.ElapsedMilliseconds -gt 20000){throw "Bounded holder timeout"}; Start-Sleep -Milliseconds 20 } } finally {$f.Dispose()}');
  await untilFile(ready);const build=parallelCall('full','lease-wait-full');const start=Date.now(),peer=bridge('commit',{},'writer');
  check('independent-writer-before-build-lease-release',peer.exit===0&&peer.value?.writer===true&&Date.now()-start<10000&&!fs.existsSync(release),{elapsedMs:Date.now()-start});fs.writeFileSync(release,'release');
  const holder=await held,built=await build;check('lease-release-and-build-success',holder.exit===0&&built.exit===0&&built.response?.result?.success===true);check('independent-writer-preserved',read(path.join(data,'settings.json')).b24SyntheticWriter==='preserved');
 }
 {const before=read(path.join(data,'build-state.json'));const command='function Get-Date { [datetime]"2026-10-21T12:00:00" }; & '+quote(file('tools/build-site.ps1'))+' -Mode Full -Backup -NoPublicData -NoDelete -PhpExecutable '+quote(php);
  const results=await Promise.all([ps(command),ps(command)]);observations.push({label:'controlled-same-clock',results});check('same-clock-native-builds-success',results.every(r=>r.exit===0));
  const after=read(path.join(data,'build-state.json')),added=after.runs.filter(r=>!before.runs.some(b=>b.id===r.id));check('same-clock-unique-runs',added.length===2&&new Set(added.map(r=>r.id)).size===2&&added.every(r=>r.id.startsWith('20261021-120000-')),{ids:added.map(r=>r.id)});
 }
 for(const fault of ['open-backup','open-output','flush-output','sync-output','rename-output','open-state']){
  const plan=proposal(),before=exactTree(),marker=file('tmp/b24/io-marker.json');fs.rmSync(marker,{force:true});
  const failure=bridge('commit',plan,fault);observations.push({label:fault,...failure,marker:fs.existsSync(marker)?read(marker):null});
  check(fault+'-reached',fs.existsSync(marker)&&read(marker).ordinal===(['open-backup','open-state'].includes(fault)?1:2));check(fault+'-refused',failure.exit!==0&&typeof failure.value?.error==='string');
  check(fault+'-exact-rollback',JSON.stringify(before)===JSON.stringify(exactTree()));
  const retry=bridge('commit',plan);check(fault+'-safe-retry',retry.exit===0&&retry.value?.committed===true);
  const committed=exactTree(),replay=bridge('commit',plan);check(fault+'-replay-no-write',replay.exit===0&&replay.value?.replayed===true&&JSON.stringify(committed)===JSON.stringify(exactTree()));
  const tampered=bridge('commit',{...plan,outputs:{'index.html':'tampered'}});check(fault+'-id-reuse-refused',tampered.exit!==0&&JSON.stringify(committed)===JSON.stringify(exactTree()));
 }
 for(const fault of ['crash-prepared','crash-output','crash-committed']){
  const plan=proposal(),before=exactTree(),marker=file('tmp/b24/io-marker.json');fs.rmSync(marker,{force:true});
  const interrupted=bridge('commit',plan,fault);check(fault+'-boundary-reached',interrupted.exit===73&&fs.existsSync(marker));
  const recovered=bridge('prepare');check(fault+'-recovery-readable',recovered.exit===0);
  if(fault==='crash-committed')check(fault+'-rollforward',fs.readFileSync(file('index.html'),'utf8')===plan.outputs['index.html']&&read(path.join(data,'build-state.json')).lastRun.id===plan.id);
  else check(fault+'-rollback',JSON.stringify(before)===JSON.stringify(exactTree()));
  const retried=bridge('commit',plan);check(fault+'-retry',retried.exit===0&&retried.value?.committed===true);
 }
 for(const kind of ['private','public']){
  const plan=proposal(),target=kind==='private'?path.join(data,'rates.json'):file('index.html'),original=fs.readFileSync(target);
  if(kind==='private')put(target,{cars:{},changed:'synthetic concurrent writer'});else fs.writeFileSync(target,'B24 independent public change\n');
  const changed=exactTree(),refused=bridge('commit',plan);check('stale-'+kind+'-refused',refused.exit!==0&&refused.value?.code===409&&JSON.stringify(changed)===JSON.stringify(exactTree()));fs.writeFileSync(target,original);
 }
 {const plan=proposal(),before=exactTree();plan.state.outputs['index.html'].outputHash='sha256:'+'0'.repeat(64);const r=bridge('commit',plan);check('false-output-receipt-refused',r.exit!==0&&JSON.stringify(before)===JSON.stringify(exactTree()));}
 {const plan=proposal(),before=exactTree();plan.state.runs=plan.state.runs.slice(0,1);const r=bridge('commit',plan);check('lost-history-proposal-refused',r.exit!==0&&JSON.stringify(before)===JSON.stringify(exactTree()));}
 {const plan=proposal(),bytes=fs.readFileSync(file('cars/qa-b24-neighbor.html'));plan.deletes=['cars/qa-b24-neighbor.html'];const r=bridge('commit',plan);check('transactional-output-delete',r.exit===0&&!fs.existsSync(file('cars/qa-b24-neighbor.html'))&&sha(fs.readFileSync(path.join(data,'backups/generated-output-backups',plan.id,'cars/qa-b24-neighbor.html')))===sha(bytes));fs.writeFileSync(file('cars/qa-b24-neighbor.html'),bytes);}
 {const state=read(path.join(data,'build-state.json')),audit=read(path.join(data,'audit-log.json')).items;check('build-history-audit-one-per-commit',state.runs.every(run=>audit.filter(row=>row.action==='site.build.commit'&&row.entityId===run.id).length===1));}
 {const r=cp.spawnSync(php,[...flags,'tools/project-progress-validate.php','--file=private/rent-rk-data/project-progress-map.json'],{cwd:s.lab,env:env(),encoding:'utf8',windowsHide:true,timeout:30000});put(path.join(out,'project-progress-validator.json'),{exit:r.status,stdout:r.stdout,stderr:r.stderr,laboratoryId:s.baseline.laboratoryId});check('deferred-project-progress-validator-isolated',r.status===0);}
 if(!existingLab)put(path.join(out,'preservation.json'),a.verify(s));
 put(path.join(out,'source-binding.json'),{sourceSha256:s.baseline.sourceSha256,artifactDependencies:s.baseline.artifactDependencies,php,flags,toolSha256:sha(fs.readFileSync(__filename))});
 const report=file('tmp/bootstrap-b24-build/'+runBinding+'/batch-primary.json');put(report,{schemaVersion:1,runId:runBinding,status:'PASS',sourceSha256:s.baseline.sourceSha256,laboratoryId:s.baseline.laboratoryId,checks:checks.length,passed:checks.length,failed:0,results:checks.map(c=>({test:c.id,passed:c.passed,detail:c.detail})),observations,limits:['Windows native Full/Car only. Cooperating RentalReturnStore readers; not atomic multi-file visibility for raw static readers. Controlled injected I/O/process exits, not device failure. No external delivery or broad public JSON guarantee.']});
 console.log(JSON.stringify({checks:checks.length,failed:[],lab:s.dir,report}));
}
main().catch(e=>{put(path.join(out,'failure.json'),{error:e.stack,lab:s.dir,freeC:free(),needsFullFixture:false,retention:'Preserve sanitized diagnostics/frozen tested source before task-owned temp cleanup.'});console.error(e.stack);process.exitCode=1;});
