﻿param(
  [ValidateSet("Full", "Dirty", "Car", "Route", "CarPageContent", "PublicDataOnly")]
  [string]$Mode = "Full",
  [string]$Slug = "",
  [switch]$DryRun,
  [switch]$NoPublicData,
  [switch]$NoDelete,
  [switch]$Backup,
  [switch]$BaselineAudit,
  [switch]$RegisterBaseline,
  [switch]$WriteExpectedToTemp,
  [string]$ExpectedTempRoot = "",
  [switch]$FixtureMode,
  [string]$InputCarsJson = "",
  [string]$InputRatesJson = "",
  [string]$InputCarPageContentJson = "",
  [string]$PhpExecutable = "php"
)

$ErrorActionPreference = "Stop"

$root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$privateDataDir = Join-Path $root "private/rent-rk-data"
$buildStatePath = Join-Path $privateDataDir "build-state.json"
$buildStateHelpers = Join-Path $PSScriptRoot "build-state.ps1"
if (-not (Test-Path -LiteralPath $buildStateHelpers)) {
  throw "Build-state helper is missing: $buildStateHelpers"
}
. $buildStateHelpers

$runId = (Get-Date).ToString("yyyyMMdd-HHmmss") + "-" + [Guid]::NewGuid().ToString("N")
$script:BuildOutputManifest = @()
$script:BuildDeleteManifest = @()
$script:BuildBaselineManifest = @()
$script:BuildSources = @()
$script:BuildPublicDataAction = "skipped"
$script:BuildFixtureMode = [bool]$FixtureMode
$script:BuildSourceMode = if ($script:BuildFixtureMode) { "fixture" } else { "private" }
$script:BuildFixtureCarsPath = ""
$script:BuildFixtureRatesPath = ""
$script:BuildFixtureCarPageContentPath = ""
$script:BuildFixtureDependencyPaths = @()
$script:BuildTargetPlanOnly = @("Dirty", "Route") -contains $Mode
$script:BuildCarOnly = $Mode -eq "Car"
$script:BuildPageContentOnly = $Mode -eq "CarPageContent"
$script:BuildAllowedOutputPaths = @{}
$script:BuildGeneratorName = "tools/build-site.ps1"
$script:BuildExpectedTempRoot = ""
$script:BuildAtomic = (-not $FixtureMode) -and (-not $DryRun -or $RegisterBaseline) -and ($NoPublicData -or $RegisterBaseline) -and $Mode -ne "PublicDataOnly"
$script:BuildInputSnapshot = @{}
$script:BuildTransactionSnapshot = $null
$script:BuildPendingOutputs = @{}
$script:BuildPendingDeletes = @{}
$buildLease = $null
try {
if (-not $DryRun -or $RegisterBaseline) {
  if (-not (Test-Path -LiteralPath $privateDataDir)) { New-Item -ItemType Directory -Path $privateDataDir -Force | Out-Null }
  $clock = [Diagnostics.Stopwatch]::StartNew()
  while ($null -eq $buildLease) {
    try { $buildLease = [IO.File]::Open((Join-Path $privateDataDir ".site-build.lock"), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
    catch [IO.IOException] { if ($clock.ElapsedMilliseconds -ge 30000) { throw "Another site build is still active; retry later." }; Start-Sleep -Milliseconds 25 }
  }
}
if ($script:BuildAtomic) {
  $script:BuildTransactionSnapshot = Invoke-BuildTransaction "prepare" @{}
  $privateDataDir = [IO.Path]::GetFullPath($script:BuildTransactionSnapshot.dataDir)
  $buildStatePath = Join-Path $privateDataDir "build-state.json"
  foreach ($input in $script:BuildTransactionSnapshot.inputs) {
    $script:BuildInputSnapshot[[IO.Path]::GetFullPath($input.path)] = $input.bytes
  }
}

function Resolve-BuildFixturePath {
  param(
    [string]$Path,
    [string]$Label,
    [bool]$Required = $false
  )

  if ([string]::IsNullOrWhiteSpace($Path)) {
    if ($Required) { throw "-$Label is required in -FixtureMode." }
    return ""
  }

  $candidate = if ([System.IO.Path]::IsPathRooted($Path)) { $Path } else { Join-Path $root $Path }
  $fullPath = [System.IO.Path]::GetFullPath($candidate)
  $tmpRoot = [System.IO.Path]::GetFullPath((Join-Path $root "tmp")).TrimEnd("\", "/") + [System.IO.Path]::DirectorySeparatorChar
  if (-not $fullPath.StartsWith($tmpRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "-$Label must be under workspace tmp/: $fullPath"
  }
  if ($fullPath -match '(?i)[\\/](private|data|admin|api|assets|cars|pages|routes|partner)[\\/]') {
    $relative = Get-BuildRelativePathFromFullPath $root $fullPath
    if (-not $relative.StartsWith("tmp/", [System.StringComparison]::OrdinalIgnoreCase)) {
      throw "-$Label points to a forbidden project surface: $fullPath"
    }
  }
  if ($Required -and -not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
    throw "-$Label file is missing: $fullPath"
  }

  return $fullPath
}

if ($script:BuildFixtureMode) {
  if ($Mode -ne "Full") {
    throw "-FixtureMode currently supports only -Mode Full."
  }
  if ([string]::IsNullOrWhiteSpace($ExpectedTempRoot)) {
    throw "-FixtureMode requires explicit -ExpectedTempRoot under tmp/."
  }
  if ($BaselineAudit -or $RegisterBaseline -or $Backup) {
    throw "-FixtureMode cannot be combined with -BaselineAudit, -RegisterBaseline or -Backup."
  }
  $DryRun = $true
  $NoPublicData = $true
  $NoDelete = $true
  $WriteExpectedToTemp = $true
}

$script:BuildState = if ($script:BuildFixtureMode) { New-BuildStateDefault } else { Read-BuildState $buildStatePath }

if ($RegisterBaseline) {
  $BaselineAudit = $true
  $DryRun = $true
  $NoPublicData = $true
  $NoDelete = $true
}

if ($BaselineAudit) {
  if ($Mode -ne "Full") {
    throw "-BaselineAudit and -RegisterBaseline are only supported with -Mode Full."
  }
  if (-not $DryRun) {
    throw "-BaselineAudit must be combined with -DryRun."
  }
  if (-not $NoPublicData -or -not $NoDelete) {
    throw "-BaselineAudit requires -NoPublicData and -NoDelete."
  }
}

if ($WriteExpectedToTemp) {
  if (-not $DryRun) {
    throw "-WriteExpectedToTemp is only allowed with -DryRun."
  }
  $tempRoot = if ([string]::IsNullOrWhiteSpace($ExpectedTempRoot)) {
    Join-Path $root ("tmp/baseline-expected-" + $runId + "/expected")
  } elseif ([System.IO.Path]::IsPathRooted($ExpectedTempRoot)) {
    $ExpectedTempRoot
  } else {
    Join-Path $root $ExpectedTempRoot
  }
  $tempRootFull = [System.IO.Path]::GetFullPath($tempRoot)
  $workspaceTmpFull = [System.IO.Path]::GetFullPath((Join-Path $root "tmp")).TrimEnd("\", "/") + [System.IO.Path]::DirectorySeparatorChar
  if (-not ($tempRootFull + [System.IO.Path]::DirectorySeparatorChar).StartsWith($workspaceTmpFull, [System.StringComparison]::OrdinalIgnoreCase) -and
      -not $tempRootFull.StartsWith($workspaceTmpFull, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "-WriteExpectedToTemp can only write under workspace tmp/: $tempRootFull"
  }
  if ($script:BuildFixtureMode) {
    $rootFull = [System.IO.Path]::GetFullPath($root).TrimEnd("\", "/")
    $tmpRootFull = [System.IO.Path]::GetFullPath((Join-Path $root "tmp")).TrimEnd("\", "/")
    $tempRootTrimmed = $tempRootFull.TrimEnd("\", "/")
    if ($tempRootTrimmed -eq $rootFull -or $tempRootTrimmed -eq $tmpRootFull) {
      throw "-FixtureMode output root must be a dedicated directory inside tmp/, not the project root or tmp root."
    }
    $relativeTempRoot = Get-BuildRelativePathFromFullPath $root $tempRootFull
    if ($relativeTempRoot -notmatch '^tmp/') {
      throw "-FixtureMode output root must be under tmp/: $relativeTempRoot"
    }
    foreach ($forbiddenRoot in @("cars", "pages", "routes", "partner", "assets")) {
      if ($relativeTempRoot -eq $forbiddenRoot -or $relativeTempRoot.StartsWith($forbiddenRoot + "/", [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "-FixtureMode output root points to a real public path: $relativeTempRoot"
      }
    }
  }
  New-Item -ItemType Directory -Force -Path $tempRootFull | Out-Null
  $script:BuildExpectedTempRoot = $tempRootFull
}

if ($script:BuildFixtureMode) {
  $script:BuildFixtureCarsPath = Resolve-BuildFixturePath $InputCarsJson "InputCarsJson" $true
  $script:BuildFixtureRatesPath = Resolve-BuildFixturePath $InputRatesJson "InputRatesJson" $false
  $script:BuildFixtureCarPageContentPath = Resolve-BuildFixturePath $InputCarPageContentJson "InputCarPageContentJson" $false
  $script:BuildFixtureDependencyPaths = @($script:BuildFixtureCarsPath, $script:BuildFixtureRatesPath, $script:BuildFixtureCarPageContentPath) |
    Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } |
    ForEach-Object { Get-BuildRelativePathFromFullPath $root $_ }
}

if (-not $DryRun -and -not $Backup) {
  throw "Stage 1 safety gate: real generated-output writes require -Backup. Use -DryRun for a no-write plan."
}
if ($script:BuildTargetPlanOnly -and -not $DryRun) {
  throw "Stage 1 per-target modes currently support plan/dry-run only. Re-run with -DryRun."
}
if ($script:BuildCarOnly) {
  if ([string]::IsNullOrWhiteSpace($Slug)) {
    throw "-Mode Car requires -Slug <slug>."
  }
  if (-not $NoPublicData) {
    throw "-Mode Car requires -NoPublicData to prevent public JSON writes."
  }
  if (-not $NoDelete) {
    throw "-Mode Car requires -NoDelete to prevent generated-output deletes."
  }
}
if ($script:BuildPageContentOnly) {
  if ([string]::IsNullOrWhiteSpace($Slug)) {
    throw "-Mode CarPageContent requires -Slug <slug>."
  }
  if (-not $NoPublicData) {
    throw "-Mode CarPageContent requires -NoPublicData to prevent public JSON writes."
  }
  if (-not $NoDelete) {
    throw "-Mode CarPageContent requires -NoDelete to prevent generated-output deletes."
  }
}

$publisherPath = Join-Path $PSScriptRoot "publish-public-data.ps1"
if (-not (Test-Path -LiteralPath $publisherPath)) {
  throw "Publication publisher is missing: $publisherPath"
}

function Add-BuildSource {
  param(
    [string]$Path,
    [string]$Label,
    [string]$Role = "source"
  )

  $relative = if (Test-Path -LiteralPath $Path) { Get-BuildRelativePathFromFullPath $root $Path } else { $Path.Replace($root, "").TrimStart("\", "/").Replace("\", "/") }
  $script:BuildSources += [ordered]@{
    path = $relative
    label = $Label
    role = $Role
    exists = Test-BuildInputExists $Path
    hash = Get-BuildFileHashValue $Path
  }
}

function Invoke-PublicDataPublisherForBuild {
  if ($NoPublicData) {
    $script:BuildPublicDataAction = "skipped by -NoPublicData"
    return
  }

  if ($DryRun) {
    $script:BuildPublicDataAction = "dry-run manifest"
    & $publisherPath -Mode Full -DryRun -ManifestOnly
  } else {
    $script:BuildPublicDataAction = "write"
    & $publisherPath -Mode Full
  }
}

if ($Mode -eq "PublicDataOnly") {
  if ($NoPublicData) {
    throw "-Mode PublicDataOnly cannot be combined with -NoPublicData."
  }
  Invoke-PublicDataPublisherForBuild
  Write-Host ("Build-site public-data-only completed. RunId: {0}; DryRun: {1}" -f $runId, [bool]$DryRun)
  return
}

Invoke-PublicDataPublisherForBuild

function RequireBuildJson($path, $label) {
  if (-not (Test-BuildInputExists $path)) {
    throw "Required build source is missing: $label ($path)"
  }
}

function ReadBuildJson($path, $defaultValue) {
  if (-not (Test-BuildInputExists $path)) { return $defaultValue }
  $raw = Read-BuildInputRaw $path
  if ([string]::IsNullOrWhiteSpace($raw)) { return $defaultValue }
  return $raw | ConvertFrom-Json
}

function BuildArray($value) {
  if ($null -eq $value) { return @() }
  return @($value | ForEach-Object { $_ })
}
if ($script:BuildFixtureMode) {
  $carsPath = $script:BuildFixtureCarsPath
  Add-BuildSource $carsPath "fixture current-cars" "fixture-source"
  RequireBuildJson $carsPath "fixture current-cars"
  $cars = BuildArray (ReadBuildJson $carsPath @())
} else {
  $carsPath = Join-Path $root "private/rent-rk-data/current-cars.json"
  Add-BuildSource $carsPath "private current-cars" "private-source"
  RequireBuildJson $carsPath "private current-cars"
  $cars = BuildArray (ReadBuildJson $carsPath @())
}
$script:carsBySlug = @{}
foreach ($car in $cars) {
  if (-not [string]::IsNullOrWhiteSpace([string]$car.slug)) {
    $script:carsBySlug[[string]$car.slug] = $car
  }
}
if ($script:BuildFixtureMode) {
  $carPageContentPath = $script:BuildFixtureCarPageContentPath
  if (-not [string]::IsNullOrWhiteSpace($carPageContentPath)) {
    Add-BuildSource $carPageContentPath "fixture car page content" "fixture-source"
  }
  $carPageContentData = if ([string]::IsNullOrWhiteSpace($carPageContentPath)) {
    [pscustomobject]@{ version = 1; items = [pscustomobject]@{} }
  } else {
    ReadBuildJson $carPageContentPath ([pscustomobject]@{ version = 1; items = [pscustomobject]@{} })
  }
} else {
  $carPageContentPath = Join-Path $privateDataDir "car-page-content.json"
  Add-BuildSource $carPageContentPath "private car page content" "private-source"
  $carPageContentData = ReadBuildJson $carPageContentPath ([pscustomobject]@{ version = 1; items = [pscustomobject]@{} })
}
$script:carPageContentItems = if ($null -ne $carPageContentData.items) { $carPageContentData.items } else { [pscustomobject]@{} }
if ($script:BuildFixtureMode) {
  $routesPath = ""
  $routeItems = @()
} else {
  $routesPath = Join-Path $root "data/routes.json"
  Add-BuildSource $routesPath "public routes source" "public-source-dependency"
  RequireBuildJson $routesPath "public routes source"
  $routeItems = BuildArray (ReadBuildJson $routesPath @())
}
$partnersPath = Join-Path $root "private/rent-rk-data/partners.json"
$partnerItems = @()
if ($script:BuildFixtureMode) {
  $partnerItems = @()
} elseif (Test-BuildInputExists $partnersPath) {
  Add-BuildSource $partnersPath "private partners" "private-source"
  try {
    $partnerData = ReadBuildJson $partnersPath ([pscustomobject]@{ items = @() })
    if ($null -ne $partnerData.items) {
      $partnerItems = @($partnerData.items | Where-Object { $_.active -and -not [string]::IsNullOrWhiteSpace([string]$_.slug) })
    }
  } catch {
    $partnerItems = @()
  }
} else {
  Add-BuildSource $partnersPath "private partners" "private-source"
  Write-Warning "Private partners source is missing; partner pages will be skipped."
}
$adminUsersPath = Join-Path $root "private/rent-rk-data/admin-users.json"
$partnerUsers = @()
if ($script:BuildFixtureMode) {
  $partnerUsers = @()
} elseif (Test-BuildInputExists $adminUsersPath) {
  Add-BuildSource $adminUsersPath "private admin-users" "private-source"
  try {
    $adminUsersData = ReadBuildJson $adminUsersPath ([pscustomobject]@{ users = @() })
    if ($null -ne $adminUsersData.users) {
      $partnerUsers = @($adminUsersData.users | Where-Object {
        $login = [string]$_.login
        $_.active `
          -and $_.role -eq "partner" `
          -and -not [string]::IsNullOrWhiteSpace([string]$_.partnerSlug) `
          -and -not $login.StartsWith("qa-", [System.StringComparison]::OrdinalIgnoreCase)
      })
    }
  } catch {
    $partnerUsers = @()
  }
} else {
  Add-BuildSource $adminUsersPath "private admin-users" "private-source"
  Write-Warning "Private admin-users source is missing; partner agent pages will be skipped."
}
$lessorsPath = Join-Path $root "private/rent-rk-data/lessors.json"
$script:lessorsByScope = @{}
if ($script:BuildFixtureMode) {
  $script:lessorsByScope = @{}
} elseif (-not (Test-BuildInputExists $lessorsPath)) {
  Add-BuildSource $lessorsPath "private lessors" "private-source"
  Write-Warning "Private lessors source is missing; lessor publication visibility will use defaults."
} else {
  Add-BuildSource $lessorsPath "private lessors" "private-source"
}
$accessRulesPath = Join-Path $root "private/rent-rk-data/access-rules.json"
$accessRuleItems = @()
if ($script:BuildFixtureMode) {
  $accessRuleItems = @()
} elseif (Test-BuildInputExists $accessRulesPath) {
  Add-BuildSource $accessRulesPath "private access-rules" "private-source"
  try {
    $accessRulesData = ReadBuildJson $accessRulesPath ([pscustomobject]@{ items = @() })
    if ($null -ne $accessRulesData.items) {
      $accessRuleItems = @($accessRulesData.items)
    }
  } catch {
    $accessRuleItems = @()
  }
} else {
  Add-BuildSource $accessRulesPath "private access-rules" "private-source"
}
$script:ratesByCar = @{}
if ($script:BuildFixtureMode) {
  $ratesPath = $script:BuildFixtureRatesPath
  if (-not [string]::IsNullOrWhiteSpace($ratesPath)) {
    Add-BuildSource $ratesPath "fixture rates" "fixture-source"
    $ratesData = ReadBuildJson $ratesPath ([pscustomobject]@{ cars = @{} })
    if ($null -ne $ratesData.cars) {
      foreach ($prop in $ratesData.cars.PSObject.Properties) {
        $script:ratesByCar[$prop.Name] = $prop.Value
      }
    }
  }
} else {
  $ratesPath = Join-Path $root "private/rent-rk-data/rates.json"
  Add-BuildSource $ratesPath "private rates" "private-source"
  RequireBuildJson $ratesPath "private rates"
  try {
    $ratesData = ReadBuildJson $ratesPath ([pscustomobject]@{ cars = @{} })
    if ($null -ne $ratesData.cars) {
      foreach ($prop in $ratesData.cars.PSObject.Properties) {
        $script:ratesByCar[$prop.Name] = $prop.Value
      }
    }
  } catch {
    $script:ratesByCar = @{}
  }
}

$callbackSettingsPath = Join-Path $root "private/rent-rk-data/callback-settings.json"
$script:callbackSettings = [pscustomobject]@{
  rent_rk = [pscustomobject]@{
    callback_enabled = $false
    default_delay_seconds = 60
    default_title = "Помочь с выбором автомобиля?"
    default_text = "Оставьте номер — менеджер подскажет свободные варианты и условия аренды."
    default_button_text = "Перезвоните мне"
    success_text = "Заявка принята. Менеджер свяжется с вами."
    repeat_policy = "daily"
  }
  parks = [pscustomobject]@{}
}
if ($script:BuildFixtureMode) {
  $script:callbackSettings = $script:callbackSettings
} elseif (Test-BuildInputExists $callbackSettingsPath) {
  Add-BuildSource $callbackSettingsPath "private callback-settings" "private-source"
  try {
    $script:callbackSettings = ReadBuildJson $callbackSettingsPath $script:callbackSettings
  } catch {
    Write-Warning "Callback settings are invalid; public callback widget will be disabled."
  }
} else {
  Add-BuildSource $callbackSettingsPath "private callback-settings" "private-source"
}

$phoneHuman = "+7 (978) 948-51-11"
$phoneHref = "tel:+79789485111"
$telegram = "https://t.me/spok2003"
$yandexMapUrl = "https://yandex.ru/maps/-/CPS5nP-P"
$yandexMapEmbed = "https://yandex.ru/map-widget/v1/?ll=34.169443%2C44.506351&amp;mode=poi&amp;poi%5Bpoint%5D=34.169362%2C44.505843&amp;poi%5Buri%5D=ymapsbm1%3A%2F%2Forg%3Foid%3D134040500420&amp;z=16"
$siteBaseUrl = "https://base-rent.ru"
$defaultOgImage = "assets/img/cars/mercedes-benz-c300/mercedes-benz-c300-1.jpg"
$script:ImageDimensionCache = @{}
try {
  Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
} catch {
  Write-Warning "System.Drawing is unavailable; generated image width/height attributes will be skipped."
}

function RelPath($depth, $path) {
  if ($depth -eq 0) { return $path }
  return ("../" * $depth) + $path
}

function VersionedAssetPath($depth, $path) {
  $assetPath = RelPath $depth $path
  $localPath = Join-Path $root ($path -replace '/', [System.IO.Path]::DirectorySeparatorChar)
  $version = $runId
  if (Test-Path -LiteralPath $localPath) {
    $version = (Get-Item -LiteralPath $localPath).LastWriteTimeUtc.ToString("yyyyMMddHHmmss")
  }
  return "${assetPath}?v=$version"
}

function Test-ExternalAssetPath($path) {
  $value = [string]$path
  return ($value -match '(?i)^https?://' -or $value -match '^//' -or $value -match '(?i)^data:image/')
}

function NormalizeAssetWebPath($path) {
  $raw = ([string]$path).Trim()
  if ([string]::IsNullOrWhiteSpace($raw)) { return "" }

  $value = $raw.Replace("\", "/")
  if ($value -match '(?i)^file://') {
    throw "Local file URLs are not allowed in generated HTML: $raw"
  }
  if (Test-ExternalAssetPath $value) { return $value }

  if ($value -match '^[A-Za-z]:/') {
    $fullPath = [System.IO.Path]::GetFullPath($value)
    return Get-BuildRelativePathFromFullPath $root $fullPath
  }

  if ($value -match '(?i)(^|/|\.\./)[A-Za-z]:/' -or
      $value -match '(?i):/Users/' -or
      $value -match '(?i)^/Users/' -or
      $value -match '(?i)Documents/Codex') {
    throw "Local filesystem paths are not allowed in generated HTML: $raw"
  }

  if ($value -match '(^|/)\.\.(/|$)') {
    throw "Parent-directory asset paths are not allowed in generated HTML: $raw"
  }

  return $value.TrimStart("/")
}

function RelAssetPath($depth, $path) {
  $value = NormalizeAssetWebPath $path
  if (Test-ExternalAssetPath $value) { return $value }
  return RelPath $depth $value
}

function ImageDimensionAttrs($path) {
  $value = NormalizeAssetWebPath $path
  if ([string]::IsNullOrWhiteSpace($value) -or (Test-ExternalAssetPath $value)) { return "" }
  if ($script:ImageDimensionCache.ContainsKey($value)) { return $script:ImageDimensionCache[$value] }

  $attrs = ""
  $fullPath = Join-Path $root $value
  if (Test-Path -LiteralPath $fullPath) {
    $image = $null
    try {
      $image = [System.Drawing.Image]::FromFile($fullPath)
      $attrs = (" width=""{0}"" height=""{1}""" -f $image.Width, $image.Height)
    } catch {
      $attrs = ""
    } finally {
      if ($null -ne $image) { $image.Dispose() }
    }
  }

  $script:ImageDimensionCache[$value] = $attrs
  return $attrs
}

function CallbackDelay($value, $fallback = 60) {
  $delay = 0
  if ([int]::TryParse([string]$value, [ref]$delay) -and $delay -ge 15) {
    return [Math]::Min($delay, 86400)
  }
  if ($fallback -ge 15) { return [int]$fallback }
  return 60
}

function CallbackRepeatPolicy($value) {
  $policy = [string]$value
  if (@("session", "daily", "days") -contains $policy) { return $policy }
  return "daily"
}

function CallbackText($value, $fallback) {
  if ([string]::IsNullOrWhiteSpace([string]$value)) { return $fallback }
  return [string]$value
}

function CallbackGlobalSettings() {
  $global = $script:callbackSettings.rent_rk
  if ($null -eq $global) { $global = [pscustomobject]@{} }
  return [pscustomobject]@{
    callback_enabled = [bool]$global.callback_enabled
    default_delay_seconds = CallbackDelay $global.default_delay_seconds 60
    default_title = CallbackText $global.default_title "Помочь с выбором автомобиля?"
    default_text = CallbackText $global.default_text "Оставьте номер — менеджер подскажет свободные варианты и условия аренды."
    default_button_text = CallbackText $global.default_button_text "Перезвоните мне"
    success_text = CallbackText $global.success_text "Заявка принята. Менеджер свяжется с вами."
    repeat_policy = CallbackRepeatPolicy $global.repeat_policy
  }
}

function CallbackParkSettings($scopeId) {
  $scopeId = [string]$scopeId
  $park = $null
  if ($null -ne $script:callbackSettings.parks) {
    $prop = $script:callbackSettings.parks.PSObject.Properties[$scopeId]
    if ($null -ne $prop) { $park = $prop.Value }
  }
  if ($null -eq $park) { $park = [pscustomobject]@{} }
  $mode = [string]$park.callback_mode
  if (@("rent_rk_default", "park_own", "disabled") -notcontains $mode) { $mode = "rent_rk_default" }
  return [pscustomobject]@{
    callback_mode = $mode
    park_callback_enabled = if ($null -eq $park.park_callback_enabled) { $true } else { [bool]$park.park_callback_enabled }
    allow_park_text_edit = [bool]$park.allow_park_text_edit
    delay_seconds = CallbackDelay $park.delay_seconds 60
    park_title = CallbackText $park.park_title "Помочь с выбором автомобиля?"
    park_text = CallbackText $park.park_text "Оставьте номер — менеджер парка подскажет свободные варианты и условия аренды."
    park_button_text = CallbackText $park.park_button_text "Перезвоните мне"
    repeat_policy = CallbackRepeatPolicy $park.repeat_policy
  }
}

function CallbackContextForPage($relativePath, $isPartnerPage, $depth) {
  if ($isPartnerPage) { return $null }
  $global = CallbackGlobalSettings
  $apiUrl = RelPath $depth "api/callback.php"
  $pageType = "unknown"
  $car = $null
  $carSlug = ""
  if ($relativePath -match '^cars/([^/]+)\.html$') {
    $carSlug = $matches[1]
    if ($script:carsBySlug.ContainsKey($carSlug)) { $car = $script:carsBySlug[$carSlug] }
    $pageType = "car_page"
  } elseif (@("index.html", "cars/index.html") -contains $relativePath) {
    $pageType = "main_showcase"
  } else {
    return $null
  }

  $context = [ordered]@{
    can_show = $false
    source_page_type = $pageType
    callback_mode = "disabled"
    delay_seconds = 60
    repeat_policy = "daily"
    car_id = ""
    car_title = ""
    api_url = $apiUrl
    texts = [ordered]@{
      title = $global.default_title
      text = $global.default_text
      button_text = $global.default_button_text
      success_text = $global.success_text
    }
  }

  if ($pageType -eq "main_showcase") {
    $context.can_show = [bool]$global.callback_enabled
    $context.callback_mode = "rent_rk_own"
    $context.delay_seconds = $global.default_delay_seconds
    $context.repeat_policy = $global.repeat_policy
    return $context
  }

  if ($null -eq $car) { return $null }
  $ownerScopeId = if ([string]::IsNullOrWhiteSpace([string]$car.owner_scope_id)) { "rent_rk" } else { [string]$car.owner_scope_id }
  $context.car_id = $carSlug
  $context.car_title = [string]$car.name
  if ($ownerScopeId -eq "rent_rk") {
    $context.can_show = [bool]$global.callback_enabled
    $context.callback_mode = "rent_rk_own"
    $context.delay_seconds = $global.default_delay_seconds
    $context.repeat_policy = $global.repeat_policy
    return $context
  }

  $park = CallbackParkSettings $ownerScopeId
  if ($park.callback_mode -eq "disabled") {
    return $null
  }
  if ($park.callback_mode -eq "park_own") {
    $context.can_show = [bool]$park.park_callback_enabled
    $context.callback_mode = "park_own"
    $context.delay_seconds = $park.delay_seconds
    $context.repeat_policy = $park.repeat_policy
    $context.texts.title = $park.park_title
    $context.texts.text = $park.park_text
    $context.texts.button_text = $park.park_button_text
    return $context
  }

  $context.can_show = [bool]$global.callback_enabled
  $context.callback_mode = "rent_rk_default"
  $context.delay_seconds = $park.delay_seconds
  $context.repeat_policy = $park.repeat_policy
  return $context
}

function CallbackContextHtml($relativePath, $isPartnerPage, $depth) {
  $context = CallbackContextForPage $relativePath $isPartnerPage $depth
  if ($null -eq $context -or -not [bool]$context.can_show) { return "" }
  $json = $context | ConvertTo-Json -Depth 8 -Compress
  $json = $json -replace "</script>", "<\/script>"
  return "  <script type=""application/json"" id=""rent-rk-callback-context"">$json</script>"
}

function RateValue($value) {
  if ($null -eq $value -or "$value" -eq "") { return $null }
  return [int]$value
}

function CarDisplayPrice($car) {
  if ($script:ratesByCar.ContainsKey([string]$car.slug)) {
    $rate = $script:ratesByCar[[string]$car.slug]
    $manual = RateValue $rate.manual
    if ($null -ne $manual) { return $manual }
    $base = RateValue $rate.base
    if ($null -ne $base) { return $base }
  }

  return RateValue $car.price
}

function PriceText($price) {
  if ($null -eq $price) { return "Цена уточняется" }
  return "от " + ([int]$price).ToString("N0").Replace(",", " ") + " р./сутки"
}

function CarDepositAmount($car) {
  if ($null -eq $car) { return $null }
  $slug = [string]$car.slug
  if (-not [string]::IsNullOrWhiteSpace($slug) -and $script:ratesByCar.ContainsKey($slug)) {
    $deposit = RateValue $script:ratesByCar[$slug].depositAmount
    if ($null -ne $deposit) { return $deposit }
  }

  $carDepositProp = $car.PSObject.Properties["depositAmount"]
  if ($null -ne $carDepositProp) {
    $deposit = RateValue $carDepositProp.Value
    if ($null -ne $deposit) { return $deposit }
  }

  return $null
}

function DepositText($depositAmount) {
  if ($null -eq $depositAmount) { return "" }
  return "Залог: " + ([int]$depositAmount).ToString("N0").Replace(",", " ") + " ₽"
}

function HtmlAttr($text) {
  return [System.Net.WebUtility]::HtmlEncode([string]$text)
}

function CarOptionalText($car, $field) {
  if ($null -eq $car -or [string]::IsNullOrWhiteSpace([string]$field)) { return "" }
  $prop = $car.PSObject.Properties[[string]$field]
  if ($null -eq $prop -or $null -eq $prop.Value) { return "" }
  return ([string]$prop.Value).Trim()
}

function CarCardTextIsUsable($value) {
  $text = ([string]$value).Trim()
  if ([string]::IsNullOrWhiteSpace($text)) { return $false }
  $normalized = ([regex]::Replace($text, "\s+", " ")).Trim().Trim(".", ",", ";", ":").ToLowerInvariant()
  return @("уточняется", "-", "—", "null") -notcontains $normalized
}

function CarCardFactText($value) {
  $text = ([regex]::Replace(([string]$value).Trim(), "\s+", " ")).Trim()
  if (CarCardTextIsUsable $text) { return $text }
  return ""
}

function CarCardFieldFact($car, $field) {
  return CarCardFactText (CarOptionalText $car $field)
}

$script:CarBodyTypeOptions = [ordered]@{
  sedan = [ordered]@{ label = "Седан"; group = "Легковые"; sort = 10 }
  hatchback = [ordered]@{ label = "Хэтчбек"; group = "Легковые"; sort = 20 }
  liftback = [ordered]@{ label = "Лифтбек"; group = "Легковые"; sort = 30 }
  wagon = [ordered]@{ label = "Универсал"; group = "Легковые"; sort = 40 }
  coupe = [ordered]@{ label = "Купе"; group = "Легковые"; sort = 50 }
  convertible = [ordered]@{ label = "Кабриолет"; group = "Легковые"; sort = 60 }
  crossover = [ordered]@{ label = "Кроссовер"; group = "Внедорожники"; sort = 70 }
  suv = [ordered]@{ label = "Внедорожник"; group = "Внедорожники"; sort = 80 }
  minivan = [ordered]@{ label = "Минивэн"; group = "Коммерческие и семейные"; sort = 90 }
  van = [ordered]@{ label = "Фургон"; group = "Коммерческие и семейные"; sort = 100 }
  pickup = [ordered]@{ label = "Пикап"; group = "Коммерческие и семейные"; sort = 110 }
}

$script:CarFuelTypeOptions = [ordered]@{
  petrol = [ordered]@{ label = "Бензин"; group = "ДВС"; sort = 10 }
  diesel = [ordered]@{ label = "Дизель"; group = "ДВС"; sort = 20 }
  hybrid = [ordered]@{ label = "Гибрид"; group = "Гибрид"; sort = 30 }
  plug_in_hybrid = [ordered]@{ label = "Подключаемый гибрид"; group = "Гибрид"; sort = 40 }
  electric = [ordered]@{ label = "Электро"; group = "Электро"; sort = 50 }
  gas = [ordered]@{ label = "Газ"; group = "Альтернативное"; sort = 60 }
}

$script:CarEquipmentOptions = [ordered]@{
  air_conditioning = [ordered]@{ label = "Кондиционер"; group = "Комфорт"; sort = 10 }
  climate_control = [ordered]@{ label = "Климат-контроль"; group = "Комфорт"; sort = 20 }
  heated_seats = [ordered]@{ label = "Подогрев сидений"; group = "Комфорт"; sort = 30 }
  keyless_entry = [ordered]@{ label = "Бесключевой доступ"; group = "Комфорт"; sort = 40 }
  panoramic_roof = [ordered]@{ label = "Люк / панорамная крыша"; group = "Комфорт"; sort = 50 }
  rear_camera = [ordered]@{ label = "Камера заднего вида"; group = "Помощь водителю"; sort = 60 }
  parking_sensors = [ordered]@{ label = "Парктроники"; group = "Помощь водителю"; sort = 70 }
  cruise_control = [ordered]@{ label = "Круиз-контроль"; group = "Помощь водителю"; sort = 80 }
  navigation = [ordered]@{ label = "Навигация"; group = "Мультимедиа"; sort = 90 }
  bluetooth = [ordered]@{ label = "Bluetooth"; group = "Мультимедиа"; sort = 100 }
  apple_carplay = [ordered]@{ label = "Apple CarPlay"; group = "Мультимедиа"; sort = 110 }
  android_auto = [ordered]@{ label = "Android Auto"; group = "Мультимедиа"; sort = 120 }
  isofix = [ordered]@{ label = "Крепления ISOFIX"; group = "Семья"; sort = 130 }
  winter_tires = [ordered]@{ label = "Зимние шины"; group = "Сезонное"; sort = 140 }
}

function CarDictionaryCode($value) {
  $code = ([string]$value).Trim().ToLowerInvariant()
  $code = [regex]::Replace($code, "[^a-z0-9_]+", "_")
  return $code.Trim("_")
}

function CarStructuredText($value) {
  $text = [regex]::Replace([string]$value, "(?is)<(script|style)\b[^>]*>.*?</\1>", " ")
  $withoutMarkup = [regex]::Replace($text, "<[^>]+>", " ")
  return CarCardFactText $withoutMarkup
}

function CarStructuredField($car, $field) {
  return CarStructuredText (CarOptionalText $car $field)
}

function CarStructuredInt($car, $field) {
  $raw = CarStructuredField $car $field
  $value = 0
  if ([int]::TryParse($raw, [ref]$value)) { return $value }
  return $null
}

function CarStructuredFloatText($car, $field) {
  $raw = (CarStructuredField $car $field).Replace(",", ".")
  $value = 0.0
  if ([double]::TryParse($raw, [System.Globalization.NumberStyles]::Float, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$value)) {
    return $value.ToString("0.#", [System.Globalization.CultureInfo]::InvariantCulture)
  }
  return ""
}

function CarDictionaryLabel($options, $code) {
  $normalized = CarDictionaryCode $code
  if ([string]::IsNullOrWhiteSpace($normalized)) { return "" }
  if (-not $options.Contains($normalized)) { return "" }
  return CarStructuredText $options[$normalized].label
}

function CarBodyTypeCode($car) {
  $code = CarDictionaryCode (CarOptionalText $car "bodyType")
  if ($script:CarBodyTypeOptions.Contains($code)) { return $code }
  return ""
}

function CarBodyTypeLabel($car) {
  return CarDictionaryLabel $script:CarBodyTypeOptions (CarBodyTypeCode $car)
}

function CarFuelTypeCode($car) {
  $code = CarDictionaryCode (CarOptionalText $car "fuelType")
  if ($script:CarFuelTypeOptions.Contains($code)) { return $code }
  return ""
}

function CarFuelTypeLabel($car) {
  return CarDictionaryLabel $script:CarFuelTypeOptions (CarFuelTypeCode $car)
}

function CarStructuredYearText($car) {
  $year = CarStructuredInt $car "year"
  if ($null -eq $year) { return "" }
  if ($year -lt 1900 -or $year -gt ([int](Get-Date).Year + 2)) { return "" }
  return [string]$year
}

function CarStructuredEquipmentCodes($car) {
  $prop = if ($null -ne $car) { $car.PSObject.Properties["equipment"] } else { $null }
  if ($null -eq $prop -or $null -eq $prop.Value) { return @() }

  $rawItems = if ($prop.Value -is [string]) {
    @($prop.Value -split "[,;`r`n]+")
  } else {
    @($prop.Value | ForEach-Object {
      if ($null -eq $_) { "" }
      elseif ($_ -is [string]) { $_ }
      elseif ($_.PSObject.Properties["code"]) { $_.code }
      elseif ($_.PSObject.Properties["key"]) { $_.key }
      elseif ($_.PSObject.Properties["value"]) { $_.value }
      else { "" }
    })
  }

  $selected = @{}
  foreach ($item in $rawItems) {
    $code = CarDictionaryCode $item
    if (-not [string]::IsNullOrWhiteSpace($code) -and $script:CarEquipmentOptions.Contains($code)) {
      $selected[$code] = $true
    }
  }

  $codes = @()
  foreach ($code in $script:CarEquipmentOptions.Keys) {
    if ($selected.ContainsKey($code)) { $codes += [string]$code }
  }
  return $codes
}

function CarEquipmentPublicItems($car) {
  return @(CarStructuredEquipmentCodes $car | ForEach-Object {
    $option = $script:CarEquipmentOptions[$_]
    [pscustomobject]@{
      code = [string]$_
      label = CarStructuredText $option.label
      group = CarStructuredText $option.group
      sort = [int]$option.sort
    }
  })
}

function CarEquipmentSpecGroupHtml($car) {
  $items = @(CarEquipmentPublicItems $car)
  if ($items.Count -eq 0) { return "" }

  $rows = @()
  foreach ($group in @($items | Group-Object group | Sort-Object { ($_.Group | Select-Object -First 1).sort })) {
    $labels = @($group.Group | Sort-Object sort | ForEach-Object { $_.label })
    if ($labels.Count -gt 0) {
      $rows += CarSpecRow ([string]$group.Name) (($labels | ForEach-Object { [string]$_ }) -join ", ")
    }
  }

  return CarSpecGroupHtml "Оснащение" $rows
}

function CarExtraSpecRows($car) {
  $prop = if ($null -ne $car) { $car.PSObject.Properties["extraSpecs"] } else { $null }
  if ($null -eq $prop -or $null -eq $prop.Value) { return @() }

  $rows = @()
  $position = 0
  foreach ($item in @($prop.Value)) {
    if ($null -eq $item) { continue }
    $label = CarStructuredText $item.label
    $value = CarStructuredText $item.value
    $unit = CarStructuredText $item.unit
    if (-not (CarCardTextIsUsable $label) -or -not (CarCardTextIsUsable $value)) { continue }
    $position += 1
    $sort = $position * 10
    $rawSort = CarStructuredText $item.sort
    $parsedSort = 0
    if ([int]::TryParse($rawSort, [ref]$parsedSort)) { $sort = $parsedSort }
    $key = CarDictionaryCode $item.key
    if ([string]::IsNullOrWhiteSpace($key)) { $key = "spec_$position" }
    $displayValue = if (CarCardTextIsUsable $unit) { "$value $unit" } else { $value }
    $rows += [pscustomobject]@{
      sort = $sort
      key = $key
      html = CarSpecRow $label $displayValue
    }
    if ($rows.Count -ge 20) { break }
  }

  return @($rows | Sort-Object sort, key | ForEach-Object { $_.html })
}

function CarExtraSpecsGroupHtml($car) {
  return CarSpecGroupHtml "Дополнительные характеристики" (CarExtraSpecRows $car)
}

function CarStructuredSpecRows($car) {
  $rows = @()
  $rows += CarSpecRow "Марка" (CarStructuredField $car "brand")
  $rows += CarSpecRow "Модель" (CarStructuredField $car "model")
  $rows += CarSpecRow "Год" (CarStructuredYearText $car)
  $rows += CarSpecRow "Поколение" (CarStructuredField $car "generation")
  $rows += CarSpecRow "Комплектация" (CarStructuredField $car "trim")
  $rows += CarSpecRow "Тип кузова" (CarBodyTypeLabel $car)
  $rows += CarSpecRow "Тип топлива" (CarFuelTypeLabel $car)
  $rows += CarSpecRow "Цвет" (CarStructuredField $car "color")
  $doors = CarStructuredInt $car "doors"
  if ($null -ne $doors) { $rows += CarSpecRow "Дверей" ([string]$doors) }
  $power = CarStructuredInt $car "enginePowerHp"
  if ($null -ne $power) { $rows += CarSpecRow "Мощность" "$power л.с." }
  $displacement = CarStructuredFloatText $car "engineDisplacementL"
  if (CarCardTextIsUsable $displacement) { $rows += CarSpecRow "Объём двигателя" "$displacement л" }
  $range = CarStructuredInt $car "electricRangeKm"
  if ($null -ne $range) { $rows += CarSpecRow "Запас хода" "$range км" }
  return @($rows | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
}

function CarStructuredDataAttributes($car) {
  $year = HtmlAttr (CarStructuredYearText $car)
  $bodyType = HtmlAttr (CarBodyTypeCode $car)
  $fuelType = HtmlAttr (CarFuelTypeCode $car)
  $equipment = HtmlAttr ((CarStructuredEquipmentCodes $car) -join ",")
  return " data-year=""$year"" data-body-type=""$bodyType"" data-fuel-type=""$fuelType"" data-equipment=""$equipment"""
}

function CarTextContainsNormalized($text, $needle) {
  $left = (CarStructuredText $text).ToLowerInvariant()
  $right = (CarStructuredText $needle).ToLowerInvariant()
  if ([string]::IsNullOrWhiteSpace($left) -or [string]::IsNullOrWhiteSpace($right)) { return $false }
  return $left.Contains($right)
}

function CarCatalogStructuredSubtitle($car) {
  $name = [string]$car.name
  $identity = @()
  foreach ($field in @("brand", "model")) {
    $value = CarStructuredField $car $field
    if ((CarCardTextIsUsable $value) -and -not (CarTextContainsNormalized $name $value)) {
      $identity += $value
    }
  }
  $year = CarStructuredYearText $car
  if ((CarCardTextIsUsable $year) -and -not (CarTextContainsNormalized $name $year)) {
    $identity += $year
  }
  $specs = @($identity)
  foreach ($value in @((CarBodyTypeLabel $car), (CarFuelTypeLabel $car))) {
    if (CarCardTextIsUsable $value) { $specs += $value }
  }

  return (($specs | Select-Object -Unique) -join " · ")
}

function CarOptionalArray($car, $field, $limit = 8) {
  if ($null -eq $car -or [string]::IsNullOrWhiteSpace([string]$field)) { return @() }
  $prop = $car.PSObject.Properties[[string]$field]
  if ($null -eq $prop -or $null -eq $prop.Value) { return @() }

  $items = @()
  if ($prop.Value -is [string]) {
    $items = @(($prop.Value -split "`r?`n|,") | ForEach-Object { CarCardFactText $_ })
  } else {
    $items = @($prop.Value | ForEach-Object { CarCardFactText $_ })
  }

  return @($items | Where-Object { CarCardTextIsUsable $_ } | Select-Object -Unique | Select-Object -First $limit)
}

function ShortCarText($value, $limit = 180) {
  $text = CarCardFactText $value
  if (-not (CarCardTextIsUsable $text)) { return "" }
  if ($text.Length -le $limit) { return $text }
  $cut = $text.Substring(0, [Math]::Max(0, $limit - 1)).Trim()
  $lastSpace = $cut.LastIndexOf(" ")
  if ($lastSpace -gt 80) {
    $cut = $cut.Substring(0, $lastSpace).Trim()
  }
  return $cut.TrimEnd(".", ",", ";", ":") + "..."
}

function CarSpecialRentalTerms($car) {
  if ($null -eq $car) { return $null }
  $prop = $car.PSObject.Properties["specialRentalTerms"]
  if ($null -eq $prop -or $null -eq $prop.Value) { return $null }
  if ($prop.Value.PSObject.Properties.Name -contains "enabled" -and [bool]$prop.Value.enabled) {
    return $prop.Value
  }
  return $null
}

$script:catalogCommonConditions = [ordered]@{
  minRental = "Посуточная аренда — от 1 суток"
  yaltaDelivery = "Подача по Ялте — бесплатно"
  crimeaDelivery = "Подача по Крыму — по договорённости"
}

function CarConditionKey($value) {
  $text = CarCardFactText $value
  $text = $text.ToLowerInvariant().Replace("ё", "е")
  $text = [regex]::Replace($text, "[—–-]", " ")
  $text = [regex]::Replace($text, "[^\p{L}\p{N}]+", " ")
  return ([regex]::Replace($text, "\s+", " ")).Trim()
}

function CarConditionMatchesAny($value, $defaults) {
  $key = CarConditionKey $value
  if ([string]::IsNullOrWhiteSpace($key)) { return $false }
  foreach ($default in @($defaults)) {
    if ($key -eq (CarConditionKey $default)) { return $true }
  }
  return $false
}

function ShortMinRentalCondition($value) {
  $text = CarCardFactText $value
  if (-not (CarCardTextIsUsable $text)) { return "" }
  $match = [regex]::Match($text, "от\s+(\d+)\s+сут", [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
  if ($match.Success) { return "от $($match.Groups[1].Value) суток" }
  $text = [regex]::Replace($text, "^(минимум|минимальный срок аренды|минимальный срок)\s*[:—-]\s*", "", [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
  return $text.Trim()
}

function ShortDeliveryCondition($value) {
  $text = CarCardFactText $value
  if (-not (CarCardTextIsUsable $text)) { return "" }
  $text = [regex]::Replace($text, "^подача\s+автомобиля\s+", "подача ", [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
  $text = [regex]::Replace($text, "^доставка\s+", "подача ", [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
  if ($text -like "Подача*") {
    return $text.Substring(0, 1).ToLowerInvariant() + $text.Substring(1)
  }
  return $text
}

function NumericCarOptionalValue($car, $fields) {
  foreach ($field in @($fields)) {
    $raw = CarOptionalText $car $field
    $number = 0
    if ([int]::TryParse([string]$raw, [ref]$number)) { return $number }
  }
  return $null
}

function GetCarMinRentalException($car) {
  $specialTerms = CarSpecialRentalTerms $car
  if ($null -ne $specialTerms) {
    $specialDays = NumericCarOptionalValue $specialTerms @("minDays", "minRentalDays")
    if ($null -ne $specialDays) {
      if ($specialDays -gt 1) { return "от $specialDays суток" }
      return ""
    }
  }

  $days = NumericCarOptionalValue $car @("minRentalDays", "minimumRentalDays")
  if ($null -ne $days) {
    if ($days -gt 1) { return "от $days суток" }
    return ""
  }

  $text = ""
  foreach ($field in @("minRentalText", "minRental", "minimumRentalText")) {
    $text = CarCardFieldFact $car $field
    if (CarCardTextIsUsable $text) { break }
  }
  if (-not (CarCardTextIsUsable $text)) { return "" }
  if (CarConditionMatchesAny $text @("Минимум: от 1 суток", $script:catalogCommonConditions.minRental, "от 1 суток")) { return "" }
  return ShortMinRentalCondition $text
}

function GetCarMinimumRentalText($car) {
  if ($null -eq $car) { return "от 1 суток" }

  if ([bool]$car.hourlyAvailable) {
    $hours = NumericCarOptionalValue $car @("minRentalHours", "minimumRentalHours")
    if ($null -eq $hours -or $hours -lt 1) { $hours = 1 }
    return "от $hours $(RuPlural $hours "часа" "часов" "часов")"
  }

  $exception = GetCarMinRentalException $car
  if (CarCardTextIsUsable $exception) { return $exception }
  return "от 1 суток"
}

function GetCarMinimumRentalCondition($car) {
  return "Минимальный срок — " + (GetCarMinimumRentalText $car)
}

function GetCarDeliveryExceptions($car) {
  $exceptions = @()
  $specialTerms = CarSpecialRentalTerms $car

  $yaltaFee = NumericCarOptionalValue $car @("yaltaDeliveryPrice", "deliveryYaltaPrice", "deliveryFeeYalta")
  if ($null -ne $yaltaFee) {
    if ($yaltaFee -gt 0) { $exceptions += "подача по Ялте $yaltaFee ₽" }
  } else {
    foreach ($field in @("deliveryText", "deliveryYaltaText", "yaltaDeliveryText", "deliveryInYaltaText")) {
      $text = CarCardFieldFact $car $field
      if (-not (CarCardTextIsUsable $text)) { continue }
      if (CarConditionMatchesAny $text @("Подача по Ялте бесплатно", $script:catalogCommonConditions.yaltaDelivery, "бесплатная подача по Ялте")) { continue }
      $exceptions += (ShortDeliveryCondition $text)
      break
    }
  }

  foreach ($field in @("crimeaDeliveryText", "deliveryCrimeaText", "deliveryZoneText")) {
    $text = CarCardFieldFact $car $field
    if (-not (CarCardTextIsUsable $text)) { continue }
    if (CarConditionMatchesAny $text @($script:catalogCommonConditions.crimeaDelivery, "Подача по Крыму по договоренности")) { continue }
    $exceptions += (ShortDeliveryCondition $text)
    break
  }

  if ($null -ne $specialTerms) {
    $specialDelivery = CarCardFactText (CarOptionalText $specialTerms "deliveryText")
    if ((CarCardTextIsUsable $specialDelivery) -and -not (CarConditionMatchesAny $specialDelivery @($script:catalogCommonConditions.yaltaDelivery, $script:catalogCommonConditions.crimeaDelivery))) {
      $exceptions += (ShortDeliveryCondition $specialDelivery)
    }
    $specialNote = CarCardFactText (CarOptionalText $specialTerms "note")
    if (CarCardTextIsUsable $specialNote) {
      $exceptions += (ShortCarText $specialNote 78)
    }
  }

  if ([bool]$car.deliveryByAgreementOnly) {
    $exceptions += "подача только по согласованию"
  }

  return @($exceptions | Where-Object { CarCardTextIsUsable $_ } | Select-Object -Unique)
}

function CarCardSeatCount($car) {
  $seats = 0
  if ([int]::TryParse([string]$car.seats, [ref]$seats)) { return $seats }
  return 0
}

function RuPlural($value, $one, $few, $many) {
  $number = [Math]::Abs([int]$value) % 100
  $last = $number % 10
  if ($number -gt 10 -and $number -lt 20) { return $many }
  if ($last -gt 1 -and $last -lt 5) { return $few }
  if ($last -eq 1) { return $one }
  return $many
}

function CarCardSeatsLabel($car) {
  $seats = CarCardSeatCount $car
  if ($seats -gt 0) { return "$seats $(RuPlural $seats "место" "места" "мест")" }
  return ""
}

function CarCardEnginePower($car) {
  $engine = CarCardFieldFact $car "engine"
  if (-not (CarCardTextIsUsable $engine)) { return "" }
  $match = [regex]::Match($engine, "(\d{2,3})\s*л\.?\s*с\.?", [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
  if ($match.Success) { return "$($match.Groups[1].Value) л.с." }
  return ""
}

function CarCardPriceSubtitleFact($car) {
  $displayPrice = CarDisplayPrice $car
  if ($null -eq $displayPrice) { return "" }
  return "от " + ([int]$displayPrice).ToString("N0").Replace(",", " ") + " ₽/сут"
}

function AddUniqueCarText([ref]$items, $text) {
  $value = CarCardFactText $text
  if (-not (CarCardTextIsUsable $value)) { return }
  if (-not (@($items.Value) -contains $value)) {
    $items.Value = @($items.Value) + $value
  }
}

function CarClassKey($car) {
  $class = (CarCardFieldFact $car "class").ToLowerInvariant()
  if ($class -match "кабриолет") { return "кабриолет" }
  if ($class -match "кроссовер|suv") { return "кроссовер" }
  if ($class -match "бизнес") { return "бизнес-седан" }
  if ($class -match "седан") { return "седан" }
  if ($class -match "компакт|хэтч") { return "компакт" }
  return $class
}

function CarHasAutomaticTransmission($car) {
  $transmission = (CarCardFieldFact $car "transmission").ToLowerInvariant()
  return $transmission -match "автомат|акпп|amt|амт|робот|dct|9g"
}

function CarFactPhrases($car, $limit = 5) {
  $facts = @()
  AddUniqueCarText ([ref]$facts) (CarCardFieldFact $car "class")
  AddUniqueCarText ([ref]$facts) (CarCardSeatsLabel $car)
  AddUniqueCarText ([ref]$facts) (CarCardFieldFact $car "transmission")
  AddUniqueCarText ([ref]$facts) (CarCardFieldFact $car "drive")
  AddUniqueCarText ([ref]$facts) (CarCardFieldFact $car "engine")
  return @($facts | Select-Object -First $limit)
}

function CarSuitabilityItems($car, $limit = 6) {
  $items = @(CarOptionalArray $car "bestFor" 8)
  $classKey = CarClassKey $car
  $classLower = (CarCardFieldFact $car "class").ToLowerInvariant()
  $driveLower = (CarCardFieldFact $car "drive").ToLowerInvariant()
  $seats = CarCardSeatCount $car

  if ($classKey -eq "кабриолет") {
    AddUniqueCarText ([ref]$items) "для прогулок по побережью"
    AddUniqueCarText ([ref]$items) "для фотосессии и особого маршрута"
  }
  if ($seats -ge 7 -or $classLower -match "7\s*мест") {
    AddUniqueCarText ([ref]$items) "для семьи или компании до $seats человек"
  } elseif ($seats -ge 5) {
    AddUniqueCarText ([ref]$items) "для семьи или небольшой компании"
  } elseif ($seats -gt 0) {
    AddUniqueCarText ([ref]$items) "для поездки вдвоём или небольшой компании"
  }
  if ($driveLower -like "*полн*") {
    AddUniqueCarText ([ref]$items) "для маршрутов с подъёмами и серпантинами"
  }
  if ($classKey -eq "кроссовер") {
    AddUniqueCarText ([ref]$items) "для поездок по Южному берегу и выездов за город"
  }
  if ($classKey -eq "седан" -or $classKey -eq "бизнес-седан") {
    AddUniqueCarText ([ref]$items) "для города, побережья и спокойных поездок по Крыму"
  }
  if ($classKey -eq "компакт") {
    AddUniqueCarText ([ref]$items) "для города и коротких маршрутов"
  }
  if (CarHasAutomaticTransmission $car) {
    AddUniqueCarText ([ref]$items) "для удобной езды по Ялте и маршрутам по Крыму"
  }
  if ($items.Count -eq 0) {
    AddUniqueCarText ([ref]$items) "для поездок по Ялте и Крыму"
  }

  return @($items | Where-Object { CarCardTextIsUsable $_ } | Select-Object -Unique | Select-Object -First $limit)
}

function CarStrongPointItems($car, $limit = 6) {
  $items = @(CarOptionalArray $car "strongPoints" 8)
  $classKey = CarClassKey $car
  $drive = CarCardFieldFact $car "drive"
  $driveLower = $drive.ToLowerInvariant()
  $transmission = CarCardFieldFact $car "transmission"
  $engine = CarCardFieldFact $car "engine"
  $seats = CarCardSeatCount $car

  if ($classKey -eq "кроссовер") {
    AddUniqueCarText ([ref]$items) "Кроссовер удобен для города, побережья и выездов за город."
  }
  if ($classKey -eq "кабриолет") {
    AddUniqueCarText ([ref]$items) "Кабриолет подходит для прогулочного маршрута и фотосъёмки."
  }
  if ($driveLower -like "*полн*") {
    AddUniqueCarText ([ref]$items) "Полный привод указан в характеристиках и полезен на дорогах с подъёмами."
  }
  if ($seats -ge 7) {
    AddUniqueCarText ([ref]$items) "$seats мест — удобно для семьи, компании или трансфера."
  } elseif ($seats -ge 5) {
    AddUniqueCarText ([ref]$items) "$seats мест — удобно для семьи или небольшой компании."
  }
  if (CarHasAutomaticTransmission $car) {
    AddUniqueCarText ([ref]$items) "Коробка $transmission снижает нагрузку в городе и на маршрутах по побережью."
  }
  if (CarCardTextIsUsable $engine) {
    AddUniqueCarText ([ref]$items) "Двигатель $engine указан в характеристиках автомобиля."
  }
  if ([bool]$car.hourlyAvailable) {
    AddUniqueCarText ([ref]$items) "Почасовая аренда доступна по согласованию с менеджером."
  }

  return @($items | Where-Object { CarCardTextIsUsable $_ } | Select-Object -Unique | Select-Object -First $limit)
}

function AddCarCardSubtitleCandidate([ref]$items, $text) {
  $candidate = CarCardFactText $text
  if (-not (CarCardTextIsUsable $candidate)) { return }
  if ($candidate.Length -gt 70) { return }
  if (-not (@($items.Value) -contains $candidate)) {
    $items.Value = @($items.Value) + $candidate
  }
}

function GetCarCardCustomSubtitle($car) {
  return CarCardFactText (CarOptionalText $car "cardSubtitle")
}

function GetCarCardSubtitleCandidates($car) {
  $candidates = @()
  AddCarCardSubtitleCandidate ([ref]$candidates) (CarCatalogStructuredSubtitle $car)

  $class = CarCardFieldFact $car "class"
  $classLower = $class.ToLowerInvariant()
  $drive = CarCardFieldFact $car "drive"
  $driveLower = $drive.ToLowerInvariant()
  $transmission = CarCardFieldFact $car "transmission"
  $seatsLabel = CarCardSeatsLabel $car
  $seats = CarCardSeatCount $car
  $power = CarCardEnginePower $car
  $price = CarCardPriceSubtitleFact $car
  $hasFullDrive = $driveLower -like "*полн*"
  $isCabriolet = $classLower -like "*кабриолет*"

  if ([bool]$car.hourlyAvailable -and $isCabriolet) {
    AddCarCardSubtitleCandidate ([ref]$candidates) "Кабриолет с почасовой арендой"
  }
  if ($isCabriolet) {
    AddCarCardSubtitleCandidate ([ref]$candidates) "Кабриолет для прогулочного маршрута"
  }
  if ($seats -ge 7 -or $classLower -like "*7*") {
    AddCarCardSubtitleCandidate ([ref]$candidates) "7 мест для семьи и компании"
  }
  if ($hasFullDrive -and (CarCardTextIsUsable $power)) {
    AddCarCardSubtitleCandidate ([ref]$candidates) "Полный привод и $power"
  }
  if ($hasFullDrive -and (CarCardTextIsUsable $transmission)) {
    AddCarCardSubtitleCandidate ([ref]$candidates) "Полный привод, $transmission"
  }
  if ((CarCardTextIsUsable $transmission) -and (CarCardTextIsUsable $power)) {
    AddCarCardSubtitleCandidate ([ref]$candidates) "$transmission, $power"
  }
  if ((CarCardTextIsUsable $class) -and (CarCardTextIsUsable $seatsLabel) -and (CarCardTextIsUsable $transmission)) {
    AddCarCardSubtitleCandidate ([ref]$candidates) "$class, $seatsLabel, $transmission"
  }
  if ((CarCardTextIsUsable $class) -and (CarCardTextIsUsable $power)) {
    AddCarCardSubtitleCandidate ([ref]$candidates) "$class, $power"
  }
  if ((CarCardTextIsUsable $class) -and (CarCardTextIsUsable $seatsLabel)) {
    AddCarCardSubtitleCandidate ([ref]$candidates) "$class, $seatsLabel"
  }
  if ((CarCardTextIsUsable $drive) -and (CarCardTextIsUsable $power)) {
    AddCarCardSubtitleCandidate ([ref]$candidates) "$drive, $power"
  }
  if ((CarCardTextIsUsable $transmission) -and (CarCardTextIsUsable $price)) {
    AddCarCardSubtitleCandidate ([ref]$candidates) "$transmission, $price"
  }
  if ((CarCardTextIsUsable $class) -and (CarCardTextIsUsable $price)) {
    AddCarCardSubtitleCandidate ([ref]$candidates) "$class, $price"
  }
  if (CarCardTextIsUsable $class) {
    AddCarCardSubtitleCandidate ([ref]$candidates) $class
  }

  return @($candidates)
}

function GetCarCardSubtitle($car) {
  $custom = GetCarCardCustomSubtitle $car
  if (CarCardTextIsUsable $custom) { return $custom }

  $candidates = @(GetCarCardSubtitleCandidates $car)
  if ($candidates.Count -gt 0) { return [string]$candidates[0] }

  return ""
}

function BuildCarCardSubtitleMap($cars) {
  $subtitleMap = @{}
  $generatedRows = @()

  foreach ($car in @($cars)) {
    $slug = CarCardFactText $car.slug
    if (-not (CarCardTextIsUsable $slug)) { continue }

    $custom = GetCarCardCustomSubtitle $car
    if (CarCardTextIsUsable $custom) {
      $subtitleMap[$slug] = $custom
      continue
    }

    $candidates = @(GetCarCardSubtitleCandidates $car)
    $primary = if ($candidates.Count -gt 0) { [string]$candidates[0] } else { "" }
    $subtitleMap[$slug] = $primary
    $generatedRows += [pscustomobject]@{
      Slug = $slug
      Candidates = $candidates
    }
  }

  for ($pass = 0; $pass -lt 4; $pass++) {
    $groups = @{}
    foreach ($slug in @($subtitleMap.Keys)) {
      $subtitle = [string]$subtitleMap[$slug]
      if (-not (CarCardTextIsUsable $subtitle)) { continue }
      if (-not $groups.ContainsKey($subtitle)) { $groups[$subtitle] = @() }
      $groups[$subtitle] = @($groups[$subtitle]) + $slug
    }

    $changed = $false
    foreach ($subtitle in @($groups.Keys)) {
      $slugs = @($groups[$subtitle])
      if ($slugs.Count -lt 2) { continue }

      $generatedGroupRows = @($generatedRows | Where-Object { $slugs -contains $_.Slug })
      if ($generatedGroupRows.Count -eq 0) { continue }

      $outsideValues = @{}
      foreach ($outsideSlug in @($subtitleMap.Keys)) {
        if ($slugs -contains $outsideSlug) { continue }
        $outsideSubtitle = [string]$subtitleMap[$outsideSlug]
        if (CarCardTextIsUsable $outsideSubtitle) { $outsideValues[$outsideSubtitle] = $true }
      }

      foreach ($row in $generatedGroupRows) {
        $chosen = ""
        foreach ($candidate in @($row.Candidates)) {
          if (-not (CarCardTextIsUsable $candidate)) { continue }
          if ($outsideValues.ContainsKey($candidate)) { continue }
          $sameCandidateRows = @($generatedGroupRows | Where-Object {
            $_.Slug -ne $row.Slug -and (@($_.Candidates) -contains $candidate)
          })
          if ($sameCandidateRows.Count -eq 0) {
            $chosen = [string]$candidate
            break
          }
        }

        if ([string]$subtitleMap[$row.Slug] -ne $chosen) {
          $subtitleMap[$row.Slug] = $chosen
          $changed = $true
        }
        if (CarCardTextIsUsable $chosen) { $outsideValues[$chosen] = $true }
      }
    }

    if (-not $changed) { break }
  }

  return $subtitleMap
}

function SubtitleFromMap($subtitleMap, $car) {
  $slug = CarCardFactText $car.slug
  if ($null -ne $subtitleMap -and (CarCardTextIsUsable $slug) -and $subtitleMap.ContainsKey($slug)) {
    return [string]$subtitleMap[$slug]
  }
  return GetCarCardSubtitle $car
}

function GetCarCardBadges($car) {
  $badges = @()
  $custom = CarOptionalText $car "cardBadge"
  if (CarCardTextIsUsable $custom) { $badges += $custom }
  $badges += @(CarOptionalArray $car "cardBadgesCustom" 3)

  $class = ([string]$car.class).ToLowerInvariant()
  $drive = ([string]$car.drive).ToLowerInvariant()
  $seats = CarCardSeatCount $car

  if ([bool]$car.hourlyAvailable) { $badges += "Почасовая аренда" }
  if ($class -like "*кабриолет*") { $badges += "Кабриолет" }
  if ($seats -ge 7 -or $class -like "*7*") { $badges += "7 мест" }
  if ($drive -like "*полн*") { $badges += "Полный привод" }

  return @($badges | Select-Object -Unique | Select-Object -First 3)
}

function GetCarCardFeatures($car) {
  $features = @()
  AddUniqueCarText ([ref]$features) $car.class
  AddUniqueCarText ([ref]$features) (CarBodyTypeLabel $car)
  AddUniqueCarText ([ref]$features) (CarFuelTypeLabel $car)

  $seatsLabel = CarCardSeatsLabel $car
  AddUniqueCarText ([ref]$features) $seatsLabel

  foreach ($field in @("transmission", "drive", "engine")) {
    $value = CarOptionalText $car $field
    AddUniqueCarText ([ref]$features) $value
  }

  return @($features | Select-Object -First 8)
}

function GetCarCardConditions($car) {
  $conditions = @()

  $conditions += (GetCarMinimumRentalText $car)

  $deliveryExceptions = @(GetCarDeliveryExceptions $car)
  $deliveryText = ($deliveryExceptions -join " ").ToLowerInvariant()
  if ($deliveryText -notmatch "ялт") {
    $conditions += "подача по Ялте"
  }
  if ($deliveryText -notmatch "крым|только по соглас") {
    $conditions += "по Крыму по договорённости"
  }
  $conditions += $deliveryExceptions

  $hourly = CarOptionalText $car "hourlyText"
  if ((CarCardTextIsUsable $hourly) -and -not (CarConditionMatchesAny $hourly @("Доступна почасовая аренда"))) {
    $conditions += $hourly
  }

  $deposit = CarOptionalText $car "depositText"
  if (CarCardTextIsUsable $deposit) {
    $conditions += $deposit
  } else {
    $depositFromRates = DepositText (CarDepositAmount $car)
    if (CarCardTextIsUsable $depositFromRates) { $conditions += $depositFromRates }
  }

  return @($conditions | Where-Object { CarCardTextIsUsable $_ } | Select-Object -Unique | Select-Object -First 4)
}

function GetCarCardScenario($car) {
  $custom = ShortCarText (CarOptionalText $car "shortScenario") 150
  if (CarCardTextIsUsable $custom) { return $custom }

  $items = @(CarSuitabilityItems $car 1)
  if ($items.Count -eq 0) { return "" }
  $item = ([string]$items[0]).Trim().TrimEnd(".")
  if ($item -match "^(для|на|под)\s") {
    return ShortCarText "Подойдёт $item." 150
  }
  return ShortCarText "Подойдёт: $item." 150
}

function GetCarCardDescription($car) {
  $custom = ShortCarText (CarOptionalText $car "cardDescription") 210
  if (CarCardTextIsUsable $custom) { return $custom }

  $facts = @(CarFactPhrases $car 4)
  $suits = @(CarSuitabilityItems $car 2)
  $parts = @()
  if ($facts.Count -gt 0) {
    $parts += ($car.name + " — " + (($facts | ForEach-Object { [string]$_ }) -join ", ") + ".")
  } else {
    $parts += ($car.name + " доступен для аренды в Ялте и Крыму.")
  }
  if ($suits.Count -gt 0) {
    $parts += ("Подходит " + (($suits | ForEach-Object { ([string]$_).Trim().TrimEnd(".") }) -join " и ") + ".")
  }
  return ShortCarText ($parts -join " ") 210
}

function BrIcon($depth, $name, $extraClass = "") {
  $safeName = [regex]::Replace(([string]$name).ToLowerInvariant(), "[^a-z0-9-]+", "")
  if ([string]::IsNullOrWhiteSpace($safeName)) { return "" }
  $src = RelPath $depth ("assets/icons/base-rent/" + $safeName + ".svg")
  $className = "br-icon"
  if (-not [string]::IsNullOrWhiteSpace([string]$extraClass)) {
    $className += " " + ([string]$extraClass).Trim()
  }
  return "<img class=""$className"" src=""$src"" alt="""" aria-hidden=""true"" width=""18"" height=""18"">"
}

function BrIconForCardText($text, $context) {
  $value = ([string]$text).ToLowerInvariant()
  if ([string]$context -eq "car-feature") {
    if ($value -match "кабриолет") { return "camera" }
    if ($value -match "кроссовер|седан|компакт|бизнес") { return "car" }
    if ($value -match "мест") { return "seat" }
    if ($value -match "автомат|амт|механ|робот|короб") { return "gearbox" }
    if ($value -match "привод|передн|задн|полн") { return "wheel" }
    if ($value -match "л\.с|турбо|дизел|двиг") { return "engine" }
  }
  return ""
}

function CardSpanListHtml($items, $className, $depth = -1, $context = "") {
  return (@($items) | Where-Object { CarCardTextIsUsable $_ } | ForEach-Object {
    $text = HtmlAttr $_
    $iconName = if ($depth -ge 0) { BrIconForCardText $_ $context } else { "" }
    $icon = if (CarCardTextIsUsable $iconName) { BrIcon $depth $iconName "br-icon--sm" } else { "" }
    "<span class=""$className"">$icon$text</span>"
  }) -join "`n      "
}

function QuickAvailabilityForm($mode, $action, $api = "", $depth = 0) {
  $modeClass = if ($mode -eq "hero") { "hero-search" } else { "catalog-availability" }
  $modeAttr = if ($mode -eq "hero") { " data-home-availability-search" } else { " data-catalog-availability" }
  $apiAttr = if ([string]::IsNullOrWhiteSpace([string]$api)) { "" } else { " data-api=""$api""" }
  $submitText = if ($mode -eq "hero") { "Показать подходящие авто" } else { "Проверить доступность" }
  $resetButton = if ($mode -eq "hero") { "" } else { "<button class=""btn secondary"" type=""button"" data-availability-reset>Сбросить</button>" }
  $dateIcon = BrIcon $depth "calendar" "br-icon--sm"
  $pickupIcon = BrIcon $depth "map-pin" "br-icon--sm"
@"
        <form class="quick-search $modeClass" data-availability-search$modeAttr$apiAttr action="$action" method="get">
          <div class="quick-search__fields">
            <label><span class="quick-search__label">$dateIcon Получение</span><input type="date" name="date_from" required></label>
            <label><span class="quick-search__label">$dateIcon Возврат</span><input type="date" name="date_to" required></label>
            <label><span class="quick-search__label">$pickupIcon Место подачи</span><input name="pickup" placeholder="Ялта, аэропорт, адрес"></label>
          </div>
          <div class="quick-search__actions">
            <button class="btn" type="submit">$submitText</button>
            $resetButton
          </div>
          <p class="quick-search__message" data-availability-search-message aria-live="polite"></p>
        </form>
"@
}

function UrlPart($text) {
  return [System.Uri]::EscapeDataString([string]$text)
}

function SlugPart($text) {
  $slug = ([string]$text).Trim().ToLowerInvariant()
  $slug = [regex]::Replace($slug, "[^a-z0-9-]+", "-")
  return $slug.Trim("-")
}

function ScopeIdFromLessorSlug($lessorSlug) {
  $slug = SlugPart $lessorSlug
  if ([string]::IsNullOrWhiteSpace($slug)) { return "rent_rk" }
  return $slug
}

$script:lessorsByScope = @{}
if (-not $script:BuildFixtureMode -and (Test-BuildInputExists $lessorsPath)) {
  try {
    $lessorsData = Read-BuildInputRaw $lessorsPath | ConvertFrom-Json
    if ($null -ne $lessorsData.items) {
      foreach ($lessor in @($lessorsData.items)) {
        $scopeId = ScopeIdFromLessorSlug ([string]$lessor.slug)
        $script:lessorsByScope[$scopeId] = $lessor
      }
    }
  } catch {
    $script:lessorsByScope = @{}
  }
}

function PartnerAgentSlug($user) {
  $slug = SlugPart ([string]$user.partnerAgentSlug)
  if ([string]::IsNullOrWhiteSpace($slug)) {
    $slug = SlugPart ([string]$user.login)
  }
  return $slug
}

function PartnerAgents($partnerSlug) {
  $items = @()
  foreach ($user in $partnerUsers) {
    if ([string]$user.partnerSlug -ne [string]$partnerSlug) { continue }
    $slug = PartnerAgentSlug $user
    if ([string]::IsNullOrWhiteSpace($slug)) { continue }
    $items += [pscustomobject]@{
      slug = $slug
      name = if ([string]::IsNullOrWhiteSpace([string]$user.name)) { [string]$user.login } else { [string]$user.name }
      login = [string]$user.login
      partnerSlug = [string]$user.partnerSlug
    }
  }

  return @($items | Sort-Object name, slug -Unique)
}

function PartnerOwnerType($partner) {
  $ownerType = [string]$partner.partner_owner_type
  if ([string]::IsNullOrWhiteSpace($ownerType)) { $ownerType = [string]$partner.partnerOwnerType }
  if ($ownerType -ne "lessor") { return "rent_rk" }
  return "lessor"
}

function PartnerOwnerScopeId($partner) {
  $ownerType = PartnerOwnerType $partner
  if ($ownerType -eq "rent_rk") { return "rent_rk" }
  $scopeId = [string]$partner.partner_owner_scope_id
  if ([string]::IsNullOrWhiteSpace($scopeId)) { $scopeId = [string]$partner.partnerOwnerScopeId }
  return SlugPart $scopeId
}

function CarOwnerScopeId($car) {
  $scopeId = [string]$car.owner_scope_id
  if ([string]::IsNullOrWhiteSpace($scopeId)) { $scopeId = [string]$car.ownerScopeId }
  if (-not [string]::IsNullOrWhiteSpace($scopeId)) { return $scopeId.Trim() }
  return ScopeIdFromLessorSlug ([string]$car.lessorSlug)
}

function CarAvailableForRentRkPartners($car) {
  if ($null -ne $car.available_for_rent_rk_partners) { return [bool]$car.available_for_rent_rk_partners }
  if ($null -ne $car.availableForRentRkPartners) { return [bool]$car.availableForRentRkPartners }
  return $true
}

function PublishChannels($car) {
  if ($null -eq $car.publishChannels) { return @() }
  if ($car.publishChannels -is [string]) {
    return @(($car.publishChannels -split ",") | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ -ne "" })
  }
  return @($car.publishChannels | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ -ne "" })
}

function CarHasPublicationFields($car) {
  foreach ($field in @("adminStatus", "publicStatus", "isPublished", "publishChannels")) {
    if ($null -ne $car.$field) { return $true }
  }
  return $false
}

function CarIsActiveForShowcase($car) {
  if ($null -ne $car.archived -and [bool]$car.archived) { return $false }
  if ($null -ne $car.adminStatus -and -not [string]::IsNullOrWhiteSpace([string]$car.adminStatus)) {
    return ([string]$car.adminStatus) -eq "active"
  }
  foreach ($field in @("active", "isActive", "published", "isPublished")) {
    if ($null -ne $car.$field) { return [bool]$car.$field }
  }
  return $true
}

function CarOwnerVisibleInRentRkShowcase($car) {
  $scopeId = CarOwnerScopeId $car
  if ($scopeId -eq "rent_rk") { return $true }
  if (-not $script:lessorsByScope.ContainsKey($scopeId)) { return $true }
  $lessor = $script:lessorsByScope[$scopeId]
  if ($null -ne $lessor.visible_in_rent_rk_showcase) { return [bool]$lessor.visible_in_rent_rk_showcase }
  if ($null -ne $lessor.visibleInRentRkShowcase) { return [bool]$lessor.visibleInRentRkShowcase }
  return $true
}

function CarVisibleInPublicRentRkShowcase($car) {
  if (-not (CarIsActiveForShowcase $car)) { return $false }
  if (CarHasPublicationFields $car) {
    $channels = PublishChannels $car
    return ([string]$car.publicStatus -eq "published") -and [bool]$car.isPublished -and ($channels -contains "rent_rk_public")
  }
  return CarOwnerVisibleInRentRkShowcase $car
}

function CarVisibleForRentRkPartner($car) {
  if (-not (CarAvailableForRentRkPartners $car)) { return $false }
  if (CarHasPublicationFields $car) {
    $channels = PublishChannels $car
    return (CarIsActiveForShowcase $car) -and (CarOwnerVisibleInRentRkShowcase $car) -and ($channels -contains "rent_rk_partners") -and ([string]$car.publicStatus -in @("published", "limited"))
  }
  return (CarVisibleInPublicRentRkShowcase $car)
}

function ActiveRuleAllowsLessorPartner($scopeId, $car) {
  $carSlug = [string]$car.slug
  $carOwnerScopeId = CarOwnerScopeId $car
  foreach ($rule in $accessRuleItems) {
    if ([string]$rule.status -ne "active") { continue }
    if ([string]$rule.to_scope_id -ne [string]$scopeId) { continue }
    if ([string]$rule.from_scope_id -ne [string]$carOwnerScopeId) { continue }
    if (-not [bool]$rule.allow_lessor_partners) { continue }
    if (@($rule.cars) -contains [string]$carSlug) { return $true }
  }
  return $false
}

function PartnerCanSeeCar($partner, $car) {
  $ownerType = PartnerOwnerType $partner
  if ($ownerType -eq "rent_rk") {
    return CarVisibleForRentRkPartner $car
  }

  $scopeId = PartnerOwnerScopeId $partner
  if ([string]::IsNullOrWhiteSpace($scopeId)) { return $false }
  if ((CarOwnerScopeId $car) -eq $scopeId) { return $true }
  return ActiveRuleAllowsLessorPartner $scopeId $car
}

function PartnerVisibleCars($partner) {
  return @($script:cars | Where-Object { PartnerCanSeeCar $partner $_ })
}

function SiteUrl($relative) {
  $path = ([string]$relative).Replace("\", "/").TrimStart("/")
  if ([string]::IsNullOrWhiteSpace($path) -or $path -eq "index.html") {
    return "$siteBaseUrl/"
  }
  if ($path -eq "cars/index.html") {
    return "$siteBaseUrl/cars/"
  }
  if ($path -eq "routes/index.html") {
    return "$siteBaseUrl/routes/"
  }
  if ($path.EndsWith("/index.html")) {
    return "$siteBaseUrl/" + $path.Substring(0, $path.Length - "index.html".Length)
  }
  return "$siteBaseUrl/$path"
}

function AssetUrl($path) {
  $value = NormalizeAssetWebPath $path
  if (Test-ExternalAssetPath $value) { return $value }
  return "$siteBaseUrl/" + $value.TrimStart("/")
}

function RootAssetUrl($path) {
  $value = NormalizeAssetWebPath $path
  if (Test-ExternalAssetPath $value) { return $value }
  return "/" + $value.TrimStart("/")
}

function Crumb($name, $url) {
  return [pscustomobject]@{ Name = $name; Url = $url }
}

function JsonLd($obj) {
  $json = $obj | ConvertTo-Json -Depth 12 -Compress
  $json = $json -replace "</script>", "<\/script>"
  return "<script type=""application/ld+json"">$json</script>"
}

function BreadcrumbSchema($items) {
  $crumbs = @($items)
  $elements = for ($i = 0; $i -lt $crumbs.Count; $i++) {
    [ordered]@{
      "@type" = "ListItem"
      position = $i + 1
      name = [string]$crumbs[$i].Name
      item = SiteUrl $crumbs[$i].Url
    }
  }
  return [ordered]@{
    "@context" = "https://schema.org"
    "@type" = "BreadcrumbList"
    itemListElement = @($elements)
  }
}

function BreadcrumbsHtml($items, $depth) {
  $crumbs = @($items)
  if ($crumbs.Count -le 1) { return "" }

  $parts = for ($i = 0; $i -lt $crumbs.Count; $i++) {
    $name = HtmlAttr $crumbs[$i].Name
    if ($i -eq ($crumbs.Count - 1)) {
      "<span aria-current=""page"">$name</span>"
    } else {
      $href = HtmlAttr (RelPath $depth $crumbs[$i].Url)
      "<a href=""$href"">$name</a><span aria-hidden=""true"">/</span>"
    }
  }

  return @"
  <nav class="breadcrumbs container" aria-label="Хлебные крошки">
    $($parts -join "`n    ")
  </nav>
"@
}

function BusinessSchema() {
  return [ordered]@{
    "@context" = "https://schema.org"
    "@type" = "AutoRental"
    "@id" = "$siteBaseUrl/#organization"
    name = "Rent RK"
    legalName = "АПРИОРИ"
    url = "$siteBaseUrl/"
    telephone = "+79789485111"
    image = AssetUrl $defaultOgImage
    priceRange = "RUB"
    address = [ordered]@{
      "@type" = "PostalAddress"
      addressLocality = "Ялта"
      streetAddress = "ул. Московская, 33"
      addressCountry = "RU"
    }
    areaServed = @("Ялта", "Крым")
    sameAs = @(
      $telegram,
      "https://yandex.ru/maps/org/apriori/134040500420/"
    )
  }
}

function StripHtml($html) {
  $text = [regex]::Replace([string]$html, "<[^>]+>", " ")
  return ([regex]::Replace($text, "\s+", " ")).Trim()
}

function FaqSchemaFromHtml($html) {
  $matches = [regex]::Matches([string]$html, "(?s)<details[^>]*>\s*<summary>(.*?)</summary>(.*?)</details>")
  $entities = foreach ($match in $matches) {
    [ordered]@{
      "@type" = "Question"
      name = StripHtml $match.Groups[1].Value
      acceptedAnswer = [ordered]@{
        "@type" = "Answer"
        text = StripHtml $match.Groups[2].Value
      }
    }
  }

  return [ordered]@{
    "@context" = "https://schema.org"
    "@type" = "FAQPage"
    mainEntity = @($entities)
  }
}

function Layout($title, $description, $body, $depth, $current = "", $relativePath = "index.html", $breadcrumbs = @(), $schemas = @(), $ogImage = "", $isPartnerPage = $false, $noindex = $false) {
  $css = VersionedAssetPath $depth "assets/css/main.css"
  $analyticsJs = VersionedAssetPath $depth "assets/js/analytics-tracker.js"
  $js = VersionedAssetPath $depth "assets/js/main.js"
  $homeUrl = RelPath $depth "index.html"
  $carsUrl = RelPath $depth "cars/index.html"
  $conditions = RelPath $depth "pages/conditions.html"
  $faq = RelPath $depth "pages/faq.html"
  $contacts = RelPath $depth "pages/contacts.html"
  $routes = RelPath $depth "routes/index.html"
  $goodPlaceImg = RelPath $depth "assets/img/good-place-2026.png"
  $goodPlaceImgAttrs = ImageDimensionAttrs "assets/img/good-place-2026.png"
  $phone = $script:phoneHuman
  $phoneLink = $script:phoneHref
  $tg = $script:telegram
  $yandexOrg = "https://yandex.ru/maps/org/apriori/134040500420/"
  $year = '<span data-current-year></span>'
  $canonical = SiteUrl $relativePath
  $titleAttr = HtmlAttr $title
  $descriptionAttr = HtmlAttr $description
  $canonicalAttr = HtmlAttr $canonical
  $ogImageAbs = AssetUrl $(if ([string]::IsNullOrWhiteSpace($ogImage)) { $defaultOgImage } else { $ogImage })
  $ogImageAttr = HtmlAttr $ogImageAbs
  $robotsMeta = if ($noindex) { '  <meta name="robots" content="noindex,follow">' } else { "" }
  $breadcrumbsHtml = BreadcrumbsHtml $breadcrumbs $depth
  $callbackContextScript = CallbackContextHtml $relativePath $isPartnerPage $depth
  $contactsMenuItem = if ($isPartnerPage) { "" } else { "<a href=""$contacts""$(if($current -eq "contacts"){' aria-current="page"'}else{''})>Контакты</a>" }
  $headerActions = if ($isPartnerPage) {
    '<a class="btn" href="#partner-request">Создать заявку</a>'
  } else {
    "<a class=""btn secondary"" href=""$phoneLink"">$phone</a>`n        <a class=""btn"" href=""$tg"">Telegram</a>"
  }
  $footerContactBlock = if ($isPartnerPage) {
@"
      <div>
        <strong>Партнёрская заявка</strong>
        <p><a href="#partner-request">Создать заявку клиента</a><br>Заявка будет закреплена за партнёрским каналом.</p>
      </div>
"@
  } else {
@"
      <div>
        <strong>Контакты</strong>
        <p><a href="$phoneLink">$phone</a><br><a href="$tg">Telegram</a><br>Ялта, ул. Московская, 33</p>
      </div>
"@
  }
  $schemaList = @()
  $schemaList += BusinessSchema
  if (@($breadcrumbs).Count -gt 1) {
    $schemaList += BreadcrumbSchema $breadcrumbs
  }
  foreach ($schema in @($schemas)) {
    if ($null -ne $schema) { $schemaList += $schema }
  }
  $schemaScripts = ($schemaList | ForEach-Object { "  " + (JsonLd $_) }) -join "`n"
@"
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>$titleAttr</title>
  <meta name="description" content="$descriptionAttr">
  $robotsMeta
  <link rel="canonical" href="$canonicalAttr">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Rent RK">
  <meta property="og:title" content="$titleAttr">
  <meta property="og:description" content="$descriptionAttr">
  <meta property="og:url" content="$canonicalAttr">
  <meta property="og:image" content="$ogImageAttr">
  <meta name="twitter:card" content="summary_large_image">
  <link rel="stylesheet" href="$css">
$schemaScripts
</head>
<body>
  <header class="site-header">
    <div class="container nav">
      <a class="brand" href="$homeUrl">Rent RK <small>автопрокат в Ялте</small></a>
      <a class="good-place-badge" href="$yandexOrg" target="_blank" rel="noopener" aria-label="Хорошее место 2026 на Яндекс Картах">
        <img src="$goodPlaceImg" alt="Хорошее место 2026"$goodPlaceImgAttrs>
      </a>
      <nav class="menu" aria-label="Основная навигация">
        <a href="$carsUrl"$(if($current -eq "cars"){' aria-current="page"'}else{''})>Автомобили</a>
        <a href="$conditions"$(if($current -eq "conditions"){' aria-current="page"'}else{''})>Условия</a>
        <a href="$faq"$(if($current -eq "faq"){' aria-current="page"'}else{''})>FAQ</a>
        <a href="$routes"$(if($current -eq "routes"){' aria-current="page"'}else{''})>Маршруты</a>
        $contactsMenuItem
      </nav>
      <div class="header-actions">
        $headerActions
      </div>
    </div>
  </header>
$breadcrumbsHtml

$body

  <footer class="site-footer">
    <div class="container footer-grid">
      <div>
        <strong>Rent RK</strong>
        <p class="muted">Аренда автомобилей в Ялте и Крыму. Бесплатная доставка по Ялте, подача по Крыму по договоренности.</p>
      </div>
      $footerContactBlock
      <div>
        <strong>Документы</strong>
        <p><a href="$conditions">Условия аренды</a><br><a href="$faq">Вопросы и ответы</a><br><a href="$carsUrl">Каталог автомобилей</a></p>
      </div>
    </div>
    <div class="container"><p class="muted">© $year АПРИОРИ.</p></div>
  </footer>
  $callbackContextScript
  <script src="$analyticsJs"></script>
  <script src="$js"></script>
</body>
</html>
"@
}

function CarCard($car, $depth, $partnerSlug = "", $partnerAgentSlug = "", $subtitleOverride = $null) {
  $cardImage = if ([string]::IsNullOrWhiteSpace([string]$car.image)) { $defaultOgImage } else { [string]$car.image }
  $img = RelAssetPath $depth $cardImage
  $partnerQuery = ""
  if (-not [string]::IsNullOrWhiteSpace([string]$partnerSlug)) {
    $partnerQuery = "?partner=" + (UrlPart $partnerSlug)
    if (-not [string]::IsNullOrWhiteSpace([string]$partnerAgentSlug)) {
      $partnerQuery += "&agent=" + (UrlPart $partnerAgentSlug)
    }
  }
  $url = (RelPath $depth ("cars/" + $car.slug + ".html")) + $partnerQuery
  $bookingUrl = "$url#booking"
  $displayPrice = CarDisplayPrice $car
  $price = if ($null -eq $displayPrice) { "Цена по запросу" } else { "от " + ([int]$displayPrice).ToString("N0").Replace(",", " ") + " ₽/сут" }
  $priceValue = if ($null -eq $displayPrice) { "" } else { [string][int]$displayPrice }
  $deposit = DepositText (CarDepositAmount $car)
  $depositPricing = if (CarCardTextIsUsable $deposit) { "<span class=""car-card__deposit"">$(HtmlAttr $deposit)</span>" } else { "" }
  $pricingBlock = @"
    <div class="car-card__pricing">
      <span class="car-card__daily">$(HtmlAttr $price)</span>
      $depositPricing
    </div>
"@
  $imgSizeAttrs = ImageDimensionAttrs $cardImage
  $typeAttr = HtmlAttr ([string]$car.class).ToLowerInvariant()
  $driveAttr = HtmlAttr ([string]$car.drive).ToLowerInvariant()
  $ownerScopeAttr = HtmlAttr (CarOwnerScopeId $car)
  $structuredDataAttrs = CarStructuredDataAttributes $car
  $name = HtmlAttr $car.name
  $subtitleText = if ($null -ne $subtitleOverride) { CarCardFactText $subtitleOverride } else { GetCarCardSubtitle $car }
  $subtitleBlock = if (CarCardTextIsUsable $subtitleText) {
    $subtitle = HtmlAttr $subtitleText
    "<p class=""car-card__subtitle"">$subtitle</p>"
  } else {
    ""
  }
  $badgesHtml = CardSpanListHtml (GetCarCardBadges $car) "car-card__badge"
  $badgeBlock = if ([string]::IsNullOrWhiteSpace($badgesHtml)) { "" } else { "<div class=""car-card__badges"">$badgesHtml</div>" }
  $featuresHtml = CardSpanListHtml (GetCarCardFeatures $car) "pill car-card__feature" $depth "car-feature"
  $scenarioText = GetCarCardScenario $car
  $scenarioBlock = if (CarCardTextIsUsable $scenarioText) {
    "<p class=""car-card__scenario"">$(HtmlAttr $scenarioText)</p>"
  } else {
    ""
  }
  $descriptionText = GetCarCardDescription $car
  $descriptionBlock = if (CarCardTextIsUsable $descriptionText) {
    "<p class=""car-card__description"">$(HtmlAttr $descriptionText)</p>"
  } else {
    ""
  }
  $contentBlock = if ([string]::IsNullOrWhiteSpace($scenarioBlock + $descriptionBlock)) { "" } else {
@"
    <div class="car-card__content">
      $scenarioBlock
      $descriptionBlock
    </div>
"@
  }
  $conditionsHtml = CardSpanListHtml (GetCarCardConditions $car) "car-card__condition"
  $conditionsBlock = if ([string]::IsNullOrWhiteSpace($conditionsHtml)) { "" } else {
@"
    <div class="car-card__conditions">
      $conditionsHtml
    </div>
"@
  }
  $adminEditUrl = "/admin/cars/page-content.php?slug=" + (UrlPart $car.slug)
@"
<article class="card car-card" data-car-card data-slug="$($car.slug)" data-car-slug="$($car.slug)" data-contour-slug="$ownerScopeAttr" data-type="$typeAttr" data-seats="$($car.seats)" data-drive="$driveAttr" data-price="$priceValue"$structuredDataAttrs>
  <div class="car-card__media">
    <a href="$url" class="car-card__image">
      <img src="$img" alt="$name в аренду в Ялте" loading="lazy"$imgSizeAttrs>
    </a>
    <div class="car-card__price-badge">$price</div>
    $badgeBlock
  </div>
  <div class="card-body car-card__body">
    <div class="car-card__heading">
      <h3><a href="$url">$name</a></h3>
      $subtitleBlock
    </div>
    $pricingBlock
    <div class="meta car-card__features">
      $featuresHtml
    </div>
    $contentBlock
    $conditionsBlock
    <div class="car-card__availability" data-car-availability-status hidden>
      <span class="availability-chip">Проверить доступность</span>
      <small>Выберите даты, чтобы увидеть статус автомобиля.</small>
    </div>
    <div class="card-bottom car-card__actions">
      <a class="btn" href="$bookingUrl" data-car-primary-action>Проверить даты</a>
      <a class="btn secondary" href="$url" data-car-detail-link>Подробнее</a>
      <a class="car-card__edit-link admin-edit-link" href="$adminEditUrl" data-admin-edit-car hidden aria-hidden="true">✎ Редактировать</a>
    </div>
  </div>
</article>
"@
}

function RouteCard($route, $depth) {
  $url = RelPath $depth ("routes/" + $route.slug + ".html")
  $audience = ($route.audience | ForEach-Object { "<span class=""pill"">$_</span>" }) -join ""
@"
<article class="card route-card">
  <div class="card-body">
    <p class="eyebrow">$($route.type)</p>
    <h3><a href="$url">$($route.title)</a></h3>
    <div class="meta">
      <span class="pill">$($route.duration)</span>
      $audience
    </div>
    <p>$($route.summary)</p>
    <p class="muted">Подойдет авто: $($route.car).</p>
    <a class="btn secondary" href="$url">Подробнее</a>
  </div>
</article>
"@
}

function RelatedCarsSection($currentCar, $depth) {
  $currentPrice = CarDisplayPrice $currentCar
  $currentClassKey = CarClassKey $currentCar
  $currentSeats = CarCardSeatCount $currentCar
  $currentBadges = @(GetCarCardBadges $currentCar | ForEach-Object { ([string]$_).ToLowerInvariant() })

  $ranked = @($script:cars |
    Where-Object { $_.slug -ne $currentCar.slug -and (CarVisibleInPublicRentRkShowcase $_) } |
    ForEach-Object {
      $candidate = $_
      $price = CarDisplayPrice $candidate
      $seats = CarCardSeatCount $candidate
      $badges = @(GetCarCardBadges $candidate | ForEach-Object { ([string]$_).ToLowerInvariant() })
      $overlap = 0
      foreach ($badge in $badges) {
        if ($currentBadges -contains $badge) { $overlap++ }
      }

      [pscustomobject]@{
        Car = $candidate
        SameClass = ((CarClassKey $candidate) -eq $currentClassKey)
        PriceDiff = if ($null -eq $currentPrice -or $null -eq $price) { 999999999 } else { [Math]::Abs($price - $currentPrice) }
        SeatDiff = if ($currentSeats -le 0 -or $seats -le 0) { 99 } else { [Math]::Abs($seats - $currentSeats) }
        BadgeOverlap = $overlap
        Name = [string]$candidate.name
      }
    } |
    Sort-Object `
      @{ Expression = { if ($_.SameClass) { 0 } else { 1 } }; Ascending = $true },
      @{ Expression = { $_.PriceDiff }; Ascending = $true },
      @{ Expression = { $_.SeatDiff }; Ascending = $true },
      @{ Expression = { -$_.BadgeOverlap }; Ascending = $true },
      @{ Expression = { $_.Name }; Ascending = $true } |
    Select-Object -First 6)

  if ($ranked.Count -eq 0) { return "" }

  $hasTrueSimilar = @($ranked | Where-Object { $_.SameClass }).Count -gt 0
  $heading = if ($hasTrueSimilar) { "Похожие автомобили" } else { "Другие автомобили в парке" }
  $eyebrow = if ($hasTrueSimilar) { "Похожие автомобили" } else { "Альтернативы" }
  $description = if ($hasTrueSimilar) {
    "Сначала показаны машины близкого класса, затем варианты рядом по цене, вместимости и назначению."
  } else {
    "В парке нет машины того же типа, поэтому ниже — ближайшие варианты по цене, формату поездки и вместимости."
  }
  $aria = HtmlAttr $heading

  $cards = ($ranked | ForEach-Object {
    $car = $_.Car
    $url = RelPath $depth ("cars/" + $car.slug + ".html")
    $similarImage = if ([string]::IsNullOrWhiteSpace([string]$car.image)) { $defaultOgImage } else { [string]$car.image }
    $img = RelAssetPath $depth $similarImage
    $imgSizeAttrs = ImageDimensionAttrs $similarImage
    $price = PriceText (CarDisplayPrice $car)
    $featuresHtml = CardSpanListHtml (@(GetCarCardFeatures $car) | Select-Object -First 3) "pill car-card__feature" $depth "car-feature"
    $name = HtmlAttr $car.name
    $priceHtml = HtmlAttr $price
@"
<article class="card car-card car-card--compact related-car-card">
  <a class="related-car-card__media" href="$url"><img class="related-car-card__image" src="$img" alt="$name для аренды в Ялте" loading="lazy"$imgSizeAttrs></a>
  <div class="card-body car-card__body">
    <h3><a href="$url">$name</a></h3>
    <p class="price">$priceHtml</p>
    <div class="meta car-card__features">
      $featuresHtml
    </div>
    <a class="btn secondary" href="$url">Подробнее</a>
  </div>
</article>
"@
  }) -join "`n"

@"
    <section class="section soft" id="related-cars">
      <div class="container section-head">
        <div>
          <p class="eyebrow">$eyebrow</p>
          <h2>$heading</h2>
          <p>$description</p>
        </div>
        <div class="carousel-actions" aria-label="Навигация по автомобилям">
          <button class="icon-btn" type="button" data-carousel-prev aria-label="Предыдущие автомобили">‹</button>
          <button class="icon-btn" type="button" data-carousel-next aria-label="Следующие автомобили">›</button>
          <a class="btn secondary" href="../cars/index.html">Все автомобили</a>
        </div>
      </div>
      <div class="container">
        <div class="related-carousel" data-carousel tabindex="0" aria-label="$aria">$cards</div>
      </div>
    </section>
"@
}

function CarGallery($car, $depth) {
  $folderRelative = "assets/img/cars/" + $car.slug
  $folder = Join-Path $script:root $folderRelative
  $imagePaths = @()

  if ($null -ne $car.photos) {
    $photoItems = @($car.photos | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_.path) })
    if ($photoItems.Count -gt 0) {
      $imagePaths = @($photoItems |
        Sort-Object @{ Expression = { if ($null -eq $_.sort) { 9999 } else { [int]$_.sort } }; Ascending = $true }, path |
        ForEach-Object { NormalizeAssetWebPath ([string]$_.path) })
    }
  }

  if ($imagePaths.Count -eq 0 -and (Test-Path $folder)) {
    $imagePaths = @(Get-ChildItem -Path $folder -File |
      Where-Object { $_.Extension -match '^\.(jpg|jpeg|png|webp)$' } |
      Sort-Object {
        if ($_.BaseName -match '(\d+)$') { [int]$matches[1] } else { 9999 }
      }, Name |
      ForEach-Object { NormalizeAssetWebPath ($folderRelative.TrimEnd("/") + "/" + $_.Name) })
  }

  if ($imagePaths.Count -eq 0 -and -not [string]::IsNullOrWhiteSpace([string]$car.image)) {
    $fallbackImagePath = NormalizeAssetWebPath ([string]$car.image)
    $fallback = Join-Path $script:root $fallbackImagePath
    if ((Test-ExternalAssetPath $fallbackImagePath) -or (Test-Path $fallback)) {
      $imagePaths = @($fallbackImagePath)
    }
  }

  return ($imagePaths | ForEach-Object -Begin { $i = 0 } -Process {
    $index = $i
    $i++
    $src = RelAssetPath $depth $_
    $classText = CarCardFieldFact $car "class"
    $altText = if ($i -eq 1) {
      if (CarCardTextIsUsable $classText) { "$($car.name) $classText в аренду в Ялте" } else { "$($car.name) в аренду в Ялте" }
    } elseif ($i -eq 2) {
      "Салон $($car.name) для аренды в Ялте"
    } else {
      "$($car.name) — фото автомобиля для аренды в Ялте"
    }
    $alt = HtmlAttr $altText
    $imgSizeAttrs = ImageDimensionAttrs $_
@"
          <img src="$src" alt="$alt" loading="lazy"$imgSizeAttrs role="button" tabindex="0" data-gallery="car-gallery" data-full="$src" data-index="$index">
"@
  }) -join "`n"
}

function BookingForm($car, $depth) {
  $requestApi = RelPath $depth "api/request.php"
  $ratesApi = RelPath $depth ("api/rates.php?car=" + $car.slug)
  $submitLabel = HtmlAttr ("Отправить заявку на " + $car.name)
@"
    <section class="section soft booking-section" id="booking" data-booking-section hidden>
      <div class="container booking-form-shell">
        <div class="section-head compact-head">
          <div>
            <p class="eyebrow">Бронирование</p>
            <h2>Оставить заявку на $($car.name)</h2>
            <p>Укажите телефон и желаемые даты. Менеджер проверит свободность автомобиля и свяжется с вами для подтверждения условий.</p>
          </div>
        </div>
        <form class="booking-form feature" data-booking-form action="$requestApi" method="post">
          <input type="hidden" name="car_slug" value="$($car.slug)">
          <input type="hidden" name="car_name" value="$($car.name)">
          <input type="hidden" name="partner_slug" value="" data-partner-field>
          <input type="hidden" name="partner_agent_slug" value="" data-partner-agent-field>
          <label class="hp-field">Не заполняйте это поле <input name="website" tabindex="-1" autocomplete="off"></label>
          <div class="form-grid">
            <label>Имя <input name="name" autocomplete="name" placeholder="Как к вам обращаться"></label>
            <label>Телефон <input name="phone" autocomplete="tel" placeholder="+7..." required></label>
            <label>Дата подачи <input type="date" name="start_date"></label>
            <label>Время подачи <input type="time" name="start_time"></label>
            <label>Дата возврата <input type="date" name="end_date"></label>
            <label>Время возврата <input type="time" name="end_time"></label>
          </div>
          <div class="price-calculator" data-price-calculator data-api="$ratesApi">
            <div>
              <span>Предварительный расчёт</span>
              <strong data-price-total>Выберите даты аренды</strong>
            </div>
            <p data-price-details>Стоимость считается автоматически по тарифам автомобиля. Финальную сумму подтвердит менеджер.</p>
          </div>
          <div class="form-grid">
            <label>Место подачи <input name="pickup_place" placeholder="Ялта, аэропорт, адрес или город"></label>
            <label>Место возврата <input name="return_place" placeholder="Если отличается от подачи"></label>
          </div>
          <label>Комментарий <textarea name="message" rows="4" placeholder="Например: нужна подача утром, детское кресло, поездка по маршруту"></textarea></label>
          <label class="check-row">
            <input type="checkbox" name="consent" value="1" required>
            <span>Согласен на обработку данных для связи по заявке.</span>
          </label>
          <button class="btn" type="submit">$submitLabel</button>
          <p class="form-note" data-form-message></p>
        </form>
        <div class="booking-success feature" data-booking-success hidden>
          <p class="eyebrow">Заявка принята</p>
          <h3>Заявка принята в работу</h3>
          <p>Спасибо. Менеджер проверит календарь, уточнит детали и свяжется с вами в ближайшее время.</p>
          <p class="muted">Если вопрос срочный, можно сразу позвонить или написать в Telegram.</p>
          <div class="button-row">
            <a class="btn" href="$phoneHref">Позвонить</a>
            <a class="btn secondary" href="$telegram">Telegram</a>
          </div>
        </div>
      </div>
    </section>
"@
}

function AddCarSummaryItem([ref]$items, $icon, $label, $value) {
  $safeValue = CarCardFactText $value
  if (-not (CarCardTextIsUsable $safeValue)) { return }
  $items.Value = @($items.Value) + [pscustomobject]@{
    Icon = [string]$icon
    Label = [string]$label
    Value = $safeValue
  }
}

function CarDetailSummaryItems($car) {
  $items = @()
  AddCarSummaryItem ([ref]$items) "wallet" "Цена" (PriceText (CarDisplayPrice $car))
  AddCarSummaryItem ([ref]$items) "wallet" "Залог" (DepositText (CarDepositAmount $car))
  AddCarSummaryItem ([ref]$items) "tag" "Тип" (CarCardFieldFact $car "class")
  AddCarSummaryItem ([ref]$items) "seat" "Места" (CarCardSeatsLabel $car)
  AddCarSummaryItem ([ref]$items) "gearbox" "Коробка" (CarCardFieldFact $car "transmission")
  AddCarSummaryItem ([ref]$items) "wheel" "Привод" (CarCardFieldFact $car "drive")
  AddCarSummaryItem ([ref]$items) "engine" "Двигатель" (CarCardFieldFact $car "engine")
  AddCarSummaryItem ([ref]$items) "engine" "Мощность" (CarCardEnginePower $car)
  AddCarSummaryItem ([ref]$items) "calendar" "Аренда" (GetCarMinimumRentalText $car)
  AddCarSummaryItem ([ref]$items) "pickup" "Подача" "по Ялте бесплатно"
  return @($items | Select-Object -First 10)
}

function CarDetailSummaryHtml($car, $depth) {
  $items = @(CarDetailSummaryItems $car)
  if ($items.Count -eq 0) { return "" }

  $cards = (@($items) | ForEach-Object {
    $icon = BrIcon $depth $_.Icon "br-icon--md"
    $label = HtmlAttr $_.Label
    $value = HtmlAttr $_.Value
@"
          <article class="car-summary-item">
            $icon
            <span>$label</span>
            <strong>$value</strong>
          </article>
"@
  }) -join "`n"

@"
        <div class="car-summary-grid">
$cards
        </div>
"@
}

function AddCarHeroBadge([ref]$items, $icon, $value) {
  $safeValue = CarCardFactText $value
  if (-not (CarCardTextIsUsable $safeValue)) { return }
  if (@($items.Value | ForEach-Object { $_.Value }) -contains $safeValue) { return }
  $items.Value = @($items.Value) + [pscustomobject]@{
    Icon = [string]$icon
    Value = $safeValue
  }
}

function CarHeroFactsHtml($car, $depth) {
  $availabilityApi = RelPath $depth "api/available-cars.php"
@"
          <div class="car-detail-availability" data-car-detail-availability data-api="$availabilityApi" data-slug="$($car.slug)" hidden>
            <span class="availability-chip is-unknown">Проверяем даты</span>
            <small>Если даты уже выбраны, покажем предварительный статус по календарю.</small>
          </div>
"@
}

function CarHeroEyebrow($car) {
  $class = CarCardFieldFact $car "class"
  if (CarCardTextIsUsable $class) {
    return (([string]$class).Substring(0, 1).ToUpperInvariant() + ([string]$class).Substring(1)) + " / Rent RK"
  }
  return "Автомобиль Rent RK"
}

function CarHeroLeadText($car) {
  $description = CarDetailDescription $car
  if (CarCardTextIsUsable $description) {
    $sentences = @([regex]::Split(([string]$description).Trim(), '(?<=[.!?])\s+(?=[А-ЯЁA-Z])') | ForEach-Object { $_.Trim() } | Where-Object { CarCardTextIsUsable $_ })
    if ($sentences.Count -gt 0) {
      $lead = [string]$sentences[0]
      if ($lead.Length -lt 118 -and $sentences.Count -gt 1) {
        $lead = ($lead + " " + [string]$sentences[1]).Trim()
      }
      return ShortCarText $lead 180
    }
    return ShortCarText $description 180
  }
  return "Автомобиль для аренды в Ялте и поездок по Крыму. Подача по Ялте бесплатная, подача по Крыму — по договорённости."
}

function GetCarPageContent($slug) {
  if ($null -eq $script:carPageContentItems) { return $null }
  $prop = $script:carPageContentItems.PSObject.Properties[[string]$slug]
  if ($null -eq $prop) { return $null }
  return $prop.Value
}

function GetCarPageContentSection($content, $section) {
  if ($null -eq $content -or [string]::IsNullOrWhiteSpace([string]$section)) { return $null }
  $prop = $content.PSObject.Properties[[string]$section]
  if ($null -eq $prop) { return $null }
  return $prop.Value
}

function CarPageContentText($content, $section, $field, $fallback = "") {
  $sectionObject = GetCarPageContentSection $content $section
  if ($null -eq $sectionObject) { return $fallback }
  $prop = $sectionObject.PSObject.Properties[[string]$field]
  if ($null -eq $prop) { return $fallback }
  $value = CarCardFactText $prop.Value
  if (CarCardTextIsUsable $value) { return $value }
  return $fallback
}

function CarPageContentArray($content, $section, $field, $fallbackItems = @(), $limit = 12) {
  $sectionObject = GetCarPageContentSection $content $section
  if ($null -eq $sectionObject) { return @($fallbackItems) }
  $prop = $sectionObject.PSObject.Properties[[string]$field]
  if ($null -eq $prop -or $null -eq $prop.Value) { return @($fallbackItems) }

  $items = @()
  if ($prop.Value -is [string]) {
    $items = @(($prop.Value -split "`r?`n") | ForEach-Object { CarCardFactText $_ })
  } else {
    $items = @($prop.Value | ForEach-Object { CarCardFactText $_ })
  }

  $items = @($items | Where-Object { CarCardTextIsUsable $_ } | Select-Object -Unique | Select-Object -First $limit)
  if ($items.Count -eq 0) { return @($fallbackItems) }
  return $items
}

function CarPageContentPairs($content, $section, $field = "items", $labelField = "label", $valueField = "value", $limit = 20) {
  $sectionObject = GetCarPageContentSection $content $section
  if ($null -eq $sectionObject) { return @() }
  $prop = $sectionObject.PSObject.Properties[[string]$field]
  if ($null -eq $prop -or $null -eq $prop.Value) { return @() }

  $pairs = @()
  foreach ($item in @($prop.Value)) {
    if ($null -eq $item) { continue }
    if ($item -is [string]) {
      $parts = ([string]$item) -split "[:—-]", 2
      if ($parts.Count -lt 2) { continue }
      $label = CarCardFactText $parts[0]
      $value = CarCardFactText $parts[1]
    } else {
      $labelProp = $item.PSObject.Properties[[string]$labelField]
      $valueProp = $item.PSObject.Properties[[string]$valueField]
      $label = if ($null -eq $labelProp) { "" } else { CarCardFactText $labelProp.Value }
      $value = if ($null -eq $valueProp) { "" } else { CarCardFactText $valueProp.Value }
    }
    if ((CarCardTextIsUsable $label) -and (CarCardTextIsUsable $value)) {
      $pairs += [pscustomobject]@{ Label = $label; Value = $value }
    }
  }

  return @($pairs | Select-Object -First $limit)
}

function CarPageContentSpecRows($pairs) {
  return @(@($pairs) | ForEach-Object { CarSpecRow $_.Label $_.Value })
}

function CarSpecRow($label, $value) {
  $safeValue = CarCardFactText $value
  if (-not (CarCardTextIsUsable $safeValue)) { return "" }
  return "<tr><th>$(HtmlAttr $label)</th><td>$(HtmlAttr $safeValue)</td></tr>"
}

function CarSpecGroupHtml($title, $rows) {
  $rowsHtml = (@($rows) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) }) -join "`n"
  if ([string]::IsNullOrWhiteSpace($rowsHtml)) { return "" }
  $titleHtml = HtmlAttr $title
@"
          <article class="spec-group">
            <h3>$titleHtml</h3>
            <table class="specs">
              <tbody>
$rowsHtml
              </tbody>
            </table>
          </article>
"@
}

function CarGroupedSpecsHtml($car, $pageContent = $null) {
  $price = PriceText (CarDisplayPrice $car)
  $deposit = DepositText (CarDepositAmount $car)
  $structuredRows = CarStructuredSpecRows $car
  $carRows = @()
  $carRows += CarSpecRow "Класс" $car.class
  $carRows += CarSpecRow "Кузов" (CarCardFieldFact $car "body")
  $carRows += CarSpecRow "Количество мест" (CarCardSeatsLabel $car)
  $carRows += CarSpecRow "Двигатель" $car.engine
  $carRows += CarSpecRow "Коробка" $car.transmission
  $carRows += CarSpecRow "Привод" $car.drive
  $carRows += CarSpecRow "Расход" (CarCardFieldFact $car "fuelConsumption")

  $rentalRows = @()
  $rentalRows += CarSpecRow "Цена от" $price
  $rentalRows += CarSpecRow "Минимальный срок" (GetCarMinimumRentalText $car)
  if ([bool]$car.hourlyAvailable) { $rentalRows += CarSpecRow "Почасовая аренда" "доступна по согласованию с менеджером" }
  $rentalRows += CarSpecRow "Залог" $deposit
  $rentalRows += CarSpecRow "Доставка" "по Ялте бесплатно, по Крыму по договорённости"
  $rentalRows += CarSpecRow "Документы" "паспорт и водительское удостоверение"
  $rentalRows += CarSpecRow "Стаж" "от 3 лет"
  $rentalRows += CarSpecRow "Страховка" "открытая страховка на каждом авто"

  $contentCarRows = CarPageContentSpecRows (CarPageContentPairs $pageContent "specs")
  if (@($contentCarRows | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) }).Count -gt 0) {
    $carRows = @($structuredRows + $contentCarRows)
  } else {
    $carRows = @($structuredRows + $carRows)
  }
  $contentRentalRows = CarPageContentSpecRows (CarPageContentPairs $pageContent "rentalTerms")
  if (@($contentRentalRows | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) }).Count -gt 0) {
    $rentalRows = $contentRentalRows
  }

  $groups = @()
  $groups += CarSpecGroupHtml "Характеристики автомобиля" $carRows
  $groups += CarEquipmentSpecGroupHtml $car
  $groups += CarExtraSpecsGroupHtml $car
  $groups += CarSpecGroupHtml "Условия аренды" $rentalRows
  $groupsHtml = (@($groups) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) }) -join "`n"
  if ([string]::IsNullOrWhiteSpace($groupsHtml)) { return "" }

@"
    <section class="section car-specs-section">
      <div class="container">
        <div class="section-head compact-head">
          <div>
            <p class="eyebrow">Факты</p>
            <h2>Характеристики и условия</h2>
            <p>Все основные параметры собраны в одном месте: без повторов, пустых строк и технических заглушек.</p>
          </div>
        </div>
        <div class="spec-groups">
$groupsHtml
        </div>
      </div>
    </section>
"@
}

function CarDetailListHtml($items) {
  $html = (@($items) | Where-Object { CarCardTextIsUsable $_ } | ForEach-Object {
    "<li>$(HtmlAttr $_)</li>"
  }) -join "`n              "
  if ([string]::IsNullOrWhiteSpace($html)) { return "" }
  return "<ul class=""car-detail-chip-list"">`n              $html`n            </ul>"
}

function CarDetailContentPanel($title, $items, $className = "") {
  $list = CarDetailListHtml $items
  if ([string]::IsNullOrWhiteSpace($list)) { return "" }
  $titleHtml = HtmlAttr $title
  $extraClass = if ([string]::IsNullOrWhiteSpace([string]$className)) { "" } else { " " + ([string]$className).Trim() }
@"
          <article class="car-content-panel$extraClass">
            <h2>$titleHtml</h2>
            $list
          </article>
"@
}

function CarDetailTerms($car) {
  $terms = @(
    "Документы — паспорт и водительское удостоверение",
    "Стаж — от 3 лет",
    (GetCarMinimumRentalCondition $car),
    "Подача по Ялте — бесплатно",
    "Подача по Крыму — по договорённости",
    "Страховка открыта на каждом авто"
  )

  $depositFromRates = DepositText (CarDepositAmount $car)
  if (CarCardTextIsUsable $depositFromRates) {
    $terms += $depositFromRates
  }

  $exceptions = @(GetCarCardConditions $car)
  $defaultMatches = @(
    "от 1 суток",
    "подача по Ялте",
    "подача по Ялте бесплатно",
    "по Крыму по договорённости",
    "подача по Крыму по договорённости",
    (GetCarMinimumRentalText $car),
    (GetCarMinimumRentalCondition $car),
    $script:catalogCommonConditions.minRental,
    $script:catalogCommonConditions.yaltaDelivery,
    $script:catalogCommonConditions.crimeaDelivery
  )
  foreach ($exception in $exceptions) {
    if ((CarCardTextIsUsable $depositFromRates) -and (CarConditionMatchesAny $exception @($depositFromRates))) { continue }
    if (CarConditionMatchesAny $exception $defaultMatches) { continue }
    if (CarCardTextIsUsable $exception) {
      $terms += "Особое условие: $exception"
    }
  }

  if ([bool]$car.hourlyAvailable) {
    $terms += "Почасовая аренда — по согласованию с менеджером"
  }

  return @($terms | Where-Object { CarCardTextIsUsable $_ } | Select-Object -Unique)
}

function CarBookingProcessItems($car) {
  $items = @(
    "Укажите даты, время и удобное место подачи",
    "Менеджер сверит календарь и подтвердит свободное окно",
    "Если автомобиль занят, предложим близкие варианты из парка",
    "Маршрут и возврат в другом городе согласуем до поездки"
  )
  if ([bool]$car.hourlyAvailable) {
    $items += "Для короткой аренды сразу укажите нужный интервал"
  }
  return @($items | Where-Object { CarCardTextIsUsable $_ } | Select-Object -Unique)
}

function CarDetailDescription($car) {
  $description = CarCardFactText (CarOptionalText $car "detailDescription")
  if (-not (CarCardTextIsUsable $description)) {
    $description = CarCardFactText (CarOptionalText $car "cardDescription")
  }
  if (CarCardTextIsUsable $description) { return $description }

  $name = [string]$car.name
  $classKey = CarClassKey $car
  $seats = CarCardSeatCount $car
  $seatsText = CarCardSeatsLabel $car
  $transmission = CarCardFieldFact $car "transmission"
  $drive = CarCardFieldFact $car "drive"
  $displayPrice = CarDisplayPrice $car
  $priceNote = if ($null -ne $displayPrice -and [int]$displayPrice -ge 9000) {
    "По формату это вариант для особого дня, красивого маршрута и поездки без спешки."
  } elseif ($null -ne $displayPrice -and [int]$displayPrice -le 4500) {
    "По формату это практичный вариант для города, коротких маршрутов и спокойной аренды без лишнего пафоса."
  } else {
    "По формату это универсальный вариант для города, побережья и поездок по Крыму."
  }

  $sentences = @()
  if ($classKey -eq "кабриолет") {
    $sentences += "$name — кабриолет для прогулок по Южному берегу Крыма, фотосессий, свиданий и спокойных поездок по побережью."
    $sentences += "Машина больше про впечатление, открытый верх и красивый маршрут, чем про практичность на каждый день."
  } elseif ($seats -ge 7) {
    $sentences += "$name — просторный автомобиль для семьи, компании или трансфера по Ялте и Крыму."
    $sentences += "Он удобен, когда важны запас места, багаж и спокойная посадка для нескольких пассажиров."
  } elseif ($classKey -eq "кроссовер") {
    $sentences += "$name — кроссовер для Ялты, Южного берега и маршрутов с подъёмами."
    $sentences += "Высокая посадка помогает чувствовать себя увереннее в городе, на серпантинах и при выездах за пределы курортной зоны."
  } elseif ($classKey -eq "бизнес-седан") {
    $sentences += "$name — бизнес-седан для деловых поездок, встреч и комфортного движения по трассе."
    $sentences += "Он подойдёт тем, кому нужен спокойный премиальный формат без лишней демонстративности."
  } elseif ($classKey -eq "компакт") {
    $sentences += "$name — компактный автомобиль для города, коротких маршрутов и удобной парковки."
    $sentences += "Такой формат проще в плотном движении Ялты и на повседневных поездках."
  } else {
    $sentences += "$name — автомобиль для аренды в Ялте и поездок по Крыму."
    $sentences += $priceNote
  }

  if (CarCardTextIsUsable $seatsText) {
    if ($seats -le 4 -and $seats -gt 0) {
      $sentences += "В салоне ${seatsText}: комфортнее всего ехать вдвоём, но короткую поездку можно планировать и небольшой компанией."
    } else {
      $sentences += "В салоне $seatsText, поэтому автомобиль подойдёт для пары, семьи или небольшой компании."
    }
  }
  $motionParts = @($transmission, $drive) | Where-Object { CarCardTextIsUsable $_ }
  if ($motionParts.Count -gt 0) {
    $sentences += "По управлению: " + (($motionParts | ForEach-Object { [string]$_ }) -join ", ") + "."
  }
  if ([bool]$car.hourlyAvailable) {
    $sentences += "Для этой модели доступна почасовая аренда по согласованию с менеджером."
  }

  return ($sentences | Select-Object -First 5) -join " "
}

function CarOverviewHighlightsHtml($car, $depth, $manualItems = @()) {
  $items = @()
  $items += [pscustomobject]@{ Icon = "check"; Text = "Подходит под маршрут" }
  $items += [pscustomobject]@{ Icon = "route"; Text = "Подача по Ялте" }
  $items += [pscustomobject]@{ Icon = "car"; Text = "Аренда по Крыму" }

  $suitability = @(CarSuitabilityItems $car 3)
  if ($suitability.Count -gt 0) {
    $items = @($suitability | Select-Object -First 3 | ForEach-Object -Begin { $i = 0 } -Process {
      $icons = @("route", "seat", "check")
      [pscustomobject]@{ Icon = $icons[$i++ % $icons.Count]; Text = $_ }
    })
  }
  if (@($manualItems).Count -gt 0) {
    $items = @($manualItems | Select-Object -First 4 | ForEach-Object -Begin { $i = 0 } -Process {
      $icons = @("check", "route", "car", "shield")
      [pscustomobject]@{ Icon = $icons[$i++ % $icons.Count]; Text = $_ }
    })
  }

  $html = (@($items) | Where-Object { CarCardTextIsUsable $_.Text } | Select-Object -First 4 | ForEach-Object {
    $icon = BrIcon $depth $_.Icon "br-icon--sm"
    $text = HtmlAttr $_.Text
@"
              <li>$icon<span>$text</span></li>
"@
  }) -join "`n"

  if ([string]::IsNullOrWhiteSpace($html)) { return "" }
@"
            <ul class="car-overview-highlights">
$html
            </ul>
"@
}

function CarDetailOverviewHtml($car, $pageContent = $null) {
  $description = CarPageContentText $pageContent "summary" "body" (CarDetailDescription $car)

  if (-not (CarCardTextIsUsable $description)) { return "" }
  $eyebrow = HtmlAttr (CarPageContentText $pageContent "summary" "eyebrow" "О машине")
  $title = HtmlAttr (CarPageContentText $pageContent "summary" "title" "Коротко об автомобиле")
  $manualBadges = CarPageContentArray $pageContent "summary" "badges" @() 4
  $highlights = CarOverviewHighlightsHtml $car 1 $manualBadges
@"
    <section class="section car-overview-section">
      <div class="container">
        <article class="car-overview-card">
          <div class="car-content-intro">
            <p class="eyebrow">$eyebrow</p>
            <h2>$title</h2>
            <p>$([System.Net.WebUtility]::HtmlEncode($description))</p>
          </div>
          $highlights
        </article>
      </div>
    </section>
"@
}

function CarDetailContentSection($car, $pageContent = $null) {
  $fitForItems = CarPageContentArray $pageContent "content" "fitFor" (CarSuitabilityItems $car 5) 8
  $serviceItems = CarPageContentArray $pageContent "content" "service" @(
    "Быстрое подтверждение после заявки",
    "Связь в Telegram и по телефону",
    "Прозрачные условия без скрытых формулировок",
    "Поможем выбрать замену, если машина занята"
  ) 8
  $bookingItems = CarPageContentArray $pageContent "content" "bookingSteps" (CarBookingProcessItems $car) 8
  $panels = @()
  $panels += CarDetailContentPanel "Кому подойдёт" $fitForItems "car-content-panel--use"
  $panels += CarDetailContentPanel "Сервис Rent RK" $serviceItems "car-content-panel--trust"
  $panels += CarDetailContentPanel "Как проходит бронь" $bookingItems "car-content-panel--terms"
  $panelsHtml = (@($panels) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) }) -join "`n"

  if ([string]::IsNullOrWhiteSpace($panelsHtml)) { return "" }
@"
    <section class="section car-content-section">
      <div class="container">
        <div class="car-detail-insights">
$panelsHtml
        </div>
      </div>
    </section>
"@
}

function CarDetailFaqHtml($car, $pageContent = $null) {
  $manualFaq = CarPageContentPairs $pageContent "faq" "items" "question" "answer" 10
  if (@($manualFaq).Count -gt 0) {
    $manualDetails = (@($manualFaq) | ForEach-Object {
      $question = HtmlAttr $_.Label
      $answer = HtmlAttr $_.Value
@"
          <details>
            <summary>$question</summary>
            <p>$answer</p>
          </details>
"@
    }) -join "`n"
@"
    <article class="car-faq-panel" id="car-faq">
        <div class="section-head compact-head">
          <div>
            <p class="eyebrow">FAQ</p>
            <h2>Вопросы по аренде</h2>
            <p>Короткие ответы по бронированию и условиям перед заявкой.</p>
          </div>
        </div>
        <div class="faq car-faq">
$manualDetails
        </div>
    </article>
"@
    return
  }
  $name = HtmlAttr $car.name
  $deposit = DepositText (CarDepositAmount $car)
  $depositAnswer = if (CarCardTextIsUsable $deposit) {
    "Да, для этой модели указан " + (HtmlAttr $deposit) + ". Финальные условия менеджер подтвердит по датам и формату аренды."
  } else {
    "Условия залога менеджер уточнит при подтверждении заявки: они зависят от автомобиля, дат и формата аренды."
  }
@"
    <article class="car-faq-panel" id="car-faq">
        <div class="section-head compact-head">
          <div>
            <p class="eyebrow">FAQ</p>
            <h2>Вопросы по аренде</h2>
            <p>Короткие ответы по бронированию и условиям перед заявкой.</p>
          </div>
        </div>
        <div class="faq car-faq">
          <details>
            <summary>Можно ли арендовать $name на выбранные даты?</summary>
            <p>Да, оставьте заявку с датами. Менеджер сверит календарь и подтвердит доступность автомобиля.</p>
          </details>
          <details>
            <summary>Какие документы нужны для аренды?</summary>
            <p>Понадобятся паспорт и водительское удостоверение. Базовое требование по стажу — от 3 лет.</p>
          </details>
          <details>
            <summary>Можно ли заказать подачу автомобиля?</summary>
            <p>Да. Подача по Ялте бесплатная, по другим городам Крыма — по договорённости.</p>
          </details>
          <details>
            <summary>Есть ли залог?</summary>
            <p>$depositAnswer</p>
          </details>
          <details>
            <summary>Можно ли поехать по Крыму?</summary>
            <p>Да, маршрут по Крыму можно согласовать при заявке. Если нужна подача или возврат в другом городе, менеджер рассчитает условия отдельно.</p>
          </details>
        </div>
    </article>
"@
}

function CarGallerySection($galleryImages) {
  if ([string]::IsNullOrWhiteSpace([string]$galleryImages)) { return "" }
@"
    <section class="section car-gallery-section">
      <div class="container">
        <div class="gallery">
$galleryImages
        </div>
      </div>
    </section>
"@
}

function CarStickyCtaHtml($car) {
  $price = HtmlAttr (PriceText (CarDisplayPrice $car))
@"
    <div class="mobile-sticky-cta" aria-label="Быстрые действия по аренде">
      <div class="mobile-sticky-cta__price">
        <span>Цена</span>
        <strong>$price</strong>
      </div>
      <button class="btn" type="button" data-open-booking aria-controls="booking">Забронировать</button>
      <a class="btn secondary" href="$telegram">Telegram</a>
      <a class="btn secondary" href="$phoneHref">Позвонить</a>
    </div>
"@
}

function CarInternalLinksHtml($car, $depth) {
  $catalogIcon = BrIcon $depth "car" "br-icon--md"
  $conditionsIcon = BrIcon $depth "document" "br-icon--md"
  $routesIcon = BrIcon $depth "route" "br-icon--md"
  $faqIcon = BrIcon $depth "info" "br-icon--md"
  $similarIcon = BrIcon $depth "tag" "br-icon--md"
@"
    <article class="car-links-panel">
      <div class="section-head compact-head">
        <div>
          <p class="eyebrow">Навигация</p>
          <h2>Полезные разделы</h2>
          <p>Ссылки помогают быстро сравнить варианты, проверить условия и выбрать маршрут под поездку.</p>
        </div>
      </div>
      <div class="grid four link-grid compact-link-grid">
        <a class="feature" href="../cars/index.html"><div class="feature__title">$catalogIcon<h3>Каталог авто</h3></div><p>Вернуться к подбору и фильтрам.</p></a>
        <a class="feature" href="../pages/conditions.html"><div class="feature__title">$conditionsIcon<h3>Условия аренды</h3></div><p>Документы, стаж, страховка и подача.</p></a>
        <a class="feature" href="../routes/index.html"><div class="feature__title">$routesIcon<h3>Маршруты из Ялты</h3></div><p>Подобрать поездку по Крыму.</p></a>
        <a class="feature" href="../pages/faq.html"><div class="feature__title">$faqIcon<h3>FAQ</h3></div><p>Ответы на частые вопросы перед заявкой.</p></a>
        <a class="feature" href="#related-cars"><div class="feature__title">$similarIcon<h3>Похожие авто</h3></div><p>Сравнить близкие модели.</p></a>
      </div>
    </article>
"@
}

function CarBottomInfoSection($faqHtml, $linksHtml) {
  $content = (@($faqHtml, $linksHtml) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) }) -join "`n"
  if ([string]::IsNullOrWhiteSpace($content)) { return "" }
@"
    <section class="section car-bottom-info-section">
      <div class="container car-bottom-info-grid">
$content
      </div>
    </section>
"@
}

function CarSeoTitle($car) {
  $displayPrice = CarDisplayPrice $car
  if ($null -eq $displayPrice) {
    return "Аренда " + $car.name + " в Ялте и Крыму"
  }
  $price = ([int]$displayPrice).ToString("N0").Replace(",", " ")
  return "Аренда " + $car.name + " в Ялте и Крыму — от " + $price + " ₽/сутки"
}

function CarSeoDescription($car, $price) {
  $facts = @(CarFactPhrases $car 4)
  $factText = if ($facts.Count -gt 0) { (($facts | ForEach-Object { [string]$_ }) -join ", ") + ". " } else { "" }
  $priceText = if (CarCardTextIsUsable $price -and $price -ne "Цена уточняется") { "Стоимость: $price. " } else { "" }
  $minimumRental = GetCarMinimumRentalText $car
  return ShortCarText ($car.name + " в аренду в Ялте: " + $factText + $priceText + "Подача по Ялте, аренда $minimumRental, финальная стоимость по датам.") 190
}

function AddProductSchemaProperty([ref]$properties, $name, $value) {
  $safeValue = CarCardFactText $value
  if (-not (CarCardTextIsUsable $safeValue)) { return }
  $properties.Value = @($properties.Value) + [ordered]@{
    "@type" = "PropertyValue"
    name = [string]$name
    value = $safeValue
  }
}

function CarBrandName($car) {
  $brand = CarStructuredField $car "brand"
  if (CarCardTextIsUsable $brand) { return $brand }
  $name = CarCardFactText $car.name
  if (-not (CarCardTextIsUsable $name)) { return "Rent RK" }
  if ($name -match "^(Mercedes-Benz|Volkswagen|BMW|Jaecoo|Omoda|Exeed|Geely|Kaiyi|Ford|Peugeot)\b") {
    return $matches[1]
  }
  return ($name -split "\s+")[0]
}

function CarProductSchema($car, $relativePath, $description) {
  $displayPrice = CarDisplayPrice $car
  $imageSource = if ([string]::IsNullOrWhiteSpace([string]$car.image)) { $defaultOgImage } else { [string]$car.image }
  $url = SiteUrl $relativePath
  $properties = @()
  AddProductSchemaProperty ([ref]$properties) "Марка" (CarStructuredField $car "brand")
  AddProductSchemaProperty ([ref]$properties) "Модель" (CarStructuredField $car "model")
  AddProductSchemaProperty ([ref]$properties) "Год" (CarStructuredYearText $car)
  AddProductSchemaProperty ([ref]$properties) "Тип кузова" (CarBodyTypeLabel $car)
  AddProductSchemaProperty ([ref]$properties) "Тип топлива" (CarFuelTypeLabel $car)
  AddProductSchemaProperty ([ref]$properties) "Класс" (CarCardFieldFact $car "class")
  AddProductSchemaProperty ([ref]$properties) "Количество мест" (CarCardSeatsLabel $car)
  AddProductSchemaProperty ([ref]$properties) "Коробка" (CarCardFieldFact $car "transmission")
  AddProductSchemaProperty ([ref]$properties) "Привод" (CarCardFieldFact $car "drive")
  AddProductSchemaProperty ([ref]$properties) "Двигатель" (CarCardFieldFact $car "engine")
  AddProductSchemaProperty ([ref]$properties) "Мощность" (CarCardEnginePower $car)
  AddProductSchemaProperty ([ref]$properties) "Залог" (DepositText (CarDepositAmount $car))
  AddProductSchemaProperty ([ref]$properties) "Минимальный срок" (GetCarMinimumRentalText $car)
  if ([bool]$car.hourlyAvailable) {
    AddProductSchemaProperty ([ref]$properties) "Почасовая аренда" "доступна по согласованию с менеджером"
  }

  $offer = [ordered]@{
    "@type" = "Offer"
    url = $url
    priceCurrency = "RUB"
    seller = [ordered]@{ "@id" = "$siteBaseUrl/#organization" }
  }
  if ($null -ne $displayPrice) {
    $offer["price"] = [int]$displayPrice
  }

  $schema = [ordered]@{
    "@context" = "https://schema.org"
    "@type" = "Product"
    "@id" = "$url#product"
    name = [string]$car.name
    image = AssetUrl $imageSource
    description = [string]$description
    url = $url
    brand = [ordered]@{
      "@type" = "Brand"
      name = (CarBrandName $car)
    }
    offers = $offer
  }

  $category = CarCardFieldFact $car "class"
  if (CarCardTextIsUsable $category) {
    $schema["category"] = $category
  }
  if ($properties.Count -gt 0) {
    $schema["additionalProperty"] = @($properties)
  }
  return $schema
}

function HeroAvailability($car, $depth) {
  $availableApi = RelPath $depth "api/available-cars.php"
  $slug = HtmlAttr ([string]$car.slug)
  $name = HtmlAttr ([string]$car.name)
@"
        <div class="hero-availability hero-booking-card" data-quick-booking data-api="$availableApi" data-slug="$slug" data-booking-target="booking">
          <div>
            <p class="eyebrow">Быстрое бронирование</p>
            <h2>Выберите даты аренды</h2>
          </div>
          <p>Отметьте дату получения и возврата в календаре. Даты сразу попадут в заявку, а менеджер подтвердит доступность.</p>
          <form class="quick-booking-form" data-quick-booking-form>
            <input type="hidden" name="start_date">
            <input type="hidden" name="end_date">
            <div class="date-range-picker" data-date-range-picker data-date-range-start-label="Получение" aria-label="Календарь выбора дат аренды">
              <div class="date-range-picker__head">
                <button class="date-range-picker__nav" type="button" data-date-range-prev aria-label="Предыдущий месяц">&lsaquo;</button>
                <strong data-date-range-month></strong>
                <button class="date-range-picker__nav" type="button" data-date-range-next aria-label="Следующий месяц">&rsaquo;</button>
              </div>
              <p class="date-range-picker__summary" data-date-range-summary>Выберите дату получения и возврата</p>
              <div class="date-range-picker__grid" data-date-range-grid></div>
            </div>
            <div class="quick-booking-grid quick-booking-times">
              <label>Время получения <input type="time" name="start_time"></label>
              <label>Время возврата <input type="time" name="end_time"></label>
            </div>
            <button class="btn" type="submit">Продолжить бронирование</button>
            <p class="quick-booking-note" data-quick-booking-message aria-live="polite">Финальную доступность и стоимость подтвердит менеджер.</p>
          </form>
        </div>
"@
}

function AvailabilityCalendarSection($car, $depth) {
  $calendarId = "availability-calendar-" + $car.slug
@"
    <section class="section soft availability-calendar-section" id="$calendarId" data-availability-panel hidden>
      <div class="container">
        <div class="availability-dialog">
          <div class="availability-dialog-head">
            <div>
              <p class="eyebrow">Календарь занятости</p>
              <h2>$($car.name)</h2>
              <p>Даты показаны ориентировочно. Финальную доступность подтвердит менеджер.</p>
            </div>
            <button class="btn secondary" type="button" data-close-availability>Свернуть календарь</button>
          </div>
          <div class="availability-modal-controls">
            <button class="icon-btn" type="button" data-availability-prev aria-label="Предыдущий месяц">‹</button>
            <strong data-availability-month></strong>
            <button class="icon-btn" type="button" data-availability-next aria-label="Следующий месяц">›</button>
          </div>
          <div class="availability-calendar-grid" data-availability-calendar></div>
        </div>
      </div>
    </section>
"@
}

function PartnerPage($partner, $agent = $null) {
  $slug = [string]$partner.slug
  $name = [string]$partner.name
  $agentSlug = if ($null -ne $agent) { [string]$agent.slug } else { "" }
  $agentName = if ($null -ne $agent) { [string]$agent.name } else { "" }
  $agentLogin = if ($null -ne $agent) { [string]$agent.login } else { "" }
  $agentNameHtml = HtmlAttr $agentName
  $agentLoginAttr = HtmlAttr $agentLogin
  $depth = if ([string]::IsNullOrWhiteSpace($agentSlug)) { 2 } else { 3 }
  $leadText = if ([string]::IsNullOrWhiteSpace($agentSlug)) {
    "Проверьте свободные автомобили по датам или отправьте заявку на подбор. Заявка будет закреплена за партнёрским каналом."
  } else {
    "Проверьте свободные автомобили по датам или отправьте заявку на подбор. Заявка будет закреплена за партнёрским каналом и представителем $agentNameHtml."
  }
  $catalogNote = if ([string]::IsNullOrWhiteSpace($agentSlug)) {
    "Все переходы из этого каталога сохраняют партнёрскую метку $slug."
  } else {
    "Все переходы из этого каталога сохраняют партнёрскую метку $slug и представителя $agentSlug."
  }
  $defaultPickupPlace = HtmlAttr ([string]$partner.defaultPickupPlace)
  $requestApi = RelPath $depth "api/request.php"
  $availableApi = RelPath $depth "api/available-cars.php"
  $siteRoot = "../" * $depth
  $visibleCars = PartnerVisibleCars $partner
  $partnerSubtitleMap = BuildCarCardSubtitleMap $visibleCars
  $cards = ($visibleCars | ForEach-Object { CarCard $_ $depth $slug $agentSlug (SubtitleFromMap $partnerSubtitleMap $_) }) -join "`n"
  $heroImage = RootAssetUrl "assets/img/cars/jaecoo-j7/jaecoo-j7-1.jpg"
  $body = @"
  <main>
    <section class="hero compact" style="--hero-image: url('$heroImage')">
      <div class="container hero-content">
        <p class="eyebrow">Партнёр Rent RK</p>
        <h1>$name</h1>
        <p class="lead">$leadText</p>
      </div>
    </section>

    <section class="section soft">
      <div class="container partner-workspace">
        <article class="feature partner-panel" data-partner-availability data-api="$availableApi" data-partner="$slug" data-agent="$agentSlug" data-site-root="$siteRoot">
          <div class="section-head compact-head">
            <div>
              <p class="eyebrow">Доступность</p>
              <h2>Проверить даты</h2>
              <p>Система покажет только автомобили, которые свободны на выбранные даты.</p>
            </div>
          </div>
          <form class="partner-search-form">
            <input type="hidden" name="start_date">
            <input type="hidden" name="end_date">
            <div class="date-range-picker" data-date-range-picker data-date-range-start-label="Подача" aria-label="Календарь выбора дат аренды">
              <div class="date-range-picker__head">
                <button class="date-range-picker__nav" type="button" data-date-range-prev aria-label="Предыдущий месяц">&lsaquo;</button>
                <strong data-date-range-month></strong>
                <button class="date-range-picker__nav" type="button" data-date-range-next aria-label="Следующий месяц">&rsaquo;</button>
              </div>
              <p class="date-range-picker__summary" data-date-range-summary>Выберите дату подачи и возврата</p>
              <div class="date-range-picker__grid" data-date-range-grid></div>
            </div>
            <div class="form-grid partner-search-times">
              <label>Время подачи <input type="time" name="start_time"></label>
              <label>Время возврата <input type="time" name="end_time"></label>
            </div>
            <button class="btn" type="submit">Показать свободные авто</button>
          </form>
          <p class="form-note" data-partner-availability-message></p>
          <div class="partner-availability-results" data-partner-availability-results></div>
        </article>

        <article class="feature partner-panel" id="partner-request">
          <div class="section-head compact-head">
            <div>
              <p class="eyebrow">Заявка</p>
              <h2>Создать заявку клиента</h2>
              <p>Менеджер Rent RK проверит детали, подтвердит бронь и свяжется с клиентом.</p>
            </div>
          </div>
          <form class="booking-form" data-booking-form data-partner-request-form action="$requestApi" method="post">
            <input type="hidden" name="partner_slug" value="$slug">
            <input type="hidden" name="partner_agent_slug" value="$agentSlug">
            <input type="hidden" name="partner_agent_name" value="$agentNameHtml">
            <input type="hidden" name="partner_agent_login" value="$agentLoginAttr">
            <label class="hp-field">Не заполняйте это поле <input name="website" tabindex="-1" autocomplete="off"></label>
            <div class="form-grid">
              <input type="hidden" name="car_slug" data-partner-car-select>
              <input type="hidden" name="car_name" data-partner-car-name>
              <input type="hidden" name="request_kind" value="specific" data-partner-request-kind>
              <label>Имя клиента <input name="name" autocomplete="name" placeholder="Как обращаться"></label>
              <label>Телефон клиента <input name="phone" autocomplete="tel" placeholder="+7..." required></label>
              <label>Дата подачи <input type="date" name="start_date" required></label>
              <label>Время подачи <input type="time" name="start_time"></label>
              <label>Дата возврата <input type="date" name="end_date" required></label>
              <label>Время возврата <input type="time" name="end_time"></label>
            </div>
            <div class="form-grid">
              <label>Место подачи <input name="pickup_place" value="$defaultPickupPlace" placeholder="Отель, адрес, город"></label>
              <label>Место возврата <input name="return_place" placeholder="Если отличается от подачи"></label>
            </div>
            <div class="partner-selected-car" data-partner-selected-car>
              <strong>Автомобиль не выбран</strong>
              <span>Сначала проверьте даты и выберите свободную машину. Если клиенту нужен подбор, отправьте заявку на подбор.</span>
            </div>
            <label>Комментарий <textarea name="message" rows="4" placeholder="Номер комнаты, пожелания клиента, детское кресло"></textarea></label>
            <label class="check-row">
              <input type="checkbox" name="consent" value="1" required>
              <span>Клиент согласен на передачу данных менеджеру Rent RK для связи по заявке.</span>
            </label>
            <div class="partner-form-actions">
              <button class="btn" type="submit" data-partner-specific-submit disabled>Отправить по выбранному авто</button>
              <button class="btn secondary" type="submit" data-partner-selection-submit>Заявка на подбор</button>
            </div>
            <p class="form-note" data-form-message></p>
          </form>
          <div class="booking-success feature" data-booking-success hidden>
            <p class="eyebrow">Заявка принята</p>
            <h3>Заявка передана менеджеру</h3>
            <p>Спасибо. Менеджер проверит календарь и свяжется с клиентом для подтверждения условий.</p>
          </div>
        </article>
      </div>
    </section>

    <section class="section">
      <div class="container section-head">
        <div>
          <p class="eyebrow">Каталог</p>
          <h2>Выбрать автомобиль</h2>
          <p>$catalogNote</p>
        </div>
      </div>
      <div class="container grid cards">$cards</div>
    </section>
  </main>
"@

  $relative = if ([string]::IsNullOrWhiteSpace($agentSlug)) { "partner/$slug/index.html" } else { "partner/$slug/$agentSlug/index.html" }
  $crumbLabel = if ([string]::IsNullOrWhiteSpace($agentSlug)) { "Партнёр $name" } else { "Партнёр ${name}: $agentName" }
  $crumbs = @((Crumb "Главная" "index.html"), (Crumb $crumbLabel $relative))
  $noindex = -not [string]::IsNullOrWhiteSpace($agentSlug)
  return Layout "Партнёрская ссылка $name | Rent RK" "Партнёрская страница Rent RK: проверка доступности автомобилей и создание заявки клиента." $body $depth "partners" $relative $crumbs @() "assets/img/cars/jaecoo-j7/jaecoo-j7-1.jpg" $true $noindex
}

function Get-BuildOutputMetadata($relative) {
  $path = (Normalize-BuildRelativePath $relative)
  $dependencies = if ($script:BuildFixtureMode) {
    @($script:BuildFixtureDependencyPaths)
  } else {
    @(
      "private/rent-rk-data/current-cars.json",
      "private/rent-rk-data/rates.json",
      "private/rent-rk-data/callback-settings.json"
    )
  }

  if ($path -eq "index.html") {
    return [ordered]@{ entityType = "home"; entityId = "index"; dependencies = $dependencies }
  }
  if ($path -eq "cars/index.html") {
    return [ordered]@{ entityType = "catalog"; entityId = "cars"; dependencies = $dependencies }
  }
  if ($path -match '^cars/([^/]+)\.html$') {
    $carDependencies = if ($script:BuildFixtureMode) { $dependencies } else { @($dependencies + "private/rent-rk-data/car-page-content.json") }
    return [ordered]@{ entityType = "car"; entityId = $matches[1]; dependencies = $carDependencies }
  }
  if ($path -match '^pages/([^/]+)\.html$') {
    return [ordered]@{ entityType = "page"; entityId = $matches[1]; dependencies = $dependencies }
  }
  if ($path -eq "routes/index.html") {
    $routeDependencies = if ($script:BuildFixtureMode) { $dependencies } else { @($dependencies + "data/routes.json") }
    return [ordered]@{ entityType = "route"; entityId = "index"; dependencies = $routeDependencies }
  }
  if ($path -match '^routes/([^/]+)\.html$') {
    $routeDependencies = if ($script:BuildFixtureMode) { $dependencies } else { @($dependencies + "data/routes.json") }
    return [ordered]@{ entityType = "route"; entityId = $matches[1]; dependencies = $routeDependencies }
  }
  if ($path -match '^partner/([^/]+)/') {
    $partnerDependencies = if ($script:BuildFixtureMode) { $dependencies } else { @($dependencies + "private/rent-rk-data/partners.json" + "private/rent-rk-data/admin-users.json" + "private/rent-rk-data/access-rules.json") }
    return [ordered]@{ entityType = "partner"; entityId = $matches[1]; dependencies = $partnerDependencies }
  }
  if ($path -eq "robots.txt") {
    $robotDependencies = if ($script:BuildFixtureMode) { $dependencies } else { @("private/rent-rk-data/current-cars.json") }
    return [ordered]@{ entityType = "robots"; entityId = "root"; dependencies = $robotDependencies }
  }
  if ($path -eq "sitemap.xml") {
    $sitemapDependencies = if ($script:BuildFixtureMode) { $dependencies } else { @($dependencies + "data/routes.json" + "private/rent-rk-data/partners.json") }
    return [ordered]@{ entityType = "sitemap"; entityId = "root"; dependencies = $sitemapDependencies }
  }

  return [ordered]@{ entityType = "generated"; entityId = $path; dependencies = $dependencies }
}

function Get-BuildOutputPlanStatus($ownership, $plannedHash) {
  if ($ownership.status -eq "missing") { return "create" }
  if ($ownership.status -eq "conflict") { return "conflict" }
  if ($ownership.status -eq "unknown") { return "unknown-ownership" }
  if ($ownership.currentHash -eq $plannedHash) { return "unchanged" }
  return "change"
}

function Add-BuildOutputPlan {
  param(
    [string]$RelativePath,
    [string]$Content
  )

  $relative = Normalize-BuildRelativePath $RelativePath
  $metadata = Get-BuildOutputMetadata $relative
  $plannedHash = Get-BuildTextHash ([string]$Content)
  $sourceHash = Get-BuildDependencyHash $root ([string[]]$metadata.dependencies) ([ordered]@{
    outputPath = $relative
    entityType = $metadata.entityType
    entityId = $metadata.entityId
  })
  $ownership = Test-BuildOutputOwnership $root $script:BuildState $relative
  $status = Get-BuildOutputPlanStatus $ownership $plannedHash
  $item = [ordered]@{
    outputPath = $relative
    entityType = $metadata.entityType
    entityId = $metadata.entityId
    status = $status
    sourceHash = $sourceHash
    currentHash = $ownership.currentHash
    knownHash = $ownership.knownHash
    plannedHash = $plannedHash
    dependencies = @($metadata.dependencies)
    backupPath = ""
    error = ""
  }

  $script:BuildOutputManifest += $item
  return $item
}

function Write-BuildManifestSummary {
  Write-Host "Build-site plan"
  Write-Host ("Run id: {0}" -f $runId)
  Write-Host ("Mode: {0}; DryRun: {1}; NoPublicData: {2}; NoDelete: {3}; Backup: {4}; BaselineAudit: {5}; RegisterBaseline: {6}; FixtureMode: {7}" -f $Mode, [bool]$DryRun, [bool]$NoPublicData, [bool]$NoDelete, [bool]$Backup, [bool]$BaselineAudit, [bool]$RegisterBaseline, [bool]$script:BuildFixtureMode)
  Write-Host ("Public data publisher: {0}" -f $script:BuildPublicDataAction)
  if ($WriteExpectedToTemp) {
    Write-Host ("Expected temp output root: {0}" -f (Get-BuildRelativePathFromFullPath $root $script:BuildExpectedTempRoot))
  }
  Write-Host "Sources:"
  foreach ($source in $script:BuildSources) {
    Write-Host ("- {0}: {1} (exists={2}; hash={3})" -f $source.role, $source.path, $source.exists, $source.hash)
  }

  $dirtyItems = Get-BuildDirtyItems $script:BuildState
  Write-Host ("Dirty entities: {0}" -f @($dirtyItems).Count)
  foreach ($dirty in $dirtyItems) {
    Write-Host ("- {0}:{1} reason={2}" -f (Get-BuildPropertyValue $dirty "entityType" ""), (Get-BuildPropertyValue $dirty "entityId" ""), (Get-BuildPropertyValue $dirty "reason" ""))
  }

  $created = @($script:BuildOutputManifest | Where-Object { $_.status -eq "create" })
  $changed = @($script:BuildOutputManifest | Where-Object { $_.status -eq "change" })
  $unchanged = @($script:BuildOutputManifest | Where-Object { $_.status -eq "unchanged" })
  $conflicts = @($script:BuildOutputManifest | Where-Object { $_.status -eq "conflict" })
  $unknown = @($script:BuildOutputManifest | Where-Object { $_.status -eq "unknown-ownership" })
  $other = @($script:BuildOutputManifest | Where-Object { @("create", "change", "unchanged", "conflict", "unknown-ownership") -notcontains $_.status })
  Write-Host ("Outputs create/change/unchanged/conflict/unknown/other: {0}/{1}/{2}/{3}/{4}/{5}" -f $created.Count, $changed.Count, $unchanged.Count, $conflicts.Count, $unknown.Count, $other.Count)
  foreach ($item in @($created + $changed + $conflicts + $unknown + $other)) {
    Write-Host ("- {0}: {1} [{2}:{3}]" -f $item.outputPath, $item.status, $item.entityType, $item.entityId)
  }

  Write-Host ("Outputs that would be deleted: {0}" -f @($script:BuildDeleteManifest).Count)
  foreach ($item in $script:BuildDeleteManifest) {
    Write-Host ("- {0}: {1}" -f $item.outputPath, $item.status)
  }
}

function Update-BuildBaselineManifest {
  $script:BuildBaselineManifest = @()
  foreach ($item in $script:BuildOutputManifest) {
    $script:BuildBaselineManifest += New-BuildBaselineAuditItem $item
  }
  foreach ($item in $script:BuildDeleteManifest) {
    $script:BuildBaselineManifest += New-BuildBaselineAuditItem $item
  }
}

function Write-BuildBaselineAuditSummary {
  if (-not $BaselineAudit) { return }

  Write-Host "Baseline audit"
  $categories = @(
    "can-register",
    "unknown-ownership",
    "content-diff",
    "missing-output",
    "stale-output",
    "protected-output",
    "manual-review-required"
  )
  foreach ($category in $categories) {
    $count = @($script:BuildBaselineManifest | Where-Object { $_.category -eq $category }).Count
    Write-Host ("- {0}: {1}" -f $category, $count)
  }
  foreach ($item in $script:BuildBaselineManifest) {
    Write-Host ("- {0}: {1} (status={2}; {3}:{4}; reason={5})" -f $item.outputPath, $item.category, $item.status, $item.entityType, $item.entityId, $item.reason)
  }
}

function Register-BuildBaselineManifest {
  $registered = 0
  $skipped = 0
  foreach ($item in $script:BuildOutputManifest) {
    if (Register-BuildBaselineOutput $script:BuildState $item $runId $script:BuildGeneratorName "RegisterBaseline") {
      $registered += 1
    } else {
      $skipped += 1
    }
  }

  return [ordered]@{
    registered = $registered
    skipped = $skipped
  }
}

function Write-BuildExpectedTempOutput {
  param(
    [string]$RelativePath,
    [string]$Content
  )

  if ([string]::IsNullOrWhiteSpace($script:BuildExpectedTempRoot)) { return }

  $relative = Normalize-BuildRelativePath $RelativePath
  $target = [System.IO.Path]::GetFullPath((Join-Path $script:BuildExpectedTempRoot $relative))
  $tempRootWithSeparator = [System.IO.Path]::GetFullPath($script:BuildExpectedTempRoot).TrimEnd("\", "/") + [System.IO.Path]::DirectorySeparatorChar
  if (-not $target.StartsWith($tempRootWithSeparator, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Expected temp output escaped temp root: $relative"
  }

  $directory = Split-Path -Parent $target
  if (-not (Test-Path -LiteralPath $directory)) {
    New-Item -ItemType Directory -Force -Path $directory | Out-Null
  }

  $encoding = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($target, [string]$Content, $encoding)
}

function WritePage($relative, $content) {
  $relative = Normalize-BuildRelativePath $relative
  if ($script:BuildAllowedOutputPaths.Count -gt 0 -and -not $script:BuildAllowedOutputPaths.ContainsKey($relative)) {
    return
  }
  $plan = Add-BuildOutputPlan $relative ([string]$content)
  Write-BuildExpectedTempOutput $relative ([string]$content)

  if ($DryRun) { return }
  if ($plan.status -eq "conflict") {
    Add-BuildConflict $script:BuildState $runId $relative $plan.entityType $plan.entityId $plan.currentHash $plan.knownHash "output changed after last known generation"
    throw "Refusing to overwrite changed generated output: $relative"
  }
  if ($plan.status -eq "unknown-ownership" -and -not $Backup) {
    Add-BuildConflict $script:BuildState $runId $relative $plan.entityType $plan.entityId $plan.currentHash $plan.knownHash "unknown output ownership"
    throw "Refusing to overwrite output with unknown ownership: $relative"
  }

  $backupPath = ""
  if ($Backup) {
    $backupPath = Backup-BuildGeneratedOutput $root $privateDataDir $runId $relative
    $plan.backupPath = $backupPath
  }

  $path = Get-BuildAbsolutePath $root $relative
  $dir = Split-Path -Parent $path
  if (-not $script:BuildAtomic -and -not (Test-Path -LiteralPath $dir)) {
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
  }

  if ($script:BuildAtomic) {
    $script:BuildPendingDeletes.Remove($relative)
    $script:BuildPendingOutputs[$relative] = [string]$content
  } elseif ($plan.status -ne "unchanged") {
    $encoding = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($path, [string]$content, $encoding)
  }

  $outputHash = if ($script:BuildAtomic) { Get-BuildTextHash ([string]$content) } else { Get-BuildFileHashValue $path }
  Set-BuildOutputStateEntry $script:BuildState $relative $plan.entityType $plan.entityId $plan.sourceHash $outputHash $script:BuildGeneratorName ([string[]]$plan.dependencies) $backupPath $plan.status ""
}

function RemoveGeneratedOutput($relative, $reason) {
  if ($script:BuildPageContentOnly) { return }
  $relative = Normalize-BuildRelativePath $relative
  if ($script:BuildAllowedOutputPaths.Count -gt 0 -and -not $script:BuildAllowedOutputPaths.ContainsKey($relative)) {
    return
  }
  $metadata = Get-BuildOutputMetadata $relative
  $ownership = Test-BuildOutputOwnership $root $script:BuildState $relative
  $status = if ($DryRun -or $NoDelete) { "would-delete" } elseif ($ownership.status -eq "conflict") { "delete-conflict" } elseif ($ownership.status -eq "unknown") { "delete-unknown-ownership" } else { "delete" }
  $item = [ordered]@{
    outputPath = $relative
    entityType = $metadata.entityType
    entityId = $metadata.entityId
    status = $status
    reason = $reason
    currentHash = $ownership.currentHash
    knownHash = $ownership.knownHash
    backupPath = ""
  }
  $script:BuildDeleteManifest += $item

  if ($DryRun -or $NoDelete) { return }
  if ($ownership.status -eq "conflict") {
    Add-BuildConflict $script:BuildState $runId $relative $metadata.entityType $metadata.entityId $ownership.currentHash $ownership.knownHash "delete target changed after last known generation"
    throw "Refusing to delete changed generated output: $relative"
  }
  if ($ownership.status -eq "unknown" -and -not $Backup) {
    Add-BuildConflict $script:BuildState $runId $relative $metadata.entityType $metadata.entityId $ownership.currentHash $ownership.knownHash "delete target has unknown ownership"
    throw "Refusing to delete output with unknown ownership: $relative"
  }

  if ($Backup) {
    $item.backupPath = Backup-BuildGeneratedOutput $root $privateDataDir $runId $relative
  }
  $path = Get-BuildAbsolutePath $root $relative
  if ($script:BuildAtomic) {
    $script:BuildPendingDeletes[$relative] = $true
  } elseif (Test-Path -LiteralPath $path -PathType Leaf) {
    Remove-Item -LiteralPath $path -Force
  }
  Set-BuildOutputStateEntry $script:BuildState $relative $metadata.entityType $metadata.entityId "" "" $script:BuildGeneratorName ([string[]]$metadata.dependencies) $item.backupPath "deleted" $reason
}

function RemoveGeneratedOutputTree($relative, $reason) {
  if ($script:BuildPageContentOnly) { return }
  $relative = (Normalize-BuildRelativePath $relative).TrimEnd("/")
  if ($script:BuildAllowedOutputPaths.Count -gt 0 -and -not $script:BuildAllowedOutputPaths.ContainsKey($relative)) {
    return
  }
  $path = Get-BuildAbsolutePath $root $relative
  if (-not (Test-Path -LiteralPath $path -PathType Container)) { return }

  $script:BuildDeleteManifest += [ordered]@{
    outputPath = $relative + "/"
    entityType = "partner"
    entityId = ($relative -replace '^partner/', '').Trim("/")
    status = if ($DryRun -or $NoDelete) { "would-delete-tree" } else { "delete-tree" }
    reason = $reason
    currentHash = ""
    knownHash = ""
    backupPath = ""
  }
  if ($DryRun -or $NoDelete) { return }
  if (-not $Backup) {
    throw "Refusing to delete generated output tree without -Backup: $relative"
  }

  $backupPath = New-BuildOutputBackupPath $root $privateDataDir $runId ($relative + "/__tree__")
  $backupDir = Split-Path -Parent $backupPath
  if (-not $script:BuildAtomic -and -not (Test-Path -LiteralPath $backupDir)) {
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
  }
  if ($script:BuildAtomic) {
    foreach ($entry in Get-ChildItem -LiteralPath $path -File -Recurse) {
      if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked generated tree refused." }
      $script:BuildPendingDeletes[(Get-BuildRelativePathFromFullPath $root $entry.FullName)] = $true
    }
  } else {
    Copy-Item -LiteralPath $path -Destination $backupDir -Recurse -Force
    Remove-Item -LiteralPath $path -Recurse -Force
  }
}

function Get-RelatedOutputsForEntity {
  param(
    [string]$EntityType,
    [string]$EntityId
  )

  $entityType = ([string]$EntityType).Trim()
  $entityId = ([string]$EntityId).Trim()
  switch ($entityType) {
    "car" {
      if ($entityId -eq "") { return @("cars/index.html", "index.html", "sitemap.xml") }
      return @("cars/$entityId.html", "cars/index.html", "index.html", "data/current-cars.json", "sitemap.xml")
    }
    "car_page_content" {
      if ($entityId -eq "") { return @() }
      return @("cars/$entityId.html")
    }
    "landing" {
      return @("landing:$entityId", "sitemap.xml")
    }
    "public_data" {
      if ($entityId -eq "rates") { return @("data/rates.json") }
      if ($entityId -eq "availability") { return @("data/availability.json") }
      return @("data/current-cars.json")
    }
    "catalog" { return @("cars/index.html", "index.html", "sitemap.xml") }
    "home" { return @("index.html") }
    "route" {
      if ($entityId -eq "" -or $entityId -eq "index") { return @("routes/index.html", "sitemap.xml") }
      return @("routes/$entityId.html", "routes/index.html", "sitemap.xml")
    }
    "sitemap" { return @("sitemap.xml") }
    "robots" { return @("robots.txt") }
    default { return @() }
  }
}

function Add-TargetPlanOutput {
  param([string]$RelativePath)

  if ($RelativePath -like "landing:*") {
    $script:BuildOutputManifest += [ordered]@{
      outputPath = $RelativePath
      entityType = "landing"
      entityId = $RelativePath.Substring("landing:".Length)
      status = "dynamic-marker"
      sourceHash = ""
      currentHash = ""
      knownHash = ""
      plannedHash = ""
      dependencies = @("private/rent-rk-data/landing-page-drafts.json", "private/rent-rk-data/landing-page-versions.json")
      backupPath = ""
      error = "Landing pages stay dynamic through landing.php on Stage 1."
    }
    return
  }
  if ($RelativePath -like "data/*.json") {
    $publicDataDependencies = if ($script:BuildFixtureMode) { @($script:BuildFixtureDependencyPaths) } else { @("private/rent-rk-data/current-cars.json", "private/rent-rk-data/rates.json", "private/rent-rk-data/availability.json") }
    $script:BuildOutputManifest += [ordered]@{
      outputPath = Normalize-BuildRelativePath $RelativePath
      entityType = "public_data"
      entityId = [System.IO.Path]::GetFileNameWithoutExtension($RelativePath)
      status = if ($NoPublicData) { "skipped by -NoPublicData" } else { "public-json-would-update" }
      sourceHash = ""
      currentHash = Get-BuildFileHashValue (Get-BuildAbsolutePath $root $RelativePath)
      knownHash = ""
      plannedHash = ""
      dependencies = $publicDataDependencies
      backupPath = ""
      error = ""
    }
    return
  }

  $metadata = Get-BuildOutputMetadata $RelativePath
  $ownership = Test-BuildOutputOwnership $root $script:BuildState $RelativePath
  $status = if ($ownership.status -eq "missing") { "target-create" } elseif ($ownership.status -eq "unknown") { "unknown-ownership" } elseif ($ownership.status -eq "conflict") { "conflict" } else { "target-update" }
  $script:BuildOutputManifest += [ordered]@{
    outputPath = Normalize-BuildRelativePath $RelativePath
    entityType = $metadata.entityType
    entityId = $metadata.entityId
    status = $status
    sourceHash = Get-BuildDependencyHash $root ([string[]]$metadata.dependencies) ([ordered]@{ outputPath = $RelativePath; targetPlan = $true })
    currentHash = $ownership.currentHash
    knownHash = $ownership.knownHash
    plannedHash = ""
    dependencies = @($metadata.dependencies)
    backupPath = ""
    error = ""
  }
}

function Show-TargetBuildPlanAndExit {
  $entities = @()
  if ($Mode -eq "Car") {
    if ([string]::IsNullOrWhiteSpace($Slug)) { throw "-Mode Car requires -Slug <slug>." }
    if (-not $script:carsBySlug.ContainsKey($Slug)) { throw "Car slug not found in private current-cars: $Slug" }
    $entities += [ordered]@{ entityType = "car"; entityId = $Slug; reason = "explicit -Mode Car" }
  } elseif ($Mode -eq "Route") {
    if ([string]::IsNullOrWhiteSpace($Slug)) { throw "-Mode Route requires -Slug <slug>." }
    $route = @($routeItems | Where-Object { [string]$_.slug -eq $Slug } | Select-Object -First 1)
    if (@($route).Count -eq 0) { throw "Route slug not found in data/routes.json: $Slug" }
    $entities += [ordered]@{ entityType = "route"; entityId = $Slug; reason = "explicit -Mode Route" }
  } elseif ($Mode -eq "Dirty") {
    foreach ($dirty in Get-BuildDirtyItems $script:BuildState) {
      $entities += [ordered]@{
        entityType = [string](Get-BuildPropertyValue $dirty "entityType" "")
        entityId = [string](Get-BuildPropertyValue $dirty "entityId" "")
        reason = [string](Get-BuildPropertyValue $dirty "reason" "")
      }
    }
  }

  foreach ($entity in $entities) {
    foreach ($output in Get-RelatedOutputsForEntity $entity.entityType $entity.entityId) {
      Add-TargetPlanOutput $output
    }
  }

  Write-BuildManifestSummary
  Write-Host ("Target plan entities: {0}" -f @($entities).Count)
  foreach ($entity in $entities) {
    Write-Host ("- {0}:{1} reason={2}" -f $entity.entityType, $entity.entityId, $entity.reason)
  }
  return
}

if ($script:BuildTargetPlanOnly) {
  Show-TargetBuildPlanAndExit
  return
}

$publicShowcaseCars = @($cars | Where-Object { CarVisibleInPublicRentRkShowcase $_ })
$hiddenPublicCars = @($cars | Where-Object { -not (CarVisibleInPublicRentRkShowcase $_) })
$publicShowcaseSlugs = @{}
foreach ($publicCar in $publicShowcaseCars) {
  $publicSlug = [string]$publicCar.slug
  if (-not [string]::IsNullOrWhiteSpace($publicSlug)) {
    $publicShowcaseSlugs[$publicSlug] = $true
  }
}
if ($script:BuildFixtureMode) {
  $script:BuildAllowedOutputPaths[(Normalize-BuildRelativePath "index.html")] = $true
  $script:BuildAllowedOutputPaths[(Normalize-BuildRelativePath "cars/index.html")] = $true
  foreach ($fixtureCar in $publicShowcaseCars) {
    $fixtureSlug = [string]$fixtureCar.slug
    if (-not [string]::IsNullOrWhiteSpace($fixtureSlug)) {
      $script:BuildAllowedOutputPaths[(Normalize-BuildRelativePath ("cars/" + $fixtureSlug + ".html"))] = $true
    }
  }
}
if ($script:BuildCarOnly) {
  if (-not $script:carsBySlug.ContainsKey($Slug)) {
    throw "Car slug not found in private current-cars: $Slug"
  }
  foreach ($relativeOutput in @("cars/$Slug.html", "cars/index.html", "index.html", "sitemap.xml")) {
    $script:BuildAllowedOutputPaths[(Normalize-BuildRelativePath $relativeOutput)] = $true
  }
}
if ($script:BuildPageContentOnly) {
  if (-not $publicShowcaseSlugs.ContainsKey($Slug)) {
    throw "Car slug is not visible in the public Rent RK showcase: $Slug"
  }
  $script:BuildAllowedOutputPaths[(Normalize-BuildRelativePath ("cars/" + $Slug + ".html"))] = $true
}
if (-not $script:BuildFixtureMode) {
  foreach ($hiddenCar in $hiddenPublicCars) {
    $hiddenSlug = [string]$hiddenCar.slug
    if ([string]::IsNullOrWhiteSpace($hiddenSlug)) { continue }
    RemoveGeneratedOutput ("cars/" + $hiddenSlug + ".html") "hidden car no longer belongs to public showcase"
  }
  Get-ChildItem -Path (Join-Path $root "cars") -Filter "*.html" -File | Where-Object {
    $_.Name -ne "index.html" -and -not $publicShowcaseSlugs.ContainsKey($_.BaseName)
  } | ForEach-Object {
    RemoveGeneratedOutput (Get-BuildRelativePathFromFullPath $root $_.FullName) "stale car page not present in public showcase"
  }
}
$featuredCars = @($publicShowcaseCars | Select-Object -First 6)
$featuredSubtitleMap = BuildCarCardSubtitleMap $featuredCars
$catalogSubtitleMap = BuildCarCardSubtitleMap $publicShowcaseCars
$featuredCards = ($featuredCars | ForEach-Object { CarCard $_ 0 "" "" (SubtitleFromMap $featuredSubtitleMap $_) }) -join "`n"
$allCardsRoot = ($publicShowcaseCars | ForEach-Object { CarCard $_ 0 "" "" (SubtitleFromMap $catalogSubtitleMap $_) }) -join "`n"
$allCardsCars = ($publicShowcaseCars | ForEach-Object { CarCard $_ 1 "" "" (SubtitleFromMap $catalogSubtitleMap $_) }) -join "`n"
$homeQuickSearch = QuickAvailabilityForm "hero" "cars/index.html" "" 0
$catalogQuickSearch = QuickAvailabilityForm "catalog" "index.html" "../api/available-cars.php" 1
$homeFeatureCatalogIcon = BrIcon 0 "car" "br-icon--lg"
$homeFeatureClockIcon = BrIcon 0 "clock" "br-icon--lg"
$homeFeaturePickupIcon = BrIcon 0 "pickup" "br-icon--lg"
$homeFeatureCheckIcon = BrIcon 0 "check" "br-icon--lg"
$stepCarIcon = BrIcon 0 "car" "br-icon--md"
$stepDateIcon = BrIcon 0 "calendar" "br-icon--md"
$stepCheckIcon = BrIcon 0 "shield" "br-icon--md"
$stepKeyIcon = BrIcon 0 "key" "br-icon--md"
$stepClockIcon = BrIcon 0 "clock" "br-icon--md"

$homeBody = @"
  <main>
    <section class="hero">
      <div class="container hero-content">
        <p class="eyebrow">Автопрокат в Ялте</p>
        <h1>Аренда авто в Ялте и Крыму</h1>
        <p class="lead">Реальные автомобили из собственного каталога, доставка по Ялте бесплатно, подача по Крыму по договоренности. Есть посуточная аренда, а для отдельных авто доступен почасовой формат.</p>
        <div class="hero-actions">
          <a class="btn" href="cars/index.html">Выбрать автомобиль</a>
          <a class="btn secondary" href="$phoneHref">Позвонить</a>
        </div>
        $homeQuickSearch
      </div>
    </section>

    <section class="section">
      <div class="container section-head">
        <div>
          <p class="eyebrow">Каталог</p>
          <h2>Популярные автомобили</h2>
          <p>Стоимость зависит от автомобиля, срока аренды, сезона и места подачи. Точную цену на ваши даты подтвердит менеджер.</p>
        </div>
        <a class="btn secondary" href="cars/index.html">Весь каталог</a>
      </div>
      <div class="container grid cards">$featuredCards</div>
    </section>

    <section class="section soft">
      <div class="container section-head">
        <div>
          <p class="eyebrow">Почему удобно</p>
          <h2>Понятные условия перед поездкой</h2>
          <p>Перед бронированием можно уточнить свободные даты, стоимость, залог, место подачи и подходящий класс автомобиля.</p>
        </div>
      </div>
      <div class="container grid four">
        <div class="feature"><div class="feature__title">$homeFeatureCatalogIcon<h3>Собственный каталог</h3></div><p>На сайте собраны автомобили, которые можно выбрать под город, маршрут, семью или поездку по Крыму.</p></div>
        <div class="feature"><div class="feature__title">$homeFeatureClockIcon<h3>Посуточно и почасово</h3></div><p>Большинство автомобилей доступно от 1 суток, отдельные модели можно согласовать на почасовую аренду.</p></div>
        <div class="feature"><div class="feature__title">$homeFeaturePickupIcon<h3>Подача автомобиля</h3></div><p>По Ялте доставка бесплатная, подача по Крыму согласуется с менеджером заранее.</p></div>
        <div class="feature"><div class="feature__title">$homeFeatureCheckIcon<h3>Помощь с выбором</h3></div><p>Подскажем машину под количество пассажиров, багаж, горные дороги, фотосессию или спокойный городской маршрут.</p></div>
      </div>
    </section>

    <section class="section">
      <div class="container section-head">
        <div>
          <p class="eyebrow">Как проходит аренда</p>
          <h2>От выбора машины до возврата</h2>
          <p>Заявка не требует онлайн-оплаты: менеджер проверит даты и подтвердит условия перед передачей автомобиля.</p>
        </div>
      </div>
      <div class="container rental-steps">
        <article class="rental-step"><span>1</span><div class="rental-step__title">$stepCarIcon<h3>Выберите автомобиль</h3></div><p>Откройте каталог и сравните подходящие модели по цене, классу и характеристикам.</p></article>
        <article class="rental-step"><span>2</span><div class="rental-step__title">$stepDateIcon<h3>Укажите даты</h3></div><p>В заявке оставьте желаемые даты, время и место подачи автомобиля.</p></article>
        <article class="rental-step"><span>3</span><div class="rental-step__title">$stepCheckIcon<h3>Получите подтверждение</h3></div><p>Менеджер проверит доступность, стоимость и условия залога на ваши даты.</p></article>
        <article class="rental-step"><span>4</span><div class="rental-step__title">$stepKeyIcon<h3>Заберите автомобиль</h3></div><p>Получите машину в Ялте или согласуйте подачу по Крыму заранее.</p></article>
        <article class="rental-step"><span>5</span><div class="rental-step__title">$stepClockIcon<h3>Верните в срок</h3></div><p>Верните автомобиль в согласованное время и место после совместного осмотра.</p></article>
      </div>
    </section>

    <section class="section">
      <div class="container cta-band">
        <div>
          <h2>Подберем машину под поездку</h2>
          <p>Кроссовер для горных дорог, 7 мест для семьи, седан для города или кабриолет для особого маршрута.</p>
        </div>
        <a class="btn" href="$telegram">Написать в Telegram</a>
      </div>
    </section>
  </main>
"@
WritePage "index.html" (Layout "Аренда авто в Ялте и Крыму | Rent RK" "Прокат автомобилей в Ялте и Крыму: посуточная аренда, почасовая аренда для отдельных авто, доставка по Ялте бесплатно, подача по Крыму по договоренности." $homeBody 0 "home" "index.html" @() @() $defaultOgImage)

$catalogHero = RootAssetUrl "assets/img/cars/jaecoo-j7/jaecoo-j7-1.jpg"
$catalogMinRentalIcon = BrIcon 1 "clock" "br-icon--sm"
$catalogYaltaDeliveryIcon = BrIcon 1 "pickup" "br-icon--sm"
$catalogCrimeaDeliveryIcon = BrIcon 1 "map-pin" "br-icon--sm"
$catalogCommonConditionsHtml = @"
        <aside class="catalog-conditions" aria-label="Условия аренды">
          <strong>Условия аренды</strong>
          <ul>
            <li>$catalogMinRentalIcon<span>$($script:catalogCommonConditions.minRental)</span></li>
            <li>$catalogYaltaDeliveryIcon<span>$($script:catalogCommonConditions.yaltaDelivery)</span></li>
            <li>$catalogCrimeaDeliveryIcon<span>$($script:catalogCommonConditions.crimeaDelivery)</span></li>
          </ul>
        </aside>
"@
$catalogBody = @"
  <main>
    <section class="hero compact" style="--hero-image: url('$catalogHero')">
      <div class="container hero-content">
        <p class="eyebrow">Каталог автомобилей</p>
        <h1>Автомобили в аренду</h1>
        <p class="lead">Актуальный список машин доступных к аренде.</p>
      </div>
    </section>
    <section class="section">
      <div class="container">
        $catalogQuickSearch
        <form class="catalog-filters" data-catalog-filters>
          <div class="filter-group">
            <span>Тип</span>
            <label><input type="checkbox" name="type" value="седан"> седан</label>
            <label><input type="checkbox" name="type" value="кроссовер"> кроссовер</label>
            <label><input type="checkbox" name="type" value="кабриолет"> кабриолет</label>
            <label><input type="checkbox" name="type" value="компакт"> компакт</label>
          </div>
          <div class="filter-group">
            <span>Мест</span>
            <label><input type="checkbox" name="seats" value="4"> 4</label>
            <label><input type="checkbox" name="seats" value="5"> 5</label>
            <label><input type="checkbox" name="seats" value="7"> 7</label>
          </div>
          <div class="filter-group">
            <span>Привод</span>
            <label><input type="checkbox" name="drive" value="перед"> передний</label>
            <label><input type="checkbox" name="drive" value="зад"> задний</label>
            <label><input type="checkbox" name="drive" value="полн"> полный</label>
          </div>
          <div class="filter-group">
            <span>Цена</span>
            <label><input type="radio" name="price" value="under-5000"> до 5 000</label>
            <label><input type="radio" name="price" value="5000-8000"> 5 000-8 000</label>
            <label><input type="radio" name="price" value="over-8000"> от 8 000</label>
          </div>
          <button class="btn secondary catalog-filter-reset" type="reset">Сбросить</button>
        </form>
        $catalogCommonConditionsHtml
        <p class="catalog-filter-empty" data-catalog-empty hidden>По выбранным параметрам машин не найдено. Сбросьте фильтры или измените условия.</p>
        <div class="grid cards" data-catalog-grid>$allCardsCars</div>
      </div>
    </section>
  </main>
"@
$catalogCrumbs = @((Crumb "Главная" "index.html"), (Crumb "Автомобили" "cars/index.html"))
WritePage "cars/index.html" (Layout "Каталог автомобилей в аренду в Ялте | Rent RK" "Каталог автомобилей Rent RK: седаны, кроссоверы, BMW, Mercedes-Benz, Jaecoo, Omoda, Exeed, Geely, Peugeot, Ford, Volkswagen." $catalogBody 1 "cars" "cars/index.html" $catalogCrumbs @() "assets/img/cars/jaecoo-j7/jaecoo-j7-1.jpg")

foreach ($car in $publicShowcaseCars) {
  $depth = 1
  $carRelative = "cars/" + $car.slug + ".html"
  $pageContent = GetCarPageContent ([string]$car.slug)
  $galleryImages = CarGallery $car 1
  $price = PriceText (CarDisplayPrice $car)
  $deposit = DepositText (CarDepositAmount $car)
  $bookingBlock = BookingForm $car 1
  $heroAvailability = HeroAvailability $car 1
  $carHeroFacts = CarHeroFactsHtml $car 1
  $carHeroEyebrow = HtmlAttr (CarPageContentText $pageContent "hero" "eyebrow" (CarHeroEyebrow $car))
  $carHeroTitle = HtmlAttr (CarPageContentText $pageContent "hero" "title" ("Аренда " + $car.name + " в Ялте и Крыму"))
  $carHeroLead = HtmlAttr (CarPageContentText $pageContent "hero" "subtitle" (CarHeroLeadText $car))
  $carHeroPrice = HtmlAttr (CarPageContentText $pageContent "hero" "priceText" $price)
  $carHeroPrimaryCta = HtmlAttr (CarPageContentText $pageContent "hero" "primaryCta" "Проверить доступность")
  $carHeroSecondaryCta = HtmlAttr (CarPageContentText $pageContent "hero" "secondaryCta" "Написать в Telegram")
  $carGallerySection = CarGallerySection $galleryImages
  $carOverview = CarDetailOverviewHtml $car $pageContent
  $carSpecs = CarGroupedSpecsHtml $car $pageContent
  $availabilityCalendar = ""
  $carContentSection = CarDetailContentSection $car $pageContent
  $carFaq = CarDetailFaqHtml $car $pageContent
  $carLinks = CarInternalLinksHtml $car 1
  $carBottomInfo = CarBottomInfoSection $carFaq $carLinks
  $carRelated = RelatedCarsSection $car 1
  $carStickyCta = CarStickyCtaHtml $car
  $adminEditUrl = "/admin/cars/page-content.php?slug=" + (UrlPart $car.slug)
  $carOwnerScopeAttr = HtmlAttr (CarOwnerScopeId $car)
  $carStructuredDataAttrs = CarStructuredDataAttributes $car
  $carHeroSource = if ([string]::IsNullOrWhiteSpace([string]$car.image)) { $defaultOgImage } else { [string]$car.image }
  $carHeroImage = RootAssetUrl $carHeroSource
  $carSeoTitle = CarPageContentText $pageContent "seo" "title" (CarSeoTitle $car)
  $carSeoDescription = CarPageContentText $pageContent "seo" "description" (CarSeoDescription $car $price)
  $carSchemas = @((CarProductSchema $car $carRelative $carSeoDescription), (FaqSchemaFromHtml $carFaq))
  $body = @"
  <main>
    <section class="hero compact car-hero" data-car-detail data-car-slug="$($car.slug)" data-contour-slug="$carOwnerScopeAttr"$carStructuredDataAttrs style="--hero-image: url('$carHeroImage')">
      <div class="container hero-content">
        <div class="hero-copy">
          <p class="eyebrow">$carHeroEyebrow</p>
          <h1>$carHeroTitle</h1>
          <p class="lead">$carHeroLead</p>
          <p class="car-hero-price">$carHeroPrice</p>
          <div class="car-hero-promo-slot" data-promo-hero-slot hidden></div>
          $carHeroFacts
          <div class="hero-actions">
            <button class="btn" type="button" data-open-booking aria-controls="booking">$carHeroPrimaryCta</button>
            <a class="btn secondary" href="$telegram">$carHeroSecondaryCta</a>
            <a class="btn secondary" href="$phoneHref">Позвонить</a>
            <a class="admin-edit-link car-detail-edit-link" href="$adminEditUrl" data-admin-edit-car hidden aria-hidden="true">✎ Редактировать</a>
          </div>
          <p class="car-hero-delivery">Подача по Ялте — бесплатно<span>Подача по Крыму — по договорённости</span></p>
        </div>
        $heroAvailability
      </div>
    </section>
    $bookingBlock
    $carGallerySection
    $carOverview
    $carSpecs
    $carContentSection
    $availabilityCalendar
    $carStickyCta
    $carRelated
    $carBottomInfo
  </main>
"@
  $carCrumbs = @((Crumb "Главная" "index.html"), (Crumb "Автомобили" "cars/index.html"), (Crumb $car.name $carRelative))
  WritePage $carRelative (Layout $carSeoTitle $carSeoDescription $body 1 "cars" $carRelative $carCrumbs $carSchemas $carHeroSource)
}

function InfoFeatureCard($depth, $iconName, $title, $text) {
  $icon = BrIcon $depth $iconName "br-icon--md"
  $titleHtml = HtmlAttr $title
  $textHtml = HtmlAttr $text
@"
          <article class="feature decision-card">
            <div class="feature__title">$icon<h3>$titleHtml</h3></div>
            <p>$textHtml</p>
          </article>
"@
}

function InfoLinkCard($depth, $iconName, $href, $title, $text) {
  $icon = BrIcon $depth $iconName "br-icon--md"
  $hrefHtml = HtmlAttr $href
  $titleHtml = HtmlAttr $title
  $textHtml = HtmlAttr $text
@"
          <a class="feature decision-link" href="$hrefHtml">
            <div class="feature__title">$icon<h3>$titleHtml</h3></div>
            <p>$textHtml</p>
          </a>
"@
}

function PublicCarLinkListHtml($items, $depth, $limit = 8) {
  $links = (@($items) | Select-Object -First $limit | ForEach-Object {
    $url = RelPath $depth ("cars/" + $_.slug + ".html")
    $name = HtmlAttr $_.name
    $price = HtmlAttr (PriceText (CarDisplayPrice $_))
    "<li><a href=""$url"">$name</a><span>$price</span></li>"
  }) -join "`n"
  if ([string]::IsNullOrWhiteSpace($links)) { return "<p class=""muted"">Подходящие автомобили лучше уточнить у менеджера по датам.</p>" }
  return "<ul class=""compact-list service-car-links"">`n$links`n        </ul>"
}

function KnownDepositTableHtml($depth) {
  $rows = (@($publicShowcaseCars) | ForEach-Object {
    $deposit = DepositText (CarDepositAmount $_)
    if (CarCardTextIsUsable $deposit) {
      $url = RelPath $depth ("cars/" + $_.slug + ".html")
      $name = HtmlAttr $_.name
      "<tr><th><a href=""$url"">$name</a></th><td>$(HtmlAttr $deposit)</td></tr>"
    }
  }) -join "`n"
  if ([string]::IsNullOrWhiteSpace($rows)) {
    return "<p class=""muted"">Размер залога зависит от автомобиля и подтверждается менеджером перед бронированием.</p>"
  }
@"
        <table class="specs compact-specs">
          <caption>Залоги, которые сейчас указаны в тарифах</caption>
          $rows
        </table>
"@
}

$script:serviceCrossovers = @($publicShowcaseCars | Where-Object { (CarClassKey $_) -eq "кроссовер" })
$script:serviceSevenSeats = @($publicShowcaseCars | Where-Object { (CarCardSeatCount $_) -ge 7 -or ([string]$_.class).ToLowerInvariant() -match "7\s*мест" })

$knownDepositsHtml = KnownDepositTableHtml 1
$conditionCards = @(
  InfoFeatureCard 1 "document" "Документы" "Для оформления нужны паспорт и водительское удостоверение. Данные нужны для договора и передачи автомобиля."
  InfoFeatureCard 1 "clock" "Срок аренды" "Базовый срок аренды начинается от 1 суток. Почасовые условия возможны только для отдельных автомобилей и по согласованию."
  InfoFeatureCard 1 "pickup" "Подача" "По Ялте подача бесплатная. Подача по Крыму обсуждается заранее и зависит от места, даты и времени."
  InfoFeatureCard 1 "wallet" "Цена и залог" "Цена зависит от модели и дат. Если залог указан в тарифах, он показывается в карточке автомобиля."
) -join "`n"
$conditionLinks = @(
  InfoLinkCard 1 "car" "../cars/index.html" "Выбрать автомобиль" "Откройте каталог, проверьте даты и сравните цену, залог и характеристики."
  InfoLinkCard 1 "info" "../pages/faq.html" "Частые вопросы" "Короткие ответы по документам, оплате, возврату и нестандартным ситуациям."
  InfoLinkCard 1 "phone" "../pages/contacts.html" "Связаться с менеджером" "Уточните свободность автомобиля, подачу и детали оформления."
) -join "`n"
$conditionsBody = @"
  <main>
    <section class="hero compact" style="--hero-image: url('/assets/img/cars/volkswagen-tiguan-r-line/volkswagen-tiguan-r-line-1.jpg')">
      <div class="container hero-content">
        <p class="eyebrow">Условия</p>
        <h1>Условия аренды автомобиля</h1>
        <p class="lead">Что нужно для оформления, как считается стоимость, когда возвращается залог и какие детали лучше уточнить до заявки.</p>
      </div>
    </section>
    <section class="section">
      <div class="container section-head">
        <div>
          <p class="eyebrow">Коротко</p>
          <h2>Главное перед бронированием</h2>
          <p>Мы показываем только подтверждённые условия из текущей витрины и тарифов. Если данных по конкретной машине нет, финальные детали подтверждает менеджер.</p>
        </div>
      </div>
      <div class="container grid four decision-grid">
        $conditionCards
      </div>
    </section>
    <section class="section soft">
      <div class="container service-layout">
        <article class="text-page">
          <p class="eyebrow">Оформление</p>
          <h2>Как проходит аренда</h2>
          <ol class="numbered-flow">
            <li><strong>Вы выбираете авто и даты.</strong><span>В каталоге можно проверить предварительную доступность по датам и сразу перейти к заявке на конкретный автомобиль.</span></li>
            <li><strong>Менеджер подтверждает условия.</strong><span>Мы сверяем календарь, цену, залог, место подачи и время передачи автомобиля.</span></li>
            <li><strong>Оформляем договор и осмотр.</strong><span>При передаче фиксируем состояние автомобиля, документы и условия возврата.</span></li>
            <li><strong>Возврат и закрытие аренды.</strong><span>Автомобиль осматривается повторно. Залог возвращается при соблюдении условий договора.</span></li>
          </ol>
        </article>
        <aside class="feature decision-card">
          <div class="feature__title">$(BrIcon 1 "shield" "br-icon--md")<h3>Что входит в базовые условия</h3></div>
          <ul class="compact-list">
            <li>аренда от 1 суток;</li>
            <li>стаж водителя от 3 лет;</li>
            <li>паспорт и водительское удостоверение для оформления;</li>
            <li>открытая страховка на автомобилях;</li>
            <li>бесплатная подача по Ялте;</li>
            <li>подача по Крыму по договорённости.</li>
          </ul>
        </aside>
      </div>
    </section>
    <section class="section">
      <div class="container service-layout">
        <article class="text-page">
          <p class="eyebrow">Стоимость</p>
          <h2>Цена, залог и подтверждение суммы</h2>
          <p>На сайте указана базовая цена “от” для каждой машины. Итоговая стоимость зависит от автомобиля, дат, срока аренды, сезона, формата подачи и дополнительных договорённостей.</p>
          <p>Залог показывается в карточке автомобиля, если он указан в тарифах. Если залог не указан, мы не подставляем его автоматически: менеджер подтверждает сумму перед бронированием.</p>
          $knownDepositsHtml
        </article>
        <aside class="feature decision-card">
          <div class="feature__title">$(BrIcon 1 "check" "br-icon--md")<h3>Что лучше уточнить заранее</h3></div>
          <ul class="compact-list">
            <li>точные даты и время получения/возврата;</li>
            <li>место подачи и возврата;</li>
            <li>размер залога по выбранной машине;</li>
            <li>нужны ли детское кресло, бустер или второй водитель;</li>
            <li>форма оплаты и порядок возврата залога.</li>
          </ul>
        </aside>
      </div>
    </section>
    <section class="section soft">
      <div class="container section-head compact-head">
        <div>
          <p class="eyebrow">Дальше</p>
          <h2>Куда перейти после условий</h2>
          <p>Если условия подходят, проще всего открыть каталог и проверить свободные машины на свои даты.</p>
        </div>
      </div>
      <div class="container grid three decision-grid">
        $conditionLinks
      </div>
    </section>
  </main>
"@
$conditionsCrumbs = @((Crumb "Главная" "index.html"), (Crumb "Условия" "pages/conditions.html"))
WritePage "pages/conditions.html" (Layout "Условия аренды авто в Ялте | Rent RK" "Условия аренды авто в Ялте: документы, стаж, залог, подача по Ялте и Крыму, оформление, возврат и подтверждение стоимости по датам." $conditionsBody 1 "conditions" "pages/conditions.html" $conditionsCrumbs @() "assets/img/cars/volkswagen-tiguan-r-line/volkswagen-tiguan-r-line-1.jpg")

$faqQuickLinks = @(
  InfoLinkCard 1 "document" "../pages/conditions.html" "Условия аренды" "Документы, стаж, подача, залог и возврат в одном месте."
  InfoLinkCard 1 "car" "../cars/index.html" "Каталог авто" "Проверьте свободные машины по датам и сравните цену с залогом."
  InfoLinkCard 1 "phone" "../pages/contacts.html" "Связаться" "Напишите или позвоните, если нужен быстрый ответ по конкретной машине."
) -join "`n"
$faqBody = @"
  <main>
    <section class="hero compact" style="--hero-image: url('/assets/img/cars/geely-atlas-pro/geely-atlas-pro-1.jpg')">
      <div class="container hero-content">
        <p class="eyebrow">FAQ</p>
        <h1>Частые вопросы</h1>
        <p class="lead">Короткие ответы по аренде авто в Ялте: документы, даты, залог, подача, оплата, возврат и нестандартные ситуации.</p>
      </div>
    </section>
    <section class="section">
      <div class="container section-head compact-head">
        <div>
          <p class="eyebrow">Навигация</p>
          <h2>С чего начать</h2>
          <p>Если вопрос связан с конкретной машиной, сначала проверьте её карточку: там есть цена, залог при наличии в тарифах и форма заявки на выбранные даты.</p>
        </div>
      </div>
      <div class="container grid three decision-grid">
        $faqQuickLinks
      </div>
    </section>
    <section class="section faq">
      <div class="container faq-layout">
        <article class="faq-category">
          <h2>Бронирование и даты</h2>
          <details open><summary>Как понять, свободна ли машина на мои даты?</summary><p>В каталоге выберите даты получения и возврата. Сайт покажет предварительный статус по календарю, а финальную доступность подтвердит менеджер после заявки.</p></details>
          <details><summary>Можно ли забронировать конкретный автомобиль?</summary><p>Да. На странице автомобиля нажмите кнопку заявки и укажите даты. Если машина занята, менеджер предложит близкие варианты из текущего каталога.</p></details>
          <details><summary>Можно ли арендовать авто на 1 сутки?</summary><p>Да, базовое условие аренды — от 1 суток. Для отдельных автомобилей возможны особые условия, они уточняются при бронировании.</p></details>
          <details><summary>Что делать, если планы изменились?</summary><p>Сообщите менеджеру как можно раньше. Мы проверим, можно ли перенести даты, изменить автомобиль или обновить условия заявки.</p></details>
        </article>

        <article class="faq-category">
          <h2>Документы и водитель</h2>
          <details><summary>Какие документы нужны для аренды авто?</summary><p>Понадобятся паспорт и водительское удостоверение. Они нужны для оформления договора и передачи автомобиля.</p></details>
          <details><summary>Какой нужен стаж вождения?</summary><p>Базовое условие — стаж от 3 лет. Если ситуация нестандартная, возможность аренды лучше заранее обсудить с менеджером.</p></details>
          <details><summary>Можно ли вписать второго водителя?</summary><p>Да, второго водителя можно согласовать заранее. Его данные также нужны для оформления условий аренды.</p></details>
          <details><summary>Есть ли детское кресло?</summary><p>Детское кресло или бустер можно запросить заранее. Наличие лучше подтвердить до передачи автомобиля.</p></details>
        </article>

        <article class="faq-category">
          <h2>Оплата, цена и залог</h2>
          <details><summary>Почему цена указана “от”?</summary><p>Цена зависит от автомобиля, дат, срока аренды, сезона и места подачи. На сайте указан ориентир, а итоговую сумму менеджер подтверждает по заявке.</p></details>
          <details><summary>Есть ли залог?</summary><p>Залог зависит от выбранного автомобиля. Если сумма есть в тарифах, она показывается в карточке авто; если нет, менеджер уточнит её перед бронированием.</p></details>
          <details><summary>Когда возвращается залог?</summary><p>Залог возвращается после возврата и осмотра автомобиля, если нет повреждений, задолженности по аренде, штрафов и нарушений условий договора.</p></details>
          <details><summary>Как можно оплатить аренду?</summary><p>Доступные способы оплаты лучше уточнить при бронировании. Менеджер заранее проговорит сумму, залог и порядок оплаты.</p></details>
        </article>

        <article class="faq-category">
          <h2>Подача и получение</h2>
          <details><summary>Можно ли получить машину у отеля или по адресу?</summary><p>Да, подача по Ялте бесплатная. Укажите адрес, дату и время, чтобы менеджер согласовал передачу автомобиля.</p></details>
          <details><summary>Можно ли подать авто по Крыму?</summary><p>Да, подача по Крыму возможна по договорённости. Стоимость и возможность зависят от места, времени и выбранного автомобиля.</p></details>
          <details><summary>Как проходит осмотр автомобиля?</summary><p>Перед передачей фиксируется состояние автомобиля. При возврате осмотр проводится повторно, чтобы спокойно закрыть аренду.</p></details>
          <details><summary>Где находится Rent RK?</summary><p>Ориентир для получения автомобиля: Ялта, ул. Московская, 33. Перед приездом лучше заранее согласовать время передачи.</p></details>
        </article>

        <article class="faq-category">
          <h2>Во время аренды</h2>
          <details><summary>Можно ли выезжать за пределы Крыма?</summary><p>Такой выезд нужно заранее согласовать с менеджером. Условия зависят от выбранного автомобиля и формата аренды.</p></details>
          <details><summary>Есть ли ограничение по пробегу?</summary><p>Лимит пробега и доплата за превышение подтверждаются при оформлении. Если для выбранного автомобиля есть лимит, менеджер проговорит его до передачи.</p></details>
          <details><summary>Кто оплачивает штрафы?</summary><p>Штрафы за нарушения ПДД в период аренды оплачивает арендатор. Это касается штрафов с камер, парковок и других административных нарушений.</p></details>
          <details><summary>Что делать при ДТП или поломке?</summary><p>Сначала обеспечьте безопасность и при необходимости вызовите экстренные службы. Затем сразу свяжитесь с менеджером и не покидайте место ДТП без оформления и согласования.</p></details>
        </article>
      </div>
    </section>
  </main>
"@
$faqCrumbs = @((Crumb "Главная" "index.html"), (Crumb "FAQ" "pages/faq.html"))
$faqSchemas = @((FaqSchemaFromHtml $faqBody))
WritePage "pages/faq.html" (Layout "FAQ по аренде авто в Ялте | Rent RK" "Ответы на вопросы об аренде авто в Ялте: документы, стаж, залог, подача, оплата, возврат, пробег и действия во время аренды." $faqBody 1 "faq" "pages/faq.html" $faqCrumbs $faqSchemas "assets/img/cars/geely-atlas-pro/geely-atlas-pro-1.jpg")

$contactTrustCards = @(
  InfoFeatureCard 1 "map-pin" "Адрес в Ялте" "Ориентир для получения автомобиля указан на странице контактов и в карточке организации на Яндекс Картах."
  InfoFeatureCard 1 "shield" "Осмотр автомобиля" "Перед передачей и при возврате фиксируем состояние машины, чтобы условия были понятны обеим сторонам."
  InfoFeatureCard 1 "wallet" "Цена до оформления" "Стоимость, залог и подачу подтверждаем до передачи автомобиля, по выбранным датам и машине."
  InfoFeatureCard 1 "telegram" "Быстрая связь" "Если нужно уточнить свободность или условия, проще всего написать в Telegram или позвонить."
) -join "`n"
$contactsBody = @"
  <main>
    <section class="hero compact" style="--hero-image: url('/assets/img/cars/mercedes-benz-c300/mercedes-benz-c300-2.jpg')">
      <div class="container hero-content">
        <p class="eyebrow">Контакты</p>
        <h1>Связаться с Rent RK</h1>
        <p class="lead">Ялта, ул. Московская, 33. Быстрее всего уточнить доступность автомобиля по телефону или в Telegram.</p>
      </div>
    </section>
    <section class="section">
      <div class="container grid two">
        <div class="feature"><h2>Контакты</h2><p><a href="$phoneHref">$phoneHuman</a><br><a href="$telegram">Telegram</a><br>Ялта, ул. Московская, 33</p></div>
        <div class="feature"><h2>Подача</h2><p>Доставка по Ялте бесплатная. Подача автомобиля по Крыму возможна по договоренности.</p></div>
      </div>
    </section>
    <section class="section soft">
      <div class="container section-head compact-head">
        <div>
          <p class="eyebrow">Доверие</p>
          <h2>Что можно уточнить до встречи</h2>
          <p>Контакты нужны не только для связи: до передачи автомобиля лучше заранее проговорить свободность, цену, залог, подачу и порядок оформления.</p>
        </div>
      </div>
      <div class="container grid four decision-grid">
        $contactTrustCards
      </div>
    </section>
    <section class="section soft">
      <div class="container section-head">
        <div>
          <p class="eyebrow">Адрес на карте</p>
          <h2>Мы на Яндекс Картах</h2>
          <p>Ориентир для получения автомобиля: Ялта, ул. Московская, 33. Перед приездом лучше заранее согласовать время передачи машины с менеджером.</p>
        </div>
        <a class="btn secondary" href="$yandexMapUrl" target="_blank" rel="noopener">Открыть в Яндекс Картах</a>
      </div>
      <div class="container map-block">
        <iframe src="$yandexMapEmbed" title="Rent RK на Яндекс Картах" loading="lazy" allowfullscreen></iframe>
      </div>
    </section>
    <section class="section">
      <div class="container section-head">
        <div>
          <p class="eyebrow">Отзывы</p>
          <h2>Отзывы клиентов на Яндекс Картах</h2>
          <p>Отзывы загружаются из карточки организации на Яндекс Картах. Если виджет не открылся, можно перейти в карточку организации по ссылке.</p>
        </div>
        <a class="btn secondary" href="$yandexMapUrl" target="_blank" rel="noopener">Смотреть на Яндекс Картах</a>
      </div>
      <div class="container reviews-layout">
        <div class="reviews-widget">
          <iframe src="https://yandex.ru/maps-reviews-widget/134040500420?comments" title="Отзывы Rent RK на Яндекс Картах" loading="lazy"></iframe>
          <a href="https://yandex.ru/maps/org/apriori/134040500420/" target="_blank" rel="noopener">Априори на карте Ялты — Яндекс Карты</a>
        </div>
        <div class="feature">
          <h2>Перед получением авто</h2>
          <p>Чтобы передача автомобиля прошла спокойно и без лишнего ожидания, лучше связаться с нами заранее — написать или позвонить.</p>
          <p>Мы уточним, какие автомобили свободны на нужные даты, подскажем условия аренды, размер залога, стоимость подачи, если автомобиль нужен не в Ялте, и согласуем удобное место и время передачи ключей.</p>
          <p>Перед встречей также можно заранее обсудить важные детали:</p>
          <ul class="compact-list">
            <li>срок аренды и время получения/возврата;</li>
            <li>требования к водителю и необходимые документы;</li>
            <li>условия залога и его возврата;</li>
            <li>наличие детского кресла, бустера или других дополнительных принадлежностей;</li>
            <li>возможность подачи автомобиля по Ялте или в другой населенный пункт Крыма;</li>
            <li>удобный способ оплаты и оформления договора.</li>
          </ul>
          <p>На месте мы осматриваем автомобиль вместе с арендатором, фиксируем его состояние, объясняем основные условия пользования, порядок действий при ДТП или поломке и отвечаем на вопросы по конкретной машине.</p>
          <p>Так вы заранее понимаете все условия, а получение автомобиля занимает меньше времени и проходит без спешки.</p>
        </div>
      </div>
    </section>
  </main>
"@
$contactsCrumbs = @((Crumb "Главная" "index.html"), (Crumb "Контакты" "pages/contacts.html"))
WritePage "pages/contacts.html" (Layout "Контакты автопроката Rent RK в Ялте" "Контакты Rent RK: телефон, Telegram, адрес в Ялте и условия подачи автомобиля." $contactsBody 1 "contacts" "pages/contacts.html" $contactsCrumbs @() "assets/img/cars/mercedes-benz-c300/mercedes-benz-c300-2.jpg")

$servicePages = @(
  @{
    File="arenda-avto-v-yalte.html"
    H1="Аренда авто в Ялте"
    Title="Аренда авто в Ялте | Rent RK"
    Description="Аренда авто в Ялте: каталог машин, подача по городу, аренда от 1 суток, документы, залог и подтверждение стоимости по датам."
    Lead="Автомобиль можно получить в Ялте, подача по городу бесплатная. Выберите машину, проверьте даты и отправьте заявку на конкретную модель."
    Bullets=@("аренда от 1 суток", "подача по Ялте бесплатно", "для оформления нужны паспорт и права", "стоимость и залог подтверждаются по выбранным датам")
    Cars="all"
  },
  @{
    File="arenda-avto-v-krymu.html"
    H1="Аренда авто в Крыму"
    Title="Аренда авто в Крыму | Rent RK"
    Description="Аренда авто в Крыму с подачей по договорённости: автомобили из каталога, условия, документы, залог и подтверждение цены."
    Lead="Если автомобиль нужен не в Ялте, укажите город, дату и время подачи. Возможность и стоимость подачи по Крыму менеджер подтверждает заранее."
    Bullets=@("подача по Крыму согласуется отдельно", "условия зависят от места и времени", "автомобиль выбирается из текущего каталога", "финальная сумма подтверждается до передачи")
    Cars="all"
  },
  @{
    File="arenda-avto-bez-voditelya.html"
    H1="Аренда авто без водителя"
    Title="Аренда авто без водителя в Ялте | Rent RK"
    Description="Аренда авто без водителя в Ялте: машины из каталога, стаж от 3 лет, паспорт и права, подача по Ялте, заявка по датам."
    Lead="Самостоятельная аренда подходит, если вы хотите сами управлять автомобилем и заранее понимаете даты, место получения и возврата."
    Bullets=@("стаж водителя от 3 лет", "паспорт и водительское удостоверение", "осмотр автомобиля перед передачей", "условия возврата фиксируются при оформлении")
    Cars="all"
  },
  @{
    File="arenda-avto-s-voditelem.html"
    H1="Аренда авто с водителем"
    Title="Аренда авто с водителем в Ялте | Rent RK"
    Description="Аренда авто с водителем в Ялте по предварительному согласованию: условия зависят от времени, автомобиля и формата услуги."
    Lead="Аренда с водителем обсуждается индивидуально. Напишите дату, время, количество пассажиров и требования к автомобилю, чтобы менеджер проверил возможность."
    Bullets=@("условия рассчитываются индивидуально", "нужно заранее согласовать время и формат", "автомобиль подбирается из доступных вариантов", "стоимость подтверждается менеджером")
    Cars="all"
  },
  @{
    File="arenda-krossovera.html"
    H1="Аренда кроссовера в Ялте"
    Title="Аренда кроссовера в Ялте | Rent RK"
    Description="Аренда кроссовера в Ялте: Jaecoo, Omoda, Exeed, Geely, Volkswagen и другие машины из текущего каталога."
    Lead="Кроссовер удобен, когда важны высокая посадка, запас места и уверенное поведение на разных типах дорог. Конкретную машину лучше выбирать по датам, цене и залогу."
    Bullets=@("в каталоге есть кроссоверы разных ценовых уровней", "часть машин имеет полный привод", "количество мест и двигатель указаны в карточке", "наличие проверяется по выбранным датам")
    Cars="crossovers"
  },
  @{
    File="arenda-avto-7-mest.html"
    H1="Аренда авто на 7 мест"
    Title="Аренда авто на 7 мест в Ялте | Rent RK"
    Description="Аренда авто на 7 мест в Ялте: доступные модели из каталога, условия подачи, цена, залог и заявка по датам."
    Lead="Автомобиль на 7 мест стоит выбирать, когда важно разместить больше пассажиров в одной машине. Доступность зависит от дат и подтверждается менеджером."
    Bullets=@("количество мест указано в карточке автомобиля", "цена зависит от дат и срока аренды", "подача по Ялте бесплатная", "условия по Крыму согласуются отдельно")
    Cars="seven"
  },
  @{
    File="podacha-avtomobilya.html"
    H1="Подача автомобиля"
    Title="Подача автомобиля по Ялте и Крыму | Rent RK"
    Description="Подача автомобиля по Ялте и Крыму: бесплатная доставка по Ялте, подача по Крыму по договорённости, согласование даты и адреса."
    Lead="По Ялте подача бесплатная. Если автомобиль нужен в другом месте, укажите адрес, дату и время: менеджер подтвердит возможность и условия."
    Bullets=@("по Ялте подача бесплатная", "по Крыму условия согласуются отдельно", "важно указать точный адрес и время", "место возврата можно обсудить заранее")
    Cars="all"
  }
)
foreach($p in $servicePages) {
  $bulletHtml = ($p.Bullets | ForEach-Object { "<li>$(HtmlAttr $_)</li>" }) -join "`n"
  $carsForService = switch ($p.Cars) {
    "crossovers" { $script:serviceCrossovers }
    "seven" { $script:serviceSevenSeats }
    default { $publicShowcaseCars }
  }
  $serviceCarsHtml = PublicCarLinkListHtml $carsForService 1 7
  $serviceLinks = @(
    InfoLinkCard 1 "document" "../pages/conditions.html" "Условия аренды" "Проверьте документы, стаж, залог и порядок возврата."
    InfoLinkCard 1 "info" "../pages/faq.html" "FAQ" "Ответы на частые вопросы перед заявкой."
    InfoLinkCard 1 "phone" "../pages/contacts.html" "Контакты" "Уточните свободность, подачу и детали оформления."
  ) -join "`n"
  $body = @"
  <main>
    <section class="hero compact" style="--hero-image: url('/assets/img/cars/omoda-c5/omoda-c5-1.jpg')">
      <div class="container hero-content"><p class="eyebrow">Услуга</p><h1>$($p.H1)</h1><p class="lead">$($p.Lead)</p></div>
    </section>
    <section class="section">
      <div class="container service-layout">
        <article class="text-page">
          <p class="eyebrow">Важно</p>
          <h2>Что учесть перед заявкой</h2>
          <p>$($p.Lead)</p>
          <ul class="info-list">
            $bulletHtml
          </ul>
        </article>
        <aside class="feature decision-card">
          <div class="feature__title">$(BrIcon 1 "check" "br-icon--md")<h3>Как быстрее оформить</h3></div>
          <p>Выберите автомобиль в каталоге, укажите даты и место подачи. После заявки менеджер подтвердит свободность, цену, залог и детали передачи.</p>
          <a class="btn" href="../cars/index.html">Проверить автомобили</a>
        </aside>
      </div>
    </section>
    <section class="section soft">
      <div class="container service-layout">
        <article class="text-page">
          <p class="eyebrow">Автомобили</p>
          <h2>Подходящие варианты из каталога</h2>
          <p>Список берётся из текущей публичной витрины. Доступность конкретной машины нужно проверять по датам.</p>
          $serviceCarsHtml
        </article>
        <aside class="feature decision-card">
          <div class="feature__title">$(BrIcon 1 "wallet" "br-icon--md")<h3>Цена и залог</h3></div>
          <p>Цена на странице автомобиля указана как ориентир “от”. Залог показывается, если он есть в тарифах; остальные суммы подтверждаются менеджером.</p>
        </aside>
      </div>
    </section>
    <section class="section">
      <div class="container grid three decision-grid">
        $serviceLinks
      </div>
    </section>
  </main>
"@
  $serviceRelative = "pages/" + $p.File
  $serviceCrumbs = @((Crumb "Главная" "index.html"), (Crumb $p.H1 $serviceRelative))
  WritePage $serviceRelative (Layout $p.Title $p.Description $body 1 "" $serviceRelative $serviceCrumbs @() "assets/img/cars/omoda-c5/omoda-c5-1.jpg")
}

$routeCards = ($routeItems | ForEach-Object { RouteCard $_ 1 }) -join "`n"
$forCouples = ($routeItems | Where-Object { $_.audience -contains "для пары" } | Select-Object -First 4 | ForEach-Object { "<li><a href=""$($_.slug).html"">$($_.title)</a></li>" }) -join "`n"
$forFamily = ($routeItems | Where-Object { $_.audience -contains "для семьи" } | Select-Object -First 4 | ForEach-Object { "<li><a href=""$($_.slug).html"">$($_.title)</a></li>" }) -join "`n"
$forNature = ($routeItems | Where-Object { $_.audience -contains "природа" } | Select-Object -First 8 | ForEach-Object { "<li><a href=""$($_.slug).html"">$($_.title)</a></li>" }) -join "`n"
$forHistory = ($routeItems | Where-Object { $_.audience -contains "история" } | Select-Object -First 6 | ForEach-Object { "<li><a href=""$($_.slug).html"">$($_.title)</a></li>" }) -join "`n"

$routesBody = @"
  <main>
    <section class="hero compact" style="--hero-image: url('/assets/img/cars/exeed-vx-7-mest/exeed-vx-7-mest-1.jpg')">
      <div class="container hero-content"><p class="eyebrow">Маршруты</p><h1>Маршруты из Ялты на авто</h1><p class="lead">Подбор маршрутов для спокойных прогулок, горных выездов, семейных поездок, истории и больших путешествий по Крыму.</p></div>
    </section>
    <section class="section">
      <div class="container section-head">
        <div>
          <p class="eyebrow">Идеи поездок</p>
          <h2>Каталог маршрутов</h2>
          <p>Выберите настроение поездки, а автомобиль подберем под дорогу, количество пассажиров и темп дня.</p>
        </div>
        <a class="btn secondary" href="../cars/index.html">Выбрать авто</a>
      </div>
      <div class="container grid cards">$routeCards</div>
    </section>
    <section class="section soft">
      <div class="container section-head">
        <div>
          <p class="eyebrow">Подборки</p>
          <h2>Маршруты по настроению</h2>
        </div>
      </div>
      <div class="container grid four">
        <div class="feature"><h3>Для пары</h3><ul class="compact-list">$forCouples</ul></div>
        <div class="feature"><h3>Для семьи</h3><ul class="compact-list">$forFamily</ul></div>
        <div class="feature"><h3>Для природы</h3><ul class="compact-list">$forNature</ul></div>
        <div class="feature"><h3>Для истории</h3><ul class="compact-list">$forHistory</ul></div>
      </div>
    </section>
    <section class="section">
      <div class="container cta-band">
        <div>
          <h2>Нужна машина под конкретный маршрут?</h2>
          <p>Напишите, куда хотите поехать и сколько человек будет в машине. Подскажем класс авто и условия подачи.</p>
        </div>
        <a class="btn" href="$telegram">Обсудить маршрут</a>
      </div>
    </section>
  </main>
"@
$routesCrumbs = @((Crumb "Главная" "index.html"), (Crumb "Маршруты" "routes/index.html"))
WritePage "routes/index.html" (Layout "Маршруты из Ялты на арендованном авто | Rent RK" "Маршруты из Ялты по Крыму: Ливадия, Ай-Петри, Бахчисарай, Севастополь, Новый Свет, Тарханкут и другие направления." $routesBody 1 "routes" "routes/index.html" $routesCrumbs @() "assets/img/cars/exeed-vx-7-mest/exeed-vx-7-mest-1.jpg")

foreach ($route in $routeItems) {
  $audienceText = ($route.audience -join ", ")
  $body = @"
  <main>
    <section class="hero compact" style="--hero-image: url('/assets/img/cars/volkswagen-tiguan-r-line/volkswagen-tiguan-r-line-1.jpg')">
      <div class="container hero-content">
        <p class="eyebrow">$($route.type)</p>
        <h1>Маршрут из Ялты: $($route.title)</h1>
        <p class="lead">$($route.summary)</p>
        <div class="hero-actions">
          <a class="btn" href="../cars/index.html">Выбрать автомобиль</a>
          <a class="btn secondary" href="$telegram">Обсудить поездку</a>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="container text-page">
        <h2>Кому подойдет маршрут</h2>
        <p>$($route.description)</p>
        <table class="specs">
          <tr><th>Формат</th><td>$($route.type)</td></tr>
          <tr><th>Продолжительность</th><td>$($route.duration)</td></tr>
          <tr><th>Подойдет</th><td>$audienceText</td></tr>
          <tr><th>Рекомендуемый автомобиль</th><td>$($route.car)</td></tr>
          <tr><th>Подача</th><td>По Ялте бесплатно, по Крыму по договоренности</td></tr>
        </table>
      </div>
    </section>
    <section class="section soft">
      <div class="container cta-band">
        <div>
          <h2>Подберем авто для этого маршрута</h2>
          <p>Для спокойных маршрутов подойдет седан, для горных и дальних направлений чаще удобнее кроссовер.</p>
        </div>
        <a class="btn" href="../cars/index.html">Смотреть автомобили</a>
      </div>
    </section>
  </main>
"@
  $routeRelative = "routes/" + $route.slug + ".html"
  $routeCrumbs = @((Crumb "Главная" "index.html"), (Crumb "Маршруты" "routes/index.html"), (Crumb $route.title $routeRelative))
  WritePage $routeRelative (Layout ("Маршрут из Ялты: " + $route.title + " | Rent RK") ($route.summary + " Аренда авто в Ялте для поездок по Крыму.") $body 1 "routes" $routeRelative $routeCrumbs @() "assets/img/cars/volkswagen-tiguan-r-line/volkswagen-tiguan-r-line-1.jpg")
}

$partnerPublicRoot = Join-Path $root "partner"
if (-not $script:BuildFixtureMode -and (Test-Path $partnerPublicRoot)) {
  Get-ChildItem -Path $partnerPublicRoot -Directory | ForEach-Object {
    RemoveGeneratedOutputTree (Get-BuildRelativePathFromFullPath $root $_.FullName) "partner pages are regenerated as a set"
  }
}

foreach ($partner in $partnerItems) {
  WritePage ("partner/" + $partner.slug + "/index.html") (PartnerPage $partner)
  foreach ($agent in (PartnerAgents $partner.slug)) {
    WritePage ("partner/" + $partner.slug + "/" + $agent.slug + "/index.html") (PartnerPage $partner $agent)
  }
}

WritePage "robots.txt" "User-agent: *`nDisallow: /admin/`nDisallow: /api/`nDisallow: /data/`nAllow: /`nSitemap: $siteBaseUrl/sitemap.xml`n"

$urls = @("/", "/cars/")
$urls += $publicShowcaseCars | ForEach-Object { "/cars/$($_.slug).html" }
$urls += @("/pages/conditions.html","/pages/faq.html","/pages/contacts.html","/pages/arenda-avto-v-yalte.html","/pages/arenda-avto-v-krymu.html","/pages/arenda-avto-bez-voditelya.html","/pages/arenda-avto-s-voditelem.html","/pages/arenda-krossovera.html","/pages/arenda-avto-7-mest.html","/pages/podacha-avtomobilya.html","/routes/")
$urls += $routeItems | ForEach-Object { "/routes/$($_.slug).html" }
$urls += $partnerItems | ForEach-Object { "/partner/$($_.slug)/" }
$xmlUrls = ($urls | ForEach-Object { "  <url><loc>$siteBaseUrl$_</loc></url>" }) -join "`n"
WritePage "sitemap.xml" "<?xml version=`"1.0`" encoding=`"UTF-8`"?>`n<urlset xmlns=`"http://www.sitemaps.org/schemas/sitemap/0.9`">`n$xmlUrls`n</urlset>`n"

Write-Host "Build-site rendering completed"
$carsReadLabel = if ($script:BuildFixtureMode) { "Fixture cars read" } else { "Private cars read" }
$ratesReadLabel = if ($script:BuildFixtureMode) { "Rates loaded from fixture" } else { "Rates loaded from private" }
Write-Host ("{0}: {1}" -f $carsReadLabel, @($cars).Count)
Write-Host ("Public showcase pages: {0}" -f @($publicShowcaseCars).Count)
Write-Host ("Hidden/skipped cars: {0}" -f @($hiddenPublicCars).Count)
Write-Host ("Partner pages: {0}" -f @($partnerItems).Count)
Write-Host ("Route pages: {0}" -f @($routeItems).Count)
Write-Host ("{0}: {1}" -f $ratesReadLabel, $script:ratesByCar.Count)

Write-BuildManifestSummary
if ($BaselineAudit) {
  Update-BuildBaselineManifest
  Write-BuildBaselineAuditSummary
}

if ($RegisterBaseline) {
  $registration = Register-BuildBaselineManifest
  $runRecord = [ordered]@{
    id = $runId
    mode = $Mode
    dryRun = [bool]$DryRun
    noPublicData = [bool]$NoPublicData
    noDelete = [bool]$NoDelete
    backup = [bool]$Backup
    slug = [string]$Slug
    allowedOutputs = @($script:BuildAllowedOutputPaths.Keys)
    fullSiteRebuildPrevented = [bool]($script:BuildPageContentOnly -or $script:BuildCarOnly)
    baselineAudit = [bool]$BaselineAudit
    registerBaseline = [bool]$RegisterBaseline
    startedAt = $runId
    finishedAt = (Get-Date).ToString("s")
    status = "registered-baseline"
    outputs = @($script:BuildOutputManifest).Count
    deletes = @($script:BuildDeleteManifest).Count
    baselineRegistered = [int]$registration.registered
    baselineSkipped = [int]$registration.skipped
    publicData = $script:BuildPublicDataAction
  }
  $script:BuildState.lastRun = $runRecord
  $script:BuildState.runs = @($runRecord) + @($script:BuildState.runs | Select-Object -First 49)
  $script:BuildState.updatedAt = (Get-Date).ToString("s")
  Write-BuildState $buildStatePath $script:BuildState
  Write-Host ("Baseline registered outputs: {0}; skipped: {1}" -f $registration.registered, $registration.skipped)
  Write-Host ("Build state updated: {0}" -f (Get-BuildRelativePathFromFullPath $root $buildStatePath))
  Write-Host "RegisterBaseline completed without writing generated outputs or public data."
} elseif (-not $DryRun) {
  if ($script:BuildCarOnly) {
    $script:BuildState.dirty = @(Get-BuildDirtyItems $script:BuildState | Where-Object {
      -not (
        [string](Get-BuildPropertyValue $_ "entityType" "") -eq "car" -and
        [string](Get-BuildPropertyValue $_ "entityId" "") -eq [string]$Slug
      )
    })
  }
  $runRecord = [ordered]@{
    id = $runId
    mode = $Mode
    dryRun = [bool]$DryRun
    noPublicData = [bool]$NoPublicData
    noDelete = [bool]$NoDelete
    backup = [bool]$Backup
    slug = [string]$Slug
    allowedOutputs = @($script:BuildAllowedOutputPaths.Keys)
    fullSiteRebuildPrevented = [bool]($script:BuildPageContentOnly -or $script:BuildCarOnly)
    baselineAudit = [bool]$BaselineAudit
    registerBaseline = [bool]$RegisterBaseline
    startedAt = $runId
    finishedAt = (Get-Date).ToString("s")
    status = "completed"
    outputs = @($script:BuildOutputManifest).Count
    deletes = @($script:BuildDeleteManifest).Count
    publicData = $script:BuildPublicDataAction
  }
  $script:BuildState.lastRun = $runRecord
  $script:BuildState.runs = @($runRecord) + @($script:BuildState.runs | Select-Object -First 49)
  $script:BuildState.updatedAt = (Get-Date).ToString("s")
  Write-BuildState $buildStatePath $script:BuildState
  Write-Host ("Build state updated: {0}" -f (Get-BuildRelativePathFromFullPath $root $buildStatePath))
} else {
  Write-Host "Dry-run completed without writing build-state or generated outputs."
}
} finally {
  if ($null -ne $buildLease) { $buildLease.Dispose() }
}
