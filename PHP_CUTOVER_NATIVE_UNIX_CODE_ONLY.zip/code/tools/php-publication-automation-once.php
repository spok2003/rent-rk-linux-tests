<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || !RENT_RK_AUDIT_ISOLATION_VERIFIED
    || !defined('RENT_RK_PHP_PUBLICATION_AUTOMATION') || RENT_RK_PHP_PUBLICATION_AUTOMATION !== true) {
    fwrite(STDERR, "Verified automation laboratory required.\n");
    exit(2);
}
require __DIR__ . '/../admin/includes/bootstrap.php';
try {
    echo json_encode(PhpPublicationAutomation::once(), JSON_THROW_ON_ERROR) . PHP_EOL;
} catch (Throwable $e) {
    fwrite(STDERR, "Automation stopped; no publication acknowledged.\n");
    exit(1);
}
