<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || !RENT_RK_AUDIT_ISOLATION_VERIFIED
    || realpath((string) getenv('RENT_RK_AUDIT_LAB_ROOT')) !== realpath(__DIR__ . '/..')) throw new RuntimeException('Verified synthetic lab required.');
$mode = $argv[1] ?? '';
if (str_starts_with($mode, 'race-')) {
    touch(__DIR__ . '/../tmp/sitemap-ready-' . $mode);
    $until = microtime(true) + 12;
    while (!is_file(__DIR__ . '/../tmp/sitemap-go') && microtime(true) < $until) usleep(10000);
    if (!is_file(__DIR__ . '/../tmp/sitemap-go')) throw new RuntimeException('Barrier timeout.');
}
define('ADMIN_USER', 'qa-snapshot-root');
require __DIR__ . '/../admin/includes/bootstrap.php';
require __DIR__ . '/../admin/includes/approved-public-car-snapshot.php';
$_SESSION['admin_user'] = 'qa-snapshot-root';
$env = ['sapi' => PHP_SAPI, 'php' => PHP_VERSION, 'cache' => ini_get('opcache.enable'), 'cliCache' => ini_get('opcache.enable_cli'), 'fileCache' => ini_get('opcache.file_cache')];
$slug = $argv[2] ?? 'synthetic-approved-car';
try {
    $service = ApprovedPublicCarSnapshots::fromServer();
    $result = match ($mode) {
        'preview' => $service->candidate($slug)['reviewVersion'],
        'approve' => $service->approve($slug, $service->candidate($slug)['reviewVersion'], true),
        'plan', 'race-plan' => $service->plan($slug),
        'prepare-option-c' => car_publication_prepare_plan($slug),
        'inspect' => ApprovedPublicCarSnapshots::store()['version'],
        'fields' => ['draft_id' => 'd-main', 'command_id' => bin2hex(random_bytes(16)),
            'expected_version' => business_form_version(demand_publication_action_paths($slug)), 'expected_sitemap_hash' => demand_sitemap_version()],
        default => null,
    };
    if (in_array($mode, ['demand', 'crash-prepared', 'crash-committed', 'race-demand'], true)) {
        $payload = json_decode(base64_decode($argv[3], true), true, 32, JSON_THROW_ON_ERROR);
        if (str_starts_with($mode, 'crash-')) {
            $GLOBALS['rental_return_test_hook'] = static function (string $point) use ($mode): void {
                if ($mode === 'crash-prepared' && $point === 'write.after_rename.sitemap.xml') exit(73);
                if ($mode === 'crash-committed' && $point === 'journal.committed') exit(74);
            };
        }
        $result = demand_publication_execute($slug, $payload, 'rent_rk', static fn() => match ($slug) {
            'workflow_publish_indexed' => demand_workflow_publish_indexed('d-main'),
            'workflow_close_index' => demand_workflow_close_from_index('d-main'),
            'workflow_request_index' => demand_workflow_request_index_review('d-main'),
            default => throw new LogicException('Unexpected QA Demand action.'),
        });
    }
    echo json_encode(['result' => $result, 'environment' => $env], JSON_THROW_ON_ERROR);
} catch (Throwable $e) {
    echo json_encode(['error' => $e->getMessage(), 'code' => $e->getCode(), 'environment' => $env], JSON_THROW_ON_ERROR);
    exit(1);
}
