$script:BuildStateVersion = 1
if (-not (Get-Variable BuildAtomic -Scope Script -ErrorAction SilentlyContinue)) { $script:BuildAtomic = $false }
if (-not (Get-Variable BuildInputSnapshot -Scope Script -ErrorAction SilentlyContinue)) { $script:BuildInputSnapshot = @{} }
if (-not (Get-Variable BuildTransactionSnapshot -Scope Script -ErrorAction SilentlyContinue)) { $script:BuildTransactionSnapshot = $null }

function Resolve-BuildInputPath([string]$Path) {
  $full = [IO.Path]::GetFullPath($Path)
  if ($script:BuildAtomic) {
    $alias = [IO.Path]::GetFullPath((Join-Path $root "private/rent-rk-data")).TrimEnd("\", "/") + [IO.Path]::DirectorySeparatorChar
    if ($full.StartsWith($alias, [StringComparison]::OrdinalIgnoreCase)) {
      return [IO.Path]::GetFullPath((Join-Path $privateDataDir $full.Substring($alias.Length)))
    }
  }
  return $full
}

function Test-BuildInputExists([string]$Path) {
  $full = Resolve-BuildInputPath $Path
  if ($script:BuildInputSnapshot -and $script:BuildInputSnapshot.ContainsKey($full)) { return $null -ne $script:BuildInputSnapshot[$full] }
  return Test-Path -LiteralPath $full -PathType Leaf
}

function Read-BuildInputRaw([string]$Path) {
  $full = Resolve-BuildInputPath $Path
  if ($script:BuildInputSnapshot -and $script:BuildInputSnapshot.ContainsKey($full)) {
    if ($null -eq $script:BuildInputSnapshot[$full]) { return $null }
    return [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($script:BuildInputSnapshot[$full])).TrimStart([char]0xfeff)
  }
  return Get-Content -LiteralPath $full -Raw -Encoding UTF8
}

function Invoke-BuildTransaction([string]$Action, $Payload) {
  $psi = New-Object Diagnostics.ProcessStartInfo
  $psi.FileName = $PhpExecutable
  $bridge = Join-Path $PSScriptRoot "build-site-transaction.php"
  $psi.Arguments = '-d opcache.enable=0 -d opcache.enable_cli=0 -d opcache.file_cache= -d opcache.file_cache_only=0 "' + $bridge + '" ' + $Action
  $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
  $psi.RedirectStandardInput = $true; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
  $psi.StandardOutputEncoding = New-Object Text.UTF8Encoding($false)
  $process = [Diagnostics.Process]::Start($psi)
  try {
    $output = $process.StandardOutput.ReadToEndAsync(); $errorOutput = $process.StandardError.ReadToEndAsync()
    # Windows PowerShell's ProcessStartInfo has no StandardInputEncoding.
    $json = $Payload | ConvertTo-Json -Depth 64 -Compress
    $ascii = [regex]::Replace($json, '[^\x00-\x7f]', [Text.RegularExpressions.MatchEvaluator]{ param($match) '\u' + ([int][char]$match.Value).ToString('x4') })
    $process.StandardInput.Write($ascii); $process.StandardInput.Close()
    $process.WaitForExit(); $wire = $output.GetAwaiter().GetResult(); $errorText = $errorOutput.GetAwaiter().GetResult()
    if ($process.ExitCode -ne 0) {
      $failure = $null; try { $failure = $wire | ConvertFrom-Json } catch {}
      if ($failure -and $failure.error) { throw ("Build transaction refused: " + $failure.error) }
      throw "Build transaction participant failed before a confirmed commit."
    }
    $reply = $wire | ConvertFrom-Json
    if ($reply.environment) { Write-Host ("Build transaction participant: " + ($reply.environment | ConvertTo-Json -Compress)) }
    return $reply
  } finally { $process.Dispose() }
}

function New-BuildStateDefault {
  return [ordered]@{
    version = $script:BuildStateVersion
    updatedAt = $null
    lastRun = $null
    outputs = [ordered]@{}
    dirty = @()
    conflicts = @()
    runs = @()
  }
}

function Get-BuildPropertyValue {
  param(
    $Object,
    [string]$Name,
    $Default = $null
  )

  if ($null -eq $Object) { return $Default }
  if ($Object -is [System.Collections.IDictionary]) {
    if ($Object.Contains($Name)) { return $Object[$Name] }
    return $Default
  }
  $property = $Object.PSObject.Properties[$Name]
  if ($null -ne $property) { return $property.Value }
  return $Default
}

function ConvertTo-BuildObjectArray {
  param($Value)

  if ($null -eq $Value) { return @() }
  return @($Value | ForEach-Object { $_ })
}

function ConvertTo-BuildOrderedMap {
  param($Value)

  $map = [ordered]@{}
  if ($null -eq $Value) { return $map }
  if ($Value -is [System.Collections.IDictionary]) {
    foreach ($key in @($Value.Keys | Sort-Object)) {
      $map[[string]$key] = $Value[$key]
    }
    return $map
  }

  foreach ($property in @($Value.PSObject.Properties | Sort-Object Name)) {
    $map[[string]$property.Name] = $property.Value
  }
  return $map
}

function Read-BuildState {
  param([string]$Path)

  $state = New-BuildStateDefault
  if (-not (Test-BuildInputExists $Path)) { return $state }

  $raw = Read-BuildInputRaw $Path
  if ([string]::IsNullOrWhiteSpace($raw)) { return $state }

  $parsed = $raw | ConvertFrom-Json
  $version = [int](Get-BuildPropertyValue $parsed "version" $script:BuildStateVersion)
  if ($version -lt 1) { $version = $script:BuildStateVersion }

  $state.version = $version
  $state.updatedAt = Get-BuildPropertyValue $parsed "updatedAt" $null
  $state.lastRun = Get-BuildPropertyValue $parsed "lastRun" $null
  $state.outputs = ConvertTo-BuildOrderedMap (Get-BuildPropertyValue $parsed "outputs" $null)
  $state.dirty = ConvertTo-BuildObjectArray (Get-BuildPropertyValue $parsed "dirty" @())
  $state.conflicts = ConvertTo-BuildObjectArray (Get-BuildPropertyValue $parsed "conflicts" @())
  $state.runs = ConvertTo-BuildObjectArray (Get-BuildPropertyValue $parsed "runs" @())
  return $state
}

function Write-BuildState {
  param(
    [string]$Path,
    $State
  )

  if ($script:BuildAtomic) {
    $reply = Invoke-BuildTransaction "commit" ([ordered]@{ id = $runId; version = $script:BuildTransactionSnapshot.version;
      state = $State; outputs = $script:BuildPendingOutputs; deletes = @($script:BuildPendingDeletes.Keys) })
    if (-not $reply.committed) { throw "Build commit was not confirmed." }
    return
  }
  $directory = Split-Path -Parent $Path
  if (-not (Test-Path -LiteralPath $directory)) {
    New-Item -ItemType Directory -Force -Path $directory | Out-Null
  }

  $json = $State | ConvertTo-Json -Depth 64
  $encoding = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($Path, $json + [Environment]::NewLine, $encoding)
}

function Normalize-BuildRelativePath {
  param([string]$RelativePath)

  $relative = ([string]$RelativePath).Replace("\", "/").Trim()
  if ($relative -eq "") { throw "Build output path is empty." }
  if ([System.IO.Path]::IsPathRooted($relative)) {
    throw "Build output path must be relative: $relative"
  }
  if ($relative -match '(^|/)\.\.($|/)') {
    throw "Build output path must not contain parent traversal: $relative"
  }
  return $relative.TrimStart("/")
}

function Get-BuildAbsolutePath {
  param(
    [string]$Root,
    [string]$RelativePath
  )

  $relative = Normalize-BuildRelativePath $RelativePath
  return [System.IO.Path]::GetFullPath((Join-Path $Root $relative))
}

function Get-BuildRelativePathFromFullPath {
  param(
    [string]$Root,
    [string]$Path
  )

  $rootFull = [System.IO.Path]::GetFullPath($Root).TrimEnd("\", "/") + [System.IO.Path]::DirectorySeparatorChar
  $pathFull = [System.IO.Path]::GetFullPath($Path)
  if (-not $pathFull.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Path is outside build root: $Path"
  }
  return ($pathFull.Substring($rootFull.Length)).Replace("\", "/")
}

function Get-BuildTextHash {
  param([AllowNull()][string]$Text)

  if ($null -eq $Text) { $Text = "" }
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $hash = $sha.ComputeHash($bytes)
    return "sha256:" + ([System.BitConverter]::ToString($hash).Replace("-", "").ToLowerInvariant())
  } finally {
    $sha.Dispose()
  }
}

function Get-BuildFileHashValue {
  param([string]$Path)

  $Path = Resolve-BuildInputPath $Path
  if ($script:BuildInputSnapshot -and $script:BuildInputSnapshot.ContainsKey($Path)) {
    if ($null -eq $script:BuildInputSnapshot[$Path]) { return $null }
    $hash = [Security.Cryptography.SHA256]::Create()
    try { return "sha256:" + ([BitConverter]::ToString($hash.ComputeHash([Convert]::FromBase64String($script:BuildInputSnapshot[$Path]))).Replace("-", "").ToLowerInvariant()) } finally { $hash.Dispose() }
  }
  if ($script:BuildTransactionSnapshot) {
    $rootPrefix = [IO.Path]::GetFullPath($root).TrimEnd("\", "/") + [IO.Path]::DirectorySeparatorChar
    if ($Path.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
      $relative = $Path.Substring($rootPrefix.Length).Replace("\", "/")
      $known = $script:BuildTransactionSnapshot.outputs.PSObject.Properties[$relative]
      if ($null -ne $known) { if ($null -eq $known.Value) { return $null }; return "sha256:" + $known.Value }
    }
  }
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
  return "sha256:" + ((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant())
}

function ConvertTo-BuildSortedJsonValue {
  param($Value)

  if ($null -eq $Value) { return $null }
  if ($Value -is [string]) { return $Value }
  if ($Value -is [ValueType]) { return $Value }
  if ($Value -is [System.Collections.IDictionary]) {
    $map = [ordered]@{}
    foreach ($key in @($Value.Keys | Sort-Object)) {
      $map[[string]$key] = ConvertTo-BuildSortedJsonValue $Value[$key]
    }
    return $map
  }
  if ($Value -is [System.Collections.IEnumerable]) {
    return @($Value | ForEach-Object { ConvertTo-BuildSortedJsonValue $_ })
  }

  $object = [ordered]@{}
  foreach ($property in @($Value.PSObject.Properties | Sort-Object Name)) {
    $object[[string]$property.Name] = ConvertTo-BuildSortedJsonValue $property.Value
  }
  return $object
}

function Get-BuildNormalizedJsonHash {
  param($Value)

  $normalized = ConvertTo-BuildSortedJsonValue $Value
  $json = $normalized | ConvertTo-Json -Depth 64 -Compress
  return Get-BuildTextHash $json
}

function Get-BuildDependencyHash {
  param(
    [string]$Root,
    [string[]]$Dependencies,
    $Extra = $null
  )

  $items = @()
  foreach ($dependency in @($Dependencies | Sort-Object -Unique)) {
    $relative = Normalize-BuildRelativePath $dependency
    $path = Get-BuildAbsolutePath $Root $relative
    $items += [ordered]@{
      path = $relative
      exists = Test-BuildInputExists $path
      hash = Get-BuildFileHashValue $path
    }
  }

  return Get-BuildNormalizedJsonHash ([ordered]@{
    dependencies = $items
    extra = $Extra
  })
}

function Get-BuildOutputStateEntry {
  param(
    $State,
    [string]$RelativePath
  )

  $relative = Normalize-BuildRelativePath $RelativePath
  $outputs = Get-BuildPropertyValue $State "outputs" ([ordered]@{})
  if ($outputs -is [System.Collections.IDictionary] -and $outputs.Contains($relative)) {
    return $outputs[$relative]
  }
  $property = $outputs.PSObject.Properties[$relative]
  if ($null -ne $property) { return $property.Value }
  return $null
}

function Test-BuildOutputOwnership {
  param(
    [string]$Root,
    $State,
    [string]$RelativePath
  )

  $relative = Normalize-BuildRelativePath $RelativePath
  $path = Get-BuildAbsolutePath $Root $relative
  $exists = Test-Path -LiteralPath $path -PathType Leaf
  $currentHash = Get-BuildFileHashValue $path
  $entry = Get-BuildOutputStateEntry $State $relative
  if (-not $exists) {
    return [ordered]@{
      status = "missing"
      currentHash = $null
      knownHash = Get-BuildPropertyValue $entry "outputHash" $null
      entry = $entry
    }
  }
  if ($null -eq $entry) {
    return [ordered]@{
      status = "unknown"
      currentHash = $currentHash
      knownHash = $null
      entry = $null
    }
  }

  $knownHash = [string](Get-BuildPropertyValue $entry "outputHash" "")
  if ($knownHash -ne "" -and $knownHash -eq $currentHash) {
    return [ordered]@{
      status = "owned"
      currentHash = $currentHash
      knownHash = $knownHash
      entry = $entry
    }
  }

  return [ordered]@{
    status = "conflict"
    currentHash = $currentHash
    knownHash = $knownHash
    entry = $entry
  }
}

function Add-BuildConflict {
  param(
    $State,
    [string]$RunId,
    [string]$RelativePath,
    [string]$EntityType,
    [string]$EntityId,
    [string]$CurrentHash,
    [string]$KnownHash,
    [string]$Reason
  )

  $State.conflicts = @([ordered]@{
    runId = $RunId
    outputPath = Normalize-BuildRelativePath $RelativePath
    entityType = $EntityType
    entityId = $EntityId
    currentHash = $CurrentHash
    knownHash = $KnownHash
    reason = $Reason
    detectedAt = (Get-Date).ToString("s")
  }) + @($State.conflicts)
  $State.updatedAt = (Get-Date).ToString("s")
}

function Set-BuildOutputStateEntry {
  param(
    $State,
    [string]$RelativePath,
    [string]$EntityType,
    [string]$EntityId,
    [string]$SourceHash,
    [string]$OutputHash,
    [string]$Generator,
    [string[]]$Dependencies,
    [string]$BackupPath,
    [string]$LastStatus,
    [string]$LastError
  )

  $relative = Normalize-BuildRelativePath $RelativePath
  $State.outputs[$relative] = [ordered]@{
    outputPath = $relative
    entityType = $EntityType
    entityId = $EntityId
    sourceHash = $SourceHash
    outputHash = $OutputHash
    generatedAt = (Get-Date).ToString("s")
    generator = $Generator
    dependencies = @($Dependencies)
    backupPath = $BackupPath
    lastStatus = $LastStatus
    lastError = $LastError
  }
  $State.updatedAt = (Get-Date).ToString("s")
}

function Test-BuildBaselineAutoRegisterableOutput {
  param([string]$RelativePath)

  $relative = Normalize-BuildRelativePath $RelativePath
  if ($relative -eq "index.html") { return $true }
  if ($relative -eq "cars/index.html") { return $true }
  if ($relative -match '^cars/[^/]+\.html$') { return $true }
  return $false
}

function Test-BuildBaselineProtectedOutput {
  param([string]$RelativePath)

  $relative = Normalize-BuildRelativePath $RelativePath
  if ($relative -eq "robots.txt") { return $true }
  if ($relative -eq "sitemap.xml") { return $true }
  if ($relative -match '^data/[^/]+\.json$') { return $true }
  return $false
}

function Get-BuildBaselineCategory {
  param($ManifestItem)

  $relative = Normalize-BuildRelativePath ([string](Get-BuildPropertyValue $ManifestItem "outputPath" ""))
  $status = [string](Get-BuildPropertyValue $ManifestItem "status" "")
  $currentHash = [string](Get-BuildPropertyValue $ManifestItem "currentHash" "")
  $plannedHash = [string](Get-BuildPropertyValue $ManifestItem "plannedHash" "")
  $autoRegisterable = Test-BuildBaselineAutoRegisterableOutput $relative

  if ($status -match '^would-delete' -or $status -match '^delete') {
    return "stale-output"
  }
  if (Test-BuildBaselineProtectedOutput $relative) {
    return "protected-output"
  }
  if ($status -eq "create" -or $status -eq "target-create") {
    return "missing-output"
  }
  if ($status -eq "conflict" -or $status -match 'conflict') {
    return "manual-review-required"
  }
  if ($status -eq "unknown-ownership") {
    if ($autoRegisterable -and $currentHash -ne "" -and $plannedHash -ne "" -and $currentHash -eq $plannedHash) {
      return "can-register"
    }
    if ($autoRegisterable -and $currentHash -ne "" -and $plannedHash -ne "" -and $currentHash -ne $plannedHash) {
      return "content-diff"
    }
    if ($autoRegisterable) {
      return "unknown-ownership"
    }
    return "manual-review-required"
  }
  if ($status -eq "change") {
    return "content-diff"
  }
  if ($status -eq "unchanged") {
    if ($autoRegisterable) { return "can-register" }
    return "manual-review-required"
  }
  if ($status -match '^target-') {
    return "manual-review-required"
  }

  return "manual-review-required"
}

function Get-BuildBaselineReason {
  param(
    $ManifestItem,
    [string]$Category
  )

  $relative = Normalize-BuildRelativePath ([string](Get-BuildPropertyValue $ManifestItem "outputPath" ""))
  $status = [string](Get-BuildPropertyValue $ManifestItem "status" "")

  switch ($Category) {
    "can-register" { return "current file hash matches the planned generated output and path is inside the baseline registration scope" }
    "content-diff" { return "current file hash differs from the planned generated output" }
    "missing-output" { return "planned generated output is missing on disk" }
    "stale-output" { return "existing generated output is not part of the current plan or would be removed" }
    "protected-output" { return "protected output is excluded from baseline registration: $relative" }
    "unknown-ownership" { return "ownership is unknown and the audit cannot prove the current file matches planned output" }
    "manual-review-required" {
      if (-not (Test-BuildBaselineAutoRegisterableOutput $relative)) {
        return "path is outside the minimal baseline registration scope"
      }
      return "status requires manual review before registration: $status"
    }
    default { return "manual review required" }
  }
}

function New-BuildBaselineAuditItem {
  param($ManifestItem)

  $category = Get-BuildBaselineCategory $ManifestItem
  return [ordered]@{
    outputPath = Normalize-BuildRelativePath ([string](Get-BuildPropertyValue $ManifestItem "outputPath" ""))
    entityType = [string](Get-BuildPropertyValue $ManifestItem "entityType" "")
    entityId = [string](Get-BuildPropertyValue $ManifestItem "entityId" "")
    status = [string](Get-BuildPropertyValue $ManifestItem "status" "")
    category = $category
    reason = Get-BuildBaselineReason $ManifestItem $category
    sourceHash = [string](Get-BuildPropertyValue $ManifestItem "sourceHash" "")
    currentHash = [string](Get-BuildPropertyValue $ManifestItem "currentHash" "")
    knownHash = [string](Get-BuildPropertyValue $ManifestItem "knownHash" "")
    plannedHash = [string](Get-BuildPropertyValue $ManifestItem "plannedHash" "")
    dependencies = @(Get-BuildPropertyValue $ManifestItem "dependencies" @())
  }
}

function Register-BuildBaselineOutput {
  param(
    $State,
    $ManifestItem,
    [string]$RunId,
    [string]$Generator,
    [string]$RegistrationMode = "RegisterBaseline"
  )

  $auditItem = New-BuildBaselineAuditItem $ManifestItem
  if ($auditItem.category -ne "can-register") {
    return $false
  }

  $outputHash = [string]$auditItem.currentHash
  if ($outputHash -eq "") {
    $outputHash = [string]$auditItem.plannedHash
  }
  if ($outputHash -eq "") {
    return $false
  }

  Set-BuildOutputStateEntry $State $auditItem.outputPath $auditItem.entityType $auditItem.entityId $auditItem.sourceHash $outputHash $Generator ([string[]]$auditItem.dependencies) "" "registered-baseline" ""
  $entry = Get-BuildOutputStateEntry $State $auditItem.outputPath
  if ($entry -is [System.Collections.IDictionary]) {
    $entry["registeredAt"] = (Get-Date).ToString("s")
    $entry["registrationMode"] = $RegistrationMode
    $entry["runId"] = $RunId
  }

  return $true
}

function New-BuildOutputBackupPath {
  param(
    [string]$Root,
    [string]$PrivateDataDir,
    [string]$RunId,
    [string]$RelativePath
  )

  $relative = Normalize-BuildRelativePath $RelativePath
  $backupRoot = [System.IO.Path]::GetFullPath((Join-Path $PrivateDataDir ("backups/generated-output-backups/" + $RunId)))
  $candidate = [System.IO.Path]::GetFullPath((Join-Path $backupRoot $relative))
  $backupRootWithSeparator = $backupRoot.TrimEnd("\", "/") + [System.IO.Path]::DirectorySeparatorChar
  if (-not ($candidate + [System.IO.Path]::DirectorySeparatorChar).StartsWith($backupRootWithSeparator, [System.StringComparison]::OrdinalIgnoreCase) -and
      -not $candidate.StartsWith($backupRootWithSeparator, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Backup path escaped private backup root: $RelativePath"
  }
  return $candidate
}

function Backup-BuildGeneratedOutput {
  param(
    [string]$Root,
    [string]$PrivateDataDir,
    [string]$RunId,
    [string]$RelativePath
  )

  if ($script:BuildAtomic) {
    $known = $script:BuildTransactionSnapshot.outputs.PSObject.Properties[$RelativePath]
    if ($null -eq $known -or $null -eq $known.Value) { return "" }
    return "@data/backups/generated-output-backups/" + $RunId + "/" + $RelativePath
  }
  $sourcePath = Get-BuildAbsolutePath $Root $RelativePath
  if (-not (Test-Path -LiteralPath $sourcePath)) { return "" }

  $backupPath = New-BuildOutputBackupPath $Root $PrivateDataDir $RunId $RelativePath
  $backupDirectory = Split-Path -Parent $backupPath
  if (-not (Test-Path -LiteralPath $backupDirectory)) {
    New-Item -ItemType Directory -Force -Path $backupDirectory | Out-Null
  }
  Copy-Item -LiteralPath $sourcePath -Destination $backupPath -Force
  return Get-BuildRelativePathFromFullPath $Root $backupPath
}

function Get-BuildDirtyItems {
  param($State)

  return ConvertTo-BuildObjectArray (Get-BuildPropertyValue $State "dirty" @())
}

function Find-BuildDirtyItem {
  param(
    $State,
    [string]$EntityType,
    [string]$EntityId
  )

  foreach ($item in Get-BuildDirtyItems $State) {
    if ([string](Get-BuildPropertyValue $item "entityType" "") -eq $EntityType -and
        [string](Get-BuildPropertyValue $item "entityId" "") -eq $EntityId) {
      return $item
    }
  }
  return $null
}
