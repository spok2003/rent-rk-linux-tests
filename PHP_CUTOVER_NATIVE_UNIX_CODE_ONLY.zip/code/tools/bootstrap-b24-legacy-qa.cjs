'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process'),a=require('./business-data-audit.cjs');
const root=path.resolve(__dirname,'..'),php=process.env.RENT_RK_QA_PHP||'D:/OSPanel/modules/PHP-8.4/php.exe';
const dir=fs.realpathSync(path.resolve(root,'../..')),baseline=JSON.parse(fs.readFileSync(path.join(dir,'baseline.json')));
if(fs.realpathSync(process.env.RENT_RK_AUDIT_LAB_ROOT||'.')!==fs.realpathSync(root)||!fs.existsSync(path.join(root,'.rent-rk-test-lab'))||path.dirname(dir)!==fs.realpathSync(path.join(process.env.LOCALAPPDATA,'Temp'))||!/^rent-rk-audit-\d+-b24-legacy-[a-f0-9]{8}$/.test(path.basename(dir))||baseline.sourceSha256!==a.qaSourceIdentity().sourceHashesSha256)throw Error('Frozen standard temporary lab required');
const run=process.env.RENT_RK_QA_RUN_BINDING;if(!/^[a-f0-9]{32}$/.test(run||''))throw Error('Run binding required');
const out=path.join(root,'tmp/bootstrap-b24-legacy',run);fs.mkdirSync(out,{recursive:true});
const results=[],native=[];
for(const disabled of [false,true]){
 const r=cp.spawnSync(php,[...(disabled?['-d','disable_functions=exec,shell_exec,system,passthru,proc_open,popen']:[]),'tools/bootstrap-b24-legacy-qa.php'],{cwd:root,env:process.env,encoding:'utf8',windowsHide:true,timeout:60000,maxBuffer:8*1024**2});
 if(r.status!==0)throw Error(r.stderr||'Native worker failed');const value=JSON.parse(r.stdout);native.push({disabledTransport:disabled,...value});
 for(const c of value.checks)results.push({...c,test:(disabled?'exec-disabled:':'normal:')+c.test});
 results.push({test:(disabled?'disabled':'normal')+':effective-runtime',passed:value.environment.opcache==='0'&&value.environment.cli==='0'&&!value.environment.fileCache&&value.environment.execAvailable===!disabled});
}
const report=path.join(out,'batch-primary.json'),passed=results.filter(x=>x.passed).length;
fs.writeFileSync(report,JSON.stringify({runId:run,status:passed===results.length?'PASS':'FAIL',checks:results.length,passed,failed:results.length-passed,results,native,scope:'Native safe refusal of historical helper exec sites, plus structural unconditional return for dead page-content exec. Not successful publication or Unix execution.'},null,2));
console.log(JSON.stringify({report:path.relative(root,report).replaceAll('\\','/')}));
if(passed!==results.length)process.exitCode=1;
