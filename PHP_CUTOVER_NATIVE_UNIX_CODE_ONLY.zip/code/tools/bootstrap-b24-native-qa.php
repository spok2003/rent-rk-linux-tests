<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || !RENT_RK_AUDIT_ISOLATION_VERIFIED) { throw new RuntimeException('Verified CLI laboratory required.'); }
$root = realpath((string) getenv('RENT_RK_AUDIT_LAB_ROOT'));
if (!$root || realpath(__DIR__ . '/..') !== $root || !is_file($root . '/.rent-rk-test-lab')) { throw new RuntimeException('Laboratory location mismatch.'); }
$action = $argv[1] ?? '';
if (!in_array($action, ['full', 'car'], true)) { throw new RuntimeException('Fixed build action required.'); }
define('AUTO_REBUILD_SITE_AFTER_ADMIN_CHANGES', true);
require $root . '/admin/includes/bootstrap.php';
$result = null; $error = null;
try { $result = rebuild_public_site_result($action === 'car' ? 'qa-b24-car' : ''); }
catch (Throwable $e) { $error = ['class' => get_class($e), 'message' => $e->getMessage()]; }
echo json_encode(['action' => $action, 'result' => $result, 'error' => $error,
    'environment' => ['php' => PHP_BINARY, 'version' => PHP_VERSION, 'sapi' => PHP_SAPI,
        'opcache' => ini_get('opcache.enable'), 'opcacheCli' => ini_get('opcache.enable_cli'), 'fileCache' => ini_get('opcache.file_cache'),
        'allowUrlFopen' => ini_get('allow_url_fopen'), 'execNative' => function_exists('exec') && (new ReflectionFunction('exec'))->isInternal(),
        'dataRoot' => realpath(DATA_DIR), 'bootstrapSha256' => hash_file('sha256', $root . '/admin/includes/bootstrap.php')]], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
