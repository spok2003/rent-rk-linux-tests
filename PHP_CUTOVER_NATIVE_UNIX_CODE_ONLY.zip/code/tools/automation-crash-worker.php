<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || !RENT_RK_AUDIT_ISOLATION_VERIFIED
    || !defined('RENT_RK_PHP_PUBLICATION_AUTOMATION') || RENT_RK_PHP_PUBLICATION_AUTOMATION !== true) exit(2);
$point = $argv[1] ?? '';
if (!in_array($point, ['write.after_rename.sitemap.xml','journal.committed'], true)) exit(2);
$GLOBALS['rental_return_test_hook'] = static function (string $step) use ($point): void {
    if ($step === $point) exit(73);
};
require __DIR__ . '/../tools/php-publication-automation-once.php';
