<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../admin/includes/bootstrap.php';

$allowedStatuses = [
    'production_ready',
    'production_deployed_needs_observation',
    'local_ready_not_deployed',
    'in_progress',
    'half_done_blocked',
    'planned_not_started',
    'deprecated_or_superseded',
    'unknown_needs_investigation',
];
$summaryKeys = [
    'production_ready' => 'productionReady',
    'production_deployed_needs_observation' => 'productionDeployedNeedsObservation',
    'local_ready_not_deployed' => 'localReadyNotDeployed',
    'in_progress' => 'inProgress',
    'half_done_blocked' => 'halfDoneBlocked',
    'planned_not_started' => 'plannedNotStarted',
    'deprecated_or_superseded' => 'deprecatedOrSuperseded',
    'unknown_needs_investigation' => 'unknownNeedsInvestigation',
];
$allowedPriorities = ['P0', 'P1', 'P2', 'P3'];
$allowedAreas = [
    'security',
    'reliability',
    'production',
    'UX',
    'business',
    'SEO',
    'content',
    'architecture',
    'technical_debt',
    'feature',
    'docs',
    'ops',
    'marketing',
    'roles',
    'integrations',
];
$allowedRisks = ['low', 'medium', 'high'];
$errors = [];
$warnings = [];
$fixSummary = false;
$file = PROJECT_PROGRESS_MAP_FILE;
$requiredDocs = [
    'docs/PROJECT_STATE.md' => true,
    'docs/OPERATION_METHODS_LOG.md' => true,
];

foreach (array_slice($argv, 1) as $arg) {
    if ($arg === '--fix-summary') {
        $fixSummary = true;
        continue;
    }
    if (str_starts_with($arg, '--file=')) {
        $file = substr($arg, strlen('--file='));
        continue;
    }
    $errors[] = 'Unknown argument: ' . $arg;
}

function progress_fail(array &$errors, string $message): void
{
    $errors[] = $message;
}

function progress_warn(array &$warnings, string $message): void
{
    $warnings[] = $message;
}

function progress_stringify(mixed $value): string
{
    if (is_scalar($value) || $value === null) {
        return (string) $value;
    }

    return (string) json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function progress_walk_values(mixed $value, callable $visit, string $path = '$'): void
{
    if (is_array($value)) {
        foreach ($value as $key => $child) {
            progress_walk_values($child, $visit, $path . '.' . (string) $key);
        }
        return;
    }

    $visit($path, progress_stringify($value));
}

function progress_expected_summary(array $modules, array $summaryKeys): array
{
    $summary = array_fill_keys(array_values($summaryKeys), 0);
    $summary += ['p0' => 0, 'p1' => 0, 'p2' => 0, 'p3' => 0];

    foreach ($modules as $module) {
        if (!is_array($module)) {
            continue;
        }
        $status = (string) ($module['status'] ?? '');
        $priority = strtolower((string) ($module['priority'] ?? ''));
        $statusKey = $summaryKeys[$status] ?? null;
        if ($statusKey !== null) {
            $summary[$statusKey]++;
        }
        if (isset($summary[$priority])) {
            $summary[$priority]++;
        }
    }

    return $summary;
}

foreach ($requiredDocs as $relativePath => $mustBeNonEmpty) {
    $docFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativePath);
    if (!is_file($docFile)) {
        progress_fail($errors, 'Required project document not found: ' . $relativePath);
        continue;
    }
    if ($mustBeNonEmpty && trim((string) file_get_contents($docFile)) === '') {
        progress_fail($errors, 'Required project document is empty: ' . $relativePath);
    }
}

if (!is_file($file)) {
    progress_fail($errors, 'Map file not found: ' . $file);
    $data = [];
} else {
    $raw = (string) file_get_contents($file);
    $decoded = json_decode($raw, true);
    if (!is_array($decoded) || json_last_error() !== JSON_ERROR_NONE) {
        progress_fail($errors, 'Invalid JSON: ' . json_last_error_msg());
        $data = [];
    } else {
        $data = $decoded;
    }
}

if ($data) {
    foreach (['schemaVersion', 'updatedAt', 'updatedBy', 'projectStateRevision', 'sourceReport', 'summary', 'modules'] as $field) {
        if (!array_key_exists($field, $data)) {
            progress_fail($errors, 'Missing top-level field: ' . $field);
        }
    }

    if ((int) ($data['schemaVersion'] ?? 0) !== 1) {
        progress_fail($errors, 'schemaVersion must be 1.');
    }

    $updatedAt = (string) ($data['updatedAt'] ?? '');
    if ($updatedAt === '') {
        progress_fail($errors, 'updatedAt is empty.');
    } else {
        try {
            new DateTimeImmutable($updatedAt);
        } catch (Throwable) {
            progress_fail($errors, 'updatedAt is not a valid date-time.');
        }
    }

    if (trim((string) ($data['updatedBy'] ?? '')) === '') {
        progress_fail($errors, 'updatedBy is empty.');
    }
    if (trim((string) ($data['projectStateRevision'] ?? '')) === '') {
        progress_fail($errors, 'projectStateRevision is empty.');
    }
    if ((string) ($data['sourceReport'] ?? '') !== 'docs/PROJECT_AUDIT_AND_PRIORITY_PLAN_20260704.md') {
        progress_warn($warnings, 'sourceReport does not point to the 2026-07-04 audit report.');
    }

    $modules = isset($data['modules']) && is_array($data['modules']) ? $data['modules'] : [];
    if (!$modules) {
        progress_fail($errors, 'modules must be a non-empty array.');
    }

    $ids = [];
    foreach ($modules as $index => $module) {
        if (!is_array($module)) {
            progress_fail($errors, 'Module #' . $index . ' is not an object.');
            continue;
        }
        $id = trim((string) ($module['id'] ?? ''));
        $prefix = $id !== '' ? 'Module ' . $id : 'Module #' . $index;
        if ($id === '') {
            progress_fail($errors, $prefix . ': id is empty.');
        } elseif (isset($ids[$id])) {
            progress_fail($errors, $prefix . ': duplicate id.');
        }
        $ids[$id] = true;

        foreach (['title', 'area', 'status', 'priority', 'progress', 'productionDeploy', 'productionSmoke', 'risk', 'owner', 'lastEvidence', 'nextAction', 'blocker'] as $field) {
            if (!array_key_exists($field, $module)) {
                progress_fail($errors, $prefix . ': missing field ' . $field . '.');
            }
        }

        $status = (string) ($module['status'] ?? '');
        $priority = (string) ($module['priority'] ?? '');
        $area = (string) ($module['area'] ?? '');
        $risk = (string) ($module['risk'] ?? '');
        $progress = $module['progress'] ?? null;
        $nextAction = trim((string) ($module['nextAction'] ?? ''));
        $blocker = trim((string) ($module['blocker'] ?? ''));

        if (!in_array($status, $allowedStatuses, true)) {
            progress_fail($errors, $prefix . ': unsupported status ' . $status . '.');
        }
        if (!in_array($priority, $allowedPriorities, true)) {
            progress_fail($errors, $prefix . ': unsupported priority ' . $priority . '.');
        }
        if (!in_array($area, $allowedAreas, true)) {
            progress_fail($errors, $prefix . ': unsupported area ' . $area . '.');
        }
        if (!in_array($risk, $allowedRisks, true)) {
            progress_fail($errors, $prefix . ': unsupported risk ' . $risk . '.');
        }
        if (!is_int($progress) || $progress < 0 || $progress > 100) {
            progress_fail($errors, $prefix . ': progress must be an integer from 0 to 100.');
        }
        if (in_array($priority, ['P0', 'P1'], true) && $nextAction === '') {
            progress_fail($errors, $prefix . ': P0/P1 module must have nextAction.');
        }
        if ($status === 'half_done_blocked' && $blocker === '' && $risk !== 'high') {
            progress_fail($errors, $prefix . ': blocked module must have blocker text or high risk.');
        }
        foreach (['productionDeploy', 'productionSmoke'] as $boolField) {
            if (!is_bool($module[$boolField] ?? null)) {
                progress_fail($errors, $prefix . ': ' . $boolField . ' must be boolean.');
            }
        }
    }

    $expectedSummary = progress_expected_summary($modules, $summaryKeys);
    $summary = isset($data['summary']) && is_array($data['summary']) ? $data['summary'] : [];
    foreach ($expectedSummary as $key => $count) {
        if ((int) ($summary[$key] ?? -1) !== $count) {
            if ($fixSummary) {
                $data['summary'][$key] = $count;
            } else {
                progress_fail($errors, 'summary.' . $key . ' mismatch: expected ' . $count . ', got ' . (string) ($summary[$key] ?? 'missing') . '.');
            }
        }
    }

    foreach ((array) ($data['nextSteps'] ?? []) as $index => $step) {
        if (!is_array($step)) {
            progress_fail($errors, 'nextSteps #' . $index . ' is not an object.');
            continue;
        }
        $priority = (string) ($step['priority'] ?? '');
        if (!in_array($priority, $allowedPriorities, true)) {
            progress_fail($errors, 'nextSteps #' . $index . ': unsupported priority.');
        }
        if (in_array($priority, ['P0', 'P1'], true) && trim((string) ($step['nextAction'] ?? '')) === '') {
            progress_fail($errors, 'nextSteps #' . $index . ': P0/P1 nextAction is empty.');
        }
    }

    foreach ((array) ($data['risks'] ?? []) as $index => $risk) {
        if (!is_array($risk)) {
            progress_fail($errors, 'risks #' . $index . ' is not an object.');
            continue;
        }
        if (!in_array((string) ($risk['level'] ?? ''), $allowedRisks, true)) {
            progress_fail($errors, 'risks #' . $index . ': unsupported level.');
        }
        if (!in_array((string) ($risk['priority'] ?? ''), $allowedPriorities, true)) {
            progress_fail($errors, 'risks #' . $index . ': unsupported priority.');
        }
    }

    $suspiciousPatterns = [
        '/\bpassword\b/i',
        '/\bpasswd\b/i',
        '/\.ftp\.env/i',
        '/ftp[\s_-]?password/i',
        '/ftp[\s_-]?pass/i',
        '/\bsession\b/i',
        '/\bcookie\b/i',
        '/\bcsrf\b/i',
        '/\bbearer\b/i',
        '/private\s+key/i',
        '/\bsecret\b/i',
        '/api\s*key/i',
        '/\btoken\b/i',
        '/\+\d[\d\s().-]{8,}\d/',
        '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i',
        '/\bpassport\b/i',
        '/\bcard\s*number\b/i',
    ];
    progress_walk_values($data, static function (string $path, string $value) use (&$errors, $suspiciousPatterns): void {
        foreach ($suspiciousPatterns as $pattern) {
            if (preg_match($pattern, $value)) {
                progress_fail($errors, 'Suspicious string at ' . $path . '.');
                return;
            }
        }
        if (preg_match('~https?://[^\s"\']+/(docs|tools)/~i', $value)) {
            progress_fail($errors, 'Direct public URL to closed docs/tools at ' . $path . '.');
        }
    });

    if ($fixSummary && !$errors) {
        write_json_file($file, $data);
        echo "Summary fixed.\n";
    }
}

foreach ($warnings as $warning) {
    fwrite(STDERR, "[warning] " . $warning . "\n");
}
foreach ($errors as $error) {
    fwrite(STDERR, "[error] " . $error . "\n");
}

if ($errors) {
    exit(1);
}

echo "OK: project progress map is valid.\n";
