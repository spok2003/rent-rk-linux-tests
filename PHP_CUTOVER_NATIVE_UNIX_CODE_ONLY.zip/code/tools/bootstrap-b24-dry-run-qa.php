<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || !RENT_RK_AUDIT_ISOLATION_VERIFIED) { throw new RuntimeException('Verified laboratory CLI required'); }
$root = realpath((string) getenv('RENT_RK_AUDIT_LAB_ROOT'));
if (!$root || realpath(__DIR__ . '/..') !== $root || !is_file($root . '/.rent-rk-test-lab')) { throw new RuntimeException('Laboratory location mismatch'); }
define('AUTO_REBUILD_SITE_AFTER_ADMIN_CHANGES', true);
define('ADMIN_USER', 'qa-dry-root');
require $root . '/admin/includes/bootstrap.php';
$_SESSION['admin_user'] = 'qa-dry-root';
$mode = $argv[1] ?? 'dry'; $kind = $argv[2] ?? 'peer'; $start = microtime(true);
$result = null; $error = null; $accessCalls = 0;
try {
    if ($mode === 'writer') {
        RentalReturnStore::transaction(static function () use ($kind): void {
            $file = match ($kind) { 'rates' => RATES_FILE, 'rights' => ADMIN_USERS_FILE, 'scope' => CARS_FILE, default => DATA_DIR . 'qa-dry-peer.json' };
            $x = RentalReturnStore::read($file, []);
            if ($kind === 'rates') { $x['changedDuringWait'] = true; }
            elseif ($kind === 'rights') { $x['users'][0]['deniedPermissions'] = ['cars.edit', 'cars.publish', 'content.publish.single_page']; }
            elseif ($kind === 'scope') { $x[0]['owner_scope_id'] = 'foreign'; }
            else { $x['preserved'] = true; }
            RentalReturnStore::stage($file, $x);
        });
        $result = ['committed' => true];
    } elseif ($mode === 'lease') {
        $lease = fopen(PROJECT_ROOT . 'private/rent-rk-data/.site-build.lock', 'c+b');
        if (!$lease || !flock($lease, LOCK_EX | LOCK_NB)) { throw new RuntimeException('QA lease failed'); }
        file_put_contents(PROJECT_ROOT . 'tmp/b24-dry/lease-ready', 'ready');
        $deadline = microtime(true) + 15;
        while (!is_file(PROJECT_ROOT . 'tmp/b24-dry/lease-release') && microtime(true) < $deadline) { usleep(20000); }
        fclose($lease); $result = ['released' => true];
    } elseif ($mode === 'full') {
        $result = rebuild_public_site_result();
    } else {
        RentalReturnStore::read(SETTINGS_FILE, []);
        $check = static function () use (&$accessCalls, $mode): bool {
            $accessCalls++;
            if (!has_permission('cars.edit') || (!has_permission('cars.publish') && !has_permission('content.publish.single_page'))) { return false; }
            return $mode !== 'denied';
        };
        if ($mode === 'transaction') {
            $result = RentalReturnStore::transaction(static fn() => run_car_publish_dry_run('qa-b24-car', $check));
        } else {
            $result = run_car_publish_dry_run($kind === 'missing' ? 'qa-missing' : 'qa-b24-car', $check);
        }
    }
} catch (Throwable $e) { $error = ['class' => get_class($e), 'code' => $e->getCode(), 'message' => $e->getMessage()]; }
echo json_encode(['mode' => $mode, 'kind' => $kind, 'result' => $result, 'error' => $error, 'accessCalls' => $accessCalls, 'elapsedMs' => (microtime(true)-$start)*1000,
    'environment' => ['php' => PHP_BINARY, 'version' => PHP_VERSION, 'sapi' => PHP_SAPI, 'opcache' => ini_get('opcache.enable'), 'cli' => ini_get('opcache.enable_cli'), 'fileCache' => ini_get('opcache.file_cache'), 'dataRoot' => DATA_DIR, 'nativeExec' => (new ReflectionFunction('exec'))->isInternal(), 'bootstrapSha256' => hash_file('sha256', $root . '/admin/includes/bootstrap.php')]], JSON_THROW_ON_ERROR);
