param(
    [ValidateSet("Full", "Cars", "Rates", "Availability")]
    [string]$Mode = "Full",
    [string]$Slug = "",
    [switch]$DryRun,
    [switch]$NoWrite,
    [switch]$ManifestOnly,
    [switch]$Preflight
)

$ErrorActionPreference = "Stop"

$root = Resolve-Path (Join-Path $PSScriptRoot "..")
$privateDir = Join-Path $root "private/rent-rk-data"
$publicDir = Join-Path $root "data"
$buildStateHelpers = Join-Path $PSScriptRoot "build-state.ps1"
if (Test-Path -LiteralPath $buildStateHelpers) {
    . $buildStateHelpers
}
$script:PublicDataManifest = @()
$script:PublicDataWriteEnabled = -not ($DryRun -or $NoWrite -or $ManifestOnly -or $Preflight)
$script:PublicDataPreflightSlug = ([string]$Slug).Trim()

function Assert-PublicDataEnvironment {
    $bootstrap = Join-Path $root "admin/includes/bootstrap.php"
    if (-not (Test-Path -LiteralPath $bootstrap)) {
        throw "Refusing public data generation outside the Rent RK project root."
    }

    $privateFull = [System.IO.Path]::GetFullPath($privateDir).TrimEnd("\", "/") + [System.IO.Path]::DirectorySeparatorChar
    $publicFull = [System.IO.Path]::GetFullPath($publicDir).TrimEnd("\", "/") + [System.IO.Path]::DirectorySeparatorChar
    if ($privateFull -eq $publicFull) {
        throw "Private and public data directories must be different."
    }
}

function Assert-JsonFile {
    param(
        [string]$Path,
        [string]$Label
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "Required source is missing: $Label ($Path)"
    }
}

function Read-JsonFile {
    param(
        [string]$Path,
        $Default = $null
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        return $Default
    }

    $raw = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    if ([string]::IsNullOrWhiteSpace($raw)) {
        return $Default
    }

    return $raw | ConvertFrom-Json
}

function Write-JsonFile {
    param(
        [string]$Path,
        [object]$Value
    )

    $json = $Value | ConvertTo-Json -Depth 32
    $content = $json + [Environment]::NewLine
    $currentHash = if (Get-Command Get-BuildFileHashValue -ErrorAction SilentlyContinue) { Get-BuildFileHashValue $Path } else { if (Test-Path -LiteralPath $Path) { "sha256:" + ((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()) } else { $null } }
    $plannedHash = if (Get-Command Get-BuildTextHash -ErrorAction SilentlyContinue) { Get-BuildTextHash $content } else { "sha256:" + ([System.BitConverter]::ToString(([System.Security.Cryptography.SHA256]::Create()).ComputeHash([System.Text.Encoding]::UTF8.GetBytes($content))).Replace("-", "").ToLowerInvariant()) }
    $status = if ($null -eq $currentHash) { "create" } elseif ($currentHash -eq $plannedHash) { "unchanged" } else { "change" }
    $relativePath = if (Get-Command Get-BuildRelativePathFromFullPath -ErrorAction SilentlyContinue) {
        Get-BuildRelativePathFromFullPath $root $Path
    } else {
        $Path
    }

    $script:PublicDataManifest += [ordered]@{
        outputPath = $relativePath
        mode = $Mode
        status = $status
        currentHash = $currentHash
        plannedHash = $plannedHash
        writeEnabled = [bool]$script:PublicDataWriteEnabled
    }

    $publicFull = [System.IO.Path]::GetFullPath($publicDir).TrimEnd("\", "/") + [System.IO.Path]::DirectorySeparatorChar
    $targetFull = [System.IO.Path]::GetFullPath($Path)
    if (-not $targetFull.StartsWith($publicFull, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to write public data outside data/: $Path"
    }

    if (-not $script:PublicDataWriteEnabled) {
        return
    }

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $content, $utf8NoBom)
}

function Test-PublicDataTargetEnabled {
    param([string]$Target)

    return $Mode -eq "Full" -or $Mode -eq $Target
}

if ($Preflight) {
    if (-not (Test-PublicDataTargetEnabled "Cars")) {
        throw "-Preflight requires -Mode Full or -Mode Cars because it compares data/current-cars.json."
    }
    if ([string]::IsNullOrWhiteSpace($script:PublicDataPreflightSlug)) {
        throw "-Preflight requires -Slug <car-slug>."
    }
}

function ConvertTo-ObjectArray {
    param($Value)

    if ($null -eq $Value) {
        return @()
    }

    return @($Value | ForEach-Object { $_ })
}

function ConvertTo-PublicDataPropertyMap {
    param($Object)

    $map = [ordered]@{}
    if ($null -eq $Object) {
        return $map
    }
    if ($Object -is [System.Collections.IDictionary]) {
        foreach ($key in @($Object.Keys | Sort-Object)) {
            $map[[string]$key] = $Object[$key]
        }
        return $map
    }

    foreach ($property in @($Object.PSObject.Properties | Sort-Object Name)) {
        $map[[string]$property.Name] = $property.Value
    }
    return $map
}

function Get-PublicDataValueHash {
    param($Value)

    if (Get-Command Get-BuildNormalizedJsonHash -ErrorAction SilentlyContinue) {
        return Get-BuildNormalizedJsonHash $Value
    }

    $json = $Value | ConvertTo-Json -Depth 32 -Compress
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes([string]$json)
        return "sha256:" + ([System.BitConverter]::ToString($sha.ComputeHash($bytes)).Replace("-", "").ToLowerInvariant())
    } finally {
        $sha.Dispose()
    }
}

function Find-PublicCarBySlug {
    param(
        $Cars,
        [string]$CarSlug
    )

    foreach ($car in ConvertTo-ObjectArray $Cars) {
        if ([string]$car.slug -eq $CarSlug) {
            return $car
        }
    }
    return $null
}

function Write-PublicCarPreflight {
    param(
        [string]$CarSlug,
        $PlannedCars
    )

    $publicPath = Join-Path $publicDir "current-cars.json"
    $existingCars = ConvertTo-ObjectArray (Read-JsonFile $publicPath @())
    $plannedCar = Find-PublicCarBySlug $PlannedCars $CarSlug
    $existingCar = Find-PublicCarBySlug $existingCars $CarSlug

    $plannedMap = ConvertTo-PublicDataPropertyMap $plannedCar
    $existingMap = ConvertTo-PublicDataPropertyMap $existingCar
    $fieldNames = @($plannedMap.Keys + $existingMap.Keys | Sort-Object -Unique)
    $changedFields = @()
    foreach ($field in $fieldNames) {
        $plannedValue = if ($plannedMap.Contains($field)) { $plannedMap[$field] } else { $null }
        $existingValue = if ($existingMap.Contains($field)) { $existingMap[$field] } else { $null }
        if ((Get-PublicDataValueHash $plannedValue) -ne (Get-PublicDataValueHash $existingValue)) {
            $changedFields += [ordered]@{
                field = $field
                currentHash = Get-PublicDataValueHash $existingValue
                plannedHash = Get-PublicDataValueHash $plannedValue
            }
        }
    }

    $recordStatus = "unchanged"
    if ($null -eq $plannedCar -and $null -eq $existingCar) {
        $recordStatus = "missing-private-and-public"
    } elseif ($null -eq $plannedCar) {
        $recordStatus = "would-remove-from-public-data"
    } elseif ($null -eq $existingCar) {
        $recordStatus = "would-add-to-public-data"
    } elseif ($changedFields.Count -gt 0) {
        $recordStatus = "would-change-public-fields"
    }

    Write-Host "Public data preflight"
    Write-Host ("Slug: {0}" -f $CarSlug)
    Write-Host "Output: data/current-cars.json"
    Write-Host ("Record status: {0}" -f $recordStatus)
    Write-Host ("Changed public fields: {0}" -f $changedFields.Count)
    foreach ($change in $changedFields) {
        Write-Host ("- {0} (current={1}; planned={2})" -f $change.field, $change.currentHash, $change.plannedHash)
    }
    Write-Host "Note: future real single-car publish must account for data/current-cars.json as a whole-file public dataset generated from live private current-cars/rates/availability sources."
}

function Normalize-SlugPart {
    param($Value)

    $text = ([string]$Value).Trim().ToLowerInvariant()
    if ($text -eq "") {
        return ""
    }

    $text = $text -replace "[^a-z0-9]+", "-"
    $text = $text.Trim("-")
    return $text
}

function Get-ScopeIdFromLessorSlug {
    param($Slug)

    $part = Normalize-SlugPart $Slug
    if ($part -eq "") {
        return ""
    }

    return "lessor-$part"
}

function Get-CarOwnerScopeId {
    param($Car)

    foreach ($key in @("owner_scope_id", "partner_owner_scope_id", "scopeId")) {
        if ($Car.PSObject.Properties.Name -contains $key -and -not [string]::IsNullOrWhiteSpace([string]$Car.$key)) {
            return ([string]$Car.$key).Trim()
        }
    }

    foreach ($key in @("lessorSlug", "lessor_slug", "ownerSlug")) {
        if ($Car.PSObject.Properties.Name -contains $key -and -not [string]::IsNullOrWhiteSpace([string]$Car.$key)) {
            return Get-ScopeIdFromLessorSlug $Car.$key
        }
    }

    return "rent_rk"
}

function Get-OptionalBool {
    param($Object, [string[]]$Keys)

    foreach ($key in $Keys) {
        if ($Object.PSObject.Properties.Name -contains $key) {
            return [bool]$Object.$key
        }
    }

    return $null
}

function Get-PublishChannels {
    param($Car)

    if ($Car.PSObject.Properties.Name -notcontains "publishChannels" -or $null -eq $Car.publishChannels) {
        return @()
    }
    if ($Car.publishChannels -is [string]) {
        return @(($Car.publishChannels -split ",") | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ -ne "" })
    }
    return @($Car.publishChannels | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ -ne "" })
}

function Test-CarHasPublicationFields {
    param($Car)

    foreach ($key in @("adminStatus", "publicStatus", "isPublished", "publishChannels")) {
        if ($Car.PSObject.Properties.Name -contains $key) {
            return $true
        }
    }
    return $false
}

function Test-CarIsActiveForShowcase {
    param($Car)

    if ($Car.PSObject.Properties.Name -contains "archived" -and [bool]$Car.archived) {
        return $false
    }

    if ($Car.PSObject.Properties.Name -contains "adminStatus" -and -not [string]::IsNullOrWhiteSpace([string]$Car.adminStatus)) {
        return ([string]$Car.adminStatus) -eq "active"
    }

    $flag = Get-OptionalBool $Car @("active", "isActive", "published", "isPublished")
    if ($null -ne $flag) {
        return [bool]$flag
    }

    return $true
}

function Test-OwnerScopeVisibleInShowcase {
    param($ScopeId)

    $scope = ([string]$ScopeId).Trim()
    if ($scope -eq "" -or $scope -eq "rent_rk") {
        return $true
    }

    if ($script:lessorsByScope.ContainsKey($scope)) {
        $lessor = $script:lessorsByScope[$scope]
        $flag = Get-OptionalBool $lessor @("visible_in_rent_rk_showcase", "visibleInRentRkShowcase", "visible_in_rent_rk", "rentRkVisible", "isPublic", "publicVisible")
        if ($null -ne $flag) {
            return [bool]$flag
        }
    }

    return $true
}

function Test-CarVisibleInPublicShowcase {
    param($Car)

    if (-not (Test-CarIsActiveForShowcase $Car)) {
        return $false
    }
    if (Test-CarHasPublicationFields $Car) {
        $publicStatus = if ($Car.PSObject.Properties.Name -contains "publicStatus") { [string]$Car.publicStatus } else { "" }
        $isPublished = if ($Car.PSObject.Properties.Name -contains "isPublished") { [bool]$Car.isPublished } else { $false }
        $channels = Get-PublishChannels $Car
        return $publicStatus -eq "published" -and $isPublished -and ($channels -contains "rent_rk_public")
    }

    return Test-OwnerScopeVisibleInShowcase (Get-CarOwnerScopeId $Car)
}

function Get-FirstNumber {
    param($Object, [string[]]$Keys)

    foreach ($key in $Keys) {
        if ($Object -and $Object.PSObject.Properties.Name -contains $key) {
            $raw = $Object.$key
            if ($null -ne $raw -and [string]$raw -ne "") {
                $value = 0.0
                if ([double]::TryParse(([string]$raw), [Globalization.NumberStyles]::Any, [Globalization.CultureInfo]::InvariantCulture, [ref]$value)) {
                    return $value
                }
            }
        }
    }

    return $null
}

function ConvertTo-PublicPrice {
    param($Car, $Rate)

    $value = Get-FirstNumber $Rate @("manual", "base", "day", "daily")
    if ($null -eq $value) {
        $value = Get-FirstNumber $Car @("price", "basePrice", "dailyRate")
    }

    if ($null -eq $value) {
        return $null
    }

    return [int][Math]::Round($value)
}

function Copy-PublicTextField {
    param($Source, [string]$Key, $Target)

    if ($Source.PSObject.Properties.Name -notcontains $Key -or $null -eq $Source.$Key) {
        return
    }

    $value = ([string]$Source.$Key).Trim()
    if ($value -ne "") {
        $Target[$Key] = $value
    }
}

function Copy-PublicListField {
    param($Source, [string]$Key, $Target, [int]$Limit = 8)

    if ($Source.PSObject.Properties.Name -notcontains $Key -or $null -eq $Source.$Key) {
        return
    }

    $items = @()
    if ($Source.$Key -is [string]) {
        $items = @(($Source.$Key -split "`n|,") | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ -ne "" })
    } else {
        $items = @($Source.$Key | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ -ne "" })
    }

    $items = @($items | Select-Object -Unique | Select-Object -First $Limit)
    if ($items.Count -gt 0) {
        $Target[$Key] = $items
    }
}

function ConvertTo-PublicSpecialRentalTerms {
    param($Terms)

    if ($null -eq $Terms -or $Terms.PSObject.Properties.Name -notcontains "enabled" -or -not [bool]$Terms.enabled) {
        return $null
    }

    $publicTerms = [ordered]@{
        enabled = $true
    }

    if ($Terms.PSObject.Properties.Name -contains "minDays" -and $null -ne $Terms.minDays -and [string]$Terms.minDays -ne "") {
        $minDays = 0
        if ([int]::TryParse(([string]$Terms.minDays), [ref]$minDays) -and $minDays -gt 0) {
            $publicTerms["minDays"] = $minDays
        }
    }

    foreach ($key in @("deliveryText", "note")) {
        if ($Terms.PSObject.Properties.Name -contains $key -and -not [string]::IsNullOrWhiteSpace([string]$Terms.$key)) {
            $publicTerms[$key] = ([string]$Terms.$key).Trim()
        }
    }

    return $publicTerms
}

function ConvertTo-PublicCar {
    param($Car, $Rate)

    $slug = ([string]$Car.slug).Trim()
    $name = ""
    foreach ($key in @("name", "title", "model")) {
        if ($Car.PSObject.Properties.Name -contains $key -and -not [string]::IsNullOrWhiteSpace([string]$Car.$key)) {
            $name = ([string]$Car.$key).Trim()
            break
        }
    }

    $publicCar = [ordered]@{
        slug = $slug
        name = $name
    }

    foreach ($key in @("class", "category", "seats", "drive", "transmission", "engine", "hourlyAvailable", "image")) {
        if ($Car.PSObject.Properties.Name -contains $key -and $null -ne $Car.$key -and [string]$Car.$key -ne "") {
            $publicCar[$key] = $Car.$key
        }
    }

    $price = ConvertTo-PublicPrice $Car $Rate
    if ($null -ne $price) {
        $publicCar["price"] = $price
    }

    foreach ($key in @("shortScenario", "cardDescription", "detailDescription", "seoTitle", "seoDescription")) {
        Copy-PublicTextField $Car $key $publicCar
    }

    foreach ($key in @("bestFor", "strongPoints", "cardBadgesCustom")) {
        Copy-PublicListField $Car $key $publicCar 8
    }

    if ($Car.PSObject.Properties.Name -contains "specialRentalTerms") {
        $specialTerms = ConvertTo-PublicSpecialRentalTerms $Car.specialRentalTerms
        if ($null -ne $specialTerms) {
            $publicCar["specialRentalTerms"] = $specialTerms
        }
    }

    $publicCar["isPublished"] = $true
    $publicCar["publicStatus"] = "published"

    return $publicCar
}

function Copy-PublicRateField {
    param($Rate, [string]$Key, $Target)

    if ($Rate -and $Rate.PSObject.Properties.Name -contains $Key -and $null -ne $Rate.$Key -and [string]$Rate.$Key -ne "") {
        $Target[$Key] = $Rate.$Key
    }
}

function ConvertTo-PublicRate {
    param($Rate)

    $publicRate = [ordered]@{}
    foreach ($key in @("base", "highSeason", "lowSeason", "holiday", "from3", "from7", "from14", "hourly", "manual", "updatedAt")) {
        Copy-PublicRateField $Rate $key $publicRate
    }

    return $publicRate
}

function ConvertTo-PublicAvailabilityStatus {
    param($Status)

    $statusText = ([string]$Status).Trim().ToLowerInvariant()
    switch ($statusText) {
        "service" { return "service" }
        "maintenance" { return "service" }
        "unavailable" { return "unavailable" }
        "blocked" { return "unavailable" }
        "free" { return $null }
        default { return "busy" }
    }
}

Assert-PublicDataEnvironment
Assert-JsonFile (Join-Path $privateDir "current-cars.json") "private current-cars"
Assert-JsonFile (Join-Path $privateDir "rates.json") "private rates"
Assert-JsonFile (Join-Path $privateDir "availability.json") "private availability"

$cars = ConvertTo-ObjectArray (Read-JsonFile (Join-Path $privateDir "current-cars.json") @())
$rates = Read-JsonFile (Join-Path $privateDir "rates.json") ([pscustomobject]@{ updatedAt = $null; settings = @{}; cars = @{} })
$availability = Read-JsonFile (Join-Path $privateDir "availability.json") ([pscustomobject]@{ updatedAt = $null; cars = @{} })
$lessors = ConvertTo-ObjectArray (Read-JsonFile (Join-Path $privateDir "lessors.json") @())

if ($availability -is [array]) {
    Write-Warning "Private availability source is an array; Stage 1 keeps business logic unchanged, but empty-array public generation risk must be fixed separately."
} elseif ($availability.PSObject.Properties.Name -notcontains "cars") {
    Write-Warning "Private availability source has no cars property; public availability generation may be empty. Business logic was not changed by Stage 1."
}

$script:lessorsByScope = @{}
foreach ($lessor in $lessors) {
    $scope = ""
    foreach ($key in @("scopeId", "scope_id", "owner_scope_id", "id")) {
        if ($lessor.PSObject.Properties.Name -contains $key -and -not [string]::IsNullOrWhiteSpace([string]$lessor.$key)) {
            $scope = ([string]$lessor.$key).Trim()
            break
        }
    }

    if ($scope -eq "" -and $lessor.PSObject.Properties.Name -contains "slug") {
        $scope = Get-ScopeIdFromLessorSlug $lessor.slug
    }

    if ($scope -ne "") {
        $script:lessorsByScope[$scope] = $lessor
    }
}

$publicCars = @()
$visibleSlugs = @{}
$skippedCars = @()
$missingRates = @()

foreach ($car in $cars) {
    $slug = ([string]$car.slug).Trim()
    if ($slug -eq "") {
        continue
    }

    if (-not (Test-CarVisibleInPublicShowcase $car)) {
        $skippedCars += $slug
        continue
    }

    $rate = $null
    if ($rates.cars -and $rates.cars.PSObject.Properties.Name -contains $slug) {
        $rate = $rates.cars.$slug
    } else {
        $missingRates += $slug
    }

    $publicCars += ConvertTo-PublicCar $car $rate
    $visibleSlugs[$slug] = $true
}

$publicRatesCars = [ordered]@{}
foreach ($car in $publicCars) {
    $slug = ([string]$car.slug).Trim()
    if ($rates.cars -and $rates.cars.PSObject.Properties.Name -contains $slug) {
        $publicRatesCars[$slug] = ConvertTo-PublicRate $rates.cars.$slug
    }
}

$publicRates = [ordered]@{
    updatedAt = $rates.updatedAt
    generatedAt = (Get-Date).ToString("s")
    settings = [ordered]@{}
    cars = $publicRatesCars
}

foreach ($key in @("currency", "defaultDeposit", "highSeasonMonths", "lowSeasonMonths", "holidayDates", "includedMileage")) {
    if ($rates.settings -and $rates.settings.PSObject.Properties.Name -contains $key) {
        $publicRates.settings[$key] = $rates.settings.$key
    }
}

$publicAvailabilityCars = [ordered]@{}
if ($availability.cars) {
    foreach ($slug in $visibleSlugs.Keys | Sort-Object) {
        $publicAvailabilityCars[$slug] = [ordered]@{}
        if ($availability.cars.PSObject.Properties.Name -contains $slug) {
            foreach ($dateProp in $availability.cars.$slug.PSObject.Properties) {
                $publicStatus = ConvertTo-PublicAvailabilityStatus $dateProp.Value.status
                if ($null -eq $publicStatus) {
                    continue
                }

                $entry = [ordered]@{
                    status = $publicStatus
                }

                if ($dateProp.Value.PSObject.Properties.Name -contains "updatedAt" -and -not [string]::IsNullOrWhiteSpace([string]$dateProp.Value.updatedAt)) {
                    $entry["updatedAt"] = $dateProp.Value.updatedAt
                }

                $publicAvailabilityCars[$slug][$dateProp.Name] = $entry
            }
        }
    }
}

$publicAvailability = [ordered]@{
    updatedAt = $availability.updatedAt
    generatedAt = (Get-Date).ToString("s")
    cars = $publicAvailabilityCars
}

if (Test-PublicDataTargetEnabled "Cars") {
    Write-JsonFile (Join-Path $publicDir "current-cars.json") $publicCars
}
if (Test-PublicDataTargetEnabled "Rates") {
    Write-JsonFile (Join-Path $publicDir "rates.json") $publicRates
}
if (Test-PublicDataTargetEnabled "Availability") {
    Write-JsonFile (Join-Path $publicDir "availability.json") $publicAvailability
}

if ($Preflight) {
    Write-PublicCarPreflight $script:PublicDataPreflightSlug $publicCars
}

if ($script:PublicDataWriteEnabled) {
    Write-Host "Publication data generated"
} else {
    Write-Host "Publication data dry-run/no-write completed"
}
Write-Host ("Mode: {0}; Slug: {1}; DryRun: {2}; NoWrite: {3}; ManifestOnly: {4}; Preflight: {5}; Write enabled: {6}" -f $Mode, $script:PublicDataPreflightSlug, [bool]$DryRun, [bool]$NoWrite, [bool]$ManifestOnly, [bool]$Preflight, [bool]$script:PublicDataWriteEnabled)
Write-Host ("Private cars: {0}" -f $cars.Count)
Write-Host ("Public cars generated: {0}" -f $publicCars.Count)
Write-Host ("Rates generated: {0}" -f $publicRatesCars.Count)
Write-Host ("Availability car buckets generated: {0}" -f $publicAvailabilityCars.Count)
Write-Host ("Skipped cars: {0}" -f $skippedCars.Count)
Write-Host ("Missing rates: {0}" -f $missingRates.Count)
Write-Host "Public data manifest:"
foreach ($item in $script:PublicDataManifest) {
    Write-Host ("- {0}: {1} (current={2}; planned={3}; write={4})" -f $item.outputPath, $item.status, $item.currentHash, $item.plannedHash, $item.writeEnabled)
}
if ($skippedCars.Count -gt 0) {
    Write-Host ("Skipped car slugs: {0}" -f ($skippedCars -join ", "))
}
if ($missingRates.Count -gt 0) {
    Write-Host ("Missing rate slugs: {0}" -f ($missingRates -join ", "))
}
