<?php
declare(strict_types=1);

// Internal CLI participant of build-site.ps1, not a public publication endpoint.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../admin/includes/bootstrap.php';

function site_build_public_path(string $name): bool
{
    return in_array($name, ['index.html', 'sitemap.xml', 'robots.txt'], true)
        || (bool) preg_match('~^(?:cars|pages|routes)/[a-z0-9-]+\.html$~D', $name)
        || (bool) preg_match('~^partner/[a-z0-9-]+/(?:[a-z0-9-]+/)?index\.html$~D', $name);
}

function site_build_snapshot(): array
{
    $inputs = [];
    foreach (['current-cars', 'rates', 'car-page-content', 'partners', 'admin-users', 'lessors', 'access-rules', 'callback-settings', 'build-state'] as $name) {
        $inputs[] = rtrim(DATA_DIR, '/\\') . '/' . $name . '.json';
    }
    foreach (['data/routes.json', 'tools/build-site.ps1', 'tools/build-state.ps1', 'tools/build-site-transaction.php'] as $name) {
        $inputs[] = PROJECT_ROOT . $name;
    }
    $rows = []; $hashes = []; $total = 0;
    foreach ($inputs as $path) {
        if (is_link($path)) { throw new RuntimeException('Linked build input refused.'); }
        $bytes = is_file($path) ? file_get_contents($path) : null;
        if ($bytes === false || ($total += strlen($bytes ?? '')) > 32 * 1024 * 1024) { throw new RuntimeException('Build input cannot be snapshotted.'); }
        $path = str_replace('\\', '/', $path);
        $rows[] = ['path' => $path, 'bytes' => $bytes === null ? null : base64_encode($bytes)];
        $hashes[$path] = $bytes === null ? null : hash('sha256', $bytes);
    }
    $outputs = [];
    foreach (['index.html', 'sitemap.xml', 'robots.txt'] as $name) {
        $outputs[$name] = is_file(PROJECT_ROOT . $name) ? hash_file('sha256', PROJECT_ROOT . $name) : null;
    }
    foreach (['cars', 'pages', 'routes', 'partner'] as $dir) {
        if (!is_dir(PROJECT_ROOT . $dir)) { continue; }
        $iterator = new RecursiveIteratorIterator(new RecursiveCallbackFilterIterator(
            new RecursiveDirectoryIterator(PROJECT_ROOT . $dir, FilesystemIterator::SKIP_DOTS),
            static function (SplFileInfo $entry): bool {
                if ($entry->isLink()) { throw new RuntimeException('Linked build output refused.'); }
                return $entry->getFilename() !== 'abcp';
            }
        ));
        foreach ($iterator as $entry) {
            $name = substr(str_replace('\\', '/', $entry->getPathname()), strlen(str_replace('\\', '/', PROJECT_ROOT)));
            if (site_build_public_path($name)) { $outputs[$name] = hash_file('sha256', $entry->getPathname()); }
        }
    }
    ksort($outputs); ksort($hashes);
    return ['version' => hash('sha256', json_encode([realpath(PROJECT_ROOT), realpath(DATA_DIR), $hashes, $outputs], JSON_THROW_ON_ERROR)),
        'inputs' => $rows, 'outputs' => $outputs, 'dataDir' => rtrim(DATA_DIR, '/\\')];
}

try {
    $wire = stream_get_contents(STDIN, 64 * 1024 * 1024 + 1);
    if ($wire === false || strlen($wire) > 64 * 1024 * 1024) { throw new RuntimeException('Build proposal exceeds limit.'); }
    $request = json_decode(preg_replace('/^\xEF\xBB\xBF/', '', $wire), true, 512, JSON_THROW_ON_ERROR);
    if (!is_array($request)) { throw new RuntimeException('Invalid build proposal.'); }
    $action = $argv[1] ?? '';
    if (!in_array($action, ['prepare', 'commit'], true)) { throw new RuntimeException('Invalid build phase.'); }
    $reply = RentalReturnStore::transaction(static function () use ($action, $request): array {
        if (PhpPublicationCutover::selected()) throw new RuntimeException('BLOCKED_LEGACY_PHP_CUTOVER', 409);
        if ($action === 'prepare') { return site_build_snapshot(); }
        $id = (string) ($request['id'] ?? '');
        if (!preg_match('~^\d{8}-\d{6}-[a-f0-9]{32}$~D', $id) || !is_array($request['state'] ?? null)
            || !is_array($request['outputs'] ?? null) || !is_array($request['deletes'] ?? null)) { throw new RuntimeException('Invalid build plan.'); }
        $fingerprint = hash('sha256', json_encode($request, JSON_THROW_ON_ERROR));
        $state = RentalReturnStore::read(BUILD_STATE_FILE, default_build_state());
        foreach (($state['runs'] ?? []) as $run) {
            if (($run['id'] ?? null) === $id) {
                if (($run['commitFingerprint'] ?? '') !== $fingerprint) { throw new RuntimeException('Build id reuse refused.', 409); }
                return ['committed' => true, 'replayed' => true, 'id' => $id];
            }
        }
        $current = site_build_snapshot();
        if (!hash_equals($current['version'], (string) ($request['version'] ?? ''))) { throw new RuntimeException('Build inputs or publication changed; repeat from a fresh snapshot.', 409); }
        $after = array_replace($state, $request['state']);
        if (($after['lastRun']['id'] ?? null) !== $id || ($after['runs'][0]['id'] ?? null) !== $id) { throw new RuntimeException('Build receipt mismatch.'); }
        if (array_slice($after['runs'], 1) !== array_slice($state['runs'] ?? [], 0, 49)) { throw new RuntimeException('Build history preservation mismatch.'); }
        $outputs = $request['outputs']; $deletes = $request['deletes'];
        if (count($outputs) + count($deletes) > 2000) { throw new RuntimeException('Build plan exceeds limit.'); }
        foreach (array_unique(array_merge(array_keys($outputs), $deletes)) as $name) {
            if (!is_string($name) || !site_build_public_path($name) || (isset($outputs[$name]) && in_array($name, $deletes, true))) { throw new RuntimeException('Invalid build output.'); }
            $before = RentalReturnStore::publicationOutputBytes($name);
            if ($before !== null) {
                $backup = '@data/backups/generated-output-backups/' . $id . '/' . $name;
                if (RentalReturnStore::publicationOutputBytes($backup) !== null) { throw new RuntimeException('Build backup collision.', 409); }
                RentalReturnStore::stagePublicationOutput($backup, $before);
            }
            if (array_key_exists($name, $outputs)) {
                if (!is_string($outputs[$name]) || $outputs[$name] === '') { throw new RuntimeException('Invalid build bytes.'); }
                if (($after['outputs'][$name]['outputHash'] ?? '') !== 'sha256:' . hash('sha256', $outputs[$name])) {
                    throw new RuntimeException('Build output receipt does not match staged bytes.');
                }
                RentalReturnStore::stagePublicationOutput($name, $outputs[$name]);
            } elseif ($before !== null) {
                RentalReturnStore::stagePublicationDeletion($name);
            }
        }
        $after['runs'][0]['commitFingerprint'] = $fingerprint;
        $after['lastRun']['commitFingerprint'] = $fingerprint;
        RentalReturnStore::stage(BUILD_STATE_FILE, $after);
        audit_log('site.build.commit', 'site', $id, 'Generated build committed', ['runId' => $id, 'outputs' => count($outputs), 'deletes' => count($deletes)]);
        return ['committed' => true, 'replayed' => false, 'id' => $id];
    });
    $reply['environment'] = ['php' => PHP_VERSION, 'sapi' => PHP_SAPI, 'opcache' => ini_get('opcache.enable'),
        'opcacheCli' => ini_get('opcache.enable_cli'), 'fileCache' => ini_get('opcache.file_cache'), 'allowUrlFopen' => ini_get('allow_url_fopen')];
    echo json_encode($reply, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $error) {
    echo json_encode(['error' => $error->getMessage(), 'code' => $error->getCode()], JSON_THROW_ON_ERROR);
    exit(1);
}
