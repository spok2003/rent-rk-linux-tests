<?php
declare(strict_types=1);

// This file is loaded only by the isolated PHP configuration, before a QA entry point.
$lab = realpath((string) getenv('RENT_RK_AUDIT_LAB_ROOT'));
$binding = json_decode((string) file_get_contents(__DIR__ . '/binding.json'), true);
if (!$lab || str_replace('\\', '/', $lab) !== ($binding['root'] ?? null)
    || str_replace('\\', '/', (string) realpath((string) ini_get('open_basedir'))) !== ($binding['boundary'] ?? $binding['root'] ?? null)
    || ini_get('allow_url_fopen') !== '0'
    || !in_array(PHP_SAPI, ['cli', 'cli-server'], true)) {
    throw new RuntimeException('Audit isolation failed before application startup.');
}
if (!defined('RENT_RK_AUDIT_ISOLATION_VERIFIED')) define('RENT_RK_AUDIT_ISOLATION_VERIFIED', true);
unset($lab, $binding);
