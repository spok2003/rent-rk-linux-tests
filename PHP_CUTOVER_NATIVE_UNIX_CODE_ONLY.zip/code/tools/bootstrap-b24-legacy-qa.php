<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || !RENT_RK_AUDIT_ISOLATION_VERIFIED) { throw new RuntimeException('Verified lab CLI required'); }
$root = realpath((string) getenv('RENT_RK_AUDIT_LAB_ROOT'));
if (!$root || realpath(__DIR__ . '/..') !== $root || !is_file($root . '/.rent-rk-test-lab')) { throw new RuntimeException('Wrong lab root'); }
require $root . '/admin/includes/bootstrap.php';
RentalReturnStore::leave();
$checks = []; $observations = [];
$check = static function (string $id, bool $passed) use (&$checks): void {
    $checks[] = ['test' => $id, 'passed' => $passed];
    if (!$passed) { throw new RuntimeException($id); }
};
$snapshot = static function () use ($root): array {
    $result = [];
    foreach (array_unique([$root . '/private/rent-rk-data', rtrim(DATA_DIR, '/\\'), $root . '/data', $root . '/cars', $root . '/pages', $root . '/routes', $root . '/partner', $root . '/tmp']) as $dir) {
        if (!is_dir($dir)) { continue; }
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $file) {
            if ($file->isLink()) { throw new RuntimeException('Linked fixture'); }
            if ($file->isFile()) {
                $label = substr($file->getPathname(), strlen($root) + 1);
                if (preg_match('~(?:^|[\\\\/])sess_[^\\\\/]+~', $label)) {
                    $label = 'redacted-session-file:' . hash('sha256', $label);
                }
                $result[$label] = hash_file('sha256', $file->getPathname());
            }
        }
    }
    foreach (['index.html', 'sitemap.xml', 'robots.txt'] as $name) { $result[$name] = is_file($root . '/' . $name) ? hash_file('sha256', $root . '/' . $name) : null; }
    ksort($result); return $result;
};
$source = file_get_contents($root . '/admin/includes/bootstrap.php');
$body = static function (string $name) use ($source): string {
    $r = new ReflectionFunction($name); $lines = explode("\n", $source);
    return implode("\n", array_slice($lines, $r->getStartLine() - 1, $r->getEndLine() - $r->getStartLine() + 1));
};
$before = $snapshot();
foreach (['run_guarded_single_car_publish_preflight', 'run_guarded_single_car_publish_apply'] as $name) {
    $tokens = token_get_all('<?php ' . $body($name)); $opened = false; $first = null;
    foreach ($tokens as $t) {
        if (!$opened) { if ($t === '{') { $opened = true; } continue; }
        if (is_array($t) && in_array($t[0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) { continue; }
        $first = is_array($t) ? $t[0] : $t; break;
    }
    $check($name . ':first-statement-return', $first === T_RETURN);
    $check($name . ':historical-body-retained', str_contains($body($name), '@exec('));
    foreach (['ford-fiesta', 'qa-independent-car', '', '../not-a-car'] as $slug) {
        foreach (['direct', 'dynamic', 'reflection'] as $mode) {
            for ($repeat = 0; $repeat < 2; $repeat++) {
                $override = $root . '/tools/build-site.ps1';
                $result = match ($mode) {
                    'direct' => $name === 'run_guarded_single_car_publish_apply' ? run_guarded_single_car_publish_apply($slug, $override) : run_guarded_single_car_publish_preflight($slug, $override),
                    'dynamic' => call_user_func($name, $slug, $override),
                    default => (new ReflectionFunction($name))->invoke($slug, $override),
                };
                $id = $name . ':' . $mode . ':' . hash('sha256', $slug) . ':' . $repeat;
                $check($id, $result['success'] === false && $result['blocked'] === true && $result['status'] === 'deprecated' && $result['reason'] === 'deprecated_legacy_publication' && $result['output'] === [] && $result['result'] === null && $result['exitCode'] === null && $result['resultPath'] === '');
                $observations[] = ['id' => $id, 'result' => $result];
            }
        }
    }
}
$pageBody = $body('run_car_page_content_publish');
$prefix = substr($pageBody, 0, strpos($pageBody, '    $status = public_site_rebuild_status();'));
$check('page-content-native-wrapper-return-before-legacy-exec', str_contains($prefix, 'return publish_car_page_content_php($slug, [], $expectedVersion);') && !str_contains($prefix, 'exec(') && !preg_match('/\b(?:goto|yield|eval)\b/', $prefix));
$after = $snapshot();
$check('exact-file-byte-and-path-preservation', $before === $after);
$check('no-active-transaction', !RentalReturnStore::active());
echo json_encode(['status' => 'PASS', 'checks' => $checks, 'observations' => $observations, 'before' => $before, 'after' => $after,
    'environment' => ['php' => PHP_BINARY, 'version' => PHP_VERSION, 'sapi' => PHP_SAPI, 'os' => PHP_OS_FAMILY, 'opcache' => ini_get('opcache.enable'), 'cli' => ini_get('opcache.enable_cli'), 'fileCache' => ini_get('opcache.file_cache'), 'execAvailable' => function_exists('exec'), 'bootstrapSha256' => hash('sha256', $source)]], JSON_THROW_ON_ERROR);
