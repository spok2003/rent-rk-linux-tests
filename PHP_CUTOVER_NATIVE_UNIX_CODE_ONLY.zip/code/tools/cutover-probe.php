<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || !RENT_RK_AUDIT_ISOLATION_VERIFIED) exit(2);
require __DIR__ . '/../admin/includes/bootstrap.php';
$action = $argv[1] ?? '';
if ($action === 'hold-worker') {
    $GLOBALS['rental_return_test_hook'] = static function (string $point): void {
        if ($point !== 'journal.prepared') return;
        file_put_contents(DATA_DIR . 'qa-worker-at-commit', 'prepared');
        $deadline = microtime(true) + 6;
        do {
            if (is_file(DATA_DIR . 'qa-release-worker')) return;
            usleep(10000);
            clearstatcache();
        } while (microtime(true) < $deadline);
        throw new RuntimeException('QA worker barrier expired');
    };
    $result = PhpPublicationAutomation::once();
} elseif ($action === 'legacy') {
    $result = ['full' => rebuild_public_site_result(), 'car' => rebuild_public_site_result('synthetic-auto-car'),
        'available' => public_site_rebuild_status(), 'boolean' => rebuild_public_site(),
        'withdrawn' => PhpPublicationAutomation::unavailable('synthetic-auto-car'),
        'exec' => function_exists('exec'), 'os' => PHP_OS_FAMILY, 'sapi' => PHP_SAPI, 'php' => PHP_VERSION];
} elseif (in_array($action, ['dry','prepare-no-authority','apply-no-authority'], true)) {
    $actor = $argv[2] ?? 'qa-dry-root';
    $slug = $argv[3] ?? 'synthetic-auto-car';
    if (!in_array($actor, ['qa-dry-root', 'qa-rate-editor', 'qa-car-publisher', 'qa-park-preview'], true)
        || !in_array($slug, ['synthetic-auto-car','synthetic-auto-second'], true)) exit(2);
    $_SESSION['admin_user'] = $actor;
    if ($action === 'dry') {
        $result = run_car_publish_dry_run($slug);
    } else {
        require_once __DIR__ . '/../admin/includes/approved-public-car-snapshot.php';
        try {
            $service = ApprovedPublicCarSnapshots::fromServer();
            if ($action === 'prepare-no-authority') {
                $service->preparePhpApply($slug, $argv[4] ?? 'Car', []);
            } else {
                $generationOnly = ['payload' => ['actor' => ['cutoverGeneration' => PhpPublicationCutover::generation()]]];
                $service->applyPhpPlan($slug, $argv[4] ?? 'Car', [], $generationOnly, true);
            }
            $result = ['unexpected' => true];
        } catch (RuntimeException $e) {
            $result = ['reason' => $e->getMessage()];
        }
    }
} else {
    exit(2);
}
echo json_encode($result, JSON_THROW_ON_ERROR), PHP_EOL;
