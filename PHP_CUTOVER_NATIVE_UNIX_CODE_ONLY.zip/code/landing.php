<?php

declare(strict_types=1);

require_once __DIR__ . '/admin/includes/bootstrap.php';

$slug = demand_transliterate((string) ($_GET['slug'] ?? ''));
$landing = $slug !== '' ? demand_find_public_landing_by_slug($slug) : null;
$known = $slug !== '' ? demand_find_landing_by_slug_any_status($slug) : null;

if (!$landing) {
    http_response_code($known && in_array((string) ($known['publishStatus'] ?? ''), ['archived', 'merged', 'rolled_back'], true) ? 410 : 404);
    ?><!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Страница не найдена | Rent RK</title>
  <meta name="robots" content="noindex,nofollow">
  <link rel="stylesheet" href="/assets/css/main.css">
</head>
<body>
  <main class="section">
    <div class="container text-page">
      <h1>Страница не найдена</h1>
      <p>Посадочная страница недоступна или снята с публикации.</p>
      <a class="btn" href="/cars/">Смотреть автомобили</a>
    </div>
  </main>
</body>
</html><?php
    exit;
}

$publishStatus = (string) ($landing['publishStatus'] ?? '');
$indexed = $publishStatus === 'published_indexed';
$robots = $indexed ? 'index,follow' : 'noindex,follow';
$canonical = demand_public_landing_url($landing);
$title = (string) ($landing['title'] ?? $landing['h1'] ?? 'Аренда авто | Rent RK');
$description = (string) ($landing['metaDescription'] ?? $landing['intro'] ?? '');
$publicLanding = demand_prepare_public_landing_content($landing);
$linkedCars = (array) ($publicLanding['linkedCars'] ?? []);
$firstPhoto = '/assets/img/cars/omoda-c5/omoda-c5-1.jpg';
foreach ($linkedCars as $car) {
    $photos = car_photos($car);
    $photo = $photos[0]['path'] ?? ($car['image'] ?? '');
    if (trim((string) $photo) !== '') {
        $firstPhoto = '/' . ltrim(str_replace('\\', '/', (string) $photo), '/');
        break;
    }
}
$callback = callback_context_public_payload(callback_context_from_public_input([
    'page_url' => $canonical,
]));

function landing_block_body(array $block): string
{
    return trim((string) ($block['body'] ?? ''));
}

?><!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?></title>
  <meta name="description" content="<?= e($description) ?>">
  <meta name="robots" content="<?= e($robots) ?>">
  <link rel="canonical" href="<?= e($canonical) ?>">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Rent RK">
  <meta property="og:title" content="<?= e($title) ?>">
  <meta property="og:description" content="<?= e($description) ?>">
  <meta property="og:url" content="<?= e($canonical) ?>">
  <meta property="og:image" content="<?= e(demand_site_base_url() . $firstPhoto) ?>">
  <link rel="stylesheet" href="/assets/css/main.css">
</head>
<body>
  <header class="site-header">
    <div class="container nav">
      <a class="brand" href="/index.html">Rent RK <small>автопрокат в Ялте</small></a>
      <nav class="menu" aria-label="Основная навигация">
        <a href="/cars/">Автомобили</a>
        <a href="/pages/conditions.html">Условия</a>
        <a href="/pages/faq.html">FAQ</a>
        <a href="/routes/">Маршруты</a>
        <a href="/pages/contacts.html">Контакты</a>
      </nav>
      <div class="header-actions">
        <a class="btn secondary" href="tel:+79789485111" data-landing-phone>+7 (978) 948-51-11</a>
        <a class="btn" href="https://t.me/spok2003" data-landing-messenger>Telegram</a>
      </div>
    </div>
  </header>

  <nav class="breadcrumbs container" aria-label="Хлебные крошки">
    <a href="/index.html">Главная</a><span aria-hidden="true">/</span>
    <span aria-current="page"><?= e((string) ($landing['h1'] ?? 'Посадочная страница')) ?></span>
  </nav>

  <main>
    <section class="hero compact" style="--hero-image: url('<?= e($firstPhoto) ?>')">
      <div class="container hero-content">
        <p class="eyebrow">Rent RK</p>
        <h1><?= e((string) ($landing['h1'] ?? 'Аренда авто')) ?></h1>
        <p class="lead"><?= e((string) ($publicLanding['heroIntro'] ?? 'Подберите автомобиль под задачу и уточните условия у менеджера.')) ?></p>
        <div class="button-row">
          <a class="btn" href="#booking">Подобрать авто</a>
          <a class="btn secondary" href="#cars">Посмотреть автомобили</a>
          <a class="btn secondary" href="#conditions">Уточнить условия</a>
        </div>
      </div>
    </section>

    <?php if ($linkedCars): ?>
      <section class="section" id="cars">
        <div class="container">
          <div class="section-head compact-head">
            <div>
              <p class="eyebrow">Подходящие автомобили</p>
              <h2>Авто по этому запросу</h2>
            </div>
          </div>
          <div class="landing-cars-grid">
            <?php foreach (array_slice($linkedCars, 0, 6) as $car): ?>
              <?php
                $carSlug = normalize_car_slug((string) ($car['slug'] ?? ''));
                $photos = car_photos($car);
                $photo = (string) ($photos[0]['path'] ?? ($car['image'] ?? ''));
                $photo = $photo !== '' ? '/' . ltrim(str_replace('\\', '/', $photo), '/') : $firstPhoto;
                $rate = rate_for_car($carSlug, $car);
                $price = normalize_rate_price($rate['base'] ?? ($car['price'] ?? null));
                $deposit = normalize_rate_price($rate['depositAmount'] ?? $rate['deposit'] ?? $car['deposit'] ?? $car['depositAmount'] ?? null);
                $details = array_values(array_filter([
                    trim((string) ($car['class'] ?? $car['body'] ?? '')),
                    (int) ($car['seats'] ?? 0) > 0 ? (int) $car['seats'] . ' мест' : '',
                    trim((string) ($car['transmission'] ?? '')),
                    trim((string) ($car['drive'] ?? '')),
                ]));
              ?>
              <article class="landing-car-card">
                <a class="landing-car-card__image" href="/cars/<?= e($carSlug) ?>.html">
                  <img src="<?= e($photo) ?>" alt="<?= e((string) ($car['name'] ?? car_name($carSlug))) ?>" loading="lazy">
                </a>
                <div class="landing-car-card__body">
                  <h3><?= e((string) ($car['name'] ?? car_name($carSlug))) ?></h3>
                  <?php if ($details): ?><p class="landing-car-card__meta"><?= e(implode(' · ', array_slice($details, 0, 4))) ?></p><?php endif; ?>
                  <div class="landing-car-card__facts">
                    <span><?= $price !== null ? 'от ' . e(format_money((int) $price)) . ' / сутки' : 'Цена по датам' ?></span>
                    <span><?= $deposit !== null ? 'залог ' . e(format_money((int) $deposit)) : 'залог уточняется' ?></span>
                  </div>
                  <div class="landing-car-card__actions">
                    <a class="btn" href="/cars/<?= e($carSlug) ?>.html#booking" data-landing-car-click data-car-slug="<?= e($carSlug) ?>">Выбрать авто</a>
                    <a class="text-link" href="/cars/<?= e($carSlug) ?>.html">Подробнее</a>
                  </div>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
          <?php if (count($linkedCars) > 6): ?>
            <details class="landing-more-cars">
              <summary>Показать ещё автомобили</summary>
              <div class="landing-cars-grid">
                <?php foreach (array_slice($linkedCars, 6) as $car): ?>
                  <?php
                    $carSlug = normalize_car_slug((string) ($car['slug'] ?? ''));
                    $photos = car_photos($car);
                    $photo = (string) ($photos[0]['path'] ?? ($car['image'] ?? ''));
                    $photo = $photo !== '' ? '/' . ltrim(str_replace('\\', '/', $photo), '/') : $firstPhoto;
                    $rate = rate_for_car($carSlug, $car);
                    $price = normalize_rate_price($rate['base'] ?? ($car['price'] ?? null));
                    $deposit = normalize_rate_price($rate['depositAmount'] ?? $rate['deposit'] ?? $car['deposit'] ?? $car['depositAmount'] ?? null);
                    $details = array_values(array_filter([
                        trim((string) ($car['class'] ?? $car['body'] ?? '')),
                        (int) ($car['seats'] ?? 0) > 0 ? (int) $car['seats'] . ' мест' : '',
                        trim((string) ($car['transmission'] ?? '')),
                        trim((string) ($car['drive'] ?? '')),
                    ]));
                  ?>
                  <article class="landing-car-card">
                    <a class="landing-car-card__image" href="/cars/<?= e($carSlug) ?>.html">
                      <img src="<?= e($photo) ?>" alt="<?= e((string) ($car['name'] ?? car_name($carSlug))) ?>" loading="lazy">
                    </a>
                    <div class="landing-car-card__body">
                      <h3><?= e((string) ($car['name'] ?? car_name($carSlug))) ?></h3>
                      <?php if ($details): ?><p class="landing-car-card__meta"><?= e(implode(' · ', array_slice($details, 0, 4))) ?></p><?php endif; ?>
                      <div class="landing-car-card__facts">
                        <span><?= $price !== null ? 'от ' . e(format_money((int) $price)) . ' / сутки' : 'Цена по датам' ?></span>
                        <span><?= $deposit !== null ? 'залог ' . e(format_money((int) $deposit)) : 'залог уточняется' ?></span>
                      </div>
                      <div class="landing-car-card__actions">
                        <a class="btn" href="/cars/<?= e($carSlug) ?>.html#booking" data-landing-car-click data-car-slug="<?= e($carSlug) ?>">Выбрать авто</a>
                        <a class="text-link" href="/cars/<?= e($carSlug) ?>.html">Подробнее</a>
                      </div>
                    </div>
                  </article>
                <?php endforeach; ?>
              </div>
            </details>
          <?php endif; ?>
        </div>
      </section>
    <?php endif; ?>

    <section class="section soft landing-public-copy">
      <div class="container text-page">
        <?php foreach ((array) ($publicLanding['publicTextSections'] ?? []) as $section): ?>
          <?php if (!is_array($section)) { continue; } ?>
          <article class="landing-public-section">
            <h2><?= e((string) ($section['title'] ?? 'Полезно знать')) ?></h2>
            <p><?= e((string) ($section['body'] ?? '')) ?></p>
          </article>
        <?php endforeach; ?>
      </div>
    </section>

    <section class="section" id="conditions">
      <div class="container">
        <div class="section-head compact-head">
          <div>
            <p class="eyebrow">Условия</p>
            <h2>Что важно уточнить до поездки</h2>
          </div>
        </div>
        <div class="landing-condition-grid">
          <?php foreach ((array) ($publicLanding['conditionCards'] ?? []) as $card): ?>
            <?php if (!is_array($card)) { continue; } ?>
            <article class="landing-condition-card">
              <h3><?= e((string) ($card['title'] ?? 'Условие')) ?></h3>
              <p><?= e((string) ($card['text'] ?? 'Менеджер уточнит условия перед бронированием.')) ?></p>
            </article>
          <?php endforeach; ?>
        </div>
      </div>
    </section>

    <section class="section soft">
      <div class="container text-page landing-faq">
        <h2>FAQ</h2>
        <div class="landing-faq-list">
          <?php foreach ((array) ($publicLanding['faqItems'] ?? []) as $item): ?>
            <?php if (!is_array($item)) { continue; } ?>
            <details>
              <summary><?= e((string) ($item['question'] ?? 'Вопрос')) ?></summary>
              <p><?= e((string) ($item['answer'] ?? 'Уточняется менеджером.')) ?></p>
            </details>
          <?php endforeach; ?>
        </div>
      </div>
    </section>

    <?php if (!empty($publicLanding['internalLinks'])): ?>
      <section class="section landing-related-links">
        <div class="container text-page">
          <p class="eyebrow">Похожие варианты</p>
          <h2>Также может подойти</h2>
          <p>Если вы ещё выбираете формат поездки, посмотрите похожие варианты.</p>
          <div class="landing-related-links__grid">
            <?php foreach (array_slice((array) ($publicLanding['internalLinks'] ?? []), 0, 5) as $link): ?>
              <?php
                if (!is_array($link)) {
                    continue;
                }
                $linkUrl = demand_internal_link_safe_url($link['targetUrl'] ?? '');
                $anchor = demand_internal_link_clean_anchor($link['anchorText'] ?? '', (string) ($link['targetTitle'] ?? ''));
                if ($linkUrl === '' || $anchor === '') {
                    continue;
                }
              ?>
              <a class="landing-related-links__item" href="<?= e($linkUrl) ?>">
                <span><?= e($anchor) ?></span>
                <?php if (!empty($link['targetTitle']) && (string) $link['targetTitle'] !== $anchor): ?>
                  <small><?= e((string) $link['targetTitle']) ?></small>
                <?php endif; ?>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
      </section>
    <?php endif; ?>

    <section class="section booking-section" id="booking">
      <div class="container booking-form-shell">
        <div class="section-head compact-head">
          <div>
            <p class="eyebrow">Заявка</p>
            <h2>Подобрать автомобиль</h2>
            <p><?= e((string) ($publicLanding['cta'] ?? 'Оставьте даты и пожелания — менеджер проверит доступные авто и условия.')) ?></p>
          </div>
        </div>
        <form class="booking-form feature" data-booking-form action="/api/request.php" method="post">
          <input type="hidden" name="request_kind" value="selection">
          <input type="hidden" name="car_slug" value="">
          <input type="hidden" name="car_name" value="Подбор автомобиля">
          <input type="hidden" name="landing_page_id" value="<?= e((string) ($landing['id'] ?? '')) ?>">
          <input type="hidden" name="landing_page_slug" value="<?= e((string) ($landing['slug'] ?? '')) ?>">
          <input type="hidden" name="partner_slug" value="">
          <input type="hidden" name="partner_agent_slug" value="">
          <label class="hp-field">Не заполняйте это поле <input name="website" tabindex="-1" autocomplete="off"></label>
          <div class="form-grid">
            <label>Имя <input name="name" autocomplete="name" placeholder="Как к вам обращаться"></label>
            <label>Телефон <input name="phone" autocomplete="tel" placeholder="+7..." required></label>
            <label>Дата подачи <input type="date" name="start_date"></label>
            <label>Время подачи <input type="time" name="start_time"></label>
            <label>Дата возврата <input type="date" name="end_date"></label>
            <label>Время возврата <input type="time" name="end_time"></label>
          </div>
          <div class="form-grid">
            <label>Место подачи <input name="pickup_place" placeholder="Ялта, аэропорт, адрес или город"></label>
            <label>Место возврата <input name="return_place" placeholder="Если отличается от подачи"></label>
          </div>
          <label>Комментарий <textarea name="message" rows="4" placeholder="Например: нужна подача утром, детское кресло, поездка по маршруту"></textarea></label>
          <label class="check-row">
            <input type="checkbox" name="consent" value="1" required>
            <span>Согласен на обработку данных для связи по заявке.</span>
          </label>
          <button class="btn" type="submit">Отправить заявку</button>
          <p class="form-note" data-form-message></p>
        </form>
        <div class="booking-success feature" data-booking-success hidden>
          <p class="eyebrow">Заявка принята</p>
          <h3>Заявка принята в работу</h3>
          <p>Менеджер проверит автомобили и свяжется с вами.</p>
          <div class="button-row">
            <a class="btn" href="tel:+79789485111" data-landing-phone>Позвонить</a>
            <a class="btn secondary" href="https://t.me/spok2003" data-landing-messenger>Telegram</a>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container footer-grid">
      <div>
        <strong>Rent RK</strong>
        <p class="muted">Аренда автомобилей в Ялте и Крыму. Бесплатная доставка по Ялте, подача по Крыму по договоренности.</p>
      </div>
      <div>
        <strong>Контакты</strong>
        <p><a href="tel:+79789485111" data-landing-phone>+7 (978) 948-51-11</a><br><a href="https://t.me/spok2003" data-landing-messenger>Telegram</a><br>Ялта, ул. Московская, 33</p>
      </div>
      <div>
        <strong>Документы</strong>
        <p><a href="/pages/conditions.html">Условия аренды</a><br><a href="/pages/faq.html">Вопросы и ответы</a><br><a href="/cars/">Каталог автомобилей</a></p>
      </div>
    </div>
  </footer>

  <script type="application/json" id="rent-rk-callback-context"><?= json_encode($callback, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
  <script src="/assets/js/analytics-tracker.js"></script>
  <script>
    window.RentRkLandingPage = {
      id: <?= json_encode((string) ($landing['id'] ?? ''), JSON_UNESCAPED_UNICODE) ?>,
      slug: <?= json_encode((string) ($landing['slug'] ?? ''), JSON_UNESCAPED_UNICODE) ?>,
      indexed: <?= $indexed ? 'true' : 'false' ?>
    };
    if (window.RentRkLandingPage.indexed) {
      window.RentRkAnalytics?.track("landing_page_public_view", {
        pageType: "landing_page",
        entityType: "landing_page",
        entityId: window.RentRkLandingPage.id,
        meta: { slug: window.RentRkLandingPage.slug }
      }, { dedupeMs: 60000 });
      document.addEventListener("click", (event) => {
        const car = event.target?.closest("[data-landing-car-click]");
        if (car) {
          window.RentRkAnalytics?.track("landing_page_car_click", {
            pageType: "landing_page",
            entityType: "landing_page",
            entityId: window.RentRkLandingPage.id,
            carId: car.dataset.carSlug || "",
            meta: { slug: window.RentRkLandingPage.slug }
          }, { dedupeMs: 1000 });
        }
        if (event.target?.closest("[data-landing-phone]")) {
          window.RentRkAnalytics?.track("landing_page_phone_click", { pageType: "landing_page", entityType: "landing_page", entityId: window.RentRkLandingPage.id }, { dedupeMs: 1000 });
        }
        if (event.target?.closest("[data-landing-messenger]")) {
          window.RentRkAnalytics?.track("landing_page_messenger_click", { pageType: "landing_page", entityType: "landing_page", entityId: window.RentRkLandingPage.id }, { dedupeMs: 1000 });
        }
      }, true);
      document.addEventListener("focusin", (event) => {
        if (event.target?.closest("[data-booking-form]")) {
          window.RentRkAnalytics?.track("landing_page_request_started", { pageType: "landing_page", entityType: "landing_page", entityId: window.RentRkLandingPage.id }, { dedupeMs: 600000 });
        }
      }, true);
    }
  </script>
  <script src="/assets/js/main.js"></script>
</body>
</html>
