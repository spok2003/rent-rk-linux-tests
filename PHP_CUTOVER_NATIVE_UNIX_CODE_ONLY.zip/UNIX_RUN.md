# Native Unix component run (not executed)

This is a transfer kit, not approval to install or connect. Provide one explicitly authorized disposable native Linux/Unix environment with isolated loopback, no external egress or mounted working data, a local filesystem supporting flock, fsync and same-directory rename, existing PHP 8.4 CLI/cli-server with sodium, DOM, mbstring and fileinfo, Node.js 22+ and Python 3. Record OS/kernel, mount type, PHP binary SHA/version, SAPI and available extensions. Do not use production.

Verify the SHA-256 of this closeout's PHP_CUTOVER_NATIVE_UNIX_CODE_ONLY.zip against its new transfer receipt, not the earlier package 3 ZIP. Its input manifests are source identities, not Windows result receipts. Inside that isolated environment, as its unprivileged test user:

```sh
owner="$(python3 -c 'import tempfile; print(tempfile.mkdtemp(prefix="rent-rk-b24-code-only-"))')"
python3 -m zipfile -t /approved-transfer/PHP_CUTOVER_NATIVE_UNIX_CODE_ONLY.zip
python3 -m zipfile -e /approved-transfer/PHP_CUTOVER_NATIVE_UNIX_CODE_ONLY.zip "$owner"
mkdir -p "$owner/code/data" "$owner/code/tmp/business-data-audit"
RENT_RK_UNIX_QA_PHP=/usr/bin/php node "$owner/qa/run.cjs" "$owner/code" series-1
```

Use a previously approved alternate absolute PHP executable if needed. Use the same isolated local TMPDIR for extraction and execution. The runner checks the source/QA hashes and rejects a sibling private store before creating new synthetic data and trust. The PHP guard disables external I/O functions and exec for this component. The stock audit tool records Windows-only browser and ZIP module paths; the native launcher preserves the preflight output and ignores only absence of those two unused modules, not source, PHP or artifact violations. Do not run the full Gate or historical B24 PowerShell contract.

Require native OS/SAPI from the CLI probe and loopback HTTP receipts; missing PHP capability must fail without fallback. Require Full/Car confirmations, HTTP 200/403 and PLAN_ONLY/no writes, absent legacy invocation, queued and active stop, prepared/committed recovery, refusal of the old bridge, withdrawal and sitemap/URL/photo/ownership controls. Preserve primary, before/after and Unix environment receipts. Check ownership from lab-ownership.json, stop task processes, and remove only the two exact disposable directories in the authorized temp root after saving evidence. Windows cleanup.ps1 is not used on Unix. Report any native precondition failure without dropping the Unix gate.

The same runner must demonstrate that both effective profiles (cars.publish without global/settings authority, and content.publish.single_page for its own park) receive real preview rows in HTTP and PLAN_ONLY/canApply=false in CLI. It must refuse missing or lost rights, lost scope, a foreign car, approval, ticket preparation and apply. Do not use the reproduce switch; that belongs only to the earlier Windows source boundary.
