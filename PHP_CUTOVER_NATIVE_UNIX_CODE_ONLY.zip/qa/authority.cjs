'use strict';
module.exports=async ({cli,check,diag,fs,at,data,sha,read,json,put,info,post,slug,second,root,editor,reproduce,save,
  invariant,unchanged,rootApproval})=>{
  const manager='qa-car-publisher', park='qa-park-preview';
  const m=await info(manager,slug), p=await info(park,second);
  const facts=x=>({edit:x.canEdit,publish:x.canPublish,single:x.canSingle,settings:x.settings,global:x.global,
    owns:x.owns,inList:x.inList,scope:x.scope});
  check('effective-legacy-rights-and-scope-not-role-name',m.canEdit&&m.canPublish&&!m.settings&&!m.global&&m.owns&&m.inList
    &&p.canEdit&&p.canSingle&&!p.canPublish&&!p.settings&&!p.global&&p.owns&&p.inList&&p.scope==='synthetic-preview-park',
    {manager:facts(m),park:facts(p)});
  const before=invariant();
  const dry=(actor,target,csrf)=>post('/admin/car-edit.php?id='+target,actor,{action:'publish_dry_run',csrf_token:csrf,id:target});
  const resultRow=(r,target)=>r.body.includes('Dry-run проверки публичной страницы выполнен:')&&r.body.includes('cars/'+target+'.html');
  const mr=await dry(manager,slug,m.csrf), pr=await dry(park,second,p.csrf);
  const ml=await cli(['tools/cutover-probe.php','dry',manager,slug]);
  const pl=await cli(['tools/cutover-probe.php','dry',park,second]);
  if(reproduce){
    const repro=mr.status===200&&pr.status===200&&!resultRow(mr,slug)&&!resultRow(pr,second)
      &&mr.body.includes('BLOCKED_PHP_APPLY_ACCESS')&&pr.body.includes('BLOCKED_PHP_APPLY_ACCESS')
      &&ml.result?.error==='BLOCKED_PHP_APPLY_ACCESS'&&pl.result?.error==='BLOCKED_PHP_APPLY_ACCESS';
    const evidence={manager:facts(m),park:facts(p),managerHttp:diag(mr),parkHttp:diag(pr),managerCli:ml,parkCli:pl,
      bodyMatched:'BLOCKED_PHP_APPLY_ACCESS',unchanged:unchanged(before)};
    check('old-http-200-with-real-authority-error-reproduced',repro&&evidence.unchanged,evidence);
    save('reproduction.json',evidence);
    return;
  }
  for(const [label,r,c,target] of [['cars-publish',mr,ml,slug],['single-page-own-park',pr,pl,second]]){
    check(label+'-http-and-cli-preview-only',r.status===200&&resultRow(r,target)&&c.exit===0&&c.result?.status==='PLAN_ONLY'
      &&c.result.canApply===false&&c.result.parsed.items.some(x=>x.path==='cars/'+target+'.html')
      &&c.result.parsed.items.every(x=>!('payloadBase64' in x)&&!('ticket' in x))
      &&!r.body.includes('preview_id'),{http:diag(r),cli:c});
  }
  const foreignHttp=await dry(park,slug,p.csrf), foreignCli=await cli(['tools/cutover-probe.php','dry',park,slug]);
  const invalid=await cli(['tools/cutover-probe.php','dry',editor,slug]);
  check('foreign-park-and-missing-rights-rejected-without-output',foreignHttp.status===403&&!resultRow(foreignHttp,slug)
    &&foreignCli.result?.reason==='access_changed'&&foreignCli.result.parsed.items.length===0
    &&invalid.result?.reason==='access_changed'&&invalid.result.parsed.items.length===0
    &&!pr.body.includes('cars/'+slug+'.html')&&!JSON.stringify(pl.result).includes('cars/'+slug+'.html'),
    {http:diag(foreignHttp),foreignCli,invalid});
  const approve=(actor,target,csrf,action,fields)=>post('/admin/public-car-approvals.php?slug='+target,actor,{action,slug:target,csrf_token:csrf,...fields});
  for(const mode of ['Car','Full']){
    const ticket=await approve(park,second,p.csrf,'prepare_cutover',{plan_mode:mode});
    const service=await cli(['tools/cutover-probe.php','prepare-no-authority',park,second,mode]);
    const applyService=await cli(['tools/cutover-probe.php','apply-no-authority',park,second,mode]);
    check('preview-does-not-grant-'+mode+'-ticket-or-apply',ticket.status===403&&!ticket.body.includes('name="preview_id"')
      &&service.result?.reason==='BLOCKED_PHP_APPLY_ACCESS'&&applyService.result?.reason==='BLOCKED_PHP_APPLY_ACCESS',
      {http:diag(ticket),service,applyService});
  }
  const deniedApproval=await approve(park,second,p.csrf,'approve',{review_version:rootApproval.reviewVersion,confirm_publish:'1'});
  const deniedApply=await approve(park,second,p.csrf,'apply_cutover',{preview_id:'a'.repeat(32),confirm_publish:'1'});
  check('preview-does-not-grant-approval-or-apply',deniedApproval.status===403&&deniedApply.status===403
    &&!deniedApply.body.includes('Точный PHP-план применён')&&!deniedApproval.body.includes('Версия одобрена.'),
    {approval:diag(deniedApproval),apply:diag(deniedApply)});
  const users=data('admin-users'), original=read(users);
  try {
    const noRight=json(users);
    noRight.users.find(x=>x.login===park).permissions=['cars.edit'];
    put(users,noRight);
    const r=await dry(park,second,p.csrf);
    check('previous-session-cannot-reuse-revoked-right',r.status===403&&!resultRow(r,second),diag(r));
    const outOfScope=JSON.parse(original);
    outOfScope.users.find(x=>x.login===park).lessorSlug='synthetic-other-park';
    put(users,outOfScope);
    const denied=await dry(park,second,p.csrf);
    check('previous-session-cannot-reuse-lost-car-scope',denied.status===403&&!resultRow(denied,second),diag(denied));
  } finally {fs.writeFileSync(users,original);}
  check('authority-previews-and-refusals-preserve-public-and-private-bytes',unchanged(before)&&sha(read(users))===sha(original));
};
