'use strict';
module.exports=async function ({fs,path,cp,crypto,assert,out,lab,at,data,save,env,php,a,beforePublic,inputs,frozen,editorial,cutover,configured,reproduce}) {
  const net=require('node:net');
  const sha=x=>a.sha(x), json=f=>JSON.parse(fs.readFileSync(f)), text=f=>fs.readFileSync(f,'utf8');
  const put=(f,x)=>{fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,JSON.stringify(x,null,2)+'\n');};
  const ordered=x=>Array.isArray(x)?x.map(ordered):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,ordered(x[k])])):x;
  const canonical=x=>JSON.stringify(ordered(x));
  const slug='synthetic-auto-car', detail='cars/'+slug+'.html', photoRoot='assets/img/cars/'+slug;
  const neighbor='cars/synthetic-foreign.html';
  const results=[], seriesBinding=crypto.randomBytes(16).toString('hex');
  function check(id,passed,detail={}){
    results.push({id,passed:!!passed,detail});
    if(!passed)throw Error(id+': '+JSON.stringify(detail));
  }
  const image=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl6XQAAAABJRU5ErkJggg==','base64');
  const listingPages=['conditions','faq','contacts','arenda-avto-v-yalte','arenda-avto-v-krymu','arenda-avto-bez-voditelya','arenda-avto-s-voditelem',
    'arenda-krossovera','arenda-avto-7-mest','podacha-avtomobilya'];
  const site={baseUrl:'https://base-rent.ru',name:'Synthetic Rent RK',phone:'+70000000000',telegram:'https://t.me/synthetic',address:'Synthetic address',
    extraSitemapPaths:[...listingPages.map(x=>'/pages/'+x+'.html'),'/routes/','/routes/synthetic-route.html'],
    callback:{enabled:false,delaySeconds:60,repeatPolicy:'daily',texts:{title:'Synthetic',text:'Synthetic',button_text:'Send',success_text:'Saved'}}};
  let staticPublication={siteDecisionId:'synthetic-site',pages:Object.fromEntries(listingPages.map(x=>['/pages/'+x+'.html',
    {title:'Synthetic '+x,heading:'Synthetic '+x,description:'Approved synthetic',sections:[{heading:'Approved',text:'Synthetic content'}],
     faq:x==='faq'?[{question:'Synthetic?',answer:'Yes.'}]:[]}]))};
  const key=crypto.generateKeyPairSync('ed25519'), pub=key.publicKey.export({format:'der',type:'spki'}).subarray(-32);
  const secret=Buffer.concat([key.privateKey.export({format:'der',type:'pkcs8'}).subarray(-32),pub]);
  let routes=null, edition=null;
  if(editorial){
    routes=fs.readFileSync(at('tools/reliability-public-routes.json'));
    const bytes=text(at('admin/includes/apriori-editorial-v2-content.php')).match(/<<<'EDITORIAL_JSON'\r?\n([^\r\n]+)/)[1];
    edition=JSON.parse(bytes);
    assert.equal(sha(bytes),'334b3cbe1c999cf429c91776f91ea3a744b779fee0041022cd781852a427e3ac');
    Object.assign(site,{name:edition.brand,phone:edition.contacts.phone.replace(/[^+0-9]/g,''),telegram:'https://t.me/'+edition.contacts.telegram.replace(/^@/,''),
      address:edition.contacts.address,extraSitemapPaths:edition.items.filter(x=>!['index.html','cars/index.html'].includes(x.path))
        .map(x=>x.path==='routes/index.html'?'/routes/':'/'+x.path)});
    staticPublication={siteDecisionId:'synthetic-site',editorialEdition:'editorial-20261108-v2',
      editorialSourceSha256:'b4b0d98607b1b6db099c1792a9563afa5fb15921a7d39dafef0a520cfddd6bb5'};
  }
  const config={issuer:'synthetic-owner',keyId:'synthetic-key',publicKeyBase64:pub.toString('base64'),secretKeyBase64:secret.toString('base64'),
    site,siteDecisionId:'synthetic-site',staticPublication,signatureLifetimeSeconds:3600,
    inventory:{decisionId:'synthetic-inventory',siteDigest:sha(canonical(site)),staticPagesSha256:sha(canonical(staticPublication)),dependencies:{},publicFiles:{}}};
  secret.fill(0);
  const photos=['main.png','second.png','third.png'].map((name,i)=>({id:'p'+i,path:photoRoot+'/'+name,sort:i*10,isMain:i===0}));
  const car={slug,name:'Synthetic Approved Car',brand:'Synthetic',model:'Auto',year:2025,seats:5,price:4321,depositAmount:12345,
    class:'Sedan',drive:'front',bodyType:'sedan',fuelType:'petrol',equipment:[],active:true,adminStatus:'active',publicStatus:'published',
    isPublished:true,publishChannels:['rent_rk_public'],owner_type:'rent_rk',owner_scope_id:'rent_rk',image:photos[0].path,
    detailDescription:'APPROVED DESCRIPTION ONLY',photos};
  const users={users:[{login:'qa-dry-root',role:'admin',active:true,name:'Synthetic Root',permissions:[],lessorSlug:''},
    {login:'qa-rate-editor',role:'manager',active:true,name:'Synthetic Rates',permissions:['tariffs.view','tariffs.edit'],
      deniedPermissions:['cars.publish'],lessorSlug:''},
    {login:'qa-car-publisher',role:'manager',active:true,permissions:['cars.edit','cars.publish'],deniedPermissions:['settings.manage'],lessorSlug:''},
    {login:'qa-park-preview',role:'manager',active:true,permissions:['cars.edit','content.publish.single_page'],
      deniedPermissions:['cars.publish','settings.manage'],lessorSlug:'synthetic-preview-park'}]};
  const root='qa-dry-root', editor='qa-rate-editor';
  const urls=['https://base-rent.ru/partner/synthetic-partner/','https://rent-rk.ru/landing.php?slug=synthetic-demand'];
  let server, port, serverLog='';
  const urlsPreserved=()=>urls.every(u=>text(at('sitemap.xml')).includes(u));
  const queue=()=>json(data('php-publication-jobs'));
  const head=()=>queue().cars[slug];
  const job=()=>queue().jobs[head().job];
  const build=()=>json(data('build-state'));
  const approvals=()=>json(data('approved-public-car-snapshots'));
  const currentBytes=()=>sha(fs.readFileSync(at(detail)));
  const journal=at('tmp/default-data/.rental-transactions/journal.json');
  const bodyHash=r=>sha(Buffer.from(r.body));
  const configFile=path.join(lab.dir,'sandbox/synthetic-auto-trust.php');
  const writeConfig=c=>fs.writeFileSync(configFile,'<?php return json_decode(base64_decode('+
      JSON.stringify(Buffer.from(JSON.stringify(c)).toString('base64'))+'),true,512,JSON_THROW_ON_ERROR);');
  const fixtures=()=>{
    fs.mkdirSync(at(photoRoot),{recursive:true});
    for(const p of photos)fs.writeFileSync(at(p.path),image);
    fs.writeFileSync(at(neighbor),'FOREIGN SYNTHETIC PAGE');
    for(const p of ['index.html','cars/index.html','sitemap.xml'])fs.unlinkSync(at(p));
    const now=new Date();const date=new Date(now.getTime()+86400000).toISOString().slice(0,10);
    if(routes)fs.writeFileSync(at('data/routes.json'),routes);
    else put(at('data/routes.json'),[{slug:'synthetic-route',title:'Synthetic route',summary:'Summary',description:'Description',type:'ring',
      duration:'one hour',car:'any',audience:['all']}]);
    for(const [n,v] of Object.entries({'current-cars':[car],rates:{cars:{[slug]:{manual:4321,base:4321,depositAmount:12345}}},
      'car-page-content':{version:1,items:{}},'admin-users':users,partners:{items:[{slug:'synthetic-partner',name:'Synthetic Partner',active:true}]},
      lessors:{items:[{slug:'synthetic-preview-park',name:'Preview Park',active:true,visible_in_rent_rk_showcase:true},
        {slug:'synthetic-other-park',name:'Other Park',active:true,visible_in_rent_rk_showcase:true}]},'landing-page-drafts':{items:[{id:'d-synthetic',scope_id:'rent_rk',slug:'synthetic-demand',
        publishStatus:'published_indexed',indexStatus:'in_sitemap'}]},'access-rules':{},settings:{},
      'callback-settings':{parks:{'synthetic-preview-park':{scope_id:'synthetic-preview-park',callback_mode:'disabled'}}},
      'audit-log':{items:[]},'build-state':{version:1,outputs:{},dirty:[],conflicts:[],runs:[]},
      requests:{items:[{id:'q-existing',carSlug:slug,name:'Existing synthetic request'}]},
      rentals:{nextNumber:2,items:[{id:'r-existing',number:1,carSlug:slug,carName:car.name,issueStatus:'planned',
        startDate:date,endDate:date,startTime:'10:00',endTime:'18:00'}]},
      payments:{items:[{id:'p-existing',rentalId:'r-existing',amount:100}]}}))put(data(n),v);
    for(const [k,f] of Object.entries({routes:at('data/routes.json'),partners:data('partners'),representatives:data('admin-users'),demand:data('landing-page-drafts')})){
      config.inventory.dependencies[k]=sha(fs.readFileSync(f));
    }
    assert(!fs.existsSync(configFile));writeConfig(config);
  };
  const call=async (p,opts={})=>{
    const r=await fetch('http://127.0.0.1:'+port+p,{redirect:'manual',signal:AbortSignal.timeout(20000),...opts});
    return {status:r.status,body:await r.text(),cookie:r.headers.getSetCookie().map(c=>c.split(';')[0]).join('; ')};
  };
  const sessions={};
  async function info(actor,carSlug=slug){
    const r=await call('/__qa_session?actor='+actor+'&car='+carSlug,{headers:sessions[actor]?{Cookie:sessions[actor]}:{}});
    assert.equal(r.status,200,r.body.slice(0,100));
    if(r.cookie)sessions[actor]=r.cookie;
    assert(sessions[actor]);
    return JSON.parse(r.body);
  }
  const post=(p,actor,fields)=>call(p,{method:'POST',headers:{Cookie:sessions[actor]},
    body:fields instanceof FormData?fields:new URLSearchParams(fields)});
  const cli=async (args,input='')=>new Promise((resolve,reject)=>{
    const c=cp.spawn(php,args,{cwd:lab.lab,env,windowsHide:true});
    let out='',err='';c.stdout.on('data',b=>out+=b);c.stderr.on('data',b=>err+=b);c.on('error',reject);
    const timer=setTimeout(()=>c.kill(),25000);
    c.stdin.on('error',()=>{});c.stdin.end(input);
    c.on('close',exit=>{clearTimeout(timer);let result=null;try{result=JSON.parse(out);}catch{}resolve({exit,result,stderr:err.slice(0,500)});});
  });
  const run=async crash=>cli(crash?['tools/automation-crash-worker.php',crash]:['tools/php-publication-automation-once.php']);
  const diag=(r)=>({http:r.status,bodySha256:bodyHash(r),bodyBytes:Buffer.byteLength(r.body)});
  const status=(r,s)=>r.result?.status===s;
  const optionPath='/admin/car-edit.php?id='+slug;
  const approvePath='/admin/public-car-approvals.php?slug='+slug;
  const carsPath='/admin/cars.php?id='+slug;
  async function saveRate(amount){
    const t=await info(editor);
    check('tariff-actor-not-publisher-'+results.length,!t.canPublish);
    return post('/admin/rates.php?scope_id=rent_rk',editor,{csrf_token:t.csrf,form_version:t.ratesVersion,
      ['rates['+slug+'][manual]']:String(amount),['rates['+slug+'][depositAmount]']:'14600'});
  }
  function optionsReceipt(){
    return Object.values(json(data('car-publication-plans')).items).at(-1);
  }
  async function newOption(){
    const t=await info(root);
    const r=await post(optionPath,root,{action:'guarded_publish_preflight',id:slug,csrf_token:t.csrf});
    const p=optionsReceipt();
    check('real-option-c-preview-'+results.length,r.status===200&&p?.state==='prepared',diag(r));
    return p;
  }
  async function applyOption(p,confirmed){
    const t=await info(root);
    return post(optionPath,root,{action:'guarded_publish_apply',id:slug,csrf_token:t.csrf,confirm_publication_plan:confirmed?'1':'0',
      publication_plan_id:p.id,publication_plan_digest:p.digest});
  }
  async function handoffs(){
    const r=await call(approvePath,{headers:{Cookie:sessions[root]}});
    return Object.fromEntries([...r.body.matchAll(/name="handoff\[([^\]]+)\]" value="([a-f0-9]{64})"/g)].map(x=>[x[1],x[2]]));
  }
  async function transfer(paths,tokens){
    const t=await info(root);
    return post(approvePath,root,{action:'handoff',slug,csrf_token:t.csrf,confirm_handoff:'1',
      ...Object.fromEntries(paths.map(p=>['handoff['+p+']',tokens[p]]))});
  }
  try{
    fixtures();
    port=await new Promise(resolve=>{const s=net.createServer();s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p));});});
    server=cp.spawn(php,['-S','127.0.0.1:'+port,'-t',lab.lab,at('tools/automation-router.php')],
      {cwd:lab.lab,env,windowsHide:true,stdio:['ignore','ignore','pipe']});
    server.stderr.on('data',b=>serverLog+=b);
    for(let i=0;i<50;i++){
      try{await call('/__ready');break;}catch{await new Promise(r=>setTimeout(r,100));}
    }
    const t=await info(root);
    check('loopback-php-guard',t.sapi==='cli-server'&&t.cache==='0'&&!t.fileCache&&t.noUrl&&(!cutover||!t.exec),
      {php:t.php,sapi:t.sapi,os:t.os,exec:t.exec});
    if(cutover) await require('./cutover.cjs').initial({cli,check});
    const a0=await post(approvePath,root,{action:'approve',slug,csrf_token:t.csrf,review_version:t.reviewVersion,confirm_publish:'1'});
    check('actual-approval-transaction-queues-without-worker',a0.status===200&&job().kind==='publish'&&job().status==='pending'
      &&!fs.existsSync(at(detail))&&a0.body.includes('Ожидает публикации'),diag(a0));
    const firstId=head().job;
    const stopped=await run('write.after_rename.sitemap.xml');
    check('worker-killed-at-native-public-commit',stopped.exit===73&&fs.existsSync(journal),stopped);
    const recovered=await run();
    check('queued-action-recovered-and-published-once',status(recovered,'PUBLISHED')&&head().job===firstId&&job().status==='published'
      &&job().attempts.length===1&&build().runs.length===1&&urlsPreserved()&&!fs.existsSync(journal),recovered);
    check('approved-car-content-published',text(at(detail)).includes('APPROVED DESCRIPTION ONLY')&&text(at(detail)).includes(photos[0].path));
    if(cutover){
      await require('./cutover.cjs').exercise({cli,check,diag,fs,at,data,sha,read:f=>fs.readFileSync(f),json,text,
        put,root,editor,info,post,call,approvePath,optionPath,carsPath,slug,detail,photos,urlsPreserved,job,head,queue,build,approvals,
        run,saveRate,newOption,applyOption,handoffs,transfer,journal,status,edition,neighbor,sessions,config,writeConfig,save,reproduce});
      for(const [f,b] of beforePublic)fs.writeFileSync(at(f),b);
      const preserve=a.verify(lab);save('preservation.json',preserve);
      check('cutover-code-only-preservation',preserve.canonicalUnchanged&&preserve.laboratorySourceUnchanged&&preserve.laboratoryArtifactsUnchanged);
      return;
    }
    const firstHash=currentBytes();
    const opt=await newOption();
    const refused=await applyOption(opt,false);
    check('manual-option-c-still-needs-explicit-confirmation',refused.status===409&&currentBytes()===firstHash,diag(refused));
    const done=await applyOption(opt,true);
    check('manual-option-c-applies-reviewed-bytes',done.status===200&&opt.immutable.outputs.every(o=>sha(fs.readFileSync(at(o.path)))===o.afterHash),diag(done));
    const tokens=await handoffs();
    check('handoff-offers-proven-paths-not-sitemap',Object.keys(tokens).length===3&&tokens[detail]&&!tokens['sitemap.xml'],{paths:Object.keys(tokens)});
    const original=fs.readFileSync(at(detail));fs.writeFileSync(at(detail),'CHANGED AFTER PREVIEW');
    const handoffConflict=await transfer([detail],tokens);
    check('handoff-stale-preview-rejected',handoffConflict.status===409&&text(at(detail))==='CHANGED AFTER PREVIEW',diag(handoffConflict));
    fs.writeFileSync(at(detail),original);
    const handoff=await transfer([detail],tokens);
    check('handoff-only-selected-page',handoff.status===200&&build().outputs[detail].generator==='approved-php-plan-apply-v1'
      &&build().outputs['index.html'].generator==='php-native-car-v1'&&currentBytes()===sha(original),diag(handoff));
    const changed=json(data('current-cars'));changed[0].detailDescription='UNAPPROVED NEIGHBORING DRAFT';
    put(data('current-cars'),changed);
    const r0=await saveRate(6000);
    check('real-rate-post-queued-without-publish-right',r0.status===302&&job().kind==='rates'&&job().status==='pending'
      &&currentBytes()===sha(original),diag(r0));
    const denied=await run();
    check('card-handoff-does-not-claim-shared-outputs',status(denied,'BLOCKED')&&denied.result.reason==='BLOCKED_PHP_APPLY_UNKNOWN_OWNERSHIP'
      &&currentBytes()===sha(original),denied);
    const more=await handoffs();
    const shared=await transfer(['index.html','cars/index.html'],more);
    check('explicit-shared-page-handoff',shared.status===200&&Object.keys(queue().handoffs).length===3,diag(shared));
    const r1=await saveRate(6200);
    check('new-authorized-rate-supersedes-blocked',r1.status===302&&job().status==='pending',diag(r1));
    const protectedBefore=Object.fromEntries(['rentals','payments','requests'].map(x=>[x,sha(fs.readFileSync(data(x)))]));
    const lost=await run('journal.committed');
    check('committed-publication-with-lost-response',lost.exit===73&&fs.existsSync(journal),lost);
    const next=await run();
    check('lost-response-replay-idle-no-second-effect',status(next,'IDLE')&&job().status==='published'&&job().attempts.length===1
      &&text(at(detail)).includes('APPROVED DESCRIPTION ONLY')&&!text(at(detail)).includes('UNAPPROVED NEIGHBORING DRAFT')
      &&text(at(detail)).includes('6 200')&&text(at(detail)).includes('14600'),next);
    const pending=await saveRate(6300), rateId=head().job;
    check('new-rate-saved',pending.status===302&&job().status==='pending',diag(pending));
    const userBytes=fs.readFileSync(data('admin-users')), changedUsers=JSON.parse(userBytes);
    changedUsers.users.find(x=>x.login===editor).active=false;put(data('admin-users'),changedUsers);
    const rateBefore=currentBytes(), noAuth=await run();
    check('revoked-actor-blocks-before-apply',status(noAuth,'BLOCKED')&&noAuth.result.reason==='BLOCKED_PHP_AUTOMATION_AUTHORITY'
      &&head().job===rateId&&currentBytes()===rateBefore,noAuth);
    fs.writeFileSync(data('admin-users'),userBytes);
    const photoBefore=photos.map(p=>sha(fs.readFileSync(at(p.path))));
    const ph=await info(root);
    const moved=await post(carsPath,root,{action:'car_photo_move',car_slug:slug,csrf_token:ph.csrf,photo_key:ph.photoKey,direction:'down'});
    check('native-photo-order-action-queues',moved.status===302&&job().kind==='photos'&&job().status==='pending',diag(moved));
    const race=await Promise.all([run(),run()]);
    check('parallel-workers-one-effect',race.filter(x=>status(x,'PUBLISHED')).length===1&&race.filter(x=>status(x,'IDLE')).length===1
      &&job().attempts.length===1,race);
    check('published-gallery-order-main-and-rate-preserved',text(at(detail)).indexOf(photos[2].path)<text(at(detail)).indexOf(photos[1].path)
      &&photos.every((p,i)=>sha(fs.readFileSync(at(p.path)))===photoBefore[i])&&text(at(detail)).includes('6 200'));
    const ul=await info(root), form=new FormData();
    for(const [k,v] of Object.entries({action:'car_main_photo_upload',car_slug:slug,csrf_token:ul.csrf}))form.set(k,v);
    form.set('main_photo',new Blob([image],{type:'image/png'}),'synthetic.png');
    const galleryJob=head().job, uploaded=await post(carsPath,root,form);
    const draft=json(data('current-cars'))[0];
    check('real-new-photo-not-published-old-bytes-preserved',uploaded.status===302&&draft.image!==photos[0].path
      &&fs.existsSync(at(draft.image))&&head().job===galleryJob&&!text(at(detail)).includes(draft.image)
      &&photos.every((p,i)=>sha(fs.readFileSync(at(p.path)))===photoBefore[i]),diag(uploaded));
    const oldJob=await saveRate(6400);
    check('older-rate-queued-before-hide',oldJob.status===302&&job().kind==='rates',diag(oldJob));
    const staleId=head().job;
    const withdraw=await info(root);
    const hidden=await post(carsPath,root,{action:'publication_fields',car_slug:slug,csrf_token:withdraw.csrf,
      expected_version:withdraw.carVersion,admin_status:'active',public_status:'hidden',publish_blocked_reason:'INTERNAL REASON'});
    check('actual-hide-pending-separate-from-old-public-bytes',hidden.status===302&&head().withdrawn&&job().kind==='hide'
      &&job().status==='pending'&&queue().jobs[staleId].status==='superseded'&&text(at(detail)).includes('APPROVED DESCRIPTION ONLY'),diag(hidden));
    const request=await call('/api/request.php',{method:'POST',headers:{Referer:'http://127.0.0.1:'+port+'/'+detail},
      body:new URLSearchParams({car_slug:slug,phone:'+79780000001',consent:'1',command_id:crypto.randomBytes(16).toString('hex')})});
    check('stale-tab-direct-request-blocked-while-worker-stopped',request.status===409&&JSON.parse(request.body).ok===false,diag(request));
    const ri=await info(root);
    const issue=await post('/admin/rental-issue.php?id=r-existing',root,{action:'issue_complete',id:'r-existing',
      expected_version:ri.rentVersion,csrf_token:ri.csrf});
    check('actual-issue-post-denied-before-worker',issue.body.includes('Автомобиль сейчас недоступен')
      &&sha(fs.readFileSync(data('rentals')))===protectedBefore.rentals,diag(issue));
    fs.unlinkSync(at(photos[0].path));
    const w=await run();
    check('withdrawal-with-missing-old-photo',status(w,'PUBLISHED')&&job().status==='published'&&head().withdrawn
      &&urlsPreserved()&&!text(at('sitemap.xml')).includes('/'+detail)
      &&!text(at('index.html')).includes('Synthetic Approved Car')&&!text(at('cars/index.html')).includes('Synthetic Approved Car'),w);
    const neutral=await call('/'+detail), unknown=await call('/cars/unknown-fixture.html');
    check('neutral-direct-url-and-no-arbitrary-route',neutral.status===200&&neutral.body.includes('Автомобиль сейчас недоступен')
      &&neutral.body.includes('href="/cars/"')&&!neutral.body.includes('<form')&&!neutral.body.includes('INTERNAL REASON')
      &&!neutral.body.includes('6 200')&&unknown.status===404,{neutral:diag(neutral),unknown:diag(unknown)});
    check('preserved-neighbors-and-business-records',text(at(neighbor))==='FOREIGN SYNTHETIC PAGE'
      &&Object.entries(protectedBefore).every(([n,h])=>sha(fs.readFileSync(data(n)))===h));
    const after=await run();
    check('older-job-cannot-restore-withdrawn-page',status(after,'IDLE')&&queue().jobs[staleId].status==='superseded'
      &&text(at(detail)).includes('Автомобиль сейчас недоступен'),after);
    const re=await info(root);
    const requested=await post(carsPath,root,{action:'publication_fields',car_slug:slug,csrf_token:re.csrf,
      expected_version:re.carVersion,admin_status:'active',public_status:'published'});
    const unavailable=await run();
    check('republication-does-not-substitute-missing-approved-photo',requested.status===302&&status(unavailable,'BLOCKED')
      &&head().withdrawn&&text(at(detail)).includes('Автомобиль сейчас недоступен'),unavailable);
    const rv=await info(root);
    const revoked=await post(approvePath,root,{action:'revoke',slug,csrf_token:rv.csrf,review_version:rv.revokeVersion,reason:'SYNTHETIC'});
    const rvRun=await run();
    check('approval-revoke-through-http-preserves-business-and-page-history',revoked.status===200&&status(rvRun,'PUBLISHED')
      &&head().withdrawn&&job().kind==='revoke'&&approvals().active[slug].state==='revoked'
      &&Object.entries(protectedBefore).every(([n,h])=>sha(fs.readFileSync(data(n)))===h),{response:diag(revoked),worker:rvRun});
    const fleet=['synthetic-auto-second','synthetic-auto-third'];
    for(const key of fleet){
      const gallery=photos.map(p=>({...p,path:p.path.replace(slug,key)}));
      fs.mkdirSync(at('assets/img/cars/'+key),{recursive:true});
      for(const p of gallery)fs.writeFileSync(at(p.path),image);
      put(data('current-cars'),[...json(data('current-cars')),{...car,slug:key,name:key,image:gallery[0].path,photos:gallery}]);
      const s=await info(root,key);
      const r=await post('/admin/public-car-approvals.php?slug='+key,root,
        {action:'approve',slug:key,csrf_token:s.csrf,review_version:s.reviewVersion,confirm_publish:'1'});
      check('parallel-pending-approval-'+key,r.status===200&&queue().cars[key]&&!fs.existsSync(at('cars/'+key+'.html')),diag(r));
    }
    const carUrl=key=>text(at('sitemap.xml')).includes('/cars/'+key+'.html');
    const firstPub=await run();
    check('first-publish-does-not-publish-unprocessed-neighbor',status(firstPub,'PUBLISHED')&&carUrl(fleet[0])&&!carUrl(fleet[1]),firstPub);
    const secondPub=await run();
    check('second-publish-keeps-first',status(secondPub,'PUBLISHED')&&fleet.every(carUrl)&&urlsPreserved(),secondPub);
    for(const [i,key] of fleet.entries()){
      const s=await info(root,key);
      const r=await post('/admin/cars.php?id='+key,root,{action:i===0?'archive_car':'delete_car',car_slug:key,csrf_token:s.csrf});
      check('separate-real-withdraw-actions-'+key,r.status===302&&queue().cars[key].withdrawn,diag(r));
    }
    const firstWd=await run();
    check('first-withdraw-does-not-remove-second-url',status(firstWd,'PUBLISHED')&&!carUrl(fleet[0])&&carUrl(fleet[1]),firstWd);
    const secondWd=await run(), permanent=await call('/cars/'+fleet[1]+'.html');
    check('second-withdraw-permanent-neutral-not-redirect',status(secondWd,'PUBLISHED')&&fleet.every(x=>!carUrl(x))&&urlsPreserved()
      &&permanent.status===200&&permanent.body.includes('Автомобиль больше не представлен в прокате'),{worker:secondWd,http:diag(permanent)});
    save('application-evidence.json',{seriesBinding,approvalObjectsPreserved:Object.keys(approvals().objects),
      queue:queue(),build:build(),sitemap:approvals().sitemapContinuity.map(x=>x.payload),protectedBefore,
      finalOutputSha256:currentBytes()});
    for(const [f,b] of beforePublic)fs.writeFileSync(at(f),b);
    const preserve=a.verify(lab);
    save('preservation.json',{...preserve,baselinePublicBytesRestored:[...beforePublic].every(([p,b])=>fs.readFileSync(at(p)).equals(b))});
    check('code-only-preservation',preserve.canonicalUnchanged&&preserve.laboratorySourceUnchanged&&preserve.laboratoryArtifactsUnchanged);
  }catch(e){
    process.exitCode=1;
    save('failure.json',{message:e.message,phpServerErrorLines:serverLog.split('\n').filter(l=>/Fatal error|Parse error|Uncaught/.test(l)).slice(-6)});
  }finally{
    if(server&&server.exitCode===null){
      const stopped=new Promise(resolve=>server.once('exit',resolve));
      server.kill();await stopped;
    }
    save('primary.json',{status:process.exitCode?'FAIL':reproduce?'REPRODUCED':'PASS_COMPONENT_ONLY',sourceSha256:lab.baseline.sourceSha256,
      laboratoryId:lab.baseline.laboratoryId,seriesBinding,frozen,editorial,configured,platform:process.platform,
      loopbackStopped:server?.exitCode!==null||server?.signalCode!==null,results});
    console.log(JSON.stringify({status:process.exitCode?'FAIL':reproduce?'REPRODUCED':'PASS_COMPONENT_ONLY',checks:results.length,last:results.at(-1)}));
  }
};
