'use strict';
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),os=require('node:os');
const assert=require('node:assert/strict');
const stage=fs.realpathSync(process.argv[2]), owner=path.dirname(stage), series=process.argv[3];
assert(/^series-[0-9]+$/.test(series));
const out=path.join(__dirname,series);
const temp=fs.realpathSync(path.join(process.env.LOCALAPPDATA,'Temp'));
assert.equal(path.dirname(owner),temp);
assert.equal(fs.realpathSync(os.tmpdir()),temp);
assert.match(path.basename(owner),/^rent-rk-b24-code-only-[a-z0-9_]+$/);
assert(!fs.existsSync(path.join(owner,'private')));
assert.deepEqual(fs.readdirSync(path.join(stage,'private/rent-rk-data')),['project-progress-map.json']);
assert.deepEqual(fs.readdirSync(path.join(stage,'data')),[]);
const env=Object.fromEntries(Object.entries(process.env).filter(([k])=>
  /^(systemroot|windir|systemdrive|comspec|localappdata|appdata|userprofile|pathext)$/i.test(k)));
env.TMP=temp;env.TEMP=temp;
env.RENT_RK_QA_PHP='D:/OSPanel/modules/PHP-8.4/php.exe';
env.PATH=[path.join(process.env.SystemRoot,'System32'),path.dirname(env.RENT_RK_QA_PHP)].join(path.delimiter);
const a=require(path.join(stage,'tools/business-data-audit.cjs'));
const freeze=require('./verify-freeze.cjs');
const frozen=freeze(stage,out);
const original=JSON.parse(fs.readFileSync(path.join(out,'primary.json')));
assert.equal(original.status,'PASS_COMPONENT_ONLY');
assert.equal(a.qaSourceIdentity().sourceHashesSha256,original.sourceSha256);
const base=path.join(stage,'artifacts/sitemap-writers-plan-continuity-20261108');
fs.mkdirSync(base,{recursive:true});
const c=cp.spawn(process.execPath,[path.join(stage,'tools/sitemap-writers-continuity-qa.cjs'),'php-apply-regression'],
  {cwd:stage,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
let stdout='',stderr='';
c.stdout.on('data',x=>stdout+=x); c.stderr.on('data',x=>stderr+=x);
c.on('close',(exit,signal)=>{
  const evidence=path.join(base,'php-apply-regression');
  for(const name of ['primary.json','laboratory.json','inputs.json','source-binding.json']){
    const p=path.join(evidence,name);
    if(fs.existsSync(p))fs.copyFileSync(p,path.join(out,'regression-'+name),fs.constants.COPYFILE_EXCL);
  }
  const result=JSON.parse(fs.readFileSync(path.join(out,'regression-primary.json')));
  assert.equal(result.sourceSha256,original.sourceSha256);
  a.save(path.join(out,'regression-execution.json'),{exit,signal,stdout,stderr,
    checks:result.results.length,passed:result.results.filter(x=>x.passed).length,sourceSha256:result.sourceSha256,
    independentlyExecuted:true,status:result.status});
  a.save(path.join(out,'freeze-after-regression.json'),{before:frozen,after:freeze(stage,out)});
  console.log(JSON.stringify({exit,status:result.status,checks:result.results.length,last:result.results.at(-1)?.test}));
  if(exit!==0||result.status!=='PASS_COMPONENT_ONLY')process.exitCode=1;
});
