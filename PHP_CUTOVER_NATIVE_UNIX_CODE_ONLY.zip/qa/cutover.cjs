'use strict';
const cliMode=(cli,state,generation)=>cli(['tools/php-publication-mode.php',state,String(generation)]);
const legacy=cli=>cli(['tools/cutover-probe.php','legacy']);
const bridge=(cli,action)=>cli(['tools/build-site-transaction.php',action],'{}');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
exports.initial=async ({cli,check})=>{
  const original=await legacy(cli);
  check('full-car-legacy-helpers-refuse-before-powerShell-discovery',
    original.exit===0&&!original.result.exec&&!original.result.boolean&&original.result.available.reason==='php_preview'
    &&['full','car'].every(x=>!original.result[x].success&&original.result[x].skipped&&original.result[x].reason==='php_confirmation_required'),original);
  const before=await cli(['tools/php-publication-automation-once.php']);
  check('selected-with-no-latch-starts-paused',before.exit===0&&before.result.status==='PAUSED',before);
  const started=await cliMode(cli,'running',0);
  check('activate-empty-queue-with-expected-generation',started.exit===0&&started.result.generation===1&&started.result.state==='running',started);
  const stale=await cliMode(cli,'paused',0);
  check('stale-mode-change-is-refused',stale.exit!==0&&stale.stderr.includes('BLOCKED_PHP_CUTOVER_GENERATION'),stale);
  const failed=await cli(['-d','disable_functions=exec,sodium_crypto_sign_detached','tools/cutover-probe.php','legacy']);
  check('missing-php-signing-capability-has-no-fallback',failed.exit===0&&!failed.result.available.available
    &&failed.result.available.message==='BLOCKED_PHP_CUTOVER_CAPABILITY'&&!failed.result.full.success,failed);
};

exports.exercise=async ({cli,check,diag,fs,at,data,sha,read,json,text,put,root,editor,info,post,call,approvePath,optionPath,carsPath,
  slug,detail,photos,urlsPreserved,job,head,queue,build,approvals,run,saveRate,newOption,applyOption,handoffs,transfer,journal,status,edition,neighbor,sessions,save,reproduce})=>{
  const protectedPaths=[data('php-publication-jobs'),data('build-state'),data('approved-public-car-snapshots'),data('audit-log'),
    ...['rates','current-cars','requests','rentals','payments','callback-settings','php-publication-mode'].map(data),
    at(detail),at('index.html'),at('cars/index.html'),at('sitemap.xml'),at(neighbor),...photos.map(p=>at(p.path))];
  const hashes=()=>Object.fromEntries(protectedPaths.map(p=>[p,sha(read(p))]));
  const same=before=>Object.entries(before).every(([p,h])=>sha(read(p))===h);
  const actor=await info(root), csrf=actor.csrf;
  const settingStatus=await call('/admin/access-rules.php?saved=1&rebuilt=0',{headers:{Cookie:sessions[root]}});
  check('implicit-settings-rebuild-not-reported-as-published-or-manual-powershell',settingStatus.status===200
    &&settingStatus.body.includes('Публичные файлы не обновлены')&&!settingStatus.body.includes('Запустите tools/build-site.ps1'),diag(settingStatus));
  const approval=(action,fields={},who=root,token=csrf)=>post(approvePath,who,{action,slug,csrf_token:token,...fields});
  const plan=mode=>approval('plan',{plan_mode:mode});
  const preview=mode=>approval('prepare_cutover',{plan_mode:mode});
  const token=r=>r.body.match(/name="preview_id" value="([0-9a-f]{32})"/)?.[1];
  const apply=(id,yes=true)=>approval('apply_cutover',{preview_id:id,confirm_publish:yes?'1':'0'});
  const dry=(who=root,csrfToken=csrf)=>post(optionPath,who,{action:'publish_dry_run',csrf_token:csrfToken,id:slug});
  const second='synthetic-auto-second', secondPath='cars/'+second+'.html';
  const original=json(data('current-cars'))[0];
  const gallery=photos.map(p=>({...p,path:p.path.replace(slug,second)}));
  for(const [i,p] of gallery.entries()){
    fs.mkdirSync(at('assets/img/cars/'+second),{recursive:true});
    fs.copyFileSync(at(photos[i].path),at(p.path));
  }
  put(data('current-cars'),[original,{...original,slug:second,name:'Second approved car',image:gallery[0].path,photos:gallery,
    owner_type:'lessor',owner_scope_id:'synthetic-preview-park',lessorSlug:'synthetic-preview-park',lessor_slug:'synthetic-preview-park',
    detailDescription:'NEIGHBOR APPROVED MATERIAL'}]);
  const sec=await info(root,second);
  const newApproval=await post('/admin/public-car-approvals.php?slug='+second,root,
    {action:'approve',slug:second,csrf_token:sec.csrf,review_version:sec.reviewVersion,confirm_publish:'1'});
  const neighborRun=await run();
  check('second-individually-approved-before-full',newApproval.status===200&&status(neighborRun,'PUBLISHED')
    &&text(at(secondPath)).includes('NEIGHBOR APPROVED MATERIAL'),neighborRun);
  protectedPaths.push(at(secondPath),...gallery.map(p=>at(p.path)));
  const option=await newOption(), exactBefore=sha(read(at(detail)));
  const unconfirmed=await applyOption(option,false), optionApplied=await applyOption(option,true);
  check('manual-option-c-stays-exact-in-selected-php-mode',unconfirmed.status===409&&optionApplied.status===200
    &&option.immutable.outputs.every(o=>sha(read(at(o.path)))===o.afterHash)&&!!exactBefore,{unconfirmed:diag(unconfirmed),applied:diag(optionApplied)});
  const owned=await handoffs();
  const transferApplied=await transfer(Object.keys(owned),owned);
  check('explicit-handoff-before-targets-return-to-automatic-owner',Object.keys(owned).length===3&&transferApplied.status===200,diag(transferApplied));
  const draft=json(data('current-cars'));draft[0].detailDescription='CUTOVER UNAPPROVED DRAFT';put(data('current-cars'),draft);
  draft[1].detailDescription='NEIGHBOR UNAPPROVED DRAFT';put(data('current-cars'),draft);
  const synced=await plan('Car');
  check('ordinary-plan-sync-separate-from-dry-run',synced.status===200&&synced.body.includes('PLAN_ONLY'),diag(synced));
  await require('./authority.cjs')({cli,check,diag,fs,at,data,sha,read,json,put,info,post,slug,second,root,editor,reproduce,save,
    invariant:hashes,unchanged:same,rootApproval:sec});
  if(reproduce)return;
  const all=hashes(), dryHttp=await dry(), dryCli=await cli(['tools/cutover-probe.php','dry']);
  const viewer=await info(editor), denied=await dry(editor,viewer.csrf);
  check('real-car-dry-run-http-200-and-403-and-cli-no-writes',dryHttp.status===200&&dryHttp.body.includes('Предварительная проверка PHP')
    &&dryHttp.body.includes(detail)&&denied.status===403&&dryCli.result.status==='PLAN_ONLY'&&dryCli.result.canApply===false
    &&dryCli.result.parsed.items.some(x=>x.path===detail)&&same(all),{http:diag(dryHttp),denied:diag(denied),cli:dryCli});
  const oldBuild=read(data('build-state')), legacyState=build();
  legacyState.outputs[detail].generator='tools/build-site.ps1';
  put(data('build-state'),legacyState);
  const legacyOwnership=await preview('Car');
  check('matching-legacy-hash-does-not-transfer-ownership',legacyOwnership.status===409&&legacyOwnership.body.includes('BLOCKED_PHP_APPLY_UNKNOWN_OWNERSHIP'),diag(legacyOwnership));
  fs.writeFileSync(data('build-state'),oldBuild);
  const full=await preview('Full'), fullId=token(full);
  check('full-http-preview-has-30-editorial-outputs-robots-sitemap-and-card',full.status===200&&fullId
    &&edition.items.length===30&&edition.items.every(x=>full.body.includes(x.path))
    &&full.body.includes('robots.txt')&&full.body.includes('sitemap.xml')&&full.body.includes(detail)&&same(all),diag(full));
  const no=await apply(fullId,false);
  check('full-no-confirmation-not-written',no.status===403&&same(all),diag(no));
  const fullRun=await apply(fullId), fullReceipt=build().lastRun;
  check('full-confirmed-exact-php-output-set',fullRun.status===200&&fullRun.body.includes('Точный PHP-план применён')
    &&fullReceipt.mode==='Full'&&edition.items.every(x=>fullReceipt.outputs.includes(x.path)&&fs.existsSync(at(x.path)))
    &&['robots.txt','sitemap.xml',detail].every(p=>fullReceipt.outputs.includes(p)&&fs.existsSync(at(p)))
    &&!text(at(detail)).includes('CUTOVER UNAPPROVED DRAFT')&&urlsPreserved()&&text(at(neighbor))==='FOREIGN SYNTHETIC PAGE'
    &&fullReceipt.outputs.includes(secondPath)&&text(at(secondPath)).includes('NEIGHBOR APPROVED MATERIAL')
    &&!text(at(secondPath)).includes('NEIGHBOR UNAPPROVED DRAFT')
    &&photos.every(p=>sha(read(at(p.path)))===all[at(p.path)]),{response:diag(fullRun),receipt:fullReceipt});
  const rep=await apply(fullId);
  check('full-confirmation-replay-not-a-second-write',rep.status===200&&rep.body.includes('Повторной записи нет')
    &&build().lastRun.id===fullReceipt.id,diag(rep));
  const car=await preview('Car'), carId=token(car);
  check('confirmed-car-preview-ticket',car.status===200&&carId,diag(car));
  const secondBefore=sha(read(at(secondPath)));
  const carRun=await apply(carId), carReceipt=build().lastRun;
  check('confirmed-car-uses-native-plan-not-full-or-powershell',carRun.status===200&&carReceipt.mode==='Car'
    &&carReceipt.outputs.includes(detail)&&!carReceipt.outputs.includes('robots.txt')&&!carReceipt.outputs.includes(secondPath)
    &&sha(read(at(secondPath)))===secondBefore&&carReceipt.id!==fullReceipt.id,diag(carRun));
  const targetPreview=await preview('Car'), targetId=token(targetPreview), baseline=read(at(detail));
  fs.writeFileSync(at(detail),'Synthetic foreign edit after preview');
  const targetBlocked=await apply(targetId);
  check('foreign-target-change-after-preview-not-overwritten',!!targetId&&targetBlocked.status===409
    &&text(at(detail))==='Synthetic foreign edit after preview'&&build().lastRun.id===carReceipt.id,diag(targetBlocked));
  fs.writeFileSync(at(detail),baseline);
  const viewed=await preview('Car');
  const validId=token(viewed);
  check('generation-fixture-ticket',!!validId,diag(viewed));
  const paused=await cliMode(cli,'paused',1);
  const hold=await apply(validId);
  check('paused-refuses-previously-prepared-ticket',paused.result.state==='paused'&&hold.status===409
    &&hold.body.includes('BLOCKED_PHP_CUTOVER_PAUSED'),diag(hold));
  const pending=await saveRate(7200), queued=head().job, queuedBytes=hashes(), silent=await run();
  const unstarted=await preview('Full');
  check('pause-preserves-queue-and-public-state',pending.status===302&&status(silent,'PAUSED')&&job().status==='pending'
    &&same(queuedBytes)&&unstarted.status===409, {worker:silent,preview:diag(unstarted)});
  const resumed=await cliMode(cli,'running',2);
  const staleTicket=await apply(validId), pendingFull=await preview('Full');
  check('resume-does-not-refresh-old-ticket-or-overtake-pending-action',resumed.result.generation===3&&staleTicket.status===409
    &&staleTicket.body.includes('BLOCKED_PHP_CUTOVER_GENERATION')
    &&pendingFull.status===409&&pendingFull.body.includes('BLOCKED_PHP_CUTOVER_PENDING_ACTIONS')&&head().job===queued,
    {stale:diag(staleTicket),pending:diag(pendingFull)});
  const worker=cli(['tools/cutover-probe.php','hold-worker']);
  const flag=data('qa-worker-at-commit').replace(/\.json$/,'');
  for(let i=0;i<150&&!fs.existsSync(flag);i++)await delay(25);
  check('worker-holds-prepared-transaction-before-concurrent-stop',fs.existsSync(flag)&&fs.existsSync(journal));
  let stopDone=false, bridgeDone=false;
  const stopping=cliMode(cli,'paused',3).finally(()=>stopDone=true);
  const oldWriter=bridge(cli,'commit').finally(()=>bridgeDone=true);
  await delay(150);
  const waiting=!stopDone&&!bridgeDone;
  fs.writeFileSync(data('qa-release-worker').replace(/\.json$/,''),'release');
  const [completed,stopped,refused]=await Promise.all([worker,stopping,oldWriter]);
  check('stop-drains-active-worker-and-blocks-concurrent-old-writer',waiting&&status(completed,'PUBLISHED')&&stopped.result.generation===4
    &&refused.exit!==0&&JSON.stringify(refused).includes('BLOCKED_LEGACY_PHP_CUTOVER')&&head().job===queued&&job().status==='published',
    {completed,stopped,refused});
  const oldPrepare=await bridge(cli,'prepare'), unsafeReturn=await cliMode(cli,'legacy',4);
  check('direct-legacy-prepare-and-unsafe-return-refused',oldPrepare.exit!==0&&JSON.stringify(oldPrepare).includes('BLOCKED_LEGACY_PHP_CUTOVER')
    &&unsafeReturn.exit!==0&&JSON.stringify(unsafeReturn).includes('BLOCKED_PHP_CUTOVER_CONTROL'),{oldPrepare,unsafeReturn});
  const re=await cliMode(cli,'running',4);
  const next=await saveRate(7300), crash=await run('write.after_rename.sitemap.xml');
  check('prepared-journal-fixture',re.result.generation===5&&next.status===302&&crash.exit===73&&fs.existsSync(journal),crash);
  const journalHash=sha(read(journal)), torn=hashes();
  const noRecovery=await dry();
  check('car-dry-run-refuses-unfinished-recovery-without-writing',noRecovery.status===409&&noRecovery.body.includes('BLOCKED_PHP_PREVIEW_RECOVERY_REQUIRED')&&fs.existsSync(journal)
    &&sha(read(journal))===journalHash&&same(torn),diag(noRecovery));
  const pausedRecovery=await cliMode(cli,'paused',5);
  const pauseOnce=await run();
  check('stop-recovers-prepared-journal-keeps-job-and-old-confirmed-pages',pausedRecovery.result.generation===6
    &&status(pauseOnce,'PAUSED')&&!fs.existsSync(journal)&&job().status==='pending'&&text(at(detail)).includes('7 200'),{pausedRecovery,pauseOnce});
  const rr=await cliMode(cli,'running',6), lost=await run('journal.committed'), keep=await cliMode(cli,'paused',7);
  check('stop-reconciles-lost-response-without-republishing',rr.result.generation===7&&lost.exit===73&&keep.result.generation===8
    &&job().status==='published'&&job().attempts.length===1&&text(at(detail)).includes('7 300')&&!fs.existsSync(journal),{lost,keep});
  const hideInfo=await info(root);
  const hide=await post(carsPath,root,{action:'publication_fields',car_slug:slug,csrf_token:hideInfo.csrf,
    expected_version:hideInfo.carVersion,admin_status:'active',public_status:'hidden'});
  const deniedRequest=await call('/api/request.php',{method:'POST',headers:{Referer:'http://127.0.0.1/'+detail},
    body:new URLSearchParams({car_slug:slug,phone:'+79780000001',consent:'1',command_id:'a'.repeat(32)})});
  const issue=await post('/admin/rental-issue.php?id=r-existing',root,{action:'issue_complete',id:'r-existing',
    expected_version:hideInfo.rentVersion,csrf_token:hideInfo.csrf});
  check('withdrawal-prohibitions-persist-while-paused',hide.status===302&&head().withdrawn&&job().status==='pending'&&deniedRequest.status===409
    &&issue.body.includes('Автомобиль сейчас недоступен')&&text(at(detail)).includes('APPROVED DESCRIPTION ONLY'),
    {hide:diag(hide),request:diag(deniedRequest),issue:diag(issue)});
  const start=await cliMode(cli,'running',8), withdraw=await run(), idle=await run();
  check('resumed-worker-withdraws-once-keeps-neighbor-urls',start.result.generation===9&&status(withdraw,'PUBLISHED')
    &&status(idle,'IDLE')&&text(at(detail)).includes('Автомобиль сейчас недоступен')&&urlsPreserved(),{withdraw,idle});
  const lostOptIn=await cli(['-d','auto_prepend_file='+at('guard/prepend-no-opt-in.php'),'tools/cutover-probe.php','legacy']);
  check('lost-opt-in-does-not-reenable-legacy-or-lift-withdrawal',lostOptIn.exit===0&&lostOptIn.result.withdrawn
    &&!lostOptIn.result.full.success&&!lostOptIn.result.boolean&&!lostOptIn.result.available.available,lostOptIn);
  save('cutover-state-evidence.json',{fullReceipt,carReceipt,mode:json(data('php-publication-mode')),
    jobs:queue(),sitemap:approvals().sitemapContinuity.map(x=>x.payload)});
};
