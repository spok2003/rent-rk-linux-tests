$ErrorActionPreference = 'Stop'
$temp = (Get-Item -LiteralPath (Join-Path $env:LOCALAPPDATA 'Temp')).FullName
if ($temp -notmatch '^C:\\') { throw 'Expected normal C Temp' }
for ($p = Get-Item -LiteralPath $temp; $null -ne $p; $p = $p.Parent) {
    if ($p.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked Temp ancestry' }
}
$receipts = @($args | ForEach-Object {
    if ($_ -notmatch '^series-[0-9]+$') { throw 'Unexpected series' }
    "$_/lab-ownership.json"
})
if (-not $receipts.Count) { throw 'Explicit owned series required' }
$targets = foreach ($receipt in $receipts) {
    $meta = Get-Content -LiteralPath (Join-Path $PSScriptRoot $receipt) -Raw | ConvertFrom-Json
    $items = @(
        @{ p=$meta.stageOwner; pattern='^rent-rk-b24-code-only-[a-z0-9_]+$'; marker='code/tools/business-data-audit.cjs' },
        @{ p=$meta.laboratory; pattern='^rent-rk-audit-\d+-php-automation-[a-f0-9]{8}$'; marker='sandbox/app/.rent-rk-test-lab' }
    )
    $reg = Join-Path (Split-Path -Parent (Join-Path $PSScriptRoot $receipt)) 'regression-laboratory.json'
    if (Test-Path -LiteralPath $reg -PathType Leaf) {
        $rm = Get-Content -LiteralPath $reg -Raw | ConvertFrom-Json
        $items += @{p=$rm.dir;pattern='^rent-rk-audit-\d+-sitemap-continuity-[a-f0-9]{8}$';marker='sandbox/app/.rent-rk-test-lab'}
    }
    foreach ($entry in $items) {
        $i = Get-Item -LiteralPath $entry.p
        if ($i.Parent.FullName -ne $temp -or $i.Name -notmatch $entry.pattern -or
            ($i.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Unsafe owned target' }
        $queue=[Collections.Generic.Queue[string]]::new()
        $queue.Enqueue($i.FullName)
        [long]$bytes=0
        while ($queue.Count) {
            foreach ($child in Get-ChildItem -LiteralPath ($queue.Dequeue()) -Force) {
                if ($child.Name -ieq 'abcp' -or ($child.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
                    throw 'Excluded or linked object found; preservation required'
                }
                if ($child.PSIsContainer) { $queue.Enqueue($child.FullName) } else { $bytes+=$child.Length }
            }
        }
        if (-not (Test-Path -LiteralPath (Join-Path $i.FullName $entry.marker) -PathType Leaf)) {
            throw 'Missing ownership marker'
        }
        [pscustomobject]@{ name=$i.Name; path=$i.FullName; bytes=$bytes }
    }
}
$live = Get-CimInstance Win32_Process -Filter "Name='node.exe' OR Name='php.exe' OR Name='powershell.exe' OR Name='pwsh.exe'"
foreach ($target in $targets) {
    if (@($live | Where-Object { $_.CommandLine -and $_.CommandLine -like ('*'+$target.name+'*') }).Count) {
        throw 'Owned process still uses a target'
    }
}
foreach ($target in $targets) { Remove-Item -LiteralPath $target.path -Recurse }
$record = [ordered]@{
    status='REMOVED_TASK_OWNED_TEMP_ONLY'
    removed=@($targets | Select-Object name,bytes)
    remainingFreeCBytes=(Get-PSDrive C).Free
    workingStoresInspected=$false
}
$dest=Join-Path $PSScriptRoot ('cleanup-' + ($args -join '-') + '.json')
$file=[IO.File]::Open($dest,[IO.FileMode]::CreateNew)
try {
    $encodedRecord=[Text.UTF8Encoding]::new($false).GetBytes(($record | ConvertTo-Json -Depth 5))
    $file.Write($encodedRecord,0,$encodedRecord.Length)
} finally { $file.Dispose() }
