"""Prepare explicitly allowlisted PHP-plan synthetic lab inputs."""
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import zipfile
import sys

PACKAGE = Path(__file__).absolute().parent
ROOT = PACKAGE.parent.parent
assert len(sys.argv)==2 and re.fullmatch(r"series-[0-9]+",sys.argv[1])
OUT = PACKAGE / sys.argv[1] if len(sys.argv)>1 else PACKAGE
if OUT != PACKAGE:
    OUT.mkdir()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(relative):
    parts = relative.split("/")
    assert all(p and p not in (".", "..", "abcp") and ":" not in p for p in parts)
    path = ROOT
    for part in parts:
        path = path / part
        assert not getattr(path.lstat(), "st_file_attributes", 0) & 1024 and not path.is_symlink(), relative
    assert path.is_file()
    return path.read_bytes()


def save(relative, data):
    with (OUT / relative).open("x", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def main():
    assert ROOT.name == "rent-rk_new"
    for p in [ROOT, *ROOT.parents, OUT, OUT.parent]:
        assert not getattr(p.lstat(), "st_file_attributes", 0) & 1024 and not p.is_symlink()
    helpers = ["prepare.py", "run.cjs", "scenario.cjs", "cutover.cjs", "authority.cjs", "router.php", "regress.cjs",
               "cleanup.ps1", "crash-worker.php", "probe.php", "verify-freeze.cjs"]
    helper_hashes = {f: sha(read(str((PACKAGE/f).relative_to(ROOT)).replace("\\","/"))) for f in helpers}
    save("qa-before.json", helper_hashes)
    bootstrap = read("admin/includes/bootstrap.php").decode("utf-8")
    includes = re.findall(r"^require_once __DIR__ \. '/([a-z0-9-]+\.php)';", bootstrap, re.M)
    runtime = {"admin/car-edit.php", "admin/includes/bootstrap.php",
               *("admin/includes/"+f for f in includes), "tools/build-site-transaction.php",
               "tools/build-site.ps1", "tools/build-state.ps1", "tools/publish-public-data.ps1"}
    runtime.update({"landing.php", "partner/index.php", "admin/public-car-approvals.php", "admin/demand.php", "admin/rates.php", "admin/cars.php", "admin/access-rules.php", "admin/rental-issue.php", "api/request.php", "admin/includes/public-rate-limit.php", "tools/php-publication-automation-once.php", "tools/php-publication-mode.php",
        *("admin/includes/"+name for name in (
        "approved-public-car-snapshot.php", "approved-sitemap-continuity.php", "approved-php-plan-apply.php",
        "approved-public-dynamic-inventory.php", "approved-dynamic-inventory-automation.php", "php-public-renderer-core.php",
        "php-public-renderer-templates.php", "php-public-renderer-static.php", "apriori-editorial-v2.php",
        "apriori-editorial-v2-content.php"))})
    qa = {"tools/"+name for name in (
        "business-data-audit.cjs", "business-data-audit-prepend.php",
        "business-data-review-policy.json", "business-data-writer-review.cjs",
        "bootstrap-b24-legacy-qa.cjs", "bootstrap-b24-legacy-qa.php",
        "bootstrap-b24-dry-run-qa.cjs", "bootstrap-b24-dry-run-qa.php",
        "bootstrap-b24-build-qa.cjs", "bootstrap-b24-native-qa.php",
        "bootstrap-b24-transaction-qa.php", "project-progress-validate.php", "sitemap-writers-continuity-qa.cjs", "sitemap-writers-continuity-qa.php")}
    audit = read("tools/business-data-audit.cjs").decode("utf-8")
    required = audit.split("const laboratoryArtifactFiles = ",1)[1].split("const environmentDependencies",1)[0]
    artifacts = set(re.findall(r"^  path: '([^']+)',",required,re.M)) - {"index.html","sitemap.xml"} - runtime
    assert all(re.fullmatch(r"artifacts/bootstrap-[a-z0-9-]+-2026101[89]/[a-z0-9_./-]+|artifacts/finance-fixture-failure-fix-20261017/[a-z0-9_./-]+",f)
               for f in artifacts), sorted(artifacts)
    meta_block = required.split("const technicalMetadataFiles = ",1)[1]
    technical = set(re.findall(r"^  '([^']+)'",meta_block,re.M))
    assert technical == {"artifacts/test-lifecycle/TEST_REGISTRY.json","artifacts/test-lifecycle/CURRENT_SUMMARY.json",
        "private/rent-rk-data/project-progress-map.json","docs/PROJECT_STATE.md","docs/OPERATION_METHODS_LOG.md",
        "artifacts/retention-ledger/INDEX.json","artifacts/retention-ledger/CURRENT_SUMMARY.json",
        "artifacts/retention-registry-20260929/RETENTION_REGISTRY_DRAFT.json"}
    for prefix in ("artifacts/test-lifecycle/entries","artifacts/retention-ledger/entries"):
        folder=ROOT/prefix
        for p in [folder,folder.parent,folder.parent.parent]:
            assert not getattr(p.lstat(), "st_file_attributes", 0) & 1024 and not p.is_symlink()
        for f in folder.iterdir():
            if re.fullmatch(r"[A-Za-z0-9_.-]+\.json",f.name):
                technical.add(prefix+"/"+f.name)
    synthetic = {
        "assets/css/main.css": b"/* Synthetic asset */",
        "assets/js/main.js": b"/* Synthetic asset */",
        "assets/js/analytics-tracker.js": b"/* Synthetic asset */",
        "tools/automation-router.php": (PACKAGE/"router.php").read_bytes(),
        "tools/automation-crash-worker.php": (PACKAGE/"crash-worker.php").read_bytes(),
        "tools/cutover-probe.php": (PACKAGE/"probe.php").read_bytes(),
        "tools/reliability-public-routes.json": read("artifacts/php-storefront-presentation-parity-20261108/approval-materials/public-routes.json"),
        "admin/config.php": (
            b"<?php\ndeclare(strict_types=1);\nif (!defined('RENT_RK_AUDIT_ISOLATION_VERIFIED') || !RENT_RK_AUDIT_ISOLATION_VERIFIED) { throw new RuntimeException('Synthetic config requires audit isolation'); }\nif (!defined('ADMIN_USER')) define('ADMIN_USER', 'qa-dry-root');\n"
            + (b"define('ADMIN_PASSWORD_SALT', '');\ndefine('ADMIN_PASSWORD_HASH', '');\n" if OUT != PACKAGE else b"define('ADMIN_PASSWORD_HASH', 'no-login-in-b24-cli');\n")
            + b"define('TELEGRAM_BOT_TOKEN', '');\ndefine('TELEGRAM_CHAT_ID', '');\n"),
        "index.html": b"<!doctype html><title>B24 synthetic baseline</title>\n",
        "cars/index.html": b"<!doctype html><title>B24 synthetic catalog baseline</title>\n",
        "sitemap.xml": b'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"/>\n',
    }
    classes={f:c for c,files in (("runtime",runtime),("qa-policy",qa),("registered-evidence-input",artifacts),
        ("technical-metadata",technical),("synthetic",synthetic)) for f in files}
    assert len(classes)==sum(map(len,(runtime,qa,artifacts,technical,synthetic)))
    save("allowlist.json", dict(sorted(classes.items())))
    base = Path(os.environ["LOCALAPPDATA"])/"Temp" if os.name == "nt" else Path(tempfile.gettempdir()).resolve()
    assert base.resolve()==Path(tempfile.gettempdir()).resolve() and (os.name != "nt" or base.drive.casefold()=="c:")
    assert all(not getattr(p.lstat(), "st_file_attributes", 0) & 1024 and not p.is_symlink() for p in [base,*base.parents])
    owner=Path(tempfile.mkdtemp(prefix="rent-rk-b24-code-only-",dir=base))
    stage=owner/"code"
    rows=[]
    for f,c in sorted(classes.items()):
        data=synthetic[f] if c=="synthetic" else read(f)
        path=stage/f
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open("xb") as dst: dst.write(data)
        assert path.read_bytes()==data
        rows.append({"path":f,"class":c,"origin":"task-authored" if c=="synthetic" else f,
                     "bytes":len(data),"sha256":sha(data)})
    (stage/"tmp/business-data-audit").mkdir(parents=True)
    (stage/"data").mkdir()
    assert not (owner/"private").exists()
    assert {f.name for f in (stage/"private/rent-rk-data").iterdir()}=={"project-progress-map.json"}
    assert not list((stage/"data").iterdir())
    save("manifest.json",{"boundedFileSetSha256":sha(json.dumps(rows,separators=(",",":")).encode()),"files":rows})
    print(stage)


if __name__=="__main__":
    main()
