'use strict';
const fs=require('node:fs'), path=require('node:path'), crypto=require('node:crypto'), assert=require('node:assert/strict');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=f=>JSON.parse(fs.readFileSync(f));
module.exports=(stage,out)=>{
  const qa=read(path.join(out,'qa-before.json')), manifest=read(path.join(out,'manifest.json'));
  for(const [name,h] of Object.entries(qa))assert.equal(sha(fs.readFileSync(path.join(__dirname,name))),h,name);
  for(const {path:name,sha256:h} of manifest.files)assert.equal(sha(fs.readFileSync(path.join(stage,name))),h,name);
  return {status:'FROZEN_BYTES_MATCH',qaSha256:sha(fs.readFileSync(path.join(out,'qa-before.json'))),
    stageSha256:sha(fs.readFileSync(path.join(out,'manifest.json'))),qaCount:Object.keys(qa).length,stagedCount:manifest.files.length};
};
