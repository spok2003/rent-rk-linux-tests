'use strict';
const fs=require('node:fs'), path=require('node:path'), cp=require('node:child_process'), os=require('node:os');
const crypto=require('node:crypto'), assert=require('node:assert/strict');
assert(/^series-[0-9]+$/.test(process.argv[3]));
const out=path.join(__dirname,process.argv[3]), stage=fs.realpathSync(process.argv[2]), owner=path.dirname(stage);
const freeze=require('./verify-freeze.cjs');
const win=process.platform==='win32';
const temp=fs.realpathSync(win?path.join(process.env.LOCALAPPDATA,'Temp'):os.tmpdir());
assert.equal(path.dirname(owner),temp);
assert.equal(fs.realpathSync(os.tmpdir()),temp);
assert.match(path.basename(owner),/^rent-rk-b24-code-only-[a-z0-9_]+$/);
for(let p=stage;;p=path.dirname(p)){assert(!fs.lstatSync(p).isSymbolicLink());if(p===path.dirname(p))break;}
assert(!fs.existsSync(path.join(owner,'private')));
assert.deepEqual(fs.readdirSync(path.join(stage,'private/rent-rk-data')),['project-progress-map.json']);
assert.deepEqual(fs.readdirSync(path.join(stage,'data')),[]);
const frozen=freeze(stage,out);
fs.writeFileSync(path.join(out,'freeze-at-launch.json'),JSON.stringify(frozen,null,2)+'\n',{flag:'wx'});
const php=win?'D:/OSPanel/modules/PHP-8.4/php.exe':fs.realpathSync(process.env.RENT_RK_UNIX_QA_PHP||'/usr/bin/php');
const approvedEnv=['SystemRoot','WINDIR','SystemDrive','COMSPEC','LOCALAPPDATA','APPDATA','USERPROFILE','PATHEXT','TMPDIR'];
for(const k of Object.keys(process.env))if(!approvedEnv.some(x=>x.toLowerCase()===k.toLowerCase()))delete process.env[k];
process.env.PATH=win?[path.join(process.env.SystemRoot,'System32'),path.dirname(php)].join(path.delimiter):'/usr/bin:/bin';
process.env.TMP=temp;process.env.TEMP=temp;process.env.RENT_RK_QA_PHP=php;
const a=require(path.join(stage,'tools/business-data-audit.cjs'));
const read=f=>JSON.parse(fs.readFileSync(f));
const put=(f,v)=>{fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,JSON.stringify(v,null,2)+'\n');};
const sha=x=>a.sha(x);
const sort=x=>Array.isArray(x)?x.map(sort):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,sort(x[k])])):x;
const canonical=x=>JSON.stringify(sort(x));
const lab=a.create('php-automation',{temporary:true});
assert.equal(path.dirname(fs.realpathSync(lab.dir)),temp);
assert(!fs.existsSync(path.join(lab.dir,'sandbox/private')));
assert(!fs.existsSync(path.join(lab.lab,'admin/config.local.php')));
const at=f=>path.join(lab.lab,f), data=f=>at('tmp/default-data/'+f+'.json');
const save=(f,x)=>a.save(path.join(out,f),x);
save('lab-ownership.json',{stageOwner:owner,laboratory:lab.dir,laboratoryId:lab.baseline.laboratoryId});
const cutover=process.argv[4]!=='automation-only';
const guard='\nopcache.enable=0\nopcache.enable_cli=0\nopcache.file_cache=\nopcache.file_cache_only=0\n'
  +(cutover?'disable_functions=mail,curl_exec,curl_multi_exec,fsockopen,pfsockopen,stream_socket_client,exec,shell_exec,system,passthru,popen\n':'');
fs.appendFileSync(at('guard/isolation.ini'),guard);
fs.appendFileSync(at('guard/prepend.php'),'\ndefine("RENT_RK_APPROVED_PUBLIC_SERVER_CONFIG", dirname(__DIR__,2)."/synthetic-auto-trust.php");\n');
const probeConfig='guard/prepend-no-opt-in.php';
fs.copyFileSync(at('guard/prepend.php'),at(probeConfig),fs.constants.COPYFILE_EXCL);
fs.appendFileSync(at('guard/prepend.php'),'\ndefine("RENT_RK_PHP_PUBLICATION_AUTOMATION",true);\n');
if(cutover)fs.appendFileSync(at('guard/prepend.php'),'\ndefine("RENT_RK_PHP_PUBLICATION_CUTOVER",true);\n');
const guardHashes=()=>Object.fromEntries(['guard/isolation.ini','guard/prepend.php',probeConfig].map(p=>[p,sha(fs.readFileSync(at(p)))]));
const configured=guardHashes();
const env=a.env(lab.lab), inputs=a.validateLaboratoryInputs(lab);
if(!win) env.PHP_INI_SCAN_DIR=path.delimiter+env.PHP_INI_SCAN_DIR;
// This component has no browser automation or ZIP dependency. Preserve the stock preflight result.
const unusedModules=win?[]:['jszip','playwright'];
assert.deepEqual(inputs.violations.filter(v=>!(unusedModules.includes(v.input)&&v.reason==='NODE_MODULE_UNAVAILABLE')),[]);
assert.deepEqual(lab.baseline.protected,{});
save('isolation.json',{inputs,protectedStageSet:lab.baseline.protected,serverTrust:'SYNTHETIC_ONLY',
  guardSha256:sha(fs.readFileSync(at('guard/isolation.ini'))),prependSha256:sha(fs.readFileSync(at('guard/prepend.php'))),
  externalPrivateAbsent:true,workingSettingsCopied:false,platform:process.platform,cutover,configured,unusedModules});
save('baseline-binding.json',lab.baseline);
const extraFiles={
  'tools/reliability-public-routes.json':'tools/reliability-public-routes.json'
};
for(const [dest,src] of Object.entries(extraFiles)){
  if(fs.existsSync(at(dest))){assert(fs.readFileSync(at(dest)).equals(fs.readFileSync(path.join(stage,src))));continue;}
  fs.mkdirSync(path.dirname(at(dest)),{recursive:true});
  fs.copyFileSync(path.join(stage,src),at(dest),fs.constants.COPYFILE_EXCL);
}
const beforePublic=new Map(['index.html','sitemap.xml','cars/index.html'].map(f=>[f,fs.readFileSync(at(f))]));
require('./scenario.cjs')({fs,path,cp,crypto,assert,out,lab,at,data,save,env,php,a,beforePublic,inputs,stage,frozen,
  editorial:cutover,cutover,configured,reproduce:process.argv[4]==='reproduce'}).finally(()=>{
    const extras=Object.fromEntries(Object.entries(extraFiles).map(([dest,src])=>{
      const observed=sha(fs.readFileSync(at(dest)));assert.equal(observed,sha(fs.readFileSync(path.join(stage,src))));return [dest,observed];
    }));
    assert.deepEqual(guardHashes(),configured);
    save('freeze-after-main.json',{...freeze(stage,out),extras,configured,platform:process.platform});
  });
