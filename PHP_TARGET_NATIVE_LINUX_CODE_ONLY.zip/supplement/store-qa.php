<?php
declare(strict_types=1);
$root = realpath(__DIR__) . DIRECTORY_SEPARATOR;
if (PHP_SAPI !== 'cli' || !is_file($root . '.owned-synthetic') || !str_starts_with(basename(__DIR__), 'rrk-store-qa-')) {
    throw new RuntimeException('Task-owned CLI fixture required');
}
define('PROJECT_ROOT', $root);
define('DATA_DIR', $root . 'tmp/data/');
putenv('RENT_RK_ALLOW_TEST_DATA_DIR=1');
require $root . 'admin/includes/rental-return-store.php';
$out = [];
function check(bool $ok, string $id): void {
    if (!$ok) throw new RuntimeException($id);
    $GLOBALS['out'][] = $id;
}
$a = DATA_DIR . 'a.json';
$b = DATA_DIR . 'b.json';
$journal = DATA_DIR . '.rental-transactions/journal.json';
$before = '{"version":1}';
$after = '{"version":2}';
file_put_contents($a, $before);
file_put_contents($b, $before);
$work = static function () use ($a, $b): string {
    RentalReturnStore::stage($a, ['version'=>2]);
    RentalReturnStore::stage($b, ['version'=>2]);
    return 'ok';
};
$hit = 0;
$GLOBALS['rental_return_test_io_failure'] = static function ($stage, $file) use (&$hit) {
    return $stage === 'write' && $file === 'b.json' && $hit++ === 0 ? 'WRITE' : null;
};
$error = null;
try { RentalReturnStore::transaction($work); } catch (RuntimeException $e) { $error = $e; }
check($error !== null && $hit === 1 && ($GLOBALS['rental_return_io_failures'][0]['stage'] ?? null) === 'write', 'injected-write-refused');
check(file_get_contents($a) === $before && file_get_contents($b) === $before && !is_file($journal) && !is_file($b.'.rrv2-tmp'), 'rollback-exact-no-journal-or-temp');
unset($GLOBALS['rental_return_test_io_failure']);
RentalReturnStore::leave();
check(RentalReturnStore::transaction($work) === 'ok' && json_decode(file_get_contents($b), true)['version'] === 2, 'retry-succeeds');
$expected = file_get_contents($a);
check(json_decode($expected, true) === ['version'=>2] && file_get_contents($b) === $expected, 'both-expected-after-retry');
check(RentalReturnStore::transaction($work) === 'ok' && file_get_contents($a) === $expected &&
    file_get_contents($b) === $expected && !is_file($journal) && !is_file($a.'.rrv2-tmp') &&
    !is_file($b.'.rrv2-tmp') && !is_file($journal.'.rrv2-tmp'), 'repeat-preserves-both-exact-bytes-and-clean-journal');
RentalReturnStore::leave();
$entry = ['before'=>base64_encode($before),'beforeHash'=>hash('sha256',$before),'after'=>base64_encode($after),'afterHash'=>hash('sha256',$after)];
$newer = '{"version":3}';
file_put_contents($a, $after);
file_put_contents($b, $newer);
$prepared = json_encode(['format'=>1,'decision'=>'prepared','files'=>['a.json'=>$entry,'b.json'=>$entry]], JSON_THROW_ON_ERROR);
file_put_contents($journal, $prepared);
$error = null;
try { RentalReturnStore::enter(); } catch (RuntimeException $e) { $error = $e; }
check($error?->getCode() === 503 && str_contains($error->getPrevious()?->getMessage() ?? '', 'Конфликт восстановления'), 'conflict-refused');
check(file_get_contents($a) === $after && file_get_contents($b) === $newer && file_get_contents($journal) === $prepared, 'conflict-keeps-all-targets-and-journal');
$error = null;
try { RentalReturnStore::transaction($work); } catch (RuntimeException $e) { $error = $e; }
check($error?->getCode() === 503 && file_get_contents($b) === $newer, 'poisoned-process-refuses-retry');
echo json_encode(['checks'=>$out,'sourceSha256'=>hash_file('sha256',$root.'admin/includes/rental-return-store.php'),'qaSha256'=>hash_file('sha256',__FILE__),'platform'=>PHP_OS_FAMILY,'php'=>PHP_VERSION,'fault'=>'injected_not_os'], JSON_THROW_ON_ERROR);
