# One future manual run

Do not upload or dispatch without separate approval. Keep workflow_dispatch
as the only trigger. Pin the new ZIP's commit and NATIVE_KIT_RECEIPT SHA in
the checkout/input verification step; retain pinned Actions and permissions.
Do not change tool provisioning, non-root execution, ext4 or network none.
Verify the outer SHA, CRC, paths and every INDEX hash before extraction.
Run the original UNIX_RUN.md command unchanged. In the same isolated Linux
environment, independently stage the supplemental test on ext4:

```sh
t="$(mktemp -d "${TMPDIR:?}/rrk-store-qa-XXXXXXXX")"
mkdir -p "$t/admin/includes" "$t/tmp/data"
touch "$t/.owned-synthetic"
cp "$owner/code/admin/includes/rental-return-store.php" "$t/admin/includes/"
cp "$owner/supplement/store-qa.php" "$t/"
set +e
/usr/bin/php -n "$t/store-qa.php" > store-primary.json 2> store-stderr.txt
rc=$?
set -e
printf '%s\n' "$rc" > store-exit.txt
test "$rc" -eq 0
```

Verify supplemental SHA before and after. Retain only the separate primary,
stderr, exit code and manifests; require both series to succeed independently.
Use an always-run artifact step without masking either exit status. Register
a new anchor after the run, outside the frozen input. No old 52/52 is inherited.
